create or replace database DB_IAW_DEV_DM;

create or replace schema DB_IAW_DEV_DM.BR;

create or replace TABLE DB_IAW_DEV_DM.BR.DIM_USER (
	"User Login" VARCHAR(255) NOT NULL COMMENT 'the login of the user account',
	"First Name" VARCHAR(255) NOT NULL COMMENT 'the user''s first name',
	"Last Name" VARCHAR(255) NOT NULL COMMENT 'the user''s last name',
	"Email Address" VARCHAR(255) COMMENT 'the user''s email address',
	"Capacity" VARCHAR(255) COMMENT 'What user can see',
	"Comments" VARCHAR(255) COMMENT 'any comments',
	MD_LOADDATE TIMESTAMP_NTZ(7) COMMENT 'metadata load date',
	MD_SRCSYSTEM VARCHAR(100)
);
create or replace TABLE DB_IAW_DEV_DM.BR.IAS_CERTS_ADVISOR_RVP (
	ADVISOR_NAME VARCHAR(512),
	ADVISOR_ROLE VARCHAR(512),
	RVP_NAME VARCHAR(512)
);
create or replace TABLE DB_IAW_DEV_DM.BR.IAS_MANUAL_ADVISOR_RVP (
	ADVISOR VARCHAR(512),
	TEAM VARCHAR(512),
	REPID VARCHAR(512),
	RVP VARCHAR(512),
	PROVINCE VARCHAR(512)
);
create or replace TABLE DB_IAW_DEV_DM.BR.IAS_MAPPING_OPER_TYPE (
	DESCRIPTION_SHORT_EN VARCHAR(30),
	DESCRIPTION_SHORT_FR VARCHAR(30),
	DESCRIPTION_EN VARCHAR(60),
	DESCRIPTION_FR VARCHAR(60),
	CASHFLOW VARCHAR(12),
	DISTRIBUTION VARCHAR(3)
);
create or replace TABLE DB_IAW_DEV_DM.BR.IAS_MONTHLY_MILESTONES (
	ADVISOR VARCHAR(512),
	TEAM VARCHAR(512),
	REPID VARCHAR(512),
	RVP VARCHAR(512),
	PROVINCE VARCHAR(512),
	AUA_DEC NUMBER(34,4),
	AUA_JAN NUMBER(34,4),
	AUA_FEB NUMBER(34,4)
);
create or replace TABLE DB_IAW_DEV_DM.BR.IAS_PRODUCT_ASSETCATEGORY (
	TI_ALTERNATE_TI_TYPE VARCHAR(50),
	ASSET_CATEGORY VARCHAR(512)
);
create or replace TABLE DB_IAW_DEV_DM.BR.IAS_PRODUCT_TYPE (
	DESCRIPTIONEN VARCHAR(512),
	DESCRIPTIONFR VARCHAR(512),
	TI_ALTERNATE_TI_TYPE VARCHAR(50),
	TI_ALTERNATE_TI_CLASS VARCHAR(50),
	PRODUCTTYPE VARCHAR(100)
);
create or replace TABLE DB_IAW_DEV_DM.BR.IAS_RAPCODE_PLAN (
	ACCOUNT_RAP_CODE VARCHAR(10),
	RETAIL_PLAN VARCHAR(100),
	PLAN_LABEL VARCHAR(512),
	ACCOUNT_TYPE VARCHAR(512),
	GROUP_TYPE_CODE VARCHAR(100),
	ASC_1_RESP_PLAN_TYPES VARCHAR(100),
	ACCUMULATION_TYPE VARCHAR(100)
);
create or replace view DB_IAW_DEV_DM.BR.VW_IAS_RRCODE_MASTERCODE(
	A_C_REPRESENTATIVE,
	COMMISSIONPCT,
	TOREPID,
	MASTER_CODE,
	PHYSICAL,
	COM_TYPE,
	IS_RESHARED
) as

/* Advisors from commission portal : All active users of the portal */
WITH ADV AS 
(
	SELECT DISTINCT TRIM(RM.MAINREPCODE) AS MAINREPCODE, RM.FIRSTNAME, RM.LASTNAME
	FROM DB_IAW_DEV_STAGING.IAS_COMMISSION.REGISTERED_REPRESENTATIVE rm 
	WHERE rm.ACTIVE = 1 
	ORDER BY MAINREPCODE, RM.FIRSTNAME, RM.LASTNAME 
),

/* Only active shares of commissions */
LV_SHARE AS 
(
	SELECT * FROM DB_IAW_DEV_STAGING.IAS_COMMISSION.SHARE R
	WHERE SHARETYPE <> 'noreference' AND SHARETYPE <> 'option' AND (FROMREPID <> 'SBEP' OR SHARETYPE <> 'override')
),

/* Case 1 : RR code share with a master code of an advisor */
FROM_RR_TO_MAIN AS
(
	SELECT DISTINCT TRIM(s.FROMREPID) AS FROMREPID, s.COMMISSIONPCT, TRIM(s.TOREPID) AS TOREPID, 
	TRIM(ADV_to.MAINREPCODE) AS MASTER_CODE, 1 AS PHYSICAL, 'FROM_RR_TO_MAIN' AS COM_TYPE, 0 AS IS_RESHARED	
	FROM LV_SHARE s 
	LEFT JOIN ADV ADV_to
	ON TRIM(s.TOREPID) = TRIM(ADV_to.MAINREPCODE)
	WHERE ADV_to.MAINREPCODE IS NOT NULL AND s.COMMISSIONPCT > 0
	ORDER BY FROMREPID
),

/* Case 2 : RR code share with RR code that has a master code */
FROM_RR_TO_RR_TO_MAIN AS
(
	SELECT DISTINCT TRIM(s.FROMREPID) AS FROMREPID, s.COMMISSIONPCT, TRIM(s.TOREPID) AS TOREPID, 
  TRIM(rr.MAINREPCODE) AS MASTER_CODE, 1 AS PHYSICAL, 'FROM_RR_TO_RR_TO_MAIN' AS COM_TYPE, 0 AS IS_RESHARED
	FROM LV_SHARE s 
	LEFT JOIN FROM_RR_TO_MAIN
	ON FROM_RR_TO_MAIN.FROMREPID = TRIM(s.FROMREPID) AND FROM_RR_TO_MAIN.TOREPID = TRIM(s.TOREPID) 	
	LEFT JOIN DB_IAW_DEV_STAGING.IAS_COMMISSION.REGISTERED_REPRESENTATIVE rr 
	ON TRIM(rr.REPID) = TRIM(s.TOREPID) AND rr.ACTIVE=1 AND TRIM(rr.REPID) = TRIM(rr.MAINREPCODE)
	WHERE FROM_RR_TO_MAIN.FROMREPID IS NULL AND s.COMMISSIONPCT > 0 AND rr.MAINREPCODE IS NOT NULL
	ORDER BY FROMREPID
),

/* RR code share with an RR code that is not linked to a main rep code */
OTHER AS
(
	SELECT DISTINCT TRIM(s.FROMREPID) AS FROMREPID, s.COMMISSIONPCT, TRIM(s.TOREPID) AS TOREPID, 
  TRIM(s.TOREPID) AS MASTER_CODE, 0 AS PHYSICAL, 'OTHER' AS COM_TYPE, 0 AS IS_RESHARED
	FROM LV_SHARE s 
	LEFT JOIN FROM_RR_TO_MAIN
	ON FROM_RR_TO_MAIN.FROMREPID = TRIM(s.FROMREPID) AND FROM_RR_TO_MAIN.TOREPID = TRIM(s.TOREPID) 
	LEFT JOIN FROM_RR_TO_RR_TO_MAIN
	ON FROM_RR_TO_RR_TO_MAIN.FROMREPID = TRIM(s.FROMREPID) AND FROM_RR_TO_RR_TO_MAIN.TOREPID = TRIM(s.TOREPID)
	WHERE s.COMMISSIONPCT > 0 AND FROM_RR_TO_MAIN.FROMREPID IS NULL AND  FROM_RR_TO_RR_TO_MAIN.FROMREPID IS NULL 
	ORDER BY FROMREPID
),

AV_ALL AS
(
	SELECT T.A_C_REPRESENTATIVE, T.COMMISSIONPCT, T.TOREPID, T.MASTER_CODE, T.PHYSICAL, T.COM_TYPE, T.IS_RESHARED
	FROM 
	(
		SELECT FROMREPID AS A_C_REPRESENTATIVE, COMMISSIONPCT, TOREPID, MASTER_CODE, PHYSICAL, COM_TYPE, IS_RESHARED
		FROM FROM_RR_TO_MAIN
		WHERE MASTER_CODE IS NOT NULL
		
		UNION ALL
		
		SELECT FROMREPID AS A_C_REPRESENTATIVE, COMMISSIONPCT, TOREPID, MASTER_CODE, PHYSICAL, COM_TYPE, IS_RESHARED
		FROM FROM_RR_TO_RR_TO_MAIN
		WHERE MASTER_CODE IS NOT NULL
		
		UNION ALL
		
		SELECT FROMREPID AS A_C_REPRESENTATIVE, COMMISSIONPCT, TOREPID, MASTER_CODE, PHYSICAL, COM_TYPE, IS_RESHARED
		FROM OTHER
		WHERE MASTER_CODE IS NOT NULL
	) AS T
)

SELECT *
FROM AV_ALL
ORDER BY A_C_REPRESENTATIVE;
CREATE OR REPLACE FILE FORMAT DB_IAW_DEV_DM.BR.CSV_DEFAULT
;
CREATE OR REPLACE FILE FORMAT DB_IAW_DEV_DM.BR.PIPE_UTF16
	FIELD_DELIMITER = '|'
;
create or replace schema DB_IAW_DEV_DM.DATALAKE;

create or replace schema DB_IAW_DEV_DM.EXPLORATION;

create or replace TABLE DB_IAW_DEV_DM.EXPLORATION.IAS_COMMISSION_REVENUES (
	HK_LINK VARCHAR(40) COMMENT 'Hash of the business keys',
	HK_HUB_CONTRACT VARCHAR(40) COMMENT 'Hash key for PARTY_ROLE_ACCOUNT_HOLDER',
	HK_HUB_PARTY_ROLE_ADVISOR VARCHAR(40) COMMENT 'Hash key for the REGISTERED_REPRESENTATIVE_COMMISSION',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	REPID VARCHAR(50) COMMENT 'Master code  code',
	ADVISOR_ID VARCHAR(512) COMMENT 'Advisor ID in commission portal',
	PROGRAM_TYPE VARCHAR(512) COMMENT 'Program type of the account',
	ACCOUNTID VARCHAR(100) COMMENT 'Account ID',
	PROCESSDATE DATE COMMENT 'Process Date',
	SOURCECODE VARCHAR(50) COMMENT 'Source Code / TRANSACTION_TYPE',
	QUANTITY NUMBER(38,0) COMMENT 'Transaction quantity',
	TRANSTYPE VARCHAR(10) COMMENT 'Transaction Type ([B]uy/[S]ell) / BUY_SELL_INDICATOR',
	REVENUE NUMBER(38,2) COMMENT 'Representative gross revenue',
	COMMISSION NUMBER(38,2) COMMENT 'Representative gross commission',
	NETCOMMISSION NUMBER(38,2) COMMENT 'Representative net commission',
	TRANSFEE NUMBER(38,2) COMMENT 'Representative transaction fees'
);
create or replace TABLE DB_IAW_DEV_DM.EXPLORATION.IAS_HOLDINGS (
	HK_LINK VARCHAR(40) COMMENT 'Hash key for the Link',
	HK_HUB_CONTRACT VARCHAR(40) COMMENT 'Hash key for HUB_CONTRACT',
	HK_HUB_REGISTERED_REPRESENTATIVE VARCHAR(40) COMMENT 'Hash key for HUB_REGISTERED_REPRESENTATIVE',
	HK_HUB_INVESTMENT_PRODUCT_TYPE VARCHAR(40) COMMENT 'Hash key for HUB_INVESTMENT_PRODUCT_TYPE',
	MD_SEQ VARCHAR(50) COMMENT 'The value of METADATA$FILE_ROW_NUMBER when loading using INFORMATICA',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(40) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Extraction date of the occurrence',
	A_C_ID VARCHAR(100) COMMENT 'Account ID',
	A_C_REPRESENTATIVE VARCHAR(50) COMMENT 'Advisor RR code',
	TI_ALTERNATE_ID VARCHAR(50) COMMENT 'Financial product ID',
	TRAN_SUMM_CURR_MKT_VALUE NUMBER(38,2) COMMENT 'Market value of the holding in CAD or USD',
	TRAN_SUMM_BUSINESS_DATE DATE COMMENT 'Update business date',
	TI_ALTERNATE_TI_TYPE VARCHAR(50) COMMENT 'Financial product type ID',
	B_V_SECURITY_POSITION_VAL NUMBER(38,2) COMMENT 'Book value',
	B_V_SECURITY_POSITION_COS NUMBER(38,4) COMMENT 'Average cost base',
	TRAN_SUMM_AVG_UNIT_COST NUMBER(38,5) COMMENT 'Average cost base',
	TRAN_SUMM_NET_SETT_AMT NUMBER(38,2) COMMENT 'Cash position',
	TRAN_SUMM_CURRENCY VARCHAR(10) COMMENT 'Holding value currency',
	TRAN_SUMM_SETT_QTY NUMBER(38,4) COMMENT 'Units',
	TRAN_SUMM_TRADE_QTY NUMBER(38,4) COMMENT 'Units calculated by trade date'
);
create or replace schema DB_IAW_DEV_DM.EXTERNAL_KPI;

create or replace TABLE DB_IAW_DEV_DM.EXTERNAL_KPI.MASTER_KPI_DATA_CLARINGTON (
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Extraction date of the occurrence',
	KPI_DATE TIMESTAMP_NTZ(9) COMMENT 'Date',
	TRADE_ACCOUNT_PROCESSING_AUTOMATION_PCT_MF NUMBER(20,4) COMMENT 'Trade/Account Processing Automation % MF',
	TRADE_ACCOUNT_PROCESSING_AUTOMATION_PCT_GIF NUMBER(20,4) COMMENT 'Trade/Account Processing Automation % GIF',
	FTE NUMBER(20,4) COMMENT 'FTE',
	TOTAL_TRANSACTIONS_MF NUMBER(20,4) COMMENT 'Total Transactions MF',
	TOTAL_TRANSACTIONS_GIF NUMBER(20,4) COMMENT 'Total Transactions GIF',
	TOTAL_TRANSACTIONS_FTE_MF NUMBER(20,4) COMMENT 'Total Transactions/FTE MF',
	TOTAL_TRANSACTIONS_FTE_GIF NUMBER(20,4) COMMENT 'Total Transactions/FTE GIF',
	NO_OF_ACCOUNTS NUMBER(20,4) COMMENT 'No. of Accounts',
	ACCOUNTS_FTE NUMBER(20,4) COMMENT 'Accounts/FTE',
	ACCOUNTS_FTE_TARGET NUMBER(20,4) COMMENT 'Accounts/FTE Target',
	YOY_NEW_ACCOUNTS_CLIENT_NAME NUMBER(20,4) COMMENT 'YoY New Accounts Client Name',
	YOY_NEW_ACCOUNTS_CLIENT_NOMINEE NUMBER(20,4) COMMENT 'YoY New Accounts Client Nominee',
	EXPENSES NUMBER(20,4) COMMENT 'Expenses',
	REVENUES NUMBER(20,4) COMMENT 'Revenues',
	EFFICIENCY_RATIO NUMBER(20,4) COMMENT 'Efficiency Ratio',
	EXPENSES_TARGET NUMBER(20,4) COMMENT 'Expenses Target',
	REVENUE_TARGET NUMBER(20,4) COMMENT 'Revenue Target',
	EFFICIENCY_RATIO_TARGET NUMBER(20,4) COMMENT 'Efficiency Ratio Target',
	TOTAL_ASSETS NUMBER(20,4) COMMENT 'Total Assets',
	AFFILIATE_PENETRATION_IIROC NUMBER(20,4) COMMENT 'Affiliate Penetration IIROC',
	AFFILIATE_PENETRATION_IIROC_TARGET NUMBER(20,4) COMMENT 'Affiliate Penetration IIROC Target',
	AFFILIATE_PENETRATION_MFDA NUMBER(20,4) COMMENT 'Affiliate Penetration MFDA',
	AFFILIATE_PENETRATION_MFDA_TARGET NUMBER(20,4) COMMENT 'Affiliate Penetration MFDA Target',
	GROSS_MARGIN NUMBER(20,4) COMMENT 'Gross Margin',
	GROSS_MARGIN_TARGET NUMBER(20,4) COMMENT 'Gross Margin Target',
	NET_SALES NUMBER(20,4) COMMENT 'Net Sales',
	NO_OF_ACCOUNTS_CLIENT_NAME NUMBER(20,4) COMMENT '# of Accounts Client Name',
	NO_OF_ACCOUNTS_NOMINEE NUMBER(20,4) COMMENT '# of Accounts Nominee'
);
create or replace TABLE DB_IAW_DEV_DM.EXTERNAL_KPI.MASTER_KPI_DATA_IAPW (
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(40) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Extraction date of the occurrence',
	KPI_DATE TIMESTAMP_NTZ(9) COMMENT 'KPI Date',
	NO_OF_ACTIVE_CLIENTS NUMBER(38,4) COMMENT 'No. of Active Clients',
	NO_OF_ACTIVE_ACCOUNTS NUMBER(38,4) COMMENT 'No. of Active Accounts',
	FTE NUMBER(38,4) COMMENT 'FTE',
	ACCOUNTS_FTE NUMBER(38,4) COMMENT 'Accounts/FTE',
	ACCOUNTS_FTE_TARGET NUMBER(38,4) COMMENT 'Accounts/FTE Target',
	APPWAY_REGISTRATION NUMBER(38,4) COMMENT 'Appway % Registration',
	APPWAY_REGISTRATION_TARGET NUMBER(38,4) COMMENT 'Appway % Registration Target',
	NO_OF_CLIENT_ID_REGISTERED NUMBER(38,4) COMMENT 'No. of Client ID registered',
	PORTAL_REGISTRATION NUMBER(38,4) COMMENT 'Portal % registration',
	PORTAL_REGISTRATION_TARGET NUMBER(38,4) COMMENT 'Portal % registration Target',
	MYPORTFOLIO_TO_NEW_CLIENT NUMBER(38,4) COMMENT 'MyPortfolio+ to new client',
	E_DELIVERY_PORTFOLIO_STATEMENTS NUMBER(38,4) COMMENT 'E-Delivery Portfolio Statements',
	E_DELIVERY_TAX_SLIPS NUMBER(38,4) COMMENT 'E-Delivery Tax Slips',
	E_DELIVERY_CONFIRMS NUMBER(38,4) COMMENT 'E-Delivery Confirms',
	AVG_E_DELIVERY_REGISTRATION NUMBER(38,4) COMMENT 'Avg. E-Delivery % registration',
	E_DELIVERY_REGISTRATION_TARGET NUMBER(38,4) COMMENT 'E-Delivery % registration Target',
	RETAIL_YTD_EXPENSES NUMBER(38,4) COMMENT 'Retail YTD Expenses',
	RETAIL_YTD_REVENUES NUMBER(38,4) COMMENT 'Retail YTD Revenues',
	RETAIL_FINANCIAL_EFFICIENCY_RATIO NUMBER(38,4) COMMENT 'Retail Financial Efficiency Ratio',
	RETAIL_YTD_EXPENSES_TARGET NUMBER(38,4) COMMENT 'Retail YTD Expenses Target',
	RETAIL_YTD_REVENUES_TARGET NUMBER(38,4) COMMENT 'Retail YTD Revenues Target',
	RETAIL_EFFICIENCY_RATIO_TARGET NUMBER(38,4) COMMENT 'Retail Efficiency Ratio Target',
	CAP_MRKTS_YTD_EXPENSES NUMBER(38,4) COMMENT 'Cap. Mrkts YTD Expenses',
	CAP_MKTS_YTD_REVENUES NUMBER(38,4) COMMENT 'Cap. Mkts YTD Revenues',
	CAP_MRKTS_EFFICIENCY_RATIO NUMBER(38,4) COMMENT 'Cap. Mrkts Efficiency Ratio',
	CAP_MRKTS_YTD_EXPENSES_TARGET NUMBER(38,4) COMMENT 'Cap. Mrkts YTD Expenses Target',
	CAP_MRKTS_YTD_REVENUES_TARGET NUMBER(38,4) COMMENT 'Cap. Mrkts YTD Revenues Target',
	CAP_MRKTS_EFFICIENCY_RATIO_TARGET NUMBER(38,4) COMMENT 'Cap. Mrkts Efficiency Ratio Target',
	TOTAL_ASSETS NUMBER(38,4) COMMENT 'Total Assets',
	NET_TOTAL_REVENUE NUMBER(38,4) COMMENT 'Net Total Revenue',
	NET_TOTAL_REVENUE_TARGET NUMBER(38,4) COMMENT 'Net Total Revenue Target',
	NET_BOND_DESK_REVENUE NUMBER(38,4) COMMENT 'Net Bond Desk Revenue',
	NET_BOND_DESK_REVENUE_TARGET NUMBER(38,4) COMMENT 'Net Bond Desk Revenue Target',
	CAPITAL_MKTS_REVENUE NUMBER(38,4) COMMENT 'Capital Mkts Revenue',
	CAPITAL_MKTS_REVENUE_TARGET NUMBER(38,4) COMMENT 'Capital Mkts Revenue Target',
	NET_RETAIL_REVENUE NUMBER(38,4) COMMENT 'Net Retail Revenue',
	NET_RETAIL_REVENUE_TARGET NUMBER(38,4) COMMENT 'Net Retail Revenue Target',
	RETAIL_REVENUE_GROWTH NUMBER(38,4) COMMENT 'Retail Revenue Growth',
	EBIT NUMBER(38,4) COMMENT 'EBIT',
	SMA_ADOPTION NUMBER(38,4) COMMENT 'SMA Adoption',
	INSURANCE_REVENUE NUMBER(38,4) COMMENT 'Insurance Revenue',
	AUA_TARGET NUMBER(38,4) COMMENT 'AUA Target',
	DEPARTED_ADVISORS NUMBER(38,4) COMMENT 'Departed Advisors',
	RECRUITING NUMBER(38,4) COMMENT 'Recruiting',
	TERMINATED_ADVISORS NUMBER(38,4) COMMENT 'Terminated Advisors'
);
create or replace TABLE DB_IAW_DEV_DM.EXTERNAL_KPI.MASTER_KPI_DATA_INVESTIA (
	HK_HUB VARCHAR(40) COMMENT ' Hash key for the Hub ',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT ' Start Date of the image/version ',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT ' Creation Date Time of the occurrence ',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT ' Represents the source system, file, etc. of the instance ',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT ' Source system ',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT ' Extraction date of the occurrence ',
	KPI_DATE TIMESTAMP_NTZ(9) COMMENT ' KPI Date ',
	NO_CLIENT_ID NUMBER(20,4) COMMENT ' # Client ID ',
	E_DELIVERY NUMBER(20,4) COMMENT ' E-delivery ',
	E_DELIVERY_PCT NUMBER(20,4) COMMENT ' % E-delivery ',
	E_DELIVERY_TARGET_PCT NUMBER(20,4) COMMENT ' % E-delivery Target ',
	PORTAL_REGISTRATION NUMBER(20,4) COMMENT ' Portal Registration ',
	PORTAL_REGISTRATION_PCT NUMBER(20,4) COMMENT ' % Portal Registration ',
	PORTAL_REGISTRATION_TARGET NUMBER(20,4) COMMENT ' Portal Registration Target ',
	FTE NUMBER(20,4) COMMENT ' FTE ',
	CLIENTS_BY_FTE NUMBER(20,4) COMMENT ' Clients by FTE ',
	CLIENTS_BY_FTE_TARGET NUMBER(20,4) COMMENT ' Clients by FTE Target ',
	NO_OF_ACCOUNTS NUMBER(20,4) COMMENT ' No of accounts ',
	ACCOUNTS_BY_FTE NUMBER(20,4) COMMENT ' Accounts by FTE ',
	ACTUAL_YTD_EXPENSES NUMBER(20,4) COMMENT ' Actual YTD Expenses ',
	ACTUAL_YTD_REVENUES NUMBER(20,4) COMMENT ' Actual YTD Revenues ',
	EFFICIENCY_RATIO NUMBER(20,4) COMMENT ' Efficiency Ratio ',
	YTD_EXPENSES_TARGET NUMBER(20,4) COMMENT ' YTD Expenses Taregt ',
	YTD_REVENUES_TARGET NUMBER(20,4) COMMENT ' YTD Revenues Target ',
	EFFICIENCY_RATIO_TARGET NUMBER(20,4) COMMENT ' Efficiency Ratio Target ',
	AUA_IN_NOMINEE NUMBER(20,4) COMMENT ' AUA in Nominee ',
	AUA_IN_CLIENT_NAME NUMBER(20,4) COMMENT ' AUA in Client Name ',
	NO_OF_RPAS_IMPLEMENTED NUMBER(20,4) COMMENT ' # of RPAs implemented ',
	HOURS_SAVED_DUE_TO_RPAS NUMBER(20,4) COMMENT ' Hours Saved due to RPAs ',
	CONTINUOUS_IMPROVEMENT_QUICK_WINS NUMBER(20,4) COMMENT ' Continuous improvement/quick wins ',
	TOTAL_ASSETS NUMBER(20,4) COMMENT ' Total Assets  ',
	ORGANIC_GROWTH NUMBER(20,4) COMMENT ' Organic Growth  ',
	TOTAL_REVENUE NUMBER(20,4) COMMENT ' Total Revenue  ',
	TOTAL_REVENUE_TARGET NUMBER(20,4) COMMENT ' Total Revenue Target  ',
	RECRUITING NUMBER(20,4) COMMENT ' Recruiting  ',
	TERMINATED_ADVISORS NUMBER(20,4) COMMENT ' Terminated Advisors  '
);
create or replace view DB_IAW_DEV_DM.EXTERNAL_KPI.VW_MASTER_KPI_DATA_CLARINGTON(
	"Start Date of the image/version",
	"Extraction date of the occurrence",
	"KPI Date",
	"Trade/Account Processing Automation % MF",
	"Trade/Account Processing Automation % GIF",
	FTE,
	"Total Transactions MF",
	"Total Transactions GIF",
	"Total Transactions/FTE MF",
	"Total Transactions/FTE GIF",
	"No. of Accounts",
	"Accounts/FTE",
	"Accounts/FTE Target",
	"YoY New Accounts Client Name",
	"YoY New Accounts Client Nominee",
	"Expenses",
	"Revenues",
	"Efficiency Ratio",
	"Expenses Target",
	"Revenue Target",
	"Efficiency Ratio Target",
	"Total Assets",
	"Affiliate Penetration IIROC",
	"Affiliate Penetration IIROC Target",
	"Affiliate Penetration MFDA",
	"Affiliate Penetration MFDA Target",
	"Gross Margin",
	"Gross Margin Target",
	"Net Sales",
	"# of Accounts Client Name",
	"# of Accounts Nominee"
) as 
SELECT 
MD_START_DT	 AS "Start Date of the image/version" ,
MD_EXTRACT_DT	 AS "Extraction date of the occurrence" ,
KPI_DATE AS "KPI Date",
TRADE_ACCOUNT_PROCESSING_AUTOMATION_PCT_MF AS "Trade/Account Processing Automation % MF",
TRADE_ACCOUNT_PROCESSING_AUTOMATION_PCT_GIF AS "Trade/Account Processing Automation % GIF",
FTE AS "FTE",
TOTAL_TRANSACTIONS_MF AS "Total Transactions MF",
TOTAL_TRANSACTIONS_GIF AS "Total Transactions GIF",
TOTAL_TRANSACTIONS_FTE_MF AS "Total Transactions/FTE MF",
TOTAL_TRANSACTIONS_FTE_GIF AS "Total Transactions/FTE GIF",
NO_OF_ACCOUNTS AS "No. of Accounts",
ACCOUNTS_FTE AS "Accounts/FTE",
ACCOUNTS_FTE_TARGET AS "Accounts/FTE Target",
YOY_NEW_ACCOUNTS_CLIENT_NAME AS "YoY New Accounts Client Name",
YOY_NEW_ACCOUNTS_CLIENT_NOMINEE AS "YoY New Accounts Client Nominee",
EXPENSES AS "Expenses",
REVENUES AS "Revenues",
EFFICIENCY_RATIO AS "Efficiency Ratio",
EXPENSES_TARGET AS "Expenses Target",
REVENUE_TARGET AS "Revenue Target",
EFFICIENCY_RATIO_TARGET AS "Efficiency Ratio Target",
TOTAL_ASSETS AS "Total Assets",
AFFILIATE_PENETRATION_IIROC AS "Affiliate Penetration IIROC",
AFFILIATE_PENETRATION_IIROC_TARGET AS "Affiliate Penetration IIROC Target",
AFFILIATE_PENETRATION_MFDA AS "Affiliate Penetration MFDA",
AFFILIATE_PENETRATION_MFDA_TARGET AS "Affiliate Penetration MFDA Target",
GROSS_MARGIN AS "Gross Margin",
GROSS_MARGIN_TARGET AS "Gross Margin Target",
NET_SALES AS "Net Sales",
NO_OF_ACCOUNTS_CLIENT_NAME AS "# of Accounts Client Name",
NO_OF_ACCOUNTS_NOMINEE AS "# of Accounts Nominee"
from DB_IAW_DEV_DM.EXTERNAL_KPI.MASTER_KPI_DATA_CLARINGTON;
create or replace view DB_IAW_DEV_DM.EXTERNAL_KPI.VW_MASTER_KPI_DATA_IAPW(
	"Start Date of the image/version",
	"Extraction date of the occurrence",
	"KPI Date",
	"No. of Active Clients",
	"No. of Active Accounts",
	FTE,
	"Accounts/FTE",
	"Accounts/FTE Target",
	"Appway % Registration",
	"Appway % Registration Target",
	"No. of Client ID registered",
	"Portal % registration",
	"Portal % registration Target",
	"MyPortfolio+ to new client ",
	"E-Delivery Portfolio Statements",
	"E-Delivery Tax Slips",
	"E-Delivery Confirms",
	"Avg. E-Delivery % registration",
	"E-Delivery % registration Target",
	"Retail YTD Expenses",
	"Retail YTD Revenues",
	"Retail Financial Efficiency Ratio",
	"Retail YTD Expenses Target",
	"Retail YTD Revenues Target",
	"Retail Efficiency Ratio Target",
	"Cap. Mrkts YTD Expenses",
	"Cap. Mkts YTD Revenues",
	"Cap. Mrkts Efficiency Ratio",
	"Cap. Mrkts YTD Expenses Target",
	"Cap. Mrkts YTD Revenues Target",
	"Cap. Mrkts Efficiency Ratio Target",
	"Total Assets",
	"Net Total Revenue",
	"Net Total Revenue Target",
	"Net Bond Desk Revenue",
	"Net Bond Desk Revenue Target",
	"Capital Mkts Revenue",
	"Capital Mkts Revenue Target",
	"Net Retail Revenue",
	"Net Retail Revenue Target",
	"Retail Revenue Growth",
	EBIT,
	"SMA Adoption",
	"Insurance Revenue",
	"AUA Target",
	"Departed Advisors",
	"Recruiting",
	"Terminated Advisors"
) as
SELECT 
MD_START_DT	 AS "Start Date of the image/version" ,
MD_EXTRACT_DT	 AS "Extraction date of the occurrence" ,
KPI_DATE as "KPI Date",
NO_OF_ACTIVE_CLIENTS as "No. of Active Clients",
NO_OF_ACTIVE_ACCOUNTS as "No. of Active Accounts",
FTE as "FTE",
ACCOUNTS_FTE as "Accounts/FTE",
ACCOUNTS_FTE_TARGET as "Accounts/FTE Target",
APPWAY_REGISTRATION as "Appway % Registration",
APPWAY_REGISTRATION_TARGET as "Appway % Registration Target",
NO_OF_CLIENT_ID_REGISTERED as "No. of Client ID registered",
PORTAL_REGISTRATION as "Portal % registration",
PORTAL_REGISTRATION_TARGET as "Portal % registration Target",
MYPORTFOLIO_TO_NEW_CLIENT as "MyPortfolio+ to new client",
E_DELIVERY_PORTFOLIO_STATEMENTS as "E-Delivery Portfolio Statements",
E_DELIVERY_TAX_SLIPS as "E-Delivery Tax Slips",
E_DELIVERY_CONFIRMS as "E-Delivery Confirms",
AVG_E_DELIVERY_REGISTRATION as "Avg. E-Delivery % registration",
E_DELIVERY_REGISTRATION_TARGET as "E-Delivery % registration Target",
RETAIL_YTD_EXPENSES as "Retail YTD Expenses",
RETAIL_YTD_REVENUES as "Retail YTD Revenues",
RETAIL_FINANCIAL_EFFICIENCY_RATIO as "Retail Financial Efficiency Ratio",
RETAIL_YTD_EXPENSES_TARGET as "Retail YTD Expenses Target",
RETAIL_YTD_REVENUES_TARGET as "Retail YTD Revenues Target",
RETAIL_EFFICIENCY_RATIO_TARGET as "Retail Efficiency Ratio Target",
CAP_MRKTS_YTD_EXPENSES as "Cap. Mrkts YTD Expenses",
CAP_MKTS_YTD_REVENUES as "Cap. Mkts YTD Revenues",
CAP_MRKTS_EFFICIENCY_RATIO as "Cap. Mrkts Efficiency Ratio",
CAP_MRKTS_YTD_EXPENSES_TARGET as "Cap. Mrkts YTD Expenses Target",
CAP_MRKTS_YTD_REVENUES_TARGET as "Cap. Mrkts YTD Revenues Target",
CAP_MRKTS_EFFICIENCY_RATIO_TARGET as "Cap. Mrkts Efficiency Ratio Target",
TOTAL_ASSETS as "Total Assets",
NET_TOTAL_REVENUE as "Net Total Revenue",
NET_TOTAL_REVENUE_TARGET as "Net Total Revenue Target",
NET_BOND_DESK_REVENUE as "Net Bond Desk Revenue",
NET_BOND_DESK_REVENUE_TARGET as "Net Bond Desk Revenue Target",
CAPITAL_MKTS_REVENUE as "Capital Mkts Revenue",
CAPITAL_MKTS_REVENUE_TARGET as "Capital Mkts Revenue Target",
NET_RETAIL_REVENUE as "Net Retail Revenue",
NET_RETAIL_REVENUE_TARGET as "Net Retail Revenue Target",
RETAIL_REVENUE_GROWTH as "Retail Revenue Growth",
EBIT as "EBIT",
SMA_ADOPTION as "SMA Adoption",
INSURANCE_REVENUE as "Insurance Revenue",
AUA_TARGET as "AUA Target",
DEPARTED_ADVISORS as "Departed Advisors",
RECRUITING as "Recruiting",
TERMINATED_ADVISORS as "Terminated Advisors" 
FROM DB_IAW_DEV_DM.EXTERNAL_KPI.MASTER_KPI_DATA_IAPW;
create or replace view DB_IAW_DEV_DM.EXTERNAL_KPI.VW_MASTER_KPI_DATA_INVESTIA(
	"Start Date of the image/version",
	"Extraction date of the occurrence",
	"KPI Date",
	"# Client ID",
	"E-delivery",
	"% E-delivery",
	"% E-delivery Target",
	"Portal Registration",
	"% Portal Registration",
	"Portal Registration Target",
	FTE,
	"Clients by FTE",
	"Clients by FTE Target",
	"No of accounts",
	"Accounts by FTE",
	"Actual YTD Expenses",
	"Actual YTD Revenues",
	"Efficiency Ratio",
	"YTD Expenses Taregt",
	"YTD Revenues Target",
	"Efficiency Ratio Target",
	"AUA in Nominee",
	"AUA in Client Name",
	"# of RPAs implemented",
	"Hours Saved due to RPAs",
	"Continuous improvement/quick wins",
	"Total Assets ",
	"Organic Growth ",
	"Total Revenue ",
	"Total Revenue Target ",
	" Recruiting ",
	"Terminated Advisors"
) as
SELECT 
MD_START_DT	 AS "Start Date of the image/version" ,
MD_EXTRACT_DT	 AS "Extraction date of the occurrence" ,
KPI_DATE	 AS "KPI Date" ,
No_CLIENT_ID	 AS "# Client ID" ,
E_DELIVERY	 AS "E-delivery" ,
E_DELIVERY_PCT	 AS "% E-delivery" ,
E_DELIVERY_TARGET_PCT	 AS "% E-delivery Target" ,
PORTAL_REGISTRATION	 AS "Portal Registration" ,
PORTAL_REGISTRATION_PCT	 AS "% Portal Registration" ,
PORTAL_REGISTRATION_TARGET	 AS "Portal Registration Target" ,
FTE	 AS "FTE" ,
CLIENTS_BY_FTE	 AS "Clients by FTE" ,
CLIENTS_BY_FTE_TARGET	 AS "Clients by FTE Target" ,
NO_OF_ACCOUNTS	 AS "No of accounts" ,
ACCOUNTS_BY_FTE	 AS "Accounts by FTE" ,
ACTUAL_YTD_EXPENSES	 AS "Actual YTD Expenses" ,
ACTUAL_YTD_REVENUES	 AS "Actual YTD Revenues" ,
EFFICIENCY_RATIO	 AS "Efficiency Ratio" ,
YTD_EXPENSES_TARGET	 AS "YTD Expenses Taregt" ,
YTD_REVENUES_TARGET	 AS "YTD Revenues Target" ,
EFFICIENCY_RATIO_TARGET	 AS "Efficiency Ratio Target" ,
AUA_IN_NOMINEE	 AS "AUA in Nominee" ,
AUA_IN_CLIENT_NAME	 AS "AUA in Client Name" ,
No_OF_RPAS_IMPLEMENTED	 AS "# of RPAs implemented" ,
HOURS_SAVED_DUE_TO_RPAS	 AS "Hours Saved due to RPAs" ,
CONTINUOUS_IMPROVEMENT_QUICK_WINS	 AS "Continuous improvement/quick wins" ,
TOTAL_ASSETS	 AS "Total Assets " ,
ORGANIC_GROWTH	 AS "Organic Growth " ,
TOTAL_REVENUE	 AS "Total Revenue " ,
TOTAL_REVENUE_TARGET	 AS "Total Revenue Target " ,
RECRUITING	 AS " Recruiting " ,
TERMINATED_ADVISORS	 AS "Terminated Advisors" 
FROM DB_IAW_DEV_DM.EXTERNAL_KPI.MASTER_KPI_DATA_INVESTIA;
create or replace schema DB_IAW_DEV_DM.EXTRACTIONS;

create or replace TRANSIENT TABLE DB_IAW_DEV_DM.EXTRACTIONS.WT_COMMISSION_ORGANIC_GROWTH (
	TEAM_RANK NUMBER(18,0),
	TEAM_NAME VARCHAR(512),
	MONTHLY_NET_ORGANIC_GROWTH_BY_TEAM NUMBER(38,2),
	YTD_NET_ORGANIC_GROWTH_BY_TEAM NUMBER(38,2)
);
CREATE OR REPLACE FILE FORMAT DB_IAW_DEV_DM.EXTRACTIONS.COMMISSION_EXPORT_CSV
	FIELD_DELIMITER = ';'
	COMPRESSION = NONE
;
CREATE OR REPLACE FILE FORMAT DB_IAW_DEV_DM.EXTRACTIONS.EXPORT_SQL
	RECORD_DELIMITER = 'NONE'
	FIELD_DELIMITER = 'NONE'
	COMPRESSION = NONE
;
CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.EXTRACTIONS."USP_COMMISSION_ORGANIC_GROWTH"("p_START_DATE" VARCHAR(10))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var vSQLSelectCmd = `
INSERT INTO DB_IAW_DEV_DM.EXTRACTIONS.WT_COMMISSION_ORGANIC_GROWTH SELECT * FROM (
WITH LatestVersionAdvisors AS (
		SELECT distinct 
			team_name
		FROM DB_IAW_DEV_DM.SHARED.DIM_ADVISOR
		WHERE (
            HK_HUB <> ''0''
            AND new_advisor <> 1
            AND month(md_start_dt) = month(dateadd(months, - 1, to_date(''@START_DATE@'')))
			AND year (md_start_dt) = year(to_date(''@START_DATE@''))
            )
            OR  (md_end_dt is null and HK_HUB <> ''0'')
		)
	,ThisMonthReport AS (
		SELECT A.TEAM_NAME
			,coalesce(sum(DECODE(FT.CASH_FLOW_TYPE, ''IN FLOW'', FT.GROSS_AMOUNT)), 0) InflowGrossAmt
			,coalesce(sum(DECODE(FT.CASH_FLOW_TYPE, ''OUT FLOW'', FT.GROSS_AMOUNT)), 0) OutflowGrossAmt
			,InflowGrossAmt + OutflowGrossAmt AS NetOrganicGrowth
		FROM DB_IAW_DEV_DM.SHARED.DIM_ADVISOR A
		JOIN DB_IAW_DEV_DM.TRANSACTIONS.FACT_TRANSACTIONS FT ON FT.SK_DIM_ADVISORS = A.ID
		WHERE month(FT.TRADE_DATE) = month(dateadd(months, - 1, to_date(''@START_DATE@'')))
			AND year(FT.trade_date) = year(to_date(''@START_DATE@''))
			AND A.new_advisor <> 1
			AND ft.departed_advisor_ind <> 1
		GROUP BY A.TEAM_NAME
		)
	,LastMonthReport AS (
		SELECT
            A.TEAM_NAME
			,coalesce(sum(DECODE(FT.CASH_FLOW_TYPE, ''IN FLOW'', FT.GROSS_AMOUNT)), 0) InflowGrossAmt
			,coalesce(sum(DECODE(FT.CASH_FLOW_TYPE, ''OUT FLOW'', FT.GROSS_AMOUNT)), 0) OutflowGrossAmt
			,InflowGrossAmt + OutflowGrossAmt AS NetOrganicGrowth
		FROM DB_IAW_DEV_DM.SHARED.DIM_ADVISOR A
		JOIN DB_IAW_DEV_DM.TRANSACTIONS.FACT_TRANSACTIONS FT ON FT.SK_DIM_ADVISORS = A.ID
		WHERE month(FT.TRADE_DATE) = month(dateadd(months, - 2, to_date(''@START_DATE@'')))
			AND year(FT.trade_date) = year(dateadd(months, - 2, to_date(''@START_DATE@'')))
			AND A.new_advisor <> 1
			AND ft.departed_advisor_ind <> 1
		GROUP BY A.TEAM_NAME
		)
	,YTDReport AS (
		SELECT 
            A.TEAM_NAME
			,coalesce(sum(DECODE(FT.CASH_FLOW_TYPE, ''IN FLOW'', FT.GROSS_AMOUNT)), 0) YTD_Inflow_GrossAmt
			,coalesce(sum(DECODE(FT.CASH_FLOW_TYPE, ''OUT FLOW'', FT.GROSS_AMOUNT)), 0) YTD_Outflow_GrossAmt
			,YTD_Inflow_GrossAmt + YTD_Outflow_GrossAmt AS YTDNetOrganicGrowth
		FROM DB_IAW_DEV_DM.SHARED.DIM_ADVISOR A
		JOIN DB_IAW_DEV_DM.TRANSACTIONS.FACT_TRANSACTIONS FT ON FT.SK_DIM_ADVISORS = A.ID
		WHERE month(FT.TRADE_DATE) <= month(dateadd(months, - 1, to_date(''@START_DATE@'')))
			AND year(FT.trade_date) = year(to_date(''@START_DATE@''))
			AND A.new_advisor <> 1
			AND ft.departed_advisor_ind <> 1
		GROUP BY A.TEAM_NAME
		)
	,PrevYTDReport AS (
		SELECT 
            A.TEAM_NAME
			,coalesce(sum(DECODE(FT.CASH_FLOW_TYPE, ''IN FLOW'', FT.GROSS_AMOUNT)), 0) YTD_Inflow_GrossAmt
			,coalesce(sum(DECODE(FT.CASH_FLOW_TYPE, ''OUT FLOW'', FT.GROSS_AMOUNT)), 0) YTD_Outflow_GrossAmt
			,YTD_Inflow_GrossAmt + YTD_Outflow_GrossAmt AS YTDNetOrganicGrowth
		FROM DB_IAW_DEV_DM.SHARED.DIM_ADVISOR A
		JOIN DB_IAW_DEV_DM.TRANSACTIONS.FACT_TRANSACTIONS FT ON FT.SK_DIM_ADVISORS = A.ID
		WHERE month(FT.TRADE_DATE) <= month(dateadd(months, - 1, to_date(''@START_DATE@'')))
			AND year(FT.trade_date) = year(dateadd(years, - 1, to_date(''@START_DATE@'')))
			AND A.new_advisor <> 1
			AND ft.departed_advisor_ind <> 1
		GROUP BY A.TEAM_NAME 
		)

SELECT DISTINCT dense_rank() OVER (
		ORDER BY YTD_Net_Organic_Growth_By_Team DESC
		) AS Team_Rank
	,resultat.team_name
	,resultat.Monthly_Net_Organic_Growth_By_Team
	,resultat.YTD_Net_Organic_Growth_By_Team
FROM (
	SELECT
		LTV.TEAM_NAME
		,coalesce(TM.InflowGrossAmt, 0) AS MONTH_IN_FLOW
		,coalesce(TM.OutFlowGrossAmt, 0) AS MONTH_OUT_FLOW
		,coalesce(TM.NetOrganicGrowth, 0) AS Actual_Monthly_Net_Organic_Growth
		,coalesce(LM.NetOrganicGrowth, 0) AS Prev_Monthly_Net_Organic_Growth
		,Actual_Monthly_Net_Organic_Growth - Prev_Monthly_Net_Organic_Growth AS Month_over_Month_growth
		,coalesce(round(((Actual_Monthly_Net_Organic_Growth - Prev_Monthly_Net_Organic_Growth) / nullif(abs(Prev_Monthly_Net_Organic_Growth), 0) * 100), 2), 0) AS Month_over_Month_growth_Percentage
		,coalesce(YTD.YTD_Inflow_GrossAmt, 0) AS YTD_Inflow_GrossAmt
		,coalesce(YTD.YTD_Outflow_GrossAmt, 0) AS YTD_Outflow_GrossAmt
		,coalesce(YTD.YTDNetOrganicGrowth, 0) AS YTD_Net_Organic_Growth
		,coalesce(PYTD.YTDNetOrganicGrowth, 0) AS Previous_YTD_Net_Organic_Growth
		,YTD_Net_Organic_Growth - Previous_YTD_Net_Organic_Growth AS YTD_Period_over_period_growth
		,coalesce(round(((YTD_Net_Organic_Growth - Previous_YTD_Net_Organic_Growth) / nullif(abs(Previous_YTD_Net_Organic_Growth), 0) * 100), 2), 0) AS YTD_Period_over_period_growth_Percentage
		,round(sum(YTD_Net_Organic_Growth) OVER (PARTITION BY LTV.team_name), 2) AS YTD_Net_Organic_Growth_By_Team
		,round(sum(Actual_Monthly_Net_Organic_Growth) OVER (PARTITION BY LTV.team_name), 2) AS Monthly_Net_Organic_Growth_By_Team
	FROM LatestVersionAdvisors LTV
	LEFT JOIN THISMONTHREPORT TM    ON   LTV.TEAM_NAME = TM.TEAM_NAME  
	LEFT JOIN LASTMONTHREPORT LM    ON   LTV.TEAM_NAME = LM.TEAM_NAME  
	LEFT JOIN YTDReport YTD         ON   LTV.TEAM_NAME = YTD.TEAM_NAME  
	LEFT JOIN PREVYTDREPORT PYTD    ON   LTV.TEAM_NAME = PYTD.TEAM_NAME
	) AS resultat
WHERE resultat.YTD_Net_Organic_Growth_By_Team <> 0
	AND resultat.team_name NOT IN (
		''iA House''
		,''National Branch''
		,''''
		)
ORDER BY Team_Rank
) AS T;
`; 
vSQLSelectCmd = vSQLSelectCmd.replace(/@START_DATE@/g, p_START_DATE);
var selectStatement = snowflake.createStatement({sqlText: vSQLSelectCmd});
var vSQLResult = selectStatement.execute();
return "SUCCESS";
';
create or replace schema DB_IAW_DEV_DM.HOLDINGS;

create or replace TABLE DB_IAW_DEV_DM.HOLDINGS.FACT_HOLDINGS (
	ID NUMBER(38,0) autoincrement COMMENT 'ID of fact holdings',
	HK_LINK VARCHAR(40) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	SK_DIM_ACCOUNTS NUMBER(38,0),
	SK_DIM_MARKETPRODUCTS NUMBER(38,0),
	SK_DIM_ADVISORS NUMBER(38,0),
	SK_DIM_CLIENTS NUMBER(38,0),
	SK_DIM_PLANS NUMBER(38,0),
	RR_CD VARCHAR(50),
	PLN_SYSID VARCHAR(1000),
	BALANCE_DATE TIMESTAMP_NTZ(9),
	HOLDING_VALUE NUMBER(38,9),
	AUA NUMBER(38,12),
	AUM NUMBER(38,12),
	AUM_CLARINGTON NUMBER(38,12),
	AUM_IA NUMBER(38,12),
	CASH_POSITION NUMBER(38,12),
	PROGRAM_TYPE VARCHAR(50),
	ACCOUNT_PROGRAM_TYPE VARCHAR(50),
	ADMINISTRATORY_TYPE VARCHAR(1000)
);
create or replace TABLE DB_IAW_DEV_DM.HOLDINGS.WT_FACT_HOLDINGS (
	HK_LINK VARCHAR(40) COMMENT 'Hash key for the Link',
	HK_HUB_CONTRACT VARCHAR(40) COMMENT 'Hash key for CONTRACT',
	HK_HUB_INVESTMENT_PRODUCT_TYPE VARCHAR(40) COMMENT 'Hash key for the REF_MAPPING_PRODUCT_TYPE',
	HK_HUB_PARTY_ROLE_ADVISOR VARCHAR(40) COMMENT 'Hash key for the HUB_PARTY_ROLE_ADVISOR',
	HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER VARCHAR(40) COMMENT 'Hash key for HUB_PARTY_ROLE_ACCOUNT_HOLDER',
	HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES VARCHAR(40) COMMENT 'Hash key for the REF_INVESTMENT_SAVING_PROGRAM_TYPES',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	SK_DIM_ACCOUNTS NUMBER(38,0),
	SK_DIM_MARKETPRODUCTS NUMBER(38,0),
	SK_DIM_ADVISORS NUMBER(38,0),
	SK_DIM_CLIENTS NUMBER(38,0),
	SK_DIM_PLANS NUMBER(38,0),
	RR_CD VARCHAR(50),
	PLN_SYSID VARCHAR(1000),
	BALANCE_DATE TIMESTAMP_NTZ(9),
	HOLDING_VALUE NUMBER(38,9),
	AUA NUMBER(38,12),
	AUM NUMBER(38,12),
	AUM_CLARINGTON NUMBER(38,12),
	AUM_IA NUMBER(38,12),
	CASH_POSITION NUMBER(38,12),
	PROGRAM_TYPE VARCHAR(50),
	ACCOUNT_PROGRAM_TYPE VARCHAR(50),
	ADMINISTRATORY_TYPE VARCHAR(1000)
);
create or replace view DB_IAW_DEV_DM.HOLDINGS.VW_FACT_HOLDINGS(
	MD_START_DT,
	MD_SRCSYSTEM,
	SK_DIM_ACCOUNTS,
	SK_DIM_MARKETPRODUCTS,
	"Rep code",
	SK_DIM_ADVISORS,
	SK_DIM_CLIENTS,
	PLN_SYSID,
	SK_DIM_PLANS,
	"Balance date",
	"Market value",
	AUA,
	AUM,
	"AUM Clarington",
	"AUM iA",
	"Cash position",
	"Program type",
	"Account program type",
	"Administratory type"
) as 
	SELECT 
	MD_START_DT ,
	MD_SRC_SYSTEM ,
	SK_DIM_ACCOUNTS ,
	SK_DIM_MARKETPRODUCTS ,
	RR_CD ,
	SK_DIM_ADVISORS,
	SK_DIM_CLIENTS,
	PLN_SYSID ,
	SK_DIM_PLANS,
	BALANCE_DATE ,
	HOLDING_VALUE ,
	AUA ,
	AUM ,
	AUM_CLARINGTON ,
	AUM_IA ,
	CASH_POSITION ,
	PROGRAM_TYPE ,
	ACCOUNT_PROGRAM_TYPE ,
	ADMINISTRATORY_TYPE 
	FROM HOLDINGS.FACT_HOLDINGS
	WHERE DATE(BALANCE_DATE) >= (SELECT DATE(DATEADD(YEAR, -2,MAX(BALANCE_DATE) ))  FROM HOLDINGS.FACT_HOLDINGS)
order by SK_DIM_CLIENTS, SK_DIM_ADVISORS, SK_DIM_MARKETPRODUCTS,SK_DIM_ADVISORS;
create or replace view DB_IAW_DEV_DM.HOLDINGS.VW_INITIAL_LOADING_WT_FACT_HOLDINGS(
	HK_LINK,
	HK_HUB_CONTRACT,
	HK_HUB_INVESTMENT_PRODUCT_TYPE,
	HK_HUB_PARTY_ROLE_ADVISOR,
	HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
	HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES,
	MD_START_DT,
	MD_SOURCE,
	MD_SRC_SYSTEM,
	MD_EXTRACT_DT,
	SK_DIM_ACCOUNTS,
	SK_DIM_MARKETPRODUCTS,
	SK_DIM_ADVISORS,
	SK_DIM_CLIENTS,
	SK_DIM_PLANS,
	RR_CD,
	PLN_SYSID,
	BALANCE_DATE,
	HOLDING_VALUE,
	AUA,
	AUM,
	AUM_CLARINGTON,
	AUM_IA,
	CASH_POSITION,
	PROGRAM_TYPE,
	ACCOUNT_PROGRAM_TYPE,
	ADMINISTRATORY_TYPE
) as
SELECT
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.HK_LINK,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_CONTRACT,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_INVESTMENT_PRODUCT_TYPE,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_PARTY_ROLE_ADVISOR,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_SOURCE,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.MD_SRC_SYSTEM,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.MD_EXTRACT_DT,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_ACCOUNTS.ID IS NULL THEN -1
	ELSE SHARED.DIM_ACCOUNTS.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_ACCOUNTS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_FINANCIAL_INSTRUMENTS.ID IS NULL THEN -1
	ELSE SHARED.DIM_FINANCIAL_INSTRUMENTS.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_MARKETPRODUCTS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_ADVISOR.ID IS NULL THEN -1
	ELSE SHARED.DIM_ADVISOR.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_ADVISORS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_CLIENTS.ID IS NULL THEN -1
	ELSE SHARED.DIM_CLIENTS.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_CLIENTS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_PLANS.ID IS NULL THEN -1
	ELSE SHARED.DIM_PLANS.ID
END) AS VARCHAR(251)) AS FLOAT) AS SK_DIM_PLANS,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.RR_CD,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.PLN_SYSID,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.BALANCE_DATE,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.HOLDING_VALUE,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.AUA,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.AUM,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.AUM_CLARINGTON,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.AUM_IA,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.CASH_POSITION,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.PROGRAM_TYPE,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.ACCOUNT_PROGRAM_TYPE,
	DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.ADMINISTRATORY_TYPE
FROM
	(SHARED.DIM_ACCOUNTS
RIGHT OUTER JOIN (SHARED.DIM_CLIENTS
RIGHT OUTER JOIN (SHARED.DIM_PLANS
RIGHT OUTER JOIN (SHARED.DIM_ADVISOR
RIGHT OUTER JOIN (SHARED.DIM_FINANCIAL_INSTRUMENTS
RIGHT OUTER JOIN (HOLDINGS.FACT_HOLDINGS
RIGHT OUTER JOIN (DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT
INNER JOIN DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT ON
	(DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.HK_LINK = DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_LINK)) ON
	(DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_LINK = HOLDINGS.FACT_HOLDINGS.HK_LINK)) ON
	(DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_INVESTMENT_PRODUCT_TYPE = SHARED.DIM_FINANCIAL_INSTRUMENTS.HK_HUB)
	AND ((SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_START_DT <= DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
		AND ((SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_END_DT > DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
			OR SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_PARTY_ROLE_ADVISOR = SHARED.DIM_ADVISOR.HK_HUB)
	AND ((SHARED.DIM_ADVISOR.MD_START_DT <= DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
		AND ((SHARED.DIM_ADVISOR.MD_END_DT > DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
			OR SHARED.DIM_ADVISOR.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES = SHARED.DIM_PLANS.HK_HUB)
	AND ((SHARED.DIM_PLANS.MD_START_DT <= DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
		AND ((SHARED.DIM_PLANS.MD_END_DT > DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
			OR SHARED.DIM_PLANS.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER = SHARED.DIM_CLIENTS.HK_HUB)
	AND ((SHARED.DIM_CLIENTS.MD_START_DT <= DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
		AND ((SHARED.DIM_CLIENTS.MD_END_DT > DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
			OR SHARED.DIM_CLIENTS.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.HOLDINGS_BDV.LINK_INVESTMENT.HK_HUB_CONTRACT = SHARED.DIM_ACCOUNTS.HK_HUB)
	AND ((SHARED.DIM_ACCOUNTS.MD_START_DT <= DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
		AND ((SHARED.DIM_ACCOUNTS.MD_END_DT > DB_IAW_DEV_DWH.HOLDINGS_BDV.SAT_LINK_INVESTMENT.MD_START_DT)
			OR SHARED.DIM_ACCOUNTS.MD_END_DT IS NULL)));
create or replace schema DB_IAW_DEV_DM.HOLDINGS_BKP;

create or replace TABLE DB_IAW_DEV_DM.HOLDINGS_BKP.FACT_HOLDINGS_BKP (
	MD_SRCSYSTEM VARCHAR(50),
	SK_DIM_ACCOUNTS VARCHAR(16777216),
	SK_DIM_MARKETPRODUCTS VARCHAR(16777216),
	SK_DIM_REGISTERED_REPRESENTATIVES VARCHAR(16777216),
	"Rep code" VARCHAR(50),
	SK_DIM_ADVISORS VARCHAR(50),
	SK_DIM_CLIENTS VARCHAR(16777216),
	PLN_SYSID VARCHAR(16777216),
	SK_DIM_PLANS VARCHAR(8000),
	"Balance date" TIMESTAMP_NTZ(9),
	"Market value" NUMBER(38,9),
	AUA NUMBER(38,12),
	AUM NUMBER(38,12),
	"AUM Clarington" NUMBER(38,10),
	"AUM iA" NUMBER(38,9),
	"Cash position" NUMBER(38,12),
	"Program type" VARCHAR(23),
	"Account program type" VARCHAR(28),
	"Administratory type" VARCHAR(8000)
);
create or replace TABLE DB_IAW_DEV_DM.HOLDINGS_BKP.FUND2 (
	FUNDSERVID VARCHAR(1000) COMMENT 'Fund serv Id',
	FUNDID VARCHAR(1000) COMMENT 'Fund Id',
	FUNDDESCFR VARCHAR(1000) COMMENT 'Fund Desc FR',
	FUNDDESCEN VARCHAR(1000) COMMENT 'Fund Desc EN',
	FUNDTYPE VARCHAR(1000) COMMENT 'Fund Type',
	GROUPNAMEFR VARCHAR(1000) COMMENT 'Manager Name FR',
	GROUPNAMEEN VARCHAR(1000) COMMENT 'Manager Name EN',
	RRSPELIGIBLE VARCHAR(1000) COMMENT 'RRSP Eligible Indicator',
	FUNDDESCLONGFR VARCHAR(1000),
	FUNDDESCLONGEN VARCHAR(1000),
	LEGALNAMEEN VARCHAR(1000),
	LEGALNAMEFR VARCHAR(1000),
	STAMP VARCHAR(1000) COMMENT 'Last Modification Timestamp',
	MD_SRCSYSTEM VARCHAR(50),
	MD_LOADDATE TIMESTAMP_NTZ(9)
);
create or replace view DB_IAW_DEV_DM.HOLDINGS_BKP.VW_FACT_HOLDINGS(
	MD_SRCSYSTEM,
	SK_DIM_ACCOUNTS,
	SK_DIM_MARKETPRODUCTS,
	SK_DIM_REGISTERED_REPRESENTATIVES,
	"Rep code",
	SK_DIM_ADVISORS,
	SK_DIM_CLIENTS,
	PLN_SYSID,
	SK_DIM_PLANS,
	"Balance date",
	"Market value",
	AUA,
	AUM,
	"AUM Clarington",
	"AUM iA",
	"Cash position",
	"Program type",
	"Account program type",
	"Administratory type"
) as 
									
/********************************************************************************/
/**************************** INVESTIA UNIVERIS  ********************************/
/********************************************************************************/

SELECT
	H.MD_SRCSYSTEM,
	DECODE(H.ACT_SYSID,NULL,'-1',CONCAT('I_', H.ACT_SYSID)) AS SK_DIM_ACCOUNTS,
	DECODE(H.IVD_SYSID,NULL,'-1',CONCAT('I_', H.IVD_SYSID)) AS SK_DIM_MARKETPRODUCTS,
	DECODE(H.REP_SYSID,NULL,'-1',CONCAT('I_', H.REP_SYSID)) AS SK_DIM_REGISTERED_REPRESENTATIVES,
	NVL(AD.NK_REP_CD,'-1') AS "Rep code",
	DECODE(H.MASTER_CD,NULL,'-1',CONCAT('I_', H.MASTER_CD)) AS SK_DIM_ADVISORS,
	DECODE(H.IVR_SYSID,NULL,'-1',CONCAT('I_', H.IVR_SYSID)) AS SK_DIM_CLIENTS,
	DECODE( H.PLN_SYSID,NULL,'-1',CONCAT('I_', H.PLN_SYSID)) AS PLN_SYSID,
	NVL(PL.PLN_MNEM,'-1') AS SK_DIM_PLANS,
	BAL_DATE AS "Balance date",
	MV AS "Market value",
	AUA,
	CASE WHEN MP.MGT_NAME_ENG IN ('IA Clarington Investments Inc. (CCM)','IA Clarington GIF (IAC)','Industrial Alliance Insurance & Financial Services Inc. INA') 
		 THEN AUA
		 ELSE 0
	END AS AUM,
/* Business Rule HOLDINGS.006 */
	CASE WHEN MP.MGT_NAME_ENG IN ('IA Clarington Investments Inc. (CCM)','IA Clarington GIF (IAC)') 
		 THEN AUA
		 ELSE 0
	END AS "AUM Clarington",
/* Business Rule HOLDINGS.004 */
	CASE WHEN MP.MGT_NAME_ENG IN ('Industrial Alliance Insurance & Financial Services Inc. INA') 
		 THEN AUA
		 ELSE 0
	END AS "AUM iA",
/* Business Rule HOLDINGS.005 */
	CASE WHEN MP.SYMBOL = 'INVXCCA' /*'IAAFCCA' FOR FUNDEX*/
		 THEN AUA
		 ELSE 0
	END AS "Cash position",
/* Business Rule HOLDINGS.002 */
	CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
		 THEN 'Fee-based' /* WHEN IVD_LOAD_FLAG <> 'FCL' AND WF_IND = 0 */
		 ELSE 'Commission-based'
	END AS "Program type",
/* Business Rule HOLDINGS.008 */
	CASE WHEN COUNT(DISTINCT (CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
								   THEN 'Fee-based' 
								   ELSE 'Commission-based' 
							   END) ) OVER (PARTITION BY H.IVR_SYSID,H.PLN_SYSID ) = 2 
		  THEN 'Commission-based & Fee-based'
		  ELSE (CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
		  			 THEN 'Fee-based' 
		  			 ELSE 'Commission-based'
		  		END)
	END AS "Account program type",
	AC.ADMINISTRATOR_TYPE AS "Administratory type"
FROM
	"DB_IAW_DEV_STAGING".INVESTIA.HOLDINGS H
LEFT OUTER JOIN "DB_IAW_DEV_STAGING".INVESTIA.MARKETPRODUCTS MP ON
	H.IVD_SYSID = MP.IVD_SYSID   AND H.MD_LOADDATE = MP.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.REGISTERED_REPRESENTATIVE AD ON
	H.REP_SYSID = AD.REP_SYSID   AND H.MD_LOADDATE = AD.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.ACCOUNTS AC ON
	H.PLN_SYSID = AC.PLN_SYSID   AND H.MD_LOADDATE = AC.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.INVESTIA.PLANS PL ON
	AC.PLN_CD = PL.PLN_CD        AND AC.MD_LOADDATE = PL.MD_LOADDATE
WHERE
	AD.NK_REP_CD NOT IN ('610X','611X')
AND H.MV>0
--Get last image
AND H.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".INVESTIA.HOLDINGS )

/********************************************************************************/
/********************************************************************************/

								UNION ALL 

/********************************************************************************/
/**************************** FUNDEX UNIVERIS  ********************************/
/********************************************************************************/
SELECT
	H.MD_SRCSYSTEM,
	DECODE(H.ACT_SYSID,NULL,'-1',CONCAT('F_', H.ACT_SYSID)) AS SK_DIM_ACCOUNTS,
	DECODE(H.IVD_SYSID,NULL,'-1',CONCAT('F_', H.IVD_SYSID)) AS SK_DIM_MARKETPRODUCTS,
	DECODE(H.REP_SYSID,NULL,'-1',CONCAT('F_', H.REP_SYSID)) AS SK_DIM_REGISTERED_REPRESENTATIVES,
	NVL(AD.NK_REP_CD,'-1') AS "Rep code",
	DECODE(H.MASTER_CD,NULL,'-1',CONCAT('F_', H.MASTER_CD)) AS SK_DIM_ADVISORS,
	DECODE(H.IVR_SYSID,NULL,'-1',CONCAT('F_', H.IVR_SYSID)) AS SK_DIM_CLIENTS,
	DECODE( H.PLN_SYSID,NULL,'-1',CONCAT('F_', H.PLN_SYSID)) AS PLN_SYSID,
	NVL(PL.PLN_MNEM,'-1') AS SK_DIM_PLANS,
	BAL_DATE AS "BAL date",
	MV AS "Market value",
	AUA AS "AUA",
	CASE WHEN MP.MGT_NAME_ENG IN ('IA Clarington Investments Inc. (CCM)','IA Clarington GIF (IAC)','Industrial Alliance Insurance & Financial Services Inc. INA') 
		 THEN AUA
		 ELSE 0
	END AS AUM,
/* Business Rule HOLDINGS.006 */
	CASE WHEN MP.MGT_NAME_ENG IN ('IA Clarington Investments Inc. (CCM)','IA Clarington GIF (IAC)') 
		 THEN AUA
		 ELSE 0
	END AS "AUM Clarington",
/* Business Rule HOLDINGS.004 */
	CASE WHEN MP.MGT_NAME_ENG IN ('Industrial Alliance Insurance & Financial Services Inc. INA') 
		 THEN AUA
		 ELSE 0
	END AS "AUM iA",
/* Business Rule HOLDINGS.005 */
	CASE WHEN MP.SYMBOL = 'IAAFCCA' /*'INVXCCA' FOR INVESTIA*/
		 THEN AUA
		 ELSE 0
	END AS "Cash position",
/* Business Rule HOLDINGS.002 */
	CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
		 THEN 'Fee-based' /* WHEN IVD_LOAD_FLAG <> 'FCL' AND WF_IND = 0 */
		 ELSE 'Commission-based'
	END AS "Program type",
/* Business Rule HOLDINGS.008 */
	CASE WHEN COUNT(DISTINCT ( CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
									THEN 'Fee-based' 
									ELSE 'Commission-based' 
								END) ) OVER (PARTITION BY H.IVR_SYSID ,H.PLN_SYSID) = 2 
		 THEN 'Commission-based & Fee-based'
		 ELSE (CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
		 			THEN 'Fee-based'
					ELSE 'Commission-based'
				END)
	END AS "Account program type",
	AC.ADMINISTRATOR_TYPE AS "Administratory type"
FROM
	"DB_IAW_DEV_STAGING".FUNDEX.HOLDINGS H
LEFT OUTER JOIN "DB_IAW_DEV_STAGING".FUNDEX.MARKETPRODUCTS MP ON
	H.IVD_SYSID = MP.IVD_SYSID   AND H.MD_LOADDATE = MP.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.REGISTERED_REPRESENTATIVE AD ON
	H.REP_SYSID = AD.REP_SYSID   AND H.MD_LOADDATE = AD.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.ACCOUNTS AC ON
	H.PLN_SYSID = AC.PLN_SYSID AND H.IVR_SYSID = AC.IVR_SYSID    AND H.MD_LOADDATE = AC.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.FUNDEX.PLANS PL ON
	AC.PLN_CD = PL.PLN_CD     AND AC.MD_LOADDATE = PL.MD_LOADDATE
WHERE H.MV>0
--Get last image
AND H.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".FUNDEX.HOLDINGS )
/********************************************************************************/
/********************************************************************************/

									UNION ALL 

/********************************************************************************/
/********************************** IAS NBIB ************************************/
/********************************************************************************/

SELECT
	'IAS' AS MD_SRCSYSTEM,
	NVL(H.A_C_ID,'-1') AS SK_DIM_ACCOUNTS,
	NVL(H.TI_ALTERNATE_ID,'-1') AS SK_DIM_MARKETPRODUCTS,
	NULL AS SK_DIM_REGISTERED_REPRESENTATIVES,
	NVL(H.A_C_REPRESENTATIVE,'-1') AS "Rep code",
	NVL(S.MASTER_CODE,'-1') AS SK_DIM_ADVISORS,
	NVL(A.A_C_CLIENT,'-1') AS SK_DIM_CLIENTS,
	NVL(H.A_C_ID,'-1') AS PLN_SYSID,
	CASE WHEN A.ACCOUNT_RAP_CODE = 'Z' AND RP.ASC_1_RESP_Plan_Types IS NULL 
		 THEN CONCAT(IFNULL(A.ACCOUNT_RAP_CODE, ''), '_', IFNULL(A.RETAIL_PLAN, ''), '_', '0')
		 WHEN A.ACCOUNT_RAP_CODE = 'Z' AND RP.ASC_1_RESP_Plan_Types IS NOT NULL 
		 THEN CONCAT(IFNULL(A.ACCOUNT_RAP_CODE, ''), '_', IFNULL(A.RETAIL_PLAN, ''), '_', IFNULL(RP.ASC_1_RESP_Plan_Types, ''))
		 ELSE CONCAT(IFNULL(A.ACCOUNT_RAP_CODE, ''), '_', IFNULL(A.RETAIL_PLAN, ''))
	END AS SK_DIM_PLANS,
	H.TRAN_SUMM_BUSINESS_DATE AS "BAL date",
	H.TRAN_SUMM_CURR_MKT_VALUE AS "Market value",
	DECODE(H.TRAN_SUMM_CURRENCY,'USD',H.TRAN_SUMM_CURR_MKT_VALUE*E.EXCHANGERATE,H.TRAN_SUMM_CURR_MKT_VALUE) * COALESCE(S.COMMISSIONPCT,100) * 0.01 AS AUA,
	DECODE(H.TI_ALTERNATE_TI_TYPE,'380',DECODE(H.TRAN_SUMM_CURRENCY,'USD',H.TRAN_SUMM_CURR_MKT_VALUE*E.EXCHANGERATE,H.TRAN_SUMM_CURR_MKT_VALUE),0) * COALESCE(S.COMMISSIONPCT,100) * 0.01 AS AUM,
	DECODE(H.TI_ALTERNATE_TI_TYPE,'380',DECODE(H.TRAN_SUMM_CURRENCY,'USD',H.TRAN_SUMM_CURR_MKT_VALUE*E.EXCHANGERATE,H.TRAN_SUMM_CURR_MKT_VALUE),0) AS "AUM Clarington",
	0 AS "AUM iA",
	DECODE(H.TRAN_SUMM_CURRENCY,'USD',H.TRAN_SUMM_NET_SETT_AMT*E.EXCHANGERATE,H.TRAN_SUMM_NET_SETT_AMT) * COALESCE(S.COMMISSIONPCT,100) * 0.01 AS "Cash Position",
 	CASE ASC_3_MANAGED_TYPE WHEN '1' 
 							THEN 'SMAs'
							WHEN 'C' 
							THEN 'Managed Account Program'
							WHEN 'D' 
							THEN 'Managed Account Program'
							WHEN 'F' 
							THEN 'Fee-based'
							WHEN 'G' 
							THEN 'Managed Account Program'
							WHEN 'J' 
							THEN 'SMAs'
							WHEN 'L' 
							THEN 'SMAs'
							WHEN 'M' 
							THEN 'Managed Account Program'
							WHEN 'N' 
							THEN 'SMAs'
							WHEN 'Q' 
							THEN 'Managed Account Program'
							WHEN 'R' 
							THEN 'Fee-based'
							WHEN 'S' 
							THEN 'Fee-based'
							WHEN 'V' 
							THEN 'SMAs'
							WHEN 'X' 
							THEN 'SMAs'
							ELSE 'Commission-based'
	END AS "Program type",
	CASE ASC_3_MANAGED_TYPE WHEN '1' 
							THEN 'SMAs'
							WHEN 'C' 
							THEN 'Managed Account Program'
							WHEN 'D' 
							THEN 'Managed Account Program'
							WHEN 'F' 
							THEN 'Fee-based'
							WHEN 'G' 
							THEN 'Managed Account Program'
							WHEN 'J' 
							THEN 'SMAs'
							WHEN 'L' 
							THEN 'SMAs'
							WHEN 'M' 
							THEN 'Managed Account Program'
							WHEN 'N' 
							THEN 'SMAs'
							WHEN 'Q' 
							THEN 'Managed Account Program'
							WHEN 'R' 
							THEN 'Fee-based'
							WHEN 'S' 
							THEN 'Fee-based'
							WHEN 'V' 
							THEN 'SMAs'
							WHEN 'X' 
							THEN 'SMAs'
							ELSE 'Commission-based'
	END AS "Account program type",
	A.ADMINISTRATOR_TYPE AS "Administratory type"
FROM
	DB_IAW_DEV_STAGING.IAS.HOLDINGS H
LEFT JOIN BR.VW_IAS_RRCODE_MASTERCODE S ON
	S.A_C_REPRESENTATIVE = H.A_C_REPRESENTATIVE
LEFT JOIN DB_IAW_DEV_STAGING.IAS.EXCHANGERATE E ON
	EXCHANGEDATE = TRAN_SUMM_BUSINESS_DATE AND H.MD_LOADDATE = E.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.IAS."ACCOUNTS" A ON
	H.A_C_ID = A.A_C_ID AND H.MD_LOADDATE = A.MD_LOADDATE
LEFT JOIN BR.IAS_RAPCODE_PLAN RP ON
	(A.ACCOUNT_RAP_CODE = RP.ACCOUNT_RAP_CODE AND A.ACCOUNT_RAP_CODE <> 'P' AND A.ACCOUNT_RAP_CODE <> 'Z')
	 OR ( A.ACCOUNT_RAP_CODE = 'Z' AND RP.ACCOUNT_RAP_CODE = 'Z' AND A.RETAIL_PLAN = RP.RETAIL_PLAN AND A.ASC_1_RESP_PLAN_TYPES IS NOT NULL AND A.ASC_1_RESP_PLAN_TYPES = RP.ASC_1_RESP_PLAN_TYPES )
	 OR ( A.ACCOUNT_RAP_CODE = 'Z' AND RP.ACCOUNT_RAP_CODE = 'Z' AND A.RETAIL_PLAN = RP.RETAIL_PLAN AND A.ASC_1_RESP_PLAN_TYPES IS NULL AND 0 = RP.ASC_1_RESP_PLAN_TYPES )
	 OR (A.ACCOUNT_RAP_CODE = 'P' AND RP.ACCOUNT_RAP_CODE = 'P' AND A.RETAIL_PLAN = RP.RETAIL_PLAN)
WHERE (H.A_C_ID NOT RLIKE '^[A-Z][A-Z]'
OR H.A_C_ID IS NULL)
AND (AUA <> 0 OR "Cash Position" <> 0)
AND (SK_DIM_ADVISORS <> 'SEST')
-- To desactivate : correction must be done in source systems
AND (S.MASTER_CODE IS NOT NULL)
--Get last image
AND H.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS.HOLDINGS )
/********************************************************************************/
/********************************************************************************/

									UNION ALL 


/********************************************************************************/
/********************************** IAS UNIVERIS ************************************/
/********************************************************************************/

SELECT
	H.MD_SRCSYSTEM,
	DECODE(H.ACT_SYSID,NULL,'-1',CONCAT('IU_', H.ACT_SYSID)) AS SK_DIM_ACCOUNTS,
	DECODE(H.IVD_SYSID,NULL,'-1',CONCAT('IU_', H.IVD_SYSID)) AS SK_DIM_MARKETPRODUCTS,
	DECODE(H.REP_SYSID,NULL,'-1',CONCAT('IU_', H.REP_SYSID)) AS SK_DIM_REGISTERED_REPRESENTATIVES,
	NVL(AD.NK_REP_CD,'-1') AS "Rep code",
	COALESCE(S.MASTER_CODE,'-1') AS SK_DIM_ADVISORS,
	DECODE(H.IVR_SYSID,NULL,'-1',CONCAT('IU_', H.IVR_SYSID)) AS SK_DIM_CLIENTS,
	DECODE(H.PLN_SYSID,NULL,'-1',CONCAT('IU_', H.PLN_SYSID)) AS PLN_SYSID,
	NVL(PL.PLN_MNEM,'-1') AS SK_DIM_PLANS,
	BAL_DATE AS "BAL date",
	MV * COALESCE(S.COMMISSIONPCT,100) * 0.01 AS "Market value",
	AUA * COALESCE(S.COMMISSIONPCT,100) * 0.01 AS "AUA",
	CASE WHEN MP.MGT_NAME_ENG IN ('IA Clarington Investments Inc. (CCM)','IA Clarington GIF (IAC)','Industrial Alliance Insurance & Financial Services Inc. INA') 
		 THEN AUA * COALESCE(S.COMMISSIONPCT,100) * 0.01
		 ELSE 0
	END AS AUM,
	CASE WHEN MP.MGT_NAME_ENG IN ('IA Clarington Investments Inc. (CCM)','IA Clarington GIF (IAC)') 
		 THEN AUA * COALESCE(S.COMMISSIONPCT,100) * 0.01
		 ELSE 0
	END AS "AUM Clarington",
	CASE WHEN MP.MGT_NAME_ENG IN ('Industrial Alliance Insurance & Financial Services Inc. INA') 
		 THEN AUA * COALESCE(S.COMMISSIONPCT,100) * 0.01
		 ELSE 0
	END AS "AUM iA",
	0 AS "Cash position",
	CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
		 THEN 'Fee-based'
		 ELSE 'Commission-based'
	END AS "Program type",
	CASE WHEN COUNT(DISTINCT (CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
								   THEN 'Fee-based' 
								   ELSE 'Commission-based' 
							   END) ) OVER (PARTITION BY H.IVR_SYSID) = 2 
		 THEN 'Commission-based & Fee-based'
		 ELSE (CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 
		 			THEN 'Fee-based'
		 			ELSE 'Commission-based'
		 		END)
	END AS "Account program type",
	AC.ADMINISTRATOR_TYPE AS "Administratory type"
FROM
	"DB_IAW_DEV_STAGING".IAS_UNIVERIS.HOLDINGS H
LEFT OUTER JOIN "DB_IAW_DEV_STAGING".IAS_UNIVERIS.MARKETPRODUCTS MP ON
	H.IVD_SYSID = MP.IVD_SYSID  AND H.MD_LOADDATE = MP.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.REGISTERED_REPRESENTATIVE AD ON
	H.REP_SYSID = AD.REP_SYSID  AND H.MD_LOADDATE = AD.MD_LOADDATE
LEFT JOIN BR.VW_IAS_RRCODE_MASTERCODE S ON
	S.A_C_REPRESENTATIVE = AD.NK_REP_CD AND S.COMMISSIONPCT > 0
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS."ACCOUNTS" AC ON
	H.PLN_SYSID = AC.PLN_SYSID AND H.IVR_SYSID = AC.IVR_SYSID AND H.MD_LOADDATE = AC.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.PLANS PL ON
	AC.PLN_CD = PL.PLN_CD  AND AC.MD_LOADDATE = PL.MD_LOADDATE
WHERE H.MV>0
--Get last image
AND H.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".IAS_UNIVERIS.HOLDINGS );
create or replace view DB_IAW_DEV_DM.HOLDINGS_BKP.VW_FACT_HOLDINGS_ACCESS(
	MD_SRCSYSTEM,
	SK_DIM_ACCOUNTS,
	SK_DIM_MARKETPRODUCTS,
	SK_DIM_REGISTERED_REPRESENTATIVES,
	"Rep code",
	SK_DIM_ADVISORS,
	SK_DIM_CLIENTS,
	PLN_SYSID,
	SK_DIM_PLANS,
	"Balance date",
	"Market value",
	AUA,
	AUM,
	"AUM Clarington",
	"AUM iA",
	"Cash position",
	"Program type",
	"Account program type",
	"Administratory type"
) as 

SELECT H.MD_SRCSYSTEM, SK_DIM_ACCOUNTS, SK_DIM_MARKETPRODUCTS, SK_DIM_REGISTERED_REPRESENTATIVES, "Rep code", SK_DIM_ADVISORS, SK_DIM_CLIENTS, PLN_SYSID, SK_DIM_PLANS, "Balance date", "Market value", AUA, AUM, "AUM Clarington", "AUM iA", "Cash position", "Program type", "Account program type", "Administratory type"
FROM DB_IAW_DEV_DATAMART.HOLDINGS.FACT_HOLDINGS H
INNER JOIN DB_IAW_DEV_DATAMART.BR.DIM_USER U
ON U."User Login"= CURRENT_USER()  AND  (H.MD_SRCSYSTEM=U."Capacity" OR U."Capacity" ='ALL');
create or replace schema DB_IAW_DEV_DM.PUBLIC;

create or replace TABLE DB_IAW_DEV_DM.PUBLIC.D (
	COLUMN1 NUMBER(38,0)
);
create or replace schema DB_IAW_DEV_DM.RECONCILIATION;

create or replace TABLE DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_EXCEPTIONS (
	NAME VARCHAR(1000) COMMENT 'Name of the Query that causes an exception',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Data Start Date for exception',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row inserted date',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Taskflow Audit Id',
	RETURNED_VALUE VARCHAR(1000) COMMENT 'Description if needed for clarity of exception',
	primary key (NAME, MD_START_DT)
);
create or replace TABLE DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_RESULTS (
	NAME VARCHAR(1000),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID VARCHAR(1000),
	RESULT VARCHAR(2),
	DESCRIPTION VARCHAR(1000),
	DETAILS VARCHAR(200000)
);
create or replace TABLE DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_RULE_ENGINE (
	NAME VARCHAR(1000) COMMENT '[VERIFICATION LAYER]_[DATA ENTITY]_[VALIDATION]',
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_END_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_MODIFY_DT TIMESTAMP_NTZ(9),
	DESCRIPTION VARCHAR(5000) COMMENT 'validation',
	QUERY VARCHAR(200000) COMMENT 'INSERT SELECT INTO DB_IAW_DEV_DM.VALIDATIONS.RECON_RESULTS TABLE'
);
create or replace TABLE DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_RULE_ENGINE_BKP (
	NAME VARCHAR(1000),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_END_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_MODIFY_DT TIMESTAMP_NTZ(9),
	DESCRIPTION VARCHAR(5000),
	QUERY VARCHAR(200000)
);
CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.RECONCILIATION."USP_DLY_BATCH_RECONCILE_CHECK2"("pNAME" VARCHAR(1000), "pDATA_START_DT" VARCHAR(20), "pAUDIT_ID" VARCHAR(1000), "pUSE_PATTERN" VARCHAR(10))
RETURNS VARCHAR(5000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var vExceptionId;
var vExceptionMsg;
var vSQLExcpCmd;

//Stage 1: Check the Arguments Signature are Valid for the process to continue.
if ( pNAME.length <= 0 || pDATA_START_DT.length <= 0 || pAUDIT_ID.length <= 0 )
{
vExceptionId = "EXCEPTION:-1";
vExceptionMsg = " Signature Argument Missing";
return vExceptionId + "-" + vExceptionMsg;
}

//Stage 2: Compose the string based on Use Pattern
var vSQLCmd;
if ( pUSE_PATTERN==null )
{
vSQLCmd = " SELECT NAME, DESCRIPTION, QUERY, substring(CURRENT_DATABASE(),(regexp_instr(CURRENT_DATABASE(),''_'',2,2) + 1), 3) FROM DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_RULE_ENGINE WHERE NAME = ''" + pNAME + "'' AND MD_END_DT IS NULL ";
}
else
{
vSQLCmd = " SELECT NAME, DESCRIPTION, QUERY, substring(CURRENT_DATABASE(),(regexp_instr(CURRENT_DATABASE(),''_'',2,2) + 1), 3) FROM DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_RULE_ENGINE WHERE NAME LIKE ''%" + pUSE_PATTERN + "%'' AND MD_END_DT IS NULL ";
}
pUSE_PATTERN="N/A";
	

//Stage 3: Get the Rule query from the table object.
var vSQLStmt = snowflake.createStatement( { sqlText: vSQLCmd } );
var vSQLResult = vSQLStmt.execute();
var vName;
var vDbName;

while (vSQLResult.next())
{
try {
vName = vSQLResult.getColumnValue(1);
var desc = vSQLResult.getColumnValue(2);
var query = vSQLResult.getColumnValue(3); 	
vDbName = vSQLResult.getColumnValue(4);

//Stage 3: Search and replace place holder for Audit and Data Start Date.
query = query.replace(/@NAME@/g, vName);
query = query.replace(/@DATA_START_DT@/g, pDATA_START_DT);
query = query.replace(/@AUDIT_ID@/g,pAUDIT_ID); 
// Line Feed and CR elimination
query = query.replace(/\\r/g," ");
query = query.replace(/\\n/g," ");

//Stage 4: Query fetched will be used to be executed for the final results.
var vSQLCmd2 = query;
var vSQLStmt2 = snowflake.createStatement( { sqlText: vSQLCmd2 } );
var vSQLResult2 = vSQLStmt2.execute();
}
catch(err)
{
vSQLExcpCmd = "INSERT INTO DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_EXCEPTIONS (NAME, MD_START_DT, MD_CREATION_DT, MD_CREATION_AUDIT_ID, DESCRIPTION) VALUES( ''" + vName + "'',''" + pDATA_START_DT  + "'', CURRENT_TIMESTAMP ,''"  + pAUDIT_ID + "'','' Exception raised '')" ;
var vSQLStmtExcp = snowflake.createStatement( { sqlText: vSQLExcpCmd } );
var vSQLResultExcp = vSQLStmtExcp.execute();
return err;
//return vSQLExcpCmd;
// return row //	
vExceptionId = "EXCEPTION:-99";
vExceptionMsg = " Fetch While Loop Not Successful" + "  Query Statement: " + vName;
return vExceptionId + "-" + vExceptionMsg;
}
}

vExceptionId = "EXCEPTION:0";
vExceptionMsg = " " + pNAME + " " + pDATA_START_DT + " With Pattern if Any  "  + pUSE_PATTERN +  " Successful";
return vExceptionId + "-" + vExceptionMsg;
';
CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.RECONCILIATION."USP_RECONCILE_CHECK"("pNAME" VARCHAR(1000), "pDATA_START_DT" VARCHAR(20), "pAUDIT_ID" VARCHAR(1000), "pUSE_PATTERN" VARCHAR(10))
RETURNS VARCHAR(5000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var vExceptionId;
var vExceptionMsg;
var vSQLExcpCmd;

//Stage 1: Check the Arguments Signature are Valid for the process to continue.
if ( pNAME.length <= 0 || pDATA_START_DT.length <= 0 || pAUDIT_ID.length <= 0 )
{
vExceptionId = "EXCEPTION:-1";
vExceptionMsg = " Signature Argument Missing";
return vExceptionId + "-" + vExceptionMsg;
}

//Stage 2: Compose the string based on Use Pattern
var vSQLCmd;
if ( pUSE_PATTERN==null )
{
vSQLCmd = " SELECT NAME, DESCRIPTION, QUERY FROM DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_RULE_ENGINE WHERE NAME = ''" + pNAME + "'' AND MD_END_DT IS NULL ";
}
else
{
vSQLCmd = " SELECT NAME, DESCRIPTION, QUERY FROM DB_IAW_DEV_DM.RECONCILIATION.RECONCILE_RULE_ENGINE WHERE NAME LIKE ''%" + pUSE_PATTERN + "%'' AND MD_END_DT IS NULL ";
}
pUSE_PATTERN="N/A";

//Stage 3: Get the Rule query from the table object.
var vSQLStmt = snowflake.createStatement( { sqlText: vSQLCmd } );
var vSQLResult = vSQLStmt.execute();
var vName;

while (vSQLResult.next())
{
//try {
vName = vSQLResult.getColumnValue(1);
var desc = vSQLResult.getColumnValue(2);
var query = vSQLResult.getColumnValue(3); 	

//Stage 3: Search and replace place holder for Audit and Data Start Date.
query = query.replace(/@NAME@/g, vName);
query = query.replace(/@DATA_START_DT@/g, pDATA_START_DT);
query = query.replace(/@AUDIT_ID@/g,pAUDIT_ID); 
// Line Feed and CR elimination 
// If comments needs in query for rule engine use /* */ Do not use the -- comment style.
query = query.replace(/\\r/g," ");
query = query.replace(/\\n/g," ");

//Stage 4: Query fetched will be used to be executed for the final results.
var vSQLCmd2 = query;
var vSQLStmt2 = snowflake.createStatement( { sqlText: vSQLCmd2 } );
var vSQLResult2 = vSQLStmt2.execute();
//}
//catch(err)
//{
//vExceptionId = "-99";
//vExceptionMsg = " Fetch While Loop Not Successful" + "  Query Statement: " + vName + err;
//return err;
//}
}

vExceptionId = "EXCEPTION:0";
vExceptionMsg = " " + pNAME + " " + pDATA_START_DT + " With Pattern if Any  "  + pUSE_PATTERN +  " Successful";
return vExceptionId + "-" + vExceptionMsg;
';
create or replace schema DB_IAW_DEV_DM.REVENUES;

create or replace TABLE DB_IAW_DEV_DM.REVENUES.FACT_REVENUE (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the dimension',
	HK_LINK VARCHAR(40) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	SK_DIM_CLIENTS NUMBER(38,0),
	SK_DIM_ADVISORS NUMBER(38,0),
	SK_DIM_PLANS NUMBER(38,0),
	SK_DIM_MARKETPRODUCTS NUMBER(38,0),
	SK_DIM_ACCOUNTS NUMBER(38,0),
	PAYMENT_DATE TIMESTAMP_NTZ(9) COMMENT 'Process Date',
	REVENUE_AMOUNT NUMBER(38,12) COMMENT 'REVENUE AMOUNT',
	REVENUE_TYPE VARCHAR(512) COMMENT 'REVENUE TYPE',
	REVENUE_SUBTYPE VARCHAR(512) COMMENT 'REVENUE SUBTYPE',
	AUA NUMBER(38,12) COMMENT 'AUA'
);
create or replace TABLE DB_IAW_DEV_DM.REVENUES.WT_FACT_REVENUE (
	HK_LINK VARCHAR(40) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER VARCHAR(40) COMMENT 'Hash key HUB_PARTY_ROLE_ACCOUNT_HOLDER',
	HK_HUB_PARTY_ROLE_ADVISOR VARCHAR(40) COMMENT 'Hash key for HUB_REGISTERED_REPRESENTATIVE_COMMISSION',
	HK_HUB_REF_INVESTMENT_SAVING_PROGRAM_TYPES VARCHAR(40) COMMENT 'Hash key for REF_INVESTMENT_SAVING_PROGRAM_TYPES',
	HK_HUB_INVESTMENT_PRODUCT_TYPE VARCHAR(40) COMMENT 'Hash key for REF_MAPPING_PRODUCT_TYPE',
	HK_HUB_CONTRACT VARCHAR(40) COMMENT 'Hash key for HUB_CONTRACT',
	SK_DIM_CLIENTS NUMBER(38,0),
	SK_DIM_ADVISORS NUMBER(38,0),
	SK_DIM_PLANS NUMBER(38,0),
	SK_DIM_MARKETPRODUCTS NUMBER(38,0),
	SK_DIM_ACCOUNTS NUMBER(38,0),
	PAYMENT_DATE TIMESTAMP_NTZ(9) COMMENT 'Process Date',
	REVENUE_AMOUNT NUMBER(38,12) COMMENT 'REVENUE AMOUNT',
	REVENUE_TYPE VARCHAR(512) COMMENT 'REVENUE TYPE',
	REVENUE_SUBTYPE VARCHAR(512) COMMENT 'REVENUE SUBTYPE',
	AUA NUMBER(38,12) COMMENT 'AUA'
);
create or replace view DB_IAW_DEV_DM.REVENUES.VW_FACT_REVENUES(
	MD_SRCSYSTEM,
	SK_DIM_ACCOUNTS,
	SK_DIM_MARKETPRODUCTS,
	SK_ADVISORS,
	SK_DIM_CLIENTS,
	SK_DIM_PLANS,
	"Payment date",
	"Revenue type",
	"Revenue amount",
	REVENUE_SUBTYPE,
	AUA
) as 
SELECT  
	MD_SRC_SYSTEM ,
	SK_DIM_ACCOUNTS ,
	SK_DIM_MARKETPRODUCTS ,
	SK_DIM_ADVISORS ,
	SK_DIM_CLIENTS ,
	SK_DIM_PLANS ,
	PAYMENT_DATE ,
	REVENUE_TYPE ,
	REVENUE_AMOUNT ,
	REVENUE_SUBTYPE ,
	AUA 
FROM REVENUES.FACT_REVENUE
WHERE DATE(PAYMENT_DATE) >= (SELECT DATE(DATEADD(YEAR, -2,MAX(PAYMENT_DATE) ))  FROM REVENUES.FACT_REVENUE) 
order by SK_DIM_MARKETPRODUCTS,SK_DIM_ADVISORS,SK_DIM_CLIENTS,SK_DIM_PLANS,REVENUE_TYPE;
create or replace view DB_IAW_DEV_DM.REVENUES.VW_INITIAL_LOADING_WT_FACT_REVENUES(
	MD_START_DT,
	MD_SRC_SYSTEM,
	MD_EXTRACT_DT,
	MD_SOURCE,
	HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
	HK_HUB_PARTY_ROLE_ADVISOR,
	HK_HUB_REF_INVESTMENT_SAVING_PROGRAM_TYPES,
	HK_HUB_INVESTMENT_PRODUCT_TYPE,
	HK_HUB_CONTRACT,
	SK_DIM_CLIENTS,
	SK_DIM_ADVISORS,
	SK_DIM_PLANS,
	SK_DIM_MARKETPRODUCTS,
	SK_DIM_ACCOUNTS,
	PAYMENT_DATE,
	REVENUE,
	REVENUE_TYPE,
	REVENUE_SUBTYPE
) as
SELECT 
	MAX(MD_START_DT) AS MD_START_DT,
	MAX(MD_SRC_SYSTEM) AS MD_SRC_SYSTEM,
	MAX(MD_EXTRACT_DT) AS MD_EXTRACT_DT,
	MAX(MD_SOURCE) AS MD_SOURCE,
	HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
	HK_HUB_PARTY_ROLE_ADVISOR,
	HK_HUB_REF_INVESTMENT_SAVING_PROGRAM_TYPES,
	HK_HUB_INVESTMENT_PRODUCT_TYPE,
	HK_HUB_CONTRACT,
	SK_DIM_CLIENTS,
	SK_DIM_ADVISORS,
	SK_DIM_PLANS,
	SK_DIM_MARKETPRODUCTS,
	SK_DIM_ACCOUNTS,
	PAYMENT_DATE,
	SUM(REVENUE) AS REVENUE,
	REVENUE_TYPE,
	REVENUE_SUBTYPE
FROM (
SELECT
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_SRC_SYSTEM,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_EXTRACT_DT,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_SOURCE,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_PARTY_ROLE_ADVISOR,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_REF_INVESTMENT_SAVING_PROGRAM_TYPES,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_INVESTMENT_PRODUCT_TYPE,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_CONTRACT,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_CLIENTS.ID IS NULL THEN -1
	ELSE SHARED.DIM_CLIENTS.ID
END) AS VARCHAR(252)) AS FLOAT) SK_DIM_CLIENTS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_ADVISOR.ID IS NULL THEN -1
	ELSE SHARED.DIM_ADVISOR.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_ADVISORS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_PLANS.ID IS NULL THEN -1
	ELSE SHARED.DIM_PLANS.ID
END) AS VARCHAR(251)) AS FLOAT) AS SK_DIM_PLANS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_FINANCIAL_INSTRUMENTS.ID IS NULL THEN -1
	ELSE SHARED.DIM_FINANCIAL_INSTRUMENTS.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_MARKETPRODUCTS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_ACCOUNTS.ID IS NULL THEN -1
	ELSE SHARED.DIM_ACCOUNTS.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_ACCOUNTS,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.PAYMENT_DATE,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.REVENUE,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.REVENUE_TYPE,
	DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.REVENUE_SUBTYPE
FROM
	(SHARED.DIM_ACCOUNTS
RIGHT OUTER JOIN (SHARED.DIM_CLIENTS
RIGHT OUTER JOIN (SHARED.DIM_PLANS
RIGHT OUTER JOIN (SHARED.DIM_ADVISOR
RIGHT OUTER JOIN (SHARED.DIM_FINANCIAL_INSTRUMENTS
RIGHT OUTER JOIN DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE ON
	(DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_INVESTMENT_PRODUCT_TYPE = SHARED.DIM_FINANCIAL_INSTRUMENTS.HK_HUB)
	AND ((SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_START_DT <= DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
		AND ((SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_END_DT > DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
			OR SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_PARTY_ROLE_ADVISOR = SHARED.DIM_ADVISOR.HK_HUB)
	AND ((SHARED.DIM_ADVISOR.MD_START_DT <= DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
		AND ((SHARED.DIM_ADVISOR.MD_END_DT > DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
			OR SHARED.DIM_ADVISOR.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_REF_INVESTMENT_SAVING_PROGRAM_TYPES = SHARED.DIM_PLANS.HK_HUB)
	AND ((SHARED.DIM_PLANS.MD_START_DT <= DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
		AND ((SHARED.DIM_PLANS.MD_END_DT > DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
			OR SHARED.DIM_PLANS.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER = SHARED.DIM_CLIENTS.HK_HUB)
	AND ((SHARED.DIM_CLIENTS.MD_START_DT <= DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
		AND ((SHARED.DIM_CLIENTS.MD_END_DT > DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
			OR SHARED.DIM_CLIENTS.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.HK_HUB_CONTRACT = SHARED.DIM_ACCOUNTS.HK_HUB)
	AND ((SHARED.DIM_ACCOUNTS.MD_START_DT <= DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
		AND ((SHARED.DIM_ACCOUNTS.MD_END_DT > DB_IAW_DEV_DWH.REVENUES_BDV.LINK_REVENUE.MD_START_DT)
			OR SHARED.DIM_ACCOUNTS.MD_END_DT IS NULL)))
)			
GROUP BY
	HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
	HK_HUB_PARTY_ROLE_ADVISOR,
	HK_HUB_REF_INVESTMENT_SAVING_PROGRAM_TYPES,
	HK_HUB_INVESTMENT_PRODUCT_TYPE,
	HK_HUB_CONTRACT,
	PAYMENT_DATE,
	REVENUE_TYPE,
	REVENUE_SUBTYPE,
	SK_DIM_MARKETPRODUCTS,
	SK_DIM_ADVISORS,
	SK_DIM_PLANS,
	SK_DIM_CLIENTS,
	SK_DIM_ACCOUNTS;
create or replace schema DB_IAW_DEV_DM.REVENUES_BKP;

create or replace TABLE DB_IAW_DEV_DM.REVENUES_BKP.FACT_REVENUES (
	MD_SRCSYSTEM VARCHAR(50),
	SK_DIM_ACCOUNTS VARCHAR(16777216),
	SK_DIM_MARKETPRODUCTS VARCHAR(16777216),
	SK_ADVISORS VARCHAR(50),
	SK_DIM_REGISTERED_REPRESENTATIVES VARCHAR(16777216),
	SK_DIM_CLIENTS VARCHAR(16777216),
	SK_DIM_PLANS VARCHAR(8000),
	"Payment date" TIMESTAMP_NTZ(9),
	"Revenue type" VARCHAR(17),
	"Revenue amount" FLOAT,
	REVENUE_SUBTYPE VARCHAR(40)
);
create or replace view DB_IAW_DEV_DM.REVENUES_BKP.VW_FACT_REVENUES(
	MD_SRCSYSTEM,
	SK_DIM_ACCOUNTS,
	SK_DIM_MARKETPRODUCTS,
	SK_ADVISORS,
	SK_DIM_REGISTERED_REPRESENTATIVES,
	SK_DIM_CLIENTS,
	SK_DIM_PLANS,
	"Payment date",
	"Revenue type",
	"Revenue amount",
	REVENUE_SUBTYPE
) as
/********************************************************************************/
/****************** FUNDEX Sales commissions ************************************/
/********************************************************************************/
SELECT
	R.MD_SRCSYSTEM, --AS "FACT revenues source system",
	DECODE(R.ACT_SYSID,NULL,'-1',CONCAT('F_', R.ACT_SYSID)) AS SK_DIM_ACCOUNTS,
	DECODE(R.IVD_SYSID,NULL,'-1',CONCAT('F_', R.IVD_SYSID)) AS SK_DIM_MARKETPRODUCTS,
	DECODE(NVL(X.MASTER_CD,X.REP_CD_ORIGINAL),NULL,'-1',CONCAT('F_', NVL(X.MASTER_CD, X.REP_CD_ORIGINAL))) AS SK_ADVISORS,
	DECODE(R.REP_SYSID,NULL,'-1',CONCAT('F_', R.REP_SYSID)) AS SK_DIM_REGISTERED_REPRESENTATIVES,
	DECODE(R.IVR_SYSID,NULL,'-1',CONCAT('F_', R.IVR_SYSID)) AS SK_DIM_CLIENTS,
	NVL(PL.PLN_MNEM,'-1') AS SK_DIM_PLANS,
	R.PAID_DT AS "Payment date",
	CASE WHEN R.COM_PROD_CD IN ('02','10') THEN 'Trailers'
		 WHEN R.COM_PROD_CD = '37' 		   THEN 'Fee based/Managed'
								   		   ELSE 'Trade commissions'
	END AS "Revenue type",
	R.COM_BEN_PYBL*NVL(X.COMM_RATE,1) AS "Revenue amount",
	CASE WHEN SCP.COM_PROD_MNEM IN ('MFTRX','BONUS','COMM') THEN 'Trade commissions'
		 WHEN SCP.COM_PROD_MNEM IN ('ADJUS','OTHER') THEN 'Others'
		 WHEN SCP.COM_PROD_MNEM IN ('REF','SREF') THEN 'Referals'
		 WHEN SCP.COM_PROD_MNEM IN ('TOF','TF') THEN 'Charge back client fees'
 		 WHEN SCP.COM_PROD_MNEM IN ('GICC') THEN 'GIC commissions'
		 ELSE SCP.COM_PROD_LONG_DESC
	END AS REVENUE_SUBTYPE
FROM
	DB_IAW_DEV_STAGING.FUNDEX.REVENUE_PAYABLE R
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.X_DBB_MASTER_REP X ON
	R.REP_SYSID = X.REP_SYSID AND R.MD_LOADDATE = X.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.ACCOUNTS AC ON
	R.PLN_SYSID = AC.PLN_SYSID AND R.MD_LOADDATE = AC.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.FUNDEX.PLANS PL ON
	AC.PLN_CD = PL.PLN_CD AND AC.MD_LOADDATE = PL.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.FUNDEX.S_COM_PROD SCP ON
	R.COM_PROD_CD =SCP.COM_PROD_CD 
WHERE 
	R.COM_PROD_CD NOT IN ('02','37','20','21','22','23','24','25','26') AND R.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.FUNDEX.REVENUE_PAYABLE )
	
	/* Exclude Taxe remittances */
	
/********************************************************************************/
/********************************************************************************/
/********************************************************************************/

									UNION ALL
									
/********************************************************************************/
/*********************** FUNDEX Trailer fees ************************************/
/********************************************************************************/									
									

SELECT
	p.MD_SRCSYSTEM,
	DECODE(p.PLN_SRF_SYSID,NULL,'-1',CONCAT('F_', p.PLN_SRF_SYSID)),
	DECODE(cs.IVD_SYSID,NULL,'-1',CONCAT('F_', cs.IVD_SYSID)),
	DECODE(NVL(X.MASTER_CD,X.REP_CD_ORIGINAL),NULL,'-1',CONCAT('F_', NVL(X.MASTER_CD, X.REP_CD_ORIGINAL))),
	DECODE(p.REP_SYSID,NULL,'-1',CONCAT('F_', p.REP_SYSID)),
	DECODE(a.IVR_SYSID,NULL,'-1',CONCAT('F_', a.IVR_SYSID)),
	NVL(PL.PLN_MNEM,'-1'),
	p.TO_DT,
	'Trailers',
	p.COM_PYBL*NVL(p.EXCH_RATE,1)* NVL(X.COMM_RATE,1),
	'Mutual Fund Servicing Commissions' AS REVENUE_SUBTYPE
FROM
	DB_IAW_DEV_STAGING.FUNDEX.PLN_SRF p
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.COM_SRF cs ON
	p.PLN_SRF_SYSID = cs.PLN_SRF_SYSID AND p.MD_LOADDATE = cs.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX."ACCOUNTS" a ON
	p.PLN_SYSID = a.PLN_SYSID AND p.MD_LOADDATE = a.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.FUNDEX.PLANS PL ON
	a.PLN_CD = PL.PLN_CD AND a.MD_LOADDATE = PL.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.X_DBB_MASTER_REP X ON
	p.REP_SYSID = X.REP_SYSID AND p.MD_LOADDATE = X.MD_LOADDATE
	
WHERE p.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.FUNDEX.COM_SRF )
	
/********************************************************************************/
/********************************************************************************/
/********************************************************************************/	
	
									UNION ALL
									
/********************************************************************************/
/************************** FUNDEX Wrap fees ************************************/
/********************************************************************************/									

SELECT
	wf.MD_SRCSYSTEM,
	DECODE(wf.ACT_SYSID,NULL,'-1',CONCAT('F_', wf.ACT_SYSID)),
	'-1',
	DECODE(NVL(X.MASTER_CD,X.REP_CD_ORIGINAL),NULL,'-1',CONCAT('F_', NVL(X.MASTER_CD, X.REP_CD_ORIGINAL))),
	DECODE(wf.REP_SYSID,NULL,'-1',CONCAT('F_', wf.REP_SYSID)),
	DECODE(wf.IVR_SYSID,NULL,'-1',CONCAT('F_', wf.IVR_SYSID)),
	NVL(PL.PLN_MNEM,'-1'),
	LAST_DAY(TO_DATE(TO_CHAR(TRUNC(wf.FISCAL_SYSID / 100))|| '-' || DECODE(MOD(wf.FISCAL_SYSID,100)<10,TRUE,'0' || TO_CHAR(MOD(wf.FISCAL_SYSID,100)),TO_CHAR(MOD(wf.FISCAL_SYSID,100)))|| '-01','YYYY-MM-DD')),
	'Fee based/Managed',
	wf.FEE_AMT*NVL(X.COMM_RATE,1),
	'Fee for Service' AS REVENUE_SUBTYPE
FROM
	DB_IAW_DEV_STAGING.FUNDEX.WRAP_FEE wf
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX."ACCOUNTS" a ON
	wf.PLN_SYSID = a.PLN_SYSID AND wf.MD_LOADDATE = a.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.FUNDEX.PLANS PL ON
	a.PLN_CD = PL.PLN_CD AND a.MD_LOADDATE = PL.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.X_DBB_MASTER_REP X ON
	wf.REP_SYSID = X.REP_SYSID AND wf.MD_LOADDATE = X.MD_LOADDATE
WHERE
	wf.STATUS_CD = 'F'
AND TRUNC(wf.FISCAL_SYSID / 100) IN (2019,2020) 

AND wf.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.FUNDEX.WRAP_FEE )

/********************************************************************************/
/********************************************************************************/
/********************************************************************************/

									UNION ALL
									
/********************************************************************************/
/*********************** INVESTIA Sales commissions *****************************/
/********************************************************************************/												
									
SELECT
	R.MD_SRCSYSTEM,
	DECODE(R.ACT_SYSID,NULL,'-1',CONCAT('I_', R.ACT_SYSID)),
	DECODE(R.IVD_SYSID,NULL,'-1',CONCAT('I_', R.IVD_SYSID)),
	DECODE(NVL(X.MASTER_CD,X.REP_CD_ORIGINAL),NULL,'-1',CONCAT('I_', NVL(X.MASTER_CD, X.REP_CD_ORIGINAL))),
	DECODE(R.REP_SYSID,NULL,'-1',CONCAT('I_', R.REP_SYSID)),
	DECODE(R.IVR_SYSID,NULL,'-1',CONCAT('I_', R.IVR_SYSID)),
	NVL(PL.PLN_MNEM,'-1') ,
	R.PAID_DT,
	CASE WHEN R.COM_PROD_CD IN ('02','10') THEN 'Trailers'
		 WHEN R.COM_PROD_CD = '35' 		   THEN 'Fee based/Managed'
								   		   ELSE 'Trade commissions'
	END AS "Revenue type",
	R.COM_BEN_PYBL*NVL(X.COMM_RATE,1) AS "Revenue amount",
	CASE WHEN SCP.COM_PROD_MNEM IN ('MFTRX','BONUS','COMM') THEN 'Trade commissions'
		 WHEN SCP.COM_PROD_MNEM IN ('ADJUS','OTHER') THEN 'Others'
		 WHEN SCP.COM_PROD_MNEM IN ('REF','SREF') THEN 'Referals'
		 WHEN SCP.COM_PROD_MNEM IN ('TOF','TF') THEN 'Charge back client fees'
 		 WHEN SCP.COM_PROD_MNEM IN ('GICC') THEN 'GIC commissions'
		 ELSE SCP.COM_PROD_LONG_DESC
	END AS REVENUE_SUBTYPE
FROM
	DB_IAW_DEV_STAGING.INVESTIA.REVENUE_PAYABLE R
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.X_DBB_MASTER_REP X ON
	R.REP_SYSID = X.REP_SYSID AND R.MD_LOADDATE = X.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.ACCOUNTS AC ON
	R.PLN_SYSID = AC.PLN_SYSID AND R.MD_LOADDATE = AC.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.INVESTIA.PLANS PL ON
	AC.PLN_CD = PL.PLN_CD AND AC.MD_LOADDATE = PL.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.INVESTIA.S_COM_PROD SCP ON
	R.COM_PROD_CD =SCP.COM_PROD_CD 
WHERE
	R.COM_PROD_CD NOT IN ('02','35','20','21','22','23','24','25','26') AND R.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.INVESTIA.REVENUE_PAYABLE )
	
	
/********************************************************************************/
/********************************************************************************/
/********************************************************************************/	
	
									UNION ALL
									
/********************************************************************************/
/************************* INVESTIA Trailer fees ********************************/
/********************************************************************************/										

SELECT
	p.MD_SRCSYSTEM,
	DECODE(p.PLN_SRF_SYSID,NULL,'-1',CONCAT('I_', p.PLN_SRF_SYSID)) ,
	DECODE(cs.IVD_SYSID,NULL,'-1',CONCAT('I_', cs.IVD_SYSID)) ,
	DECODE(NVL(X.MASTER_CD,X.REP_CD_ORIGINAL),NULL,'-1',CONCAT('I_', NVL(X.MASTER_CD, X.REP_CD_ORIGINAL))),
	DECODE(p.REP_SYSID,NULL,'-1',CONCAT('I_', p.REP_SYSID)),
	DECODE(a.IVR_SYSID,NULL,'-1',CONCAT('I_', a.IVR_SYSID)) ,
	NVL(PL.PLN_MNEM,'-1') ,
	p.TO_DT,
	'Trailers',
	p.COM_PYBL*NVL(p.EXCH_RATE,1)* NVL(X.COMM_RATE,1),
	'Mutual Fund Servicing Commissions' AS REVENUE_SUBTYPE
FROM
	DB_IAW_DEV_STAGING.INVESTIA.PLN_SRF p
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.COM_SRF cs ON
	p.PLN_SRF_SYSID = cs.PLN_SRF_SYSID AND p.MD_LOADDATE = cs.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA."ACCOUNTS" a ON
	p.PLN_SYSID = a.PLN_SYSID AND p.MD_LOADDATE = a.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.INVESTIA.PLANS PL ON
	a.PLN_CD = PL.PLN_CD AND a.MD_LOADDATE = PL.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.X_DBB_MASTER_REP X ON
	p.REP_SYSID = X.REP_SYSID AND p.MD_LOADDATE = X.MD_LOADDATE
	
WHERE p.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.INVESTIA.PLN_SRF )
/********************************************************************************/
/********************************************************************************/
/********************************************************************************/
	
									UNION ALL
									
/********************************************************************************/
/************************** INVESTIA Wrap fees **********************************/
/********************************************************************************/										

SELECT
	wf.MD_SRCSYSTEM ,
	DECODE(wf.ACT_SYSID,NULL,'-1',CONCAT('I_', wf.ACT_SYSID)),
	'-1',
	DECODE(NVL(X.MASTER_CD,X.REP_CD_ORIGINAL),NULL,'-1',CONCAT('I_', NVL(X.MASTER_CD, X.REP_CD_ORIGINAL))),
	DECODE(wf.REP_SYSID,NULL,'-1',CONCAT('I_', wf.REP_SYSID)),
	DECODE(wf.IVR_SYSID,NULL,'-1',CONCAT('I_', wf.IVR_SYSID)),
	NVL(PL.PLN_MNEM,'-1'),
	LAST_DAY(TO_DATE(TO_CHAR(TRUNC(wf.FISCAL_SYSID / 100))|| '-' || DECODE(MOD(wf.FISCAL_SYSID,100)<10,TRUE,'0' || TO_CHAR(MOD(wf.FISCAL_SYSID,100)),TO_CHAR(MOD(wf.FISCAL_SYSID,100)))|| '-01','YYYY-MM-DD')),
	'Fee based/Managed',
	wf.FEE_AMT*NVL(X.COMM_RATE,1),
	'Fee for Service' AS REVENUE_SUBTYPE
FROM
	DB_IAW_DEV_STAGING.INVESTIA.WRAP_FEE wf
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA."ACCOUNTS" a ON
	wf.PLN_SYSID = a.PLN_SYSID AND wf.MD_LOADDATE = a.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.INVESTIA.PLANS PL ON
	a.PLN_CD = PL.PLN_CD AND a.MD_LOADDATE = PL.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.X_DBB_MASTER_REP X ON
	wf.REP_SYSID = X.REP_SYSID AND wf.MD_LOADDATE = X.MD_LOADDATE
WHERE
	wf.STATUS_CD = 'F'
	AND TRUNC(wf.FISCAL_SYSID / 100) IN (2019,2020)
	
	AND wf.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.INVESTIA.WRAP_FEE )
	
/********************************************************************************/
/********************************************************************************/
/********************************************************************************/
	
									UNION ALL
									
									
/********************************************************************************/
/********************************* IAS Rvenues **********************************/
/********************************************************************************/
									
SELECT
	'IAS',
	COALESCE(R.ACCOUNTID,'-1'),
	'-1',
	COALESCE(R.REPID,'-1'),
	COALESCE(R.REPID,'-1'),
	COALESCE(A.A_C_CLIENT,'-1'),
	'-1' ,
	R.PROCESSDATE ,
	CASE R.SOURCECODE WHEN 'OFF' THEN 'Trade commissions'
                WHEN 'FXF' THEN 'Fee based/Managed'
                WHEN 'MGD' THEN 'Fee based/Managed'
                WHEN 'JRN' THEN 'Trailers'
                WHEN 'MNL' THEN 'Trade commissions'
                /*WHEN 'EXP' THEN 'Expenses' */
                WHEN 'INS' THEN 'Insurances'
                WHEN 'TRD' THEN 'Trade commissions'
                /*WHEN 'TXR' THEN 'Tax remittances'*/
                ELSE 'Unkown' 
	END,
	R.COMMISSION,
	
	CASE R.SOURCECODE WHEN 'OFF' THEN 'OffBook commission'
                WHEN 'FXF' THEN 'Fixed fees'
                WHEN 'MGD' THEN 'Managed'
                WHEN 'JRN' THEN 'Trailer fees and GIC'
                WHEN 'MNL' THEN 'Others'
               /* WHEN 'EXP' THEN 'Expenses'*/
                WHEN 'INS' THEN 'Insurances'
                WHEN 'TRD' THEN 'Trade commissions'
               /* WHEN 'TXR' THEN 'Tax remittances'*/
                ELSE 'Unkown' END AS REVENUE_SUBTYPE
	
FROM
	DB_IAW_DEV_STAGING.IAS_COMMISSION.REVENUES R
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS.EXCHANGERATE E ON
	E.EXCHANGEDATE = R.PROCESSDATE AND E.MD_LOADDATE = R.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS."ACCOUNTS" A ON
	R.ACCOUNTID = A.A_C_ID AND R.MD_LOADDATE = A.MD_LOADDATE
WHERE
	R.SOURCECODE NOT IN ('EXP','TXR')
	AND
	(A.A_C_ID NOT RLIKE '^[A-Z][A-Z]'
	OR A.A_C_ID IS NULL) AND R.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS_COMMISSION.REVENUES )
	
	
/********************************************************************************/
/********************************************************************************/
/********************************************************************************/
	
									UNION ALL
									
/********************************************************************************/
/************************* IAS UNIVERIS Sales commissions ***********************/
/********************************************************************************/									
									
SELECT
	R.MD_SRCSYSTEM,
	DECODE(R.ACT_SYSID,NULL,'-1',CONCAT('IU_', R.ACT_SYSID)) ,
	DECODE(R.IVD_SYSID,NULL,'-1',CONCAT('IU_', R.IVD_SYSID)),
	COALESCE(S.MASTER_CODE,'-1'),
	COALESCE(TO_CHAR(R.REP_SYSID),'-1'),
	DECODE(R.IVR_SYSID,NULL,'-1',CONCAT('IU_', R.IVR_SYSID)),
	COALESCE(PL.PLN_MNEM,'-1') ,
	R.PAID_DT,
	CASE WHEN R.COM_PROD_CD IN ('02','10') THEN 'Trailers'
		 WHEN R.COM_PROD_CD = '37' THEN 'Fee based/Managed'
								   ELSE 'Trade commissions'
	END,
	R.COM_BEN_PYBL * NVL(S.COMMISSIONPCT,100) * 0.01,
	
	CASE WHEN SCP.COM_PROD_MNEM IN ('MFTRX','BONUS','COMM') THEN 'Trade commissions'
		 WHEN SCP.COM_PROD_MNEM IN ('ADJUS','OTHER') THEN 'Others'
		 WHEN SCP.COM_PROD_MNEM IN ('REF','SREF') THEN 'Referals'
		 WHEN SCP.COM_PROD_MNEM IN ('TOF','TF') THEN 'Charge back client fees'
 		 WHEN SCP.COM_PROD_MNEM IN ('GICC') THEN 'GIC commissions'
		 ELSE SCP.COM_PROD_LONG_DESC
	END AS REVENUE_SUBTYPE

FROM
	DB_IAW_DEV_STAGING.IAS_UNIVERIS.REVENUE_PAYABLE R
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.REGISTERED_REPRESENTATIVE AD ON
	R.REP_SYSID = AD.REP_SYSID AND R.MD_LOADDATE = AD.MD_LOADDATE
LEFT JOIN BR.VW_IAS_RRCODE_MASTERCODE S ON
	S.A_C_REPRESENTATIVE = AD.NK_REP_CD
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.ACCOUNTS AC ON
	R.PLN_SYSID = AC.PLN_SYSID AND R.MD_LOADDATE = AC.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.PLANS PL ON
	AC.PLN_CD = PL.PLN_CD AND AC.MD_LOADDATE = PL.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.S_COM_PROD SCP ON
	R.COM_PROD_CD =SCP.COM_PROD_CD 
WHERE
	R.COM_PROD_CD NOT IN ('02','20','21','22','23','24','25','26') AND R.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS_UNIVERIS.REVENUE_PAYABLE )
	
/********************************************************************************/
/********************************************************************************/
/********************************************************************************/	
	
									UNION ALL
									
/********************************************************************************/
/************************* IAS UNIVERIS Trailer fees ****************************/
/********************************************************************************/
									
SELECT
	p.MD_SRCSYSTEM ,
	DECODE(p.PLN_SRF_SYSID,NULL,'-1',CONCAT('IU_', p.PLN_SRF_SYSID)),
	DECODE(cs.IVD_SYSID,NULL,'-1',CONCAT('IU_', cs.IVD_SYSID)),
	COALESCE(S.MASTER_CODE,'-1'),
	COALESCE(TO_CHAR(p.REP_SYSID),'-1'),
	DECODE(a.IVR_SYSID,NULL,'-1',CONCAT('IU_', a.IVR_SYSID)),
	COALESCE(PL.PLN_MNEM,'-1'),
	p.TO_DT,
	'Trailers',
	p.COM_PYBL*NVL(p.EXCH_RATE,1)* NVL(S.COMMISSIONPCT,100) * 0.01,	
	'Mutual Fund Servicing Commissions' AS REVENUE_SUBTYPE
FROM
	DB_IAW_DEV_STAGING.IAS_UNIVERIS.PLN_SRF p
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.COM_SRF cs ON
	p.PLN_SRF_SYSID = cs.PLN_SRF_SYSID AND p.MD_LOADDATE = cs.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS."ACCOUNTS" a ON
	p.PLN_SYSID = a.PLN_SYSID AND p.MD_LOADDATE = a.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.PLANS PL ON
	a.PLN_CD = PL.PLN_CD AND a.MD_LOADDATE = PL.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.REGISTERED_REPRESENTATIVE AD ON
	p.REP_SYSID = AD.REP_SYSID AND p.MD_LOADDATE = AD.MD_LOADDATE
LEFT JOIN BR.VW_IAS_RRCODE_MASTERCODE S ON
	S.A_C_REPRESENTATIVE = AD.NK_REP_CD

WHERE p.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS_UNIVERIS.PLN_SRF );
create or replace view DB_IAW_DEV_DM.REVENUES_BKP.VW_FACT_REVENUES_ACCESS(
	MD_SRCSYSTEM,
	SK_DIM_ACCOUNTS,
	SK_DIM_MARKETPRODUCTS,
	SK_ADVISORS,
	SK_DIM_REGISTERED_REPRESENTATIVES,
	SK_DIM_CLIENTS,
	SK_DIM_PLANS,
	"Payment date",
	"Revenue type",
	"Revenue amount"
) as 
SELECT R.MD_SRCSYSTEM, SK_DIM_ACCOUNTS, SK_DIM_MARKETPRODUCTS, SK_ADVISORS, SK_DIM_REGISTERED_REPRESENTATIVES, SK_DIM_CLIENTS, SK_DIM_PLANS, "Payment date", "Revenue type", "Revenue amount"
FROM DB_IAW_DEV_DATAMART.REVENUES.FACT_REVENUES R
INNER JOIN DB_IAW_DEV_DATAMART.BR.DIM_USER U
ON U."User Login"= CURRENT_USER()  AND  (R.MD_SRCSYSTEM=U."Capacity" OR U."Capacity" ='ALL');
create or replace schema DB_IAW_DEV_DM.SHARED;

create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_ACCOUNTS (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) DEFAULT '0' COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CONTRACT_ID VARCHAR(1000) COMMENT 'Capabilities for RLS',
	UNIVERIS_PLAN_ID NUMBER(38,0) COMMENT 'Univeris Plan ID',
	UNIVERIS_CLIENT_ID NUMBER(38,0) COMMENT 'Univeris Client ID',
	PLAN_CODE VARCHAR(8000) COMMENT 'The plan mnemonic code',
	PLAN_LABEL VARCHAR(8000) COMMENT 'The plan mnemonic label',
	ACCOUNT_TYPE VARCHAR(14) COMMENT 'The type of the account Registered or not registered',
	OPEN_DATE TIMESTAMP_NTZ(9) COMMENT 'The setup date UNIVERIS and open date NBIN of the account',
	CLOSE_DATE TIMESTAMP_NTZ(9) COMMENT 'The close date of the account',
	GROUP_TYPE_CODE VARCHAR(8000) COMMENT 'The group type code such as RRSP,LEV,RRSP,LIRA...',
	ACCUMULATION_TYPE VARCHAR(1000) COMMENT 'Accumulation type',
	ADMINISTRATOR_TYPE VARCHAR(8000) COMMENT 'Client Name, Broker/Nominee or Third party',
	ACCOUNT_AUA_SEGMENT VARCHAR(512) COMMENT 'Advisor AUA Segment : 25k-100k',
	ACCOUNT_AUA_SEGMENT_ORDER NUMBER(38,0) COMMENT 'Advisor AUA Segment ORDER',
	ACCOUNT_IND NUMBER(1,0) COMMENT 'Total Number of Client Accounts Flag'
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_ACCOUNTS_BKP (
	ID NUMBER(38,0),
	HK_HUB VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_END_DT TIMESTAMP_NTZ(9),
	MD_HASH_NAT_KEYS VARCHAR(64),
	MD_HASHDIFF_TYPE1 VARCHAR(40),
	MD_HASHDIFF_TYPE2 VARCHAR(40),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID VARCHAR(1000),
	MD_MODIFY_DT TIMESTAMP_NTZ(9),
	MD_MODIFY_AUDIT_ID VARCHAR(1000),
	MD_SOURCE VARCHAR(1000),
	MD_SRC_SYSTEM VARCHAR(100),
	MD_EXTRACT_DT TIMESTAMP_NTZ(9),
	MD_SECURITY_TYPE VARCHAR(1000),
	CONTRACT_ID VARCHAR(1000),
	PLAN_MNEMONIC_CD VARCHAR(8000),
	PLAN_MNEMONIC_LBL VARCHAR(8000),
	ACCOUNT_TYPE VARCHAR(14),
	SETUP_DATE TIMESTAMP_NTZ(9),
	CLOSE_DATE TIMESTAMP_NTZ(9),
	GROUP_TYPE_CD VARCHAR(8000),
	ADMINISTRATOR_TYPE VARCHAR(8000)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_ACCOUNTS_SV (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) DEFAULT '0' COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CONTRACT_ID VARCHAR(1000) COMMENT 'Capabilities for RLS',
	UNIVERIS_PLAN_ID NUMBER(38,0) COMMENT 'Univeris Plan ID',
	UNIVERIS_CLIENT_ID NUMBER(38,0) COMMENT 'Univeris Client ID',
	PLAN_CODE VARCHAR(8000) COMMENT 'The plan mnemonic code',
	PLAN_LABEL VARCHAR(8000) COMMENT 'The plan mnemonic label',
	ACCOUNT_TYPE VARCHAR(14) COMMENT 'The type of the account Registered or not registered',
	OPEN_DATE TIMESTAMP_NTZ(9) COMMENT 'The setup date UNIVERIS and open date NBIN of the account',
	CLOSE_DATE TIMESTAMP_NTZ(9) COMMENT 'The close date of the account',
	GROUP_TYPE_CODE VARCHAR(8000) COMMENT 'The group type code such as RRSP,LEV,RRSP,LIRA...',
	ACCUMULATION_TYPE VARCHAR(1000) COMMENT 'Accumulation type',
	ADMINISTRATOR_TYPE VARCHAR(8000) COMMENT 'Client Name, Broker/Nominee or Third party'
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_ADVISOR (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) DEFAULT '0' COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	SRC_ID VARCHAR(50) COMMENT 'Not used TBD ?',
	MASTER_CODE VARCHAR(50) COMMENT 'Master code of the advisor',
	COMPANY_CODE VARCHAR(50) COMMENT 'Company code of the advisor',
	COMPANY_NAME VARCHAR(512) COMMENT 'Company name of the advisor',
	REGULATORY_ORGANIZATION_NAME VARCHAR(512) COMMENT 'REGULATORY ORGANIZATION NAME of the advisor',
	REGULATORY_ORGANIZATION_CODE VARCHAR(50) COMMENT 'REGULATORY ORGANIZATION CODE of the advisor',
	DEALER_CODE VARCHAR(50) COMMENT 'Dealer code',
	DEALER_NAME VARCHAR(512) COMMENT 'Dealer name',
	REGION_CODE VARCHAR(512) COMMENT 'Region code',
	REGION_NAME VARCHAR(512) COMMENT 'Region name',
	REGION_VP VARCHAR(16777216) COMMENT 'full name of the RVP',
	BRANCHCODE VARCHAR(50) COMMENT 'Code of the representative branch code',
	BRANCHNAME VARCHAR(512) COMMENT 'Name of the representative branch',
	TEAM_CODE NUMBER(38,0) COMMENT 'Representant Group ID',
	TEAM_NAME VARCHAR(512) COMMENT 'Advisor team description',
	ADVISOR_FULLNAME VARCHAR(512) COMMENT 'Representative name',
	FIRSTNAME VARCHAR(512) COMMENT 'Representative first name',
	LASTNAME VARCHAR(512) COMMENT 'Representative last name',
	ADVISOR_CORPORATION_NAME VARCHAR(512) COMMENT 'Representative corporation name',
	STATUS VARCHAR(512) COMMENT 'Active RR code indicator',
	GROUP_RSP_INDICATOR VARCHAR(512) COMMENT 'Group Retirement Savings Plan (RSP) indicator',
	PROVINCE_CODE VARCHAR(16777216) COMMENT 'province code',
	PROVINCE VARCHAR(16777216) COMMENT 'province name',
	ADVISOR_AUA_SEGMENT VARCHAR(512) COMMENT 'Advisor AUA Segment : 25k-100k',
	ADVISOR_AUA_SEGMENT_ORDER NUMBER(38,0) COMMENT 'Advisor AUA Segment ORDER',
	ADVISOR_START_DATE TIMESTAMP_NTZ(9) COMMENT 'the starting date of the advisor',
	NEW_ADVISOR NUMBER(38,0) COMMENT 'New advisor indicator (0 or 1)',
	ADVISOR_EFFECIVENESS_DT TIMESTAMP_NTZ(9) COMMENT 'Its the date after one year of advisor joining date , implemented as part of Organic growth',
	DEPARTED_ADVISOR_IND NUMBER(1,0) COMMENT 'DEPARTED ADVISOR INDICATOR',
	PRIMARY_ROLE VARCHAR(500),
	END_DATE TIMESTAMP_NTZ(9) COMMENT 'Departure date of the advisor (TBD)',
	REASON VARCHAR(1000) COMMENT 'Reason of departure',
	NEW_FIRM VARCHAR(1000) COMMENT 'Departure destination',
	NEW_FIRM_TYPE VARCHAR(1000) COMMENT 'Departure destination Type',
	NEW_FIRM_BACK_OFFICE VARCHAR(1000) COMMENT 'Departure destination Back-Office',
	PRESTIGE_STATUS VARCHAR(100) COMMENT 'Prestige Status',
	TRANSITION_PERIOD_END_DATE TIMESTAMP_NTZ(9) COMMENT 'Advisor transition end date',
	DEAL_ASSESTS NUMBER(11,0) COMMENT 'Deal assets',
	EXPECTED_ASSESTS NUMBER(11,0) COMMENT 'Expected assets',
	PREVIOUS_FIRM VARCHAR(100) COMMENT 'Previous Firm of the Advisor',
	PREVIOUS_FIRM_TYPE VARCHAR(100) COMMENT 'Previous Firm type of the Advisor',
	AGE_SEGMENT VARCHAR(50) COMMENT 'Advisor Age Segment : 25-34',
	AGE_SEGMENT_ORD NUMBER(2,0) COMMENT 'Advisor Age Segment ORDER',
	SUSPENDED_IND NUMBER(1,0) COMMENT 'suspended Flag, if an advisor is deleted in certs but still have AUA, will be considered as suspended'
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_ADVISOR_RACHID_JIHED (
	ID NUMBER(38,0),
	HK_HUB VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_END_DT TIMESTAMP_NTZ(9),
	MD_HASH_NAT_KEYS VARCHAR(64),
	MD_HASHDIFF_TYPE1 VARCHAR(40),
	MD_HASHDIFF_TYPE2 VARCHAR(40),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID VARCHAR(1000),
	MD_MODIFY_DT TIMESTAMP_NTZ(9),
	MD_MODIFY_AUDIT_ID VARCHAR(1000),
	MD_SOURCE VARCHAR(1000),
	MD_SRC_SYSTEM VARCHAR(100),
	MD_EXTRACT_DT TIMESTAMP_NTZ(9),
	MD_SECURITY_TYPE VARCHAR(1000),
	SRC_ID VARCHAR(50),
	MASTER_CODE VARCHAR(50),
	COMPANY_CODE VARCHAR(50),
	COMPANY_NAME VARCHAR(512),
	REGULATORY_ORGANIZATION_NAME VARCHAR(512),
	REGULATORY_ORGANIZATION_CODE VARCHAR(50),
	DEALER_CODE VARCHAR(50),
	DEALER_NAME VARCHAR(512),
	REGION_CODE VARCHAR(512),
	REGION_NAME VARCHAR(512),
	REGION_VP VARCHAR(16777216),
	BRANCHCODE VARCHAR(50),
	BRANCHNAME VARCHAR(512),
	TEAM_CODE NUMBER(38,0),
	TEAM_NAME VARCHAR(512),
	ADVISOR_FULLNAME VARCHAR(512),
	FIRSTNAME VARCHAR(512),
	LASTNAME VARCHAR(512),
	ADVISOR_CORPORATION_NAME VARCHAR(512),
	STATUS VARCHAR(512),
	GROUP_RSP_INDICATOR VARCHAR(512),
	PROVINCE_CODE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	ADVISOR_AUA_SEGMENT VARCHAR(512),
	ADVISOR_AUA_SEGMENT_ORDER NUMBER(38,0),
	ADVISOR_START_DATE TIMESTAMP_NTZ(9),
	NEW_ADVISOR NUMBER(38,0),
	ADVISOR_EFFECIVENESS_DT TIMESTAMP_NTZ(9),
	DEPARTED_ADVISOR_IND NUMBER(1,0),
	PRIMARY_ROLE VARCHAR(500),
	END_DATE TIMESTAMP_NTZ(9),
	REASON VARCHAR(1000),
	NEW_FIRM VARCHAR(1000),
	NEW_FIRM_TYPE VARCHAR(1000),
	NEW_FIRM_BACK_OFFICE VARCHAR(1000),
	PRESTIGE_STATUS VARCHAR(100)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_CLIENTS (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) DEFAULT '0' COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CLIENT_ID VARCHAR(100) COMMENT 'Client ID',
	PROVINCE_DESC VARCHAR(100) COMMENT 'Client province description',
	PROVINCE_CODE VARCHAR(10) COMMENT 'Client province code',
	COUNTRY_DESC VARCHAR(100) COMMENT 'Client country description',
	COUNTRY_CODE VARCHAR(10) COMMENT 'Client country code',
	INCOME_AMT NUMBER(38,2) COMMENT 'Client income',
	INCOME_LEVEL_1_SEGMENT VARCHAR(50) COMMENT 'Client level 1 income Segment : $30k - $50k',
	INCOME_LEVEL_1_SEGMENT_ORD NUMBER(2,0) COMMENT 'Client level 1 income Segment ORDER',
	INCOME_LEVEL_2_SEGMENT VARCHAR(50) COMMENT 'Client level 2 income Segment : Lower Income',
	INCOME_LEVEL_2_SEGMENT_ORD NUMBER(2,0) COMMENT 'Client level 2 income Segment ORDER',
	CLIENT_AUA_SEGMENT VARCHAR(50) COMMENT 'Client AUA Segment : 25k-100k',
	CLIENT_AUA_SEGMENT_ORD NUMBER(2,0) COMMENT 'Client AUA Segment ORDER',
	AGE_SEGMENT VARCHAR(50) COMMENT 'Client Age Segment : 25-34',
	AGE_SEGMENT_ORD NUMBER(2,0) COMMENT 'Client Age Segment ORDER',
	NEW_CLIENT_IND VARCHAR(16777216) COMMENT 'New client indicator',
	CLIENT_START_DT TIMESTAMP_NTZ(9) COMMENT 'Client Start Date'
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_DATE (
	ID NUMBER(38,0) COMMENT 'Surrogate key of the dimension',
	DATE DATE NOT NULL,
	FULL_DATE_DESC VARCHAR(64) NOT NULL,
	DAY_NUM_IN_WEEK NUMBER(1,0) NOT NULL,
	DAY_NUM_IN_MONTH NUMBER(2,0) NOT NULL,
	DAY_NUM_IN_YEAR NUMBER(3,0) NOT NULL,
	DAY_NAME VARCHAR(10) NOT NULL,
	DAY_ABBREV VARCHAR(3) NOT NULL,
	WEEKDAY_IND VARCHAR(64) NOT NULL,
	US_HOLIDAY_IND VARCHAR(64),
	_HOLIDAY_IND VARCHAR(64),
	MONTH_END_IND VARCHAR(64) NOT NULL,
	WEEK_BEGIN_DATE_NKEY NUMBER(9,0) NOT NULL,
	WEEK_BEGIN_DATE DATE NOT NULL,
	WEEK_END_DATE_NKEY NUMBER(9,0) NOT NULL,
	WEEK_END_DATE DATE NOT NULL,
	WEEK_NUM_IN_YEAR NUMBER(9,0) NOT NULL,
	MONTH_NAME VARCHAR(10) NOT NULL,
	MONTH_ABBREV VARCHAR(3) NOT NULL,
	MONTH_NUM_IN_YEAR NUMBER(2,0) NOT NULL,
	YEARMONTH VARCHAR(10) NOT NULL,
	QUARTER NUMBER(1,0) NOT NULL,
	YEARQUARTER VARCHAR(10) NOT NULL,
	YEAR NUMBER(5,0) NOT NULL,
	FISCAL_WEEK_NUM NUMBER(2,0) NOT NULL,
	FISCAL_MONTH_NUM NUMBER(2,0) NOT NULL,
	FISCAL_YEARMONTH VARCHAR(10) NOT NULL,
	FISCAL_QUARTER NUMBER(1,0) NOT NULL,
	FISCAL_YEARQUARTER VARCHAR(10) NOT NULL,
	FISCAL_HALFYEAR NUMBER(1,0) NOT NULL,
	FISCAL_YEAR NUMBER(5,0) NOT NULL,
	SQL_TIMESTAMP TIMESTAMP_NTZ(9),
	CURRENT_ROW_IND VARCHAR(1) DEFAULT 'Y',
	EFFECTIVE_DATE DATE DEFAULT CAST(CURRENT_TIMESTAMP() AS DATE),
	EXPIRATION_DATE DATE DEFAULT CAST('9999-12-31' AS DATE),
	MONTH_NAME_YEAR VARCHAR(100),
	MONTH_NAME_YEAR_ORD NUMBER(38,0)
)COMMENT='Type 0 Dimension Table Housing Calendar and Fiscal Year Date Attributes'
;
create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_FINANCIAL_INSTRUMENTS (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) DEFAULT '0' COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	INVESTMENT_PRODUCT_ID VARCHAR(16777216),
	SYMBOL VARCHAR(512),
	NAME VARCHAR(1000),
	ASSET_CATEGORY VARCHAR(512),
	CATEGORY VARCHAR(512),
	PRODUCT_GROUP VARCHAR(512),
	ISSUER_COMPANY_CODE VARCHAR(4),
	ISSUER_COMPANY_NAME VARCHAR(1000)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.DIM_PLANS (
	ID NUMBER(38,0) autoincrement COMMENT 'Column description',
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) DEFAULT '0' COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	PLAN_CODE VARCHAR(8000),
	PLAN_LABEL VARCHAR(8000),
	ACCOUNT_TYPE VARCHAR(16777216),
	GROUP_TYPE_CODE VARCHAR(8000),
	ACCUMULATION_TYPE VARCHAR(8000)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.WT_DIM_ACCOUNTS (
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) DEFAULT '0' COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CONTRACT_ID VARCHAR(1000) COMMENT 'Capabilities for RLS',
	UNIVERIS_PLAN_ID NUMBER(38,0) COMMENT 'Univeris Plan ID',
	UNIVERIS_CLIENT_ID NUMBER(38,0) COMMENT 'Univeris Client ID',
	PLAN_CODE VARCHAR(8000) COMMENT 'The plan mnemonic code',
	PLAN_LABEL VARCHAR(8000) COMMENT 'The plan mnemonic label',
	ACCOUNT_TYPE VARCHAR(14) COMMENT 'The type of the account Registered or not registered',
	OPEN_DATE TIMESTAMP_NTZ(9) COMMENT 'The setup date UNIVERIS and open date NBIN of the account',
	CLOSE_DATE TIMESTAMP_NTZ(9) COMMENT 'The close date of the account',
	GROUP_TYPE_CODE VARCHAR(8000) COMMENT 'The group type code such as RRSP,LEV,RRSP,LIRA...',
	ACCUMULATION_TYPE VARCHAR(1000) COMMENT 'Accumulation type',
	ADMINISTRATOR_TYPE VARCHAR(8000) COMMENT 'Client Name, Broker/Nominee or Third party',
	ACCOUNT_AUA_SEGMENT VARCHAR(512) COMMENT 'Advisor AUA Segment : 25k-100k',
	ACCOUNT_AUA_SEGMENT_ORDER NUMBER(38,0) COMMENT 'Advisor AUA Segment ORDER',
	ACCOUNT_IND NUMBER(1,0) COMMENT 'Total Number of Client Accounts Flag'
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.WT_DIM_ACCOUNTS_BKP (
	HK_HUB VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_END_DT TIMESTAMP_NTZ(9),
	MD_HASH_NAT_KEYS VARCHAR(64),
	MD_HASHDIFF_TYPE1 VARCHAR(40),
	MD_HASHDIFF_TYPE2 VARCHAR(40),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID VARCHAR(1000),
	MD_MODIFY_DT TIMESTAMP_NTZ(9),
	MD_MODIFY_AUDIT_ID VARCHAR(1000),
	MD_SOURCE VARCHAR(1000),
	MD_SRC_SYSTEM VARCHAR(100),
	MD_EXTRACT_DT TIMESTAMP_NTZ(9),
	MD_SECURITY_TYPE VARCHAR(1000),
	CONTRACT_ID VARCHAR(1000),
	PLAN_MNEMONIC_CD VARCHAR(8000),
	PLAN_MNEMONIC_LBL VARCHAR(8000),
	ACCOUNT_TYPE VARCHAR(14),
	SETUP_DATE TIMESTAMP_NTZ(9),
	CLOSE_DATE TIMESTAMP_NTZ(9),
	GROUP_TYPE_CD VARCHAR(8000),
	ADMINISTRATOR_TYPE VARCHAR(8000)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.WT_DIM_ACCOUNTS_SV (
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) DEFAULT '0' COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) DEFAULT '0' COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CONTRACT_ID VARCHAR(1000) COMMENT 'Capabilities for RLS',
	UNIVERIS_PLAN_ID NUMBER(38,0) COMMENT 'Univeris Plan ID',
	UNIVERIS_CLIENT_ID NUMBER(38,0) COMMENT 'Univeris Client ID',
	PLAN_CODE VARCHAR(8000) COMMENT 'The plan mnemonic code',
	PLAN_LABEL VARCHAR(8000) COMMENT 'The plan mnemonic label',
	ACCOUNT_TYPE VARCHAR(14) COMMENT 'The type of the account Registered or not registered',
	OPEN_DATE TIMESTAMP_NTZ(9) COMMENT 'The setup date UNIVERIS and open date NBIN of the account',
	CLOSE_DATE TIMESTAMP_NTZ(9) COMMENT 'The close date of the account',
	GROUP_TYPE_CODE VARCHAR(8000) COMMENT 'The group type code such as RRSP,LEV,RRSP,LIRA...',
	ACCUMULATION_TYPE VARCHAR(1000) COMMENT 'Accumulation type',
	ADMINISTRATOR_TYPE VARCHAR(8000) COMMENT 'Client Name, Broker/Nominee or Third party'
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.WT_DIM_ADVISOR (
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	ID VARCHAR(50),
	MASTER_CODE VARCHAR(50),
	COMPANY_CODE VARCHAR(50),
	COMPANY_NAME VARCHAR(512),
	REGULATORY_ORGANIZATION_NAME VARCHAR(512),
	REGULATORY_ORGANIZATION_CODE VARCHAR(50),
	DEALER_CODE VARCHAR(50),
	DEALER_NAME VARCHAR(512),
	REGION_CODE VARCHAR(512),
	REGION_NAME VARCHAR(512),
	REGION_VP VARCHAR(16777216) COMMENT 'full name of the RVP',
	BRANCHCODE VARCHAR(50) COMMENT 'Code of the representative branch code',
	BRANCHNAME VARCHAR(512) COMMENT 'Name of the representative branch',
	TEAM_CODE NUMBER(38,0) COMMENT 'Representant Group ID',
	TEAM_NAME VARCHAR(512) COMMENT 'Advisor team description',
	ADVISOR_FULLNAME VARCHAR(512) COMMENT 'Representative name',
	FIRSTNAME VARCHAR(512) COMMENT 'Representative first name',
	LASTNAME VARCHAR(512) COMMENT 'Representative last name',
	ADVISOR_CORPORATION_NAME VARCHAR(512) COMMENT 'Representative corporation name',
	STATUS VARCHAR(512) COMMENT 'Active RR code indicator',
	GROUP_RSP_INDICATOR VARCHAR(512),
	PROVINCE_CODE VARCHAR(16777216) COMMENT 'province code',
	PROVINCE VARCHAR(16777216) COMMENT 'province name',
	ADVISOR_AUA_SEGMENT VARCHAR(512),
	ADVISOR_AUA_SEGMENT_ORDER NUMBER(38,0),
	ADVISOR_START_DATE TIMESTAMP_NTZ(9),
	NEW_ADVISOR NUMBER(38,0),
	ADVISOR_EFFECTIVENESS_DT TIMESTAMP_NTZ(9) COMMENT 'Its the date after one year of advisor joining date , implemented as part of Organic growth',
	DEPARTED_ADVISOR_IND NUMBER(1,0) COMMENT 'DEPARTED ADVISOR INDICATOR',
	PRIMARY_ROLE VARCHAR(500),
	END_DATE TIMESTAMP_NTZ(9) COMMENT 'Departure date of the advisor (TBD)',
	REASON VARCHAR(1000) COMMENT 'Reason of departure',
	NEW_FIRM VARCHAR(1000) COMMENT 'Departure destination',
	NEW_FIRM_TYPE VARCHAR(1000) COMMENT 'Departure destination Type',
	NEW_FIRM_BACK_OFFICE VARCHAR(1000) COMMENT 'Departure destination Back-Office',
	PRESTIGE_STATUS VARCHAR(100) COMMENT 'Prestige Status',
	TRANSITION_PERIOD_END_DATE TIMESTAMP_NTZ(9) COMMENT 'Advisor transition end date',
	DEAL_ASSESTS NUMBER(11,0) COMMENT 'Deal assets',
	EXPECTED_ASSESTS NUMBER(11,0) COMMENT 'Expected assets',
	PREVIOUS_FIRM VARCHAR(100) COMMENT 'Previous Firm of the Advisor',
	PREVIOUS_FIRM_TYPE VARCHAR(100) COMMENT 'Previous Firm type of the Advisor',
	AGE_SEGMENT VARCHAR(50) COMMENT 'Advisor Age Segment : 25-34',
	AGE_SEGMENT_ORD NUMBER(2,0) COMMENT 'Advisor Age Segment ORDER',
	SUSPENDED_IND NUMBER(1,0) COMMENT 'suspended Flag, if an advisor is deleted in certs but still have AUA, will be considered as suspended'
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.WT_DIM_CLIENTS (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CLIENT_ID VARCHAR(100) COMMENT 'Client ID',
	PROVINCE_DESC VARCHAR(100) COMMENT 'Client province description',
	PROVINCE_CODE VARCHAR(10) COMMENT 'Client province code',
	COUNTRY_DESC VARCHAR(100) COMMENT 'Client country description',
	COUNTRY_CODE VARCHAR(10) COMMENT 'Client country code',
	INCOME_AMT NUMBER(38,2) COMMENT 'Client income',
	INCOME_LEVEL_1_SEGMENT VARCHAR(50) COMMENT 'Client level 1 income Segment : $30k - $50k',
	INCOME_LEVEL_1_SEGMENT_ORD NUMBER(2,0) COMMENT 'Client level 1 income Segment ORDER',
	INCOME_LEVEL_2_SEGMENT VARCHAR(50) COMMENT 'Client level 2 income Segment : Lower Income',
	INCOME_LEVEL_2_SEGMENT_ORD NUMBER(2,0) COMMENT 'Client level 2 income Segment ORDER',
	CLIENT_AUA_SEGMENT VARCHAR(50) COMMENT 'Client AUA Segment : 25k-100k',
	CLIENT_AUA_SEGMENT_ORD NUMBER(2,0) COMMENT 'Client AUA Segment ORDER',
	AGE_SEGMENT VARCHAR(50) COMMENT 'Client Age Segment : 25-34',
	AGE_SEGMENT_ORD NUMBER(2,0) COMMENT 'Client Age Segment ORDER',
	NEW_CLIENT_IND VARCHAR(16777216) COMMENT 'New client indicator',
	CLIENT_START_DT TIMESTAMP_NTZ(9) COMMENT 'Client Start Date'
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.WT_DIM_FINANCIAL_INSTRUMENTS (
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE1 VARCHAR(40) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	INVESTMENT_PRODUCT_ID VARCHAR(16777216),
	SYMBOL VARCHAR(512),
	NAME VARCHAR(1000),
	ASSET_CATEGORY VARCHAR(512),
	CATEGORY VARCHAR(512),
	PRODUCT_GROUP VARCHAR(512),
	ISSUER_COMPANY_CODE VARCHAR(4),
	ISSUER_COMPANY_NAME VARCHAR(1000)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED.WT_DIM_PLANS (
	HK_HUB VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'Represents the whole set of hashed natural keys to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(40) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	PLAN_CODE VARCHAR(8000),
	PLAN_LABEL VARCHAR(8000),
	ACCOUNT_TYPE VARCHAR(16777216),
	GROUP_TYPE_CODE VARCHAR(8000),
	ACCUMULATION_TYPE VARCHAR(8000)
);
create or replace view DB_IAW_DEV_DM.SHARED.VW_DIM_ACCOUNTS(
	ID,
	"Source system",
	"Contract ID",
	"Univeris Plan ID",
	"Univeris Client ID",
	"Plan CD",
	"Plan LBL",
	"Account type",
	"Open date",
	"Close date",
	"Group type CD",
	"Accumulation Type",
	"Administrator type",
	"Account AUA segment",
	"Account AUA segment order",
	"Account Indicator"
) as 
SELECT  
	ID,
	MD_SRC_SYSTEM AS "Source system",
	CONTRACT_ID AS "Contract ID",
UNIVERIS_PLAN_ID AS "Univeris Plan ID",
UNIVERIS_CLIENT_ID AS "Univeris Client ID",
	PLAN_CODE AS "Plan CD",
	PLAN_LABEL AS "Plan LBL",
	ACCOUNT_TYPE AS "Account type",
	OPEN_DATE AS "Open date",
	CLOSE_DATE  AS "Close date",
	GROUP_TYPE_CODE AS "Group type CD",
	ACCUMULATION_TYPE AS "Accumulation Type",
	ADMINISTRATOR_TYPE AS "Administrator type",
	ACCOUNT_AUA_SEGMENT as "Account AUA segment",
    ACCOUNT_AUA_SEGMENT_ORDER as "Account AUA segment order",
	ACCOUNT_IND	AS "Account Indicator"
FROM DB_IAW_DEV_DM."SHARED".DIM_ACCOUNTS;
create or replace view DB_IAW_DEV_DM.SHARED.VW_DIM_ADVISORS(
	MD_SRCSYSTEM,
	ID,
	"Master code",
	"Company code",
	"Company name",
	"Regulatory organization code",
	"Regulatory organization name",
	"Dealer code",
	"Dealer name",
	"Region code",
	"Region name",
	"Region VP",
	"Branch code",
	"Branch name",
	"Team code",
	"Team name",
	"Advisor fullname",
	"Last name",
	"First name",
	"Advisor corporation name",
	"Status",
	"Group RSP indicator",
	"Province code",
	"Province",
	"Advisor AUA segment",
	"Advisor AUA segment order",
	"Advisor starting date",
	"New Advisor",
	"Advisor effectiveness date",
	"Primary Role",
	"End date",
	"Departure reason",
	"New Firm",
	"New firm type",
	"New firm back office",
	"Prestige status",
	"Advisor Age Segment",
	"Advisor Age Segment Order",
	"Transition Period End",
	"Deal Assets",
	"Expected Assets",
	"Previous Firm Name",
	"Previous Firm Type",
	"Suspended Advisor Indicator"
) as 
SELECT
MD_SRC_SYSTEM AS MD_SRCSYSTEM ,
ID AS ID ,
MASTER_CODE AS 	"Master code" ,
COMPANY_CODE AS "Company code" ,
COMPANY_NAME AS	"Company name" ,
REGULATORY_ORGANIZATION_CODE AS	"Regulatory organization code",
REGULATORY_ORGANIZATION_NAME AS	"Regulatory organization name" ,
DEALER_CODE AS "Dealer code" ,
DEALER_NAME AS	"Dealer name" ,
REGION_CODE AS	"Region code",
REGION_NAME AS	"Region name" ,
REGION_VP AS "Region VP" ,
BRANCHCODE AS "Branch code" ,
BRANCHNAME AS	"Branch name" ,
TEAM_CODE AS	"Team code" ,
TEAM_NAME AS	"Team name" ,
ADVISOR_FULLNAME AS	"Advisor fullname",
LASTNAME AS	"Last name" ,
FIRSTNAME AS	"First name" ,
ADVISOR_CORPORATION_NAME as	"Advisor corporation name" ,
STATUS AS 	"Status" ,
GROUP_RSP_INDICATOR AS 	"Group RSP indicator" ,
PROVINCE_CODE as	"Province code" ,
PROVINCE AS 	"Province" ,
ADVISOR_AUA_SEGMENT as	"Advisor AUA segment" ,
ADVISOR_AUA_SEGMENT_ORDER as	"Advisor AUA segment order" , 	
ADVISOR_START_DATE as	"Advisor starting date" ,
NEW_ADVISOR as	"New Advisor" ,
CASE WHEN ADVISOR_EFFECIVENESS_DT='10000-12-31 00:00:00' THEN '9999-12-31 00:00:00' ELSE ADVISOR_EFFECIVENESS_DT END as	"Advisor effectiveness date",   --otherwise PowerBI won't accept this date	
PRIMARY_ROLE as "Primary Role",
END_DATE AS "End date",
REASON AS "Departure reason",
NEW_FIRM AS "New Firm",
NEW_FIRM_TYPE AS "New firm type",
NEW_FIRM_BACK_OFFICE AS "New firm back office",
PRESTIGE_STATUS AS "Prestige Status",
AGE_SEGMENT AS "Advisor Age Segment",
AGE_SEGMENT_ORD AS "Advisor Age Segment Order",
TRANSITION_PERIOD_END_DATE AS "Transition Period End",
DEAL_ASSESTS AS "Deal Assets",
EXPECTED_ASSESTS AS "Expected Assets",
PREVIOUS_FIRM AS "Previous Firm Name",
PREVIOUS_FIRM_TYPE AS "Previous Firm Type",
SUSPENDED_IND AS "Suspended Advisor Indicator"

FROM "SHARED".DIM_ADVISOR;
create or replace view DB_IAW_DEV_DM.SHARED.VW_DIM_CLIENTS(
	MD_SRCSYSTEM,
	ID,
	"Client ID",
	"Client type",
	"Province",
	"Country",
	"Income Segmentation",
	"Income Seg ORD",
	"Salary",
	"Salary ORD",
	"Client AUA segment",
	"Client AUA segment order",
	"Age segmentation",
	"Age segmentation ORD",
	"New Client",
	"Client Start Date"
) as 
SELECT
MD_SRC_SYSTEM AS MD_SRCSYSTEM ,
ID ,
--	HOUSEHOLD_ID VARCHAR(16777216),
CLIENT_ID as  "Client ID",
NULL as	"Client type" ,
PROVINCE_DESC AS 	"Province" ,
COUNTRY_DESC as	"Country" ,
INCOME_LEVEL_2_SEGMENT as	"Income Segmentation" ,
INCOME_LEVEL_2_SEGMENT_ORD as	"Income Seg ORD" ,
INCOME_LEVEL_1_SEGMENT AS 	"Salary" ,
INCOME_LEVEL_1_SEGMENT_ORD as	"Salary ORD" ,
CLIENT_AUA_SEGMENT as	"Client AUA segment" ,
CLIENT_AUA_SEGMENT_ORD as	"Client AUA segment order" ,
AGE_SEGMENT as	"Age segmentation" ,
AGE_SEGMENT_ORD as	"Age segmentation ORD" ,
--	IVR_PRIM_BDT DATE,
--	CORP_CD VARCHAR(30),
--	MD_LOADDATE TIMESTAMP_NTZ(9),
---	"Creation Date" DATE,
NEW_CLIENT_IND as	"New Client",
CLIENT_START_DT AS "Client Start Date"
FROM "SHARED".DIM_CLIENTS;
create or replace view DB_IAW_DEV_DM.SHARED.VW_DIM_MARKETPRODUCTS(
	MD_SRCSYSTEM,
	ID,
	"PRODUCT ID",
	"Symbol",
	"Name",
	"Asset category",
	"Category",
	"Group",
	"Issuer company code",
	"Issuer company name"
) as 
SELECT
MD_SRC_SYSTEM AS MD_SRCSYSTEM ,
	ID ,
INVESTMENT_PRODUCT_ID AS "PRODUCT ID",
SYMBOL as	"Symbol"  ,
NAME as	"Name" ,
ASSET_CATEGORY AS "Asset category" ,
CATEGORY as	"Category",
PRODUCT_GROUP as	"Group" ,
ISSUER_COMPANY_CODE as	"Issuer company code",
ISSUER_COMPANY_NAME as	"Issuer company name" 
--MD_START_DT as	MD_LOADDATE 
FROM  SHARED.DIM_FINANCIAL_INSTRUMENTS;
create or replace view DB_IAW_DEV_DM.SHARED.VW_DIM_PLANS(
	MD_SRCSYSTEM,
	ID,
	"Plan code",
	"Plan label",
	"Account type",
	"Group type code",
	"Accumulation type"
) as 
SELECT
MD_SRC_SYSTEM AS MD_SRCSYSTEM ,
	ID ,
PLAN_CODE AS "Plan code" ,
PLAN_LABEL AS	"Plan label" ,
ACCOUNT_TYPE AS	"Account type" ,
GROUP_TYPE_CODE AS	"Group type code" ,
ACCUMULATION_TYPE AS	"Accumulation type" 
--MD_START_DT AS	MD_LOADDATE 
FROM  SHARED.DIM_PLANS;
create or replace schema DB_IAW_DEV_DM.SHARED_BKP;

create or replace TABLE DB_IAW_DEV_DM.SHARED_BKP.DIM_ACCOUNTS (
	HK_HUB VARCHAR(64),
	MD_SRCSYSTEM VARCHAR(8),
	DIM_ACCOUNT_PLN_SYSID VARCHAR(16777216),
	DIM_ACCOUNT_IVR_SYSID VARCHAR(16777216),
	"Plan mnemonic CD" VARCHAR(8000),
	"Plan mnemonic LBL" VARCHAR(8000),
	"Account type" VARCHAR(14),
	"Plan status" VARCHAR(8000),
	"Setup date" TIMESTAMP_NTZ(9),
	"Close date" TIMESTAMP_NTZ(9),
	"Group type CD" VARCHAR(8000),
	"Administrator type" VARCHAR(8000)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED_BKP.DIM_ADVISORS (
	MD_SRCSYSTEM VARCHAR(50),
	ID VARCHAR(50),
	"Master code" VARCHAR(50),
	"Company code" VARCHAR(6),
	"Company name" VARCHAR(20),
	"Regulatory organization code" VARCHAR(5),
	"Regulatory organization name" VARCHAR(53),
	"Dealer code" VARCHAR(50),
	"Dealer name" VARCHAR(512),
	"Region code" VARCHAR(50),
	"Region name" VARCHAR(512),
	"Region VP" VARCHAR(16777216),
	"Branch code" VARCHAR(50),
	"Branch name" VARCHAR(512),
	"Team code" NUMBER(38,5),
	"Team name" VARCHAR(512),
	"Advisor fullname" VARCHAR(16777216),
	"Last name" VARCHAR(512),
	"First name" VARCHAR(512),
	"Advisor corporation name" VARCHAR(512),
	"Status" VARCHAR(512),
	"Group RSP indicator" VARCHAR(512),
	"Province" VARCHAR(512),
	"Advisor AUA segment" VARCHAR(16777216),
	"Advisor AUA segment order" NUMBER(1,0),
	MD_LOADDATE TIMESTAMP_NTZ(9),
	"Creation Date" DATE,
	"New Advisor" NUMBER(1,0)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED_BKP.DIM_CLIENTS (
	MD_SRCSYSTEM VARCHAR(50),
	ID VARCHAR(16777216),
	"Client type" VARCHAR(30),
	"Province" VARCHAR(50),
	"Country" VARCHAR(60),
	"Income Segmentation" VARCHAR(16777216),
	"Income Seg ORD" NUMBER(1,0),
	"Salary" VARCHAR(16777216),
	"Salary ORD" NUMBER(1,0),
	"Client AUA segment" VARCHAR(16777216),
	"Advisor AUA segment order" NUMBER(1,0),
	"Age segmentation" VARCHAR(16777216),
	"Age segmentation ORD" NUMBER(1,0),
	IVR_PRIM_BDT DATE,
	CORP_CD VARCHAR(30),
	MD_LOADDATE TIMESTAMP_NTZ(9),
	"Creation Date" DATE,
	"New Client" NUMBER(1,0)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED_BKP.DIM_DATE (
	DATE DATE NOT NULL,
	FULL_DATE_DESC VARCHAR(64) NOT NULL,
	DAY_NUM_IN_WEEK NUMBER(1,0) NOT NULL,
	DAY_NUM_IN_MONTH NUMBER(2,0) NOT NULL,
	DAY_NUM_IN_YEAR NUMBER(3,0) NOT NULL,
	DAY_NAME VARCHAR(10) NOT NULL,
	DAY_ABBREV VARCHAR(3) NOT NULL,
	WEEKDAY_IND VARCHAR(64) NOT NULL,
	US_HOLIDAY_IND VARCHAR(64) NOT NULL,
	_HOLIDAY_IND VARCHAR(64) NOT NULL,
	MONTH_END_IND VARCHAR(64) NOT NULL,
	WEEK_BEGIN_DATE_NKEY NUMBER(9,0) NOT NULL,
	WEEK_BEGIN_DATE DATE NOT NULL,
	WEEK_END_DATE_NKEY NUMBER(9,0) NOT NULL,
	WEEK_END_DATE DATE NOT NULL,
	WEEK_NUM_IN_YEAR NUMBER(9,0) NOT NULL,
	MONTH_NAME VARCHAR(10) NOT NULL,
	MONTH_ABBREV VARCHAR(3) NOT NULL,
	MONTH_NUM_IN_YEAR NUMBER(2,0) NOT NULL,
	YEARMONTH VARCHAR(10) NOT NULL,
	QUARTER NUMBER(1,0) NOT NULL,
	YEARQUARTER VARCHAR(10) NOT NULL,
	YEAR NUMBER(5,0) NOT NULL,
	FISCAL_WEEK_NUM NUMBER(2,0) NOT NULL,
	FISCAL_MONTH_NUM NUMBER(2,0) NOT NULL,
	FISCAL_YEARMONTH VARCHAR(10) NOT NULL,
	FISCAL_QUARTER NUMBER(1,0) NOT NULL,
	FISCAL_YEARQUARTER VARCHAR(10) NOT NULL,
	FISCAL_HALFYEAR NUMBER(1,0) NOT NULL,
	FISCAL_YEAR NUMBER(5,0) NOT NULL,
	SQL_TIMESTAMP TIMESTAMP_NTZ(9),
	CURRENT_ROW_IND VARCHAR(1) DEFAULT 'Y',
	EFFECTIVE_DATE DATE DEFAULT CAST(CURRENT_TIMESTAMP() AS DATE),
	EXPIRATION_DATE DATE DEFAULT CAST('9999-12-31' AS DATE)
)COMMENT='Type 0 Dimension Table Housing Calendar and Fiscal Year Date Attributes'
;
create or replace TABLE DB_IAW_DEV_DM.SHARED_BKP.DIM_MARKETPRODUCTS (
	MD_SRCSYSTEM VARCHAR(50),
	ID VARCHAR(16777216),
	"Symbol" VARCHAR(512),
	"Name" VARCHAR(512),
	"Asset category" VARCHAR(512),
	"Category" VARCHAR(512),
	"Group" VARCHAR(512),
	"Issuer company code" VARCHAR(4),
	"Issuer company name" VARCHAR(1000),
	MD_LOADDATE TIMESTAMP_NTZ(7)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED_BKP.DIM_PLANS (
	MD_SRCSYSTEM VARCHAR(16777216),
	ID VARCHAR(8000),
	"Plan code" VARCHAR(8000),
	"Plan label" VARCHAR(8000),
	"Account type" VARCHAR(16777216),
	"Group type code" VARCHAR(8000),
	"Accumulation type" VARCHAR(100),
	MD_LOADDATE TIMESTAMP_NTZ(7)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED_BKP.DIM_REGISTERED_REPRESENTATIVES (
	MD_SRCSYSTEM VARCHAR(8),
	ID VARCHAR(16777216),
	"Company code" VARCHAR(50),
	"Company name" VARCHAR(512),
	"Regulatory organization code" VARCHAR(50),
	"Regulatory organization name" VARCHAR(512),
	"Dealer code" VARCHAR(50),
	"Dealer name" VARCHAR(512),
	"Region code" VARCHAR(50),
	"Region name" VARCHAR(512),
	"Region VP" VARCHAR(16777216),
	"Branch code" VARCHAR(16777216),
	"Branch name" VARCHAR(16777216),
	"Team code" VARCHAR(50),
	"Team name" VARCHAR(512),
	"RR fullname" VARCHAR(16777216),
	"RR code" VARCHAR(16777216),
	"Last name" VARCHAR(16777216),
	"First name" VARCHAR(16777216),
	"RR corporation name" VARCHAR(16777216),
	"Status" VARCHAR(16777216),
	"Group RSP indicator" VARCHAR(512),
	MD_LOADDATE TIMESTAMP_NTZ(7)
);
create or replace TABLE DB_IAW_DEV_DM.SHARED_BKP.WORKING_TABLE_DIM_ACCOUNTS_MERGE (
	HK_HUB VARCHAR(64),
	MD_SRCSYSTEM VARCHAR(8),
	DIM_ACCOUNT_PLN_SYSID VARCHAR(16777216),
	DIM_ACCOUNT_IVR_SYSID VARCHAR(16777216),
	"Plan mnemonic CD" VARCHAR(8000),
	"Plan mnemonic LBL" VARCHAR(8000),
	"Account type" VARCHAR(14),
	"Plan status" VARCHAR(8000),
	"Setup date" TIMESTAMP_NTZ(9),
	"Close date" TIMESTAMP_NTZ(9),
	"Group type CD" VARCHAR(8000),
	"Administrator type" VARCHAR(8000)
);
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_ACCOUNTS(
	MD_SRCSYSTEM,
	DIM_ACCOUNT_PLN_SYSID,
	DIM_ACCOUNT_IVR_SYSID,
	"Plan mnemonic CD",
	"Plan mnemonic LBL",
	"Account type",
	"Plan status",
	"Setup date",
	"Close date",
	"Group type CD",
	"Administrator type"
) as 
 /********************************************************************************************************************/
 /************************************************** INVESTIA ********************************************************/
 /********************************************************************************************************************/

  SELECT A.md_srcsystem,--AS "Dim Account Source system", 
         Concat('I_', pln_sysid) AS DIM_ACCOUNT_PLN_SYSID,--I for investia 
         Concat('I_', ivr_sysid) AS DIM_ACCOUNT_IVR_SYSID,--I for investia 
         pln_mnem                AS "Plan mnemonic CD", 
         pln_desc                AS "Plan mnemonic LBL", 
         CASE 
           WHEN pln_reg = 0 THEN 'Non registered' 
           ELSE 'Registered' 
         end                     AS "Account type", 
         pln_status              AS "Plan status", 
         setup_dt                AS "Setup date", 
         close_dt                AS "Close date", 
         stmt_group_mnem         AS "Group type CD", 
         administrator_type      AS "Administrator type" 
  FROM   "DB_IAW_DEV_STAGING".investia.accounts A 
         INNER JOIN "DB_IAW_DEV_STAGING".investia.plans P 
                 ON A.pln_cd = P.pln_cd AND A.MD_LOADDATE = P.MD_LOADDATE
  WHERE A.MD_LOADDATE= (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".investia.accounts)
 
 /********************************************************************************************************************/
 /********************************************************************************************************************/                
                 
                 								UNION ALL 
                 
/********************************************************************************************************************/
/************************************************** FUNDEX **********************************************************/
/********************************************************************************************************************/
                 								
  SELECT A.md_srcsystem          AS "Dim Account Source system", 
         Concat('F_', pln_sysid) AS DIM_ACCOUNT_PLN_SYSID,--F for fundex 
         Concat('F_', ivr_sysid) AS DIM_ACCOUNT_IVR_SYSID,--F for fundex 
         pln_mnem                AS "Plan mnemonic CD", 
         pln_desc                AS "Plan mnemonic LBL", 
         CASE 
           WHEN pln_reg = 0 THEN 'Non registered' 
           ELSE 'Registered' 
         end                     AS "Account type", 
         pln_status              AS "Plan status", 
         setup_dt                AS "Setup date", 
         close_dt                AS "Close date", 
         stmt_group_mnem         AS "Group type CD", 
         administrator_type      AS "Administrator type" 
  FROM   "DB_IAW_DEV_STAGING".fundex.accounts A 
         INNER JOIN "DB_IAW_DEV_STAGING".fundex.plans P 
                 ON A.pln_cd = P.pln_cd AND A.MD_LOADDATE = P.MD_LOADDATE
  WHERE A.MD_LOADDATE= (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".fundex.accounts)
                 
 /********************************************************************************************************************/
 /********************************************************************************************************************/                

  													UNION ALL 
  
 /********************************************************************************************************************/
 /************************************************** IAS UNIVERIS ****************************************************/
 /********************************************************************************************************************/

  SELECT A.md_srcsystem,--AS "Dim Account Source system", 
         Concat('IU_', pln_sysid) AS DIM_ACCOUNT_PLN_SYSID, 
         Concat('IU_', ivr_sysid) AS DIM_ACCOUNT_IVR_SYSID, 
         pln_mnem                 AS "Plan mnemonic CD", 
         pln_desc                 AS "Plan mnemonic LBL", 
         CASE 
           WHEN pln_reg = 0 THEN 'Non registered' 
           ELSE 'Registered' 
         end                      AS "Account type", 
         pln_status               AS "Plan status", 
         setup_dt                 AS "Setup date", 
         close_dt                 AS "Close date", 
         stmt_group_mnem          AS "Group type CD", 
         administrator_type       AS "Administrator type" 
  FROM   "DB_IAW_DEV_STAGING".ias_univeris.accounts A 
         INNER JOIN "DB_IAW_DEV_STAGING".ias_univeris.plans P 
                 ON A.pln_cd = P.pln_cd AND A.MD_LOADDATE = P.MD_LOADDATE
  WHERE A.MD_LOADDATE= (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".ias_univeris.accounts)
                 
/********************************************************************************************************************/
/********************************************************************************************************************/

 													 UNION ALL 
  
/********************************************************************************************************************/
/************************************************** DEFAULT VALUES **************************************************/
/********************************************************************************************************************/
 													 
  SELECT 'N/D' AS "Dim Account Source system", 
         '-1'  AS DIM_ACCOUNT_PLN_SYSID, 
         '-1'  AS DIM_ACCOUNT_IVR_SYSID, 
         '-1'  AS "Plan mnemonic CD", 
         NULL  AS "Plan mnemonic LBL", 
         NULL  AS "Account type", 
         NULL  AS "Plan status", 
         NULL  AS "Setup date", 
         NULL  AS "Close date", 
         NULL  AS "Group type CD", 
         NULL  AS "Administrator type";
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_ADVISORS(
	MD_SRCSYSTEM,
	ID,
	"Master code",
	"Company code",
	"Company name",
	"Regulatory organization code",
	"Regulatory organization name",
	"Dealer code",
	"Dealer name",
	"Region code",
	"Region name",
	"Region VP",
	"Branch code",
	"Branch name",
	"Team code",
	"Team name",
	"Advisor fullname",
	"Last name",
	"First name",
	"Advisor corporation name",
	"Status",
	"Group RSP indicator",
	"Province",
	"Advisor AUA segment",
	"Advisor AUA segment order",
	MD_LOADDATE,
	"Creation Date",
	"New Advisor"
) as 

WITH 

-- INVESTIA advisors AUA
MC_AUA_INVESTIA AS
(SELECT MASTER_CD AS MASTER_CODE, SUM(AUA) AS SUM_AUA
FROM DB_IAW_DEV_STAGING.INVESTIA.HOLDINGS h
GROUP BY MASTER_CD),

-- FUNDEX advisors AUA
MC_AUA_FUNDEX AS
(SELECT MASTER_CD AS MASTER_CODE, SUM(AUA) AS SUM_AUA
FROM DB_IAW_DEV_STAGING.FUNDEX.HOLDINGS h
GROUP BY MASTER_CD),



IAS_RR_RVP AS
(
	SELECT DISTINCT rr."RR code", rr."Region VP"
	FROM DB_IAW_DEV_STAGING.IAS_CERTS.REGISTERED_REPRESENTATIVE rr 
),

-- IAS advisors AUA
MC_AUA_IAS AS
(
	SELECT h.SK_DIM_ADVISORS 	AS RR_CODE, 
			SUM(COALESCE(h.AUA, 0)) 					AS SUM_AUA
	FROM DB_IAW_DEV_DATAMART.HOLDINGS.VW_FACT_HOLDINGS h
	GROUP BY h.SK_DIM_ADVISORS
),

-- IAS advisors Cash position
MC_CASH_IAS AS 
(
	SELECT h.SK_DIM_ADVISORS 				AS RR_CODE, 
			SUM(COALESCE(h."Cash position",0)) 		AS SUM_CASH
	FROM DB_IAW_DEV_DATAMART.HOLDINGS.VW_FACT_HOLDINGS h
	GROUP BY h.SK_DIM_ADVISORS
)
/************************************************** INVESTIA ********************************************************/
select 
     A.MD_SRCSYSTEM,
	CONCAT('I_',MASTER_CD)                                                  AS ID, --I for investia
	 MASTER_CD                                                              AS "Master code",
    'Wealth'                                                                AS "Company code",
	'iA Wealth Management'                                                  AS "Company name",
	'MFDA'                                                                  AS "Regulatory organization code",
	'Mutual Fund Dealers Association'                                       AS "Regulatory organization name",
	DLR_CD                                                                  AS "Dealer code",
	DLR_NAME_ENG                                                            AS "Dealer name",
	RGN_CD                                                                  AS "Region code",
	RGN_NAME                                                                AS "Region name",
    RGN_MGR                                                                 AS "Region VP",
	BRN_CD                                                                  AS "Branch code",
	BRN_NAME                                                                AS "Branch name",
	REP_TEAM_CD                                                             AS "Team code",
	REP_TEAM_NAME                                                           AS "Team name",
    /*Business rule ADVISORS.001*/
    REPLACE(REP_LNAME,'*','') || ', ' || REPLACE(REP_FNAME,'*','') || ' (' || MASTER_CD || ')'              AS "Advisor fullname",
	REP_LNAME                                                               AS "Last name",
	REP_FNAME                                                               AS "First name",
	NK_REP_CORP_NAME                                                        AS "Advisor corporation name",
	REP_ST_NAME                                                             AS "Status",
	REP_GRP_RSP                                                             AS "Group RSP indicator",
	PROV_DESC                                                               AS "Province",
	CASE 	WHEN M.SUM_AUA <= 1000000 THEN '<= 1M'
			WHEN M.SUM_AUA>1000000
			AND M.SUM_AUA <= 5000000 THEN '1M-5M'
			WHEN M.SUM_AUA>5000000
			AND M.SUM_AUA <= 10000000 THEN '5M-10M'
			WHEN M.SUM_AUA>10000000
			AND M.SUM_AUA <= 20000000 THEN '10M-20M'
			WHEN M.SUM_AUA>20000000
			AND M.SUM_AUA <= 30000000 THEN '20M-30M'
			WHEN M.SUM_AUA>30000000
			AND M.SUM_AUA <= 50000000 THEN '30M-50M'
			WHEN M.SUM_AUA>50000000 THEN '> 50M'
	END 																	AS "Advisor AUA segment",
	CASE 	WHEN M.SUM_AUA <= 1000000 THEN 1
			WHEN M.SUM_AUA>1000000
			AND M.SUM_AUA <= 5000000 THEN 2
			WHEN M.SUM_AUA>5000000
			AND M.SUM_AUA <= 10000000 THEN 3
			WHEN M.SUM_AUA>10000000
			AND M.SUM_AUA <= 20000000 THEN 4
			WHEN M.SUM_AUA>20000000
			AND M.SUM_AUA <= 30000000 THEN 5
			WHEN M.SUM_AUA>30000000
			AND M.SUM_AUA <= 50000000 THEN 6
			WHEN M.SUM_AUA>50000000 THEN 7
	END 																	AS "Advisor AUA segment order",
	A.MD_LOADDATE                                                           AS MD_LOADDATE,
	A.CREATE_DT                                                             AS "Creation Date",
    CASE WHEN MONTH(A.MD_LOADDATE)= MONTH(A.CREATE_DT) AND YEAR(A.MD_LOADDATE)= YEAR(A.CREATE_DT) THEN 1 ELSE 0 END AS "New Advisor"
	
    from DB_IAW_DEV_STAGING.INVESTIA.ADVISORS A
    LEFT JOIN "DB_IAW_DEV_STAGING"."INVESTIA"."PROVINCE" P
    ON A.PROV_CD = P.PROV_CD
    LEFT JOIN MC_AUA_INVESTIA M
    ON M.MASTER_CODE = A.MASTER_CD
    WHERE MASTER_CD<>'L8933'
    /*Business rule ADVISORS.002*/
    --Where  NK_REP_CD not in ('610X','611X') 
    --AND REP_ST_NAME in ('Active','Suspended') 

UNION

/************************************************** FUNDEX ********************************************************/
select 
    A.MD_SRCSYSTEM,
    CONCAT('F_',MASTER_CD)                                                  AS ID, --F for fundex
    MASTER_CD                                                               AS "Master code",
	'Wealth'                                                                AS "Company code",
	'iA Wealth Management'                                                  AS "Company name",
	'MFDA'                                                                  AS "Regulatory organization code",
	'Mutual Fund Dealers Association'                                       AS "Regulatory organization name",
	DLR_CD                                                                  AS "Dealer code",
	DLR_NAME_ENG                                                            AS "Dealer name",
	RGN_CD                                                                  AS "Region code",
	RGN_NAME                                                                AS "Region name",
    /*RGN_MGR*/ 'Fundex Advisors'                                           AS "Region VP",
	BRN_CD                                                                  AS "Branch code",
	BRN_NAME                                                                AS "Branch name",
	REP_TEAM_CD                                                             AS "Team code",
	REP_TEAM_NAME                                                           AS "Team name",
    /*Business rule ADVISORS.001*/
    REP_LNAME || ', ' || REP_FNAME || ' (' || MASTER_CD || ')'              AS "Advisor fullname",
	REP_LNAME                                                               AS "Last name",
	REP_FNAME                                                               AS "First name",
	NK_REP_CORP_NAME                                                        AS "Advisor corporation name",
	REP_ST_NAME                                                             AS "Status",
	REP_GRP_RSP                                                             AS "Group RSP indicator",
	PROV_DESC                                                               AS "Province",
	CASE 	WHEN M.SUM_AUA <= 1000000 THEN '<= 1M'
			WHEN M.SUM_AUA>1000000
			AND M.SUM_AUA <= 5000000 THEN '1M-5M'
			WHEN M.SUM_AUA>5000000
			AND M.SUM_AUA <= 10000000 THEN '5M-10M'
			WHEN M.SUM_AUA>10000000
			AND M.SUM_AUA <= 20000000 THEN '10M-20M'
			WHEN M.SUM_AUA>20000000
			AND M.SUM_AUA <= 30000000 THEN '20M-30M'
			WHEN M.SUM_AUA>30000000
			AND M.SUM_AUA <= 50000000 THEN '30M-50M'
			WHEN M.SUM_AUA>50000000 THEN '> 50M'
	END 																	AS "Advisor AUA segment",
	CASE 	WHEN M.SUM_AUA <= 1000000 THEN 1
			WHEN M.SUM_AUA>1000000
			AND M.SUM_AUA <= 5000000 THEN 2
			WHEN M.SUM_AUA>5000000
			AND M.SUM_AUA <= 10000000 THEN 3
			WHEN M.SUM_AUA>10000000
			AND M.SUM_AUA <= 20000000 THEN 4
			WHEN M.SUM_AUA>20000000
			AND M.SUM_AUA <= 30000000 THEN 5
			WHEN M.SUM_AUA>30000000
			AND M.SUM_AUA <= 50000000 THEN 6
			WHEN M.SUM_AUA>50000000 THEN 7
	END 																	AS "Advisor AUA segment order",
	A.MD_LOADDATE                                                           AS MD_LOADDATE,
	A.CREATE_DT                                                             AS "Creation Date",
    CASE WHEN MONTH(A.MD_LOADDATE)= MONTH(A.CREATE_DT) AND YEAR(A.MD_LOADDATE)= YEAR(A.CREATE_DT) THEN 1 ELSE 0 END AS "New Advisor"
	
    from DB_IAW_DEV_STAGING.FUNDEX.ADVISORS A
    LEFT JOIN "DB_IAW_DEV_STAGING"."FUNDEX"."PROVINCE" P
    ON A.PROV_CD = P.PROV_CD
    LEFT JOIN MC_AUA_FUNDEX M
    ON M.MASTER_CODE = A.MASTER_CD
    /*Business rule ADVISORS.002*/
    --Where REP_ST_NAME in ('Active')
    
UNION

/************************************************** IAS ********************************************************/
select distinct
    'IAS'                                                                   AS MD_SRCSYSTEM,
    TRIM(S.MASTER_CODE) 															AS ID,
    TRIM(S.MASTER_CODE) 															AS "Master code",
	'Wealth'                                                                AS "Company code",
	'iA Wealth Management'                                                  AS "Company name",
	'IIROC'                                                                 AS "Regulatory organization code",
	'Investment Industry Regulatory Organization of Canada'                 AS "Regulatory organization name",
	''                                                                      AS "Dealer code",
	'iA Securities'                                                         AS "Dealer name",
	''                                                                      AS "Region code",
	''                                                                      AS "Region name",
    COALESCE(	NULLIF(mm.RVP,'#N/A'),
    			NULLIF(TRIM(RR_RVP."Region VP"),''),
    			NULLIF(URR.RGN_MGR,''),
    			NULLIF(TRIM(ICAR.RVP_NAME),''),
    			ma.RVP,
    			mm.RVP,
    			'Unknown') 								AS "Region VP",
	COALESCE(RR.BRANCHCODE,URR.BRN_CD ,'')                         			AS "Branch code",
	COALESCE(RR.BRANCHNAME,URR.BRN_NAME ,'')                                                 			AS "Branch name",
	RR.GROUPID                                                               AS "Team code",
	COALESCE(mm.TEAM, '')                                                      AS "Team name",
    COALESCE(NULLIF(regexp_replace(RR.REPNAME,'\\(.*\\)',''),''), 
    		 NULLIF(regexp_replace(RC.REPNAME,'\\(.*\\)',''),''),
    		 NULLIF(regexp_replace(URR.REP_LNAME,'\\(.*\\)',''),'') || ', ' || NULLIF(regexp_replace(URR.REP_FNAME,'\\(.*\\)',''),''),
    				'') || ' (' || S.MASTER_CODE || ')' 
    /*R.LASTNAME || ', ' || R.FIRSTNAME || ' (' || R.REPID || ')'*/         AS "Advisor fullname",
	COALESCE(RR.LASTNAME,URR.REP_LNAME )                                                             AS "Last name",
	COALESCE(RR.FIRSTNAME,URR.REP_FNAME )                                                    		AS "First name",
	'' /*RR_CERTS."Trade Name"*/                                            		AS "Advisor corporation name",
	CASE COALESCE(RR.ACTIVEIND, 0) WHEN 0 THEN 'Inactive' WHEN 1 THEN 'Active' Else '' END   AS "Status",
	NULL                                                                    AS "Group RSP indicator",
	COALESCE(mm.PROVINCE,'')                                               		AS "Province",
	CASE 	WHEN M.SUM_AUA <= 1000000 THEN '<= 1M'
			WHEN M.SUM_AUA>1000000
			AND M.SUM_AUA <= 5000000 THEN '1M-5M'
			WHEN M.SUM_AUA>5000000
			AND M.SUM_AUA <= 10000000 THEN '5M-10M'
			WHEN M.SUM_AUA>10000000
			AND M.SUM_AUA <= 20000000 THEN '10M-20M'
			WHEN M.SUM_AUA>20000000
			AND M.SUM_AUA <= 30000000 THEN '20M-30M'
			WHEN M.SUM_AUA>30000000
			AND M.SUM_AUA <= 50000000 THEN '30M-50M'
			WHEN M.SUM_AUA>50000000 THEN '> 50M'
			ELSE 'Unknown'
	END 																	AS "Advisor AUA segment",
	CASE 	WHEN M.SUM_AUA <= 1000000 THEN 1
			WHEN M.SUM_AUA>1000000
			AND M.SUM_AUA <= 5000000 THEN 2
			WHEN M.SUM_AUA>5000000
			AND M.SUM_AUA <= 10000000 THEN 3
			WHEN M.SUM_AUA>10000000
			AND M.SUM_AUA <= 20000000 THEN 4
			WHEN M.SUM_AUA>20000000
			AND M.SUM_AUA <= 30000000 THEN 5
			WHEN M.SUM_AUA>30000000
			AND M.SUM_AUA <= 50000000 THEN 6
			WHEN M.SUM_AUA>50000000 THEN 7
			ELSE 0
	END 																	AS "Advisor AUA segment order",
	RR.MD_LOADDATE                                                          AS MD_LOADDATE,
	RR.STARTDATE                                                            AS "Creation Date",
	CASE WHEN MONTH(RR.MD_LOADDATE)= MONTH(RR.STARTDATE) AND YEAR(RR.MD_LOADDATE)= YEAR(RR.STARTDATE) THEN 1 ELSE 0 END AS "New Advisor"
    
    FROM BR.VW_IAS_RRCODE_MASTERCODE S
	LEFT JOIN IAS_RR_RVP RR_RVP
	ON RR_RVP."RR code" = S.MASTER_CODE AND RR_RVP."Region VP" <> ''
	LEFT JOIN DB_IAW_DEV_DATAMART.BR.IAS_MONTHLY_MILESTONES mm
	ON TRIM(S.MASTER_CODE) = TRIM(mm.REPID)
	LEFT JOIN BR.IAS_MANUAL_ADVISOR_RVP ma
	ON TRIM(S.MASTER_CODE) = TRIM(ma.REPID)
    LEFT JOIN MC_AUA_IAS M
    ON M.RR_CODE = S.MASTER_CODE
    LEFT JOIN MC_CASH_IAS MC 
    ON MC.RR_CODE = S.MASTER_CODE
    LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS_UNIVERIS.REGISTERED_REPRESENTATIVE URR
    ON S.MASTER_CODE=URR.NK_REP_CD
    
    /* deal with main rep codes that has no RVP*/
    
    LEFT JOIN DB_IAW_DEV_STAGING.IAS_COMMISSION.REGISTERED_REPRESENTATIVE RR
    ON RR.REPID = S.MASTER_CODE AND RR.MAINREPCODE = S.MASTER_CODE
    AND RR.LASTNAME IS NOT NULL AND RR.FIRSTNAME IS NOT NULL AND RR.ACTIVE = 1 --AND RR.REPID <> RR.MAINREPCODE
    LEFT JOIN DB_IAW_DEV_STAGING.IAS_COMMISSION.REGISTERED_REPRESENTATIVE RC
    ON RC.REPID = S.MASTER_CODE --AND RR.MAINREPCODE = S.MASTER_CODE
    AND RC.ACTIVE = 0   
    
    
    LEFT JOIN BR.IAS_CERTS_ADVISOR_RVP ICAR 
    ON (CONTAINS(UPPER(ICAR.ADVISOR_NAME),UPPER(TRIM(RR.FIRSTNAME))) AND CONTAINS(UPPER(ICAR.ADVISOR_NAME),UPPER(TRIM(RR.LASTNAME))) )
    OR CONTAINS(UPPER(ICAR.ADVISOR_NAME),UPPER(TRIM(RR.REPNAME)))
    OR (CONTAINS(UPPER(ICAR.ADVISOR_NAME),UPPER(TRIM(SPLIT_PART(RR.REPNAME,',',1)))) AND CONTAINS(UPPER(ICAR.ADVISOR_NAME),UPPER(TRIM(SPLIT_PART(RR.REPNAME,',',2)))))
    
    WHERE M.SUM_AUA <> 0 OR MC.SUM_CASH <> 0

UNION

/************************************************** DEFAULT VALUES ***************************************************/
SELECT 
    'N/D'                                                                   AS MD_SRCSYSTEM,
	'-1'                                                                    AS ID,
	'-1'                                                                    AS "Master code",
    'Wealth'                                                                AS "Company code",
	'iA Wealth Management'                                                  AS "Company name",
	NULL                                                                    AS "Regulatory organization code",
	NULL                                                                    AS "Regulatory organization name",
	'-1'                                                                    AS "Dealer code",
	NULL                                                                    AS "Dealer name",
	'-1'                                                                    AS "Region code",
	NULL                                                                    AS "Region name",
    'Unknown'                                                               AS "Region VP",
	'-1'                                                                    AS "Branch code",
	NULL                                                                    AS "Branch name",
	NULL                                                                    AS "Team code",
	NULL                                                                    AS "Team name",
    NULL                                                                    AS "Advisor fullname",
	NULL                                                                    AS "Last name",
	NULL                                                                    AS "First name",
	NULL                                                                    AS "Advisor corporation name",
	NULL                                                                    AS "Status",
	NULL                                                                    AS "Group RSP indicator",
	NULL                                                                    AS "Province",
	NULL																	AS "Advisor AUA segment",
	NULL																	AS "Advisor AUA segment order",	
	NULL                                                                    AS MD_LOADDATE,
	NULL                                                                    AS "Creation Date",
    NULL                                                                    AS "New Advisor";
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_ADVISORS_ACCESS(
	MD_SRCSYSTEM,
	ID,
	"Master code",
	"Company code",
	"Company name",
	"Regulatory organization code",
	"Regulatory organization name",
	"Dealer code",
	"Dealer name",
	"Region code",
	"Region name",
	"Region VP",
	"Branch code",
	"Branch name",
	"Team code",
	"Team name",
	"Advisor fullname",
	"Last name",
	"First name",
	"Advisor corporation name",
	"Status",
	"Group RSP indicator",
	"Province",
	"Advisor AUA segment",
	"Advisor AUA segment order"
) as 

SELECT R.MD_SRCSYSTEM, ID, "Master code", "Company code", "Company name", "Regulatory organization code", "Regulatory organization name", "Dealer code", "Dealer name", "Region code", "Region name", "Region VP", "Branch code", "Branch name", "Team code", "Team name", "Advisor fullname", "Last name", "First name", "Advisor corporation name", "Status", "Group RSP indicator", "Province", "Advisor AUA segment", "Advisor AUA segment order"
FROM DB_IAW_DEV_DATAMART."SHARED".DIM_ADVISORS R
INNER JOIN DB_IAW_DEV_DATAMART.BR.DIM_USER U
ON U."User Login"= CURRENT_USER()  AND  (R.MD_SRCSYSTEM=U."Capacity" OR U."Capacity" ='ALL');
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_CLIENTS(
	MD_SRCSYSTEM,
	ID,
	HOUSEHOLD_ID,
	"Client type",
	"Province",
	"Country",
	"Income Segmentation",
	"Income Seg ORD",
	"Salary",
	"Salary ORD",
	"Client AUA segment",
	"Advisor AUA segment order",
	"Age segmentation",
	"Age segmentation ORD",
	IVR_PRIM_BDT,
	CORP_CD,
	MD_LOADDATE,
	"Creation Date",
	"New Client"
) as 

WITH 

-- INVESTIA clients AUA
CI_AUA_INVESTIA AS
(SELECT h.IVR_SYSID AS CLIENT_ID, SUM(AUA) AS SUM_AUA
FROM DB_IAW_DEV_STAGING.INVESTIA.HOLDINGS h
WHERE h.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.INVESTIA.HOLDINGS)
GROUP BY IVR_SYSID),

-- FUNDEX clients AUA
CI_AUA_FUNDEX AS
(SELECT h.IVR_SYSID AS CLIENT_ID, SUM(AUA) AS SUM_AUA
FROM DB_IAW_DEV_STAGING.FUNDEX.HOLDINGS h
WHERE h.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.FUNDEX.HOLDINGS )
GROUP BY IVR_SYSID),

-- IAS UNIVERIS clients AUA
CI_AUA_IAS_UNIVERIS AS
(SELECT h.IVR_SYSID AS CLIENT_ID, SUM(AUA) AS SUM_AUA
FROM DB_IAW_DEV_STAGING.IAS_UNIVERIS.HOLDINGS h
WHERE h.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS_UNIVERIS.HOLDINGS )
GROUP BY IVR_SYSID),

-- IAS clients AUA
CI_AUA_IAS AS
(SELECT A.A_C_CLIENT AS CLIENT_ID, 
		SUM(	DECODE(	h.TRAN_SUMM_CURRENCY,'USD',
           				h.TRAN_SUMM_CURR_MKT_VALUE*E.EXCHANGERATE,
       					h.TRAN_SUMM_CURR_MKT_VALUE)
       		) AS SUM_AUA
FROM DB_IAW_DEV_STAGING.IAS.HOLDINGS h
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS.EXCHANGERATE E ON
EXCHANGEDATE = TRAN_SUMM_BUSINESS_DATE AND h.MD_LOADDATE = E.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS."ACCOUNTS" A ON
H.A_C_ID = A.A_C_ID AND h.MD_LOADDATE = A.MD_LOADDATE
WHERE H.A_C_ID NOT RLIKE '^[A-Z][A-Z]'

AND h.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS.HOLDINGS )

GROUP BY A_C_CLIENT),

-- IAS annual income gross amount 
IAS_CLIENT_INC AS
(
	SELECT c.A_C_CLIENT,
	CASE 
		WHEN c.CLIENT_TAX_RECIP_TYPE IN (3,4) 											    THEN -1
		WHEN c.CLIENT_ANNUAL_GROSS_INC LIKE '%K%' 										    THEN TRY_TO_NUMBER(regexp_replace(c.CLIENT_ANNUAL_GROSS_INC,'[^0-9]',''))
		WHEN c.CLIENT_ANNUAL_GROSS_INC LIKE '%M%' 										    THEN TRY_TO_NUMBER(regexp_replace(c.CLIENT_ANNUAL_GROSS_INC,'[^0-9]','')) * 1000
		WHEN TRY_TO_NUMBER(regexp_replace(c.CLIENT_ANNUAL_GROSS_INC,'[^0-9]','')) = 0 		THEN -1
		WHEN TRY_TO_NUMBER(regexp_replace(c.CLIENT_ANNUAL_GROSS_INC,'[^0-9]','')) < 1000 	THEN TRY_TO_NUMBER(regexp_replace(c.CLIENT_ANNUAL_GROSS_INC,'[^0-9]',''))
		WHEN TRY_TO_NUMBER(regexp_replace(c.CLIENT_ANNUAL_GROSS_INC,'[^0-9]','')) >= 1000 	THEN TRY_TO_NUMBER(regexp_replace(c.CLIENT_ANNUAL_GROSS_INC,'[^0-9]',''))*0.001
		ELSE -1 
	END AS CLIENT_ANNUAL_GROSS_INC_NUMBER
	FROM DB_IAW_DEV_STAGING.IAS.CLIENTS c
	WHERE c.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS.CLIENTS)
)


/*
,CLIENT_PROGRAM_TYPE_INVESTIA AS
(

SELECT 
DISTINCT ID,CASE NB_PROGRAM WHEN 1 THEN PT WHEN 2 THEN 'Commission-based & Fee-based' END AS PT
FROM(
SELECT  DISTINCT IVR_SYSID AS ID, "Program type" AS PT ,count(DISTINCT "Program type") OVER (PARTITION BY IVR_SYSID) AS NB_PROGRAM
FROM (SELECT IVR_SYSID, CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 THEN 'Fee-based' ELSE 'Commission-based' END AS "Program type" FROM DB_IAW_DEV_STAGING.INVESTIA.HOLDINGS WHERE MV>0) --we calculated the prgram type just like in the view holding because this column does not exist in the source table investia.holdings
) 

),


CLIENT_PROGRAM_TYPE_FUNDEX AS
(



SELECT 
DISTINCT ID,CASE NB_PROGRAM WHEN 1 THEN PT WHEN 2 THEN 'Commission-based & Fee-based' END AS PT
FROM(
SELECT  DISTINCT IVR_SYSID AS ID, "Program type" AS PT ,count(DISTINCT "Program type") OVER (PARTITION BY IVR_SYSID) AS NB_PROGRAM
FROM (SELECT IVR_SYSID, CASE WHEN IVD_LOAD_FLAG = 'FCL' OR WF_IND = 1 THEN 'Fee-based' ELSE 'Commission-based' END AS "Program type" FROM DB_IAW_DEV_STAGING.FUNDEX.HOLDINGS WHERE MV>0) --we calculated the prgram type just like in the view holding because this column does not exist in the source table fundex.holdings
)
)
*/

/************************************************** INVESTIA ********************************************************/
SELECT 
MD_SRCSYSTEM
,CONCAT('I_',IVR_SYSID)                                     AS ID --I for investia
,CONCAT('I_',IVR_SYSID) 									AS HOUSEHOLD_ID
,RECIPIENT_DESC_ENG                                         AS "Client type"
--,IVR_ST_NAME_ENG                                            AS "Client status"
--,LANG_CD                                                    AS "Client language code"
--,IVR_SETUP_DT                                               AS "Client setup date"
--,IVR_STOP_DT                                                AS "Client stop date"

--,(SELECT MAX(PROV_DESC) FROM "DB_IAW_DEV_STAGING"."INVESTIA"."PROVINCE" WHERE IVR_RES_CD=PROV_CD) AS "Province"

,CASE   WHEN LENGTH(IVR_RES_CD)=3 THEN 'Outside Canada' 
        WHEN LENGTH(IVR_RES_CD)=2 THEN IFNULL((SELECT MAX(PROV_DESC) 
                                               FROM "DB_IAW_DEV_STAGING"."INVESTIA"."PROVINCE" 
                                               WHERE IVR_RES_CD=PROV_CD),'Outside Canada') 
        ELSE 'Unknown' END                                  AS "Province"
,CASE   WHEN LENGTH(IVR_RES_CD)=3 THEN (SELECT MAX(COUNTRY_DESC) 
                                        FROM "DB_IAW_DEV_STAGING"."INVESTIA"."COUNTRY" 
                                        WHERE IVR_RES_CD=COUNTRY_CD)  
        WHEN LENGTH(IVR_RES_CD)=2 THEN 'Canada' 
        ELSE 'Unknown' END                                  AS "Country" 
--Technical Rule: if the length of IVR_RES_CD =2 it means that it's a canadian province code so country=Canada 
--otherwise it's a foreign country and we get the LBL from COUNTRY table
--,SALARY_DESC												AS "Income Segmentation"

,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN '(<$30k)'
                  WHEN '$30,001 to $50,000' THEN '$30k - $50k'
                  WHEN '$50,001 to $70,000' THEN '$50k - $70k'
                  WHEN '$70,001 to $100,000' THEN '$70k - $100k'
                  WHEN '$100,001 to $200,000' THEN '$100k - $200k'
                  WHEN '$200,001 to $300,000' THEN '$200k - $300k'
                  WHEN 'Greater or Equal to $300,001' THEN '$300k+'
                  WHEN 'More or Equal to $300,001' THEN '$300k+'
              WHEN 'Unknown' THEN 'Unknown' 
              ELSE 'Unknown' END 			AS "Income Segmentation"
                  
,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 1
                  WHEN '$30,001 to $50,000' THEN 2
                  WHEN '$50,001 to $70,000' THEN 3
                  WHEN '$70,001 to $100,000' THEN 4
                  WHEN '$100,001 to $200,000' THEN 5
                  WHEN '$200,001 to $300,000' THEN 6
                  WHEN 'Greater or Equal to $300,001' THEN 7
                  WHEN 'More or Equal to $300,001' THEN 7
                  WHEN 'Unknown' THEN 8 END 				AS "Income Seg ORD"

,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 'Lower Income'
                  WHEN '$30,001 to $50,000' THEN 'Middle Income'
                  WHEN '$50,001 to $70,000' THEN 'Middle Income'
                  WHEN '$70,001 to $100,000' THEN 'Upper Income'
                  WHEN '$100,001 to $200,000' THEN 'Upper Income'
                  WHEN '$200,001 to $300,000' THEN 'High Income'
                  WHEN 'Greater or Equal to $300,001' THEN 'High Income'
                  WHEN 'More or Equal to $300,001' THEN 'High Income'
                  WHEN 'Unknown' THEN 'Unknown' 
                  ELSE 'Unknown' END 		AS "Salary"

,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 1
                  WHEN '$30,001 to $50,000' THEN 2
                  WHEN '$50,001 to $70,000' THEN 2
                  WHEN '$70,001 to $100,000' THEN 3
                  WHEN '$100,001 to $200,000' THEN 3
                  WHEN '$200,001 to $300,000' THEN 4
                  WHEN 'Greater or Equal to $300,001' THEN 4
                  WHEN 'More or Equal to $300,001' THEN 4
                  WHEN 'Unknown' THEN 5 END AS 				"Salary ORD"
 ,CASE WHEN CA.SUM_AUA < 25000 THEN '<25k'
	WHEN CA.SUM_AUA>=25000
	AND CA.SUM_AUA <= 100000 THEN '25k-100k'
	WHEN CA.SUM_AUA>100000
	AND CA.SUM_AUA <= 250000 THEN '100k-250k'
	WHEN CA.SUM_AUA>250000
	AND CA.SUM_AUA <= 500000 THEN '250k-500k'
	WHEN CA.SUM_AUA>500000 THEN '> 500k'
END 														AS "Client AUA segment",

CASE WHEN CA.SUM_AUA < 25000 THEN 1
	WHEN CA.SUM_AUA>=25000
	AND CA.SUM_AUA <= 100000 THEN 2
	WHEN CA.SUM_AUA>100000
	AND CA.SUM_AUA <= 250000 THEN 3
	WHEN CA.SUM_AUA>250000
	AND CA.SUM_AUA <= 500000 THEN 4
	WHEN CA.SUM_AUA>500000 THEN 5
END 														AS "Advisor AUA segment order",

  CASE WHEN C.CORP_CD='C' THEN 'Corporate'
       WHEN C.IVR_PRIM_BDT IS NULL AND C.CORP_CD IS NULL THEN 'Unknown'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 25 THEN 'Under 25'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 25 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 35 THEN '25-34'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 35 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 45 THEN '35-44'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 45 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 55 THEN '45-54'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 55 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 65 THEN '55-64'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 65 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 75 THEN '65-74'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 75 THEN 'Over 75' END AS "Age segmentation",
       
  
   CASE WHEN C.CORP_CD='C' THEN 9
       WHEN C.IVR_PRIM_BDT IS NULL AND C.CORP_CD IS NULL THEN 8
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 25 THEN 1
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 25 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 35 THEN 2
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 35 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 45 THEN 3
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 45 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 55 THEN 4
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 55 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 65 THEN 5
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 65 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 75 THEN 6
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 75 THEN 7 END AS "Age segmentation ORD",
       
      
      
       C.IVR_PRIM_BDT,
       C.CORP_CD,

  C.MD_LOADDATE,
  C.CREATE_DT AS "Creation Date",
  CASE WHEN MONTH(C.MD_LOADDATE)= MONTH(C.CREATE_DT) AND YEAR(C.MD_LOADDATE)= YEAR(C.CREATE_DT) THEN 1 ELSE 0 END AS "New Client"

FROM "DB_IAW_DEV_STAGING"."INVESTIA"."CLIENTS" C
LEFT JOIN CI_AUA_INVESTIA CA
ON C.IVR_SYSID = CA.CLIENT_ID 
WHERE C.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."INVESTIA"."CLIENTS")


UNION ALL

/************************************************** FUNDEX ********************************************************/
SELECT
MD_SRCSYSTEM
,CONCAT('F_',IVR_SYSID)                                     AS ID --F for investia
,CONCAT('F_',IVR_SYSID) 									AS HOUSEHOLD_ID
,RECIPIENT_DESC_ENG                                         AS "Client type"
--,IVR_ST_NAME_ENG                                            AS "Client status"
--,LANG_CD                                                    AS "Client language code"
--,IVR_SETUP_DT                                               AS "Client setup date"
--,IVR_STOP_DT                                                AS "Client stop date"

--,(SELECT MAX(PROV_DESC) FROM "DB_IAW_DEV_STAGING"."FUNDEX"."PROVINCE" WHERE IVR_RES_CD=PROV_CD) AS "Province"

,CASE   WHEN LENGTH(IVR_RES_CD)=3 THEN 'Outside Canada' 
        WHEN LENGTH(IVR_RES_CD)=2 THEN IFNULL((SELECT MAX(PROV_DESC) 
                                               FROM "DB_IAW_DEV_STAGING"."FUNDEX"."PROVINCE" 
                                               WHERE IVR_RES_CD=PROV_CD),'Outside Canada') 
        ELSE 'Unknown' END                                  AS "Province"
,CASE   WHEN LENGTH(IVR_RES_CD)=3 THEN (SELECT MAX(COUNTRY_DESC) 
                                        FROM "DB_IAW_DEV_STAGING"."FUNDEX"."COUNTRY" 
                                        WHERE IVR_RES_CD=COUNTRY_CD) 
        WHEN LENGTH(IVR_RES_CD)=2 THEN 'Canada' 
        ELSE 'Unknown' END                                  AS "Country" 
--Technical Rule: if the length of IVR_RES_CD =2 it means that it's a canadian province code so country=Canada 
--otherwise it's a foreign country and we get the LBL from COUNTRY table
--,SALARY_DESC												AS "Income Segmentation"

,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN '(<$30k)'
                  WHEN '$30,001 to $50,000' THEN '$30k - $50k'
                  WHEN '$50,001 to $70,000' THEN '$50k - $70k'
                  WHEN '$70,001 to $100,000' THEN '$70k - $100k'
                  WHEN '$100,001 to $200,000' THEN '$100k - $200k'
                  WHEN '$200,001 to $300,000' THEN '$200k - $300k'
                  WHEN 'Greater or Equal to $300,001' THEN '$300k+'
                  WHEN 'More or Equal to $300,001' THEN '$300k+'
                  WHEN 'Unknown' THEN 'Unknown' 
                  ELSE 'Unknown' END  		AS "Income Segmentation"
                  
,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 1
                  WHEN '$30,001 to $50,000' THEN 2
                  WHEN '$50,001 to $70,000' THEN 3
                  WHEN '$70,001 to $100,000' THEN 4
                  WHEN '$100,001 to $200,000' THEN 5
                  WHEN '$200,001 to $300,000' THEN 6
                  WHEN 'Greater or Equal to $300,001' THEN 7
                  WHEN 'More or Equal to $300,001' THEN 7
                  WHEN 'Unknown' THEN 8 END 				AS "Income Seg ORD"
                  
,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 'Lower Income'
                  WHEN '$30,001 to $50,000' THEN 'Middle Income'
                  WHEN '$50,001 to $70,000' THEN 'Middle Income'
                  WHEN '$70,001 to $100,000' THEN 'Upper Income'
                  WHEN '$100,001 to $200,000' THEN 'Upper Income'
                  WHEN '$200,001 to $300,000' THEN 'High Income'
                  WHEN 'Greater or Equal to $300,001' THEN 'High Income'
                  WHEN 'More or Equal to $300,001' THEN 'High Income'
                  WHEN 'Unknown' THEN 'Unknown' 
                  ELSE 'Unknown' END AS "Salary"
                  
,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 1
                  WHEN '$30,001 to $50,000' THEN 2
                  WHEN '$50,001 to $70,000' THEN 2
                  WHEN '$70,001 to $100,000' THEN 3
                  WHEN '$100,001 to $200,000' THEN 3
                  WHEN '$200,001 to $300,000' THEN 4
                  WHEN 'Greater or Equal to $300,001' THEN 4
                  WHEN 'More or Equal to $300,001' THEN 4
                  WHEN 'Unknown' THEN 5 END 				AS "Salary ORD"
,CASE WHEN CA.SUM_AUA < 25000 THEN '<25k'
	WHEN CA.SUM_AUA>=25000
	AND CA.SUM_AUA <= 100000 THEN '25k-100k'
	WHEN CA.SUM_AUA>100000
	AND CA.SUM_AUA <= 250000 THEN '100k-250k'
	WHEN CA.SUM_AUA>250000
	AND CA.SUM_AUA <= 500000 THEN '250k-500k'
	WHEN CA.SUM_AUA>500000 THEN '> 500k'
END 														AS "Client AUA segment",

CASE WHEN CA.SUM_AUA < 25000 THEN 1
	WHEN CA.SUM_AUA>=25000
	AND CA.SUM_AUA <= 100000 THEN 2
	WHEN CA.SUM_AUA>100000
	AND CA.SUM_AUA <= 250000 THEN 3
	WHEN CA.SUM_AUA>250000
	AND CA.SUM_AUA <= 500000 THEN 4
	WHEN CA.SUM_AUA>500000 THEN 5
END 														AS "Advisor AUA segment order",

CASE WHEN C.CORP_CD='C' THEN 'Corporate'
       WHEN C.IVR_PRIM_BDT IS NULL AND C.CORP_CD IS NULL THEN 'Unknown'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 25 THEN 'Under 25'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 25 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 35 THEN '25-34'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 35 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 45 THEN '35-44'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 45 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 55 THEN '45-54'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 55 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 65 THEN '55-64'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 65 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 75 THEN '65-74'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 75 THEN 'Over 75' END AS "Age segmentation",
       
 CASE WHEN C.CORP_CD='C' THEN 9
       WHEN C.IVR_PRIM_BDT IS NULL AND C.CORP_CD IS NULL THEN 8
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 25 THEN 1
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 25 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 35 THEN 2
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 35 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 45 THEN 3
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 45 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 55 THEN 4
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 55 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 65 THEN 5
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 65 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 75 THEN 6
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 75 THEN 7 END AS "Age segmentation ORD",
            
      
       C.IVR_PRIM_BDT,
       C.CORP_CD,

  C.MD_LOADDATE,
  
  C.CREATE_DT AS "Creation Date",
  CASE WHEN MONTH(C.MD_LOADDATE)= MONTH(C.CREATE_DT) AND YEAR(C.MD_LOADDATE)= YEAR(C.CREATE_DT) THEN 1 ELSE 0 END AS "New Client"

FROM "DB_IAW_DEV_STAGING"."FUNDEX"."CLIENTS" C
LEFT JOIN CI_AUA_FUNDEX CA
ON C.IVR_SYSID = CA.CLIENT_ID
WHERE C.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."FUNDEX"."CLIENTS")

UNION ALL

/************************************************** IAS ********************************************************/
SELECT 
       'IAS'                                                AS MD_SRCSYSTEM,
       CL.A_C_CLIENT                                           AS ID,
       CL.A_C_HOUSEHOLD										AS HOUSEHOLD_ID,
       NULL                                                 AS "Client type",
      -- NULL                                                 AS "Client status",
      -- NULL                                                 AS "Client language code",
      -- NULL                                                 AS "Client setup date",
      -- NULL                                                 AS "Client stop date",
	   IFNULL( PR.PROV_DESC , 'Outside Canada' )            AS "Province",
       CT.COUNTRY_DESC                                      AS "Country",  
	   CASE  
	   		WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER=-1 					THEN 'Unknown'
	   		WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER<30 					THEN '(<$30k)'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 30 AND 50 	THEN '$30k - $50k'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 50 AND 70 	THEN '$50k - $70k'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 70 AND 100 	THEN '$70k - $100k'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 100 AND 200 THEN '$100k - $200k'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 200 AND 300 THEN '$200k - $300k'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER > 300  				THEN '$300k+'
	     ELSE 'Unknown' END  												AS "Income Segmentation"
                  
		,CASE  
	   		WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER=-1 					THEN 8
	   		WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER<30 					THEN 1
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 30 AND 50 	THEN 2
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 50 AND 70 	THEN 3
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 70 AND 100 	THEN 4
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 100 AND 200 THEN 5
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 200 AND 300 THEN 6
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER > 300  				THEN 7
	     END 				 								AS "Income Seg ORD"
		                  
		,CASE  
	   		WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER=-1 					THEN 'Unknown'
	   		WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER<30 					THEN 'Lower Income'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 30 AND 70 	THEN 'Middle Income'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 70 AND 200 	THEN 'Upper Income'
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER > 200  				THEN 'High Income'
	     ELSE 'Unknown' END 												AS "Salary"
		                  
		,CASE  
	   		WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER=-1 					THEN 5
	   		WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER<30 					THEN 1
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 30 AND 70 	THEN 2
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER BETWEEN 70 AND 200 	THEN 3
	        WHEN INC.CLIENT_ANNUAL_GROSS_INC_NUMBER > 200  				THEN 4
	     END 												AS "Salary ORD"
	    ,CASE WHEN  CA.SUM_AUA < 0 THEN '<0'
	    	WHEN CA.SUM_AUA < 25000 THEN '<25k'
			WHEN CA.SUM_AUA>=25000
			AND CA.SUM_AUA <= 100000 THEN '25k-100k'
			WHEN CA.SUM_AUA>100000
			AND CA.SUM_AUA <= 250000 THEN '100k-250k'
			WHEN CA.SUM_AUA>250000
			AND CA.SUM_AUA <= 500000 THEN '250k-500k'
			WHEN CA.SUM_AUA>500000 THEN '> 500k'
		END 														AS "Client AUA segment",
		
		CASE WHEN CA.SUM_AUA < 0 THEN 0 
			WHEN CA.SUM_AUA < 25000 THEN 1
			WHEN CA.SUM_AUA>=25000
			AND CA.SUM_AUA <= 100000 THEN 2
			WHEN CA.SUM_AUA>100000
			AND CA.SUM_AUA <= 250000 THEN 3
			WHEN CA.SUM_AUA>250000
			AND CA.SUM_AUA <= 500000 THEN 4
			WHEN CA.SUM_AUA>500000 THEN 5
		END 														AS "Advisor AUA segment order",
		
CASE  WHEN CL.CLIENT_TAX_RECIP_TYPE IN (0,3,4,5) THEN 'Corporate'
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND CL.CLIENT_BIRTH_DATE IS NULL THEN 'Unknown'
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, /*CL.MD_LOADDATE*/'2010-04-09 14:39:20'::timestamp) / 365.25) < 25 THEN 'Under 25'
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 25 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 35 THEN '25-34'
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 35 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 45 THEN '35-44'
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 45 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 55 THEN '45-54'
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 55 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 65 THEN '55-64'
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 65 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 75 THEN '65-74'
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 75 THEN 'Over 75' END AS "Age segmentation",
                                                               
		CASE  WHEN CL.CLIENT_TAX_RECIP_TYPE IN (0,3,4,5) THEN 9
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND CL.CLIENT_BIRTH_DATE IS NULL THEN 8
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, /*CL.MD_LOADDATE*/'2010-04-09 14:39:20'::timestamp) / 365.25) < 25 THEN 1
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 25 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 35 THEN 2
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 35 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 45 THEN 3
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 45 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 55 THEN 4
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 55 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 65 THEN 5
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 65 AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) < 75 THEN 6
      WHEN CL.CLIENT_TAX_RECIP_TYPE IN (1,2,6,7) AND FLOOR(DATEDIFF('day', CL.CLIENT_BIRTH_DATE, '2020-04-09 14:39:20'::timestamp) / 365.25) >= 75 THEN 7 END  AS "Age segmentation ORD",
		CL.CLIENT_BIRTH_DATE                                        AS IVR_PRIM_BDT,
        CL.CLIENT_TAX_RECIP_TYPE                                    AS CORP_CD,		
		
        CL.MD_LOADDATE                                                 AS MD_LOADDATE,

        CL.CLIENT_INIT_CONTRACT_DATE AS "Creation Date",
  CASE WHEN MONTH(CL.MD_LOADDATE)= MONTH(CL.CLIENT_INIT_CONTRACT_DATE) AND YEAR(CL.MD_LOADDATE)= YEAR(CL.CLIENT_INIT_CONTRACT_DATE) THEN 1 ELSE 0 END AS "New Client"
        
FROM (SELECT
	C.A_C_CLIENT,
	FIRST_VALUE(C.A_C_CLIENT) OVER (PARTITION BY ADR.ADR_HASH ORDER BY C.A_C_CLIENT)  A_C_HOUSEHOLD ,
	C.SIN_HASH,
	C.CLIENT_BIRTH_DATE,
	C.CLIENT_TAX_RECIP_TYPE,
	C.CLIENT_RESIDENCE,
	C.CLIENT_RESIDENCE_REGION,
	C.CLIENT_ANNUAL_GROSS_INC,
	C.CLIENT_INIT_CONTRACT_DATE,
	C.MD_LOADDATE,
	C.MD_SRCSYSTEM
FROM
	DB_IAW_DEV_STAGING.IAS.CLIENTS C 
LEFT OUTER JOIN DB_IAW_DEV_STAGING.IAS.CLIENT_ADDRESS  ADR 
ON C.A_C_CLIENT = ADR.A_C_CLIENT
) CL
LEFT JOIN DB_IAW_DEV_STAGING.FUNDEX.COUNTRY CT
ON CL.CLIENT_RESIDENCE=CT.COUNTRY_CD AND CL.MD_LOADDATE=CT.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.FUNDEX.PROVINCE PR
ON CL.CLIENT_RESIDENCE_REGION=PR.PROV_CD AND CL.MD_LOADDATE=PR.MD_LOADDATE
LEFT JOIN CI_AUA_IAS CA
ON CL.A_C_CLIENT = CA.CLIENT_ID
LEFT JOIN IAS_CLIENT_INC INC
ON CL.A_C_CLIENT = INC.A_C_CLIENT
WHERE CL.A_C_CLIENT is not NULL
AND CL.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS.CLIENTS)

UNION ALL 

/************************************************** IAS UNIVERIS ********************************************************/
SELECT 
MD_SRCSYSTEM
,CONCAT('IU_',IVR_SYSID)                                     AS ID --I for investia
,CONCAT('IU_',IVR_SYSID) 									AS HOUSEHOLD_ID
,RECIPIENT_DESC_ENG                                         AS "Client type"
,CASE   WHEN LENGTH(IVR_RES_CD)=3 THEN 'Outside Canada' 
        WHEN LENGTH(IVR_RES_CD)=2 THEN IFNULL((SELECT MAX(PROV_DESC) 
                                               FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."PROVINCE" 
                                               WHERE IVR_RES_CD=PROV_CD),'Outside Canada') 
        ELSE 'Unknown' END                                  AS "Province"
,CASE   WHEN LENGTH(IVR_RES_CD)=3 THEN (SELECT MAX(COUNTRY_DESC) 
                                        FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."COUNTRY" 
                                        WHERE IVR_RES_CD=COUNTRY_CD)  
        WHEN LENGTH(IVR_RES_CD)=2 THEN 'Canada' 
        ELSE 'Unknown' END                                  AS "Country" 
,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN '(<$30k)'
                  WHEN '$30,001 to $50,000' THEN '$30k - $50k'
                  WHEN '$50,001 to $70,000' THEN '$50k - $70k'
                  WHEN '$70,001 to $100,000' THEN '$70k - $100k'
                  WHEN '$100,001 to $200,000' THEN '$100k - $200k'
                  WHEN '$200,001 to $300,000' THEN '$200k - $300k'
                  WHEN 'Greater or Equal to $300,001' THEN '$300k+'
                  WHEN 'More or Equal to $300,001' THEN '$300k+'
              WHEN 'Unknown' THEN 'Unknown' 
              ELSE 'Unknown' END AS "Income Segmentation"
                  
,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 1
                  WHEN '$30,001 to $50,000' THEN 2
                  WHEN '$50,001 to $70,000' THEN 3
                  WHEN '$70,001 to $100,000' THEN 4
                  WHEN '$100,001 to $200,000' THEN 5
                  WHEN '$200,001 to $300,000' THEN 6
                  WHEN 'Greater or Equal to $300,001' THEN 7
                  WHEN 'More or Equal to $300,001' THEN 7
                  WHEN 'Unknown' THEN 8 END 				AS "Income Seg ORD"

,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 'Lower Income'
                  WHEN '$30,001 to $50,000' THEN 'Middle Income'
                  WHEN '$50,001 to $70,000' THEN 'Middle Income'
                  WHEN '$70,001 to $100,000' THEN 'Upper Income'
                  WHEN '$100,001 to $200,000' THEN 'Upper Income'
                  WHEN '$200,001 to $300,000' THEN 'High Income'
                  WHEN 'Greater or Equal to $300,001' THEN 'High Income'
                  WHEN 'More or Equal to $300,001' THEN 'High Income'
                  WHEN 'Unknown' THEN 'Unknown' 
                  ELSE 'Unknown' END AS "Salary"

,CASE SALARY_DESC WHEN 'Less or Equal to $30,000' THEN 1
                  WHEN '$30,001 to $50,000' THEN 2
                  WHEN '$50,001 to $70,000' THEN 2
                  WHEN '$70,001 to $100,000' THEN 3
                  WHEN '$100,001 to $200,000' THEN 3
                  WHEN '$200,001 to $300,000' THEN 4
                  WHEN 'Greater or Equal to $300,001' THEN 4
                  WHEN 'More or Equal to $300,001' THEN 4
                  WHEN 'Unknown' THEN 5 END AS 				"Salary ORD"
 ,CASE WHEN CA.SUM_AUA < 25000 THEN '<25k'
	WHEN CA.SUM_AUA>=25000
	AND CA.SUM_AUA <= 100000 THEN '25k-100k'
	WHEN CA.SUM_AUA>100000
	AND CA.SUM_AUA <= 250000 THEN '100k-250k'
	WHEN CA.SUM_AUA>250000
	AND CA.SUM_AUA <= 500000 THEN '250k-500k'
	WHEN CA.SUM_AUA>500000 THEN '> 500k'
END 														AS "Client AUA segment",

CASE WHEN CA.SUM_AUA < 25000 THEN 1
	WHEN CA.SUM_AUA>=25000
	AND CA.SUM_AUA <= 100000 THEN 2
	WHEN CA.SUM_AUA>100000
	AND CA.SUM_AUA <= 250000 THEN 3
	WHEN CA.SUM_AUA>250000
	AND CA.SUM_AUA <= 500000 THEN 4
	WHEN CA.SUM_AUA>500000 THEN 5
END 														AS "Advisor AUA segment order",

  CASE WHEN C.CORP_CD='C' THEN 'Corporate'
       WHEN C.IVR_PRIM_BDT IS NULL AND C.CORP_CD IS NULL THEN 'Unknown'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 25 THEN 'Under 25'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 25 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 35 THEN '25-34'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 35 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 45 THEN '35-44'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 45 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 55 THEN '45-54'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 55 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 65 THEN '55-64'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 65 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 75 THEN '65-74'
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 75 THEN 'Over 75' END AS "Age segmentation",
       
  
   CASE WHEN C.CORP_CD='C' THEN 9
       WHEN C.IVR_PRIM_BDT IS NULL AND C.CORP_CD IS NULL THEN 8
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 25 THEN 1
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 25 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 35 THEN 2
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 35 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 45 THEN 3
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 45 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 55 THEN 4
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 55 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 65 THEN 5
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 65 AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) < 75 THEN 6
      WHEN C.CORP_CD IS NULL AND C.IVR_PRIM_BDT IS NOT NULL AND FLOOR(DATEDIFF('day', C.IVR_PRIM_BDT, C.MD_LOADDATE) / 365.25) >= 75 THEN 7 END AS "Age segmentation ORD",
       
      
      
       C.IVR_PRIM_BDT,
       C.CORP_CD,

  C.MD_LOADDATE,
   C.CREATE_DT AS "Creation Date",
  CASE WHEN MONTH(C.MD_LOADDATE)= MONTH(C.CREATE_DT) AND YEAR(C.MD_LOADDATE)= YEAR(C.CREATE_DT) THEN 1 ELSE 0 END AS "New Client"

FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."CLIENTS" C
LEFT JOIN CI_AUA_IAS_UNIVERIS CA
ON C.IVR_SYSID = CA.CLIENT_ID
WHERE C.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."CLIENTS")

UNION ALL

/************************************************** DEFAULT VALUES **************************************************/
SELECT 
       'N/D'                                                AS MD_SRCSYSTEM,
       '-1'                                                 AS ID,
       '-1'													AS HOUSEHOLD_ID,
       NULL                                                 AS "Client type",
     --  NULL                                                 AS "Client status",
     --  NULL                                                 AS "Client language code",
     --  NULL                                                 AS "Client setup date",
     --  NULL                                                 AS "Client stop date",
       NULL                                                 AS "Country",
       NULL                                                 AS "Province",
       'Unknown'											AS "Income Segmentation",
       8                                                    AS "Income Seg ORD",
       'Unknown'                                            AS "Salary",
       5                                                    AS "Salary ORD",
       NULL													AS "Client AUA segment",
       NULL													AS "Advisor AUA segment order",
       NULL                                                 AS "Age segmentation",
       NULL                                                 AS "Age segmentation ORD",
       NULL                                                 AS IVR_PRIM_BDT,
       NULL                                                 AS CORP_CD,		
	   NULL                                                 AS MD_LOADDATE,
	   NULL                                                 AS "Creation Date",
       NULL                                                 AS "New Client";
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_CLIENTS_ACCESS(
	MD_SRCSYSTEM,
	ID,
	"Client type",
	"Province",
	"Country",
	"Income Segmentation",
	"Income Seg ORD",
	"Salary",
	"Salary ORD",
	"Client AUA segment",
	"Advisor AUA segment order",
	"Age segmentation",
	"Age segmentation ORD",
	IVR_PRIM_BDT,
	CORP_CD
) as 

SELECT R.MD_SRCSYSTEM, ID, "Client type", "Province", "Country", "Income Segmentation", "Income Seg ORD", "Salary", "Salary ORD", "Client AUA segment", "Advisor AUA segment order", "Age segmentation", "Age segmentation ORD", IVR_PRIM_BDT, CORP_CD
FROM DB_IAW_DEV_DATAMART."SHARED".VW_DIM_CLIENTS R
INNER JOIN DB_IAW_DEV_DATAMART.BR.DIM_USER U
ON U."User Login"= CURRENT_USER()  AND  (R.MD_SRCSYSTEM=U."Capacity" OR U."Capacity" ='ALL');
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_MARKETPRODUCTS(
	MD_SRCSYSTEM,
	ID,
	"Symbol",
	"Name",
	"Asset category",
	"Category",
	"Group",
	"Issuer company code",
	"Issuer company name",
	MD_LOADDATE
) as

-------------MFDA MERGE--------------------------------------
WITH PRODUCTS_MERGED
AS(
WITH PRODUCTS_SYMBOLS
AS(
SELECT DISTINCT FUNDSERVID AS SYMBOL
FROM DB_IAW_DEV_STAGING.FUNDATA.FUND
UNION
SELECT DISTINCT SYMBOL
FROM "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS"
UNION
SELECT DISTINCT SYMBOL
FROM "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS"
UNION
SELECT DISTINCT SYMBOL
FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS"
UNION
SELECT DISTINCT TI_SYMBOL
FROM "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS"
)
SELECT --* 
DISTINCT
PM.SYMBOL,  coalesce(F.FUNDDESCEN ,I.IVT_NAME_ENG,FX.IVT_NAME_ENG,IAS_UNIV.IVT_NAME_ENG, IAS.ENGLISH_DESCRIPTION) AS "Product Name",
            coalesce(F.GROUPNAMEEN,I.MGT_NAME_ENG, FX.MGT_NAME_ENG, IAS_UNIV.MGT_NAME_ENG) AS "Issuer name"
FROM PRODUCTS_SYMBOLS PM LEFT JOIN DB_IAW_DEV_STAGING.FUNDATA.FUND F ON PM.SYMBOL = F.FUNDSERVID
                    -- LEFT JOIN (SELECT SYMBOL,MAX(IVT_NAME_ENG) AS IVT_NAME_ENG, MAX(MGT_NAME_ENG) AS MGT_NAME_ENG FROM "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS" GROUP BY SYMBOL) I ON PM.SYMBOL = I.SYMBOL
                    -- LEFT JOIN (SELECT SYMBOL,MAX(IVT_NAME_ENG) AS IVT_NAME_ENG, MAX(MGT_NAME_ENG) AS MGT_NAME_ENG FROM "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS" GROUP BY SYMBOL) FX ON PM.SYMBOL = FX.SYMBOL
                    -- LEFT JOIN (SELECT SYMBOL,MAX(IVT_NAME_ENG) AS IVT_NAME_ENG, MAX(MGT_NAME_ENG) AS MGT_NAME_ENG FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS" GROUP BY SYMBOL) IAS_UNIV ON PM.SYMBOL = IAS_UNIV.SYMBOL
                    -- LEFT JOIN (SELECT TI_SYMBOL,MAX(ENGLISH_DESCRIPTION) AS ENGLISH_DESCRIPTION FROM "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS" GROUP BY TI_SYMBOL) IAS ON PM.SYMBOL = IAS.TI_SYMBOL --ceci parceque 2 produits differents peuvent avoir le meme symbol(duplication)
                     
                     LEFT JOIN  "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS" I ON PM.SYMBOL = I.SYMBOL
                     LEFT JOIN  "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS" FX ON PM.SYMBOL = FX.SYMBOL
                     LEFT JOIN  "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS" IAS_UNIV ON PM.SYMBOL = IAS_UNIV.SYMBOL
                     LEFT JOIN  "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS" IAS ON PM.SYMBOL = IAS.TI_SYMBOL
),

DIM_MP AS 
(
/************************************************** INVESTIA ********************************************************/
    select
        MD_SRCSYSTEM,
        CONCAT('I_',IVD_SYSID)                                                          AS ID, --I for investia
        --CURRENCY_CD                                                                     AS "Currency code",
        SYMBOL                                                                          AS "Symbol",
        --IVD_ST_DESC_ENG                                                                 AS "Market product status",
        --IVD_LOAD_DESC_ENG                                                               AS "Load description",
        IVT_NAME_ENG                                                                    AS "Name",
        --IVT_CD_DESC_ENG                                                                 AS "Code",
        --ASSET_CLASS_DESC_ENG                                                            AS "Asset class",
        ASSET_CTGY_DESC_ENG                                                             AS "Asset category",      
        --IVT_TYPE_DESC_ENG                                                               AS "Type",
        CASE WHEN (CTGY_DESC_ENG='Mutual Funds' OR CTGY_DESC_ENG='Mutual Fund') THEN 'Mutual Funds' ELSE CTGY_DESC_ENG END   AS "Category",
        GROUP_DESC_ENG                                                                  AS "Group",
        MGT_CD                                                                          AS "Issuer company code",
        MGT_NAME_ENG                                                                    AS "Issuer company name",
        MD_LOADDATE
        
    From "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS"
    WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS" )
    
UNION ALL

/************************************************** FUNDEX ********************************************************/
    select
        MD_SRCSYSTEM,
        CONCAT('F_',IVD_SYSID)                                                          AS ID, --F for fundex
        --CURRENCY_CD                                                                     AS "Currency code",
        SYMBOL                                                                          AS "Symbol",
        --IVD_ST_DESC_ENG                                                                 AS "Market product status",
        --IVD_LOAD_DESC_ENG                                                               AS "Load description",
        IVT_NAME_ENG                                                                    AS "Name",
        --IVT_CD_DESC_ENG                                                                 AS "Code",
        --ASSET_CLASS_DESC_ENG                                                            AS "Asset class",
        ASSET_CTGY_DESC_ENG                                                             AS "Asset category",      
        --IVT_TYPE_DESC_ENG                                                               AS "Type",
        CASE WHEN (CTGY_DESC_ENG='Mutual Funds' OR CTGY_DESC_ENG='Mutual Fund') THEN 'Mutual Funds' ELSE CTGY_DESC_ENG END   AS "Category",
        GROUP_DESC_ENG                                                                  AS "Group", 
        MGT_CD                                                                          AS "Issuer company code",
        MGT_NAME_ENG                                                                    AS "Issuer company name",
        MD_LOADDATE
    From "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS"
    WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS" )
    
UNION ALL

/************************************************** IAS UNIVERIS ********************************************************/
    select
        MD_SRCSYSTEM,
        CONCAT('IU_',IVD_SYSID)                                                          AS ID, 
        SYMBOL                                                                          AS "Symbol",
        IVT_NAME_ENG                                                                    AS "Name",
        ASSET_CTGY_DESC_ENG                                                             AS "Asset category",      
        CASE WHEN (CTGY_DESC_ENG='Mutual Funds' OR CTGY_DESC_ENG='Mutual Fund') THEN 'Mutual Funds' ELSE CTGY_DESC_ENG END   AS "Category",
        GROUP_DESC_ENG                                                                  AS "Group",
        MGT_CD                                                                          AS "Issuer company code",
        MGT_NAME_ENG                                                                    AS "Issuer company name",
        MD_LOADDATE
        
    From "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS"
    WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS" )
    
UNION ALL

/************************************************** IAS ********************************************************/
   Select
        'IAS'                                                                           AS MD_SRCSYSTEM,
        TI_ALTERNATE_ID                                                                 AS ID,
        --NULL                                                                            AS "Currency code",
        TI_SYMBOL                                                                            AS "Symbol",
        --NULL                                                                            AS "Market product status",
        --NULL                                                                            AS "Load description",
        ENGLISH_DESCRIPTION                                                             AS "Name",
        --NULL                                                                            AS "Code",
        --TI_CLASS                                                                        AS "Asset class",
        PAC.ASSET_CATEGORY                                                              AS "Asset category",
        --TI_TYPE                                                                         AS "Type",
        CASE WHEN (PT.DescriptionEn='Mutual Funds' OR PT.DescriptionEn='Mutual Fund') THEN 'Mutual Funds' ELSE PT.DescriptionEn END   AS "Category",
        PT.DescriptionEn                                                                AS "Group",
        NULL                                                                            AS "Issuer company code",
        NULL                                                                            AS "Issuer company name",
        NULL                                                                            AS  MD_LOADDATE

from "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS" IAS
LEFT JOIN BR.IAS_PRODUCT_TYPE PT 
ON IAS.TI_ALTERNATE_TI_TYPE = PT.TI_ALTERNATE_TI_TYPE AND IAS.TI_Alternate_TI_Class = PT.TI_Alternate_TI_Class
LEFT JOIN BR.IAS_PRODUCT_ASSETCATEGORY PAC
ON IAS.TI_ALTERNATE_TI_TYPE = PAC.TI_ALTERNATE_TI_TYPE

WHERE IAS.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS" )

UNION ALL 

 Select
        'IAS'                                                                           AS MD_SRCSYSTEM,
        ''                                                                              AS ID,
       -- NULL                                                                            AS "Currency code",
        NULL                                                                            AS "Symbol",
       -- NULL                                                                            AS "Market product status",
       -- NULL                                                                            AS "Load description",
        NULL /*'Cash Management Account'   */                                                    AS "Name",
       -- NULL                                                                            AS "Code",
        --'Cash Management Account'                                                       AS "Asset class",
        'Cash Management Account'                                                       AS "Asset category",
        --'Cash Management Account'                                                       AS "Type",
        'Cash Management Account'                                                       AS "Category",
        'Cash Management Account'                                                       AS "Group",
        NULL                                                                            AS "Issuer company code",
        NULL                                                                            AS "Issuer company name",
        NULL                                                                            AS  MD_LOADDATE
)

SELECT 

DMP.MD_SRCSYSTEM,
DMP.ID,
DMP."Symbol",
P_MERGE."Product Name" AS "Name",
DMP."Asset category",      
DMP."Category",
DMP."Group",
DMP."Issuer company code",
P_MERGE."Issuer name" AS "Issuer company name",
DMP.MD_LOADDATE


FROM DIM_MP DMP 
LEFT JOIN PRODUCTS_MERGED P_MERGE
ON DMP."Symbol" = P_MERGE.SYMBOL;
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_MARKETPRODUCTS2(
	MD_SRCSYSTEM,
	ID,
	"Symbol",
	"Name",
	"Asset category",
	"Category",
	"Group",
	"Issuer company code",
	"Issuer company name",
	MD_LOADDATE
) as

-------------MFDA MERGE--------------------------------------
WITH PRODUCTS_MERGED
AS(
WITH PRODUCTS_SYMBOLS
AS(
SELECT DISTINCT FUNDSERVID AS SYMBOL
FROM DB_IAW_DEV_STAGING.FUNDATA.FUND
UNION
SELECT DISTINCT SYMBOL
FROM "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS"
UNION
SELECT DISTINCT SYMBOL
FROM "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS"
UNION
SELECT DISTINCT SYMBOL
FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS"
UNION
SELECT DISTINCT TI_SYMBOL
FROM "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS"
)
SELECT --* 
DISTINCT
PM.SYMBOL,  --coalesce(F.FUNDDESCEN ,I.IVT_NAME_ENG,FX.IVT_NAME_ENG,IAS_UNIV.IVT_NAME_ENG, IAS.ENGLISH_DESCRIPTION) AS "Product Name",
            coalesce(F.GROUPNAMEEN,I.MGT_NAME_ENG, FX.MGT_NAME_ENG, IAS_UNIV.MGT_NAME_ENG) AS "Issuer name"
FROM PRODUCTS_SYMBOLS PM LEFT JOIN DB_IAW_DEV_STAGING.FUNDATA.FUND F ON PM.SYMBOL = F.FUNDSERVID
                     LEFT JOIN  "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS" I ON PM.SYMBOL = I.SYMBOL
                     LEFT JOIN  "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS" FX ON PM.SYMBOL = FX.SYMBOL
                     LEFT JOIN  "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS" IAS_UNIV ON PM.SYMBOL = IAS_UNIV.SYMBOL
                     LEFT JOIN  "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS" IAS ON PM.SYMBOL = IAS.TI_SYMBOL --ceci parceque 2 produits differents peuvent avoir le meme symbol(duplication)
),

DIM_MP AS 
(
/************************************************** INVESTIA ********************************************************/
    select
        MD_SRCSYSTEM,
        CONCAT('I_',IVD_SYSID)                                                          AS ID, --I for investia
        --CURRENCY_CD                                                                     AS "Currency code",
        SYMBOL                                                                          AS "Symbol",
        --IVD_ST_DESC_ENG                                                                 AS "Market product status",
        --IVD_LOAD_DESC_ENG                                                               AS "Load description",
        IVT_NAME_ENG                                                                    AS "Name",
        --IVT_CD_DESC_ENG                                                                 AS "Code",
        --ASSET_CLASS_DESC_ENG                                                            AS "Asset class",
        ASSET_CTGY_DESC_ENG                                                             AS "Asset category",      
        --IVT_TYPE_DESC_ENG                                                               AS "Type",
        CASE WHEN (CTGY_DESC_ENG='Mutual Funds' OR CTGY_DESC_ENG='Mutual Fund') THEN 'Mutual Funds' ELSE CTGY_DESC_ENG END   AS "Category",
        GROUP_DESC_ENG                                                                  AS "Group",
        MGT_CD                                                                          AS "Issuer company code",
        MGT_NAME_ENG                                                                    AS "Issuer company name",
        MD_LOADDATE
        
    From "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS"
    WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."INVESTIA"."MARKETPRODUCTS" )
    
UNION ALL

/************************************************** FUNDEX ********************************************************/
    select
        MD_SRCSYSTEM,
        CONCAT('F_',IVD_SYSID)                                                          AS ID, --F for fundex
        --CURRENCY_CD                                                                     AS "Currency code",
        SYMBOL                                                                          AS "Symbol",
        --IVD_ST_DESC_ENG                                                                 AS "Market product status",
        --IVD_LOAD_DESC_ENG                                                               AS "Load description",
        IVT_NAME_ENG                                                                    AS "Name",
        --IVT_CD_DESC_ENG                                                                 AS "Code",
        --ASSET_CLASS_DESC_ENG                                                            AS "Asset class",
        ASSET_CTGY_DESC_ENG                                                             AS "Asset category",      
        --IVT_TYPE_DESC_ENG                                                               AS "Type",
        CASE WHEN (CTGY_DESC_ENG='Mutual Funds' OR CTGY_DESC_ENG='Mutual Fund') THEN 'Mutual Funds' ELSE CTGY_DESC_ENG END   AS "Category",
        GROUP_DESC_ENG                                                                  AS "Group", 
        MGT_CD                                                                          AS "Issuer company code",
        MGT_NAME_ENG                                                                    AS "Issuer company name",
        MD_LOADDATE
    From "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS"
    WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."FUNDEX"."MARKETPRODUCTS" )
    
UNION ALL

/************************************************** IAS UNIVERIS ********************************************************/
    select
        MD_SRCSYSTEM,
        CONCAT('IU_',IVD_SYSID)                                                          AS ID, 
        SYMBOL                                                                          AS "Symbol",
        IVT_NAME_ENG                                                                    AS "Name",
        ASSET_CTGY_DESC_ENG                                                             AS "Asset category",      
        CASE WHEN (CTGY_DESC_ENG='Mutual Funds' OR CTGY_DESC_ENG='Mutual Fund') THEN 'Mutual Funds' ELSE CTGY_DESC_ENG END   AS "Category",
        GROUP_DESC_ENG                                                                  AS "Group",
        MGT_CD                                                                          AS "Issuer company code",
        MGT_NAME_ENG                                                                    AS "Issuer company name",
        MD_LOADDATE
        
    From "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS"
    WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."IAS_UNIVERIS"."MARKETPRODUCTS" )
    
UNION ALL

/************************************************** IAS ********************************************************/
   Select
        'IAS'                                                                           AS MD_SRCSYSTEM,
        TI_ALTERNATE_ID                                                                 AS ID,
        --NULL                                                                            AS "Currency code",
        TI_SYMBOL                                                                            AS "Symbol",
        --NULL                                                                            AS "Market product status",
        --NULL                                                                            AS "Load description",
        ENGLISH_DESCRIPTION                                                             AS "Name",
        --NULL                                                                            AS "Code",
        --TI_CLASS                                                                        AS "Asset class",
        PAC.ASSET_CATEGORY                                                              AS "Asset category",
        --TI_TYPE                                                                         AS "Type",
        CASE WHEN (PT.DescriptionEn='Mutual Funds' OR PT.DescriptionEn='Mutual Fund') THEN 'Mutual Funds' ELSE PT.DescriptionEn END   AS "Category",
        PT.DescriptionEn                                                                AS "Group",
        NULL                                                                            AS "Issuer company code",
        NULL                                                                            AS "Issuer company name",
        NULL                                                                            AS  MD_LOADDATE

from "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS" IAS
LEFT JOIN BR.IAS_PRODUCT_TYPE PT 
ON IAS.TI_ALTERNATE_TI_TYPE = PT.TI_ALTERNATE_TI_TYPE AND IAS.TI_Alternate_TI_Class = PT.TI_Alternate_TI_Class
LEFT JOIN BR.IAS_PRODUCT_ASSETCATEGORY PAC
ON IAS.TI_ALTERNATE_TI_TYPE = PAC.TI_ALTERNATE_TI_TYPE

WHERE IAS.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."IAS"."MARKETPRODUCTS" )

UNION ALL 

 Select
        'IAS'                                                                           AS MD_SRCSYSTEM,
        ''                                                                              AS ID,
       -- NULL                                                                            AS "Currency code",
        NULL                                                                            AS "Symbol",
       -- NULL                                                                            AS "Market product status",
       -- NULL                                                                            AS "Load description",
        NULL /*'Cash Management Account'   */                                                    AS "Name",
       -- NULL                                                                            AS "Code",
        --'Cash Management Account'                                                       AS "Asset class",
        'Cash Management Account'                                                       AS "Asset category",
        --'Cash Management Account'                                                       AS "Type",
        'Cash Management Account'                                                       AS "Category",
        'Cash Management Account'                                                       AS "Group",
        NULL                                                                            AS "Issuer company code",
        NULL                                                                            AS "Issuer company name",
        NULL                                                                            AS  MD_LOADDATE
)

SELECT 

DMP.MD_SRCSYSTEM,
DMP.ID,
DMP."Symbol",
DMP."Name",
DMP."Asset category",      
DMP."Category",
DMP."Group",
DMP."Issuer company code",
P_MERGE."Issuer name" AS "Issuer company name",
DMP.MD_LOADDATE


FROM DIM_MP DMP 
LEFT JOIN PRODUCTS_MERGED P_MERGE
ON DMP."Symbol" = P_MERGE.SYMBOL;
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_MARKETPRODUCTS_ACCESS(
	MD_SRCSYSTEM,
	ID,
	"Name",
	"Asset category",
	"Category",
	"Group",
	"Issuer company code",
	"Issuer company name"
) as 

SELECT R.MD_SRCSYSTEM, ID, "Name", "Asset category", "Category", "Group", "Issuer company code", "Issuer company name"
FROM DB_IAW_DEV_DATAMART."SHARED".DIM_MARKETPRODUCTS R
INNER JOIN DB_IAW_DEV_DATAMART.BR.DIM_USER U
ON U."User Login"= CURRENT_USER()  AND  (R.MD_SRCSYSTEM=U."Capacity" OR U."Capacity" ='ALL');
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_PLANS(
	MD_SRCSYSTEM,
	ID,
	"Plan code",
	"Plan label",
	"Account type",
	"Group type code",
	"Accumulation type",
	MD_LOADDATE
) as

/************************************************** INVESTIA & FUNDEX ********************************************************/
SELECT 

CASE    WHEN IP.PLN_CD IS NOT NULL AND FP.PLN_CD IS NOT NULL THEN 'INVESTIA & FUNDEX'  
        WHEN IP.PLN_CD IS NOT NULL AND FP.PLN_CD IS NULL THEN 'INVESTIA' 
        WHEN IP.PLN_CD IS NULL AND FP.PLN_CD IS NOT NULL THEN 'FUNDEX' 
        END                                                                             AS MD_SRCSYSTEM,
IFNULL(IP.PLN_MNEM,FP.PLN_MNEM)                                                         AS ID,
IFNULL(IP.PLN_MNEM,FP.PLN_MNEM)                                                         AS "Plan code",
IFNULL(IP.PLN_DESC,FP.PLN_DESC)                                                         AS "Plan label",
IFNULL(CASE WHEN IP.PLN_REG=0 THEN 'Non registered' 
       ELSE 'Registered' END, 
       CASE WHEN FP.PLN_REG=0 THEN 'Non registered' 
       ELSE 'Registered' END)                                                           AS "Account type",
IFNULL(IP.STMT_GROUP_MNEM,FP.STMT_GROUP_MNEM)                                           AS "Group type code",

'N/A'                                                                                   AS "Accumulation type",

IFNULL(IP.MD_LOADDATE, FP.MD_LOADDATE)                                                  AS MD_LOADDATE

from (SELECT * FROM "DB_IAW_DEV_STG".INVESTIA.PLANS WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STG".INVESTIA.PLANS)) IP
-- To fix
FULL JOIN (SELECT * FROM "DB_IAW_DEV_STG".FUNDEX.PLANS WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STG".FUNDEX.PLANS)) FP
ON IP.PLN_MNEM=FP.PLN_MNEM

UNION ALL

/************************************************** IAS ********************************************************/
SELECT DISTINCT
'IAS'                                                                                   AS MD_SRCSYSTEM,
--CONCAT(IFNULL(P.ACCOUNT_RAP_CODE,''),'_',IFNULL(P.RETAIL_PLAN,''))                      AS ID,
--CONCAT(IFNULL(P.ACCOUNT_RAP_CODE,''),'_',IFNULL(P.RETAIL_PLAN,''))                      AS "Plan code",
CASE WHEN P.ACCOUNT_RAP_CODE='Z' AND RP.ASC_1_RESP_Plan_Types IS NULL THEN CONCAT(IFNULL(P.ACCOUNT_RAP_CODE,''),'_',IFNULL(P.RETAIL_PLAN,''), '_', '0') WHEN P.ACCOUNT_RAP_CODE='Z' AND RP.ASC_1_RESP_Plan_Types IS NOT NULL THEN  CONCAT(IFNULL(P.ACCOUNT_RAP_CODE,''),'_',IFNULL(P.RETAIL_PLAN,''), '_', IFNULL(RP.ASC_1_RESP_Plan_Types, ''))  else CONCAT(IFNULL(P.ACCOUNT_RAP_CODE,''),'_',IFNULL(P.RETAIL_PLAN,'')) END AS ID,
CASE WHEN P.ACCOUNT_RAP_CODE='Z' AND RP.ASC_1_RESP_Plan_Types IS NULL THEN CONCAT(IFNULL(P.ACCOUNT_RAP_CODE,''),'_',IFNULL(P.RETAIL_PLAN,''), '_', '0') WHEN P.ACCOUNT_RAP_CODE='Z' AND RP.ASC_1_RESP_Plan_Types IS NOT NULL THEN  CONCAT(IFNULL(P.ACCOUNT_RAP_CODE,''),'_',IFNULL(P.RETAIL_PLAN,''), '_', IFNULL(RP.ASC_1_RESP_Plan_Types, ''))  else CONCAT(IFNULL(P.ACCOUNT_RAP_CODE,''),'_',IFNULL(P.RETAIL_PLAN,'')) END AS "Plan code",
IFNULL(RP.PLAN_LABEL, 'N/A')                                                            AS "Plan label",
CASE WHEN IFNULL(RP.ACCOUNT_TYPE, 'N/A') = 'Non-Registered'
THEN 'Non registered' END                                                               AS "Account type",
IFNULL(RP.GROUP_TYPE_CODE, 'N/A')                                                       AS "Group type code",
RP.ACCUMULATION_TYPE                                                                    AS "Accumulation type",
NULL                                                                                    AS MD_LOADDATE

      
FROM
DB_IAW_DEV_STG.IAS.PLANS P
LEFT JOIN BR.IAS_RAPCODE_PLAN RP
ON (P.ACCOUNT_RAP_CODE = RP.ACCOUNT_RAP_CODE AND P.ACCOUNT_RAP_CODE <> 'P') OR (P.ACCOUNT_RAP_CODE = 'P' AND RP.ACCOUNT_RAP_CODE = 'P' AND P.RETAIL_PLAN = RP.RETAIL_PLAN) 
WHERE P.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS.PLANS)

UNION ALL
/******************* IAS UNIVERIS ****************************************/
SELECT 
MD_SRCSYSTEM,
IP.PLN_MNEM                                                         AS ID,
IP.PLN_MNEM                                                         AS "Plan code",
IP.PLN_DESC                                                         AS "Plan label",
CASE WHEN IP.PLN_REG=0 THEN 'Non registered' 
     ELSE 'Registered' END                                          AS "Account type",
IP.STMT_GROUP_MNEM		                                            AS "Group type code",
'N/A'                                                               AS "Accumulation type",
IP.MD_LOADDATE	                                                    AS MD_LOADDATE
from "DB_IAW_DEV_STG".IAS_UNIVERIS.PLANS IP
WHERE IP.PLN_MNEM NOT IN (SELECT DISTINCT PLN_MNEM FROM "DB_IAW_DEV_STAGING".FUNDEX.PLANS UNION SELECT DISTINCT PLN_MNEM FROM "DB_IAW_DEV_STAGING".INVESTIA.PLANS ) 
AND IP.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".IAS_UNIVERIS.PLANS)
/********************************************************************************************************************/

UNION ALL

SELECT 
'N/D'   AS MD_SRCSYSTEM,
'-1'   AS ID,
'-1'   AS "Plan code",
'Unknown'        AS "Plan label",
'Unknown'        AS "Account type",
'Unknown'        AS "Group type code",
NULL            AS "Accumulation type",
NULL             AS MD_LOADDATE

;
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_PLANS_ACCESS(
	MD_SRCSYSTEM,
	ID,
	"Plan code",
	"Plan label",
	"Account type",
	"Group type code",
	"Accumulation type"
) as 

SELECT R.MD_SRCSYSTEM, ID, "Plan code", "Plan label", "Account type", "Group type code", "Accumulation type"
FROM DB_IAW_DEV_DATAMART."SHARED".DIM_PLANS R
INNER JOIN DB_IAW_DEV_DATAMART.BR.DIM_USER U
ON U."User Login"= CURRENT_USER()  AND  (R.MD_SRCSYSTEM=U."Capacity" OR U."Capacity" ='ALL');
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_REGISTERED_REPRESENTATIVES(
	MD_SRCSYSTEM,
	ID,
	"Company code",
	"Company name",
	"Regulatory organization code",
	"Regulatory organization name",
	"Dealer code",
	"Dealer name",
	"Region code",
	"Region name",
	"Region VP",
	"Branch code",
	"Branch name",
	"Team code",
	"Team name",
	"RR fullname",
	"RR code",
	"Last name",
	"First name",
	"RR corporation name",
	"Status",
	"Group RSP indicator",
	MD_LOADDATE
) as 

/************************************************** INVESTIA ********************************************************/
select 
    'INVESTIA'                                                          AS MD_SRCSYSTEM,
	CONCAT('I_',REP_SYSID)                                              AS ID, --I for investia
    COMPANY_CD                                                          AS "Company code",
	COMPANY_NAME                                                        AS "Company name",
	REGULATORY_ORG_CD                                                   AS "Regulatory organization code",
	REGULATORY_ORG_NAME                                                 AS "Regulatory organization name",
	DLR_CD                                                              AS "Dealer code",
	DLR_NAME_ENG                                                        AS "Dealer name",
	RGN_CD                                                              AS "Region code",
	RGN_NAME                                                            AS "Region name",
    RGN_MGR                                                             AS "Region VP",
	BRN_CD                                                              AS "Branch code",
	BRN_NAME                                                            AS "Branch name",
	REP_TEAM_CD                                                         AS "Team code",
	REP_TEAM_NAME                                                       AS "Team name",
    /*Business rule ADVISORS.001*/
    REP_LNAME || ', ' || REP_FNAME || ' (' || NK_REP_CD || ')'          AS "RR fullname",
	NK_REP_CD                                                           AS "RR code",
	REP_LNAME                                                           AS "Last name",
	REP_FNAME                                                           AS "First name",
	NK_REP_CORP_NAME                                                    AS "RR corporation name",
	REP_ST_NAME                                                         AS "Status",
	REP_GRP_RSP                                                         AS "Group RSP indicator",
	MD_LOADDATE                                                        
    
    from "DB_IAW_DEV_STAGING".INVESTIA.REGISTERED_REPRESENTATIVE
    /*Business rule ADVISORS.002*/
    Where  NK_REP_CD not in ('610X','611X') 
    --AND REP_ST_NAME in ('Active','Suspended') 
    AND MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".INVESTIA.REGISTERED_REPRESENTATIVE )
    
UNION ALL

/************************************************** FUNDEX ********************************************************/
select 
    'FUNDEX'                                                            AS MD_SRCSYSTEM,
    CONCAT('F_',REP_SYSID)                                              AS ID, --F for fundex
	COMPANY_CD                                                          AS "Company code",
	COMPANY_NAME                                                        AS "Company name",
	REGULATORY_ORG_CD                                                   AS "Regulatory organization code",
	REGULATORY_ORG_NAME                                                 AS "Regulatory organization name",
	DLR_CD                                                              AS "Dealer code",
	DLR_NAME_ENG                                                        AS "Dealer name",
	RGN_CD                                                              AS "Region code",
	RGN_NAME                                                            AS "Region name",
    RGN_MGR                                                             AS "Region VP",
	BRN_CD                                                              AS "Branch code",
	BRN_NAME                                                            AS "Branch name",
	REP_TEAM_CD                                                         AS "Team code",
	REP_TEAM_NAME                                                       AS "Team name",
    /*Business rule ADVISORS.001*/
    REP_LNAME || ', ' || REP_FNAME || ' (' || NK_REP_CD || ')'          AS "RR fullname",
	NK_REP_CD                                                           AS "RR code",
	REP_LNAME                                                           AS "Last name",
	REP_FNAME                                                           AS "First name",
	NK_REP_CORP_NAME                                                    AS "RR corporation name",
	REP_ST_NAME                                                         AS "Status",
	REP_GRP_RSP                                                         AS "Group RSP indicator",
	MD_LOADDATE                                                         
    from "DB_IAW_DEV_STAGING".FUNDEX.REGISTERED_REPRESENTATIVE
    /*ADVISORS.002*/
    --Where REP_ST_NAME in ('Active')
    WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING".FUNDEX.REGISTERED_REPRESENTATIVE )
   
   
   UNION ALL

/************************************************** IAS ********************************************************/
select 
    'IAS'                                                               AS MD_SRCSYSTEM,
    /*CONCAT('F_',REP_SYSID)*/ NULL                                     AS ID, 
	NULL                                                          AS "Company code",
	NULL                                                        AS "Company name",
	'IIROC'                                                      AS "Regulatory organization code",
	'IIROC'                                                 AS "Regulatory organization name",
	'iA Securities'                                                              AS "Dealer code",
	'iA Securities'                                                        AS "Dealer name",
	NULL                                                              AS "Region code",
	NULL                                                            AS "Region name",
    "Region VP"                                                             AS "Region VP",
	"Branch Code"                                                              AS "Branch code",
	"Branch Name"                                                            AS "Branch name",
	NULL                                                         AS "Team code",
	NULL                                                                AS "Team name",
    /*Business rule ADVISORS.001*/
    "Full Name"                                                         AS "RR fullname",
	"RR code"                                                           AS "RR code",
	"Last Name"                                                           AS "Last name",
	"First Name"                                                           AS "First name",
	"Trade Name"                                                    AS "RR corporation name",
	"Status"                                                         AS "Status",
	NULL                                                         AS "Group RSP indicator",
	NULL                                                         AS MD_LOADDATE
    from "DB_IAW_DEV_STAGING"."IAS_CERTS"."REGISTERED_REPRESENTATIVE"
    WHERE MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM "DB_IAW_DEV_STAGING"."IAS_CERTS"."REGISTERED_REPRESENTATIVE" );
create or replace view DB_IAW_DEV_DM.SHARED_BKP.VW_DIM_REGISTERED_REPRESENTATIVES_ACCESS(
	MD_SRCSYSTEM,
	ID,
	"Company code",
	"Company name",
	"Regulatory organization code",
	"Regulatory organization name",
	"Dealer code",
	"Dealer name",
	"Region code",
	"Region name",
	"Region VP",
	"Branch code",
	"Branch name",
	"Team code",
	"Team name",
	"RR fullname",
	"RR code",
	"Last name",
	"First name",
	"RR corporation name",
	"Status",
	"Group RSP indicator"
) as 
SELECT R.MD_SRCSYSTEM, ID, "Company code", "Company name", "Regulatory organization code", "Regulatory organization name", "Dealer code", "Dealer name", "Region code", "Region name", "Region VP", "Branch code", "Branch name", "Team code", "Team name", "RR fullname", "RR code", "Last name", "First name", "RR corporation name", "Status", "Group RSP indicator"
FROM DB_IAW_DEV_DATAMART."SHARED".DIM_REGISTERED_REPRESENTATIVES R
INNER JOIN DB_IAW_DEV_DATAMART.BR.DIM_USER U
ON U."User Login"= CURRENT_USER()  AND  (R.MD_SRCSYSTEM=U."Capacity" OR U."Capacity" ='ALL');
create or replace schema DB_IAW_DEV_DM.STRATEGIC;

create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ACCOUNTS_CLIENTS_SUMMARY_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	NB_MANAGED NUMBER(20,2) COMMENT 'Number of managed accounts',
	NB_FEE_BASED NUMBER(20,2) COMMENT 'Number of fee based accounts',
	NB_COMMISSION NUMBER(20,2) COMMENT 'Number of commision based accounts',
	NB_CLIENT NUMBER(20,2) COMMENT 'Number of Clientss',
	NB_ACCOUNT NUMBER(20,2) COMMENT 'Number of accounts',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ACCOUNTS_CLIENTS_SUMMARY_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0) COMMENT 'RVP ID',
	NB_MANAGED NUMBER(20,2) COMMENT 'Number of managed accounts',
	NB_FEE_BASED NUMBER(20,2) COMMENT 'Number of fee based accounts',
	NB_COMMISSION NUMBER(20,2) COMMENT 'Number of commision based accounts',
	NB_CLIENT NUMBER(20,2) COMMENT 'Number of Clientss',
	NB_ACCOUNT NUMBER(20,2) COMMENT 'Number of accounts',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYACCOUNTTYPE_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	VALUE NUMBER(20,2) COMMENT 'Asset Summary Value for Account Type',
	ACCOUNT_TYPE VARCHAR(1000) COMMENT 'Account Type'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYACCOUNTTYPE_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0) COMMENT 'RVP Ids',
	VALUE NUMBER(20,2) COMMENT 'Asset Summary Value for Account Type',
	ACCOUNT_TYPE VARCHAR(1000) COMMENT 'Account Types'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9),
	VALUE VARCHAR(16777216),
	COMMISSION_TYPE VARCHAR(16777216)
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date',
	COMMISSION_TYPE VARCHAR(16777216) COMMENT 'Commission type',
	EQT NUMBER(20,2) COMMENT 'EQT',
	MUT NUMBER(20,2) COMMENT 'MUT',
	FIX NUMBER(20,2) COMMENT 'FIX',
	OFF NUMBER(20,2) COMMENT 'OFF',
	CASH NUMBER(20,2) COMMENT 'CASH',
	TOTAL NUMBER(20,2) COMMENT 'TOTAL'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0),
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date',
	COMMISSION_TYPE VARCHAR(16777216) COMMENT 'Commission type',
	EQT NUMBER(20,2) COMMENT 'EQT',
	MUT NUMBER(20,2) COMMENT 'MUT',
	FIX NUMBER(20,2) COMMENT 'FIX',
	OFF NUMBER(20,2) COMMENT 'OFF',
	CASH NUMBER(20,2) COMMENT 'CASH',
	TOTAL NUMBER(20,2) COMMENT 'TOTAL'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date',
	VALUE VARCHAR(16777216) COMMENT 'value',
	COMMISSION_TYPE VARCHAR(16777216) COMMENT 'Commission type'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0) COMMENT 'RVP ID',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date',
	VALUE VARCHAR(16777216) COMMENT 'value',
	COMMISSION_TYPE VARCHAR(16777216) COMMENT 'Commission type'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPRODUCT_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9),
	VALUE VARCHAR(16777216),
	PRODUCT_CODE VARCHAR(16777216)
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPRODUCT_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0),
	PROCESS_DATE TIMESTAMP_NTZ(9),
	VALUE VARCHAR(16777216),
	PRODUCT_CODE VARCHAR(16777216)
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPROVINCE_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'Processed Date',
	VALUE NUMBER(20,2) COMMENT 'Asset Summary Value for Province Code',
	PROVINCE_CODE VARCHAR(1000) COMMENT 'Province Code'
);
create or replace TABLE DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPROVINCE_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0) COMMENT 'RVP Ids',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'Processed Date',
	VALUE NUMBER(20,2) COMMENT 'Asset Summary Value for Province',
	PROVINCE_CODE VARCHAR(1000) COMMENT 'Province Code'
);
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ACCOUNTS_CLIENTS_SUMMARY_DAILY(
	"Load Date",
	"nb Managed",
	"nb Feebased",
	"nb Commission",
	"nb Client",
	"nb Account",
	"Balance Date"
) as select 	MD_START_DT as "Load Date",
NB_MANAGED as "nb Managed",
	NB_FEE_BASED as "nb Feebased",
	NB_COMMISSION as "nb Commission",
	NB_CLIENT as "nb Client",
	NB_ACCOUNT as "nb Account",
	PROCESS_DATE as "Balance Date"
from DB_IAW_DEV_DM.STRATEGIC.ACCOUNTS_CLIENTS_SUMMARY_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ACCOUNTS_CLIENTS_SUMMARY_RVP_DAILY(
	"Load Date",
	RVP,
	"nb Managed",
	"nb Feebased",
	"nb Commission",
	"nb Client",
	"nb Account",
	"Balance Date"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	NB_MANAGED  as "nb Managed",
	NB_FEE_BASED as "nb Feebased",
	NB_COMMISSION as "nb Commission",
	NB_CLIENT as "nb Client",
	NB_ACCOUNT as "nb Account",
	PROCESS_DATE as "Balance Date"
from DB_IAW_DEV_DM.STRATEGIC.ACCOUNTS_CLIENTS_SUMMARY_RVP_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYACCOUNTTYPE_DAILY(
	"Load Date",
	AUA,
	"Program Type"
) as select 	MD_START_DT as "Load Date",
VALUE as "AUA",
	ACCOUNT_TYPE as "Program Type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYACCOUNTTYPE_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYACCOUNTTYPE_RVP_DAILY(
	"Load Date",
	RVP,
	AUA,
	"Program Type"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	VALUE as "AUA",
	ACCOUNT_TYPE as "Program Type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYACCOUNTTYPE_RVP_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_DAILY(
	"Load Date",
	"Balance Date",
	"Commission type",
	"Equity",
	"Mutual Funds",
	"Fixed Income",
	"Offbook Assets",
	"Cash",
	AUA
) as select 	MD_START_DT as "Load Date",
PROCESS_DATE as "Balance Date",
	COMMISSION_TYPE as "Commission type",
	EQT as "Equity",
	MUT as "Mutual Funds",
	FIX as "Fixed Income",
	OFF as "Offbook Assets",
	CASH as "Cash",
	TOTAL as "AUA"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_RVP_DAILY(
	"Load Date",
	RVP,
	"Balance Date",
	"Commission type",
	"Equity",
	"Mutual Funds",
	"Fixed Income",
	"Offbook Assets",
	"Cash",
	AUA
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	PROCESS_DATE as "Balance Date",
	COMMISSION_TYPE as "Commission type",
	EQT as "Equity",
	MUT as "Mutual Funds",
	FIX as "Fixed Income",
	OFF as "Offbook Assets",
	CASH as "Cash",
	TOTAL as "AUA"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_RVP_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYCOMMISSIONTYPE_DAILY(
	"Load Date",
	"Balance Date",
	AUA,
	"Commission type"
) as select 	MD_START_DT as "Load Date",
PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	COMMISSION_TYPE as "Commission type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYCOMMISSIONTYPE_RVP_DAILY(
	"Load Date",
	RVP,
	"Balance Date",
	AUA,
	"Commission type"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	COMMISSION_TYPE as "Commission type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_RVP_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYPRODUCT_DAILY(
	"Load Date",
	"Balance Date",
	AUA,
	"Product Type"
) as select 	MD_START_DT as "Load Date",
PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	PRODUCT_CODE as "Product Type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPRODUCT_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYPRODUCT_RVP_DAILY(
	"Load Date",
	RVP,
	"Balance Date",
	AUA,
	"Product Type"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	PRODUCT_CODE as "Product Type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPRODUCT_RVP_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYPROVINCE_DAILY(
	"Load Date",
	"Balance Date",
	AUA,
	"Province"
) as select 	MD_START_DT as "Load Date",
PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	PROVINCE_CODE as "Province"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPROVINCE_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_ASSETS_SUMMARY_BYPROVINCE_RVP_DAILY(
	"Load Date",
	RVP,
	"Balance Date",
	AUA,
	"Province"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	PROVINCE_CODE as "Province"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPROVINCE_RVP_DAILY;
create or replace view DB_IAW_DEV_DM.STRATEGIC.VW_NUMBER_OF_ACCOUNTS_BY_RVP(
	DATE,
	RVP,
	"Account Type",
	"No. Of Account"
) as 
SELECT X.BALANCE_DATE AS "DATE",
X.REGION_VP as "RVP",
X.ACCOUNT_TYPE as "Account Type",
COUNT(X.ID) as "No. Of Account"
FROM (
SELECT HLD.BALANCE_DATE, ACC.ID, ACC.ACCOUNT_TYPE, ADV.REGION_VP
FROM DB_IAW_DEV_DM."SHARED".DIM_ACCOUNTS ACC 
INNER JOIN DB_IAW_DEV_DM.HOLDINGS.FACT_HOLDINGS HLD ON ACC.ID = HLD.SK_DIM_ACCOUNTS
INNER JOIN DB_IAW_DEV_DM."SHARED".DIM_DATE DT ON HLD.BALANCE_DATE = DT."DATE"
INNER JOIN DB_IAW_DEV_DM."SHARED".DIM_ADVISOR ADV ON ADV.ID = HLD.SK_DIM_ADVISORS
) X
GROUP BY X.BALANCE_DATE, X.ACCOUNT_TYPE, X.REGION_VP ORDER BY X.BALANCE_DATE DESC, X.ACCOUNT_TYPE DESC, X.REGION_VP DESC;
create or replace schema DB_IAW_DEV_DM.TOOLS;

create or replace TABLE DB_IAW_DEV_DM.TOOLS.DATA_DICTIONARY (
	TABLENAME VARCHAR(512) COMMENT 'Table name',
	COLUMNNAME VARCHAR(512) COMMENT 'Column name',
	COLUMNTYPE VARCHAR(512) COMMENT 'Column type',
	DESCRIPTION VARCHAR(16777216) COMMENT 'A brief description of the column'
);
create or replace TABLE DB_IAW_DEV_DM.TOOLS.ENTITY_TYPES_COLUMNS_PATTERNS (
	COLUMN_ID VARCHAR(500) COMMENT 'HKHUB, HKLINK, MD_CREATION_DATE,...',
	COLUMN_ORDER NUMBER(38,0) COMMENT 'Order of the column in the entity',
	ENTITY_TYPE_ID VARCHAR(500) COMMENT 'HUB, SAT_WITH_ACTIVE_FLAG, LINK, ...',
	COLUMN_TYPE VARCHAR(500) COMMENT 'HASHKEY, METADATA,...',
	COLUMN_NAME_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the column name',
	COLUMN_TYPE_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the colmun type',
	COLUMN_OPTIONS_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the column options',
	COLUMN_COMMENTS_PATTERN VARCHAR(1000) COMMENT 'Pattern to build colomn comments',
	COLUMN_DESC VARCHAR(4000) COMMENT 'Column description'
);
create or replace TABLE DB_IAW_DEV_DM.TOOLS.ENTITY_TYPES_PATTERNS (
	ENTITY_TYPE_ID VARCHAR(500) COMMENT 'HUB, SAT_WITH_ACTIVE_FLAG, LINK, ...',
	ENTITY_CATEGORY VARCHAR(500) COMMENT 'STAGING, DATAVAULT,...',
	ENTITY_TYPE_NAME_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the table name',
	ENTITY_OPTIONS_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the table options',
	ENTITY_DESC VARCHAR(4000) COMMENT 'Entity type description'
);
CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.TOOLS."USP_BWS_BUILD_DATAMART"()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
//*************************************************************************************************************************************    
  // creating and loading HOLDINGS fact table
//*************************************************************************************************************************************  

  var st = snowflake.createStatement( { sqlText: "create or replace table HOLDINGS.FACT_HOLDINGS as select * from  DB_IAW_DEV_DATAMART.HOLDINGS.VW_FACT_HOLDINGS order by SK_DIM_CLIENTS, SK_DIM_ADVISORS, SK_DIM_MARKETPRODUCTS, SK_DIM_REGISTERED_REPRESENTATIVES;" } );
  st.execute();

//*************************************************************************************************************************************    
  // creating and loading ADVISORS dimension table
//*************************************************************************************************************************************  

  var st = snowflake.createStatement( { sqlText: "create or replace table SHARED.DIM_ADVISORS as select * from  DB_IAW_DEV_DATAMART.SHARED.VW_DIM_ADVISORS order by \\"Master code\\",\\"Company name\\",\\"Regulatory organization code\\",\\"Dealer name\\",\\"Region name\\",\\"Region VP\\",\\"Branch name\\",\\"Advisor fullname\\";" } );
  st.execute();

//*************************************************************************************************************************************  
  // creating and loading CLIENTS dimension table
//*************************************************************************************************************************************  

  var st = snowflake.createStatement( { sqlText: "create or replace table SHARED.DIM_CLIENTS as select * from  DB_IAW_DEV_DATAMART.SHARED.VW_DIM_CLIENTS order by ID,\\"Client type\\",\\"Province\\",\\"Country\\";" } );
  st.execute();
  
//*************************************************************************************************************************************  
  // creating and loading MARKETPRODUCTS dimension table
//*************************************************************************************************************************************  

  var st = snowflake.createStatement( { sqlText: "create or replace table SHARED.DIM_MARKETPRODUCTS as select * from  DB_IAW_DEV_DATAMART.SHARED.VW_DIM_MARKETPRODUCTS order by ID,\\"Group\\";" } );
  st.execute();
 
//*************************************************************************************************************************************  
  // creating and loading PLANS dimension table
//*************************************************************************************************************************************  

  var st = snowflake.createStatement( { sqlText: "create or replace table SHARED.DIM_PLANS as select * from  DB_IAW_DEV_DATAMART.SHARED.VW_DIM_PLANS order by \\"Plan code\\",\\"Account type\\",\\"Group type code\\",\\"Plan label\\";" } );
  st.execute();
 
//*************************************************************************************************************************************  
  // creating and loading REVENUES fact table
//*************************************************************************************************************************************  

  var st = snowflake.createStatement( { sqlText: "create or replace table REVENUES.FACT_REVENUES as select * from  DB_IAW_DEV_DATAMART.REVENUES.VW_FACT_REVENUES order by SK_DIM_MARKETPRODUCTS,SK_ADVISORS,SK_DIM_CLIENTS,SK_DIM_PLANS,\\"Revenue type\\";" } );
  st.execute();
  
//*************************************************************************************************************************************  
  // creating and loading TRANSACTIONS fact table
//*************************************************************************************************************************************  

  var st = snowflake.createStatement( { sqlText: "create or replace table TRANSACTIONS.FACT_TRANSACTIONS as select * from  DB_IAW_DEV_DATAMART.TRANSACTIONS.VW_FACT_TRANSACTIONS order by SK_DIM_MARKETPRODUCTS,SK_DIM_ADVISORS,SK_DIM_CLIENTS,SK_DIM_PLANS,\\"Transaction type\\";" } );
  st.execute();

//*************************************************************************************************************************************   
    // creating and loading REGISTERED_REPRESENTATIVES dimension table
//*************************************************************************************************************************************  

  var st = snowflake.createStatement( { sqlText: "create or replace table TRANSACTIONS.DIM_REGISTERED_REPRESENTATIVES as select * from  DB_IAW_DEV_DATAMART.SHARED.VW_DIM_REGISTERED_REPRESENTATIVES order by ID,\\"Dealer code\\",\\"Regulatory organization code\\",\\"RR fullname\\";" } );
  st.execute();

//*************************************************************************************************************************************   
//*************************************************************************************************************************************   
//*************************************************************************************************************************************   
  ';
CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.TOOLS."USP_BWS_UPDATE_VIEWS_STAGING_DB"("OLD_DB" VARCHAR(16777216), "NEW_DB" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
  var oldDB = OLD_DB;
  var newDB = NEW_DB;

  var ret = "";
  // creating and loading HOLDINGS fact table
  var st = snowflake.createStatement( { sqlText: "SELECT TABLE_SCHEMA || ''.'' || TABLE_NAME AS view_name FROM INFORMATION_SCHEMA.VIEWS v WHERE TABLE_SCHEMA <> ''INFORMATION_SCHEMA'';" } );
 
  var rs = st.execute();
  while (rs.next())
  	{
		var viewName = rs.getColumnValue(''VIEW_NAME'');
		var cmdDDL = "select replace(get_ddl(''VIEW'',''" + viewName +"''),''"+oldDB+"'', ''"+newDB+"'') as viewcode";
		var stDDL = snowflake.createStatement({sqlText:cmdDDL});
		var rsDDL = stDDL.execute();
		if (rsDDL.next()){
			var viewCode = rsDDL.getColumnValue(''VIEWCODE'');
			var stUpd = snowflake.createStatement({sqlText:viewCode});
			stUpd.execute();
			ret = viewCode
		}
	}
  
   return ret;
  ';
CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.TOOLS."USP_IAW_ADD_ENTITY_TABLE"("SCHEMA_NAME" VARCHAR(16777216), "ENTITY_NAME" VARCHAR(16777216), "ENTITY_TYPE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var cmdTable = "CREATE ";
var cmd = "SELECT etp.ENTITY_TYPE_NAME_PATTERN, etp.ENTITY_OPTIONS_PATTERN FROM TOOLS.ENTITY_TYPES_PATTERNS etp WHERE etp.ENTITY_TYPE_ID =''" + ENTITY_TYPE + "''";
var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();
if (res.next())
{
	// Build table name
	var strEntityNamePattern = res.getColumnValue(1);
	strEntityNamePattern = strEntityNamePattern.replace("{ENTITY}", ENTITY_NAME);
	var strEntityOptPattern = res.getColumnValue(2);
	strEntityOptPattern = strEntityOptPattern.replace("{ENTITY}", ENTITY_NAME);
	cmdTable += strEntityOptPattern + " TABLE " + SCHEMA_NAME + ".";
	cmdTable += strEntityNamePattern + "(";
	
	// Add columns to the create statement
	var cmdCol = "SELECT COLUMN_NAME_PATTERN, COLUMN_TYPE_PATTERN, COLUMN_OPTIONS_PATTERN, COLUMN_COMMENTS_PATTERN FROM TOOLS.ENTITY_TYPES_COLUMNS_PATTERNS WHERE ENTITY_TYPE_ID=''"+ENTITY_TYPE+"'' ORDER BY COLUMN_ORDER";
	var stCol = snowflake.createStatement( { sqlText: cmdCol } );
	var resCol = stCol.execute();

	var i = 0
	// Loop over columns to add to the table
	while(resCol.next())
	{
		if (i>0) { cmdTable += ", " }
		var strColName = resCol.getColumnValue(1);
		strColName = strColName.replace("{ENTITY}", ENTITY_NAME);
		var strColType = resCol.getColumnValue(2);
		var strColOpt = resCol.getColumnValue(3);
		var strColCom = resCol.getColumnValue(4);
		cmdTable += strColName + " " + strColType + " " + strColOpt + " COMMENT ''" + strColCom + "''";
		i += 1;  
	}
	cmdTable += ")"
	var stTable = snowflake.createStatement( { sqlText: cmdTable } );
	
	// Execute table DDL
	try
	{
		stTable.execute();
		return "Table <" + SCHEMA_NAME +"."+strEntityNamePattern + "> added.";
	}
	catch(er)
	{
		return "Error While adding table : " + cmdTable + " Error : " + er; 
	}
	
}
else
{
	return "Entity type <" + ENTITY_TYPE + "> not found!";
}

';
CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.TOOLS."USP_TEST"()
RETURNS ARRAY
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var Test = ''TEST_TABLE123''
let sql_insert = `
	Insert into DB_IAW_DEV_DM.EXTRACTIONS.WT_COMMISSION_ORGANIC_GROWTH
	select * from DB_IAW_DEV_DM.EXTRACTIONS.WT_COMMISSION_ORGANIC_GROWTH;
	`;

 snowflake.execute({"sqlText" : sql_insert, "binds" : [Test]});
  
  return [Test];
';
create or replace schema DB_IAW_DEV_DM.TRANSACTIONS;

create or replace TABLE DB_IAW_DEV_DM.TRANSACTIONS.FACT_TRANSACTIONS (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the dimension',
	HK_LINK VARCHAR(40) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	SK_DIM_CLIENTS NUMBER(38,0),
	SK_DIM_ADVISORS NUMBER(38,0),
	SK_DIM_PLANS NUMBER(38,0),
	SK_DIM_MARKETPRODUCTS NUMBER(38,0),
	TRADE_DATE TIMESTAMP_NTZ(9),
	GROSS_AMOUNT NUMBER(38,12),
	CASH_FLOW VARCHAR(16777216),
	CASH_FLOW_TYPE VARCHAR(8),
	ADMINISTRATORY_TYPE VARCHAR(8000),
	DEPARTED_ADVISOR_IND NUMBER(1,0) COMMENT 'DEPARTED ADVISOR INDICATOR',
	DAYS_LAST_PRICED NUMBER(4,0),
	TRANSACTION_ID VARCHAR(100) COMMENT 'The ID of the transaction',
	SK_DIM_ACCOUNTS NUMBER(38,0),
	SK_DEPARTED_ADVISOR NUMBER(38,0)
);
create or replace TABLE DB_IAW_DEV_DM.TRANSACTIONS.FACT_TRANSACTIONS_BKUP (
	ID NUMBER(38,0),
	HK_LINK VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID VARCHAR(1000),
	MD_SOURCE VARCHAR(1000),
	MD_SRC_SYSTEM VARCHAR(100),
	MD_EXTRACT_DT TIMESTAMP_NTZ(9),
	MD_SECURITY_TYPE VARCHAR(1000),
	SK_DIM_CLIENTS NUMBER(38,0),
	SK_DIM_ADVISORS NUMBER(38,0),
	SK_DIM_PLANS NUMBER(38,0),
	SK_DIM_MARKETPRODUCTS NUMBER(38,0),
	TRADE_DATE TIMESTAMP_NTZ(9),
	GROSS_AMOUNT NUMBER(38,12),
	CASH_FLOW VARCHAR(16777216),
	CASH_FLOW_TYPE VARCHAR(8),
	ADMINISTRATORY_TYPE VARCHAR(8000),
	DEPARTED_ADVISOR_IND NUMBER(1,0),
	DAYS_LAST_PRICED NUMBER(4,0),
	TRANSACTION_ID VARCHAR(100),
	SK_DIM_ACCOUNTS NUMBER(38,0),
	SK_DEPARTED_ADVISOR NUMBER(38,0)
);
create or replace TABLE DB_IAW_DEV_DM.TRANSACTIONS.WT_FACT_TRANSACTIONS (
	HK_LINK VARCHAR(40) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER VARCHAR(40) COMMENT 'Hash key for PARTY_ROLE_ACCOUNT_HOLDER',
	HK_HUB_PARTY_ROLE_ADVISOR VARCHAR(40) COMMENT 'Hash key for the REGISTERED_REPRESENTATIVE_COMMISSION',
	HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES VARCHAR(40) COMMENT 'Hash key for the REF_INVESTMENT_SAVING_PROGRAM_TYPES',
	HK_HUB_INVESTMENT_PRODUCT_TYPE VARCHAR(40) COMMENT 'Hash key for the REF_MAPPING_PRODUCT_TYPE',
	SK_DIM_CLIENTS NUMBER(38,0),
	SK_DIM_ADVISORS NUMBER(38,0),
	SK_DIM_PLANS NUMBER(38,0),
	SK_DIM_MARKETPRODUCTS NUMBER(38,0),
	TRADE_DATE TIMESTAMP_NTZ(9),
	GROSS_AMOUNT NUMBER(38,12),
	CASH_FLOW VARCHAR(16777216),
	CASH_FLOW_TYPE VARCHAR(8),
	ADMINISTRATORY_TYPE VARCHAR(8000),
	DEPARTED_ADVISOR_IND NUMBER(1,0) COMMENT 'DEPARTED ADVISOR INDICATOR',
	DAYS_LAST_PRICED NUMBER(4,0),
	TRANSACTION_ID VARCHAR(100) COMMENT 'The ID of the transaction',
	SK_DIM_ACCOUNTS NUMBER(38,0),
	SK_DEPARTED_ADVISOR NUMBER(38,0)
);
create or replace view DB_IAW_DEV_DM.TRANSACTIONS.VW_FACT_TRANSACTIONS(
	ID,
	SK_DIM_CLIENTS,
	SK_DIM_ADVISORS,
	SK_DIM_PLANS,
	SK_DIM_MARKETPRODUCTS,
	"Trade date",
	"Gross amount",
	CASH_FLOW,
	CASH_FLOW_TYPE,
	"Administratory type",
	"Departed advisor indicator",
	MD_SRCSYSTEM,
	SK_DEPARTED_ADVISOR
) as 
SELECT  
	ID ,
	SK_DIM_CLIENTS ,
	SK_DIM_ADVISORS ,
	SK_DIM_PLANS ,
	SK_DIM_MARKETPRODUCTS ,
	TRADE_DATE  AS "Trade date",
	GROSS_AMOUNT AS "Gross amount",
	CASH_FLOW ,
	CASH_FLOW_TYPE ,
	ADMINISTRATORY_TYPE AS "Administratory type",
	DEPARTED_ADVISOR_IND  AS "Departed advisor indicator",
	MD_SRC_SYSTEM  AS MD_SRCSYSTEM,
	SK_DEPARTED_ADVISOR 
FROM TRANSACTIONS.FACT_TRANSACTIONS
WHERE DATE(TRADE_DATE) >= (SELECT DATE(DATEADD(YEAR, -2,MAX(TRADE_DATE) ))  FROM TRANSACTIONS.FACT_TRANSACTIONS)
order by SK_DIM_MARKETPRODUCTS,SK_DIM_ADVISORS,SK_DIM_CLIENTS,SK_DIM_PLANS, SK_DEPARTED_ADVISOR;
create or replace view DB_IAW_DEV_DM.TRANSACTIONS.VW_INITIAL_LOADING_WT_FACT_TRANSACTIONS(
	MD_START_DT,
	MD_SOURCE,
	MD_SRC_SYSTEM,
	MD_EXTRACT_DT,
	HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
	HK_HUB_PARTY_ROLE_ADVISOR,
	HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES,
	HK_HUB_INVESTMENT_PRODUCT_TYPE,
	SK_DIM_CLIENTS,
	SK_DIM_ADVISORS,
	SK_DIM_PLANS,
	SK_DIM_MARKETPRODUCTS,
	TRADE_DATE,
	GROSS_AMOUNT,
	CASH_FLOW,
	CASH_FLOW_TYPE,
	ADMINISTRATORY_TYPE,
	DEPARTED_ADVISOR_IND,
	DAYS_LAST_PRICED,
	TRANSACTION_ID
) as
SELECT
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_SOURCE,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_SRC_SYSTEM,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_EXTRACT_DT,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.HK_HUB_PARTY_ROLE_ADVISOR,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.HK_HUB_INVESTMENT_PRODUCT_TYPE,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_CLIENTS.ID IS NULL THEN -1
	ELSE SHARED.DIM_CLIENTS.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_CLIENTS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_ADVISOR.ID IS NULL THEN -1
	ELSE SHARED.DIM_ADVISOR.ID
END) AS VARCHAR(252)) AS FLOAT) AS SK_DIM_ADVISORS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_PLANS.ID IS NULL THEN -1
	ELSE SHARED.DIM_PLANS.ID
END) AS VARCHAR(251)) AS FLOAT) SK_DIM_PLANS,
	CAST(CAST(
	(CASE WHEN SHARED.DIM_FINANCIAL_INSTRUMENTS.ID IS NULL THEN -1
	ELSE SHARED.DIM_FINANCIAL_INSTRUMENTS.ID
END) AS VARCHAR(252)) AS FLOAT) SK_DIM_MARKETPRODUCTS,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.TRADE_DATE,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.GROSS_AMOUNT,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.CASH_FLOW,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.CASH_FLOW_TYPE,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.ADMINISTRATORY_TYPE,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.DEPARTED_ADVISOR_IND,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.DAYS_LAST_PRICED,
	DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.TRANSACTION_ID
FROM
	(
SHARED.DIM_CLIENTS
RIGHT OUTER JOIN (SHARED.DIM_PLANS
RIGHT OUTER JOIN (SHARED.DIM_ADVISOR
RIGHT OUTER JOIN (SHARED.DIM_FINANCIAL_INSTRUMENTS
RIGHT OUTER JOIN DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION ON
	(DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.HK_HUB_INVESTMENT_PRODUCT_TYPE = SHARED.DIM_FINANCIAL_INSTRUMENTS.HK_HUB)
	AND ((SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_START_DT <= DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT)
		AND ((SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_END_DT > DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT)
			OR SHARED.DIM_FINANCIAL_INSTRUMENTS.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.HK_HUB_PARTY_ROLE_ADVISOR = SHARED.DIM_ADVISOR.HK_HUB)
	AND ((SHARED.DIM_ADVISOR.MD_START_DT <= DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT)
		AND ((SHARED.DIM_ADVISOR.MD_END_DT > DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT)
			OR SHARED.DIM_ADVISOR.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES = SHARED.DIM_PLANS.HK_HUB)
	AND ((SHARED.DIM_PLANS.MD_START_DT <= DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT)
		AND ((SHARED.DIM_PLANS.MD_END_DT > DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT)
			OR SHARED.DIM_PLANS.MD_END_DT IS NULL))) ON
	(DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER = SHARED.DIM_CLIENTS.HK_HUB)
	AND ((SHARED.DIM_CLIENTS.MD_START_DT <= DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT)
		AND ((SHARED.DIM_CLIENTS.MD_END_DT > DB_IAW_DEV_DWH.TRANSACTIONS_BDV.TRANSLINK_FINANCIAL_TRANSACTION.MD_START_DT)
			OR SHARED.DIM_CLIENTS.MD_END_DT IS NULL)));
create or replace schema DB_IAW_DEV_DM.TRANSACTIONS_BKP;

create or replace TABLE DB_IAW_DEV_DM.TRANSACTIONS_BKP.DIM_REGISTERED_REPRESENTATIVES (
	MD_SRCSYSTEM VARCHAR(8),
	ID VARCHAR(16777216),
	"Company code" VARCHAR(50),
	"Company name" VARCHAR(512),
	"Regulatory organization code" VARCHAR(50),
	"Regulatory organization name" VARCHAR(512),
	"Dealer code" VARCHAR(50),
	"Dealer name" VARCHAR(512),
	"Region code" VARCHAR(50),
	"Region name" VARCHAR(512),
	"Region VP" VARCHAR(16777216),
	"Branch code" VARCHAR(16777216),
	"Branch name" VARCHAR(16777216),
	"Team code" VARCHAR(50),
	"Team name" VARCHAR(512),
	"RR fullname" VARCHAR(16777216),
	"RR code" VARCHAR(16777216),
	"Last name" VARCHAR(16777216),
	"First name" VARCHAR(16777216),
	"RR corporation name" VARCHAR(16777216),
	"Status" VARCHAR(16777216),
	"Group RSP indicator" VARCHAR(512),
	MD_LOADDATE TIMESTAMP_NTZ(7)
);
create or replace TABLE DB_IAW_DEV_DM.TRANSACTIONS_BKP.FACT_TRANSACTIONS (
	ID VARCHAR(16777216),
	SK_DIM_CLIENTS VARCHAR(16777216),
	SK_DIM_ADVISORS VARCHAR(50),
	SK_DIM_PLANS VARCHAR(16777216),
	SK_DIM_MARKETPRODUCTS VARCHAR(16777216),
	"Plan code" VARCHAR(8000),
	"Trade date" TIMESTAMP_NTZ(9),
	"Gross amount" NUMBER(38,12),
	"Transaction type" VARCHAR(21),
	ORD_TRANSACTION_TYPE NUMBER(1,0),
	MD_LOADDATE TIMESTAMP_NTZ(9),
	MD_SRCSYSTEM VARCHAR(50),
	CASH_FLOW VARCHAR(12),
	"Administratory type" VARCHAR(8000),
	"New Money" VARCHAR(3)
);
create or replace TABLE DB_IAW_DEV_DM.TRANSACTIONS_BKP.FACT_TRANSACTIONS2 (
	ID VARCHAR(16777216),
	SK_DIM_CLIENTS VARCHAR(16777216),
	SK_DIM_ADVISORS VARCHAR(50),
	SK_DIM_PLANS VARCHAR(16777216),
	SK_DIM_MARKETPRODUCTS VARCHAR(16777216),
	"Plan code" VARCHAR(8000),
	"Trade date" TIMESTAMP_NTZ(9),
	"Gross amount" NUMBER(38,12),
	"Transaction type" VARCHAR(21),
	ORD_TRANSACTION_TYPE NUMBER(1,0),
	MD_LOADDATE TIMESTAMP_NTZ(9),
	MD_SRCSYSTEM VARCHAR(50),
	CASH_FLOW VARCHAR(12),
	"Administratory type" VARCHAR(8000),
	"New Money" VARCHAR(3)
);
create or replace TABLE DB_IAW_DEV_DM.TRANSACTIONS_BKP.TRANSACTIONS_ACCP (
	ID VARCHAR(100)
);
create or replace TABLE DB_IAW_DEV_DM.TRANSACTIONS_BKP.TRANSACTIONS_SRC (
	ID VARCHAR(100)
);
create or replace view DB_IAW_DEV_DM.TRANSACTIONS_BKP.VW_FACT_TRANSACTIONS(
	ID,
	SK_DIM_CLIENTS,
	SK_DIM_ADVISORS,
	SK_DIM_PLANS,
	SK_DIM_MARKETPRODUCTS,
	"Plan code",
	"Trade date",
	"Gross amount",
	"Transaction type",
	ORD_TRANSACTION_TYPE,
	MD_LOADDATE,
	MD_SRCSYSTEM,
	CASH_FLOW,
	"Administratory type",
	"New Money"
) as

WITH 
IAS_LV_SHARE AS 
(
	SELECT * FROM DB_IAW_DEV_STAGING.IAS_COMMISSION.SHARE R
	WHERE
	R.REVNO = 
	(
	SELECT MAX(RT.REVNO)
	FROM DB_IAW_DEV_STAGING.IAS_COMMISSION.SHARE RT
	WHERE 	
	RT.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS_COMMISSION.SHARE )
	AND
	COALESCE(RT.TOREPID, '') = COALESCE(R.TOREPID, '') AND COALESCE(RT.FROMREPID, '') = COALESCE(R.FROMREPID, '') 
	AND COALESCE(RT.SHARETYPE, '') = COALESCE(R.SHARETYPE, '') AND COALESCE(RT.SOURCECODE, '') = COALESCE(R.SOURCECODE, '')
	AND COALESCE(RT.PRODUCTCODE, '') = COALESCE(R.PRODUCTCODE, '')
	)
	AND SHARETYPE <> 'noreference' AND SHARETYPE <> 'option' AND R.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS_COMMISSION.SHARE )
)
SELECT
	DECODE(TRX.TRX_SYSID,NULL,'-1',CONCAT('I_', TRX.TRX_SYSID)) AS ID,
	DECODE(TRX.IVR_SYSID,NULL,'-1',CONCAT('I_', TRX.IVR_SYSID)) AS SK_DIM_CLIENTS,
	--DECODE(TRX.REP_SYSID,NULL,'-1',CONCAT('I_', TRX.REP_SYSID)) AS FACT_TRANSACTIONS_REP_SYSID,
	DECODE(X.MASTER_CD,NULL,'-1',CONCAT('I_', X.MASTER_CD))		AS SK_DIM_ADVISORS,
	DECODE(TRX.PLN_SYSID,NULL,'-1',CONCAT('I_', TRX.PLN_SYSID)) AS SK_DIM_PLANS,
	--DECODE(TRX.ACT_SYSID,NULL,'-1',CONCAT('I_', TRX.ACT_SYSID)) AS FACT_TRANSACTIONS_ACT_SYSID,
	DECODE(TRX.IVD_SYSID,NULL,'-1',CONCAT('I_', TRX.IVD_SYSID)) AS SK_DIM_MARKETPRODUCTS,
	DECODE(pl.PLN_MNEM,NULL,'-1',pl.PLN_MNEM) AS "Plan code",
	--TRX.TRX_STATUS,
	--TRX.TRX_ST_DESC_ENG,
	TRX.TRADE_DT                              AS "Trade date",
	--TRX.MGT_CD,
	--TRX.MGT_NAME_ENG,
	--TRX.DLR_SYSID,
	TRX.TRX_GROSS*SPR_FACTOR AS "Gross amount", --iheb:J'ai enlever le ABS() pour pouvoir garder le signe negatif
	--TRX.CURRENCY_CD,
	--TRX.PLN_TYPE,
	--TRX.SPR_CTGY,
	--TRX.TRX_MNEM_ENG,
	CASE WHEN TRX.SPR_CTGY='PUR'											 	THEN 'Purchases' 
		 WHEN TRX.SPR_CTGY='RED'											 	THEN 'Redemptions'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%SWI%'										THEN 'Switch In'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%SWO%'										THEN 'Switch Out'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%TIN%'										THEN 'Transfer In'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%TOT%'										THEN 'Transfer Out'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%XIN%' OR TRX.TRX_MNEM_ENG LIKE '%DXI%'	THEN 'External Transfer In'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%XOT%' OR TRX.TRX_MNEM_ENG LIKE '%DXO%'	THEN 'External Transfer Out'
		 ELSE 																 		 'Others'
	END AS "Transaction type",
	CASE WHEN TRX.SPR_CTGY='PUR'												THEN 1 
		 WHEN TRX.SPR_CTGY='RED'												THEN 2
		 WHEN TRX.TRX_MNEM_ENG LIKE '%SWI%'										THEN 3
		 WHEN TRX.TRX_MNEM_ENG LIKE '%SWO%'										THEN 4
		 WHEN TRX.TRX_MNEM_ENG LIKE '%TIN%'										THEN 5
		 WHEN TRX.TRX_MNEM_ENG LIKE '%TOT%'										THEN 6
		 WHEN TRX.TRX_MNEM_ENG LIKE '%XIN%' OR TRX.TRX_MNEM_ENG LIKE '%DXI%'	THEN 7
		 WHEN TRX.TRX_MNEM_ENG LIKE '%XOT%' OR TRX.TRX_MNEM_ENG LIKE '%DXO%'	THEN 8
		 ELSE 																 		 9
	END AS ORD_TRANSACTION_TYPE,
	TRX.MD_LOADDATE,
	TRX.MD_SRCSYSTEM,
	
	CASE WHEN TRX.SPR_CTGY='PUR'											 	 
		 OR TRX.SPR_CTGY='RED'											 	
		 OR TRX.TRX_MNEM_ENG LIKE '%SWI%'										
		 OR TRX.TRX_MNEM_ENG LIKE '%SWO%'										
		 OR TRX.TRX_MNEM_ENG LIKE '%TIN%'										
		 OR TRX.TRX_MNEM_ENG LIKE '%TOT%'										
		 OR (TRX.TRX_MNEM_ENG LIKE '%XIN%' OR TRX.TRX_MNEM_ENG LIKE '%DXI%')	
		 OR (TRX.TRX_MNEM_ENG LIKE '%XOT%' OR TRX.TRX_MNEM_ENG LIKE '%DXO%')	THEN 'Yes'
		 ELSE 'No' END         AS CASH_FLOW,
	
	
	--NULL            AS "In/Out"
	AC.ADMINISTRATOR_TYPE AS "Administratory type",
	NULL                            AS "New Money"
	
FROM
	DB_IAW_DEV_STAGING.INVESTIA."TRANSACTIONS" TRX
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.X_DBB_MASTER_REP X ON TRX.REP_SYSID = X.REP_SYSID AND TRX.MD_LOADDATE=X.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA."ACCOUNTS" ac ON TRX.PLN_SYSID = ac.PLN_SYSID AND TRX.MD_LOADDATE = ac.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.INVESTIA.PLANS pl ON ac.PLN_CD = pl.PLN_CD AND ac.MD_LOADDATE = pl.MD_LOADDATE
LEFT OUTER JOIN DB_IAWEALTH_FNCT_STAGING.INVESTIA.MARKETPRODUCTS mp ON TRX.IVD_SYSID = mp.IVD_SYSID AND TRX.MD_LOADDATE = mp.MD_LOADDATE
WHERE 	TRX.SPR_CTGY in ('PUR', 'PAC', 'RED', 'AWD', 'SWI', 'SWO', 'TIN', 'TOT', 'XIN', 'XOT')
AND mp.SYMBOL not in ('MRC001','IAAFCCA','INVCCA')  

AND TRX.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.INVESTIA."TRANSACTIONS" )


							UNION ALL
							
							
SELECT
	DECODE(TRX.TRX_SYSID,NULL,'-1',CONCAT('F_', TRX.TRX_SYSID)) AS ID,
	DECODE(TRX.IVR_SYSID,NULL,'-1',CONCAT('F_', TRX.IVR_SYSID)) AS SK_DIM_CLIENTS,
	--DECODE(TRX.REP_SYSID,NULL,'-1',CONCAT('F_', TRX.REP_SYSID)) AS FACT_TRANSACTIONS_REP_SYSID,
	DECODE(X.MASTER_CD,NULL,'-1',CONCAT('F_', X.MASTER_CD))		AS SK_DIM_ADVISORS,
	DECODE(TRX.PLN_SYSID,NULL,'-1',CONCAT('F_', TRX.PLN_SYSID)) AS SK_DIM_PLANS,
	--DECODE(TRX.ACT_SYSID,NULL,'-1',CONCAT('F_', TRX.ACT_SYSID)) AS FACT_TRANSACTIONS_ACT_SYSID,
	DECODE(TRX.IVD_SYSID,NULL,'-1',CONCAT('F_', TRX.IVD_SYSID)) AS SK_DIM_MARKETPRODUCTS,
	DECODE(pl.PLN_MNEM,NULL,'-1',pl.PLN_MNEM) AS "Plan code",
	--TRX.TRX_STATUS,
	--TRX.TRX_ST_DESC_ENG,
	TRX.TRADE_DT                              AS "Trade date",
	--TRX.MGT_CD,
	--TRX.MGT_NAME_ENG,
	--TRX.DLR_SYSID,
	TRX.TRX_GROSS*SPR_FACTOR AS "Gross amount", --iheb:J'ai enlever le ABS() pour pouvoir garder le signe negatif
	--TRX.CURRENCY_CD,
	--TRX.PLN_TYPE,
	--TRX.SPR_CTGY,
	--TRX.TRX_MNEM_ENG,
	CASE WHEN TRX.SPR_CTGY='PUR'											 	THEN 'Purchases' 
		 WHEN TRX.SPR_CTGY='RED'											 	THEN 'Redemptions'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%SWI%'										THEN 'Switch In'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%SWO%'										THEN 'Switch Out'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%TIN%'										THEN 'Transfer In'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%TOT%'										THEN 'Transfer Out'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%XIN%' OR TRX.TRX_MNEM_ENG LIKE '%DXI%'	THEN 'External Transfer In'
		 WHEN TRX.TRX_MNEM_ENG LIKE '%XOT%' OR TRX.TRX_MNEM_ENG LIKE '%DXO%'	THEN 'External Transfer Out'
		 ELSE 																 		 'Others'
	END AS "Transaction type",
	CASE WHEN TRX.SPR_CTGY='PUR'												THEN 1 
		 WHEN TRX.SPR_CTGY='RED'												THEN 2
		 WHEN TRX.TRX_MNEM_ENG LIKE '%SWI%'										THEN 3
		 WHEN TRX.TRX_MNEM_ENG LIKE '%SWO%'										THEN 4
		 WHEN TRX.TRX_MNEM_ENG LIKE '%TIN%'										THEN 5
		 WHEN TRX.TRX_MNEM_ENG LIKE '%TOT%'										THEN 6
		 WHEN TRX.TRX_MNEM_ENG LIKE '%XIN%' OR TRX.TRX_MNEM_ENG LIKE '%DXI%'	THEN 7
		 WHEN TRX.TRX_MNEM_ENG LIKE '%XOT%' OR TRX.TRX_MNEM_ENG LIKE '%DXO%'	THEN 8
		 ELSE 																 		 9
	END AS ORD_TRANSACTION_TYPE,
	TRX.MD_LOADDATE,
	TRX.MD_SRCSYSTEM,
	
	CASE WHEN TRX.SPR_CTGY='PUR'											 	 
		 OR TRX.SPR_CTGY='RED'											 	
		 OR TRX.TRX_MNEM_ENG LIKE '%SWI%'										
		 OR TRX.TRX_MNEM_ENG LIKE '%SWO%'										
		 OR TRX.TRX_MNEM_ENG LIKE '%TIN%'										
		 OR TRX.TRX_MNEM_ENG LIKE '%TOT%'										
		 OR (TRX.TRX_MNEM_ENG LIKE '%XIN%' OR TRX.TRX_MNEM_ENG LIKE '%DXI%')	
		 OR (TRX.TRX_MNEM_ENG LIKE '%XOT%' OR TRX.TRX_MNEM_ENG LIKE '%DXO%')	THEN 'Yes'
		 ELSE 'No' END         AS CASH_FLOW,
		 
	--NULL            AS "In/Out"
	AC.ADMINISTRATOR_TYPE AS "Administratory type",
	NULL                            AS "New Money"
	
FROM
	DB_IAW_DEV_STAGING.FUNDEX."TRANSACTIONS" TRX
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.X_DBB_MASTER_REP X ON TRX.REP_SYSID = X.REP_SYSID AND TRX.MD_LOADDATE = X.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX."ACCOUNTS" ac ON TRX.PLN_SYSID = ac.PLN_SYSID AND TRX.MD_LOADDATE = ac.MD_LOADDATE
LEFT OUTER JOIN DB_IAW_DEV_STAGING.FUNDEX.PLANS pl ON ac.PLN_CD = pl.PLN_CD AND ac.MD_LOADDATE = pl.MD_LOADDATE
LEFT OUTER JOIN DB_IAWEALTH_FNCT_STAGING.INVESTIA.MARKETPRODUCTS mp ON TRX.IVD_SYSID = mp.IVD_SYSID AND TRX.MD_LOADDATE = mp.MD_LOADDATE
WHERE 	TRX.SPR_CTGY in ('PUR', 'PAC', 'RED', 'AWD', 'SWI', 'SWO', 'TIN', 'TOT', 'XIN', 'XOT')
AND mp.SYMBOL not in ('MRC001','IAAFCCA','INVCCA')  

AND TRX.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.FUNDEX."TRANSACTIONS" )

UNION ALL

SELECT
	TO_VARCHAR(COALESCE(T."TRANSACTION",'-1')) 								AS ID,
	COALESCE(C.A_C_CLIENT,'-1') 											AS SK_DIM_CLIENTS,
	--COALESCE(T.A_C_REPRESENTATIVE,'-1') 									AS FACT_TRANSACTIONS_REP_SYSID,
	COALESCE(S.TOREPID,'-1')												AS SK_DIM_ADVISORS,
	--COALESCE(T.A_C_ID,'-1') 												AS SK_DIM_PLANS,
	CONCAT(IFNULL(C.ACCOUNT_RAP_CODE, ''), '_', IFNULL(C.RETAIL_PLAN, '')) 	AS SK_DIM_PLANS,
	--COALESCE(T.A_C_ID,'-1') 												AS FACT_TRANSACTIONS_ACT_SYSID,
	COALESCE(T.TI_ALTERNATE_ID,'-1')  										AS SK_DIM_MARKETPRODUCTS,
	CONCAT(IFNULL(C.ACCOUNT_RAP_CODE, ''), '_', IFNULL(C.RETAIL_PLAN, '')) 	AS "Plan code",
	--'' 																		AS TRX_STATUS,
    --'' 																		AS TRX_ST_DESC_ENG,
	T.TRAN_TRADING_TRADE_DATE 												AS "Trade date",
	--'' 																		AS MGT_CD,
	--'' 																		AS MGT_NAME_ENG,
	--NULL 																	AS DLR_SYSID,
	DECODE(T.TRAN_TRADING_CURRENCY,'USD',
           T.TRAN_TRADING_GROSS_AMT*E.EXCHANGERATE,
           T.TRAN_TRADING_GROSS_AMT) * S.COMMISSIONPCT  * 0.01				AS "Gross amount", --iheb:J'ai enlever le ABS() pour pouvoir garder le signe negatif
	--T.TRAN_TRADING_CURRENCY 												AS CURRENCY_CD,
	--'' 																		AS PLN_TYPE,
	--'' 																		AS SPR_CTGY,
	--'' 																		AS TRX_MNEM_ENG,
	CASE T.TRAN_TRADING_TYPE 
		WHEN 'B' THEN  'Purchases'						
		WHEN 'S' THEN 'Redemptions' 
		ELSE 'Others' END													AS "Transaction type",
		
	CASE T.TRAN_TRADING_TYPE 
		WHEN 'B' THEN  1						
		WHEN 'S' THEN 2
		ELSE 9
	END																		AS ORD_TRANSACTION_TYPE,
	NULL 																	AS MD_LOADDATE,
	'IAS' 																	AS MD_SRCSYSTEM,
	CASE WHEN Y.CASHFLOW IS NULL THEN 'Unknown' ELSE Y.CASHFLOW END         AS CASH_FLOW,
	
	--CASE WHEN TRAN_TRADING_GROSS_AMT <0 THEN 'In' ELSE 'Out' END            AS "In/Out"
	C.ADMINISTRATOR_TYPE AS "Administratory type",
	
	CASE WHEN Y.CASHFLOW='Yes' AND T.TRAN_TRADING_GROSS_AMT >=0 AND YEAR(T.MD_LOADDATE)=YEAR(T.TRAN_TRADING_TRADE_DATE) AND MONTH(T.MD_LOADDATE)=MONTH(T.TRAN_TRADING_TRADE_DATE) THEN 'Yes' ELSE 'No' END AS "New Money"
	
FROM DB_IAW_DEV_STAGING.IAS."TRANSACTIONS" T
LEFT JOIN IAS_LV_SHARE S
ON S.FROMREPID = T.A_C_REPRESENTATIVE
LEFT JOIN DB_IAW_DEV_STAGING.IAS."ACCOUNTS" C 
ON T.A_C_ID = C.A_C_ID AND T.MD_LOADDATE=C.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_STAGING.IAS.EXCHANGERATE E ON
E.EXCHANGEDATE = T.TRAN_TRADING_TRADE_DATE AND E.MD_LOADDATE=T.MD_LOADDATE
LEFT JOIN DB_IAW_DEV_DATAMART.BR.IAS_MAPPING_OPER_TYPE Y
ON T.TRAN_ENTRY_DESCRIPTION = Y.DESCRIPTION_SHORT_EN

WHERE T.MD_LOADDATE = (SELECT MAX(MD_LOADDATE) FROM DB_IAW_DEV_STAGING.IAS."TRANSACTIONS" );