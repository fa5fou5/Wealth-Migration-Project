create or replace schema STRATEGIC;

create or replace TABLE ACCOUNTS_CLIENTS_SUMMARY_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	NB_MANAGED NUMBER(20,2) COMMENT 'Number of managed accounts',
	NB_FEE_BASED NUMBER(20,2) COMMENT 'Number of fee based accounts',
	NB_COMMISSION NUMBER(20,2) COMMENT 'Number of commision based accounts',
	NB_CLIENT NUMBER(20,2) COMMENT 'Number of Clientss',
	NB_ACCOUNT NUMBER(20,2) COMMENT 'Number of accounts',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date'
);
create or replace TABLE ACCOUNTS_CLIENTS_SUMMARY_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0) COMMENT 'RVP ID',
	NB_MANAGED NUMBER(20,2) COMMENT 'Number of managed accounts',
	NB_FEE_BASED NUMBER(20,2) COMMENT 'Number of fee based accounts',
	NB_COMMISSION NUMBER(20,2) COMMENT 'Number of commision based accounts',
	NB_CLIENT NUMBER(20,2) COMMENT 'Number of Clientss',
	NB_ACCOUNT NUMBER(20,2) COMMENT 'Number of accounts',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date'
);
create or replace TABLE ASSETS_SUMMARY_BYACCOUNTTYPE_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	VALUE NUMBER(20,2) COMMENT 'Asset Summary Value for Account Type',
	ACCOUNT_TYPE VARCHAR(1000) COMMENT 'Account Type'
);
create or replace TABLE ASSETS_SUMMARY_BYACCOUNTTYPE_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0) COMMENT 'RVP Ids',
	VALUE NUMBER(20,2) COMMENT 'Asset Summary Value for Account Type',
	ACCOUNT_TYPE VARCHAR(1000) COMMENT 'Account Types'
);
create or replace TABLE ASSETS_SUMMARY_BYCOMMISSIONTYPE (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9),
	VALUE VARCHAR(16777216),
	COMMISSION_TYPE VARCHAR(16777216)
);
create or replace TABLE ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date',
	COMMISSION_TYPE VARCHAR(16777216) COMMENT 'Commission type',
	EQT NUMBER(20,2) COMMENT 'EQT',
	MUT NUMBER(20,2) COMMENT 'MUT',
	FIX NUMBER(20,2) COMMENT 'FIX',
	OFF NUMBER(20,2) COMMENT 'OFF',
	CASH NUMBER(20,2) COMMENT 'CASH',
	TOTAL NUMBER(20,2) COMMENT 'TOTAL'
);
create or replace TABLE ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0),
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date',
	COMMISSION_TYPE VARCHAR(16777216) COMMENT 'Commission type',
	EQT NUMBER(20,2) COMMENT 'EQT',
	MUT NUMBER(20,2) COMMENT 'MUT',
	FIX NUMBER(20,2) COMMENT 'FIX',
	OFF NUMBER(20,2) COMMENT 'OFF',
	CASH NUMBER(20,2) COMMENT 'CASH',
	TOTAL NUMBER(20,2) COMMENT 'TOTAL'
);
create or replace TABLE ASSETS_SUMMARY_BYCOMMISSIONTYPE_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date',
	VALUE VARCHAR(16777216) COMMENT 'value',
	COMMISSION_TYPE VARCHAR(16777216) COMMENT 'Commission type'
);
create or replace TABLE ASSETS_SUMMARY_BYCOMMISSIONTYPE_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0) COMMENT 'RVP ID',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'process date',
	VALUE VARCHAR(16777216) COMMENT 'value',
	COMMISSION_TYPE VARCHAR(16777216) COMMENT 'Commission type'
);
create or replace TABLE ASSETS_SUMMARY_BYPRODUCT_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9),
	VALUE VARCHAR(16777216),
	PRODUCT_CODE VARCHAR(16777216)
);
create or replace TABLE ASSETS_SUMMARY_BYPRODUCT_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0),
	PROCESS_DATE TIMESTAMP_NTZ(9),
	VALUE VARCHAR(16777216),
	PRODUCT_CODE VARCHAR(16777216)
);
create or replace TABLE ASSETS_SUMMARY_BYPROVINCE_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'Processed Date',
	VALUE NUMBER(20,2) COMMENT 'Asset Summary Value for Province Code',
	PROVINCE_CODE VARCHAR(1000) COMMENT 'Province Code'
);
create or replace TABLE ASSETS_SUMMARY_BYPROVINCE_RVP_DAILY (
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SRC_SYSTEM VARCHAR(100) COMMENT 'Source system',
	MD_EXTRACT_DT TIMESTAMP_NTZ(9) COMMENT 'Source extraction date',
	RVPID NUMBER(10,0) COMMENT 'RVP Ids',
	PROCESS_DATE TIMESTAMP_NTZ(9) COMMENT 'Processed Date',
	VALUE NUMBER(20,2) COMMENT 'Asset Summary Value for Province',
	PROVINCE_CODE VARCHAR(1000) COMMENT 'Province Code'
);
create or replace view VW_ACCOUNTS_CLIENTS_SUMMARY_DAILY(
	"Load Date",
	"nb Managed",
	"nb Feebased",
	"nb Commission",
	"nb Client",
	"nb Account",
	"Balance Date"
) as select 	MD_START_DT as "Load Date",
NB_MANAGED as "nb Managed",
	NB_FEE_BASED as "nb Feebased",
	NB_COMMISSION as "nb Commission",
	NB_CLIENT as "nb Client",
	NB_ACCOUNT as "nb Account",
	PROCESS_DATE as "Balance Date"
from DB_IAW_DEV_DM.STRATEGIC.ACCOUNTS_CLIENTS_SUMMARY_DAILY;
create or replace view VW_ACCOUNTS_CLIENTS_SUMMARY_RVP_DAILY(
	"Load Date",
	RVP,
	"nb Managed",
	"nb Feebased",
	"nb Commission",
	"nb Client",
	"nb Account",
	"Balance Date"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	NB_MANAGED  as "nb Managed",
	NB_FEE_BASED as "nb Feebased",
	NB_COMMISSION as "nb Commission",
	NB_CLIENT as "nb Client",
	NB_ACCOUNT as "nb Account",
	PROCESS_DATE as "Balance Date"
from DB_IAW_DEV_DM.STRATEGIC.ACCOUNTS_CLIENTS_SUMMARY_RVP_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYACCOUNTTYPE_DAILY(
	"Load Date",
	AUA,
	"Program Type"
) as select 	MD_START_DT as "Load Date",
VALUE as "AUA",
	ACCOUNT_TYPE as "Program Type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYACCOUNTTYPE_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYACCOUNTTYPE_RVP_DAILY(
	"Load Date",
	RVP,
	AUA,
	"Program Type"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	VALUE as "AUA",
	ACCOUNT_TYPE as "Program Type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYACCOUNTTYPE_RVP_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_DAILY(
	"Load Date",
	"Balance Date",
	"Commission type",
	"Equity",
	"Mutual Funds",
	"Fixed Income",
	"Offbook Assets",
	"Cash",
	AUA
) as select 	MD_START_DT as "Load Date",
PROCESS_DATE as "Balance Date",
	COMMISSION_TYPE as "Commission type",
	EQT as "Equity",
	MUT as "Mutual Funds",
	FIX as "Fixed Income",
	OFF as "Offbook Assets",
	CASH as "Cash",
	TOTAL as "AUA"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_RVP_DAILY(
	"Load Date",
	RVP,
	"Balance Date",
	"Commission type",
	"Equity",
	"Mutual Funds",
	"Fixed Income",
	"Offbook Assets",
	"Cash",
	AUA
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	PROCESS_DATE as "Balance Date",
	COMMISSION_TYPE as "Commission type",
	EQT as "Equity",
	MUT as "Mutual Funds",
	FIX as "Fixed Income",
	OFF as "Offbook Assets",
	CASH as "Cash",
	TOTAL as "AUA"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_AND_PRODUCT_RVP_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYCOMMISSIONTYPE_DAILY(
	"Load Date",
	"Balance Date",
	AUA,
	"Commission type"
) as select 	MD_START_DT as "Load Date",
PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	COMMISSION_TYPE as "Commission type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYCOMMISSIONTYPE_RVP_DAILY(
	"Load Date",
	RVP,
	"Balance Date",
	AUA,
	"Commission type"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	COMMISSION_TYPE as "Commission type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYCOMMISSIONTYPE_RVP_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYPRODUCT_DAILY(
	"Load Date",
	"Balance Date",
	AUA,
	"Product Type"
) as select 	MD_START_DT as "Load Date",
PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	PRODUCT_CODE as "Product Type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPRODUCT_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYPRODUCT_RVP_DAILY(
	"Load Date",
	RVP,
	"Balance Date",
	AUA,
	"Product Type"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	PRODUCT_CODE as "Product Type"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPRODUCT_RVP_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYPROVINCE_DAILY(
	"Load Date",
	"Balance Date",
	AUA,
	"Province"
) as select 	MD_START_DT as "Load Date",
PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	PROVINCE_CODE as "Province"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPROVINCE_DAILY;
create or replace view VW_ASSETS_SUMMARY_BYPROVINCE_RVP_DAILY(
	"Load Date",
	RVP,
	"Balance Date",
	AUA,
	"Province"
) as select 	MD_START_DT as "Load Date",
RVPID as "RVP",
	PROCESS_DATE as "Balance Date",
	VALUE as "AUA",
	PROVINCE_CODE as "Province"
from DB_IAW_DEV_DM.STRATEGIC.ASSETS_SUMMARY_BYPROVINCE_RVP_DAILY;
create or replace view VW_NUMBER_OF_ACCOUNTS(
	"Balance Date",
	"Account Type",
	"Nb Accounts",
	"Nb Active Accounts",
	"Nb Clients",
	"Nb Active Clients"
) as
WITH DATES AS
(
    SELECT DISTINCT DATE
    FROM SHARED.DIM_DATE 
    WHERE DATE BETWEEN (SELECT MIN(md_start_dt) FROM HOLDINGS.FACT_HOLDINGS) AND (SELECT MAX(md_start_dt) FROM HOLDINGS.FACT_HOLDINGS )
)
,LATEST_VERSION_INVESTMENT_CONTRACT AS 
(
    SELECT 
        D.DATE, 
        LIC.HK_HUB_CONTRACT,
        LIC.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
        SLIC.MD_START_DT,
        COALESCE (SLIC.MD_ACTIVE,'A') AS MD_ACTIVE,
	    COALESCE (ROW_NUMBER() OVER (PARTITION BY D.DATE,LIC.HK_LINK ORDER BY SLIC.MD_START_DT DESC ),1) AS RANK_SLIC
    FROM DATES D
    LEFT JOIN DB_IAW_DEV_DWH.SHARED_BDV.SAT_LINK_INVESTMENT_CONTRACT SLIC 
    ON SLIC.MD_START_DT <= D.DATE
    LEFT JOIN DB_IAW_DEV_DWH.SHARED_BDV.LINK_INVESTMENT_CONTRACT LIC
    ON LIC.HK_LINK = SLIC.HK_LINK
)
SELECT 
    DATEADD(DAY,-1,D.DATE)                                 AS "Balance Date" , 
    ACC.ACCOUNT_TYPE                                       AS "Account Type", 
    COUNT(DISTINCT ACC.CONTRACT_ID) AS "Nb Accounts" ,
    COUNT(DISTINCT ACC_AUA.CONTRACT_ID) AS "Nb Active Accounts" ,
    0 AS "Nb Clients",
    0 AS "Nb Active Clients"
FROM DATES D
LEFT JOIN LATEST_VERSION_INVESTMENT_CONTRACT LVIC
    ON D.DATE = LVIC.DATE
    AND LVIC.RANK_SLIC = 1
    AND LVIC.MD_ACTIVE = 'A' 
LEFT JOIN SHARED.DIM_ACCOUNTS ACC
    ON ACC.HK_HUB = LVIC.HK_HUB_CONTRACT
    AND D.DATE BETWEEN ACC.MD_START_DT AND COALESCE (ACC.MD_END_DT,'9999-12-31')
    AND ACC.HK_HUB <> '0'
LEFT JOIN SHARED.DIM_ACCOUNTS ACC_AUA
    ON ACC_AUA.HK_HUB = LVIC.HK_HUB_CONTRACT
    AND D.DATE BETWEEN ACC_AUA.MD_START_DT AND COALESCE (ACC_AUA.MD_END_DT,'9999-12-31')
    AND ACC_AUA.ACCOUNT_AUA_SEGMENT <> '0'
WHERE ACC.ACCOUNT_IND = 1
GROUP BY 
    "Balance Date", 
    "Account Type"
--
UNION ALL 
--
SELECT 
    DATEADD(DAY,-1,D.DATE)                                 AS "Balance Date" , 
    ''                                                     AS "Account Type", 
    0 AS "Nb Accounts" ,
    0 AS "Nb Active Accounts" ,
    COUNT(DISTINCT DC.CLIENT_ID) AS "Nb Clients",
    COUNT(DISTINCT DC_AUA.CLIENT_ID) AS "Nb Active Clients"
FROM DATES D
LEFT JOIN LATEST_VERSION_INVESTMENT_CONTRACT LVIC
    ON D.DATE = LVIC.DATE
    AND LVIC.RANK_SLIC = 1
    AND LVIC.MD_ACTIVE = 'A' 
LEFT JOIN SHARED.DIM_ACCOUNTS ACC
    ON ACC.HK_HUB = LVIC.HK_HUB_CONTRACT
    AND D.DATE BETWEEN ACC.MD_START_DT AND COALESCE (ACC.MD_END_DT,'9999-12-31')
    AND ACC.HK_HUB <> '0'
LEFT JOIN SHARED.DIM_CLIENTS DC
    ON DC.HK_HUB = LVIC.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER
    AND D.DATE BETWEEN DC.MD_START_DT AND COALESCE (DC.MD_END_DT,'9999-12-31')
    AND DC.HK_HUB <> '0'
LEFT JOIN SHARED.dim_clients DC_AUA
    ON DC_AUA.HK_HUB = LVIC.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER
    AND D.DATE BETWEEN DC_AUA.MD_START_DT AND COALESCE (DC_AUA.MD_END_DT,'9999-12-31')
    AND DC_AUA.CLIENT_AUA_SEGMENT <> '0'
WHERE ACC.ACCOUNT_IND = 1
GROUP BY 
    "Balance Date", 
    "Account Type";
create or replace view VW_NUMBER_OF_ACCOUNTS_BY_RVP(
	"Balance Date",
	"Account Type",
	RVP,
	"Nb Accounts",
	"Nb Active Accounts",
	"Nb Clients",
	"Nb Active Clients"
) as
WITH DATES AS
(
    SELECT DISTINCT DATE
    FROM SHARED.DIM_DATE 
    WHERE DATE BETWEEN (SELECT MIN(md_start_dt) FROM HOLDINGS.FACT_HOLDINGS) AND (SELECT MAX(md_start_dt) FROM HOLDINGS.FACT_HOLDINGS )
)
,LATEST_VERSION_INVESTMENT_CONTRACT AS 
(
    SELECT 
        D.DATE, 
        LIC.HK_HUB_CONTRACT,
        LIC.HK_HUB_PARTY_ROLE_ADVISOR,
        LIC.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,
        SLIC.MD_START_DT,
        COALESCE (SLIC.MD_ACTIVE,'A') AS MD_ACTIVE,
	    COALESCE (ROW_NUMBER() OVER (PARTITION BY D.DATE,LIC.HK_LINK ORDER BY SLIC.MD_START_DT DESC ),1) AS RANK_SLIC
    FROM DATES D
    LEFT JOIN DB_IAW_DEV_DWH.SHARED_BDV.SAT_LINK_INVESTMENT_CONTRACT SLIC 
    ON SLIC.MD_START_DT <= D.DATE
    LEFT JOIN DB_IAW_DEV_DWH.SHARED_BDV.LINK_INVESTMENT_CONTRACT LIC
    ON LIC.HK_LINK = SLIC.HK_LINK
)
SELECT 
    DATEADD(DAY,-1,D.DATE)                                 AS "Balance Date" , 
    ACC.ACCOUNT_TYPE                                       AS "Account Type", 
    DA.REGION_VP                                           AS RVP, 
    COUNT(DISTINCT ACC.CONTRACT_ID) AS "Nb Accounts" ,
    COUNT(DISTINCT ACC_AUA.CONTRACT_ID) AS "Nb Active Accounts" ,
    0 AS "Nb Clients",
    0 AS "Nb Active Clients"
FROM DATES D
LEFT JOIN LATEST_VERSION_INVESTMENT_CONTRACT LVIC
    ON D.DATE = LVIC.DATE
    AND LVIC.RANK_SLIC = 1
    AND LVIC.MD_ACTIVE = 'A' 
LEFT JOIN SHARED.DIM_ACCOUNTS ACC
    ON ACC.HK_HUB = LVIC.HK_HUB_CONTRACT
    AND D.DATE BETWEEN ACC.MD_START_DT AND COALESCE (ACC.MD_END_DT,'9999-12-31')
    AND ACC.HK_HUB <> '0'
LEFT JOIN SHARED.DIM_ADVISOR DA
    ON DA.HK_HUB = LVIC.HK_HUB_PARTY_ROLE_ADVISOR
    AND D.DATE BETWEEN DA.MD_START_DT AND COALESCE (DA.MD_END_DT,'9999-12-31')
    AND DA.HK_HUB <> '0'
LEFT JOIN SHARED.DIM_ACCOUNTS ACC_AUA
    ON ACC_AUA.HK_HUB = LVIC.HK_HUB_CONTRACT
    AND D.DATE BETWEEN ACC_AUA.MD_START_DT AND COALESCE (ACC_AUA.MD_END_DT,'9999-12-31')
    AND ACC_AUA.ACCOUNT_AUA_SEGMENT <> '0'
WHERE ACC.ACCOUNT_IND = 1
GROUP BY 
    "Balance Date", 
    "Account Type", 
    RVP
--
UNION ALL 
--
SELECT 
    DATEADD(DAY,-1,D.DATE)                                 AS "Balance Date" , 
    ''                                                     AS "Account Type", 
    DA.REGION_VP                                           AS RVP, 
    0 AS "Nb Accounts" ,
    0 AS "Nb Active Accounts" ,
    COUNT(DISTINCT DC.CLIENT_ID) AS "Nb Clients",
    COUNT(DISTINCT DC_AUA.CLIENT_ID) AS "Nb Active Clients"
FROM DATES D
LEFT JOIN LATEST_VERSION_INVESTMENT_CONTRACT LVIC
    ON D.DATE = LVIC.DATE
    AND LVIC.RANK_SLIC = 1
    AND LVIC.MD_ACTIVE = 'A' 
LEFT JOIN SHARED.DIM_ACCOUNTS ACC
    ON ACC.HK_HUB = LVIC.HK_HUB_CONTRACT
    AND D.DATE BETWEEN ACC.MD_START_DT AND COALESCE (ACC.MD_END_DT,'9999-12-31')
    AND ACC.HK_HUB <> '0'
LEFT JOIN SHARED.DIM_ADVISOR DA
    ON DA.HK_HUB = LVIC.HK_HUB_PARTY_ROLE_ADVISOR
    AND D.DATE BETWEEN DA.MD_START_DT AND COALESCE (DA.MD_END_DT,'9999-12-31')
    AND DA.HK_HUB <> '0'
LEFT JOIN SHARED.DIM_CLIENTS DC
    ON DC.HK_HUB = LVIC.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER
    AND D.DATE BETWEEN DC.MD_START_DT AND COALESCE (DC.MD_END_DT,'9999-12-31')
    AND DC.HK_HUB <> '0'
LEFT JOIN SHARED.dim_clients DC_AUA
    ON DC_AUA.HK_HUB = LVIC.HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER
    AND D.DATE BETWEEN DC_AUA.MD_START_DT AND COALESCE (DC_AUA.MD_END_DT,'9999-12-31')
    AND DC_AUA.CLIENT_AUA_SEGMENT <> '0'
WHERE ACC.ACCOUNT_IND = 1
GROUP BY 
    "Balance Date", 
    "Account Type", 
    RVP;