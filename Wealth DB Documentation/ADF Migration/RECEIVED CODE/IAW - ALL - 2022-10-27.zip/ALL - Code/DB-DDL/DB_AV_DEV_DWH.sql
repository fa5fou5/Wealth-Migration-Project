create or replace database DB_AV_DEV_DWH;

create or replace schema BDV;

create or replace TABLE CLEAN_SAT_POLICY (
	HK_HUB_POLICY_CLEAN VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_EVENT_TYPE VARCHAR(100),
	PRODUCT_CODE VARCHAR(50),
	PRODUCT_VERSION_CODE VARCHAR(50),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(4),
	ISSUE_STATE VARCHAR(4),
	POLICY_EFFECTIVE_DATE DATE,
	LAST_REINSTATEMENT_DATE DATE,
	POLICY_STATUS VARCHAR(2),
	POLICY_SUB_STATUS VARCHAR(2),
	PAYEMENT_FREQUENCY VARCHAR(2),
	NEXT_PREMIUM_DUE_DATE DATE,
	PAYMENT_METHOD VARCHAR(2),
	BILLING_STATUS VARCHAR(2),
	PAID_TO_DATE DATE,
	BILLING_SUSPENSION_REASON VARCHAR(255),
	BILLING_SUSPENSION_REQUESTOR VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE DATE,
	POLICY_ACB NUMBER(19,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(19,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(19,2),
	POLICY_ANNUAL_PREMIUM NUMBER(19,2),
	POLICY_MODAL_PREMIUM NUMBER(19,2),
	ANNUAL_POLICY_FEES NUMBER(19,2),
	MODAL_POLICY_FEES NUMBER(19,2),
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_POLICY_CLEAN primary key (HK_HUB_POLICY_CLEAN, MD_START_DT)
);
create or replace view VW_OIPA_COHORTE_AGENT(
	NO_POLICE,
	COUVERTURE_ID,
	NO_AGENT,
	CODE_DISTRICT,
	CODE_US,
	CODE_TYPE_AGENT,
	CODE_EQUIPE
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement d''agent de l''event ACTIVATED'
 as
WITH 
_cohorte AS (
  SELECT  
        POL.POLICYNUMBER       ::VARCHAR(200) AS NO_POLICE,
        POL.COVERAGEIDENTIFIER ::VARCHAR(200) AS COUVERTURE_ID,
        POL.AdvisorCode        ::VARCHAR(200) AS NO_AGENT,
        POL.AgencyNumber       ::VARCHAR(200) AS CODE_DISTRICT,
        POL.ServiceUnitNumber  ::VARCHAR(200) AS CODE_US,
        FPIS.AgentType         ::VARCHAR(200) AS Code_Type_Agent, --carriere ou ordinaire 
        MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT
 FROM DB_AV_DEV_STG.PSA.VW_FLATTEN_POLICY POL
 LEFT JOIN DB_AV_DEV_STG.PSA.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
             ON FPIS.correlationid = POL.correlationid
             AND FPIS.PartyID = POL.PartyID
 WHERE COALESCE(POL.AdvisorCode,'N/A') = COALESCE(FPIS.AgentCode,'N/A')
)
SELECT DISTINCT NO_POLICE,
       COUVERTURE_ID,
       NO_AGENT,
       CODE_DISTRICT,
       CODE_US,
       CODE_TYPE_AGENT,
       '' ::VARCHAR(200) AS CODE_EQUIPE --n'existe pas dans OIPA
FROM  _cohorte;
create or replace view VW_OIPA_COHORTE_ASSURE(
	NO_POLICE,
	CD_COMPAGNIE,
	COUVERTURE_ID,
	CD_PLAN,
	NO_PHASE,
	NO_SOUS_PHASE,
	NO_ASSURE,
	NO_CONJOINT,
	IND_EQUIVALENT,
	AGE_EMISSION,
	DATE_NAISSANCE,
	CD_SEXE,
	CD_ST_FUMEUR
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une police de l''event ACTIVATED'
 as
SELECT DISTINCT     VW_BRUTE.POLICYNUMBER                   AS No_Police,
                    0					    AS Cd_Compagnie,
                    VW_BRUTE.COVERAGEIDENTIFIER             AS Couverture_ID, 
                    co.CD_PLAN                              AS Cd_Plan, --modif
                    CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER) AS No_Phase,
                    1	                                AS No_Sous_Phase,
                    1                                       AS No_Assure,
                    -4                                      AS No_Conjoint,
                    0                                       AS Ind_Equivalent,
                    TRY_CAST(VW_BRUTE.ISSUEAGE AS INTEGER)  AS Age_Emission,
                    VW_BRUTE.CLIENTDATEOFBIRTH              AS Date_Naissance,
                    NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.UNDERWRITINGGENDER     ||' non trouvé') AS Cd_Sexe,
                    IFF((Age_Emission < 15 AND VW_BRUTE.TOBACCOUSE = '03' ),'2',NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.TOBACCOUSE             ||' non trouvé')) AS Cd_St_Fumeur         
FROM DB_AV_DEV_STG.PSA."VW_FLATTEN_POLICY" VW_BRUTE

LEFT JOIN DB_AV_DEV_DWH.BDV.VW_OIPA_COHORTE_COUVERTURE co 
       ON co.NO_POLICE = VW_BRUTE.POLICYNUMBER 
      AND co.COUVERTURE_ID = VW_BRUTE.COVERAGEIDENTIFIER

LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeTobaccoUse' 
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.TOBACCOUSE

LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeGender' 
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.UNDERWRITINGGENDER;
create or replace view VW_OIPA_COHORTE_COUVERTURE(
	NO_POLICE,
	COUVERTURE_ID,
	NO_COUVERTURE,
	FKID_PRODUIT,
	VERSION_PRODUIT_OIPA,
	VERSION_PROTECTION_OIPA,
	DATE_REFERENCE_TAUX_OIPA,
	CD_ST_COUVERTURE_TRAD,
	CD_ST_RAISON_COUVERTURE_TRAD,
	CD_CONJOINT,
	MNT_FRAIS,
	CAPITAL_ASSURE_COURANT,
	NB_UNITE,
	VALEUR_UNITE,
	MNT_PRIME_ANNUELLE,
	DT_LIBERATION,
	DT_EXPIRATION,
	INITIALTERMDURATION,
	MNT_PRIME_REMB_ABANDON,
	MNT_PRIME_REMB_DECES,
	CD_TYPE_EMISSION,
	DT_EMISSION_COUVERTURE,
	CD_BANDE_FORCE,
	CD_PLAN,
	DATE_VERSION
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une couverture de l''event ACTIVATED.'
 as
SELECT DISTINCT VW_BRUTE.POLICYNUMBER                          ::VARCHAR(200)   AS NO_POLICE,
       VW_BRUTE.COVERAGEIDENTIFIER                             ::VARCHAR(200)   AS COUVERTURE_ID, 
       CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER)                                  AS NO_COUVERTURE,
       PL.ID_CORRESPONDANCE_CODE_PLAN                                           AS FKID_PRODUIT,
       VW_BRUTE.PRODUCTVERSIONCODE                             ::VARCHAR(200)   AS VERSION_PRODUIT_OIPA, 
       VW_BRUTE.COVERAGEVERSIONCODE                            ::VARCHAR(200)   AS VERSION_PROTECTION_OIPA,
       TRY_CAST(VW_BRUTE.RATESREFERENCEDATE AS DATE)                            AS DATE_REFERENCE_TAUX_OIPA,
       NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESTATUS     ||' non trouvé') ::VARCHAR(200) AS CD_ST_COUVERTURE_TRAD,
       NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESUBSTATUS  ||' non trouvé') ::VARCHAR(200) AS CD_ST_RAISON_COUVERTURE_TRAD,
       1         		        	                                      AS CD_CONJOINT,
       CAST(VW_BRUTE.DISTRIBUTEDPOLICYFEES AS NUMERIC(9,2))                     AS MNT_FRAIS,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT AS NUMERIC(9,0))                         AS CAPITAL_ASSURE_COURANT,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT / 1000 AS NUMERIC(9,0))                  AS NB_UNITE,
       1000					                                      AS VALEUR_UNITE,
       CAST(VW_BRUTE.COVERAGEANNUALPREMIUM AS  NUMERIC(9,2))                    AS MNT_PRIME_ANNUELLE,
       NVL(VW_BRUTE.PAIDUPDATE,  VW_BRUTE.EXPIRYDATE)          ::DATE           AS DT_LIBERATION,
       NVL(NVL(VW_BRUTE.EXPIRYDATE, VW_BRUTE.MATURITYDATE), VW_BRUTE.PAIDUPDATE) ::VARCHAR(200)   AS DT_EXPIRATION,
       TRY_CAST(VW_BRUTE.INITIALTERMDURATION AS INTEGER)                        AS INITIALTERMDURATION,
       0.00				                                             AS MNT_PRIME_REMB_ABANDON,
       0.00				                                             AS MNT_PRIME_REMB_DECES,
       -1	      			                                             AS CD_TYPE_EMISSION,
       VW_BRUTE.COVERAGEEFFECTIVEDATE                          ::DATE           AS DT_EMISSION_COUVERTURE,
       -1  	                                                 ::NUMERIC(1,0)   AS CD_BANDE_FORCE,
       PL.PDF_PLAN_NAME     		                                      AS CD_PLAN,
       PL.PDF_VERSION_DATE 			                     ::VARCHAR(200)   AS DATE_VERSION

FROM      DB_AV_DEV_STG.PSA."VW_FLATTEN_POLICY" VW_BRUTE 

LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeSubstatus'
      AND dom1.CODE_NAME_CIBLE = 'CdStatutCouverture'
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESTATUS
    				       																			
LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
      AND dom2.CODE_NAME_CIBLE = 'CdStatutRaisonCouverture'					   															
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESUBSTATUS
				   
LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_CODE_PLAN  PL 
       ON PL.PRODUCT_VERSION_CODE  = VW_BRUTE.PRODUCTVERSIONCODE 
      AND PL.COVERAGE_VERSION_CODE  = VW_BRUTE.COVERAGEVERSIONCODE 
      AND PL.RATES_REFERENCE_DATE = VW_BRUTE.RATESREFERENCEDATE;
create or replace view VW_OIPA_COHORTE_POLICE(
	NO_POLICE,
	CD_COMPAGNIE,
	CD_ST_POLICE,
	CD_ST_RAISON_POLICE,
	CD_DEVISE,
	NO_AGENT,
	CD_DISTRICT,
	CODE_TYPE_AGENT,
	CD_PROVINCE,
	CD_COUNTRY,
	CD_FREQUENCE_PAIEMENT,
	IND_PARTICIPATION,
	COUT_BASE_REAJUSTE,
	MNT_BALANCE_PRET,
	FACTEUR_MODAL,
	CD_US,
	CD_EQUIPE,
	CD_SOURCE,
	CD_TYPE_PAIEMENT,
	MNT_VALEUR_RACHAT,
	DT_CHARGEMENT
) COMMENT='VUE POLICE D''ASSURANCE QUI CONTIENT LE DERNIER ENREGISTREMENT REÇU POUR UNE POLICE DE L''EVENT ACTIVATED'
 as
WITH _COHORTEINI AS (
                     SELECT * FROM (
                                    SELECT POL.POLICYNUMBER                  AS POLICY_NUMBER,
                                           POL.POLICYSTATUS                  AS POLICY_STATUS,
                                           POL.POLICYSUBSTATUS               AS POLICY_SUBSTATUS,
                                           POL.POLICYCURRENCY                AS POLICY_CURRENCY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS POLICY_OWNER_RESIDENCE_STATE,
                                           POL.ISSUESTATE                    AS ISSUE_STATE,
                                           POL.PAYMENTFREQUENCY              AS PAYMENT_FREQUENCY,
                                           POL.POLICYACB                     AS POLICY_ACB,
                                           POL.PAYMENTMETHOD                 AS PAYMENT_METHOD,
                                           POL.MD_DTCHARGEMENT::TIMESTAMPLTZ AS MD_DTCHARGEMENT,
                                           POL.ADVISORCODE                   AS NO_AGENT,
                                           'CA'                              AS COUNTRY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS PROVINCE,
                                           POL.AGENCYNUMBER                  AS CODE_DISTRICT,
                                           FPIS.AGENTTYPE                    AS CODE_TYPE_AGENT,
   	                                    POL.SERVICEUNITNUMBER             AS CODE_US,
                                           POL.CLIENTDATEOFBIRTH             AS CLIENT_DATE_OF_BIRTH,
                       	               MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT, 
                                           ROW_number() OVER (PARTITION BY pol.PolicyNumber ORDER BY Code_Type_Agent ASC, pol.Agent DESC, CASE WHEN UPPER(POL.POLICYOWNERCORRESPONDENCEINDICATOR) in ('TRUE','1') THEN 1 ELSE 0 END DESC, POL.PARTYID ASC) NB
                                    FROM DB_AV_DEV_STG.PSA.VW_FLATTEN_POLICY POL
                                    LEFT JOIN DB_AV_DEV_STG.PSA.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
                                                 ON FPIS.correlationid = POL.correlationid
                                                 AND FPIS.PartyID = POL.PartyID
                                    ) t 
                                    WHERE NB = 1 
),  
   _COHORTE_DOMAINEVALEUR AS (
                              SELECT POLICY_NUMBER,
                                     POLICY_CURRENCY,
                                     POLICY_ACB,
                                     ISSUE_STATE,
                                     POLICY_OWNER_RESIDENCE_STATE,
                                     NO_AGENT,
                                     CODE_TYPE_AGENT,
                                     CODE_DISTRICT,
                                     CODE_US,
                                     CLIENT_DATE_OF_BIRTH,
                                     COUNTRY,           
                                     NVL(DOM1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_STATUS     ||' non trouvé') AS CDSTPOLICE,
                                     NVL(DOM2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_SUBSTATUS  ||' non trouvé') AS CDSTRAISONPOLICE,
                                     NVL(DOM3.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_FREQUENCY ||' non trouvé') AS CDFREQUENCEPAIEMENT,
                                     NVL(DOM4.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_METHOD    ||' non trouvé') AS CDTYPEPAIEMENT,
                                     NVL(DOM5.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PROVINCE          ||' non trouvé') AS PROVINCE,
                                     MAX_MD_DTCHARGEMENT AS DT_CHARGEMENT
                               FROM _COHORTEINI 

                          LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
                                 ON DOM1.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
    				    AND DOM1.CODE_NAME_CIBLE  = 'CdStatutPolice'
    				    AND DOM1.CODE_VALEUR_SOURCE = POLICY_STATUS
    																				
			     LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
                                 ON DOM2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
			           AND DOM2.CODE_NAME_CIBLE  = 'CdStatutRaisonPolice'
				    AND DOM2.CODE_VALEUR_SOURCE = POLICY_SUBSTATUS
								
                	     LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM3 
                                 ON DOM3.CODE_NAME_SOURCE = 'AsCodePaymentFrequency' 
                                AND DOM3.CODE_VALEUR_SOURCE = PAYMENT_FREQUENCY
     
                          LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM4 
                                 ON DOM4.CODE_NAME_SOURCE = 'AsCodePaymentMethod' 
                                AND DOM4.CODE_VALEUR_SOURCE = PAYMENT_METHOD
     
		            LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM5 
                                 ON DOM5.CODE_NAME_SOURCE = 'AsCodeState' 
                                AND DOM5.CODE_VALEUR_SOURCE = PROVINCE
),

-----------------------------------------------------------------------------------
--CERTAINES COLONNE NE SONT PAS FOURNIES PAR OIPA MAIS SONT NÉCESSAIRES POUR XA.
--CETTE COHORTE CORRESPOND AUX CHAMPS IDENTIFIÉS DANS LA TABLE SVDVIEV_POLICE_TRAD
-----------------------------------------------------------------------------------

   _COHORTE AS (
                SELECT POLICY_NUMBER 	                     ::VARCHAR(200) AS NO_POLICE,
                       0                                                      AS CD_COMPAGNIE,
                       CDSTPOLICE                              ::VARCHAR(200) AS CD_ST_POLICE,
                       CDSTRAISONPOLICE	                     ::VARCHAR(200) AS CD_ST_RAISON_POLICE,           
                       POLICY_CURRENCY	                     ::VARCHAR(200) AS CD_DEVISE,
                       NO_AGENT                                ::VARCHAR(200) AS NO_AGENT,
                       CODE_DISTRICT                           ::VARCHAR(200) AS CD_DISTRICT,
                       CODE_TYPE_AGENT                         ::VARCHAR(200) AS CODE_TYPE_AGENT,
                       PROVINCE		                     ::VARCHAR(200) AS CD_PROVINCE,
                       COUNTRY		                     ::VARCHAR(200) AS CD_COUNTRY,
                       CDFREQUENCEPAIEMENT                                    AS CD_FREQUENCE_PAIEMENT,
                       0                                                      AS IND_PARTICIPATION,
                       TRY_CAST(POLICY_ACB AS DECIMAL(9,2))                   AS COUT_BASE_REAJUSTE,
                       0.00			                                    AS MNT_BALANCE_PRET,
                       CAST(1.08000 AS DECIMAL(9,2))                          AS FACTEUR_MODAL,
                       CODE_US                                 ::VARCHAR(200) AS CD_US,
                       NULL                                    ::VARCHAR(200) AS CD_EQUIPE,
                       -1                                                     AS CD_SOURCE,
                       CDTYPEPAIEMENT	                     ::VARCHAR(200) AS CD_TYPE_PAIEMENT,
                     --A VENIR EN ATTENTE DE OIPA - il n'y pas de valeur de rachat avant 5 ans.'
                       CAST(0 AS DECIMAL(9,2))                                AS MNT_VALEUR_RACHAT,
                       DT_CHARGEMENT
                FROM _COHORTE_DOMAINEVALEUR
)

SELECT * FROM _COHORTE;
create or replace view VW_SAT_POLICY_CLEAN(
	HK_HUB_POLICY,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_START_DT,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	PRODUCT_CODE,
	PRODUCT_VERSION_CODE,
	POLICY_OWNER_RESIDENCE_STATE,
	POLICY_YEAR,
	POLICY_CURRENCY,
	ISSUE_STATE,
	POLICY_EFFECTIVE_DATE,
	LAST_REINSTATEMENT_DATE,
	POLICY_STATUS,
	POLICY_SUB_STATUS,
	PAYMENT_FREQUENCY,
	NEXT_PREMIUM_DUE_DATE,
	PAYMENT_METHOD,
	BILLING_STATUS,
	PAID_TO_DATE,
	BILLING_INTERRUPTION_REASON,
	ANTICIPATE_BILLING_RESUME_DATE,
	POLICY_ACB,
	POLICY_ACB_MODAL_PREMIUM,
	POLICY_ACB_PREMIUM_ITD,
	POLICY_ANNUAL_PREMIUM,
	POLICY_MODAL_PREMIUM,
	ANNUAL_POLICY_FEES,
	MODAL_POLICY_FEES
) as
SELECT *
--,convert_timezone('America/Montreal', POLICY_EFFECTIVE_DATE)::timestamp_ntz as NTZ_POLICY_EFFECTIVE_DATE
FROM DB_AV_DEV_DWH.RDV.SAT_POLICY;
create or replace schema BDV_CLONE_IB;

create or replace TABLE CLEAN_SAT_POLICY (
	HK_HUB_POLICY_CLEAN VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_EVENT_TYPE VARCHAR(100),
	PRODUCT_CODE VARCHAR(50),
	PRODUCT_VERSION_CODE VARCHAR(50),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(4),
	ISSUE_STATE VARCHAR(4),
	POLICY_EFFECTIVE_DATE DATE,
	LAST_REINSTATEMENT_DATE DATE,
	POLICY_STATUS VARCHAR(2),
	POLICY_SUB_STATUS VARCHAR(2),
	PAYEMENT_FREQUENCY VARCHAR(2),
	NEXT_PREMIUM_DUE_DATE DATE,
	PAYMENT_METHOD VARCHAR(2),
	BILLING_STATUS VARCHAR(2),
	PAID_TO_DATE DATE,
	BILLING_SUSPENSION_REASON VARCHAR(255),
	BILLING_SUSPENSION_REQUESTOR VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE DATE,
	POLICY_ACB NUMBER(19,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(19,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(19,2),
	POLICY_ANNUAL_PREMIUM NUMBER(19,2),
	POLICY_MODAL_PREMIUM NUMBER(19,2),
	ANNUAL_POLICY_FEES NUMBER(19,2),
	MODAL_POLICY_FEES NUMBER(19,2),
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_POLICY_CLEAN primary key (HK_HUB_POLICY_CLEAN, MD_START_DT)
);
create or replace view VW_OIPA_COHORTE_AGENT(
	NO_POLICE,
	COUVERTURE_ID,
	NO_AGENT,
	CODE_DISTRICT,
	CODE_US,
	CODE_TYPE_AGENT,
	CODE_EQUIPE
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement d''agent de l''event ACTIVATED'
 as
WITH 
_cohorte AS (
  SELECT  
        POL.POLICYNUMBER       ::VARCHAR(200) AS NO_POLICE,
        POL.COVERAGEIDENTIFIER ::VARCHAR(200) AS COUVERTURE_ID,
        POL.AdvisorCode        ::VARCHAR(200) AS NO_AGENT,
        POL.AgencyNumber       ::VARCHAR(200) AS CODE_DISTRICT,
        POL.ServiceUnitNumber  ::VARCHAR(200) AS CODE_US,
        FPIS.AgentType         ::VARCHAR(200) AS Code_Type_Agent, --carriere ou ordinaire 
        MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT
 FROM DB_AV_DEV_STG.PSA.VW_FLATTEN_POLICY POL
 LEFT JOIN DB_AV_DEV_STG.PSA.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
             ON FPIS.correlationid = POL.correlationid
             AND FPIS.PartyID = POL.PartyID
 WHERE COALESCE(POL.AdvisorCode,'N/A') = COALESCE(FPIS.AgentCode,'N/A')
)
SELECT DISTINCT NO_POLICE,
       COUVERTURE_ID,
       NO_AGENT,
       CODE_DISTRICT,
       CODE_US,
       CODE_TYPE_AGENT,
       '' ::VARCHAR(200) AS CODE_EQUIPE --n'existe pas dans OIPA
FROM  _cohorte;
create or replace view VW_OIPA_COHORTE_ASSURE(
	NO_POLICE,
	CD_COMPAGNIE,
	COUVERTURE_ID,
	CD_PLAN,
	NO_PHASE,
	NO_SOUS_PHASE,
	NO_ASSURE,
	NO_CONJOINT,
	IND_EQUIVALENT,
	AGE_EMISSION,
	DATE_NAISSANCE,
	CD_SEXE,
	CD_ST_FUMEUR
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une police de l''event ACTIVATED'
 as
SELECT DISTINCT     VW_BRUTE.POLICYNUMBER                   AS No_Police,
                    0					    AS Cd_Compagnie,
                    VW_BRUTE.COVERAGEIDENTIFIER             AS Couverture_ID, 
                    co.CD_PLAN                              AS Cd_Plan, --modif
                    CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER) AS No_Phase,
                    1	                                AS No_Sous_Phase,
                    1                                       AS No_Assure,
                    -4                                      AS No_Conjoint,
                    0                                       AS Ind_Equivalent,
                    TRY_CAST(VW_BRUTE.ISSUEAGE AS INTEGER)  AS Age_Emission,
                    VW_BRUTE.CLIENTDATEOFBIRTH              AS Date_Naissance,
                    NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.UNDERWRITINGGENDER     ||' non trouvé') AS Cd_Sexe,
                    NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.TOBACCOUSE             ||' non trouvé') AS Cd_St_Fumeur         
FROM DB_AV_DEV_STG.PSA."VW_FLATTEN_POLICY" VW_BRUTE

LEFT JOIN DB_AV_DEV_DWH.BDV.VW_OIPA_COHORTE_COUVERTURE co 
       ON co.NO_POLICE = VW_BRUTE.POLICYNUMBER 
      AND co.COUVERTURE_ID = VW_BRUTE.COVERAGEIDENTIFIER

LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeTobaccoUse' 
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.TOBACCOUSE

LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeGender' 
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.UNDERWRITINGGENDER;
create or replace view VW_OIPA_COHORTE_ASSURE_TEST(
	NO_POLICE,
	CD_COMPAGNIE,
	COUVERTURE_ID,
	CD_PLAN,
	NO_PHASE,
	NO_SOUS_PHASE,
	NO_ASSURE,
	NO_CONJOINT,
	IND_EQUIVALENT,
	AGE_EMISSION,
	DATE_NAISSANCE,
	CD_SEXE,
	CD_ST_FUMEUR
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une police de l''event ACTIVATED'
 as
SELECT DISTINCT     VW_BRUTE.POLICYNUMBER                   AS No_Police,
                    0					    AS Cd_Compagnie,
                    VW_BRUTE.COVERAGEIDENTIFIER             AS Couverture_ID, 
                    co.CD_PLAN                              AS Cd_Plan, --modif
                    CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER) AS No_Phase,
                    1	                                AS No_Sous_Phase,
                    1                                       AS No_Assure,
                    -4                                      AS No_Conjoint,
                    0                                       AS Ind_Equivalent,
                    TRY_CAST(VW_BRUTE.ISSUEAGE AS INTEGER)  AS Age_Emission,
                    VW_BRUTE.CLIENTDATEOFBIRTH              AS Date_Naissance,
                    NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.UNDERWRITINGGENDER     ||' non trouvé') AS Cd_Sexe,
                    IFF((Age_Emission < 15 AND VW_BRUTE.TOBACCOUSE = '03' ),'2',NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.TOBACCOUSE             ||' non trouvé')) AS Cd_St_Fumeur         
FROM "DB_AV_DEV_STG"."PSA"."VW_FLATTEN_POLICY" VW_BRUTE

LEFT JOIN "DB_AV_DEV_DWH"."BDV_CLONE_IB".VW_OIPA_COHORTE_COUVERTURE co 
       ON co.NO_POLICE = VW_BRUTE.POLICYNUMBER 
      AND co.COUVERTURE_ID = VW_BRUTE.COVERAGEIDENTIFIER

LEFT JOIN "DB_AV_DEV_STG"."PSA".VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeTobaccoUse' 
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.TOBACCOUSE

LEFT JOIN "DB_AV_DEV_STG"."PSA".VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeGender' 
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.UNDERWRITINGGENDER ;
create or replace view VW_OIPA_COHORTE_COUVERTURE(
	NO_POLICE,
	COUVERTURE_ID,
	NO_COUVERTURE,
	FKID_PRODUIT,
	VERSION_PRODUIT_OIPA,
	VERSION_PROTECTION_OIPA,
	DATE_REFERENCE_TAUX_OIPA,
	CD_ST_COUVERTURE_TRAD,
	CD_ST_RAISON_COUVERTURE_TRAD,
	CD_CONJOINT,
	MNT_FRAIS,
	CAPITAL_ASSURE_COURANT,
	NB_UNITE,
	VALEUR_UNITE,
	MNT_PRIME_ANNUELLE,
	DT_LIBERATION,
	DT_EXPIRATION,
	INITIALTERMDURATION,
	MNT_PRIME_REMB_ABANDON,
	MNT_PRIME_REMB_DECES,
	CD_TYPE_EMISSION,
	DT_EMISSION_COUVERTURE,
	CD_BANDE_FORCE,
	CD_PLAN,
	DATE_VERSION
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une couverture de l''event ACTIVATED.'
 as
SELECT DISTINCT VW_BRUTE.POLICYNUMBER                          ::VARCHAR(200)   AS NO_POLICE,
       VW_BRUTE.COVERAGEIDENTIFIER                             ::VARCHAR(200)   AS COUVERTURE_ID, 
       CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER)                                  AS NO_COUVERTURE,
       PL.ID_CORRESPONDANCE_CODE_PLAN                                           AS FKID_PRODUIT,
       VW_BRUTE.PRODUCTVERSIONCODE                             ::VARCHAR(200)   AS VERSION_PRODUIT_OIPA, 
       VW_BRUTE.COVERAGEVERSIONCODE                            ::VARCHAR(200)   AS VERSION_PROTECTION_OIPA,
       TRY_CAST(VW_BRUTE.RATESREFERENCEDATE AS DATE)                            AS DATE_REFERENCE_TAUX_OIPA,
       NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESTATUS     ||' non trouvé') ::VARCHAR(200) AS CD_ST_COUVERTURE_TRAD,
       NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESUBSTATUS  ||' non trouvé') ::VARCHAR(200) AS CD_ST_RAISON_COUVERTURE_TRAD,
       1         		        	                                      AS CD_CONJOINT,
       CAST(VW_BRUTE.DISTRIBUTEDPOLICYFEES AS NUMERIC(9,2))                     AS MNT_FRAIS,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT AS NUMERIC(9,0))                         AS CAPITAL_ASSURE_COURANT,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT / 1000 AS NUMERIC(9,0))                  AS NB_UNITE,
       1000					                                      AS VALEUR_UNITE,
       CAST(VW_BRUTE.COVERAGEANNUALPREMIUM AS  NUMERIC(9,2))                    AS MNT_PRIME_ANNUELLE,
       NVL(VW_BRUTE.PAIDUPDATE,  VW_BRUTE.EXPIRYDATE)          ::DATE           AS DT_LIBERATION,
       NVL(NVL(VW_BRUTE.EXPIRYDATE, VW_BRUTE.MATURITYDATE), VW_BRUTE.PAIDUPDATE) ::VARCHAR(200)   AS DT_EXPIRATION,
       TRY_CAST(VW_BRUTE.INITIALTERMDURATION AS INTEGER)                        AS INITIALTERMDURATION,
       0.00				                                             AS MNT_PRIME_REMB_ABANDON,
       0.00				                                             AS MNT_PRIME_REMB_DECES,
       -1	      			                                             AS CD_TYPE_EMISSION,
       VW_BRUTE.COVERAGEEFFECTIVEDATE                          ::DATE           AS DT_EMISSION_COUVERTURE,
       -1  	                                                 ::NUMERIC(1,0)   AS CD_BANDE_FORCE,
       PL.PDF_PLAN_NAME     		                                      AS CD_PLAN,
       PL.PDF_VERSION_DATE 			                     ::VARCHAR(200)   AS DATE_VERSION

FROM      DB_AV_DEV_STG.PSA."VW_FLATTEN_POLICY" VW_BRUTE 

LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeSubstatus'
      AND dom1.CODE_NAME_CIBLE = 'CdStatutCouverture'
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESTATUS
    				       																			
LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
      AND dom2.CODE_NAME_CIBLE = 'CdStatutRaisonCouverture'					   															
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESUBSTATUS
				   
LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_CODE_PLAN  PL 
       ON PL.PRODUCT_VERSION_CODE  = VW_BRUTE.PRODUCTVERSIONCODE 
      AND PL.COVERAGE_VERSION_CODE  = VW_BRUTE.COVERAGEVERSIONCODE 
      AND PL.RATES_REFERENCE_DATE = VW_BRUTE.RATESREFERENCEDATE;
create or replace view VW_OIPA_COHORTE_POLICE(
	NO_POLICE,
	CD_COMPAGNIE,
	CD_ST_POLICE,
	CD_ST_RAISON_POLICE,
	CD_DEVISE,
	NO_AGENT,
	CD_DISTRICT,
	CODE_TYPE_AGENT,
	CD_PROVINCE,
	CD_COUNTRY,
	CD_FREQUENCE_PAIEMENT,
	IND_PARTICIPATION,
	COUT_BASE_REAJUSTE,
	MNT_BALANCE_PRET,
	FACTEUR_MODAL,
	CD_US,
	CD_EQUIPE,
	CD_SOURCE,
	CD_TYPE_PAIEMENT,
	MNT_VALEUR_RACHAT,
	DT_CHARGEMENT
) COMMENT='VUE POLICE D''ASSURANCE QUI CONTIENT LE DERNIER ENREGISTREMENT REÇU POUR UNE POLICE DE L''EVENT ACTIVATED'
 as
WITH _COHORTEINI AS (
                     SELECT * FROM (
                                    SELECT POL.POLICYNUMBER                  AS POLICY_NUMBER,
                                           POL.POLICYSTATUS                  AS POLICY_STATUS,
                                           POL.POLICYSUBSTATUS               AS POLICY_SUBSTATUS,
                                           POL.POLICYCURRENCY                AS POLICY_CURRENCY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS POLICY_OWNER_RESIDENCE_STATE,
                                           POL.ISSUESTATE                    AS ISSUE_STATE,
                                           POL.PAYMENTFREQUENCY              AS PAYMENT_FREQUENCY,
                                           POL.POLICYACB                     AS POLICY_ACB,
                                           POL.PAYMENTMETHOD                 AS PAYMENT_METHOD,
                                           POL.MD_DTCHARGEMENT::TIMESTAMPLTZ AS MD_DTCHARGEMENT,
                                           POL.ADVISORCODE                   AS NO_AGENT,
                                           'CA'                              AS COUNTRY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS PROVINCE,
                                           POL.AGENCYNUMBER                  AS CODE_DISTRICT,
                                           FPIS.AGENTTYPE                    AS CODE_TYPE_AGENT,
   	                                    POL.SERVICEUNITNUMBER             AS CODE_US,
                                           POL.CLIENTDATEOFBIRTH             AS CLIENT_DATE_OF_BIRTH,
                       	               MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT, 
                                           ROW_number() OVER (PARTITION BY pol.PolicyNumber ORDER BY Code_Type_Agent ASC, pol.Agent DESC, CASE WHEN UPPER(POL.POLICYOWNERCORRESPONDENCEINDICATOR) in ('TRUE','1') THEN 1 ELSE 0 END DESC, POL.PARTYID ASC) NB
                                    FROM DB_AV_DEV_STG.PSA.VW_FLATTEN_POLICY POL
                                    LEFT JOIN DB_AV_DEV_STG.PSA.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
                                                 ON FPIS.correlationid = POL.correlationid
                                                 AND FPIS.PartyID = POL.PartyID
                                    ) t 
                                    WHERE NB = 1 
),  
   _COHORTE_DOMAINEVALEUR AS (
                              SELECT POLICY_NUMBER,
                                     POLICY_CURRENCY,
                                     POLICY_ACB,
                                     ISSUE_STATE,
                                     POLICY_OWNER_RESIDENCE_STATE,
                                     NO_AGENT,
                                     CODE_TYPE_AGENT,
                                     CODE_DISTRICT,
                                     CODE_US,
                                     CLIENT_DATE_OF_BIRTH,
                                     COUNTRY,           
                                     NVL(DOM1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_STATUS     ||' non trouvé') AS CDSTPOLICE,
                                     NVL(DOM2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_SUBSTATUS  ||' non trouvé') AS CDSTRAISONPOLICE,
                                     NVL(DOM3.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_FREQUENCY ||' non trouvé') AS CDFREQUENCEPAIEMENT,
                                     NVL(DOM4.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_METHOD    ||' non trouvé') AS CDTYPEPAIEMENT,
                                     NVL(DOM5.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PROVINCE          ||' non trouvé') AS PROVINCE,
                                     MAX_MD_DTCHARGEMENT AS DT_CHARGEMENT
                               FROM _COHORTEINI 

                          LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
                                 ON DOM1.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
    				    AND DOM1.CODE_NAME_CIBLE  = 'CdStatutPolice'
    				    AND DOM1.CODE_VALEUR_SOURCE = POLICY_STATUS
    																				
			     LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
                                 ON DOM2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
			           AND DOM2.CODE_NAME_CIBLE  = 'CdStatutRaisonPolice'
				    AND DOM2.CODE_VALEUR_SOURCE = POLICY_SUBSTATUS
								
                	     LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM3 
                                 ON DOM3.CODE_NAME_SOURCE = 'AsCodePaymentFrequency' 
                                AND DOM3.CODE_VALEUR_SOURCE = PAYMENT_FREQUENCY
     
                          LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM4 
                                 ON DOM4.CODE_NAME_SOURCE = 'AsCodePaymentMethod' 
                                AND DOM4.CODE_VALEUR_SOURCE = PAYMENT_METHOD
     
		            LEFT JOIN DB_AV_DEV_STG.PSA.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM5 
                                 ON DOM5.CODE_NAME_SOURCE = 'AsCodeState' 
                                AND DOM5.CODE_VALEUR_SOURCE = PROVINCE
),

-----------------------------------------------------------------------------------
--CERTAINES COLONNE NE SONT PAS FOURNIES PAR OIPA MAIS SONT NÉCESSAIRES POUR XA.
--CETTE COHORTE CORRESPOND AUX CHAMPS IDENTIFIÉS DANS LA TABLE SVDVIEV_POLICE_TRAD
-----------------------------------------------------------------------------------

   _COHORTE AS (
                SELECT POLICY_NUMBER 	                     ::VARCHAR(200) AS NO_POLICE,
                       0                                                      AS CD_COMPAGNIE,
                       CDSTPOLICE                              ::VARCHAR(200) AS CD_ST_POLICE,
                       CDSTRAISONPOLICE	                     ::VARCHAR(200) AS CD_ST_RAISON_POLICE,           
                       POLICY_CURRENCY	                     ::VARCHAR(200) AS CD_DEVISE,
                       NO_AGENT                                ::VARCHAR(200) AS NO_AGENT,
                       CODE_DISTRICT                           ::VARCHAR(200) AS CD_DISTRICT,
                       CODE_TYPE_AGENT                         ::VARCHAR(200) AS CODE_TYPE_AGENT,
                       PROVINCE		                     ::VARCHAR(200) AS CD_PROVINCE,
                       COUNTRY		                     ::VARCHAR(200) AS CD_COUNTRY,
                       CDFREQUENCEPAIEMENT                                    AS CD_FREQUENCE_PAIEMENT,
                       0                                                      AS IND_PARTICIPATION,
                       TRY_CAST(POLICY_ACB AS DECIMAL(9,2))                   AS COUT_BASE_REAJUSTE,
                       0.00			                                    AS MNT_BALANCE_PRET,
                       CAST(1.08000 AS DECIMAL(9,2))                          AS FACTEUR_MODAL,
                       CODE_US                                 ::VARCHAR(200) AS CD_US,
                       NULL                                    ::VARCHAR(200) AS CD_EQUIPE,
                       -1                                                     AS CD_SOURCE,
                       CDTYPEPAIEMENT	                     ::VARCHAR(200) AS CD_TYPE_PAIEMENT,
                     --A VENIR EN ATTENTE DE OIPA - il n'y pas de valeur de rachat avant 5 ans.'
                       CAST(0 AS DECIMAL(9,2))                                AS MNT_VALEUR_RACHAT,
                       DT_CHARGEMENT
                FROM _COHORTE_DOMAINEVALEUR
)

SELECT * FROM _COHORTE;
create or replace view VW_SAT_POLICY_CLEAN(
	HK_HUB_POLICY,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_START_DT,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	PRODUCT_CODE,
	PRODUCT_VERSION_CODE,
	POLICY_OWNER_RESIDENCE_STATE,
	POLICY_YEAR,
	POLICY_CURRENCY,
	ISSUE_STATE,
	POLICY_EFFECTIVE_DATE,
	LAST_REINSTATEMENT_DATE,
	POLICY_STATUS,
	POLICY_SUB_STATUS,
	PAYMENT_FREQUENCY,
	NEXT_PREMIUM_DUE_DATE,
	PAYMENT_METHOD,
	BILLING_STATUS,
	PAID_TO_DATE,
	BILLING_INTERRUPTION_REASON,
	ANTICIPATE_BILLING_RESUME_DATE,
	POLICY_ACB,
	POLICY_ACB_MODAL_PREMIUM,
	POLICY_ACB_PREMIUM_ITD,
	POLICY_ANNUAL_PREMIUM,
	POLICY_MODAL_PREMIUM,
	ANNUAL_POLICY_FEES,
	MODAL_POLICY_FEES
) as
SELECT *
--,convert_timezone('America/Montreal', POLICY_EFFECTIVE_DATE)::timestamp_ntz as NTZ_POLICY_EFFECTIVE_DATE
FROM DB_AV_DEV_DWH.RDV.SAT_POLICY;
create or replace schema BDV_CLONE_IB_PT;

create or replace view VW_OIPA_COHORTE_AGENT(
	NO_POLICE,
	COUVERTURE_ID,
	NO_AGENT,
	CODE_DISTRICT,
	CODE_US,
	CODE_TYPE_AGENT,
	CODE_EQUIPE
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement d''agent de l''event ACTIVATED'
 as
WITH 
_cohorte AS (
  SELECT  
        POL.POLICYNUMBER       ::VARCHAR(200) AS NO_POLICE,
        POL.COVERAGEIDENTIFIER ::VARCHAR(200) AS COUVERTURE_ID,
        POL.AdvisorCode        ::VARCHAR(200) AS NO_AGENT,
        POL.AgencyNumber       ::VARCHAR(200) AS CODE_DISTRICT,
        POL.ServiceUnitNumber  ::VARCHAR(200) AS CODE_US,
        FPIS.AgentType         ::VARCHAR(200) AS Code_Type_Agent, --carriere ou ordinaire 
        MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT
 FROM DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_FLATTEN_POLICY POL
 LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
             ON FPIS.correlationid = POL.correlationid
             AND FPIS.PartyID = POL.PartyID
 WHERE COALESCE(POL.AdvisorCode,'N/A') = COALESCE(FPIS.AgentCode,'N/A')
)
SELECT DISTINCT NO_POLICE,
       COUVERTURE_ID,
       NO_AGENT,
       CODE_DISTRICT,
       CODE_US,
       CODE_TYPE_AGENT,
       '' ::VARCHAR(200) AS CODE_EQUIPE --n'existe pas dans OIPA
FROM  _cohorte;
create or replace view VW_OIPA_COHORTE_ASSURE(
	NO_POLICE,
	CD_COMPAGNIE,
	COUVERTURE_ID,
	CD_PLAN,
	NO_PHASE,
	NO_SOUS_PHASE,
	NO_ASSURE,
	NO_CONJOINT,
	IND_EQUIVALENT,
	AGE_EMISSION,
	DATE_NAISSANCE,
	CD_SEXE,
	CD_ST_FUMEUR
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une police de l''event ACTIVATED'
 as
SELECT DISTINCT     VW_BRUTE.POLICYNUMBER                   AS No_Police,
                    0					    AS Cd_Compagnie,
                    VW_BRUTE.COVERAGEIDENTIFIER             AS Couverture_ID, 
                    co.CD_PLAN                              AS Cd_Plan, --modif
                    CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER) AS No_Phase,
                    1	                                AS No_Sous_Phase,
                    1                                       AS No_Assure,
                    -4                                      AS No_Conjoint,
                    0                                       AS Ind_Equivalent,
                    TRY_CAST(VW_BRUTE.ISSUEAGE AS INTEGER)  AS Age_Emission,
                    VW_BRUTE.CLIENTDATEOFBIRTH              AS Date_Naissance,
                    NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.UNDERWRITINGGENDER     ||' non trouvé') AS Cd_Sexe,
                    IFF((Age_Emission < 15 AND VW_BRUTE.TOBACCOUSE = '03' ),'2',NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.TOBACCOUSE             ||' non trouvé')) AS Cd_St_Fumeur         
FROM DB_AV_DEV_STG.PSA_CLONE_IB_PT."VW_FLATTEN_POLICY" VW_BRUTE

LEFT JOIN DB_AV_DEV_DWH.BDV_CLONE_IB_PT.VW_OIPA_COHORTE_COUVERTURE co 
       ON co.NO_POLICE = VW_BRUTE.POLICYNUMBER 
      AND co.COUVERTURE_ID = VW_BRUTE.COVERAGEIDENTIFIER

LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeTobaccoUse' 
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.TOBACCOUSE

LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeGender' 
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.UNDERWRITINGGENDER;
create or replace view VW_OIPA_COHORTE_COUVERTURE(
	NO_POLICE,
	COUVERTURE_ID,
	NO_COUVERTURE,
	FKID_PRODUIT,
	VERSION_PRODUIT_OIPA,
	VERSION_PROTECTION_OIPA,
	DATE_REFERENCE_TAUX_OIPA,
	CD_ST_COUVERTURE_TRAD,
	CD_ST_RAISON_COUVERTURE_TRAD,
	CD_CONJOINT,
	MNT_FRAIS,
	CAPITAL_ASSURE_COURANT,
	NB_UNITE,
	VALEUR_UNITE,
	MNT_PRIME_ANNUELLE,
	DT_LIBERATION,
	DT_EXPIRATION,
	INITIALTERMDURATION,
	MNT_PRIME_REMB_ABANDON,
	MNT_PRIME_REMB_DECES,
	CD_TYPE_EMISSION,
	DT_EMISSION_COUVERTURE,
	CD_BANDE_FORCE,
	CD_PLAN,
	DATE_VERSION
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une couverture de l''event ACTIVATED.'
 as
SELECT DISTINCT VW_BRUTE.POLICYNUMBER                          ::VARCHAR(200)   AS NO_POLICE,
       VW_BRUTE.COVERAGEIDENTIFIER                             ::VARCHAR(200)   AS COUVERTURE_ID, 
       CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER)                                  AS NO_COUVERTURE,
       PL.ID_CORRESPONDANCE_CODE_PLAN                                           AS FKID_PRODUIT,
       VW_BRUTE.PRODUCTVERSIONCODE                             ::VARCHAR(200)   AS VERSION_PRODUIT_OIPA, 
       VW_BRUTE.COVERAGEVERSIONCODE                            ::VARCHAR(200)   AS VERSION_PROTECTION_OIPA,
       TRY_CAST(VW_BRUTE.RATESREFERENCEDATE AS DATE)                            AS DATE_REFERENCE_TAUX_OIPA,
       NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESTATUS     ||' non trouvé') ::VARCHAR(200) AS CD_ST_COUVERTURE_TRAD,
       NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESUBSTATUS  ||' non trouvé') ::VARCHAR(200) AS CD_ST_RAISON_COUVERTURE_TRAD,
       1         		        	                                      AS CD_CONJOINT,
       CAST(VW_BRUTE.DISTRIBUTEDPOLICYFEES AS NUMERIC(9,2))                     AS MNT_FRAIS,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT AS NUMERIC(9,0))                         AS CAPITAL_ASSURE_COURANT,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT / 1000 AS NUMERIC(9,0))                  AS NB_UNITE,
       1000					                                      AS VALEUR_UNITE,
       CAST(VW_BRUTE.COVERAGEANNUALPREMIUM AS  NUMERIC(9,2))                    AS MNT_PRIME_ANNUELLE,
       NVL(VW_BRUTE.PAIDUPDATE,  VW_BRUTE.EXPIRYDATE)          ::DATE           AS DT_LIBERATION,
       NVL(NVL(VW_BRUTE.EXPIRYDATE, VW_BRUTE.MATURITYDATE), VW_BRUTE.PAIDUPDATE) ::VARCHAR(200)   AS DT_EXPIRATION,
       TRY_CAST(VW_BRUTE.INITIALTERMDURATION AS INTEGER)                        AS INITIALTERMDURATION,
       0.00				                                             AS MNT_PRIME_REMB_ABANDON,
       0.00				                                             AS MNT_PRIME_REMB_DECES,
       -1	      			                                             AS CD_TYPE_EMISSION,
       VW_BRUTE.COVERAGEEFFECTIVEDATE                          ::DATE           AS DT_EMISSION_COUVERTURE,
       -1  	                                                 ::NUMERIC(1,0)   AS CD_BANDE_FORCE,
       PL.PDF_PLAN_NAME     		                                      AS CD_PLAN,
       PL.PDF_VERSION_DATE 			                     ::VARCHAR(200)   AS DATE_VERSION

FROM      DB_AV_DEV_STG.PSA_CLONE_IB_PT."VW_FLATTEN_POLICY" VW_BRUTE 

LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeSubstatus'
      AND dom1.CODE_NAME_CIBLE = 'CdStatutCouverture'
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESTATUS
    				       																			
LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
      AND dom2.CODE_NAME_CIBLE = 'CdStatutRaisonCouverture'					   															
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESUBSTATUS
				   
LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_CODE_PLAN  PL 
       ON PL.PRODUCT_VERSION_CODE  = VW_BRUTE.PRODUCTVERSIONCODE 
      AND PL.COVERAGE_VERSION_CODE  = VW_BRUTE.COVERAGEVERSIONCODE 
      AND PL.RATES_REFERENCE_DATE = VW_BRUTE.RATESREFERENCEDATE;
create or replace view VW_OIPA_COHORTE_POLICE(
	NO_POLICE,
	CD_COMPAGNIE,
	CD_ST_POLICE,
	CD_ST_RAISON_POLICE,
	CD_DEVISE,
	NO_AGENT,
	CD_DISTRICT,
	CODE_TYPE_AGENT,
	CD_PROVINCE,
	CD_COUNTRY,
	CD_FREQUENCE_PAIEMENT,
	IND_PARTICIPATION,
	COUT_BASE_REAJUSTE,
	MNT_BALANCE_PRET,
	FACTEUR_MODAL,
	CD_US,
	CD_EQUIPE,
	CD_SOURCE,
	CD_TYPE_PAIEMENT,
	MNT_VALEUR_RACHAT,
	DT_CHARGEMENT
) COMMENT='VUE POLICE D''ASSURANCE QUI CONTIENT LE DERNIER ENREGISTREMENT REÇU POUR UNE POLICE DE L''EVENT ACTIVATED'
 as
WITH _COHORTEINI AS (
                     SELECT * FROM (
                                    SELECT POL.POLICYNUMBER                  AS POLICY_NUMBER,
                                           POL.POLICYSTATUS                  AS POLICY_STATUS,
                                           POL.POLICYSUBSTATUS               AS POLICY_SUBSTATUS,
                                           POL.POLICYCURRENCY                AS POLICY_CURRENCY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS POLICY_OWNER_RESIDENCE_STATE,
                                           POL.ISSUESTATE                    AS ISSUE_STATE,
                                           POL.PAYMENTFREQUENCY              AS PAYMENT_FREQUENCY,
                                           POL.POLICYACB                     AS POLICY_ACB,
                                           POL.PAYMENTMETHOD                 AS PAYMENT_METHOD,
                                           POL.MD_DTCHARGEMENT::TIMESTAMPLTZ AS MD_DTCHARGEMENT,
                                           POL.ADVISORCODE                   AS NO_AGENT,
                                           'CA'                              AS COUNTRY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS PROVINCE,
                                           POL.AGENCYNUMBER                  AS CODE_DISTRICT,
                                           FPIS.AGENTTYPE                    AS CODE_TYPE_AGENT,
   	                                    POL.SERVICEUNITNUMBER             AS CODE_US,
                                           POL.CLIENTDATEOFBIRTH             AS CLIENT_DATE_OF_BIRTH,
                       	               MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT, 
                                           ROW_number() OVER (PARTITION BY pol.PolicyNumber ORDER BY Code_Type_Agent ASC, pol.Agent DESC, CASE WHEN UPPER(POL.POLICYOWNERCORRESPONDENCEINDICATOR) in ('TRUE','1') THEN 1 ELSE 0 END DESC, POL.PARTYID ASC) NB
                                    FROM DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_FLATTEN_POLICY POL
                                    LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
                                                 ON FPIS.correlationid = POL.correlationid
                                                 AND FPIS.PartyID = POL.PartyID
                                    ) t 
                                    WHERE NB = 1 
),  
   _COHORTE_DOMAINEVALEUR AS (
                              SELECT POLICY_NUMBER,
                                     POLICY_CURRENCY,
                                     POLICY_ACB,
                                     ISSUE_STATE,
                                     POLICY_OWNER_RESIDENCE_STATE,
                                     NO_AGENT,
                                     CODE_TYPE_AGENT,
                                     CODE_DISTRICT,
                                     CODE_US,
                                     CLIENT_DATE_OF_BIRTH,
                                     COUNTRY,           
                                     NVL(DOM1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_STATUS     ||' non trouvé') AS CDSTPOLICE,
                                     NVL(DOM2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_SUBSTATUS  ||' non trouvé') AS CDSTRAISONPOLICE,
                                     NVL(DOM3.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_FREQUENCY ||' non trouvé') AS CDFREQUENCEPAIEMENT,
                                     NVL(DOM4.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_METHOD    ||' non trouvé') AS CDTYPEPAIEMENT,
                                     NVL(DOM5.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PROVINCE          ||' non trouvé') AS PROVINCE,
                                     MAX_MD_DTCHARGEMENT AS DT_CHARGEMENT
                               FROM _COHORTEINI 

                          LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
                                 ON DOM1.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
    				    AND DOM1.CODE_NAME_CIBLE  = 'CdStatutPolice'
    				    AND DOM1.CODE_VALEUR_SOURCE = POLICY_STATUS
    																				
			     LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
                                 ON DOM2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
			           AND DOM2.CODE_NAME_CIBLE  = 'CdStatutRaisonPolice'
				    AND DOM2.CODE_VALEUR_SOURCE = POLICY_SUBSTATUS
								
                	     LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM3 
                                 ON DOM3.CODE_NAME_SOURCE = 'AsCodePaymentFrequency' 
                                AND DOM3.CODE_VALEUR_SOURCE = PAYMENT_FREQUENCY
     
                          LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM4 
                                 ON DOM4.CODE_NAME_SOURCE = 'AsCodePaymentMethod' 
                                AND DOM4.CODE_VALEUR_SOURCE = PAYMENT_METHOD
     
		            LEFT JOIN DB_AV_DEV_STG.PSA_CLONE_IB_PT.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM5 
                                 ON DOM5.CODE_NAME_SOURCE = 'AsCodeState' 
                                AND DOM5.CODE_VALEUR_SOURCE = PROVINCE
),

-----------------------------------------------------------------------------------
--CERTAINES COLONNE NE SONT PAS FOURNIES PAR OIPA MAIS SONT NÉCESSAIRES POUR XA.
--CETTE COHORTE CORRESPOND AUX CHAMPS IDENTIFIÉS DANS LA TABLE SVDVIEV_POLICE_TRAD
-----------------------------------------------------------------------------------

   _COHORTE AS (
                SELECT POLICY_NUMBER 	                     ::VARCHAR(200) AS NO_POLICE,
                       0                                                      AS CD_COMPAGNIE,
                       CDSTPOLICE                              ::VARCHAR(200) AS CD_ST_POLICE,
                       CDSTRAISONPOLICE	                     ::VARCHAR(200) AS CD_ST_RAISON_POLICE,           
                       POLICY_CURRENCY	                     ::VARCHAR(200) AS CD_DEVISE,
                       NO_AGENT                                ::VARCHAR(200) AS NO_AGENT,
                       CODE_DISTRICT                           ::VARCHAR(200) AS CD_DISTRICT,
                       CODE_TYPE_AGENT                         ::VARCHAR(200) AS CODE_TYPE_AGENT,
                       PROVINCE		                     ::VARCHAR(200) AS CD_PROVINCE,
                       COUNTRY		                     ::VARCHAR(200) AS CD_COUNTRY,
                       CDFREQUENCEPAIEMENT                                    AS CD_FREQUENCE_PAIEMENT,
                       0                                                      AS IND_PARTICIPATION,
                       TRY_CAST(POLICY_ACB AS DECIMAL(9,2))                   AS COUT_BASE_REAJUSTE,
                       0.00			                                    AS MNT_BALANCE_PRET,
                       CAST(1.08000 AS DECIMAL(9,2))                          AS FACTEUR_MODAL,
                       CODE_US                                 ::VARCHAR(200) AS CD_US,
                       NULL                                    ::VARCHAR(200) AS CD_EQUIPE,
                       -1                                                     AS CD_SOURCE,
                       CDTYPEPAIEMENT	                     ::VARCHAR(200) AS CD_TYPE_PAIEMENT,
                     --A VENIR EN ATTENTE DE OIPA - il n'y pas de valeur de rachat avant 5 ans.'
                       CAST(0 AS DECIMAL(9,2))                                AS MNT_VALEUR_RACHAT,
                       DT_CHARGEMENT
                FROM _COHORTE_DOMAINEVALEUR
)

SELECT * FROM _COHORTE;
create or replace view VW_SAT_POLICY_CLEAN(
	HK_HUB_POLICY,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_START_DT,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	PRODUCT_CODE,
	PRODUCT_VERSION_CODE,
	POLICY_OWNER_RESIDENCE_STATE,
	POLICY_YEAR,
	POLICY_CURRENCY,
	ISSUE_STATE,
	POLICY_EFFECTIVE_DATE,
	LAST_REINSTATEMENT_DATE,
	POLICY_STATUS,
	POLICY_SUB_STATUS,
	PAYMENT_FREQUENCY,
	NEXT_PREMIUM_DUE_DATE,
	PAYMENT_METHOD,
	BILLING_STATUS,
	PAID_TO_DATE,
	BILLING_INTERRUPTION_REASON,
	ANTICIPATE_BILLING_RESUME_DATE,
	POLICY_ACB,
	POLICY_ACB_MODAL_PREMIUM,
	POLICY_ACB_PREMIUM_ITD,
	POLICY_ANNUAL_PREMIUM,
	POLICY_MODAL_PREMIUM,
	ANNUAL_POLICY_FEES,
	MODAL_POLICY_FEES
) as
SELECT *
--,convert_timezone('America/Montreal', POLICY_EFFECTIVE_DATE)::timestamp_ntz as NTZ_POLICY_EFFECTIVE_DATE
FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_POLICY;
create or replace schema BDV_SILO_0;

create or replace TABLE CLEAN_SAT_POLICY (
	HK_HUB_POLICY_CLEAN VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_EVENT_TYPE VARCHAR(100),
	PRODUCT_CODE VARCHAR(50),
	PRODUCT_VERSION_CODE VARCHAR(50),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(4),
	ISSUE_STATE VARCHAR(4),
	POLICY_EFFECTIVE_DATE DATE,
	LAST_REINSTATEMENT_DATE DATE,
	POLICY_STATUS VARCHAR(2),
	POLICY_SUB_STATUS VARCHAR(2),
	PAYEMENT_FREQUENCY VARCHAR(2),
	NEXT_PREMIUM_DUE_DATE DATE,
	PAYMENT_METHOD VARCHAR(2),
	BILLING_STATUS VARCHAR(2),
	PAID_TO_DATE DATE,
	BILLING_SUSPENSION_REASON VARCHAR(255),
	BILLING_SUSPENSION_REQUESTOR VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE DATE,
	POLICY_ACB NUMBER(19,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(19,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(19,2),
	POLICY_ANNUAL_PREMIUM NUMBER(19,2),
	POLICY_MODAL_PREMIUM NUMBER(19,2),
	ANNUAL_POLICY_FEES NUMBER(19,2),
	MODAL_POLICY_FEES NUMBER(19,2),
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_POLICY_CLEAN primary key (HK_HUB_POLICY_CLEAN, MD_START_DT)
);
create or replace view VW_OIPA_COHORTE_AGENT(
	NO_POLICE,
	COUVERTURE_ID,
	NO_AGENT,
	CODE_DISTRICT,
	CODE_US,
	CODE_TYPE_AGENT,
	CODE_EQUIPE
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement d''agent de l''event ACTIVATED'
 as
WITH 
_cohorte AS (
  SELECT  
        POL.POLICYNUMBER       ::VARCHAR(200) AS NO_POLICE,
        POL.COVERAGEIDENTIFIER ::VARCHAR(200) AS COUVERTURE_ID,
        POL.AdvisorCode        ::VARCHAR(200) AS NO_AGENT,
        POL.AgencyNumber       ::VARCHAR(200) AS CODE_DISTRICT,
        POL.ServiceUnitNumber  ::VARCHAR(200) AS CODE_US,
        FPIS.AgentType         ::VARCHAR(200) AS Code_Type_Agent, --carriere ou ordinaire 
        MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT
 FROM DB_AV_DEV_STG.PSA_SILO_0.VW_FLATTEN_POLICY POL
 LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
             ON FPIS.correlationid = POL.correlationid
             AND FPIS.PartyID = POL.PartyID
 WHERE COALESCE(POL.AdvisorCode,'N/A') = COALESCE(FPIS.AgentCode,'N/A')
)
SELECT DISTINCT NO_POLICE,
       COUVERTURE_ID,
       NO_AGENT,
       CODE_DISTRICT,
       CODE_US,
       CODE_TYPE_AGENT,
       '' ::VARCHAR(200) AS CODE_EQUIPE --n'existe pas dans OIPA
FROM  _cohorte;
create or replace view VW_OIPA_COHORTE_ASSURE(
	NO_POLICE,
	CD_COMPAGNIE,
	COUVERTURE_ID,
	CD_PLAN,
	NO_PHASE,
	NO_SOUS_PHASE,
	NO_ASSURE,
	NO_CONJOINT,
	IND_EQUIVALENT,
	AGE_EMISSION,
	DATE_NAISSANCE,
	CD_SEXE,
	CD_ST_FUMEUR
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une police de l''event ACTIVATED'
 as
SELECT DISTINCT     VW_BRUTE.POLICYNUMBER                   AS No_Police,
                    0					    AS Cd_Compagnie,
                    VW_BRUTE.COVERAGEIDENTIFIER             AS Couverture_ID, 
                    co.CD_PLAN                              AS Cd_Plan, --modif
                    CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER) AS No_Phase,
                    1	                                AS No_Sous_Phase,
                    1                                       AS No_Assure,
                    -4                                      AS No_Conjoint,
                    0                                       AS Ind_Equivalent,
                    TRY_CAST(VW_BRUTE.ISSUEAGE AS INTEGER)  AS Age_Emission,
                    VW_BRUTE.CLIENTDATEOFBIRTH              AS Date_Naissance,
                    NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.UNDERWRITINGGENDER     ||' non trouvé') AS Cd_Sexe,
                    IFF((Age_Emission < 15 AND VW_BRUTE.TOBACCOUSE = '03' ),'2',NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.TOBACCOUSE             ||' non trouvé')) AS Cd_St_Fumeur         
FROM DB_AV_DEV_STG.PSA_SILO_0."VW_FLATTEN_POLICY" VW_BRUTE

LEFT JOIN DB_AV_DEV_DWH.BDV_SILO_0.VW_OIPA_COHORTE_COUVERTURE co 
       ON co.NO_POLICE = VW_BRUTE.POLICYNUMBER 
      AND co.COUVERTURE_ID = VW_BRUTE.COVERAGEIDENTIFIER

LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeTobaccoUse' 
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.TOBACCOUSE

LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeGender' 
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.UNDERWRITINGGENDER;
create or replace view VW_OIPA_COHORTE_COUVERTURE(
	NO_POLICE,
	COUVERTURE_ID,
	NO_COUVERTURE,
	FKID_PRODUIT,
	VERSION_PRODUIT_OIPA,
	VERSION_PROTECTION_OIPA,
	DATE_REFERENCE_TAUX_OIPA,
	CD_ST_COUVERTURE_TRAD,
	CD_ST_RAISON_COUVERTURE_TRAD,
	CD_CONJOINT,
	MNT_FRAIS,
	CAPITAL_ASSURE_COURANT,
	NB_UNITE,
	VALEUR_UNITE,
	MNT_PRIME_ANNUELLE,
	DT_LIBERATION,
	DT_EXPIRATION,
	INITIALTERMDURATION,
	MNT_PRIME_REMB_ABANDON,
	MNT_PRIME_REMB_DECES,
	CD_TYPE_EMISSION,
	DT_EMISSION_COUVERTURE,
	CD_BANDE_FORCE,
	CD_PLAN,
	DATE_VERSION
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une couverture de l''event ACTIVATED.'
 as
SELECT DISTINCT VW_BRUTE.POLICYNUMBER                          ::VARCHAR(200)   AS NO_POLICE,
       VW_BRUTE.COVERAGEIDENTIFIER                             ::VARCHAR(200)   AS COUVERTURE_ID, 
       CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER)                                  AS NO_COUVERTURE,
       PL.ID_CORRESPONDANCE_CODE_PLAN                                           AS FKID_PRODUIT,
       VW_BRUTE.PRODUCTVERSIONCODE                             ::VARCHAR(200)   AS VERSION_PRODUIT_OIPA, 
       VW_BRUTE.COVERAGEVERSIONCODE                            ::VARCHAR(200)   AS VERSION_PROTECTION_OIPA,
       TRY_CAST(VW_BRUTE.RATESREFERENCEDATE AS DATE)                            AS DATE_REFERENCE_TAUX_OIPA,
       NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESTATUS     ||' non trouvé') ::VARCHAR(200) AS CD_ST_COUVERTURE_TRAD,
       NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESUBSTATUS  ||' non trouvé') ::VARCHAR(200) AS CD_ST_RAISON_COUVERTURE_TRAD,
       1         		        	                                      AS CD_CONJOINT,
       CAST(VW_BRUTE.DISTRIBUTEDPOLICYFEES AS NUMERIC(9,2))                     AS MNT_FRAIS,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT AS NUMERIC(9,0))                         AS CAPITAL_ASSURE_COURANT,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT / 1000 AS NUMERIC(9,0))                  AS NB_UNITE,
       1000					                                      AS VALEUR_UNITE,
       CAST(VW_BRUTE.COVERAGEANNUALPREMIUM AS  NUMERIC(9,2))                    AS MNT_PRIME_ANNUELLE,
       NVL(VW_BRUTE.PAIDUPDATE,  VW_BRUTE.EXPIRYDATE)          ::DATE           AS DT_LIBERATION,
       NVL(NVL(VW_BRUTE.EXPIRYDATE, VW_BRUTE.MATURITYDATE), VW_BRUTE.PAIDUPDATE) ::VARCHAR(200)   AS DT_EXPIRATION,
       TRY_CAST(VW_BRUTE.INITIALTERMDURATION AS INTEGER)                        AS INITIALTERMDURATION,
       0.00				                                             AS MNT_PRIME_REMB_ABANDON,
       0.00				                                             AS MNT_PRIME_REMB_DECES,
       -1	      			                                             AS CD_TYPE_EMISSION,
       VW_BRUTE.COVERAGEEFFECTIVEDATE                          ::DATE           AS DT_EMISSION_COUVERTURE,
       -1  	                                                 ::NUMERIC(1,0)   AS CD_BANDE_FORCE,
       PL.PDF_PLAN_NAME     		                                      AS CD_PLAN,
       PL.PDF_VERSION_DATE 			                     ::VARCHAR(200)   AS DATE_VERSION

FROM      DB_AV_DEV_STG.PSA_SILO_0."VW_FLATTEN_POLICY" VW_BRUTE 

LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeSubstatus'
      AND dom1.CODE_NAME_CIBLE = 'CdStatutCouverture'
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESTATUS
    				       																			
LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
      AND dom2.CODE_NAME_CIBLE = 'CdStatutRaisonCouverture'					   															
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESUBSTATUS
				   
LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_CODE_PLAN  PL 
       ON PL.PRODUCT_VERSION_CODE  = VW_BRUTE.PRODUCTVERSIONCODE 
      AND PL.COVERAGE_VERSION_CODE  = VW_BRUTE.COVERAGEVERSIONCODE 
      AND PL.RATES_REFERENCE_DATE = VW_BRUTE.RATESREFERENCEDATE;
create or replace view VW_OIPA_COHORTE_POLICE(
	NO_POLICE,
	CD_COMPAGNIE,
	CD_ST_POLICE,
	CD_ST_RAISON_POLICE,
	CD_DEVISE,
	NO_AGENT,
	CD_DISTRICT,
	CODE_TYPE_AGENT,
	CD_PROVINCE,
	CD_COUNTRY,
	CD_FREQUENCE_PAIEMENT,
	IND_PARTICIPATION,
	COUT_BASE_REAJUSTE,
	MNT_BALANCE_PRET,
	FACTEUR_MODAL,
	CD_US,
	CD_EQUIPE,
	CD_SOURCE,
	CD_TYPE_PAIEMENT,
	MNT_VALEUR_RACHAT,
	DT_CHARGEMENT
) COMMENT='VUE POLICE D''ASSURANCE QUI CONTIENT LE DERNIER ENREGISTREMENT REÇU POUR UNE POLICE DE L''EVENT ACTIVATED'
 as
WITH _COHORTEINI AS (
                     SELECT * FROM (
                                    SELECT POL.POLICYNUMBER                  AS POLICY_NUMBER,
                                           POL.POLICYSTATUS                  AS POLICY_STATUS,
                                           POL.POLICYSUBSTATUS               AS POLICY_SUBSTATUS,
                                           POL.POLICYCURRENCY                AS POLICY_CURRENCY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS POLICY_OWNER_RESIDENCE_STATE,
                                           POL.ISSUESTATE                    AS ISSUE_STATE,
                                           POL.PAYMENTFREQUENCY              AS PAYMENT_FREQUENCY,
                                           POL.POLICYACB                     AS POLICY_ACB,
                                           POL.PAYMENTMETHOD                 AS PAYMENT_METHOD,
                                           POL.MD_DTCHARGEMENT::TIMESTAMPLTZ AS MD_DTCHARGEMENT,
                                           POL.ADVISORCODE                   AS NO_AGENT,
                                           'CA'                              AS COUNTRY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS PROVINCE,
                                           POL.AGENCYNUMBER                  AS CODE_DISTRICT,
                                           FPIS.AGENTTYPE                    AS CODE_TYPE_AGENT,
   	                                    POL.SERVICEUNITNUMBER             AS CODE_US,
                                           POL.CLIENTDATEOFBIRTH             AS CLIENT_DATE_OF_BIRTH,
                       	               MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT, 
                                           ROW_number() OVER (PARTITION BY pol.PolicyNumber ORDER BY Code_Type_Agent ASC, pol.Agent DESC, CASE WHEN UPPER(POL.POLICYOWNERCORRESPONDENCEINDICATOR) in ('TRUE','1') THEN 1 ELSE 0 END DESC, POL.PARTYID ASC) NB
                                    FROM DB_AV_DEV_STG.PSA_SILO_0.VW_FLATTEN_POLICY POL
                                    LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
                                                 ON FPIS.correlationid = POL.correlationid
                                                 AND FPIS.PartyID = POL.PartyID
                                    ) t 
                                    WHERE NB = 1 
),  
   _COHORTE_DOMAINEVALEUR AS (
                              SELECT POLICY_NUMBER,
                                     POLICY_CURRENCY,
                                     POLICY_ACB,
                                     ISSUE_STATE,
                                     POLICY_OWNER_RESIDENCE_STATE,
                                     NO_AGENT,
                                     CODE_TYPE_AGENT,
                                     CODE_DISTRICT,
                                     CODE_US,
                                     CLIENT_DATE_OF_BIRTH,
                                     COUNTRY,           
                                     NVL(DOM1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_STATUS     ||' non trouvé') AS CDSTPOLICE,
                                     NVL(DOM2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_SUBSTATUS  ||' non trouvé') AS CDSTRAISONPOLICE,
                                     NVL(DOM3.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_FREQUENCY ||' non trouvé') AS CDFREQUENCEPAIEMENT,
                                     NVL(DOM4.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_METHOD    ||' non trouvé') AS CDTYPEPAIEMENT,
                                     NVL(DOM5.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PROVINCE          ||' non trouvé') AS PROVINCE,
                                     MAX_MD_DTCHARGEMENT AS DT_CHARGEMENT
                               FROM _COHORTEINI 

                          LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
                                 ON DOM1.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
    				    AND DOM1.CODE_NAME_CIBLE  = 'CdStatutPolice'
    				    AND DOM1.CODE_VALEUR_SOURCE = POLICY_STATUS
    																				
			     LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
                                 ON DOM2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
			           AND DOM2.CODE_NAME_CIBLE  = 'CdStatutRaisonPolice'
				    AND DOM2.CODE_VALEUR_SOURCE = POLICY_SUBSTATUS
								
                	     LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM3 
                                 ON DOM3.CODE_NAME_SOURCE = 'AsCodePaymentFrequency' 
                                AND DOM3.CODE_VALEUR_SOURCE = PAYMENT_FREQUENCY
     
                          LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM4 
                                 ON DOM4.CODE_NAME_SOURCE = 'AsCodePaymentMethod' 
                                AND DOM4.CODE_VALEUR_SOURCE = PAYMENT_METHOD
     
		            LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM5 
                                 ON DOM5.CODE_NAME_SOURCE = 'AsCodeState' 
                                AND DOM5.CODE_VALEUR_SOURCE = PROVINCE
),

-----------------------------------------------------------------------------------
--CERTAINES COLONNE NE SONT PAS FOURNIES PAR OIPA MAIS SONT NÉCESSAIRES POUR XA.
--CETTE COHORTE CORRESPOND AUX CHAMPS IDENTIFIÉS DANS LA TABLE SVDVIEV_POLICE_TRAD
-----------------------------------------------------------------------------------

   _COHORTE AS (
                SELECT POLICY_NUMBER 	                     ::VARCHAR(200) AS NO_POLICE,
                       0                                                      AS CD_COMPAGNIE,
                       CDSTPOLICE                              ::VARCHAR(200) AS CD_ST_POLICE,
                       CDSTRAISONPOLICE	                     ::VARCHAR(200) AS CD_ST_RAISON_POLICE,           
                       POLICY_CURRENCY	                     ::VARCHAR(200) AS CD_DEVISE,
                       NO_AGENT                                ::VARCHAR(200) AS NO_AGENT,
                       CODE_DISTRICT                           ::VARCHAR(200) AS CD_DISTRICT,
                       CODE_TYPE_AGENT                         ::VARCHAR(200) AS CODE_TYPE_AGENT,
                       PROVINCE		                     ::VARCHAR(200) AS CD_PROVINCE,
                       COUNTRY		                     ::VARCHAR(200) AS CD_COUNTRY,
                       CDFREQUENCEPAIEMENT                                    AS CD_FREQUENCE_PAIEMENT,
                       0                                                      AS IND_PARTICIPATION,
                       TRY_CAST(POLICY_ACB AS DECIMAL(9,2))                   AS COUT_BASE_REAJUSTE,
                       0.00			                                    AS MNT_BALANCE_PRET,
                       CAST(1.08000 AS DECIMAL(9,2))                          AS FACTEUR_MODAL,
                       CODE_US                                 ::VARCHAR(200) AS CD_US,
                       NULL                                    ::VARCHAR(200) AS CD_EQUIPE,
                       -1                                                     AS CD_SOURCE,
                       CDTYPEPAIEMENT	                     ::VARCHAR(200) AS CD_TYPE_PAIEMENT,
                     --A VENIR EN ATTENTE DE OIPA - il n'y pas de valeur de rachat avant 5 ans.'
                       CAST(0 AS DECIMAL(9,2))                                AS MNT_VALEUR_RACHAT,
                       DT_CHARGEMENT
                FROM _COHORTE_DOMAINEVALEUR
)

SELECT * FROM _COHORTE;
create or replace view VW_SAT_POLICY_CLEAN(
	HK_HUB_POLICY,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_START_DT,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	PRODUCT_CODE,
	PRODUCT_VERSION_CODE,
	POLICY_OWNER_RESIDENCE_STATE,
	POLICY_YEAR,
	POLICY_CURRENCY,
	ISSUE_STATE,
	POLICY_EFFECTIVE_DATE,
	LAST_REINSTATEMENT_DATE,
	POLICY_STATUS,
	POLICY_SUB_STATUS,
	PAYMENT_FREQUENCY,
	NEXT_PREMIUM_DUE_DATE,
	PAYMENT_METHOD,
	BILLING_STATUS,
	PAID_TO_DATE,
	BILLING_INTERRUPTION_REASON,
	ANTICIPATE_BILLING_RESUME_DATE,
	POLICY_ACB,
	POLICY_ACB_MODAL_PREMIUM,
	POLICY_ACB_PREMIUM_ITD,
	POLICY_ANNUAL_PREMIUM,
	POLICY_MODAL_PREMIUM,
	ANNUAL_POLICY_FEES,
	MODAL_POLICY_FEES
) as
SELECT *
--,convert_timezone('America/Montreal', POLICY_EFFECTIVE_DATE)::timestamp_ntz as NTZ_POLICY_EFFECTIVE_DATE
FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_POLICY;
create or replace schema BDV_SILO_0_DH;

create or replace TABLE CLEAN_SAT_POLICY (
	HK_HUB_POLICY_CLEAN VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_EVENT_TYPE VARCHAR(100),
	PRODUCT_CODE VARCHAR(50),
	PRODUCT_VERSION_CODE VARCHAR(50),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(4),
	ISSUE_STATE VARCHAR(4),
	POLICY_EFFECTIVE_DATE DATE,
	LAST_REINSTATEMENT_DATE DATE,
	POLICY_STATUS VARCHAR(2),
	POLICY_SUB_STATUS VARCHAR(2),
	PAYEMENT_FREQUENCY VARCHAR(2),
	NEXT_PREMIUM_DUE_DATE DATE,
	PAYMENT_METHOD VARCHAR(2),
	BILLING_STATUS VARCHAR(2),
	PAID_TO_DATE DATE,
	BILLING_SUSPENSION_REASON VARCHAR(255),
	BILLING_SUSPENSION_REQUESTOR VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE DATE,
	POLICY_ACB NUMBER(19,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(19,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(19,2),
	POLICY_ANNUAL_PREMIUM NUMBER(19,2),
	POLICY_MODAL_PREMIUM NUMBER(19,2),
	ANNUAL_POLICY_FEES NUMBER(19,2),
	MODAL_POLICY_FEES NUMBER(19,2),
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_POLICY_CLEAN primary key (HK_HUB_POLICY_CLEAN, MD_START_DT)
);
create or replace view VW_OIPA_COHORTE_AGENT(
	NO_POLICE,
	COUVERTURE_ID,
	NO_AGENT,
	CODE_DISTRICT,
	CODE_US,
	CODE_TYPE_AGENT,
	CODE_EQUIPE
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement d''agent de l''event ACTIVATED'
 as
WITH 
_cohorte AS (
  SELECT  
        POL.POLICYNUMBER       ::VARCHAR(200) AS NO_POLICE,
        POL.COVERAGEIDENTIFIER ::VARCHAR(200) AS COUVERTURE_ID,
        POL.AdvisorCode        ::VARCHAR(200) AS NO_AGENT,
        POL.AgencyNumber       ::VARCHAR(200) AS CODE_DISTRICT,
        POL.ServiceUnitNumber  ::VARCHAR(200) AS CODE_US,
        FPIS.AgentType         ::VARCHAR(200) AS Code_Type_Agent, --carriere ou ordinaire 
        MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT
 FROM DB_AV_DEV_STG.PSA_SILO_0_DH.VW_FLATTEN_POLICY POL
 LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
             ON FPIS.correlationid = POL.correlationid
             AND FPIS.PartyID = POL.PartyID
 WHERE COALESCE(POL.AdvisorCode,'N/A') = COALESCE(FPIS.AgentCode,'N/A')
)
SELECT DISTINCT NO_POLICE,
       COUVERTURE_ID,
       NO_AGENT,
       CODE_DISTRICT,
       CODE_US,
       CODE_TYPE_AGENT,
       '' ::VARCHAR(200) AS CODE_EQUIPE --n'existe pas dans OIPA
FROM  _cohorte;
create or replace view VW_OIPA_COHORTE_ASSURE(
	NO_POLICE,
	CD_COMPAGNIE,
	COUVERTURE_ID,
	CD_PLAN,
	NO_PHASE,
	NO_SOUS_PHASE,
	NO_ASSURE,
	NO_CONJOINT,
	IND_EQUIVALENT,
	AGE_EMISSION,
	DATE_NAISSANCE,
	CD_SEXE,
	CD_ST_FUMEUR
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une police de l''event ACTIVATED'
 as
SELECT DISTINCT     VW_BRUTE.POLICYNUMBER                   AS No_Police,
                    0					    AS Cd_Compagnie,
                    VW_BRUTE.COVERAGEIDENTIFIER             AS Couverture_ID, 
                    co.CD_PLAN                              AS Cd_Plan, --modif
                    CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER) AS No_Phase,
                    1	                                AS No_Sous_Phase,
                    1                                       AS No_Assure,
                    -4                                      AS No_Conjoint,
                    0                                       AS Ind_Equivalent,
                    TRY_CAST(VW_BRUTE.ISSUEAGE AS INTEGER)  AS Age_Emission,
                    VW_BRUTE.CLIENTDATEOFBIRTH              AS Date_Naissance,
                    NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.UNDERWRITINGGENDER     ||' non trouvé') AS Cd_Sexe,
                    NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.TOBACCOUSE             ||' non trouvé') AS Cd_St_Fumeur         
FROM DB_AV_DEV_STG.PSA_SILO_0_DH."VW_FLATTEN_POLICY" VW_BRUTE

LEFT JOIN DB_AV_DEV_DWH.BDV_SILO_0_DH.VW_OIPA_COHORTE_COUVERTURE co 
       ON co.NO_POLICE = VW_BRUTE.POLICYNUMBER 
      AND co.COUVERTURE_ID = VW_BRUTE.COVERAGEIDENTIFIER

LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeTobaccoUse' 
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.TOBACCOUSE

LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeGender' 
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.UNDERWRITINGGENDER;
create or replace view VW_OIPA_COHORTE_COUVERTURE(
	NO_POLICE,
	COUVERTURE_ID,
	NO_COUVERTURE,
	FKID_PRODUIT,
	VERSION_PRODUIT_OIPA,
	VERSION_PROTECTION_OIPA,
	DATE_REFERENCE_TAUX_OIPA,
	CD_ST_COUVERTURE_TRAD,
	CD_ST_RAISON_COUVERTURE_TRAD,
	CD_CONJOINT,
	MNT_FRAIS,
	CAPITAL_ASSURE_COURANT,
	NB_UNITE,
	VALEUR_UNITE,
	MNT_PRIME_ANNUELLE,
	DT_LIBERATION,
	DT_EXPIRATION,
	INITIALTERMDURATION,
	MNT_PRIME_REMB_ABANDON,
	MNT_PRIME_REMB_DECES,
	CD_TYPE_EMISSION,
	DT_EMISSION_COUVERTURE,
	CD_BANDE_FORCE,
	CD_PLAN,
	DATE_VERSION
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une couverture de l''event ACTIVATED.'
 as
SELECT DISTINCT VW_BRUTE.POLICYNUMBER                          ::VARCHAR(200)   AS NO_POLICE,
       VW_BRUTE.COVERAGEIDENTIFIER                             ::VARCHAR(200)   AS COUVERTURE_ID, 
       CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER)                                  AS NO_COUVERTURE,
       PL.ID_CORRESPONDANCE_CODE_PLAN                                           AS FKID_PRODUIT,
       VW_BRUTE.PRODUCTVERSIONCODE                             ::VARCHAR(200)   AS VERSION_PRODUIT_OIPA, 
       VW_BRUTE.COVERAGEVERSIONCODE                            ::VARCHAR(200)   AS VERSION_PROTECTION_OIPA,
       TRY_CAST(VW_BRUTE.RATESREFERENCEDATE AS DATE)                            AS DATE_REFERENCE_TAUX_OIPA,
       NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESTATUS     ||' non trouvé') ::VARCHAR(200) AS CD_ST_COUVERTURE_TRAD,
       NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || COVERAGESUBSTATUS  ||' non trouvé') ::VARCHAR(200) AS CD_ST_RAISON_COUVERTURE_TRAD,
       1         		        	                                      AS CD_CONJOINT,
       CAST(VW_BRUTE.DISTRIBUTEDPOLICYFEES AS NUMERIC(9,2))                     AS MNT_FRAIS,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT AS NUMERIC(9,0))                         AS CAPITAL_ASSURE_COURANT,
       CAST(VW_BRUTE.CURRENTFACEAMOUNT / 1000 AS NUMERIC(9,0))                  AS NB_UNITE,
       1000					                                      AS VALEUR_UNITE,
       CAST(VW_BRUTE.COVERAGEANNUALPREMIUM AS  NUMERIC(9,2))                    AS MNT_PRIME_ANNUELLE,
       NVL(VW_BRUTE.PAIDUPDATE,  VW_BRUTE.EXPIRYDATE)          ::DATE           AS DT_LIBERATION,
       NVL(NVL(VW_BRUTE.EXPIRYDATE, VW_BRUTE.MATURITYDATE), VW_BRUTE.PAIDUPDATE) ::VARCHAR(200)   AS DT_EXPIRATION,
       TRY_CAST(VW_BRUTE.INITIALTERMDURATION AS INTEGER)                        AS INITIALTERMDURATION,
       0.00				                                             AS MNT_PRIME_REMB_ABANDON,
       0.00				                                             AS MNT_PRIME_REMB_DECES,
       -1	      			                                             AS CD_TYPE_EMISSION,
       VW_BRUTE.COVERAGEEFFECTIVEDATE                          ::DATE           AS DT_EMISSION_COUVERTURE,
       -1  	                                                 ::NUMERIC(1,0)   AS CD_BANDE_FORCE,
       PL.PDF_PLAN_NAME     		                                      AS CD_PLAN,
       PL.PDF_VERSION_DATE 			                     ::VARCHAR(200)   AS DATE_VERSION

FROM      DB_AV_DEV_STG.PSA_SILO_0_DH."VW_FLATTEN_POLICY" VW_BRUTE 

LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeSubstatus'
      AND dom1.CODE_NAME_CIBLE = 'CdStatutCouverture'
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESTATUS
    				       																			
LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
      AND dom2.CODE_NAME_CIBLE = 'CdStatutRaisonCouverture'					   															
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.COVERAGESUBSTATUS
				   
LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_CODE_PLAN  PL 
       ON PL.PRODUCT_VERSION_CODE  = VW_BRUTE.PRODUCTVERSIONCODE 
      AND PL.COVERAGE_VERSION_CODE  = VW_BRUTE.COVERAGEVERSIONCODE 
      AND PL.RATES_REFERENCE_DATE = VW_BRUTE.RATESREFERENCEDATE;
create or replace view VW_OIPA_COHORTE_POLICE(
	NO_POLICE,
	CD_COMPAGNIE,
	CD_ST_POLICE,
	CD_ST_RAISON_POLICE,
	CD_DEVISE,
	NO_AGENT,
	CD_DISTRICT,
	CODE_TYPE_AGENT,
	CD_PROVINCE,
	CD_COUNTRY,
	CD_FREQUENCE_PAIEMENT,
	IND_PARTICIPATION,
	COUT_BASE_REAJUSTE,
	MNT_BALANCE_PRET,
	FACTEUR_MODAL,
	CD_US,
	CD_EQUIPE,
	CD_SOURCE,
	CD_TYPE_PAIEMENT,
	MNT_VALEUR_RACHAT,
	DT_CHARGEMENT
) COMMENT='VUE POLICE D''ASSURANCE QUI CONTIENT LE DERNIER ENREGISTREMENT REÇU POUR UNE POLICE DE L''EVENT ACTIVATED'
 as
WITH _COHORTEINI AS (
                     SELECT * FROM (
                                    SELECT POL.POLICYNUMBER                  AS POLICY_NUMBER,
                                           POL.POLICYSTATUS                  AS POLICY_STATUS,
                                           POL.POLICYSUBSTATUS               AS POLICY_SUBSTATUS,
                                           POL.POLICYCURRENCY                AS POLICY_CURRENCY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS POLICY_OWNER_RESIDENCE_STATE,
                                           POL.ISSUESTATE                    AS ISSUE_STATE,
                                           POL.PAYMENTFREQUENCY              AS PAYMENT_FREQUENCY,
                                           POL.POLICYACB                     AS POLICY_ACB,
                                           POL.PAYMENTMETHOD                 AS PAYMENT_METHOD,
                                           POL.MD_DTCHARGEMENT::TIMESTAMPLTZ AS MD_DTCHARGEMENT,
                                           POL.ADVISORCODE                   AS NO_AGENT,
                                           'CA'                              AS COUNTRY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS PROVINCE,
                                           POL.AGENCYNUMBER                  AS CODE_DISTRICT,
                                           FPIS.AGENTTYPE                    AS CODE_TYPE_AGENT,
   	                                    POL.SERVICEUNITNUMBER             AS CODE_US,
                                           POL.CLIENTDATEOFBIRTH             AS CLIENT_DATE_OF_BIRTH,
                       	               MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT, 
                                           ROW_number() OVER (PARTITION BY pol.PolicyNumber ORDER BY Code_Type_Agent ASC, pol.Agent DESC, CASE WHEN UPPER(POL.POLICYOWNERCORRESPONDENCEINDICATOR) in ('TRUE','1') THEN 1 ELSE 0 END DESC, POL.PARTYID ASC) NB
                                    FROM DB_AV_DEV_STG.PSA_SILO_0_DH.VW_FLATTEN_POLICY POL
                                    LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
                                                 ON FPIS.correlationid = POL.correlationid
                                                 AND FPIS.PartyID = POL.PartyID
                                    ) t 
                                    WHERE NB = 1 
),  
   _COHORTE_DOMAINEVALEUR AS (
                              SELECT POLICY_NUMBER,
                                     POLICY_CURRENCY,
                                     POLICY_ACB,
                                     ISSUE_STATE,
                                     POLICY_OWNER_RESIDENCE_STATE,
                                     NO_AGENT,
                                     CODE_TYPE_AGENT,
                                     CODE_DISTRICT,
                                     CODE_US,
                                     CLIENT_DATE_OF_BIRTH,
                                     COUNTRY,           
                                     NVL(DOM1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_STATUS     ||' non trouvé') AS CDSTPOLICE,
                                     NVL(DOM2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_SUBSTATUS  ||' non trouvé') AS CDSTRAISONPOLICE,
                                     NVL(DOM3.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_FREQUENCY ||' non trouvé') AS CDFREQUENCEPAIEMENT,
                                     NVL(DOM4.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_METHOD    ||' non trouvé') AS CDTYPEPAIEMENT,
                                     NVL(DOM5.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PROVINCE          ||' non trouvé') AS PROVINCE,
                                     MAX_MD_DTCHARGEMENT AS DT_CHARGEMENT
                               FROM _COHORTEINI 

                          LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
                                 ON DOM1.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
    				    AND DOM1.CODE_NAME_CIBLE  = 'CdStatutPolice'
    				    AND DOM1.CODE_VALEUR_SOURCE = POLICY_STATUS
    																				
			     LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
                                 ON DOM2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
			           AND DOM2.CODE_NAME_CIBLE  = 'CdStatutRaisonPolice'
				    AND DOM2.CODE_VALEUR_SOURCE = POLICY_SUBSTATUS
								
                	     LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM3 
                                 ON DOM3.CODE_NAME_SOURCE = 'AsCodePaymentFrequency' 
                                AND DOM3.CODE_VALEUR_SOURCE = PAYMENT_FREQUENCY
     
                          LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM4 
                                 ON DOM4.CODE_NAME_SOURCE = 'AsCodePaymentMethod' 
                                AND DOM4.CODE_VALEUR_SOURCE = PAYMENT_METHOD
     
		            LEFT JOIN DB_AV_DEV_STG.PSA_SILO_0_DH.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM5 
                                 ON DOM5.CODE_NAME_SOURCE = 'AsCodeState' 
                                AND DOM5.CODE_VALEUR_SOURCE = PROVINCE
),

-----------------------------------------------------------------------------------
--CERTAINES COLONNE NE SONT PAS FOURNIES PAR OIPA MAIS SONT NÉCESSAIRES POUR XA.
--CETTE COHORTE CORRESPOND AUX CHAMPS IDENTIFIÉS DANS LA TABLE SVDVIEV_POLICE_TRAD
-----------------------------------------------------------------------------------

   _COHORTE AS (
                SELECT POLICY_NUMBER 	                     ::VARCHAR(200) AS NO_POLICE,
                       0                                                      AS CD_COMPAGNIE,
                       CDSTPOLICE                              ::VARCHAR(200) AS CD_ST_POLICE,
                       CDSTRAISONPOLICE	                     ::VARCHAR(200) AS CD_ST_RAISON_POLICE,           
                       POLICY_CURRENCY	                     ::VARCHAR(200) AS CD_DEVISE,
                       NO_AGENT                                ::VARCHAR(200) AS NO_AGENT,
                       CODE_DISTRICT                           ::VARCHAR(200) AS CD_DISTRICT,
                       CODE_TYPE_AGENT                         ::VARCHAR(200) AS CODE_TYPE_AGENT,
                       PROVINCE		                     ::VARCHAR(200) AS CD_PROVINCE,
                       COUNTRY		                     ::VARCHAR(200) AS CD_COUNTRY,
                       CDFREQUENCEPAIEMENT                                    AS CD_FREQUENCE_PAIEMENT,
                       0                                                      AS IND_PARTICIPATION,
                       TRY_CAST(POLICY_ACB AS DECIMAL(9,2))                   AS COUT_BASE_REAJUSTE,
                       0.00			                                    AS MNT_BALANCE_PRET,
                       CAST(1.08000 AS DECIMAL(9,2))                          AS FACTEUR_MODAL,
                       CODE_US                                 ::VARCHAR(200) AS CD_US,
                       NULL                                    ::VARCHAR(200) AS CD_EQUIPE,
                       -1                                                     AS CD_SOURCE,
                       CDTYPEPAIEMENT	                     ::VARCHAR(200) AS CD_TYPE_PAIEMENT,
                     --A VENIR EN ATTENTE DE OIPA - il n'y pas de valeur de rachat avant 5 ans.'
                       CAST(0 AS DECIMAL(9,2))                                AS MNT_VALEUR_RACHAT,
                       DT_CHARGEMENT
                FROM _COHORTE_DOMAINEVALEUR
)

SELECT * FROM _COHORTE;
create or replace view VW_SAT_POLICY_CLEAN(
	HK_HUB_POLICY,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_START_DT,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	PRODUCT_CODE,
	PRODUCT_VERSION_CODE,
	POLICY_OWNER_RESIDENCE_STATE,
	POLICY_YEAR,
	POLICY_CURRENCY,
	ISSUE_STATE,
	POLICY_EFFECTIVE_DATE,
	LAST_REINSTATEMENT_DATE,
	POLICY_STATUS,
	POLICY_SUB_STATUS,
	PAYMENT_FREQUENCY,
	NEXT_PREMIUM_DUE_DATE,
	PAYMENT_METHOD,
	BILLING_STATUS,
	PAID_TO_DATE,
	BILLING_INTERRUPTION_REASON,
	ANTICIPATE_BILLING_RESUME_DATE,
	POLICY_ACB,
	POLICY_ACB_MODAL_PREMIUM,
	POLICY_ACB_PREMIUM_ITD,
	POLICY_ANNUAL_PREMIUM,
	POLICY_MODAL_PREMIUM,
	ANNUAL_POLICY_FEES,
	MODAL_POLICY_FEES
) as
SELECT *
--,convert_timezone('America/Montreal', POLICY_EFFECTIVE_DATE)::timestamp_ntz as NTZ_POLICY_EFFECTIVE_DATE
FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_POLICY;
create or replace schema BDV_V0;

create or replace view VW_OIPA_COHORTE_AGENT(
	NO_POLICE,
	COUVERTURE_ID,
	NO_AGENT,
	CODE_DISTRICT,
	CODE_US,
	CODE_TYPE_AGENT,
	CODE_EQUIPE
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement d''agent de l''event ACTIVATED'
 as
WITH 
_cohorte AS (
  SELECT  
        POL.POLICYNUMBER       ::VARCHAR(200) AS NO_POLICE,
        POL.COVERAGEIDENTIFIER ::VARCHAR(200) AS COUVERTURE_ID,
        POL.AdvisorCode        ::VARCHAR(200) AS NO_AGENT,
        POL.AgencyNumber       ::VARCHAR(200) AS CODE_DISTRICT,
        POL.ServiceUnitNumber  ::VARCHAR(200) AS CODE_US,
        FPIS.AgentType         ::VARCHAR(200) AS Code_Type_Agent, --carriere ou ordinaire 
        MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT
 FROM DB_AV_DEV_STG.PSA_V0.VW_FLATTEN_POLICY POL
 LEFT JOIN DB_AV_dev_STG.PSA_V0.VW_FLATTEN_POLICY_INFO_SUPP FPIS 
             ON FPIS.correlationid = POL.correlationid
             AND FPIS.PartyID = POL.PartyID
 WHERE COALESCE(POL.AdvisorCode,'N/A') = COALESCE(FPIS.AgentCode,'N/A')
)
SELECT DISTINCT NO_POLICE,
       COUVERTURE_ID,
       NO_AGENT,
       CODE_DISTRICT,
       CODE_US,
       CODE_TYPE_AGENT,
       '' ::VARCHAR(200) AS CODE_EQUIPE --n'existe pas dans OIPA
FROM  _cohorte;
create or replace view VW_OIPA_COHORTE_ASSURE(
	NO_POLICE,
	CD_COMPAGNIE,
	COUVERTURE_ID,
	CD_PLAN,
	NO_PHASE,
	NO_SOUS_PHASE,
	NO_ASSURE,
	NO_CONJOINT,
	IND_EQUIVALENT,
	AGE_EMISSION,
	DATE_NAISSANCE,
	CD_SEXE,
	CD_ST_FUMEUR
) COMMENT='Vue Police d''assurance qui contient le dernier enregistrement reçu pour une police de l''event ACTIVATED'
 as
SELECT DISTINCT     VW_BRUTE.POLICYNUMBER                   AS No_Police,
                    0					            AS Cd_Compagnie,
                    VW_BRUTE.COVERAGEIDENTIFIER             AS Couverture_ID, 
                    co.CD_PLAN                              AS Cd_Plan, --modif
                    CAST(VW_BRUTE.COVERAGEINDEX AS INTEGER) AS No_Phase,
                    1	                                    AS No_Sous_Phase,
                    1                                       AS No_Assure,
                    -4                                      AS No_Conjoint,
                    0                                       AS Ind_Equivalent,
                    TRY_CAST(VW_BRUTE.ISSUEAGE AS INTEGER)  AS Age_Emission,
                    VW_BRUTE.CLIENTDATEOFBIRTH              AS Date_Naissance,
                    NVL(dom2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.UNDERWRITINGGENDER     ||' non trouvé') AS Cd_Sexe,
                    NVL(dom1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || VW_BRUTE.TOBACCOUSE             ||' non trouvé') AS Cd_St_Fumeur         
FROM      DB_AV_DEV_STG.PSA_V0."VW_FLATTEN_POLICY" VW_BRUTE

LEFT JOIN DB_AV_DEV_DWH.BDV_V0.VW_OIPA_COHORTE_COUVERTURE co 
       ON co.NO_POLICE = VW_BRUTE.POLICYNUMBER 
      AND co.COUVERTURE_ID = VW_BRUTE.COVERAGEIDENTIFIER

LEFT JOIN DB_AV_DEV_STG.PSA_V0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
       ON dom1.CODE_NAME_SOURCE = 'AsCodeTobaccoUse' 
      AND dom1.CODE_VALEUR_SOURCE = VW_BRUTE.TOBACCOUSE

LEFT JOIN DB_AV_DEV_STG.PSA_V0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
       ON dom2.CODE_NAME_SOURCE = 'AsCodeGender' 
      AND dom2.CODE_VALEUR_SOURCE = VW_BRUTE.UNDERWRITINGGENDER;
create or replace view VW_OIPA_COHORTE_COUVERTURE(
	NO_POLICE,
	COUVERTURE_ID,
	NO_COUVERTURE,
	FKID_PRODUIT,
	VERSION_PRODUIT_OIPA,
	VERSION_PROTECTION_OIPA,
	DATE_REFERENCE_TAUX_OIPA,
	CD_ST_COUVERTURE_TRAD,
	CD_ST_RAISON_COUVERTURE_TRAD,
	CD_CONJOINT,
	MNT_FRAIS,
	CAPITAL_ASSURE_COURANT,
	NB_UNITE,
	VALEUR_UNITE,
	MNT_PRIME_ANNUELLE,
	DT_LIBERATION,
	DT_EXPIRATION,
	INITIALTERMDURATION,
	MNT_PRIME_REMB_ABANDON,
	MNT_PRIME_REMB_DECES,
	CD_TYPE_EMISSION,
	DT_EMISSION_COUVERTURE,
	CD_BANDE_FORCE,
	CD_PLAN,
	DATE_VERSION
) as SELECT * FROM  BDV.VW_OIPA_COHORTE_COUVERTURE;
create or replace view VW_OIPA_COHORTE_POLICE(
	NO_POLICE,
	CD_COMPAGNIE,
	CD_ST_POLICE,
	CD_ST_RAISON_POLICE,
	CD_DEVISE,
	NO_AGENT,
	CD_DISTRICT,
	CODE_TYPE_AGENT,
	CD_PROVINCE,
	CD_COUNTRY,
	CD_FREQUENCE_PAIEMENT,
	IND_PARTICIPATION,
	COUT_BASE_REAJUSTE,
	MNT_BALANCE_PRET,
	FACTEUR_MODAL,
	CD_US,
	CD_EQUIPE,
	CD_SOURCE,
	CD_TYPE_PAIEMENT,
	MNT_VALEUR_RACHAT,
	DT_CHARGEMENT
) as
WITH _COHORTEINI AS (
                     SELECT * FROM (
                                    SELECT POL.POLICYNUMBER                  AS POLICY_NUMBER,
                                           POL.POLICYSTATUS                  AS POLICY_STATUS,
                                           POL.POLICYSUBSTATUS               AS POLICY_SUBSTATUS,
                                           POL.POLICYCURRENCY                AS POLICY_CURRENCY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS POLICY_OWNER_RESIDENCE_STATE,
                                           POL.ISSUESTATE                    AS ISSUE_STATE,
                                           POL.PAYMENTFREQUENCY              AS PAYMENT_FREQUENCY,
                                           POL.POLICYACB                     AS POLICY_ACB,
                                           POL.PAYMENTMETHOD                 AS PAYMENT_METHOD,
                                           POL.MD_DTCHARGEMENT::TIMESTAMPLTZ AS MD_DTCHARGEMENT,
                                           POL.ADVISORCODE                   AS NO_AGENT,
                                           'CA'                              AS COUNTRY,
                                           POL.POLICYOWNERRESIDENCESTATE     AS PROVINCE,
                                           POL.AgencyNumber                  AS CODE_DISTRICT,
                                           FPIS.AgentType                    AS CODE_TYPE_AGENT,
   	                                    POL.ServiceUnitNumber             AS CODE_US,
                                           POL.CLIENTDATEOFBIRTH             AS CLIENT_DATE_OF_BIRTH,
                       	               MAX(POL.MD_DTCHARGEMENT::TIMESTAMPLTZ) OVER (PARTITION BY POL.POLICYNUMBER ORDER BY POL.MD_DTCHARGEMENT::TIMESTAMPLTZ DESC) AS MAX_MD_DTCHARGEMENT, 
                                           ROW_number() OVER (PARTITION BY pol.PolicyNumber ORDER BY Code_Type_Agent ASC, pol.Agent DESC, CASE WHEN UPPER(POL.POLICYOWNERCORRESPONDENCEINDICATOR) in ('TRUE','1') THEN 1 ELSE 0 END DESC, POL.PARTYID ASC) NB
                                    FROM DB_AV_DEV_STG.PSA_V0."VW_FLATTEN_POLICY" POL 
                                         LEFT JOIN DB_AV_DEV_STG.PSA_V0.VW_FLATTEN_POLICY_INFO_SUPP FPIS  ON FPIS.correlationid = POL.correlationid AND FPIS.PartyID = POL.PartyID
                                    ) t 
                                    WHERE NB = 1 
                                    
),  
   _COHORTE_DOMAINEVALEUR AS (
                              SELECT POLICY_NUMBER,
                                     POLICY_CURRENCY,
                                     POLICY_ACB,
                                     ISSUE_STATE,
                                     POLICY_OWNER_RESIDENCE_STATE,
                                     NO_AGENT,
                                     CODE_TYPE_AGENT,
                                     CODE_DISTRICT,
                                     CODE_US,
                                     CLIENT_DATE_OF_BIRTH,
                                     COUNTRY,           
                                     NVL(DOM1.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_STATUS     ||' non trouvé') AS CDSTPOLICE,
                                     NVL(DOM2.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || POLICY_SUBSTATUS  ||' non trouvé') AS CDSTRAISONPOLICE,
                                     NVL(DOM3.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_FREQUENCY ||' non trouvé') AS CDFREQUENCEPAIEMENT,
                                     NVL(DOM4.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PAYMENT_METHOD    ||' non trouvé') AS CDTYPEPAIEMENT,
                                     NVL(DOM5.CODE_VALEUR_CIBLE, 'Erreur: code--> ' || PROVINCE          ||' non trouvé') AS PROVINCE,
                                     MAX_MD_DTCHARGEMENT AS DT_CHARGEMENT
                               FROM _COHORTEINI 

                          LEFT JOIN DB_AV_DEV_STG.PSA_V0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM1 
                                 ON DOM1.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
    				    AND DOM1.CODE_NAME_CIBLE  = 'CdStatutPolice'
    				    AND DOM1.CODE_VALEUR_SOURCE = POLICY_STATUS
    																				
			     LEFT JOIN DB_AV_DEV_STG.PSA_V0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM2 
                                 ON DOM2.CODE_NAME_SOURCE = 'AsCodeSubstatus' 
			           AND DOM2.CODE_NAME_CIBLE  = 'CdStatutRaisonPolice'
				    AND DOM2.CODE_VALEUR_SOURCE = POLICY_SUBSTATUS
								
                	     LEFT JOIN DB_AV_DEV_STG.PSA_V0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM3 
                                 ON DOM3.CODE_NAME_SOURCE = 'AsCodePaymentFrequency' 
                                AND DOM3.CODE_VALEUR_SOURCE = PAYMENT_FREQUENCY
     
                          LEFT JOIN DB_AV_DEV_STG.PSA_V0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM4 
                                 ON DOM4.CODE_NAME_SOURCE = 'AsCodePaymentMethod' 
                                AND DOM4.CODE_VALEUR_SOURCE = PAYMENT_METHOD
     
		            LEFT JOIN DB_AV_DEV_STG.PSA_V0.VW_OIPA_CORRESPONDANCE_DOMAINE_VALEUR DOM5 
                                 ON DOM5.CODE_NAME_SOURCE = 'AsCodeState' 
                                AND DOM5.CODE_VALEUR_SOURCE = PROVINCE
),

-----------------------------------------------------------------------------------
--CERTAINES COLONNE NE SONT PAS FOURNIES PAR OIPA MAIS SONT NÉCESSAIRES POUR XA.
--CETTE COHORTE CORRESPOND AUX CHAMPS IDENTIFIÉS DANS LA TABLE SVDVIEV_POLICE_TRAD
-----------------------------------------------------------------------------------

   _COHORTE AS (
                SELECT POLICY_NUMBER 	                     ::VARCHAR(200) AS NO_POLICE,
                       0                                                      AS CD_COMPAGNIE,
                       CDSTPOLICE                              ::VARCHAR(200) AS CD_ST_POLICE,
                       CDSTRAISONPOLICE	                     ::VARCHAR(200) AS CD_ST_RAISON_POLICE,           
                       POLICY_CURRENCY	                     ::VARCHAR(200) AS CD_DEVISE,
                       NO_AGENT                                ::VARCHAR(200) AS NO_AGENT,
                       CODE_DISTRICT                           ::VARCHAR(200) AS CD_DISTRICT,
                       CODE_TYPE_AGENT                         ::VARCHAR(200) AS CODE_TYPE_AGENT,
                       PROVINCE		                     ::VARCHAR(200) AS CD_PROVINCE,
                       COUNTRY		                     ::VARCHAR(200) AS CD_COUNTRY,
                       CDFREQUENCEPAIEMENT                                    AS CD_FREQUENCE_PAIEMENT,
                       0                                                      AS IND_PARTICIPATION,
                       TRY_CAST(POLICY_ACB AS DECIMAL(9,2))                   AS COUT_BASE_REAJUSTE,
                       0.00			                                    AS MNT_BALANCE_PRET,
                       CAST(1.08000 AS DECIMAL(9,2))                          AS FACTEUR_MODAL,
                       CODE_US                                 ::VARCHAR(200) AS CD_US,
                       NULL                                    ::VARCHAR(200) AS CD_EQUIPE,
                       -1                                                     AS CD_SOURCE,
                       CDTYPEPAIEMENT	                     ::VARCHAR(200) AS CD_TYPE_PAIEMENT,
                     --A VENIR EN ATTENTE DE OIPA - il n'y pas de valeur de rachat avant 5 ans.'
                       CAST(0 AS DECIMAL(9,2))                                AS MNT_VALEUR_RACHAT,
                       DT_CHARGEMENT
                FROM _COHORTE_DOMAINEVALEUR
)

SELECT * FROM _COHORTE;
create or replace schema BDV_ZIED;

create or replace TABLE BR_POLICY (
	HK_BR_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY BRIDGE BR_POLICY',
	MD_SNAPSHOT_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'SNAPSHOT DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Creation date',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_SERVICE_UNIT VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT_ALIAS_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY HUB_CLIENT FROM JOINING HUB_POLICY AND HUB_CLIENT THROUGH LINK_POLICY_OWNER',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT_ALIAS_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY HUB_CLIENT FROM JOINING HUB_COVERAGE AND HUB_CLIENT THROUGH LINK_COVERAGE_INSURED',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_LINK_AGENCY_POLICY VARCHAR(40) NOT NULL,
	HK_LINK_AGENCY_SERVICE_UNIT VARCHAR(40) NOT NULL,
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL,
	HK_LINK_COVERAGE_POLICY VARCHAR(40) NOT NULL,
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL,
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL,
	IND_IS_ACTIVE NUMBER(1,0) NOT NULL COMMENT 'Indicator LINK POLICY OWNER IS ACTIVE',
	constraint PK_BR_POLICY primary key (HK_BR_POLICY)
);
create or replace TABLE DATE_EXTRACT_OIPA_XA_RESV (
	DT_EXTRACT TIMESTAMP_NTZ(9) NOT NULL,
	primary key (DT_EXTRACT)
);
create or replace TABLE PIT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY HUB_COVERAGE',
	MD_SNAPSHOT_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'SNAPSHOT DATE',
	HK_HUB_COVERAGE_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HK COVERAGE SAT_COVERAGE_CLEAN',
	MD_START_DT_COVERAGE TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Start Dates SAT_COVERAGE_CLEAN',
	HK_HUB_COVERAGE_COVERAGE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HK COVERAGE SAT_COVERAGE_ADVISOR_CLEAN',
	MD_START_DT_COVERAGE_ADVISOR TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Start Dates SAT_COVERAGE_ADVISOR_CLEAN',
	constraint PK_PIT_COVERAGE primary key (HK_HUB_COVERAGE, MD_SNAPSHOT_DT)
);
create or replace TABLE PIT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY BRIDGE BR_POLICY',
	MD_SNAPSHOT_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'SNAPSHOT DATE',
	HK_HUB_POLICY_POLICY VARCHAR(40) NOT NULL COMMENT 'HK Policy SAT_POLICY_CLEAN',
	MD_START_DT_POLICY TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Start Dates SAT_POLICY_CLEAN',
	HK_HUB_POLICY_POLICY_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HK Policy SAT_POLICY_ADVISOR_CLEAN',
	MD_START_DT_POLICY_ADVISOR TIMESTAMP_NTZ(9) NOT NULL COMMENT 'Start Dates SAT_POLICY_ADVISOR_CLEAN',
	constraint PK_PIT_POLICY primary key (HK_HUB_POLICY, MD_SNAPSHOT_DT)
);
create or replace TABLE SAT_ADVISOR_CLEAN (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_USER VARCHAR(255),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL,
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	ADVISOR_TYPE VARCHAR(2),
	constraint PK_SAT_ADVISOR_CLEAN primary key (HK_HUB_ADVISOR, MD_START_DT)
);
create or replace TABLE SAT_COMMISSION_CLEAN (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_USER VARCHAR(255),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL,
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	COMMISSION_SHARE NUMBER(38,2),
	constraint PK_SAT_COMMISSION_CLEAN primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT)
);
create or replace TABLE SAT_COVERAGE_ADVISOR_CLEAN (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_CREATION_DT TIMESTAMP_LTZ(3),
	MD_USER VARCHAR(6),
	MD_CREATION_AUDIT_ID VARCHAR(2),
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL,
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	NB_ADVISOR_COVERAGE NUMBER(1,0),
	constraint PK_SAT_COVERAGE_ADVISOR_CLEAN primary key (HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_COVERAGE_CLEAN (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_USER VARCHAR(255),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL,
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	COVERAGE_CODE VARCHAR(50),
	COVERAGE_VERSION_CODE VARCHAR(50),
	COVERAGE_TYPE VARCHAR(2),
	COVERAGE_YEAR NUMBER(18,5),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE DATE,
	LAST_RENEWAL_DATE DATE,
	NEXT_RENEWAL_DATE DATE,
	COVERAGE_TERMINATION_DATE DATE,
	EXPIRY_DATE DATE,
	MATURITY_DATE DATE,
	COVERAGE_STATUS VARCHAR(2),
	COVERAGE_SUB_STATUS VARCHAR(2),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(2),
	TAXATION_TOBACCO_USE VARCHAR(2),
	INITIAL_TERME_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(19,2),
	CURRENT_FACE_AMOUNT NUMBER(19,2),
	COVERAGE_ANNUAL_PREMIUM NUMBER(19,2),
	RATES_REFERENCE_DATE DATE,
	COVERAGE_MODAL_PREMIUM NUMBER(19,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(19,2),
	PAID_UP_DATE DATE,
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(19,2),
	DISTRIBUTED_POLICY_FEES NUMBER(19,2),
	FACTOR_P NUMBER(19,19),
	COVERAGE_NCPI_ITD NUMBER(19,2),
	COVERAGE_TAXATION_DURATION NUMBER(4,0),
	COVERAGE_NPR_FACTOR NUMBER(19,2),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(19,2),
	IND_BASE_COVERAGE NUMBER(1,0),
	COVERAGE_EXPIRY_DATE DATE,
	COVERAGE_LIBIRATION_DATE DATE,
	constraint PK_SAT_COVERAGE_CLEAN primary key (HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_INSURED_INFORMATION_CLEAN (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_USER VARCHAR(255),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL,
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	ISSUE_AGE NUMBER(3,0),
	TOBACCO_USE VARCHAR(2),
	UNDERWRITING_GENDER VARCHAR(2),
	CURRENT_UNDERWRITING_AGE NUMBER(3,0),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(2),
	DATE_OF_BIRTH DATE,
	constraint PK_SAT_INSURED_INFORMATION_CLEAN primary key (HK_LINK_COVERAGE_INSURED, MD_START_DT)
);
create or replace TABLE SAT_POLICY_ADVISOR_CLEAN (
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(6),
	MD_CREATION_DT TIMESTAMP_LTZ(3),
	MD_USER VARCHAR(6),
	MD_CREATION_AUDIT_ID VARCHAR(2),
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL,
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	ADVISOR_CODE VARCHAR(10),
	ADVISOR_TYPE VARCHAR(2),
	constraint PK_SAT_POLICY_ADVISOR_CLEAN primary key (HK_HUB_POLICY, MD_START_DT)
);
create or replace TABLE SAT_POLICY_CLEAN (
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_USER VARCHAR(255),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL,
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	POLICY_EVENT_TYPE VARCHAR(100),
	PRODUCT_CODE VARCHAR(50),
	PRODUCT_VERSION_CODE VARCHAR(50),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(4),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(4),
	ISSUE_STATE VARCHAR(2),
	POLICY_EFFECTIVE_DATE DATE,
	LAST_REINSTATEMENT_DATE DATE,
	POLICY_STATUS VARCHAR(2),
	POLICY_SUB_STATUS VARCHAR(2),
	PAYMENT_FREQUENCY VARCHAR(2),
	NEXT_PREMIUM_DUE_DATE DATE,
	PAYMENT_METHOD VARCHAR(2),
	BILLING_STATUS VARCHAR(2),
	PAID_TO_DATE DATE,
	BILLING_INTERRUPTION_REASON VARCHAR(2),
	ANTICIPATE_BILLING_RESUME_DATE DATE,
	POLICY_ACB NUMBER(19,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(19,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(19,2),
	POLICY_ANNUAL_PREMIUM NUMBER(19,2),
	POLICY_MODAL_PREMIUM NUMBER(19,2),
	ANNUAL_POLICY_FEES NUMBER(19,2),
	MODAL_POLICY_FEES NUMBER(19,2),
	constraint PK_SAT_POLICY_CLEAN primary key (HK_HUB_POLICY, MD_START_DT)
);
create or replace TABLE SAT_POLICY_OWNER_CLEAN (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_USER VARCHAR(255),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL,
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	POLICY_OWNER_CORRESPONDENCE_INDICATOR VARCHAR(5),
	POLICY_PARTY_TYPE VARCHAR(2),
	constraint PK_SAT_POLICY_OWNER_CLEAN primary key (HK_LINK_POLICY_OWNER, MD_START_DT)
);
create or replace view VW_PIT_COVERAGE(
	HK_HUB_COVERAGE,
	MD_SNAPSHOT_DT,
	HK_HUB_COVERAGE_COVERAGE,
	MD_START_DT_COVERAGE,
	HK_HUB_COVERAGE_COVERAGE_ADVISOR,
	MD_START_DT_COVERAGE_ADVISOR
) as

WITH _Dates(Snapshot) AS 
  (SELECT Snapshot FROM 
  	((SELECT DISTINCT MD_START_DT AS Snapshot FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE) 
	UNION  
	(SELECT DISTINCT MD_START_DT AS Snapshot FROM DB_AV_DEV_DWH.RDV.SAT_COMMISSION)
	))
	
, _PIT_COVERAGE AS	
(SELECT 
  H_COV.HK_HUB_COVERAGE														  				AS HK_HUB_COVERAGE				
, _Dates.Snapshot 															  				AS MD_SNAPSHOT_DT
, CURRENT_TIMESTAMP(3) 					  				::TIMESTAMP_NTZ(9)	  				AS MD_CREATION_DT-- 'CREATION DATE'
, NVL(S_COV.HK_HUB_COVERAGE, DB_AV_DEV_DWH.RDV.GHOSTVALUE()) ::VARCHAR(40)      			AS HK_HUB_COVERAGE_COVERAGE
, NVL(S_COV.MD_START_DT, TIMESTAMP_NTZ_FROM_PARTS(1900,01,01,00,00,00))   	  				AS MD_START_DT_COVERAGE
, NVL(S_COV_ADV.HK_HUB_COVERAGE, DB_AV_DEV_DWH.RDV.GHOSTVALUE()) ::VARCHAR(40)  				AS HK_HUB_COVERAGE_COVERAGE_ADVISOR
, NVL(S_COV_ADV.MD_START_DT, TIMESTAMP_NTZ_FROM_PARTS(1900,01,01,00,00,00))   				AS MD_START_DT_COVERAGE_ADVISOR
FROM DB_AV_DEV_DWH.RDV.HUB_COVERAGE H_COV
LEFT JOIN DB_AV_DEV_DWH.RDV.SAT_COVERAGE S_COV 								ON H_COV.HK_HUB_COVERAGE = S_COV.HK_HUB_COVERAGE																		
LEFT JOIN DB_AV_DEV_DWH.BDV_ZIED.VW_SAT_COVERAGE_ADVISOR_CLEAN S_COV_ADV  	ON H_COV.HK_HUB_COVERAGE = S_COV_ADV.HK_HUB_COVERAGE
FULL JOIN _Dates
WHERE 1 = 1
AND S_COV.MD_START_DT = (SELECT max(MD_START_DT) FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE C 
						WHERE C.HK_HUB_COVERAGE = S_COV.HK_HUB_COVERAGE AND C.MD_START_DT <= _Dates.Snapshot)
AND S_COV_ADV.MD_START_DT = (SELECT max(MD_START_DT) FROM DB_AV_DEV_DWH.BDV_ZIED.VW_SAT_COVERAGE_ADVISOR_CLEAN CA 
						WHERE CA.HK_HUB_COVERAGE = S_COV.HK_HUB_COVERAGE AND CA.MD_START_DT <= _Dates.Snapshot)
)
SELECT
  HK_HUB_COVERAGE				
, MIN(MD_SNAPSHOT_DT) 														  AS MD_SNAPSHOT_DT
, HK_HUB_COVERAGE_COVERAGE
, MD_START_DT_COVERAGE
, HK_HUB_COVERAGE_COVERAGE_ADVISOR
, MD_START_DT_COVERAGE_ADVISOR
FROM _PIT_COVERAGE
WHERE NOT EXISTS (SELECT 1 FROM DB_AV_DEV_DWH.BDV_ZIED.PIT_COVERAGE PC
WHERE 	_PIT_COVERAGE.HK_HUB_COVERAGE 	= PC.HK_HUB_COVERAGE 
AND 	_PIT_COVERAGE.MD_SNAPSHOT_DT 	= PC.MD_SNAPSHOT_DT)
GROUP BY
  HK_HUB_COVERAGE
, HK_HUB_COVERAGE_COVERAGE
, MD_START_DT_COVERAGE
, HK_HUB_COVERAGE_COVERAGE_ADVISOR
, MD_START_DT_COVERAGE_ADVISOR;
create or replace view VW_SAT_COMMISSION_CLEAN(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_START_DT,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	COMMISSION_SHARE
) as 
(SELECT 
  HK_LINK_COMMISSIONABLE_ADVISOR																			AS HK_LINK_COMMISSIONABLE_ADVISOR
, NVL(TRY_CAST(NVL(MD_SOURCE, 'Unknown') AS VARCHAR(255)), 'Error')											AS MD_SOURCE
, NVL(MD_CREATION_DT, TO_TIMESTAMP('1001-01-01 00:00:00'))													AS MD_CREATION_DT
, NVL(TRY_CAST(MD_USER AS VARCHAR(255)),  'Error')															AS MD_USER
, NVL(MD_CREATION_AUDIT_ID, '-1')																			AS MD_CREATION_AUDIT_ID
, NVL(MD_START_DT, TO_TIMESTAMP('1001-01-01 00:00:00'))														AS MD_START_DT
, NVL(MD_IS_ACTIVE, 1)																						AS MD_IS_ACTIVE
, MD_HASHDIFF																								AS MD_HASHDIFF
, TO_DECIMAL(COMMISSION_SHARE) * 1.0		::DECIMAL(3,2)													AS COMMISSION_SHARE
FROM DB_AV_DEV_DWH.RDV.SAT_COMMISSION);
create or replace view VW_SAT_COVERAGE_ADVISOR_CLEAN(
	HK_HUB_COVERAGE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_START_DT,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	NB_ADVISOR_COVERAGE
) as 
WITH _Dates(Snapshot) AS 
  (SELECT Snapshot FROM 
  	(SELECT DISTINCT MD_START_DT AS Snapshot FROM DB_AV_DEV_DWH.RDV.SAT_COMMISSION) 
  )
, _SAT_COVERAGE_ADVISOR AS
(SELECT 
  L_COA.HK_HUB_COVERAGE																						AS HK_HUB_COVERAGE	
, 'SYSTEM' 																									AS MD_SOURCE
, CURRENT_TIMESTAMP(3) 																						AS MD_CREATION_DT
, 'SYSTEM'	 																								AS MD_USER
, '-1'																										AS MD_CREATION_AUDIT_ID
, _Dates.Snapshot																							AS MD_START_DT
, 1																											AS MD_IS_ACTIVE
, SHA1(
         concat_ws(
            '|',
            NVL(CASE WHEN S_COM.HK_LINK_COMMISSIONABLE_ADVISOR = '0000000000000000000000000000000000000000' 
				THEN NULL 
				ELSE COUNT(DISTINCT S_COM.HK_LINK_COMMISSIONABLE_ADVISOR) 
							OVER (PARTITION BY L_COA.HK_HUB_COVERAGE, S_COM.MD_START_DT) END ::VARCHAR(1), '#NULL#')
           ))																								AS MD_HASHDIFF
, CASE WHEN S_COM.HK_LINK_COMMISSIONABLE_ADVISOR = '0000000000000000000000000000000000000000' 
	THEN NULL 
	ELSE COUNT(DISTINCT S_COM.HK_LINK_COMMISSIONABLE_ADVISOR) 
				OVER (PARTITION BY L_COA.HK_HUB_COVERAGE, S_COM.MD_START_DT) END							AS NB_ADVISOR_COVERAGE
FROM DB_AV_DEV_DWH.RDV.LINK_COMMISSIONABLE_ADVISOR L_COA
LEFT JOIN DB_AV_DEV_DWH.RDV.SAT_COMMISSION S_COM ON L_COA.HK_LINK_COMMISSIONABLE_ADVISOR =  S_COM.HK_LINK_COMMISSIONABLE_ADVISOR
FULL JOIN _Dates
WHERE S_COM.MD_START_DT <= _Dates.Snapshot
)
SELECT 
  HK_HUB_COVERAGE
, MD_CREATION_DT
, MD_USER
, MD_CREATION_AUDIT_ID
, MIN(MD_START_DT) AS MD_START_DT
, MD_IS_ACTIVE
, MD_HASHDIFF
, NB_ADVISOR_COVERAGE
FROM _SAT_COVERAGE_ADVISOR
GROUP BY 
  HK_HUB_COVERAGE
, MD_SOURCE
, MD_CREATION_DT
, MD_USER
, MD_CREATION_AUDIT_ID
, MD_IS_ACTIVE
, MD_HASHDIFF
, NB_ADVISOR_COVERAGE
ORDER BY HK_HUB_COVERAGE;
create or replace view VW_SAT_COVERAGE_CLEAN(
	HK_HUB_COVERAGE,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_START_DT,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	COVERAGE_CODE,
	COVERAGE_VERSION_CODE,
	COVERAGE_TYPE,
	COVERAGE_YEAR,
	COVERAGE_INDEX,
	BASE_COVERAGE,
	COVERAGE_EFFECTIVE_DATE,
	LAST_RENEWAL_DATE,
	NEXT_RENEWAL_DATE,
	COVERAGE_TERMINATION_DATE,
	EXPIRY_DATE,
	MATURITY_DATE,
	COVERAGE_STATUS,
	COVERAGE_SUB_STATUS,
	TAXATION_AGE,
	TAXATION_GENDER,
	TAXATION_TOBACCO_USE,
	INITIAL_TERME_DURATION,
	INITIAL_FACE_AMOUNT,
	CURRENT_FACE_AMOUNT,
	COVERAGE_ANNUAL_PREMIUM,
	RATES_REFERENCE_DATE,
	COVERAGE_MODAL_PREMIUM,
	COVERAGE_ANNUAL_BASIC_PREMIUM,
	PAID_UP_DATE,
	COMMISSIONABLE_ANNUAL_PREMIUM,
	DISTRIBUTED_POLICY_FEES,
	FACTOR_P,
	COVERAGE_NCPI_ITD,
	COVERAGE_TAXATION_DURATION,
	COVERAGE_NPR_FACTOR,
	COVERAGE_ACB_MODAL_PREMIUM,
	IND_BASE_COVERAGE,
	COVERAGE_EXPIRY_DATE,
	COVERAGE_LIBIRATION_DATE
) as 
(SELECT 
  HK_HUB_COVERAGE																							AS HK_HUB_COVERAGE
, NVL(TRY_CAST(NVL(MD_SOURCE, 'Unknown') AS VARCHAR(255)), 'Error')											AS MD_SOURCE
, NVL(MD_CREATION_DT, TO_TIMESTAMP('1001-01-01 00:00:00'))													AS MD_CREATION_DT
, NVL(TRY_CAST(MD_USER AS VARCHAR(255)),  'Error')															AS MD_USER
, NVL(MD_CREATION_AUDIT_ID, '-1')																			AS MD_CREATION_AUDIT_ID
, NVL(MD_START_DT, TO_TIMESTAMP('1001-01-01 00:00:00'))														AS MD_START_DT
, NVL(MD_IS_ACTIVE, 1)																						AS MD_IS_ACTIVE
, MD_HASHDIFF																								AS MD_HASHDIFF
, NVL(TRY_CAST(NVL(COVERAGE_CODE, '-1') AS VARCHAR(50)), '-2')												AS COVERAGE_CODE
, NVL(TRY_CAST(NVL(COVERAGE_VERSION_CODE, '-1') AS VARCHAR(50)), '-2')										AS COVERAGE_VERSION_CODE
, NVL(TRY_CAST(NVL(COVERAGE_TYPE,'-1') AS VARCHAR(2)), '-2')												AS COVERAGE_TYPE
, NVL(COVERAGE_YEAR, -1)																					AS COVERAGE_YEAR
, CAST(NVL(COVERAGE_INDEX, -1) AS NUMBER(2,0))																AS COVERAGE_INDEX
, NVL(TRY_CAST(NVL(BASE_COVERAGE, '-1') AS VARCHAR(5)), '-2')												AS BASE_COVERAGE
, NVL(TRY_CAST(NVL(COVERAGE_EFFECTIVE_DATE, TO_DATE('1001-01-01')) AS DATE),TO_DATE('1001-01-02'))			AS COVERAGE_EFFECTIVE_DATE
, NVL(TRY_CAST(NVL(LAST_RENEWAL_DATE, TO_DATE('1001-01-01')) AS DATE),TO_DATE('1001-01-02'))				AS LAST_RENEWAL_DATE
, NVL(TRY_CAST(NVL(NEXT_RENEWAL_DATE, TO_DATE('1001-01-01')) AS DATE),TO_DATE('1001-01-02'))				AS NEXT_RENEWAL_DATE
, NVL(TRY_CAST(NVL(COVERAGE_TERMINATION_DATE, TO_DATE('1001-01-01')) AS DATE),TO_DATE('1001-01-02'))		AS COVERAGE_TERMINATION_DATE
, NVL(TRY_CAST(NVL(EXPIRY_DATE, TO_DATE('1001-01-01')) AS DATE),TO_DATE('1001-01-02'))						AS EXPIRY_DATE
, NVL(TRY_CAST(NVL(MATURITY_DATE, TO_DATE('1001-01-01')) AS DATE),TO_DATE('1001-01-02'))					AS MATURITY_DATE
, NVL(TRY_CAST(NVL(COVERAGE_STATUS, '-1') AS VARCHAR(2)), '-2')												AS COVERAGE_STATUS
, NVL(TRY_CAST(NVL(COVERAGE_SUB_STATUS, '-1') AS VARCHAR(2)), '-2')											AS COVERAGE_SUB_STATUS									
, CAST(TAXATION_AGE AS NUMBER(3,0))																			AS TAXATION_AGE
, NVL(TRY_CAST(NVL(TAXATION_GENDER, '-1') AS VARCHAR(2)), '-2')												AS TAXATION_GENDER
, NVL(TRY_CAST(NVL(TAXATION_TOBACCO_USE, '-1') AS VARCHAR(2)), '-2')										AS TAXATION_TOBACCO_USE
, CAST(INITIAL_TERM_DURATION AS NUMBER(3,0))																AS INITIAL_TERME_DURATION
, CAST(INITIAL_FACE_AMOUNT AS NUMBER(19,2))																	AS INITIAL_FACE_AMOUNT
, CAST(CURRENT_FACE_AMOUNT AS NUMBER(19,2))																	AS CURRENT_FACE_AMOUNT
, CAST(COVERAGE_ANNUAL_PREMIUM AS NUMBER(19,2))																AS COVERAGE_ANNUAL_PREMIUM
, NVL(TRY_CAST(NVL(RATES_REFERENCE_DATE, TO_DATE('1001-01-01')) AS DATE),TO_DATE('1001-01-02'))				AS RATES_REFERENCE_DATE
, CAST(COVERAGE_MODAL_PREMIUM AS NUMBER(19,2))																AS COVERAGE_MODAL_PREMIUM
, CAST(COVERAGE_ANNUAL_BASIC_PREMIUM AS NUMBER(19,2))														AS COVERAGE_ANNUAL_BASIC_PREMIUM
, NVL(TRY_CAST(NVL(PAID_UP_DATE, TO_DATE('1001-01-01')) AS DATE),TO_DATE('1001-01-02'))						AS PAID_UP_DATE
, CAST(COMMISSIONABLE_ANNUAL_PREMIUM AS NUMBER(19,2))														AS COMMISSIONABLE_ANNUAL_PREMIUM
, CAST(DISTRIBUTED_POLICY_FEES AS NUMBER(19,2))																AS DISTRIBUTED_POLICY_FEES
, CAST(FACTOR_P AS NUMBER(19,19))																			AS FACTOR_P
, CAST(COVERAGE_NCPI_ITD AS NUMBER(19,2))																	AS COVERAGE_NCPI_ITD
, CAST(COVERAGE_TAXATION_DURATION AS NUMBER(4,0))															AS COVERAGE_TAXATION_DURATION
, CAST(COVERAGE_NPR_FACTOR AS NUMBER(19,2))																	AS COVERAGE_NPR_FACTOR
, CAST(COVERAGE_ACB_MODAL_PREMIUM AS NUMBER(19,2))															AS COVERAGE_ACB_MODAL_PREMIUM
, COALESCE(CASE UPPER(BASE_COVERAGE) 	WHEN 'TRUE' THEN 1 
										WHEN 'FALSE' THEN 0 
										ELSE NULL END
			, CASE 	WHEN COVERAGE_INDEX = 1 THEN 1
					WHEN COVERAGE_INDEX IS NULL THEN -1
					ELSE 0 END
			) 																								AS IND_BASE_COVERAGE -- Indicateur couverture de base prend 1 si couverture de base 0 sinon
-- Date d'expiration de la couverture prend la date d'expiration si elle est définie 
										 -- la date de maturité si la date d'expiration n'est pas définie, 
										 -- la date de payement final si les dates date d'expiration et de maturité ne sont pas définies, 
										 -- sinon une valeur refuge indiquant une valeur manquante
, NVL(TRY_CAST(COALESCE(  EXPIRY_DATE
						, MATURITY_DATE
						, PAID_UP_DATE
						, TO_DATE('1001-01-01')
						) 
				AS DATE)
		, TO_DATE('1002-01-01'))																			AS COVERAGE_EXPIRY_DATE 
-- Date de libération de la couverture prend la date de payement final si elle est définie 
										  -- la date d'expiration si la date de payement final n'est pas définie
										  -- sinon une valeur refuge indiquant une valeur manquante
, NVL(TRY_CAST(COALESCE(  PAID_UP_DATE
						, EXPIRY_DATE
						, TO_DATE('1001-01-01')
						)
				AS DATE)
		, TO_DATE('1002-01-01'))																			AS COVERAGE_LIBIRATION_DATE 
FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE
);
create or replace schema LI2BHN_WORKSPACE;

create or replace TABLE BRE_GROUP (
	IDGROUP NUMBER(38,0) NOT NULL COMMENT 'ID DE LA TABLE',
	GROUPNAME VARCHAR(50) NOT NULL COMMENT 'NOM DU GROUPE DE RÈGLE (IMP) : C''EST PAR CE NOM QUE L''ON APPELERA LE MOTEUR',
	DESCGROUP VARCHAR(500) NOT NULL COMMENT 'DESCRIPTION DU GROUPE DE RÈGLES',
	SOURCETABLE VARCHAR(100) COMMENT 'TABLE SOURCE: TABLE OÙ LES DONNÉES NÉCESSAIRES À APPLICATION DES RÈGLES SONT SITUÉES',
	TARGETTABLE VARCHAR(100) COMMENT 'TABLE CIBLE: DESTINATION DU RÉSULTAT DU MOTEUR DE RÈGLE (INFORMATIF SEULEMENT)',
	SOURCETABLEFILTER VARCHAR(100) COMMENT 'TABLE SOURCE: Filtre à appliquer sur la table source',
	unique (GROUPNAME),
	primary key (IDGROUP)
);
create or replace TABLE BRE_LOG (
	DTSLOG TIMESTAMP_NTZ(9) NOT NULL COMMENT 'DATE DU LOG',
	USERNAME VARCHAR(100) NOT NULL COMMENT 'NOM DE L''UTILISATEUR QUI A LANCÉ LE MOTEUR',
	GROUPNAME VARCHAR(50) NOT NULL COMMENT 'NOM DU GROUPE DE RÈGLE PASSÉ DANS LE MOTEUR',
	MDDTSPOSITION TIMESTAMP_NTZ(9) NOT NULL COMMENT 'DATE DE POSITION PASSÉ DANS LE MOTEUR',
	CDLOGTYPE VARCHAR(20) NOT NULL COMMENT 'TYPE DE LOG: ERREUR, DEBUG',
	SQL VARCHAR(20000) NOT NULL COMMENT 'SQL GÉNÉRÉE PAR LE MOTEUR LORS DU LOG',
	MESSAGE VARCHAR(2000) COMMENT 'Message DU LOG'
);
create or replace TABLE BRE_RULE (
	IDRULE NUMBER(38,0) NOT NULL COMMENT 'ID DE LA TABLE',
	IDGROUP NUMBER(38,0) NOT NULL COMMENT 'ID DU GROUPE DE RÈGLE À QUI APPARTIENT CETTE RÈGLE',
	COLUMNNAME VARCHAR(100) NOT NULL COMMENT 'NOM DE LA COLONNE GÉNÉRÉE PAR CETTE RÈGLE',
	CDDATATYPE VARCHAR(50) NOT NULL COMMENT 'TYPE DE DONNÉE DE LA COLONNE GÉNÉRÉE PAR CETTE RÈGLE',
	NOLEVEL NUMBER(38,0) NOT NULL COMMENT 'NIVEAU AUQUEL S''APPLIQUE CETTE RÈGLE (0 = 1er NIVEAU, N ... 9)',
	NORULE VARCHAR(20) NOT NULL COMMENT 'NUMÉRO DE LA RÈGLE DANS NOTRE DICTIONNAIRE DE RÈGLE SHAREPOINT',
	DESCRULE VARCHAR(500) COMMENT 'DESCRIPTION DE LA RÈGLE ',
	SCRIPT VARCHAR(2000) NOT NULL COMMENT 'SCRIPT SQL PERMETTANT D''APPLIQUER LA RÈGLE (IMP: LES COLONNES INCLUSES DANS LE SCRIPT DOIVENT ÊTRE CALCULÉES/DISPONIBLES AU NIVEAU INFÉRIEUR)',
	ISVISIBLE BOOLEAN NOT NULL COMMENT 'INDICATEUR PERMETTANT D''AFFICHER OU NON LA COLONNE EN SORTIE DU MOTEUR',
	DTSSTART TIMESTAMP_NTZ(9) NOT NULL COMMENT 'DATE DE DÉBUT DE LA RÈGLE (PERMET DE CHANGER LA RÈGLE DANS LE TEMPS)',
	DTSEND TIMESTAMP_NTZ(9) NOT NULL COMMENT 'DATE DE FIN DE LA RÈGLE (PERMET DE CHANGER LA RÈGLE DANS LE TEMPS)',
	unique (IDGROUP, COLUMNNAME, DTSSTART),
	primary key (IDRULE),
	foreign key (IDGROUP) references DB_AV_DEV_DWH.LI2BHN_WORKSPACE.BRE_GROUP(IDGROUP)
);
create or replace TABLE BRE_VARIABLE (
	IDVARIABLE NUMBER(38,0) NOT NULL COMMENT 'ID DE LA TABLE',
	VARIABLENAME VARCHAR(50) NOT NULL COMMENT 'NOM DE LA VARIABLE (DOIT ÊTRE UNIQUE)',
	CDVARIABLETYPE VARCHAR(20) NOT NULL COMMENT 'TYPE DE VARIABLE (SYSTÈME : ALIMENTÉ PAR LE MOTEUR), CONSTANTE, VARIABLE',
	TAG VARCHAR(50) NOT NULL COMMENT 'TAG DE LA VARIABLE QUI SERA ',
	DESCVARIABLE VARCHAR(500) COMMENT 'DESCRIPTION DE LA VARIABLE',
	VALUE VARCHAR(1000) NOT NULL COMMENT 'VALEUR (EN FORMAT TEXTE) DE LA VARIABLE',
	DTSSTART TIMESTAMP_NTZ(9) NOT NULL COMMENT 'DATE DE DÉBUT DE LA VARIABLE (PERMET DE CHANGER LA VALEUR DE LA VARIABLE DANS LE TEMPS)',
	DTSEND TIMESTAMP_NTZ(9) NOT NULL COMMENT 'DATE DE FIN DE LA VARIABLE (PERMET DE CHANGER LA VALEUR DE LA VARIABLE DANS LE TEMPS)',
	unique (VARIABLENAME, DTSSTART),
	primary key (IDVARIABLE)
);
create or replace TABLE ZZD0101_TEST_INPUT (
	BK NUMBER(38,0) NOT NULL COMMENT 'BK',
	A NUMBER(38,0) COMMENT 'A',
	B VARCHAR(20) COMMENT 'B',
	C FLOAT COMMENT 'C',
	D FLOAT COMMENT 'D',
	primary key (BK)
);
create or replace TABLE ZZD0101_TEST_OUTPUT (
	BK NUMBER(38,0) NOT NULL COMMENT 'ID DE LA TABLE',
	E FLOAT COMMENT 'E TEST COLUMN',
	F FLOAT COMMENT 'F TEST COLUMN',
	primary key (BK)
);
create or replace schema PUBLIC;

create or replace TABLE DIM_POLICY (
	ID_DIM_POLICY NUMBER(38,0) NOT NULL autoincrement COMMENT 'SURROGATE KEY',
	POLICY_NUMBER VARCHAR(255) NOT NULL,
	CURRENCY_CD VARCHAR(255),
	ISSUE_STATE_CD VARCHAR(255),
	ISSUE_STATE_DESCRIPTION_FR VARCHAR(255),
	ISSUE_STATE_DESCRIPTION_EN VARCHAR(255),
	OWNER_RESIDENCE_STATE_CD VARCHAR(255),
	OWNER_RESIDENCE_STATE_DESCRIPTION_FR VARCHAR(255),
	OWNER_RESIDENCE_STATE_DESCRIPTION_EN VARCHAR(255),
	MD_HASHNATKEY VARCHAR(40) COMMENT 'HASHKEY',
	MD_HASHDIFF VARCHAR(40) COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_SECURITY_TYPE VARCHAR(255) COMMENT 'TBD - RLS',
	MD_DISPLAY_ORDER NUMBER(38,0) COMMENT 'DISPLAY ORDER IN REPORTS OR DASHBOARD (IF NOT ALPHA) FOR A DIMENSION',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'START DATE',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'END DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'MODIFY DATE',
	MD_MODIFY_AUDIT_ID NUMBER(38,0) COMMENT 'MODIFY AUDIT ID',
	MD_DESCRIPTION_FR VARCHAR(255) COMMENT 'DESCRIPTION FR DEFAULT VALUES',
	MD_DESCRIPTION_EN VARCHAR(255) COMMENT 'DESCRIPTION EN DEFAULT VALUES',
	MD_IS_ACTIVE BOOLEAN COMMENT 'COLUMN INDICATING IF THE OCCURRENCE IS ACTIVE OR INACTIVE',
	constraint PK_DIM_POLICY primary key (ID_DIM_POLICY)
);
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_ADVISOR_HUB_SERVICING_AGENCY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.HUB_SERVICING_AGENCY (HK_HUB_SERVICING_AGENCY,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID,AGENCY_NUMBER,SERVICE_UNIT_NUMBER) \\
(SELECT src.HK_HUB_SERVICING_AGENCY as HK_HUB_SERVICING_AGENCY, \\
src.AGENCY_NUMBER as AGENCY_NUMBER,\\
src.SERVICE_UNIT_NUMBER as SERVICE_UNIT_NUMBER,\\
min(src.MD_SOURCE) as MD_SOURCE,\\
min(src.MD_CREATION_DT) as MD_CREATION_DT,\\
min(src.MD_USER) as MD_USER, "  + "''"+CURRENTRUNID +" "+ " as o_MD_CREATION_AUDIT_ID \\
FROM DB_AV_DEV_STG.MODEL.VW_AV_POLICY_SERVICING_AGENCY_EXTRACT_DV src  \\
LEFT JOIN DB_AV_DEV_DWH.RDV.HUB_SERVICING_AGENCY tgt  on  tgt.HK_HUB_SERVICING_AGENCY = src.HK_HUB_SERVICING_AGENCY  \\
WHERE tgt.HK_HUB_SERVICING_AGENCY IS NULL \\
GROUP BY  src.HK_HUB_SERVICING_AGENCY, src.AGENCY_NUMBER, src.SERVICE_UNIT_NUMBER)" ;

var sql_statement = snowflake.createStatement({sqlText: sql_command });
var result_scan = sql_statement.execute();

return result_scan;


//return sql_command;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_POLICY_SERVICING_AGENCY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_SERVICING_AGENCY (HK_LINK_POLICY_SERVICING_AGENCY,HK_HUB_SERVICING_AGENCY,HK_HUB_POLICY,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID) \\
(SELECT src.HK_LINK_POLICY_SERVICING_AGENCY as HK_LINK_POLICY_SERVICING_AGENCY, \\
src.HK_HUB_SERVICING_AGENCY as HK_HUB_SERVICING_AGENCY \\
src.HK_HUB_POLICY as HK_HUB_POLICY,\\
min(src.MD_SOURCE) as MD_SOURCE,\\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID, \\
min(src.MD_USER) as MD_USER, \\
min(src.MD_CREATION_DT) as MD_CREATION_DT\\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_SERVICING_AGENCY_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_SERVICING_AGENCY tgt  on  tgt.HK_LINK_POLICY_SERVICING_AGENCY = src.HK_LINK_POLICY_SERVICING_AGENCY  \\
WHERE tgt.HK_LINK_POLICY_SERVICING_AGENCY IS NULL \\
GROUP BY  src.HK_LINK_POLICY_SERVICING_AGENCY, src.HK_HUB_SERVICING_AGENCY, src.HK_HUB_POLICY)" ;

var sql_statement = snowflake.createStatement({sqlText: sql_command });
var result_scan = sql_statement.execute();

return result_scan;

';
create or replace schema RDV;

create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	ADVISOR_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	ADVISOR_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(200) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'CREATION AUDIT ID',
	REINSURANCE_TREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	REINSURANCE_SUBTREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE HUB_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	REINSURER_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURER primary key (HK_HUB_REINSURER)
);
create or replace TABLE HUB_SERVICING_AGENCY (
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	AGENCY_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_SERVICING_AGENCY primary key (HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE HUB_TRANSACTION (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	TRANSACTION_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	CORRELATION_ID VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_TRANSACTION primary key (HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE LINK_COVERAGE_BENEFICIARY (
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY primary key (HK_LINK_COVERAGE_BENEFICIARY)
);
create or replace TABLE LINK_COVERAGE_BENEFICIARY_CONTINGENT (
	HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT_BENEFICIARY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT_BENEFICIARY_CONTINGENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(200) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY_CONTINGENT primary key (HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_CONTINGENT_HUB_CLIENT_BENEFICIARY foreign key (HK_HUB_CLIENT_BENEFICIARY) references DB_AV_DEV_DWH.RDV.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_CONTINGENT_HUB_CLIENT_BENEFICIARY_CONTINGENT foreign key (HK_HUB_CLIENT_BENEFICIARY_CONTINGENT) references DB_AV_DEV_DWH.RDV.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_CONTINGENT_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_SERVICING_AGENCY foreign key (HK_HUB_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV.HUB_SERVICING_AGENCY(HK_HUB_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_TRANSACTION (
	HK_LINK_POLICY_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_TRANSACTION primary key (HK_LINK_POLICY_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION primary key (HK_LINK_RISK_CESSION)
);
create or replace TABLE LINK_RISK_CESSION_TRANSACTION (
	HK_LINK_RISK_CESSION_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION_TRANSACTION primary key (HK_LINK_RISK_CESSION_TRANSACTION)
);
create or replace TABLE SAT_ACTIVITY (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ACTIVITY_EFFECTIVE_DATE VARCHAR(255),
	ACTIVITY_TYPE VARCHAR(255),
	TRANSACTION_NAME VARCHAR(255),
	ACTIVITY_PROCESSED_DATE VARCHAR(255),
	constraint PK_SAT_ACTIVITY primary key (HK_HUB_TRANSACTION, MD_START_DT)
);
create or replace TABLE SAT_APPLICATION (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CASE_NAME VARCHAR(255),
	CASE_NUMBER VARCHAR(255),
	APPLICATION_AUTOMATIC_APPROVAL VARCHAR(255),
	APPLICATION_RECEPTION_DATE VARCHAR(255),
	UNDERWRITING_APPROVAL_DATE VARCHAR(255),
	DEPOSIT_WITH_APPLICATION_AMOUNT NUMBER(38,2),
	APPLICATION_INPUT_MODE VARCHAR(255),
	APPLICATION_ELECTRONIC_SIGNATURE VARCHAR(255),
	APPLICATION_SOURCE VARCHAR(255),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_COMMISSION (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COMMISSION_SHARE VARCHAR(255),
	constraint PK_SAT_COMMISSION primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT),
	constraint FK_SAT_COMMISSION_LINK_COMMISSIONABLE_ADVISOR foreign key (HK_LINK_COMMISSIONABLE_ADVISOR) references DB_AV_DEV_DWH.RDV.LINK_COMMISSIONABLE_ADVISOR(HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,0),
	CURRENT_FACE_AMOUNT NUMBER(38,0),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,2),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,2),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,2),
	DISTRIBUTED_POLICY_FEES NUMBER(38,2),
	FACTOR_P NUMBER(38,14),
	COVERAGE_NCPI_ITD NUMBER(38,2),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,14),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_COVERAGE_UPDATED VARCHAR(255),
	ACTIVITY_PROCESSED_DATE TIMESTAMP_NTZ(9),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_COVERAGE_BENEFICIARY (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	BENEFICIARY_LEGAL_SUCCESSION VARCHAR(255),
	BENEFICIARY_REVOCABLE VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_TYPE VARCHAR(255),
	BENEFICIARY_RELATIONSHIP_TO_INSURED VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_PERCENT NUMBER(38,2),
	constraint PK_SAT_COVERAGE_BENEFICIARY primary key (DK_HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_COVERAGE_BENEFICIARY_CONTINGENT (
	HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(200) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CONTINGENT_BENEFICIARY_LEGAL_SUCCESSION VARCHAR(255),
	CONTINGENT_BENEFICIARY_REVOCABLE VARCHAR(255),
	CONTINGENT_BENEFICIARY_BENEFIT_SHARE_TYPE VARCHAR(255),
	CONTINGENT_BENEFICIARY_RELATIONSHIP_TO_INSURED VARCHAR(255),
	CONTINGENT_BENEFICIARY_BENEFIT_SHARE_PERCENT VARCHAR(255),
	constraint PK_SAT_COVERAGE_BENEFICIARY_CONTINGENT primary key (HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT, MD_START_DT),
	constraint FK_SAT_COVERAGE_BENEFICIARY_CONTINGENT_LINK_COVERAGE_BENEFICIARY_CONTINGENT foreign key (HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT) references DB_AV_DEV_DWH.RDV.LINK_COVERAGE_BENEFICIARY_CONTINGENT(HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT)
);
create or replace TABLE SAT_COVERAGE_INSURED (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	FIRST_NAME VARCHAR(255),
	LAST_NAME VARCHAR(255),
	POSTAL_CODE VARCHAR(255),
	PROVINCE VARCHAR(255),
	COUNTRY VARCHAR(255),
	constraint PK_SAT_COVERAGE_INSURED primary key (DK_HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_DEATH_CLAIM (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CLAIM_NUMBER VARCHAR(255),
	CLAIM_STATUS VARCHAR(255),
	DEATH_DATE VARCHAR(255),
	DEATH_TYPE VARCHAR(255),
	CLAIM_SETTLEMENT_TYPE VARCHAR(255),
	constraint PK_SAT_DEATH_CLAIM primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_DEATH_CLAIM_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_DEATH_CLAIM_BKP (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CLAIM_NUMBER VARCHAR(255),
	CLAIM_STATUS VARCHAR(255),
	DEATH_DATE VARCHAR(255),
	DEATH_TYPE VARCHAR(255),
	CLAIM_SETTLEMENT_TYPE VARCHAR(255),
	constraint PK_SAT_DEATH_CLAIM primary key (HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(200) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	POLICY_TERMINATION_DATE VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,2),
	POLICY_ANNUAL_PREMIUM NUMBER(38,2),
	POLICY_MODAL_PREMIUM NUMBER(38,2),
	ANNUAL_POLICY_FEES NUMBER(38,2),
	MODAL_POLICY_FEES NUMBER(38,2),
	POLICY_UPDATED VARCHAR(255),
	POLICYTERMINATIONDATE DATE,
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_BKP (
	HK_HUB_POLICY VARCHAR(40),
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_USER VARCHAR(255),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,2),
	POLICY_ANNUAL_PREMIUM NUMBER(38,2),
	POLICY_MODAL_PREMIUM NUMBER(38,2),
	ANNUAL_POLICY_FEES NUMBER(38,2),
	MODAL_POLICY_FEES NUMBER(38,2)
);
create or replace TABLE SAT_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(200) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	constraint PK_SAT_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE, MD_START_DT),
	constraint FK_SAT_POLICY_COVERAGE_LINK_POLICY_COVERAGE foreign key (HK_LINK_POLICY_COVERAGE) references DB_AV_DEV_DWH.RDV.LINK_POLICY_COVERAGE(HK_LINK_POLICY_COVERAGE)
);
create or replace TABLE SAT_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CORRESPONDENCE_INDICATOR VARCHAR(5),
	PARTY_TYPE VARCHAR(255),
	AMERICAN_RESIDENT_INDICATOR VARCHAR(255),
	LANGUAGE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER, MD_START_DT),
	constraint FK_SAT_POLICY_OWNER_LINK_POLICY_OWNER foreign key (HK_LINK_POLICY_OWNER) references DB_AV_DEV_DWH.RDV.LINK_POLICY_OWNER(HK_LINK_POLICY_OWNER)
);
create or replace TABLE SAT_POLICY_SERVICING_AGENCY (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	constraint PK_SAT_POLICY_SERVICING_AGENCY primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_SERVICING_AGENCY_LINK_POLICY_SERVICING_AGENCY foreign key (HK_LINK_POLICY_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV.LINK_POLICY_SERVICING_AGENCY(HK_LINK_POLICY_SERVICING_AGENCY)
);
create or replace TABLE SAT_REINSURANCE_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_COVERAGE_YEAR NUMBER(38,0),
	REINSURANCE_NAAR_FACTOR NUMBER(38,2),
	REINSURANCE_STOPPED_INDICATOR VARCHAR(255),
	REINSURANCE_STOP_DATE VARCHAR(255),
	RETAINED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_FACE_AMOUNT_AT_ACTIVATION NUMBER(38,2),
	REMAINING_FACE_AMOUNT_CEDED_SHARE NUMBER(38,2),
	REINSURANCE_REFERENCE_DATE VARCHAR(255),
	REINSURANCE_EFFECTIVE_DATE VARCHAR(255),
	INITIAL_TERM_DURATION VARCHAR(255),
	constraint PK_SAT_REINSURANCE_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_REINSURANCE_INSURED (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_ISSUE_AGE VARCHAR(255),
	REINSURANCE_GENDER VARCHAR(255),
	REINSURANCE_TOBACCO_USE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_INSURED primary key (HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_GROUP_CODE VARCHAR(255),
	CESSION_MODE VARCHAR(255),
	REINSURANCE_TYPE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY, MD_START_DT)
);
create or replace TABLE SAT_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	NAME VARCHAR(255),
	constraint PK_SAT_REINSURER primary key (HK_HUB_REINSURER, MD_START_DT)
);
create or replace TABLE SAT_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID VARCHAR(500) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_NAAR NUMBER(38,2),
	REINSURED_FACE_AMOUNT_SHARE NUMBER(38,2),
	RISK_CESSION_DATE VARCHAR(255),
	REINSURANCE_GROSS_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	RISK_CESSION_ADJUSTEMENT_ORIGIN VARCHAR(255),
	constraint PK_SAT_RISK_CESSION primary key (HK_LINK_RISK_CESSION, MD_START_DT)
);
create or replace TABLE VW_AV_POLICY_SERVICING_AGENCY_EXTRACT_DV (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY)
);
create or replace TABLE VW_LINK_COVERAGE_BENEFICIARY (
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY primary key (HK_LINK_COVERAGE_BENEFICIARY)
);
create or replace TABLE VW_SAT_POLICY_LAST_ROW (
	HK_HUB_POLICY VARCHAR(40),
	MD_HASHDIFF VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	IND_LAST_ROW NUMBER(1,0)
);
create or replace TABLE VW_SAT_POLICY_LAST_ROW_BKP (
	HK_HUB_POLICY VARCHAR(40),
	MD_HASHDIFF VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	IND_LAST_ROW NUMBER(1,0)
);
create or replace view VW_INFORMATION_TABLES(
	TABLE_CATALOG,
	TABLE_SCHEMA,
	TABLE_NAME,
	COLUMN_NAME,
	ORDINAL_POSITION,
	DATA_TYPE,
	LENGTH,
	SCALE,
	TABLE_COMMENT,
	COLUMN_COMMENT
) as

SELECT 
T.TABLE_CATALOG, T.TABLE_SCHEMA, T.TABLE_NAME,  
C.COLUMN_NAME, C.ORDINAL_POSITION, 
C.DATA_TYPE, 
COALESCE (C.CHARACTER_MAXIMUM_LENGTH, C.NUMERIC_PRECISION) AS LENGTH,
COALESCE (C.NUMERIC_SCALE, C.DATETIME_PRECISION) AS SCALE,
T.COMMENT AS TABLE_COMMENT, C.COMMENT AS COLUMN_COMMENT
FROM INFORMATION_SCHEMA.TABLES T
INNER JOIN INFORMATION_SCHEMA.COLUMNS C
	ON T.TABLE_CATALOG    = C.TABLE_CATALOG
	AND T.TABLE_SCHEMA    = C.TABLE_SCHEMA
	AND T.TABLE_NAME      = C.TABLE_NAME
WHERE T.TABLE_TYPE = 'BASE TABLE' AND T.TABLE_SCHEMA = 'RDV';
create or replace view VW_SAT_ACTIVITY_LAST_ROW(
	HK_HUB_TRANSACTION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_TRANSACTION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_TRANSACTION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_ACTIVITY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_APPLICATION_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_APPLICATION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COMMISSION_LAST_ROW(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COMMISSIONABLE_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COMMISSIONABLE_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COMMISSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_CONTINGENT_DELETED_ROW(
	MD_START_DT,
	HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	CONTINGENT_BENEFICIARY_LEGAL_SUCCESSION,
	CONTINGENT_BENEFICIARY_REVOCABLE,
	CONTINGENT_BENEFICIARY_BENEFIT_SHARE_TYPE,
	CONTINGENT_BENEFICIARY_RELATIONSHIP_TO_INSURED,
	CONTINGENT_BENEFICIARY_BENEFIT_SHARE_PERCENT
) as
WITH 

--Choisir les lignes dont Previous_MD_HASHDIFF = '#First#' pour minimiser la quantité des données à traiter
SRC_VW AS (
SELECT HK_HUB_COVERAGE, HK_HUB_CLIENT_BENEFICIARY, HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT, MD_START_DT
--Ajouter la date minimun par driving key
, MIN (MD_START_DT) OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT) AS MIN_MD_START_DT
FROM DB_AV_DEV_STG.MODEL.VW_AV_COVERAGE_BENEFICIARY_CONTINGENT_EXTRACT_DV
WHERE Previous_MD_HASHDIFF = '#First#'
),

--Choisir les enregistrements dont sa date est égal à la date minimun par driving key
DT_VW AS (
SELECT *
--Choisir le premier enregistrement dont ses dates sont égales
, ROW_NUMBER () OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT) RN
FROM SRC_VW
WHERE MD_START_DT = MIN_MD_START_DT
)

--Ajouter les lignes qui ont été supprimmées par rapport au dernier chargement
SELECT 
 DT.MD_START_DT AS MD_START_DT
,S.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT
,S.MD_SOURCE
,CURRENT_TIMESTAMP(3) AS MD_CREATION_DT
,S.MD_USER
,-1 AS MD_CREATION_AUDIT_ID
,0 AS MD_IS_ACTIVE
,DB_AV_DEV_STG.REPOSITORY.UDF_DWH_FRMK_GENERATEHASHKEY_6(
  S.CONTINGENT_BENEFICIARY_LEGAL_SUCCESSION,S.CONTINGENT_BENEFICIARY_REVOCABLE,S.CONTINGENT_BENEFICIARY_BENEFIT_SHARE_TYPE
 ,S.CONTINGENT_BENEFICIARY_RELATIONSHIP_TO_INSURED,S.CONTINGENT_BENEFICIARY_BENEFIT_SHARE_PERCENT,0) AS MD_HASHDIFF 
,S.CONTINGENT_BENEFICIARY_LEGAL_SUCCESSION
,S.CONTINGENT_BENEFICIARY_REVOCABLE
,S.CONTINGENT_BENEFICIARY_BENEFIT_SHARE_TYPE
,S.CONTINGENT_BENEFICIARY_RELATIONSHIP_TO_INSURED
,S.CONTINGENT_BENEFICIARY_BENEFIT_SHARE_PERCENT

FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_BENEFICIARY_CONTINGENT S
INNER JOIN DB_AV_DEV_DWH.RDV.LINK_COVERAGE_BENEFICIARY_CONTINGENT L
	ON L.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT = S.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT 
--Jointure pour choisir les dernieres lignes inserées dans le satellite
INNER JOIN DB_AV_DEV_DWH.RDV.VW_SAT_COVERAGE_BENEFICIARY_CONTINGENT_LAST_ROW DM 
	ON DM.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT = S.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT 
	AND DM.MD_START_DT = S.MD_START_DT
--Jointure pour choisir les couvertures qui seront affectées et savoir la date minimun par driving key qui va être inserée dans le satellite
--Date minimun = date de suppression du HK_LINK
INNER JOIN DT_VW DT
	ON DT.HK_HUB_COVERAGE = L.HK_HUB_COVERAGE
	AND DT.RN = 1
--Jointure pour savoir les HK_LINK qui seront seront inserées dans le satellite
LEFT JOIN DT_VW SVW
	ON SVW.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT = S.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT
WHERE SVW.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT IS NULL AND S.MD_IS_ACTIVE = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_CONTINGENT_LAST_ROW(
	HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_BENEFICIARY_CONTINGENT
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_DELETED_ROW(
	MD_START_DT,
	HK_LINK_COVERAGE_BENEFICIARY,
	MD_SOURCE,
	MD_CREATION_DT,
	MD_USER,
	MD_CREATION_AUDIT_ID,
	MD_IS_ACTIVE,
	MD_HASHDIFF,
	BENEFICIARY_LEGAL_SUCCESSION,
	BENEFICIARY_REVOCABLE,
	BENEFICIARY_BENEFIT_SHARE_TYPE,
	BENEFICIARY_RELATIONSHIP_TO_INSURED,
	BENEFICIARY_BENEFIT_SHARE_PERCENT
) as
WITH 

--Choisir les lignes dont Previous_MD_HASHDIFF = '#First#' pour minimiser la quantité des données à traiter
SRC_VW AS (
SELECT HK_HUB_COVERAGE, HK_LINK_COVERAGE_BENEFICIARY, MD_START_DT
--Ajouter la date minimun par driving key
, MIN (MD_START_DT) OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT) AS MIN_MD_START_DT
FROM DB_AV_DEV_STG.MODEL.VW_AV_COVERAGE_BENEFICIARY_EXTRACT_DV
WHERE Previous_MD_HASHDIFF = '#First#'
),

--Choisir les enregistrements dont sa date est égal à la date minimun par driving key
DT_VW AS (
SELECT *
--Choisir le premier enregistrement dont ses dates sont égales
, ROW_NUMBER () OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT) RN
FROM SRC_VW
WHERE MD_START_DT = MIN_MD_START_DT
)

--Ajouter les lignes qui ont été supprimmées par rapport au dernier chargement
SELECT 
 DT.MD_START_DT AS MD_START_DT
,S.HK_LINK_COVERAGE_BENEFICIARY
,S.MD_SOURCE
,CURRENT_TIMESTAMP(3) AS MD_CREATION_DT
,S.MD_USER
,-1 AS MD_CREATION_AUDIT_ID
,0 AS MD_IS_ACTIVE
,DB_AV_DEV_STG.REPOSITORY.UDF_DWH_FRMK_GENERATEHASHKEY_6(
 S.BENEFICIARY_LEGAL_SUCCESSION,S.BENEFICIARY_REVOCABLE,S.BENEFICIARY_BENEFIT_SHARE_TYPE
 ,S.BENEFICIARY_RELATIONSHIP_TO_INSURED,S.BENEFICIARY_BENEFIT_SHARE_PERCENT,0) AS MD_HASHDIFF
,S.BENEFICIARY_LEGAL_SUCCESSION
,S.BENEFICIARY_REVOCABLE
,S.BENEFICIARY_BENEFIT_SHARE_TYPE
,S.BENEFICIARY_RELATIONSHIP_TO_INSURED
,S.BENEFICIARY_BENEFIT_SHARE_PERCENT
FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_BENEFICIARY S
INNER JOIN DB_AV_DEV_DWH.RDV.LINK_COVERAGE_BENEFICIARY L 
	ON L.HK_LINK_COVERAGE_BENEFICIARY = S.HK_LINK_COVERAGE_BENEFICIARY
--Jointure pour choisir les dernieres lignes inserées dans le satellite par driving key
INNER JOIN DB_AV_DEV_DWH.RDV.VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW DM 
	ON DM.HK_LINK_COVERAGE_BENEFICIARY = S.HK_LINK_COVERAGE_BENEFICIARY 
	AND DM.MD_START_DT = S.MD_START_DT
--Jointure pour choisir les couvertures qui seront affectées et savoir la date minimun par driving key qui va être inserée dans le satellite
--Date minimun = date de suppression du HK_LINK
INNER JOIN DT_VW DT
	ON DT.HK_HUB_COVERAGE = L.HK_HUB_COVERAGE
	AND DT.RN = 1
--Jointure pour savoir les HK_LINK qui seront seront inserées dans le satellite
LEFT JOIN DT_VW SVW
	ON SVW.HK_LINK_COVERAGE_BENEFICIARY = S.HK_LINK_COVERAGE_BENEFICIARY
WHERE SVW.HK_LINK_COVERAGE_BENEFICIARY IS NULL AND S.MD_IS_ACTIVE = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_BENEFICIARY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_BENEFICIARY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_BENEFICIARY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_INSURED_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_INSURED,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_INSURED,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_DEATH_CLAIM_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_DEATH_CLAIM
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_COVERAGE_LAST_ROW(
	HK_LINK_POLICY_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_POLICY_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_POLICY_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV.SAT_POLICY_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW_BKP1(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_OWNER_LAST_ROW(
	HK_LINK_POLICY_OWNER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_POLICY_OWNER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_POLICY_OWNER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY_OWNER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_SERVICING_AGENCY_LAST_ROW(
	DK_HK_HUB_POLICY,
	HK_LINK_POLICY_SERVICING_AGENCY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_POLICY,
            HK_LINK_POLICY_SERVICING_AGENCY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY_SERVICING_AGENCY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_INSURED_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_TREATY_LAST_ROW(
	HK_HUB_REINSURANCE_TREATY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURANCE_TREATY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURANCE_TREATY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_TREATY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURER_LAST_ROW(
	HK_HUB_REINSURER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_RISK_CESSION_LAST_ROW(
	HK_LINK_RISK_CESSION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_RISK_CESSION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_RISK_CESSION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_RISK_CESSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
CREATE OR REPLACE FUNCTION "GHOSTVALUE"()
RETURNS VARCHAR(40)
LANGUAGE SQL
AS '
    REPEAT(''0'',40)
';
CREATE OR REPLACE PROCEDURE "INSERT_AV_LINK_POLICY_OWNER"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_OWNER (HK_LINK_POLICY_OWNER,HK_HUB_CLIENT,HK_HUB_POLICY,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID) \\n \\
 (SELECT src.HK_LINK_POLICY_OWNER as HK_LINK_POLICY_OWNER, \\n \\
 src.HK_HUB_POLICY as HK_HUB_POLICY, \\n \\
 src.HK_HUB_CLIENT as HK_HUB_CLIENT, \\n \\
 min(src.MD_SOURCE) as MD_SOURCE, \\n \\
 min(src.MD_CREATION_DT) as MD_CREATION_DT, \\n \\
 min(src.MD_USER) as MD_USER, "  + "''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID \\n \\
 FROM DB_AV_"+ENV+"_STG.MODEL.VW_AV_POLICY_OWNER_EXTRACT_DV src   \\n \\
 LEFT JOIN DB_AV_"+ENV+"_DWH.RDV.LINK_POLICY_OWNER tgt  on  tgt.HK_LINK_POLICY_OWNER = src.HK_LINK_POLICY_OWNER \\n \\
 WHERE tgt.HK_LINK_POLICY_OWNER IS NULL \\n \\
GROUP BY src.HK_LINK_POLICY_OWNER,src.HK_HUB_POLICY,src.HK_HUB_CLIENT)" ;
try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "P_CONV_INSERT_AV_SAT_POLICY_SERVICING_AGENCY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n \\
	INTO\\n \\
	DB_AV_" + ENV +"_DWH.RDV.SAT_COMMISSION\\n \\
	(HK_LINK_COMMISSIONABLE_ADVISOR,\\n \\
COMMISSION_SHARE,\\n \\
MD_IS_ACTIVE,\\n \\
MD_USER,\\n \\
MD_HASHDIFF,\\n \\
MD_START_DT,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_AUDIT_ID,\\n \\
MD_CREATION_DT)\\n \\
	WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.HK_LINK_COMMISSIONABLE_ADVISOR AS lkp_HK_LINK_COMMISSIONABLE_ADVISOR,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''''#First#'''' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n \\
            OR lkp.HK_LINK_COMMISSIONABLE_ADVISOR IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_COMMISSION_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_COMMISSION_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.HK_LINK_COMMISSIONABLE_ADVISOR = src.HK_LINK_COMMISSIONABLE_ADVISOR),\\n \\
sub2 AS \\n \\
(\\n \\
SELECT\\n \\
    sub1.*,\\n \\
    CASE\\n \\
        WHEN (sub1.INSERT_CRITERIA = 1\\n \\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n \\
        OR (lkp_HK_LINK_COMMISSIONABLE_ADVISOR IS NULL) THEN 1\\n \\
        ELSE 0\\n \\
    END AS INSERT_CRITERIA_HASHDIFF\\n \\
FROM\\n \\
    sub1\\n \\
)\\n \\
SELECT\\n \\
    HK_LINK_COMMISSIONABLE_ADVISOR,\\n \\
	COMMISSION_SHARE,\\n \\
	MD_IS_ACTIVE,\\n \\
	MD_USER,\\n \\
	MD_HASHDIFF,\\n \\
	MD_START_DT,\\n \\
	MD_SOURCE,\\n \\
	MD_CREATION_AUDIT_ID,\\n \\
	"+ "''" + o_MD_CREATION_AUDIT_ID + "''" +" AS MD_CREATION_AUDIT_ID,\\n \\
	MD_CREATION_DT\\n \\
	FROM\\n \\
	sub2\\n \\
	WHERE\\n \\
	INSERT_CRITERIA_HASHDIFF = 1";

try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_ADVISOR_HUB_ADVISOR"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  \\n \\
DB_AV_"+ ENV + "_DWH.RDV.HUB_ADVISOR \\n \\
(HK_HUB_ADVISOR, \\n \\
ADVISOR_CODE, \\n \\
ADVISOR_TYPE, \\n \\
MD_SOURCE, \\n \\
MD_CREATION_DT, \\n \\
MD_USER, \\n \\
MD_CREATION_AUDIT_ID)  \\n \\
(SELECT src.HK_HUB_ADVISOR as HK_HUB_ADVISOR, \\n \\
src.ADVISOR_CODE as ADVISOR_CODE,\\n \\
src.ADVISOR_TYPE as ADVISOR_TYPE,\\n \\
min(src.MD_SOURCE) as MD_SOURCE,\\n \\
min(src.MD_CREATION_DT) as MD_CREATION_DT,\\n \\
min(src.MD_USER) as MD_USER, \\n \\
 "  + "''" +CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID \\n \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_ADVISOR_EXTRACT_DV src  \\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.HUB_ADVISOR tgt  on  tgt.HK_HUB_ADVISOR = src.HK_HUB_ADVISOR  \\n \\
WHERE tgt.HK_HUB_ADVISOR IS NULL \\n \\
GROUP BY  src.HK_HUB_ADVISOR, \\n \\
 src.ADVISOR_CODE,  \\n \\
 src.ADVISOR_TYPE)" ;

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\n Stack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_ADVISOR_HUB_COVERAGE"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.HUB_COVERAGE (HK_HUB_COVERAGE,COVERAGE_IDENTIFIER,MD_SOURCE,MD_CREATION_AUDIT_ID,MD_USER,MD_CREATION_DT) \\
SELECT src.HK_HUB_COVERAGE as HK_HUB_COVERAGE, \\
src.COVERAGE_IDENTIFIER as COVERAGE_IDENTIFIER,\\
min(src.MD_SOURCE) as MD_SOURCE,\\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID, \\
min(src.MD_USER) as MD_USER, \\
min(src.MD_CREATION_DT) as MD_CREATION_DT \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_COVERAGE_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.HUB_COVERAGE tgt  on  tgt.HK_HUB_COVERAGE = src.HK_HUB_COVERAGE  \\
WHERE tgt.HK_HUB_COVERAGE IS NULL \\
GROUP BY  src.HK_HUB_COVERAGE, src.COVERAGE_IDENTIFIER" ;

var sql_statement = snowflake.createStatement({sqlText: sql_command });
var result_scan = sql_statement.execute();

return result_scan;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_ADVISOR_HUB_SERVICING_AGENCY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  \\n \\
DB_AV_"+ ENV + "_DWH.RDV.HUB_SERVICING_AGENCY \\n \\
(HK_HUB_SERVICING_AGENCY, \\n \\
AGENCY_NUMBER, \\n \\
SERVICE_UNIT_NUMBER, \\n \\
MD_SOURCE, \\n \\
MD_CREATION_DT, \\n \\
MD_USER, \\n \\
MD_CREATION_AUDIT_ID)  \\n \\
(SELECT src.HK_HUB_SERVICING_AGENCY as HK_HUB_SERVICING_AGENCY, \\n \\
src.AGENCY_NUMBER as AGENCY_NUMBER,\\n \\
src.SERVICE_UNIT_NUMBER as SERVICE_UNIT_NUMBER,\\n \\
min(src.MD_SOURCE) as MD_SOURCE,\\n \\
min(src.MD_CREATION_DT) as MD_CREATION_DT,\\n \\
min(src.MD_USER) as MD_USER, \\n \\
 "  + "''" +CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID \\n \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_SERVICING_AGENCY_EXTRACT_DV src  \\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.HUB_SERVICING_AGENCY tgt  on  tgt.HK_HUB_SERVICING_AGENCY = src.HK_HUB_SERVICING_AGENCY  \\n \\
WHERE tgt.HK_HUB_SERVICING_AGENCY IS NULL \\n \\
GROUP BY  src.HK_HUB_SERVICING_AGENCY , \\n \\
 src.AGENCY_NUMBER,  \\n \\
 src.SERVICE_UNIT_NUMBER)" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\ nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_COMMISSION_SAT_COMMISSION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result = "";
var o_MD_CREATION_AUDIT_ID = CURRENTRUNID ; 
var sql_command = "INSERT INTO
 
DB_AV_"+ ENV +"_DWH.RDV.SAT_COMMISSION(HK_LINK_COMMISSIONABLE_ADVISOR,
 
COMMISSION_SHARE,
 
MD_IS_ACTIVE,
 
MD_USER,
 
MD_START_DT,
 
MD_HASHDIFF,
 
MD_SOURCE,
 
MD_CREATION_AUDIT_ID,
 
MD_CREATION_DT)
 
WITH sub1 AS
 
(
 
SELECT
 
    src.*,
 
    lkp.MD_START_DT AS lkp_MD_START_DT,
 
    lkp.HK_LINK_COMMISSIONABLE_ADVISOR AS lkp_HK_LINK_COMMISSIONABLE_ADVISOR,
 
    CASE
 
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE
 
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF
 
            OR lkp.HK_LINK_COMMISSIONABLE_ADVISOR IS NULL THEN 1
 
            ELSE 0
 
        END
 
        ELSE 1
 
    END AS INSERT_CRITERIA
 
FROM
 
    DB_AV_"+ ENV +"_STG.MODEL.VW_AV_COMMISSION_EXTRACT_DV src
 
LEFT JOIN DB_AV_"+ ENV +"_DWH.RDV.VW_SAT_COMMISSION_LAST_ROW lkp
 
ON
 
    lkp.HK_LINK_COMMISSIONABLE_ADVISOR = src.HK_LINK_COMMISSIONABLE_ADVISOR),
 
sub2 AS
 
(
 
SELECT
 
    sub1.*,
 
    CASE
 
        WHEN (sub1.INSERT_CRITERIA = 1
 
            AND sub1.MD_START_DT > lkp_MD_START_DT)
 
        OR (HK_LINK_COMMISSIONABLE_ADVISOR IS NULL) THEN 1
 
        ELSE 0
 
    END AS INSERT_CRITERIA_HASHDIFF
 
FROM
 
    sub1
 
)
 
SELECT
 
    HK_LINK_COMMISSIONABLE_ADVISOR,
 
	COMMISSION_SHARE,
 
	MD_IS_ACTIVE,
 
	MD_USER,
 
	MD_HASHDIFF,
 
	MD_START_DT,
 
	MD_SOURCE,
 
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,
 
	MD_CREATION_DT
 
FROM
 
    sub2
 
WHERE
 
    INSERT_CRITERIA_HASHDIFF = 1";

try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  ""
 Failed: Code: "" + err.code + ""
  State: "" + err.state;
        result += ""
 Message: "" + err.message;
        result += "" 
 Stack Trace:"" + err.stackTraceTxt;
        throw result; 
    }
return result;   

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_COVERAGE_HUB_COVERAGE"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.HUB_COVERAGE (HK_HUB_COVERAGE,COVERAGE_IDENTIFIER,MD_SOURCE,MD_CREATION_AUDIT_ID,MD_USER,MD_CREATION_DT)\\
SELECT src.HK_HUB_COVERAGE as HK_HUB_COVERAGE, \\
src.COVERAGE_IDENTIFIER as COVERAGE_IDENTIFIER,\\
min(src.MD_SOURCE) as MD_SOURCE,\\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID, \\
min(src.MD_USER) as MD_USER, \\
min(src.MD_CREATION_DT) as MD_CREATION_DT \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_COVERAGE_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.HUB_COVERAGE tgt  on  tgt.HK_HUB_COVERAGE = src.HK_HUB_COVERAGE  \\
WHERE tgt.HK_HUB_COVERAGE IS NULL \\
GROUP BY  src.HK_HUB_COVERAGE, src.COVERAGE_IDENTIFIER" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_COVERAGE_LINK_COVERAGE"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_COVERAGE (HK_LINK_POLICY_COVERAGE,HK_HUB_POLICY,HK_HUB_COVERAGE,MD_SOURCE,MD_CREATION_AUDIT_ID,MD_USER,MD_CREATION_DT)\\
SELECT src.HK_LINK_POLICY_COVERAGE as HK_LINK_POLICY_COVERAGE, \\
src.HK_HUB_POLICY as HK_HUB_POLICY,\\
src.HK_HUB_COVERAGE as HK_HUB_COVERAGE,\\
min(src.MD_SOURCE) as MD_SOURCE,\\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID, \\
min(src.MD_USER) as MD_USER, \\
min(src.MD_CREATION_DT) as MD_CREATION_DT \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_COVERAGE_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_COVERAGE tgt  on  tgt.HK_LINK_POLICY_COVERAGE = src.HK_LINK_POLICY_COVERAGE  \\
WHERE tgt.HK_LINK_POLICY_COVERAGE IS NULL \\
GROUP BY  src.HK_HUB_COVERAGE, src.HK_HUB_POLICY, src.HK_LINK_POLICY_COVERAGE" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_COVERAGE_SAT_COVERAGE"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n\\
	INTO\\n\\
	DB_AV_" + ENV +"_DWH.RDV.SAT_COVERAGE\\n\\
	(HK_HUB_COVERAGE,\\n\\
	MD_SOURCE,\\n\\
	MD_CREATION_DT,\\n\\
	MD_USER,\\n\\
	MD_CREATION_AUDIT_ID,\\n\\
	MD_START_DT,\\n\\
	MD_IS_ACTIVE,\\n\\
	MD_HASHDIFF,\\n\\
	COVERAGE_CODE,\\n\\
	COVERAGE_VERSION_CODE,\\n\\
	COVERAGE_TYPE,\\n\\
	COVERAGE_YEAR,\\n\\
	COVERAGE_INDEX,\\n\\
	BASE_COVERAGE,\\n\\
	COVERAGE_EFFECTIVE_DATE,\\n\\
	LAST_RENEWAL_DATE,\\n\\
	NEXT_RENEWAL_DATE,\\n\\
	COVERAGE_TERMINATION_DATE,\\n\\
	EXPIRY_DATE,\\n\\
	MATURITY_DATE,\\n\\
	COVERAGE_STATUS,\\n\\
	COVERAGE_SUB_STATUS,\\n\\
	TAXATION_AGE,\\n\\
	TAXATION_GENDER,\\n\\
	TAXATION_TOBACCO_USE,\\n\\
	INITIAL_TERM_DURATION,\\n\\
	INITIAL_FACE_AMOUNT,\\n\\
	CURRENT_FACE_AMOUNT,\\n\\
	COVERAGE_ANNUAL_PREMIUM,\\n\\
	RATES_REFERENCE_DATE,\\n\\
	COVERAGE_MODAL_PREMIUM,\\n\\
	COVERAGE_ANNUAL_BASIC_PREMIUM,\\n\\
	PAID_UP_DATE,\\n\\
	COMMISSIONABLE_ANNUAL_PREMIUM,\\n\\
	DISTRIBUTED_POLICY_FEES,\\n\\
	FACTOR_P,\\n\\
	COVERAGE_NCPI_ITD,\\n\\
	COVERAGE_TAXATION_DURATION,\\n\\
	COVERAGE_NPR_FACTOR,\\n\\
	COVERAGE_ACB_MODAL_PREMIUM,\\n\\
	POLICY_COVERAGE_UPDATED,\\n\\
	ACTIVITY_PROCESSED_DATE)\\n\\
	WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_HUB_COVERAGE AS lkp_HK_HUB_COVERAGE,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_HUB_COVERAGE IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_COVERAGE_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_COVERAGE_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_HUB_COVERAGE = src.HK_HUB_COVERAGE),\\n\\
sub2 AS \\n\\
(\\n\\
SELECT\\n\\
    sub1.*,\\n\\
    CASE\\n\\
        WHEN (sub1.INSERT_CRITERIA = 1\\n\\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n\\
        OR (lkp_HK_HUB_COVERAGE IS NULL) THEN 1\\n\\
        ELSE 0\\n\\
    END AS INSERT_CRITERIA_HASHDIFF\\n\\
FROM\\n\\
    sub1\\n\\
)\\n\\
SELECT\\n\\
    HK_HUB_COVERAGE,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    COVERAGE_CODE,\\n\\
    COVERAGE_VERSION_CODE,\\n\\
    COVERAGE_TYPE,\\n\\
    COVERAGE_YEAR,\\n\\
    COVERAGE_INDEX,\\n\\
    BASE_COVERAGE,\\n\\
    COVERAGE_EFFECTIVE_DATE,\\n\\
    LAST_RENEWAL_DATE,\\n\\
    NEXT_RENEWAL_DATE,\\n\\
    COVERAGE_TERMINATION_DATE,\\n\\
    EXPIRY_DATE,\\n\\
    MATURITY_DATE,\\n\\
    COVERAGE_STATUS,\\n\\
    COVERAGE_SUB_STATUS,\\n\\
    TAXATION_AGE,\\n\\
    TAXATION_GENDER,\\n\\
    TAXATION_TOBACCO_USE,\\n\\
    INITIAL_TERM_DURATION,\\n\\
    INITIAL_FACE_AMOUNT,\\n\\
    CURRENT_FACE_AMOUNT,\\n\\
    COVERAGE_ANNUAL_PREMIUM,\\n\\
    RATES_REFERENCE_DATE,\\n\\
    COVERAGE_MODAL_PREMIUM,\\n\\
    COVERAGE_ANNUAL_BASIC_PREMIUM,\\n\\
    PAID_UP_DATE,\\n\\
    COMMISSIONABLE_ANNUAL_PREMIUM,\\n\\
    DISTRIBUTED_POLICY_FEES,\\n\\
    FACTOR_P,\\n\\
    COVERAGE_NCPI_ITD,\\n\\
    COVERAGE_TAXATION_DURATION,\\n\\
    COVERAGE_NPR_FACTOR,\\n\\
    COVERAGE_ACB_MODAL_PREMIUM,\\n\\
    POLICY_COVERAGE_UPDATED,\\n\\
	ACTIVITY_PROCESSED_DATE\\n\\
FROM\\n\\
    sub2\\n\\
WHERE\\n\\
    INSERT_CRITERIA_HASHDIFF = 1";

try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_COVERAGE_SAT_COVERAGE_BKP"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n\\
	INTO\\n\\
	DB_AV_" + ENV +"_DWH.RDV.SAT_COVERAGE\\n\\
	(HK_HUB_COVERAGE,\\n\\
	MD_SOURCE,\\n\\
	MD_CREATION_DT,\\n\\
	MD_USER,\\n\\
	MD_CREATION_AUDIT_ID,\\n\\
	MD_START_DT,\\n\\
	MD_IS_ACTIVE,\\n\\
	MD_HASHDIFF,\\n\\
	COVERAGE_CODE,\\n\\
	COVERAGE_VERSION_CODE,\\n\\
	COVERAGE_TYPE,\\n\\
	COVERAGE_YEAR,\\n\\
	COVERAGE_INDEX,\\n\\
	BASE_COVERAGE,\\n\\
	COVERAGE_EFFECTIVE_DATE,\\n\\
	LAST_RENEWAL_DATE,\\n\\
	NEXT_RENEWAL_DATE,\\n\\
	COVERAGE_TERMINATION_DATE,\\n\\
	EXPIRY_DATE,\\n\\
	MATURITY_DATE,\\n\\
	COVERAGE_STATUS,\\n\\
	COVERAGE_SUB_STATUS,\\n\\
	TAXATION_AGE,\\n\\
	TAXATION_GENDER,\\n\\
	TAXATION_TOBACCO_USE,\\n\\
	INITIAL_TERM_DURATION,\\n\\
	INITIAL_FACE_AMOUNT,\\n\\
	CURRENT_FACE_AMOUNT,\\n\\
	COVERAGE_ANNUAL_PREMIUM,\\n\\
	RATES_REFERENCE_DATE,\\n\\
	COVERAGE_MODAL_PREMIUM,\\n\\
	COVERAGE_ANNUAL_BASIC_PREMIUM,\\n\\
	PAID_UP_DATE,\\n\\
	COMMISSIONABLE_ANNUAL_PREMIUM,\\n\\
	DISTRIBUTED_POLICY_FEES,\\n\\
	FACTOR_P,\\n\\
	COVERAGE_NCPI_ITD,\\n\\
	COVERAGE_TAXATION_DURATION,\\n\\
	COVERAGE_NPR_FACTOR,\\n\\
	COVERAGE_ACB_MODAL_PREMIUM,\\n\\
	POLICY_COVERAGE_UPDATED)\\n\\
	WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_HUB_COVERAGE AS lkp_HK_HUB_COVERAGE,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF != lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_HUB_COVERAGE IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_COVERAGE_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_COVERAGE_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_HUB_COVERAGE = src.HK_HUB_COVERAGE),\\n\\
sub2 AS \\n\\
(\\n\\
SELECT\\n\\
    sub1.*,\\n\\
    CASE\\n\\
        WHEN (sub1.INSERT_CRITERIA = 1\\n\\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n\\
        OR (lkp_HK_HUB_COVERAGE IS NULL) THEN 1\\n\\
        ELSE 0\\n\\
    END AS INSERT_CRITERIA_HASHDIFF\\n\\
FROM\\n\\
    sub1\\n\\
)\\n\\
SELECT\\n\\
    HK_HUB_COVERAGE,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    COVERAGE_CODE,\\n\\
    COVERAGE_VERSION_CODE,\\n\\
    COVERAGE_TYPE,\\n\\
    COVERAGE_YEAR,\\n\\
    COVERAGE_INDEX,\\n\\
    BASE_COVERAGE,\\n\\
    COVERAGE_EFFECTIVE_DATE,\\n\\
    LAST_RENEWAL_DATE,\\n\\
    NEXT_RENEWAL_DATE,\\n\\
    COVERAGE_TERMINATION_DATE,\\n\\
    EXPIRY_DATE,\\n\\
    MATURITY_DATE,\\n\\
    COVERAGE_STATUS,\\n\\
    COVERAGE_SUB_STATUS,\\n\\
    TAXATION_AGE,\\n\\
    TAXATION_GENDER,\\n\\
    TAXATION_TOBACCO_USE,\\n\\
    INITIAL_TERM_DURATION,\\n\\
    INITIAL_FACE_AMOUNT,\\n\\
    CURRENT_FACE_AMOUNT,\\n\\
    COVERAGE_ANNUAL_PREMIUM,\\n\\
    RATES_REFERENCE_DATE,\\n\\
    COVERAGE_MODAL_PREMIUM,\\n\\
    COVERAGE_ANNUAL_BASIC_PREMIUM,\\n\\
    PAID_UP_DATE,\\n\\
    COMMISSIONABLE_ANNUAL_PREMIUM,\\n\\
    DISTRIBUTED_POLICY_FEES,\\n\\
    FACTOR_P,\\n\\
    COVERAGE_NCPI_ITD,\\n\\
    COVERAGE_TAXATION_DURATION,\\n\\
    COVERAGE_NPR_FACTOR,\\n\\
    COVERAGE_ACB_MODAL_PREMIUM,\\n\\
    POLICY_COVERAGE_UPDATED\\n\\
FROM\\n\\
    sub2\\n\\
WHERE\\n\\
    INSERT_CRITERIA_HASHDIFF = 1";
     
 return sql_command;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_COVERAGE_SAT_REINSURANCE_COVERAGE"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = " INSERT\\n\\
    INTO\\n\\
    DB_AV_" + ENV +"_DWH.RDV.SAT_REINSURANCE_COVERAGE\\n\\
    (HK_HUB_COVERAGE,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    REINSURANCE_COVERAGE_YEAR,\\n\\
    REINSURANCE_NAAR_FACTOR,\\n\\
    REINSURANCE_STOPPED_INDICATOR,\\n\\
    REINSURANCE_STOP_DATE,\\n\\
    RETAINED_FACE_AMOUNT,\\n\\
    REINSURANCE_FACE_AMOUNT_AT_ACTIVATION,\\n\\
    REMAINING_FACE_AMOUNT_CEDED_SHARE,\\n\\
    REINSURANCE_REFERENCE_DATE,\\n\\
    REINSURANCE_EFFECTIVE_DATE,\\n\\
    INITIAL_TERM_DURATION) \\n\\
    WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_HUB_COVERAGE AS lkp_HK_HUB_COVERAGE,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_HUB_COVERAGE IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_REINSURANCE_COVERAGE_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_REINSURANCE_COVERAGE_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_HUB_COVERAGE = src.HK_HUB_COVERAGE)\\n\\
SELECT\\n\\
    HK_HUB_COVERAGE,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    REINSURANCE_COVERAGE_YEAR,\\n\\
    REINSURANCE_NAAR_FACTOR,\\n\\
    REINSURANCE_STOPPED_INDICATOR,\\n\\
    REINSURANCE_STOP_DATE,\\n\\
    RETAINED_FACE_AMOUNT,\\n\\
    REINSURANCE_FACE_AMOUNT_AT_ACTIVATION,\\n\\
    REMAINING_FACE_AMOUNT_CEDED_SHARE,\\n\\
    REINSURANCE_REFERENCE_DATE,\\n\\
    REINSURANCE_EFFECTIVE_DATE,\\n\\
    INITIAL_TERM_DURATION \\n\\
FROM\\n\\
    sub1\\n\\
WHERE\\n\\
    INSERT_CRITERIA = 1";

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_COVERAGE_SAT_REINSURANCE_INSURED"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = " INSERT\\n\\
    INTO\\n\\
    DB_AV_" + ENV +"_DWH.RDV.SAT_REINSURANCE_INSURED\\n\\
    (HK_HUB_COVERAGE,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    REINSURANCE_ISSUE_AGE,\\n\\
    REINSURANCE_GENDER,\\n\\
    REINSURANCE_TOBACCO_USE) \\n\\
    WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_HUB_COVERAGE AS lkp_HK_HUB_COVERAGE,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_HUB_COVERAGE IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_REINSURANCE_INSURED_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_REINSURANCE_INSURED_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_HUB_COVERAGE = src.HK_HUB_COVERAGE)\\n\\
SELECT\\n\\
    HK_HUB_COVERAGE,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    REINSURANCE_ISSUE_AGE,\\n\\
    REINSURANCE_GENDER,\\n\\
    REINSURANCE_TOBACCO_USE \\n\\
FROM\\n\\
    sub1\\n\\
WHERE\\n\\
    INSERT_CRITERIA = 1";

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_DEATH_CLAIM_CLAIM_EXTRAC_DV_SAT_DEATH_CLAIM"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n\\
	INTO\\n\\
	DB_AV_" + ENV +"_DWH.RDV.SAT_DEATH_CLAIM\\n\\
	(HK_HUB_COVERAGE,\\n\\
	MD_SOURCE,\\n\\
	MD_CREATION_DT,\\n\\
	MD_USER,\\n\\
	MD_CREATION_AUDIT_ID,\\n\\
	MD_START_DT,\\n\\
	MD_IS_ACTIVE,\\n\\
	MD_HASHDIFF,\\n\\
	CLAIM_NUMBER,\\n\\
	CLAIM_STATUS,\\n\\
	DEATH_DATE,\\n\\
	DEATH_TYPE,\\n\\
	CLAIM_SETTLEMENT_TYPE)\\n\\
	WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_HUB_COVERAGE AS lkp_HK_HUB_COVERAGE,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_HUB_COVERAGE IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_DEATH_CLAIM_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_DEATH_CLAIM_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_HUB_COVERAGE = src.HK_HUB_COVERAGE),\\n\\
sub2 AS \\n\\
(\\n\\
SELECT\\n\\
    sub1.*,\\n\\
    CASE\\n\\
        WHEN (sub1.INSERT_CRITERIA = 1\\n\\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n\\
        OR (lkp_HK_HUB_COVERAGE IS NULL) THEN 1\\n\\
        ELSE 0\\n\\
    END AS INSERT_CRITERIA_HASHDIFF\\n\\
FROM\\n\\
    sub1\\n\\
)\\n\\
SELECT\\n\\
    HK_HUB_COVERAGE,\\n\\
	MD_SOURCE,\\n\\
	MD_CREATION_DT,\\n\\
	MD_USER,\\n\\
	''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n\\
	MD_START_DT,\\n\\
	MD_IS_ACTIVE,\\n\\
	MD_HASHDIFF,\\n\\
	CLAIM_NUMBER,\\n\\
	CLAIM_STATUS,\\n\\
	DEATH_DATE,\\n\\
	DEATH_TYPE,\\n\\
	CLAIM_SETTLEMENT_TYPE \\n\\
FROM\\n\\
    sub2\\n\\
WHERE\\n\\
    INSERT_CRITERIA_HASHDIFF = 1";

try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_HUB_COVERAGE"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.HUB_COVERAGE (HK_HUB_COVERAGE, MD_SOURCE, MD_CREATION_DT, MD_USER, MD_CREATION_AUDIT_ID, COVERAGE_IDENTIFIER)\\
SELECT src.HK_HUB_COVERAGE as HK_HUB_COVERAGE, \\
min(src.MD_SOURCE) as MD_SOURCE,\\
min(src.MD_CREATION_DT) as MD_CREATION_DT, \\
min(src.MD_USER) as MD_USER, \\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID, \\
src.COVERAGE_IDENTIFIER as COVERAGE_IDENTIFIER \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_REINSURANCE_COVERAGE_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.HUB_COVERAGE tgt  on  tgt.HK_HUB_COVERAGE = src.HK_HUB_COVERAGE  \\
WHERE tgt.HK_HUB_COVERAGE IS NULL \\
GROUP BY  src.HK_HUB_COVERAGE, src.COVERAGE_IDENTIFIER" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_HUB_TRANSACTION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.HUB_TRANSACTION (HK_HUB_TRANSACTION, MD_SOURCE, MD_CREATION_DT, MD_USER, MD_CREATION_AUDIT_ID, TRANSACTION_TYPE, CORRELATION_ID)\\
SELECT src.HK_HUB_TRANSACTION as HK_HUB_TRANSACTION, \\
min(src.MD_SOURCE) as MD_SOURCE,\\
min(src.MD_CREATION_DT) as MD_CREATION_DT, \\
min(src.MD_USER) as MD_USER, \\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID, \\
src.TRANSACTION_TYPE as TRANSACTION_TYPE, \\
src.CORRELATION_ID as CORRELATION_ID \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_RISK_CESSION_ACTIVITY_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.HUB_TRANSACTION tgt  on  tgt.HK_HUB_TRANSACTION = src.HK_HUB_TRANSACTION  \\
WHERE tgt.HK_HUB_TRANSACTION IS NULL \\
GROUP BY  src.HK_HUB_TRANSACTION, src.CORRELATION_ID, src.TRANSACTION_TYPE" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_COMMISSIONABLE_ADVISOR"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var result = "";
var sql_command = "INSERT INTO \\n \\
 DB_AV_"+ ENV + "_DWH.RDV.LINK_COMMISSIONABLE_ADVISOR \\n \\
 (HK_LINK_COMMISSIONABLE_ADVISOR, \\n \\
 HK_HUB_ADVISOR, \\n \\
 HK_HUB_COVERAGE, \\n \\
 MD_SOURCE, \\n \\
 MD_CREATION_DT, \\n \\
 MD_CREATION_AUDIT_ID, \\n \\
 MD_USER) \\n \\
(SELECT src.HK_LINK_COMMISSIONABLE_ADVISOR as HK_LINK_COMMISSIONABLE_ADVISOR, \\n \\
src.HK_HUB_ADVISOR as HK_HUB_ADVISOR, \\n \\
src.HK_HUB_COVERAGE as HK_HUB_COVERAGE,\\n \\
min(src.MD_SOURCE) as MD_SOURCE,\\n \\
min(src.MD_CREATION_DT) as MD_CREATION_DT,\\n \\
"+"''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID, \\n \\
min(src.MD_USER) as MD_USER \\n \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_COMMISSION_EXTRACT_DV src  \\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.LINK_COMMISSIONABLE_ADVISOR tgt  on  tgt.HK_LINK_COMMISSIONABLE_ADVISOR = src.HK_LINK_COMMISSIONABLE_ADVISOR  \\n \\
WHERE tgt.HK_LINK_COMMISSIONABLE_ADVISOR IS NULL \\n \\
GROUP BY  src.HK_LINK_COMMISSIONABLE_ADVISOR, \\n \\
src.HK_HUB_ADVISOR, \\n \\
src.HK_HUB_COVERAGE)" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_COVERAGE_BENEFICIARY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.LINK_COVERAGE_BENEFICIARY (HK_LINK_COVERAGE_BENEFICIARY,HK_HUB_COVERAGE,HK_HUB_CLIENT,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID) \\n \\
 (SELECT src.HK_LINK_COVERAGE_BENEFICIARY as HK_LINK_COVERAGE_BENEFICIARY, \\n \\
 src.HK_HUB_COVERAGE as HK_HUB_COVERAGE, \\n \\
 src.HK_HUB_CLIENT as HK_HUB_CLIENT, \\n \\
 min(src.MD_SOURCE) as MD_SOURCE, \\n \\
 min(src.MD_CREATION_DT) as MD_CREATION_DT, \\n \\
 min(src.MD_USER) as MD_USER, "  + "''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID \\n \\
 FROM DB_AV_"+ENV+"_STG.MODEL.VW_AV_COVERAGE_BENEFICIARY_EXTRACT_DV src   \\n \\
 LEFT JOIN DB_AV_"+ENV+"_DWH.RDV.LINK_COVERAGE_BENEFICIARY tgt  on  tgt.HK_LINK_COVERAGE_BENEFICIARY = src.HK_LINK_COVERAGE_BENEFICIARY \\n \\
 WHERE tgt.HK_LINK_COVERAGE_BENEFICIARY IS NULL \\n \\
GROUP BY src.HK_LINK_COVERAGE_BENEFICIARY,src.HK_HUB_COVERAGE,src.HK_HUB_CLIENT)" ;
try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_COVERAGE_INSURED"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.LINK_COVERAGE_INSURED \\n \\
(HK_LINK_COVERAGE_INSURED,HK_HUB_COVERAGE,HK_HUB_CLIENT,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID) \\n \\
(SELECT src.HK_LINK_COVERAGE_INSURED as HK_LINK_COVERAGE_INSURED, \\n \\
src.HK_HUB_COVERAGE as HK_HUB_COVERAGE, \\n \\
src.HK_HUB_CLIENT as HK_HUB_CLIENT, \\n \\
min(src.MD_SOURCE) as MD_SOURCE, \\n \\
min(src.MD_CREATION_DT) as MD_CREATION_DT, \\n \\
min(src.MD_USER) as MD_USER,''" + CURRENTRUNID + "'' as o_MD_CREATION_AUDIT_ID \\n \\
FROM DB_AV_"+ENV+"_STG.MODEL.VW_AV_COVERAGE_INSURED_EXTRACT_DV src   \\n \\
LEFT JOIN DB_AV_"+ENV+"_DWH.RDV.LINK_COVERAGE_INSURED tgt on tgt.HK_LINK_COVERAGE_INSURED = src.HK_LINK_COVERAGE_INSURED \\n \\
WHERE tgt.HK_LINK_COVERAGE_INSURED IS NULL \\n \\
GROUP BY src.HK_LINK_COVERAGE_INSURED,src.HK_HUB_COVERAGE,src.HK_HUB_CLIENT)" ;
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}
catch(err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }   
return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_POLICY_OWNER"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_OWNER (HK_LINK_POLICY_OWNER,HK_HUB_POLICY,HK_HUB_CLIENT,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID) \\n \\
 (SELECT src.HK_LINK_POLICY_OWNER as HK_LINK_POLICY_OWNER, \\n \\
 src.HK_HUB_POLICY as HK_HUB_POLICY, \\n \\
 src.HK_HUB_CLIENT as HK_HUB_CLIENT, \\n \\
 min(src.MD_SOURCE) as MD_SOURCE, \\n \\
 min(src.MD_CREATION_DT) as MD_CREATION_DT, \\n \\
 min(src.MD_USER) as MD_USER, "  + "''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID \\n \\
 FROM DB_AV_"+ENV+"_STG.MODEL.VW_AV_POLICY_OWNER_EXTRACT_DV src   \\n \\
 LEFT JOIN DB_AV_"+ENV+"_DWH.RDV.LINK_POLICY_OWNER tgt  on  tgt.HK_LINK_POLICY_OWNER = src.HK_LINK_POLICY_OWNER \\n \\
 WHERE tgt.HK_LINK_POLICY_OWNER IS NULL \\n \\
GROUP BY src.HK_LINK_POLICY_OWNER,src.HK_HUB_POLICY,src.HK_HUB_CLIENT)" ;
try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_POLICY_SERVICING_AGENCY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var result = "";
var sql_command = "INSERT INTO \\n \\
DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_SERVICING_AGENCY \\n \\
(HK_LINK_POLICY_SERVICING_AGENCY, \\n \\
HK_HUB_SERVICING_AGENCY, \\n \\
HK_HUB_POLICY, \\n \\
MD_SOURCE, \\n \\
MD_CREATION_DT, \\n \\
MD_USER, \\n \\
MD_CREATION_AUDIT_ID) \\n \\
(SELECT src.HK_LINK_POLICY_SERVICING_AGENCY as HK_LINK_POLICY_SERVICING_AGENCY, \\n \\
src.HK_HUB_SERVICING_AGENCY as HK_HUB_SERVICING_AGENCY, \\n \\
src.HK_HUB_POLICY as HK_HUB_POLICY,\\n \\
min(src.MD_SOURCE) as MD_SOURCE,\\n \\
min(src.MD_CREATION_DT) as MD_CREATION_DT,\\n \\
min(src.MD_USER) as MD_USER, \\n \\
"+"''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID \\n \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_SERVICING_AGENCY_EXTRACT_DV src  \\n \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_SERVICING_AGENCY tgt  on  tgt.HK_LINK_POLICY_SERVICING_AGENCY = src.HK_LINK_POLICY_SERVICING_AGENCY  \\n \\
WHERE tgt.HK_LINK_POLICY_SERVICING_AGENCY IS NULL \\n \\
GROUP BY  src.HK_LINK_POLICY_SERVICING_AGENCY, \\n \\
src.HK_HUB_SERVICING_AGENCY, \\n \\
src.HK_HUB_POLICY)" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\n Stack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_POLICY_TRANSACTION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT \\n \\
INTO  \\n \\
DB_AV_"+ ENV + "_DWH.RDV.LINK_POLICY_TRANSACTION \\n \\
(HK_LINK_POLICY_TRANSACTION, \\n \\
HK_HUB_POLICY, \\n \\
HK_HUB_TRANSACTION, \\n \\
MD_SOURCE, \\n \\
MD_CREATION_DT, \\n \\
MD_USER, \\n \\
MD_CREATION_AUDIT_ID)  \\n \\
(SELECT src.HK_LINK_POLICY_TRANSACTION as HK_LINK_POLICY_TRANSACTION, \\n \\
src.HK_HUB_POLICY as HK_HUB_POLICY,\\n \\
src.HK_HUB_TRANSACTION as HK_HUB_TRANSACTION,\\n \\
min(src.MD_SOURCE) as MD_SOURCE,\\n \\
min(src.MD_CREATION_DT) as MD_CREATION_DT,\\n \\
min(src.MD_USER) as MD_USER, \\n \\
"  + "''" +CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID \\n \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_ACTIVITY_EXTRACT_DV src  \\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.LINK_POLICY_TRANSACTION tgt  on  tgt.HK_LINK_POLICY_TRANSACTION = src.HK_LINK_POLICY_TRANSACTION  \\n \\
WHERE tgt.HK_LINK_POLICY_TRANSACTION IS NULL \\n \\
GROUP BY src.HK_HUB_POLICY, \\n \\
src.HK_HUB_TRANSACTION , \\n \\
src.HK_LINK_POLICY_TRANSACTION)" ;

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\n Stack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_RISK_CESSION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.LINK_RISK_CESSION (HK_LINK_RISK_CESSION, HK_HUB_REINSURER, HK_HUB_COVERAGE, HK_HUB_REINSURANCE_TREATY, MD_SOURCE, MD_CREATION_DT, MD_USER, MD_CREATION_AUDIT_ID)\\
SELECT src.HK_LINK_RISK_CESSION as HK_LINK_RISK_CESSION, \\
src.HK_HUB_REINSURER as HK_HUB_REINSURER, \\
src.HK_HUB_COVERAGE as HK_HUB_COVERAGE, \\
src.HK_HUB_REINSURANCE_TREATY as HK_HUB_REINSURANCE_TREATY, \\
min(src.MD_SOURCE) as MD_SOURCE,\\
min(src.MD_CREATION_DT) as MD_CREATION_DT, \\
min(src.MD_USER) as MD_USER, \\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_RISK_CESSION_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.LINK_RISK_CESSION tgt  on  tgt.HK_LINK_RISK_CESSION = src.HK_LINK_RISK_CESSION  \\
WHERE tgt.HK_LINK_RISK_CESSION IS NULL \\
GROUP BY  src.HK_HUB_COVERAGE, src.HK_HUB_REINSURER, src.HK_HUB_REINSURANCE_TREATY, src.HK_LINK_RISK_CESSION" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_LINK_RISK_CESSION_TRANSACTION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.LINK_RISK_CESSION_TRANSACTION (HK_LINK_RISK_CESSION_TRANSACTION, HK_HUB_TRANSACTION, HK_HUB_REINSURER, HK_HUB_COVERAGE, HK_HUB_REINSURANCE_TREATY, MD_SOURCE, MD_CREATION_DT, MD_USER, MD_CREATION_AUDIT_ID)\\
SELECT src.HK_LINK_RISK_CESSION_TRANSACTION as HK_LINK_RISK_CESSION_TRANSACTION, \\
src.HK_HUB_TRANSACTION as HK_HUB_TRANSACTION, \\
src.HK_HUB_REINSURER as HK_HUB_REINSURER, \\
src.HK_HUB_COVERAGE as HK_HUB_COVERAGE, \\
src.HK_HUB_REINSURANCE_TREATY as HK_HUB_REINSURANCE_TREATY, \\
min(src.MD_SOURCE) as MD_SOURCE,\\
min(src.MD_CREATION_DT) as MD_CREATION_DT, \\
min(src.MD_USER) as MD_USER, \\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_RISK_CESSION_ACTIVITY_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.LINK_RISK_CESSION_TRANSACTION tgt  on  tgt.HK_LINK_RISK_CESSION_TRANSACTION = src.HK_LINK_RISK_CESSION_TRANSACTION  \\
WHERE tgt.HK_LINK_RISK_CESSION_TRANSACTION IS NULL \\
GROUP BY  src.HK_HUB_REINSURER, src.HK_HUB_REINSURANCE_TREATY, src.HK_HUB_TRANSACTION, src.HK_LINK_RISK_CESSION_TRANSACTION, src.HK_HUB_COVERAGE" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_HUB_CLIENT"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT \\n \\
INTO  \\n \\
DB_AV_"+ ENV + "_DWH.RDV.HUB_CLIENT \\n \\
(HK_HUB_CLIENT, \\n \\
PARTY_ID, \\n \\
MD_SOURCE, \\n \\
MD_USER, \\n \\
MD_CREATION_AUDIT_ID, \\n \\
MD_CREATION_DT)  \\n \\
(SELECT src.HK_HUB_CLIENT as HK_HUB_CLIENT, \\n \\
src.PARTY_ID as PARTY_ID,\\n \\
min(src.MD_SOURCE) as MD_SOURCE,\\n \\
min(src.MD_USER) as MD_USER, \\n \\
 "  + "''" +CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID, \\n \\
 min(src.MD_CREATION_DT) as MD_CREATION_DT\\n \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_CLIENT_EXTRACT_DV src  \\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.HUB_CLIENT tgt  on  tgt.HK_HUB_CLIENT = src.HK_HUB_CLIENT  \\n \\
WHERE tgt.HK_HUB_CLIENT IS NULL \\n \\
GROUP BY  src.HK_HUB_CLIENT, \\n \\
  src.PARTY_ID)" ;

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\n Stack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_HUB_POLICY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT \\n \\
INTO  \\n \\
DB_AV_"+ ENV + "_DWH.RDV.HUB_POLICY \\n \\
(HK_HUB_POLICY, \\n \\
POLICY_NUMBER, \\n \\
MD_SOURCE, \\n \\
MD_CREATION_AUDIT_ID, \\n \\
MD_USER, \\n \\
MD_CREATION_DT)  \\n \\
(SELECT src.HK_HUB_POLICY as HK_HUB_POLICY, \\n \\
src.POLICY_NUMBER as POLICY_NUMBER,\\n \\
min(src.MD_SOURCE) as MD_SOURCE,\\n \\
"  + "''" +CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID, \\n \\
min(src.MD_USER) as MD_USER, \\n \\
min(src.MD_CREATION_DT) as MD_CREATION_DT \\n \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_EXTRACT_DV src  \\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.HUB_POLICY tgt  on  tgt.HK_HUB_POLICY = src.HK_HUB_POLICY  \\n \\
WHERE tgt.HK_HUB_POLICY IS NULL \\n \\
GROUP BY  src.HK_HUB_POLICY, \\n \\
src.POLICY_NUMBER)" ;

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\n Stack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_HUB_REINSURANCE_TREATY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.HUB_REINSURANCE_TREATY (HK_HUB_REINSURANCE_TREATY,REINSURANCE_TREATY_CODE,REINSURANCE_SUBTREATY_CODE,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID) \\n \\
 (SELECT src.HK_HUB_REINSURANCE_TREATY as HK_HUB_REINSURANCE_TREATY, \\n \\
 src.REINSURANCE_TREATY_CODE as REINSURANCE_TREATY_CODE, \\n \\
 src.REINSURANCE_SUBTREATY_CODE as REINSURANCE_SUBTREATY_CODE, \\n \\
 min(src.MD_SOURCE) as MD_SOURCE, \\n \\
 min(src.MD_CREATION_DT) as MD_CREATION_DT, \\n \\
 min(src.MD_USER) as MD_USER, "  + "''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID \\n \\
 FROM DB_AV_"+ENV+"_STG.MODEL.VW_AV_REINSURANCE_TREATY_EXTRACT_DV src   \\n \\
 LEFT JOIN DB_AV_"+ENV+"_DWH.RDV.HUB_REINSURANCE_TREATY tgt  on  tgt.HK_HUB_REINSURANCE_TREATY = src.HK_HUB_REINSURANCE_TREATY \\n \\
 WHERE tgt.HK_HUB_REINSURANCE_TREATY IS NULL \\n \\
 GROUP BY src.HK_HUB_REINSURANCE_TREATY,src.REINSURANCE_TREATY_CODE,src.REINSURANCE_SUBTREATY_CODE)" ;
try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_HUB_REINSURER"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT INTO  DB_AV_"+ ENV + "_DWH.RDV.HUB_REINSURER (HK_HUB_REINSURER,REINSURER_NUMBER,MD_SOURCE,MD_CREATION_AUDIT_ID,MD_USER,MD_CREATION_DT)\\
SELECT src.HK_HUB_REINSURER as HK_HUB_REINSURER, \\
src.REINSURER_NUMBER as REINSURER_NUMBER,\\
min(src.MD_SOURCE) as MD_SOURCE,\\
''" + CURRENTRUNID +"''" + " as o_MD_CREATION_AUDIT_ID, \\
min(src.MD_USER) as MD_USER, \\
min(src.MD_CREATION_DT) as MD_CREATION_DT \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_REINSURER_EXTRACT_DV src  \\
LEFT JOIN DB_AV_"+ ENV + "_DWH.RDV.HUB_REINSURER tgt  on  tgt.HK_HUB_REINSURER = src.HK_HUB_REINSURER  \\
WHERE tgt.HK_HUB_REINSURER IS NULL \\
GROUP BY  src.HK_HUB_REINSURER, src.REINSURER_NUMBER" ;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_HUB_TRANSACTION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var sql_command = "INSERT \\n \\
INTO  \\n \\
DB_AV_"+ ENV + "_DWH.RDV.HUB_TRANSACTION \\n \\
(HK_HUB_TRANSACTION, \\n \\
MD_SOURCE, \\n \\
MD_CREATION_DT, \\n \\
MD_USER, \\n \\
MD_CREATION_AUDIT_ID, \\n \\
TRANSACTION_TYPE, \\n \\
CORRELATION_ID)  \\n \\
(SELECT src.HK_HUB_TRANSACTION as HK_HUB_TRANSACTION, \\n \\
min(src.MD_SOURCE) as MD_SOURCE,\\n \\
min(src.MD_CREATION_DT) as MD_CREATION_DT,\\n \\
min(src.MD_USER) as MD_USER, \\n \\
"  + "''" +CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID, \\n \\
src.TRANSACTION_TYPE as TRANSACTION_TYPE,\\n \\
src.CORRELATION_ID as CORRELATION_ID\\n \\
FROM DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_ACTIVITY_EXTRACT_DV src  \\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.HUB_TRANSACTION tgt  on  tgt.HK_HUB_TRANSACTION = src.HK_HUB_TRANSACTION  \\n \\
WHERE tgt.HK_HUB_TRANSACTION IS NULL \\n \\
GROUP BY src.HK_HUB_TRANSACTION, \\n \\
src.CORRELATION_ID , \\n \\
src.TRANSACTION_TYPE)" ;

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\\\n  State: " + err.state;
        result += "\\\\n  Message: " + err.message;
        result += "\\\\nStack Trace:\\\\n" + err.stackTraceTxt;
        throw result; 
    }

return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_SAT_ACTIVITY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n \\
	INTO\\n \\
	DB_AV_" + ENV +"_DWH.RDV.SAT_ACTIVITY\\n \\
	(HK_HUB_TRANSACTION,\\n \\
	MD_SOURCE,\\n \\
	MD_CREATION_DT,\\n \\
	MD_USER,\\n \\
	MD_CREATION_AUDIT_ID,\\n \\
	MD_START_DT,\\n \\
	MD_IS_ACTIVE,\\n \\
	MD_HASHDIFF,\\n \\
	ACTIVITY_EFFECTIVE_DATE,\\n \\
	ACTIVITY_TYPE,\\n \\
	TRANSACTION_NAME,\\n \\
	ACTIVITY_PROCESSED_DATE)\\n \\
	WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.HK_HUB_TRANSACTION AS lkp_HK_HUB_TRANSACTION,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF != lkp.MD_HASHDIFF\\n \\
            OR lkp.HK_HUB_TRANSACTION IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_ACTIVITY_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_ACTIVITY_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.HK_HUB_TRANSACTION = src.HK_HUB_TRANSACTION)\\n \\
SELECT\\n \\
    HK_HUB_TRANSACTION,\\n \\
    MD_SOURCE,\\n \\
    MD_CREATION_DT,\\n \\
    MD_USER,\\n \\
	"  + "''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID, \\n \\
    MD_START_DT,\\n \\
    MD_IS_ACTIVE,\\n \\
    MD_HASHDIFF,\\n \\
	ACTIVITY_EFFECTIVE_DATE,\\n \\
	ACTIVITY_TYPE,\\n \\
	TRANSACTION_NAME,\\n \\
	ACTIVITY_PROCESSED_DATE\\n \\
	FROM\\n \\
    sub1\\n \\
WHERE\\n \\
    INSERT_CRITERIA = 1";
try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_SAT_APPLICATION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n \\
	INTO\\n \\
	DB_AV_" + ENV +"_DWH.RDV.SAT_APPLICATION\\n \\
	(HK_HUB_POLICY,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
MD_CREATION_AUDIT_ID,\\n \\
MD_START_DT,\\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF,\\n \\
CASE_NAME,\\n \\
CASE_NUMBER,\\n \\
APPLICATION_AUTOMATIC_APPROVAL,\\n \\
APPLICATION_RECEPTION_DATE,\\n \\
UNDERWRITING_APPROVAL_DATE,\\n \\
DEPOSIT_WITH_APPLICATION_AMOUNT,\\n \\
APPLICATION_INPUT_MODE,\\n \\
APPLICATION_ELECTRONIC_SIGNATURE,\\n \\
APPLICATION_SOURCE)\\n \\
WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.HK_HUB_POLICY AS lkp_HK_HUB_POLICY,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n \\
            OR lkp.HK_HUB_POLICY IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_APPLICATION_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_APPLICATION_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.HK_HUB_POLICY = src.HK_HUB_POLICY),\\n \\
sub2 AS \\n \\
(\\n \\
SELECT\\n \\
    sub1.*,\\n \\
    CASE\\n \\
        WHEN (sub1.INSERT_CRITERIA = 1\\n \\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n \\
        OR (lkp_HK_HUB_POLICY IS NULL) THEN 1\\n \\
        ELSE 0\\n \\
    END AS INSERT_CRITERIA_2\\n \\
FROM\\n \\
    sub1\\n \\
)\\n \\
SELECT\\n \\
    HK_HUB_POLICY,\\n \\
	MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
"+ "''" + o_MD_CREATION_AUDIT_ID + "''" +" AS MD_CREATION_AUDIT_ID,\\n \\
MD_START_DT,\\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF,\\n \\
CASE_NAME,\\n \\
CASE_NUMBER,\\n \\
APPLICATION_AUTOMATIC_APPROVAL,\\n \\
APPLICATION_RECEPTION_DATE,\\n \\
UNDERWRITING_APPROVAL_DATE,\\n \\
DEPOSIT_WITH_APPLICATION_AMOUNT,\\n \\
APPLICATION_INPUT_MODE,\\n \\
APPLICATION_ELECTRONIC_SIGNATURE,\\n \\
APPLICATION_SOURCE\\n \\
	FROM\\n \\
	sub2\\n \\
	WHERE\\n \\
    INSERT_CRITERIA_2 = 1";

try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\n Stack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_SAT_POLICY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;

var sql_command = "INSERT INTO DB_AV_"+ ENV +"_DWH.RDV.SAT_POLICY\\n\\
(HK_HUB_POLICY,\\n\\
PRODUCT_CODE,\\n\\
PRODUCT_VERSION_CODE,\\n\\
POLICY_OWNER_RESIDENCE_STATE,\\n\\
POLICY_YEAR,\\n\\
POLICY_CURRENCY,\\n\\
ISSUE_STATE,\\n\\
POLICY_EFFECTIVE_DATE,\\n\\
LAST_REINSTATEMENT_DATE,\\n\\
POLICY_STATUS,\\n\\
POLICY_SUB_STATUS,\\n\\
PAYMENT_FREQUENCY,\\n\\
NEXT_PREMIUM_DUE_DATE,\\n\\
BILLING_STATUS,\\n\\
PAID_TO_DATE,\\n\\
BILLING_INTERRUPTION_REASON,\\n\\
ANTICIPATE_BILLING_RESUME_DATE,\\n\\
POLICY_ACB,\\n\\
POLICY_ACB_MODAL_PREMIUM,\\n\\
PAYMENT_METHOD,\\n\\
POLICY_ACB_PREMIUM_ITD,\\n\\
POLICY_ANNUAL_PREMIUM,\\n\\
POLICY_MODAL_PREMIUM,\\n\\
ANNUAL_POLICY_FEES,\\n\\
MODAL_POLICY_FEES,\\n\\
MD_IS_ACTIVE,\\n\\
MD_HASHDIFF,\\n\\
MD_START_DT,\\n\\
MD_SOURCE,\\n\\
MD_CREATION_DT,\\n\\
MD_CREATION_AUDIT_ID,\\n\\
MD_USER,\\n\\
PolicyTerminationDate,\\n\\
POLICY_UPDATED)\\n\\
	WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_HUB_POLICY AS lkp_HK_HUB_POLICY,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_HUB_POLICY IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_POLICY_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_HUB_POLICY = src.HK_HUB_POLICY),\\n\\
sub2 AS \\n\\
(\\n\\
SELECT\\n\\
    sub1.*,\\n\\
    CASE\\n\\
        WHEN (sub1.INSERT_CRITERIA = 1\\n\\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n\\
        OR (lkp_HK_HUB_POLICY IS NULL) THEN 1\\n\\
        ELSE 0\\n\\
    END AS INSERT_CRITERIA_2\\n\\
FROM\\n\\
    sub1\\n\\
)\\n\\
SELECT\\n\\
    HK_HUB_POLICY,\\n\\
	PRODUCT_CODE,\\n\\
PRODUCT_VERSION_CODE,\\n\\
POLICY_OWNER_RESIDENCE_STATE,\\n\\
POLICY_YEAR,\\n\\
POLICY_CURRENCY,\\n\\
ISSUE_STATE,\\n\\
POLICY_EFFECTIVE_DATE,\\n\\
LAST_REINSTATEMENT_DATE,\\n\\
POLICY_STATUS,\\n\\
POLICY_SUB_STATUS,\\n\\
PAYMENT_FREQUENCY,\\n\\
NEXT_PREMIUM_DUE_DATE,\\n\\
BILLING_STATUS,\\n\\
PAID_TO_DATE,\\n\\
BILLING_INTERRUPTION_REASON,\\n\\
ANTICIPATE_BILLING_RESUME_DATE,\\n\\
POLICY_ACB,\\n\\
POLICY_ACB_MODAL_PREMIUM,\\n\\
PAYMENT_METHOD,\\n\\
POLICY_ACB_PREMIUM_ITD,\\n\\
POLICY_ANNUAL_PREMIUM,\\n\\
POLICY_MODAL_PREMIUM,\\n\\
ANNUAL_POLICY_FEES,\\n\\
MODAL_POLICY_FEES,\\n\\
MD_IS_ACTIVE,\\n\\
MD_HASHDIFF,\\n\\
MD_START_DT,\\n\\
MD_SOURCE,\\n\\
MD_CREATION_DT,\\n\\
"+ "''" + o_MD_CREATION_AUDIT_ID + "''" +" AS MD_CREATION_AUDIT_ID,\\n\\
MD_USER,\\n\\
PolicyTerminationDate,\\n\\
POLICY_UPDATED\\n\\
	FROM\\n\\
	sub2\\n\\
	WHERE\\n\\
    INSERT_CRITERIA_2 = 1";



try {



	var sql_statement = snowflake.createStatement({sqlText: sql_command });

	var result_scan = sql_statement.execute();

	result = "Succeeded!";

}



catch (err)  {

        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;

        result += "\\n  Message: " + err.message;

        result += "\\n Stack Trace:\\n" + err.stackTraceTxt;

        throw result; 

    }

     

 return result;



';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_SAT_REINSURANCE_TREATY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n \\
	INTO\\n \\
	DB_AV_" + ENV +"_DWH.RDV.SAT_REINSURANCE_TREATY\\n \\
	(HK_HUB_REINSURANCE_TREATY, \\n \\
MD_SOURCE, \\n \\
MD_CREATION_DT, \\n \\
MD_USER, \\n \\
MD_CREATION_AUDIT_ID, \\n \\
MD_START_DT, \\n \\
MD_IS_ACTIVE, \\n \\
MD_HASHDIFF, \\n \\
COVERAGE_GROUP_CODE, \\n \\
CESSION_MODE, \\n \\
REINSURANCE_TYPE)\\n \\
	WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.HK_HUB_REINSURANCE_TREATY AS lkp_HK_HUB_REINSURANCE_TREATY,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF != lkp.MD_HASHDIFF\\n \\
            OR lkp.HK_HUB_REINSURANCE_TREATY IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_REINSURANCE_TREATY_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_REINSURANCE_TREATY_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.HK_HUB_REINSURANCE_TREATY = src.HK_HUB_REINSURANCE_TREATY)\\n \\
SELECT\\n \\
    HK_HUB_REINSURANCE_TREATY, \\n \\
	MD_SOURCE, \\n \\
	MD_CREATION_DT, \\n \\
	MD_USER, \\n \\
	"  + "''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID, \\n \\
    MD_START_DT, \\n \\
	MD_IS_ACTIVE, \\n \\
	MD_HASHDIFF, \\n \\
	COVERAGE_GROUP_CODE, \\n \\
	CESSION_MODE, \\n \\
	REINSURANCE_TYPE\\n \\
	FROM\\n \\
    sub1\\n \\
WHERE\\n \\
    INSERT_CRITERIA = 1";
try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_POLICY_SAT_REINSURER"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = " INSERT\\n\\
    INTO\\n\\
    DB_AV_" + ENV +"_DWH.RDV.SAT_REINSURER\\n\\
    (HK_HUB_REINSURER,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    NAME) \\n\\
    WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_HUB_REINSURER AS lkp_HK_HUB_REINSURER,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_HUB_REINSURER IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_REINSURER_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_REINSURER_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_HUB_REINSURER = src.HK_HUB_REINSURER)\\n\\
SELECT\\n\\
    HK_HUB_REINSURER,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    NAME \\n\\
FROM\\n\\
    sub1\\n\\
WHERE\\n\\
    INSERT_CRITERIA = 1";

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_ACTIVITY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = " INSERT\\n\\
    INTO\\n\\
    DB_AV_" + ENV +"_DWH.RDV.SAT_ACTIVITY\\n\\
    (HK_HUB_TRANSACTION,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    ACTIVITY_EFFECTIVE_DATE,\\n\\
    ACTIVITY_TYPE,\\n\\
    TRANSACTION_NAME,\\n\\
    ACTIVITY_PROCESSED_DATE) \\n\\
    WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_HUB_TRANSACTION AS lkp_HK_HUB_TRANSACTION,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_HUB_TRANSACTION IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_RISK_CESSION_ACTIVITY_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_ACTIVITY_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_HUB_TRANSACTION = src.HK_HUB_TRANSACTION)\\n\\
SELECT\\n\\
    HK_HUB_TRANSACTION,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    ACTIVITY_EFFECTIVE_DATE,\\n\\
    ACTIVITY_TYPE,\\n\\
    TRANSACTION_NAME,\\n\\
    ACTIVITY_PROCESSED_DATE \\n\\
FROM\\n\\
    sub1\\n\\
WHERE\\n\\
    INSERT_CRITERIA = 1";

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_COMMISSION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n \\
	INTO\\n \\
	DB_AV_" + ENV +"_DWH.RDV.SAT_COMMISSION\\n \\
	(HK_LINK_COMMISSIONABLE_ADVISOR,\\n \\
COMMISSION_SHARE,\\n \\
MD_IS_ACTIVE,\\n \\
MD_USER,\\n \\
MD_HASHDIFF,\\n \\
MD_START_DT,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_AUDIT_ID,\\n \\
MD_CREATION_DT)\\n \\
	WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.HK_LINK_COMMISSIONABLE_ADVISOR AS lkp_HK_LINK_COMMISSIONABLE_ADVISOR,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n \\
            OR lkp.HK_LINK_COMMISSIONABLE_ADVISOR IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_COMMISSION_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_COMMISSION_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.HK_LINK_COMMISSIONABLE_ADVISOR = src.HK_LINK_COMMISSIONABLE_ADVISOR),\\n \\
sub2 AS \\n \\
(\\n \\
SELECT\\n \\
    sub1.*,\\n \\
    CASE\\n \\
        WHEN (sub1.INSERT_CRITERIA = 1\\n \\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n \\
        OR (lkp_HK_LINK_COMMISSIONABLE_ADVISOR IS NULL) THEN 1\\n \\
        ELSE 0\\n \\
    END AS INSERT_CRITERIA_HASHDIFF\\n \\
FROM\\n \\
    sub1\\n \\
)\\n \\
SELECT\\n \\
    HK_LINK_COMMISSIONABLE_ADVISOR,\\n \\
	COMMISSION_SHARE,\\n \\
	MD_IS_ACTIVE,\\n \\
	MD_USER,\\n \\
	MD_HASHDIFF,\\n \\
	MD_START_DT,\\n \\
	MD_SOURCE,\\n \\
	"+ "''" + o_MD_CREATION_AUDIT_ID + "''" +" AS MD_CREATION_AUDIT_ID,\\n \\
	MD_CREATION_DT\\n \\
	FROM\\n \\
	sub2\\n \\
	WHERE\\n \\
	INSERT_CRITERIA_HASHDIFF = 1";

try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_COVERAGE_BENEFICIARY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var pre_sql_command ="INSERT\\n \\
INTO\\n \\
DB_AV_" + ENV +"_DWH.RDV.SAT_COVERAGE_BENEFICIARY\\n \\
(HK_LINK_COVERAGE_BENEFICIARY,\\n \\
MD_START_DT,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
MD_CREATION_AUDIT_ID,\\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF,\\n \\
BENEFICIARY_LEGAL_SUCCESSION,\\n \\
BENEFICIARY_REVOCABLE,\\n \\
BENEFICIARY_BENEFIT_SHARE_TYPE,\\n \\
BENEFICIARY_RELATIONSHIP_TO_INSURED,\\n \\
BENEFICIARY_BENEFIT_SHARE_PERCENT)\\n \\
SELECT\\n \\
 HK_LINK_COVERAGE_BENEFICIARY,\\n \\
MD_START_DT,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
MD_CREATION_AUDIT_ID,\\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF,\\n \\
BENEFICIARY_LEGAL_SUCCESSION,\\n \\
BENEFICIARY_REVOCABLE,\\n \\
BENEFICIARY_BENEFIT_SHARE_TYPE,\\n \\
BENEFICIARY_RELATIONSHIP_TO_INSURED,\\n \\
BENEFICIARY_BENEFIT_SHARE_PERCENT\\n \\
FROM DB_AV_" + ENV +"_DWH.RDV.VW_SAT_COVERAGE_BENEFICIARY_DELETED_ROW";
var sql_command = "	INSERT\\n \\
	INTO\\n \\
	DB_AV_" + ENV +"_DWH.RDV.SAT_COVERAGE_BENEFICIARY\\n \\
	(HK_LINK_COVERAGE_BENEFICIARY,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
MD_CREATION_AUDIT_ID,\\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF,\\n \\
BENEFICIARY_LEGAL_SUCCESSION,\\n \\
BENEFICIARY_REVOCABLE,\\n \\
BENEFICIARY_BENEFIT_SHARE_TYPE,\\n \\
BENEFICIARY_RELATIONSHIP_TO_INSURED,\\n \\
BENEFICIARY_BENEFIT_SHARE_PERCENT)\\n \\
	WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.DK_HK_HUB_COVERAGE AS lkp_DK_HK_HUB_COVERAGE,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF != lkp.MD_HASHDIFF\\n \\
            OR lkp.DK_HK_HUB_COVERAGE IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_COVERAGE_BENEFICIARY_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.DK_HK_HUB_COVERAGE = src.HK_LINK_COVERAGE_BENEFICIARY)\\n \\
SELECT\\n \\
HK_LINK_COVERAGE_BENEFICIARY,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
"  + "''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID, \\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF,\\n \\
BENEFICIARY_LEGAL_SUCCESSION,\\n \\
BENEFICIARY_REVOCABLE,\\n \\
BENEFICIARY_BENEFIT_SHARE_TYPE,\\n \\
BENEFICIARY_RELATIONSHIP_TO_INSURED,\\n \\
BENEFICIARY_BENEFIT_SHARE_PERCENT\\n \\
FROM\\n \\
sub1\\n \\
WHERE\\n \\
    INSERT_CRITERIA = 1";
try {
    var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
	var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_COVERAGE_BENEFICIARY_CONTINGENT"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var pre_sql_command ="INSERT INTO DB_AV_"+ ENV +"_DWH.RDV.SAT_COVERAGE_BENEFICIARY_CONTINGENT(HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,MD_START_DT,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID,MD_IS_ACTIVE,MD_HASHDIFF,CONTINGENT_BENEFICIARY_LEGAL_SUCCESSION,CONTINGENT_BENEFICIARY_REVOCABLE,CONTINGENT_BENEFICIARY_BENEFIT_SHARE_TYPE,CONTINGENT_BENEFICIARY_RELATIONSHIP_TO_INSURED,CONTINGENT_BENEFICIARY_BENEFIT_SHARE_PERCENT)SELECT HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,MD_START_DT,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID,MD_IS_ACTIVE,MD_HASHDIFF,CONTINGENT_BENEFICIARY_LEGAL_SUCCESSION,CONTINGENT_BENEFICIARY_REVOCABLE,CONTINGENT_BENEFICIARY_BENEFIT_SHARE_TYPE,CONTINGENT_BENEFICIARY_RELATIONSHIP_TO_INSURED,CONTINGENT_BENEFICIARY_BENEFIT_SHARE_PERCENT FROM DB_AV_"+ ENV +"_DWH.RDV.VW_SAT_COVERAGE_BENEFICIARY_CONTINGENT_DELETED_ROW";
var pre_sql_command =" INSERT INTO DB_AV_+ ENV +"_DWH.RDV.SAT_COVERAGE_BENEFICIARY_CONTINGENT(HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT, MD_START_DT, MD_SOURCE, MD_CREATION_DT, MD_USER,MD_CREATION_AUDIT_ID,MD_IS_ACTIVE,MD_HASHDIFF,CONTINGENT_BENEFICIARY_LEGAL_SUCCESSION, CONTINGENT_BENEFICIARY_REVOCABLE, CONTINGENT_BENEFICIARY_BENEFIT_SHARE_TYPE, CONTINGENT_BENEFICIARY_RELATIONSHIP_TO_INSURED, CONTINGENT_BENEFICIARY_B)\\n \\
	WITH sub1 AS \\n \\
(SELECT src.*, lkp.MD_START_DT AS MD_START_DT, lkp.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT AS HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,CASE WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE WHEN src.MD_HASHDIFF != lkp.MD_HASHDIFF OR lkp.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT IS NULL THEN 1 ELSE 0 END ELSE 1 END AS INSERT_CRITERIA FROM DB_AV_dev_STG.MODEL.VW_AV_COVERAGE_BENEFICIARY_CONTINGENT_EXTRACT_DV src LEFT JOIN DB_AV_dev_DWH.RDV.VW_SAT_COVERAGE_BENEFICIARY_CONTINGENT_LAST_ROW lkp ON lkp.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT = src.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT) SELECT src.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,src.MD_START_DT, src.MD_SOURCE, src.MD_CREATION_DT, src.MD_USER, ''''" + o_MD_CREATION_AUDIT_ID + "'''' AS MD_CREATION_AUDIT_ID,src.MD_IS_ACTIVE,src.MD_HASHDIFF, src.CONTINGENT_BENEFICIARY_LEGAL_SUCCESSION, src.CONTINGENT_BENEFICIARY_REVOCABLE, src.CONTINGENT_BENEFICIARY_BENEFIT_SHARE_TYPE, src.CONTINGENT_BENEFICIARY_RELATIONSHIP_TO_INSURED, src.CONTINGENT_BENEFICIARY_B FROM DB_AV_dev_STG.MODEL.VW_AV_COVERAGE_BENEFICIARY_CONTINGENT_EXTRACT_DV src WHERE INSERT_CRITERIA = 1";

try {

	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();
	result = "Succeeded!";

}
catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n State: " + err.state;
        result += "\\n Message: " + err.message;
        result += "\\n Stack Trace:\\n " + err.stackTraceTxt;
        throw result; 
    }
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_COVERAGE_INSURED"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n \\
INTO\\n \\
DB_AV_" + ENV +"_DWH.RDV.SAT_COVERAGE_INSURED\\n \\
(DK_HK_HUB_COVERAGE,\\n \\
MD_START_DT,\\n \\
HK_LINK_COVERAGE_INSURED,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
MD_CREATION_AUDIT_ID,\\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF,\\n \\
ISSUE_AGE,\\n \\
TOBACCO_USE,\\n \\
UNDERWRITING_GENDER,\\n \\
CURRENT_UNDERWRITING_AGE,\\n \\
CURRENT_UNDERWRITING_TOBACCO_USE,\\n \\
DATE_OF_BIRTH,\\n \\
FIRST_NAME,\\n \\
LAST_NAME,\\n \\
POSTAL_CODE,\\n \\
PROVINCE,\\n \\
COUNTRY)\\n \\
WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.DK_HK_HUB_COVERAGE AS lkp_DK_HK_HUB_COVERAGE,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF != lkp.MD_HASHDIFF\\n \\
            OR lkp.DK_HK_HUB_COVERAGE IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_COVERAGE_INSURED_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_COVERAGE_INSURED_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.DK_HK_HUB_COVERAGE = src.HK_HUB_COVERAGE)\\n \\
SELECT\\n \\
HK_HUB_COVERAGE,\\n \\
MD_START_DT,\\n \\
HK_LINK_COVERAGE_INSURED,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
''" + CURRENTRUNID + "'' as o_MD_CREATION_AUDIT_ID, \\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF,\\n \\
ISSUE_AGE,\\n \\
TOBACCO_USE,\\n \\
UNDERWRITING_GENDER,\\n \\
CURRENT_UNDERWRITING_AGE,\\n \\
CURRENT_UNDERWRITING_TOBACCO_USE,\\n \\
DATE_OF_BIRTH,\\n \\
FIRST_NAME,\\n \\
LAST_NAME,\\n \\
POSTAL_CODE,\\n \\
PROVINCE,\\n \\
COUNTRY\\n \\
FROM\\n \\
sub1\\n \\
WHERE\\n \\
INSERT_CRITERIA = 1";
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}
catch(err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }    
return result;
 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_POLICY_COVERAGE"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "INSERT INTO DB_AV_DEV_DWH.RDV.SAT_POLICY_COVERAGE 
 
(MD_START_DT,HK_LINK_POLICY_COVERAGE,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID,MD_IS_ACTIVE,MD_HASHDIFF) 
 
(SELECT src.*, lkp.MD_START_DT AS lkp_MD_START_DT,lkp.HK_LINK_POLICY_COVERAGE AS lkp_HK_LINK_POLICY_COVERAGE, 
 
CASE 
 
WHEN src.PREVIOUS_MD_HASHDIFF = "#FIRST#" THEN CASE 
 
WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF OR lkp.HK_LINK_POLICY_COVERAGE IS NULL THEN 1 ELSE 0 END ELSE 1 END AS INSERT_CRITERIA 
 
FROM DB_AV_DEV_STG.MODEL.VW_AV_POLICY_COVERAGE_EXTRACT_DV src 
 
LEFT JOIN DB_AV_DEV_DWH.RDV.VW_SAT_POLICY_COVERAGE_LAST_ROW lkp ON lkp.HK_LINK_POLICY_COVERAGE= src.HK_LINK_POLICY_COVERAGE) 
  
    (SELECT 
 
    HK_HUB_COVERAGE,
 
    MD_SOURCE,
 
    MD_CREATION_DT,
  
    MD_USER,
 
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,
 
    MD_START_DT,
 
    MD_IS_ACTIVE,
 
    MD_HASHDIFF,
 
	POLICY_NUMBER,
 
    COVERAGE_IDENTIFIER,
 
    MD_SOURCE_ROW_NUMBER,
 
    MD_PATH,
 
    HK_HUB_POLICY,
 
    HK_LINK_POLICY_COVERAGE,
 
    PREVIOUS_MD_HASHDIFF,
 
    FROM 
 
    sub1 
 
WHERE 
 
    INSERT_CRITERIA = 1");

try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "
  State: " + err.state;
        result += "
  Message: " + err.message;
        result += "
Stack Trace:
" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_POLICY_OWNER"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "	INSERT\\n \\
	INTO\\n \\
	DB_AV_" + ENV +"_DWH.RDV.SAT_POLICY_OWNER\\n \\
	(HK_LINK_POLICY_OWNER,\\n \\
	MD_SOURCE,\\n \\
	MD_CREATION_DT,\\n \\
	MD_USER,\\n \\
	MD_CREATION_AUDIT_ID,\\n \\
	MD_START_DT,\\n \\
	MD_IS_ACTIVE,\\n \\
	MD_HASHDIFF,\\n \\
	CORRESPONDENCE_INDICATOR,\\n \\
	PARTY_TYPE,\\n \\
	AMERICAN_RESIDENT_INDICATOR,\\n \\
	LANGUAGE)\\n \\
	WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.HK_LINK_POLICY_OWNER AS lkp_HK_LINK_POLICY_OWNER,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF != lkp.MD_HASHDIFF\\n \\
            OR lkp.HK_LINK_POLICY_OWNER IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_OWNER_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_POLICY_OWNER_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.HK_LINK_POLICY_OWNER = src.HK_LINK_POLICY_OWNER)\\n \\
SELECT\\n \\
    HK_LINK_POLICY_OWNER,\\n \\
    MD_SOURCE,\\n \\
    MD_CREATION_DT,\\n \\
    MD_USER,\\n \\
	"  + "''" + CURRENTRUNID + "''" + " as o_MD_CREATION_AUDIT_ID, \\n \\
    MD_START_DT,\\n \\
    MD_IS_ACTIVE,\\n \\
    MD_HASHDIFF,\\n \\
	CORRESPONDENCE_INDICATOR,\\n \\
	PARTY_TYPE,\\n \\
	AMERICAN_RESIDENT_INDICATOR,\\n \\
	LANGUAGE\\n \\
	FROM\\n \\
    sub1\\n \\
WHERE\\n \\
    INSERT_CRITERIA = 1";
try {

	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_POLICY_SERVICING_AGENCY"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";
var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = "INSERT\\n \\
INTO\\n \\
DB_AV_" + ENV +"_DWH.RDV.SAT_POLICY_SERVICING_AGENCY\\n \\
(DK_HK_HUB_POLICY,\\n \\
HK_LINK_POLICY_SERVICING_AGENCY,\\n \\
MD_SOURCE,\\n \\
MD_CREATION_DT,\\n \\
MD_USER,\\n \\
MD_CREATION_AUDIT_ID,\\n \\
MD_START_DT,\\n \\
MD_IS_ACTIVE,\\n \\
MD_HASHDIFF)\\n \\
WITH sub1 AS \\n \\
(\\n \\
SELECT\\n \\
    src.*,\\n \\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n \\
    lkp.DK_HK_HUB_POLICY AS lkp_DK_HK_HUB_POLICY,\\n \\
    CASE\\n \\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n \\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n \\
            OR lkp.DK_HK_HUB_POLICY IS NULL THEN 1\\n \\
            ELSE 0\\n \\
        END\\n \\
        ELSE 1\\n \\
    END AS INSERT_CRITERIA\\n \\
FROM\\n \\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_POLICY_SERVICING_AGENCY_EXTRACT_DV src\\n \\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_POLICY_SERVICING_AGENCY_LAST_ROW lkp\\n \\
ON\\n \\
    lkp.DK_HK_HUB_POLICY = src.HK_HUB_POLICY),\\n \\
sub2 AS \\n \\
(\\n \\
SELECT\\n \\
    sub1.*,\\n \\
    CASE\\n \\
        WHEN (sub1.INSERT_CRITERIA = 1\\n \\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n \\
        OR (lkp_DK_HK_HUB_POLICY IS NULL) THEN 1\\n \\
        ELSE 0\\n \\
    END AS INSERT_CRITERIA_HASHDIFF\\n \\
FROM\\n \\
    sub1\\n \\
)\\n \\
SELECT\\n \\
    HK_HUB_POLICY,\\n \\
	HK_LINK_POLICY_SERVICING_AGENCY,\\n \\
	MD_SOURCE,\\n \\
	MD_CREATION_DT,\\n \\
	MD_USER,\\n \\
   ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n \\
    MD_START_DT,\\n \\
	MD_IS_ACTIVE,\\n \\
	MD_HASHDIFF\\n \\
	FROM\\n \\
	sub2\\n \\
	WHERE\\n \\
    INSERT_CRITERIA_HASHDIFF = 1";
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	result = "Succeeded!";
}
catch(err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\n Stack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }   
return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_INSERT_AV_SAT_RISK_CESSION"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var result="";

var o_MD_CREATION_AUDIT_ID = CURRENTRUNID;
var sql_command = " INSERT\\n\\
    INTO\\n\\
    DB_AV_" + ENV +"_DWH.RDV.SAT_RISK_CESSION\\n\\
    (HK_LINK_RISK_CESSION,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    REINSURED_FACE_AMOUNT,\\n\\
    REINSURANCE_NAAR,\\n\\
    REINSURED_FACE_AMOUNT_SHARE,\\n\\
    RISK_CESSION_DATE,\\n\\
    REINSURANCE_GROSS_ANNUAL_PREMIUM,\\n\\
    REINSURANCE_NET_ANNUAL_PREMIUM,\\n\\
    REINSURANCE_TAX_ON_ANNUAL_PREMIUM,\\n\\
    REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT,\\n\\
    REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT,\\n\\
    REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT,\\n\\
    RISK_CESSION_ADJUSTEMENT_ORIGIN)\\n\\
    WITH sub1 AS \\n\\
(\\n\\
SELECT\\n\\
    src.*,\\n\\
    lkp.MD_START_DT AS lkp_MD_START_DT,\\n\\
    lkp.HK_LINK_RISK_CESSION AS lkp_HK_LINK_RISK_CESSION,\\n\\
    CASE\\n\\
        WHEN src.PREVIOUS_MD_HASHDIFF = ''#First#'' THEN CASE\\n\\
            WHEN src.MD_HASHDIFF <> lkp.MD_HASHDIFF\\n\\
            OR lkp.HK_LINK_RISK_CESSION IS NULL THEN 1\\n\\
            ELSE 0\\n\\
        END\\n\\
        ELSE 1\\n\\
    END AS INSERT_CRITERIA\\n\\
FROM\\n\\
    DB_AV_" + ENV + "_STG.MODEL.VW_AV_RISK_CESSION_EXTRACT_DV src\\n\\
LEFT JOIN DB_AV_" + ENV + "_DWH.RDV.VW_SAT_RISK_CESSION_LAST_ROW lkp\\n\\
ON\\n\\
    lkp.HK_LINK_RISK_CESSION = src.HK_LINK_RISK_CESSION),\\n\\
sub2 AS \\n\\
(\\n\\
SELECT\\n\\
    sub1.*,\\n\\
    CASE\\n\\
        WHEN (sub1.INSERT_CRITERIA = 1\\n\\
            AND sub1.MD_START_DT > lkp_MD_START_DT)\\n\\
        OR (lkp_HK_LINK_RISK_CESSION IS NULL) THEN 1\\n\\
        ELSE 0\\n\\
    END AS INSERT_CRITERIA_HASHDIFF\\n\\
FROM\\n\\
    sub1\\n\\
)\\n\\
SELECT\\n\\
    HK_LINK_RISK_CESSION,\\n\\
    MD_SOURCE,\\n\\
    MD_CREATION_DT,\\n\\
    MD_USER,\\n\\
    ''" + o_MD_CREATION_AUDIT_ID + "'' AS MD_CREATION_AUDIT_ID,\\n\\
    MD_START_DT,\\n\\
    MD_IS_ACTIVE,\\n\\
    MD_HASHDIFF,\\n\\
    REINSURED_FACE_AMOUNT,\\n\\
    REINSURANCE_NAAR,\\n\\
    REINSURED_FACE_AMOUNT_SHARE,\\n\\
    RISK_CESSION_DATE,\\n\\
    REINSURANCE_GROSS_ANNUAL_PREMIUM,\\n\\
    REINSURANCE_NET_ANNUAL_PREMIUM,\\n\\
    REINSURANCE_TAX_ON_ANNUAL_PREMIUM,\\n\\
    REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT,\\n\\
    REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT,\\n\\
    REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT,\\n\\
    RISK_CESSION_ADJUSTEMENT_ORIGIN \\n\\
FROM\\n\\
    sub2\\n\\
WHERE\\n\\
    INSERT_CRITERIA_HASHDIFF = 1";

try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
        result += "\\n  Message: " + err.message;
        result += "\\nStack Trace:\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_M_INSERT_AV_LINK_COVERAGE_BENEFICIARY_CONTINGENT"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command ="insert into DB_AV_"+ENV+"_DWH.RDV.LINK_COVERAGE_BENEFICIARY_CONTINGENT(HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,HK_HUB_COVERAGE,HK_HUB_CLIENT_BENEFICIARY,HK_HUB_CLIENT_BENEFICIARY_CONTINGENT,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID) (select  SRC.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT, SRC.HK_HUB_COVERAGE, SRC.HK_HUB_CLIENT_BENEFICIARY, SRC.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT, MIN(SRC.MD_SOURCE), MIN(SRC.MD_CREATION_DT), MIN(SRC.MD_USER), ''"+CURRENTRUNID+"'' FROM  DB_AV_"+ENV+"_STG.MODEL.VW_AV_COVERAGE_BENEFICIARY_CONTINGENT_EXTRACT_DV SRC LEFT JOIN DB_AV_"+ENV+"_DWH.RDV.LINK_COVERAGE_BENEFICIARY_CONTINGENT LKP ON SRC.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT = LKP.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT WHERE LKP.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT IS NULL GROUP BY  SRC.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,SRC.HK_HUB_COVERAGE,SRC.HK_HUB_CLIENT_BENEFICIARY,SRC.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT);";
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
  result = "Succeeded!";
}
catch (err) {
    result = "Failed: Code: " + err.code + " \\n State: " + err.state;
    result += " \\n Message: " + err.message;
    result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
    throw result;
  }
 return result;
';
create or replace schema RDV_CLONE_AD;

create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	ADVISOR_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	ADVISOR_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURANCE_TREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	REINSURANCE_SUBTREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE HUB_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURER_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURER primary key (HK_HUB_REINSURER)
);
create or replace TABLE HUB_SERVICING_AGENCY (
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	AGENCY_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_SERVICING_AGENCY primary key (HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE HUB_TRANSACTION (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	TRANSACTION_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	CORRELATION_ID VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_TRANSACTION primary key (HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_ADVISOR(HK_HUB_ADVISOR)
);
create or replace TABLE LINK_COVERAGE_BENEFICIARY (
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY primary key (HK_LINK_COVERAGE_BENEFICIARY),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED),
	constraint FK_LINK_COVERAGE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_LINK_COVERAGE_INSURED_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_CLIENT(HK_HUB_CLIENT)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_POLICY(HK_HUB_POLICY),
	constraint FK_LINK_POLICY_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_POLICY_OWNER_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_SERVICING_AGENCY foreign key (HK_HUB_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_SERVICING_AGENCY(HK_HUB_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_TRANSACTION (
	HK_LINK_POLICY_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_TRANSACTION primary key (HK_LINK_POLICY_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_TRANSACTION(HK_HUB_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION primary key (HK_LINK_RISK_CESSION),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_RISK_CESSION_TRANSACTION (
	HK_LINK_RISK_CESSION_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION_TRANSACTION primary key (HK_LINK_RISK_CESSION_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_ACTIVITY (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ACTIVITY_EFFECTIVE_DATE VARCHAR(255),
	ACTIVITY_TYPE VARCHAR(255),
	TRANSACTION_NAME VARCHAR(255),
	ACTIVITY_PROCESSED_DATE VARCHAR(255),
	constraint PK_SAT_ACTIVITY primary key (HK_HUB_TRANSACTION, MD_START_DT),
	constraint FK_SAT_ACTIVITY_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_APPLICATION (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CASE_NAME VARCHAR(255),
	CASE_NUMBER VARCHAR(255),
	APPLICATION_AUTOMATIC_APPROVAL VARCHAR(255),
	APPLICATION_RECEPTION_DATE VARCHAR(255),
	UNDERWRITING_APPROVAL_DATE VARCHAR(255),
	DEPOSIT_WITH_APPLICATION_AMOUNT NUMBER(38,2),
	APPLICATION_INPUT_MODE VARCHAR(255),
	APPLICATION_ELECTRONIC_SIGNATURE VARCHAR(255),
	APPLICATION_SOURCE VARCHAR(255),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_COMMISSION (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COMMISSION_SHARE VARCHAR(255),
	constraint PK_SAT_COMMISSION primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COMMISSION_LINK_COMMISSIONABLE_ADVISOR foreign key (HK_LINK_COMMISSIONABLE_ADVISOR) references DB_AV_DEV_DWH.RDV_CLONE_AD.LINK_COMMISSIONABLE_ADVISOR(HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,0),
	CURRENT_FACE_AMOUNT NUMBER(38,0),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,2),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,2),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,2),
	DISTRIBUTED_POLICY_FEES NUMBER(38,2),
	FACTOR_P NUMBER(38,14),
	COVERAGE_NCPI_ITD NUMBER(38,2),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,14),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_COVERAGE_UPDATED VARCHAR(255),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_BENEFICIARY (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	BENEFICIARY_LEGAL_SUCCESSION VARCHAR(255),
	BENEFICIARY_REVOCABLE VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_TYPE VARCHAR(255),
	BENEFICIARY_RELATIONSHIP_TO_INSURED VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_PERCENT NUMBER(38,2),
	constraint PK_SAT_COVERAGE_BENEFICIARY primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (DK_HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_SAT_COVERAGE_BENEFICIARY_LINK_COVERAGE_BENEFICIARY foreign key (HK_LINK_COVERAGE_BENEFICIARY) references DB_AV_DEV_DWH.RDV_CLONE_AD.LINK_COVERAGE_BENEFICIARY(HK_LINK_COVERAGE_BENEFICIARY)
);
create or replace TABLE SAT_COVERAGE_INSURED (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	FIRST_NAME VARCHAR(255),
	LAST_NAME VARCHAR(255),
	POSTAL_CODE VARCHAR(255),
	PROVINCE VARCHAR(255),
	COUNTRY VARCHAR(255),
	constraint PK_SAT_COVERAGE_INSURED primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_INSURED_LINK_COVERAGE_INSURED foreign key (HK_LINK_COVERAGE_INSURED) references DB_AV_DEV_DWH.RDV_CLONE_AD.LINK_COVERAGE_INSURED(HK_LINK_COVERAGE_INSURED)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,2),
	POLICY_ANNUAL_PREMIUM NUMBER(38,2),
	POLICY_MODAL_PREMIUM NUMBER(38,2),
	ANNUAL_POLICY_FEES NUMBER(38,2),
	MODAL_POLICY_FEES NUMBER(38,2),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_OWNER (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CORRESPONDENCE_INDICATOR VARCHAR(5),
	PARTY_TYPE VARCHAR(255),
	AMERICAN_RESIDENT_INDICATOR VARCHAR(255),
	LANGUAGE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_OWNER_LINK_POLICY_OWNER foreign key (HK_LINK_POLICY_OWNER) references DB_AV_DEV_DWH.RDV_CLONE_AD.LINK_POLICY_OWNER(HK_LINK_POLICY_OWNER)
);
create or replace TABLE SAT_POLICY_OWNER_CLONE (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CORRESPONDENCE_INDICATOR VARCHAR(5),
	PARTY_TYPE VARCHAR(255),
	AMERICAN_RESIDENT_INDICATOR VARCHAR(255),
	LANGUAGE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (DK_HK_HUB_POLICY, MD_START_DT)
);
create or replace TABLE SAT_POLICY_SERVICING_AGENCY (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	constraint PK_SAT_POLICY_SERVICING_AGENCY primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_SERVICING_AGENCY_LINK_POLICY_SERVICING_AGENCY foreign key (HK_LINK_POLICY_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_CLONE_AD.LINK_POLICY_SERVICING_AGENCY(HK_LINK_POLICY_SERVICING_AGENCY)
);
create or replace TABLE SAT_REINSURANCE_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_COVERAGE_YEAR NUMBER(38,0),
	REINSURANCE_NAAR_FACTOR NUMBER(38,2),
	REINSURANCE_STOPPED_INDICATOR VARCHAR(255),
	REINSURANCE_STOP_DATE VARCHAR(255),
	RETAINED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_FACE_AMOUNT_AT_ACTIVATION NUMBER(38,2),
	REMAINING_FACE_AMOUNT_CEDED_SHARE NUMBER(38,2),
	REINSURANCE_REFERENCE_DATE VARCHAR(255),
	REINSURANCE_EFFECTIVE_DATE VARCHAR(255),
	INITIAL_TERM_DURATION VARCHAR(255),
	constraint PK_SAT_REINSURANCE_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_INSURED (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_ISSUE_AGE VARCHAR(255),
	REINSURANCE_GENDER VARCHAR(255),
	REINSURANCE_TOBACCO_USE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_INSURED primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_GROUP_CODE VARCHAR(255),
	CESSION_MODE VARCHAR(255),
	REINSURANCE_TYPE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY, MD_START_DT),
	constraint FK_SAT_REINSURANCE_TREATY_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	NAME VARCHAR(255),
	constraint PK_SAT_REINSURER primary key (HK_HUB_REINSURER, MD_START_DT),
	constraint FK_SAT_REINSURER_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_AD.HUB_REINSURER(HK_HUB_REINSURER)
);
create or replace TABLE SAT_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_NAAR NUMBER(38,2),
	REINSURED_FACE_AMOUNT_SHARE NUMBER(38,2),
	RISK_CESSION_DATE VARCHAR(255),
	REINSURANCE_GROSS_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	RISK_CESSION_ADJUSTEMENT_ORIGIN VARCHAR(255),
	constraint PK_SAT_RISK_CESSION primary key (HK_LINK_RISK_CESSION, MD_START_DT),
	constraint FK_SAT_RISK_CESSION_LINK_RISK_CESSION foreign key (HK_LINK_RISK_CESSION) references DB_AV_DEV_DWH.RDV_CLONE_AD.LINK_RISK_CESSION(HK_LINK_RISK_CESSION)
);
create or replace view VW_INFORMATION_TABLES(
	TABLE_CATALOG,
	TABLE_SCHEMA,
	TABLE_NAME,
	COLUMN_NAME,
	ORDINAL_POSITION,
	DATA_TYPE,
	LENGTH,
	SCALE,
	TABLE_COMMENT,
	COLUMN_COMMENT
) as

SELECT 
T.TABLE_CATALOG, T.TABLE_SCHEMA, T.TABLE_NAME,  
C.COLUMN_NAME, C.ORDINAL_POSITION, 
C.DATA_TYPE, 
COALESCE (C.CHARACTER_MAXIMUM_LENGTH, C.NUMERIC_PRECISION) AS LENGTH,
COALESCE (C.NUMERIC_SCALE, C.DATETIME_PRECISION) AS SCALE,
T.COMMENT AS TABLE_COMMENT, C.COMMENT AS COLUMN_COMMENT
FROM INFORMATION_SCHEMA.TABLES T
INNER JOIN INFORMATION_SCHEMA.COLUMNS C
	ON T.TABLE_CATALOG    = C.TABLE_CATALOG
	AND T.TABLE_SCHEMA    = C.TABLE_SCHEMA
	AND T.TABLE_NAME      = C.TABLE_NAME
WHERE T.TABLE_TYPE = 'BASE TABLE' AND T.TABLE_SCHEMA = 'RDV';
create or replace view VW_SAT_ACTIVITY_LAST_ROW(
	HK_HUB_TRANSACTION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_TRANSACTION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_TRANSACTION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_ACTIVITY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_APPLICATION_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_APPLICATION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_BENEFICIARY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_BENEFICIARY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_BENEFICIARY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_INSURED_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_INSURED,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_INSURED,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_SERVICING_AGENCY_LAST_ROW(
	DK_HK_HUB_POLICY,
	HK_LINK_POLICY_SERVICING_AGENCY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_POLICY,
            HK_LINK_POLICY_SERVICING_AGENCY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY_SERVICING_AGENCY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_INSURED_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_TREATY_LAST_ROW(
	HK_HUB_REINSURANCE_TREATY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURANCE_TREATY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURANCE_TREATY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_TREATY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURER_LAST_ROW(
	HK_HUB_REINSURER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_RISK_CESSION_LAST_ROW(
	HK_LINK_RISK_CESSION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_RISK_CESSION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_RISK_CESSION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_RISK_CESSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace schema RDV_CLONE_AD_BACKUP;

create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	ADVISOR_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	ADVISOR_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURANCE_TREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	REINSURANCE_SUBTREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE HUB_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURER_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURER primary key (HK_HUB_REINSURER)
);
create or replace TABLE HUB_SERVICING_AGENCY (
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	AGENCY_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_SERVICING_AGENCY primary key (HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE HUB_TRANSACTION (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	TRANSACTION_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	CORRELATION_ID VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_TRANSACTION primary key (HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_ADVISOR(HK_HUB_ADVISOR)
);
create or replace TABLE LINK_COVERAGE_BENEFICIARY (
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY primary key (HK_LINK_COVERAGE_BENEFICIARY),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED),
	constraint FK_LINK_COVERAGE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_LINK_COVERAGE_INSURED_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_CLIENT(HK_HUB_CLIENT)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_POLICY(HK_HUB_POLICY),
	constraint FK_LINK_POLICY_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_POLICY_OWNER_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_SERVICING_AGENCY foreign key (HK_HUB_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_SERVICING_AGENCY(HK_HUB_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_TRANSACTION (
	HK_LINK_POLICY_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_TRANSACTION primary key (HK_LINK_POLICY_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_TRANSACTION(HK_HUB_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION primary key (HK_LINK_RISK_CESSION),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_RISK_CESSION_TRANSACTION (
	HK_LINK_RISK_CESSION_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION_TRANSACTION primary key (HK_LINK_RISK_CESSION_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_ACTIVITY (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ACTIVITY_EFFECTIVE_DATE VARCHAR(255),
	ACTIVITY_TYPE VARCHAR(255),
	TRANSACTION_NAME VARCHAR(255),
	ACTIVITY_PROCESSED_DATE VARCHAR(255),
	constraint PK_SAT_ACTIVITY primary key (HK_HUB_TRANSACTION, MD_START_DT),
	constraint FK_SAT_ACTIVITY_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_APPLICATION (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CASE_NAME VARCHAR(255),
	CASE_NUMBER VARCHAR(255),
	APPLICATION_AUTOMATIC_APPROVAL VARCHAR(255),
	APPLICATION_RECEPTION_DATE VARCHAR(255),
	UNDERWRITING_APPROVAL_DATE VARCHAR(255),
	DEPOSIT_WITH_APPLICATION_AMOUNT NUMBER(38,2),
	APPLICATION_INPUT_MODE VARCHAR(255),
	APPLICATION_ELECTRONIC_SIGNATURE VARCHAR(255),
	APPLICATION_SOURCE VARCHAR(255),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_COMMISSION (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COMMISSION_SHARE VARCHAR(255),
	constraint PK_SAT_COMMISSION primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COMMISSION_LINK_COMMISSIONABLE_ADVISOR foreign key (HK_LINK_COMMISSIONABLE_ADVISOR) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.LINK_COMMISSIONABLE_ADVISOR(HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,0),
	CURRENT_FACE_AMOUNT NUMBER(38,0),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,2),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,2),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,2),
	DISTRIBUTED_POLICY_FEES NUMBER(38,2),
	FACTOR_P NUMBER(38,14),
	COVERAGE_NCPI_ITD NUMBER(38,2),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,14),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_COVERAGE_UPDATED VARCHAR(255),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_BENEFICIARY (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	BENEFICIARY_LEGAL_SUCCESSION VARCHAR(255),
	BENEFICIARY_REVOCABLE VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_TYPE VARCHAR(255),
	BENEFICIARY_RELATIONSHIP_TO_INSURED VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_PERCENT NUMBER(38,2),
	constraint PK_SAT_COVERAGE_BENEFICIARY primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (DK_HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_SAT_COVERAGE_BENEFICIARY_LINK_COVERAGE_BENEFICIARY foreign key (HK_LINK_COVERAGE_BENEFICIARY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.LINK_COVERAGE_BENEFICIARY(HK_LINK_COVERAGE_BENEFICIARY)
);
create or replace TABLE SAT_COVERAGE_INSURED (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	FIRST_NAME VARCHAR(255),
	LAST_NAME VARCHAR(255),
	POSTAL_CODE VARCHAR(255),
	PROVINCE VARCHAR(255),
	COUNTRY VARCHAR(255),
	constraint PK_SAT_COVERAGE_INSURED primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_INSURED_LINK_COVERAGE_INSURED foreign key (HK_LINK_COVERAGE_INSURED) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.LINK_COVERAGE_INSURED(HK_LINK_COVERAGE_INSURED)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,2),
	POLICY_ANNUAL_PREMIUM NUMBER(38,2),
	POLICY_MODAL_PREMIUM NUMBER(38,2),
	ANNUAL_POLICY_FEES NUMBER(38,2),
	MODAL_POLICY_FEES NUMBER(38,2),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_OWNER (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CORRESPONDENCE_INDICATOR VARCHAR(5),
	PARTY_TYPE VARCHAR(255),
	AMERICAN_RESIDENT_INDICATOR VARCHAR(255),
	LANGUAGE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_OWNER_LINK_POLICY_OWNER foreign key (HK_LINK_POLICY_OWNER) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.LINK_POLICY_OWNER(HK_LINK_POLICY_OWNER)
);
create or replace TABLE SAT_POLICY_SERVICING_AGENCY (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	constraint PK_SAT_POLICY_SERVICING_AGENCY primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_SERVICING_AGENCY_LINK_POLICY_SERVICING_AGENCY foreign key (HK_LINK_POLICY_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.LINK_POLICY_SERVICING_AGENCY(HK_LINK_POLICY_SERVICING_AGENCY)
);
create or replace TABLE SAT_REINSURANCE_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_COVERAGE_YEAR NUMBER(38,0),
	REINSURANCE_NAAR_FACTOR NUMBER(38,2),
	REINSURANCE_STOPPED_INDICATOR VARCHAR(255),
	REINSURANCE_STOP_DATE VARCHAR(255),
	RETAINED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_FACE_AMOUNT_AT_ACTIVATION NUMBER(38,2),
	REMAINING_FACE_AMOUNT_CEDED_SHARE NUMBER(38,2),
	REINSURANCE_REFERENCE_DATE VARCHAR(255),
	REINSURANCE_EFFECTIVE_DATE VARCHAR(255),
	INITIAL_TERM_DURATION VARCHAR(255),
	constraint PK_SAT_REINSURANCE_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_INSURED (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_ISSUE_AGE VARCHAR(255),
	REINSURANCE_GENDER VARCHAR(255),
	REINSURANCE_TOBACCO_USE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_INSURED primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_GROUP_CODE VARCHAR(255),
	CESSION_MODE VARCHAR(255),
	REINSURANCE_TYPE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY, MD_START_DT),
	constraint FK_SAT_REINSURANCE_TREATY_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	NAME VARCHAR(255),
	constraint PK_SAT_REINSURER primary key (HK_HUB_REINSURER, MD_START_DT),
	constraint FK_SAT_REINSURER_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.HUB_REINSURER(HK_HUB_REINSURER)
);
create or replace TABLE SAT_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_NAAR NUMBER(38,2),
	REINSURED_FACE_AMOUNT_SHARE NUMBER(38,2),
	RISK_CESSION_DATE VARCHAR(255),
	REINSURANCE_GROSS_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	RISK_CESSION_ADJUSTEMENT_ORIGIN VARCHAR(255),
	constraint PK_SAT_RISK_CESSION primary key (HK_LINK_RISK_CESSION, MD_START_DT),
	constraint FK_SAT_RISK_CESSION_LINK_RISK_CESSION foreign key (HK_LINK_RISK_CESSION) references DB_AV_DEV_DWH.RDV_CLONE_AD_BACKUP.LINK_RISK_CESSION(HK_LINK_RISK_CESSION)
);
create or replace view VW_INFORMATION_TABLES(
	TABLE_CATALOG,
	TABLE_SCHEMA,
	TABLE_NAME,
	COLUMN_NAME,
	ORDINAL_POSITION,
	DATA_TYPE,
	LENGTH,
	SCALE,
	TABLE_COMMENT,
	COLUMN_COMMENT
) as

SELECT 
T.TABLE_CATALOG, T.TABLE_SCHEMA, T.TABLE_NAME,  
C.COLUMN_NAME, C.ORDINAL_POSITION, 
C.DATA_TYPE, 
COALESCE (C.CHARACTER_MAXIMUM_LENGTH, C.NUMERIC_PRECISION) AS LENGTH,
COALESCE (C.NUMERIC_SCALE, C.DATETIME_PRECISION) AS SCALE,
T.COMMENT AS TABLE_COMMENT, C.COMMENT AS COLUMN_COMMENT
FROM INFORMATION_SCHEMA.TABLES T
INNER JOIN INFORMATION_SCHEMA.COLUMNS C
	ON T.TABLE_CATALOG    = C.TABLE_CATALOG
	AND T.TABLE_SCHEMA    = C.TABLE_SCHEMA
	AND T.TABLE_NAME      = C.TABLE_NAME
WHERE T.TABLE_TYPE = 'BASE TABLE' AND T.TABLE_SCHEMA = 'RDV';
create or replace view VW_SAT_ACTIVITY_LAST_ROW(
	HK_HUB_TRANSACTION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_TRANSACTION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_TRANSACTION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_ACTIVITY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_APPLICATION_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_APPLICATION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_BENEFICIARY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_BENEFICIARY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_BENEFICIARY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_INSURED_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_INSURED,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_INSURED,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_SERVICING_AGENCY_LAST_ROW(
	DK_HK_HUB_POLICY,
	HK_LINK_POLICY_SERVICING_AGENCY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_POLICY,
            HK_LINK_POLICY_SERVICING_AGENCY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY_SERVICING_AGENCY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_INSURED_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_TREATY_LAST_ROW(
	HK_HUB_REINSURANCE_TREATY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURANCE_TREATY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURANCE_TREATY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_TREATY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURER_LAST_ROW(
	HK_HUB_REINSURER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_RISK_CESSION_LAST_ROW(
	HK_LINK_RISK_CESSION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_RISK_CESSION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_RISK_CESSION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_RISK_CESSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace schema RDV_CLONE_IB;

create or replace TABLE HUB_ADVISOR_TEST_IB (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	ADVISOR_CODE VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_AGENCY_TEST_IB (
	HK_HUB_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	AGENCY_NUMBER VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	constraint PK_HUB_AGENCY primary key (HK_HUB_AGENCY)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_POLICY_H2P (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_PRODUCT (
	HK_HUB_PRODUCT VARCHAR(255) NOT NULL,
	PRODUCT_VERSION_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	RATES_REFERENCE_DATE VARCHAR(255),
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	constraint PK_HUB_PRODUCT primary key (HK_HUB_PRODUCT)
);
create or replace TABLE HUB_SERVICE_UNIT_TEST_IB (
	HK_HUB_SERVICE_UNIT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	constraint PK_HUB_SERVICE_UNIT primary key (HK_HUB_SERVICE_UNIT)
);
create or replace TABLE LINK_AGENCY_POLICY_TEST_IB (
	HK_LINK_AGENCY_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_AGENCY VARCHAR(40),
	HK_HUB_POLICY VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_AGENCY_POLICY primary key (HK_LINK_AGENCY_POLICY)
);
create or replace TABLE LINK_AGENCY_SERVICE_UNIT_TEST_IB (
	HK_LINK_AGENCY_SERVICE_UNIT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_AGENCY VARCHAR(40),
	HK_HUB_SERVICE_UNIT VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_AGENCY_SERVICE_UNIT primary key (HK_LINK_AGENCY_SERVICE_UNIT)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR_TEST_IB (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40),
	HK_HUB_COVERAGE VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_CLONE_IB.HUB_ADVISOR_TEST_IB(HK_HUB_ADVISOR)
);
create or replace TABLE LINK_COVERAGE_POLICY (
	HK_LINK_COVERAGE_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40),
	HK_HUB_COVERAGE VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_COVERAGE_POLICY),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_IB.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_ADVISOR_TEST_IB (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	ADVISOR_TYPE VARCHAR(255),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_SAT_ADVISOR primary key (HK_HUB_ADVISOR, MD_START_DT)
);
create or replace TABLE SAT_COMMISSION_TEST_IB (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	COMMISSION_SHARE VARCHAR(255),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_SAT_COMMISSION primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX VARCHAR(255),
	BASE_COVERAGE VARCHAR(255),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATE_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERME_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,5),
	CURRENT_FACE_AMOUNT NUMBER(38,5),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,5),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,5),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,5),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,5),
	DISTRIBUTED_POLICY_FEES NUMBER(38,5),
	FACTOR_P NUMBER(38,19),
	COVERAGE_NCPI_ITD NUMBER(30,5),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,5),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(30,5),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_EVENT_TYPE VARCHAR(255),
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYEMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENTMETHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_SUSPENSION_REASON VARCHAR(255),
	BILLING_SUSPENSION_REQUESTOR VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,5),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,5),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,5),
	POLICY_ANNUAL_PREMIUM NUMBER(38,5),
	POLICY_MODAL_PREMIUM NUMBER(38,5),
	ANNUAL_POLICY_FEES NUMBER(38,5),
	MODAL_POLICY_FEES NUMBER(38,5),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_IB.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_CLEAN (
	HK_HUB_COVERAGE VARCHAR(40),
	COVERAGE_CODE VARCHAR(50),
	COVERAGE_VERSION_CODE VARCHAR(50),
	COVERAGE_TYPE VARCHAR(2),
	COVERAGE_YEAR NUMBER(4,0),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(4),
	COVERAGE_EFFECTIVE_DATE DATE,
	LAST_RENEWAL_DATE DATE,
	NEXT_RENEWAL_DATE DATE,
	COVERAGE_TERMINATE_DATE DATE,
	EXPIRY_DATE DATE,
	MATURITY_DATE DATE,
	COVERAGE_STATUS VARCHAR(2),
	COVERAGE_SUB_STATUS VARCHAR(2),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(2),
	TAXATION_TOBACCO_USE VARCHAR(2),
	INITIAL_TERME_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(19,2),
	CURRENT_FACE_AMOUNT NUMBER(19,2),
	COVERAGE_ANNUAL_PREMIUM NUMBER(19,2),
	RATES_REFERENCE_DATE DATE,
	COVERAGE_MODAL_PREMIUM NUMBER(19,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(19,2),
	PAID_UP_DATE DATE,
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(19,2),
	DISTRIBUTED_POLICY_FEES NUMBER(19,2),
	FACTOR_P NUMBER(19,19),
	COVERAGE_NCPI_ITD NUMBER(19,2),
	COVERAGE_TAXATION_DURATION NUMBER(4,0),
	COVERAGE_NPR_FACTOR NUMBER(19,2),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(19,2),
	HK_HUB_POLICY VARCHAR(40),
	POLICY_EVENT_TYPE VARCHAR(100),
	PRODUCT_CODE VARCHAR(50),
	PRODUCT_VERSION_CODE VARCHAR(50),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(4),
	ISSUE_STATE VARCHAR(4),
	POLICY_EFFECTIVE_DATE DATE,
	LAST_REINSTATEMENT_DATE DATE,
	POLICY_STATUS VARCHAR(2),
	POLICY_SUB_STATUS VARCHAR(2),
	PAYEMENT_FREQUENCY VARCHAR(2),
	NEXT_PREMIUM_DUE_DATE DATE,
	PAYMENT_METHOD VARCHAR(2),
	BILLING_STATUS VARCHAR(2),
	PAID_TO_DATE DATE,
	BILLING_SUSPENSION_REASON VARCHAR(255),
	BILLING_SUSPENSION_REQUESTOR VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE DATE,
	POLICY_ACB NUMBER(19,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(19,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(19,2),
	POLICY_ANNUAL_PREMIUM NUMBER(19,2),
	POLICY_MODAL_PREMIUM NUMBER(19,2),
	ANNUAL_POLICY_FEES NUMBER(19,2),
	MODAL_POLICY_FEES NUMBER(19,2),
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_USER VARCHAR(255)
);
create or replace TABLE TMP_HUB_PRODUCT (
	PRODUCT_VERSION_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	RATES_REFERENCE_DATE VARCHAR(255),
	MD_CREATION_DT VARCHAR(255)
);
create or replace TABLE TMP_HUB_PRODUCT_1 (
	HK_HUB_PRODUCT VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	RATES_REFERENCE_DATE VARCHAR(255),
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE'
);
create or replace view VW_SAT_ADVISOR_LAST_ROW_TEST_IB(
	HK_HUB_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM "RDV_CLONE_IB"."SAT_ADVISOR_TEST_IB"
)
SELECT *
FROM LAST_ROW;
create or replace view VW_SAT_COMMISSION_LAST_ROW_TEST_IB(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COMMISSIONABLE_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COMMISSIONABLE_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM "RDV_CLONE_IB"."SAT_COMMISSION_TEST_IB"
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM RDV.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM RDV.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace schema RDV_CLONE_IB_PT;

create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	ADVISOR_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	ADVISOR_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURANCE_TREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	REINSURANCE_SUBTREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE HUB_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURER_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURER primary key (HK_HUB_REINSURER)
);
create or replace TABLE HUB_SERVICING_AGENCY (
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	AGENCY_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_SERVICING_AGENCY primary key (HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE HUB_TRANSACTION (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	TRANSACTION_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	CORRELATION_ID VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_TRANSACTION primary key (HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_ADVISOR(HK_HUB_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_BENEFICIARY (
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY primary key (HK_LINK_COVERAGE_BENEFICIARY),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED),
	constraint FK_LINK_COVERAGE_INSURED_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_POLICY(HK_HUB_POLICY),
	constraint FK_LINK_POLICY_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_POLICY_OWNER_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_SERVICING_AGENCY foreign key (HK_HUB_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_SERVICING_AGENCY(HK_HUB_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_TRANSACTION (
	HK_LINK_POLICY_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_TRANSACTION primary key (HK_LINK_POLICY_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_POLICY(HK_HUB_POLICY),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION primary key (HK_LINK_RISK_CESSION),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE LINK_RISK_CESSION_TRANSACTION (
	HK_LINK_RISK_CESSION_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION_TRANSACTION primary key (HK_LINK_RISK_CESSION_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_TRANSACTION(HK_HUB_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_ACTIVITY (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ACTIVITY_EFFECTIVE_DATE VARCHAR(255),
	ACTIVITY_TYPE VARCHAR(255),
	TRANSACTION_NAME VARCHAR(255),
	ACTIVITY_PROCESSED_DATE VARCHAR(255),
	constraint PK_SAT_ACTIVITY primary key (HK_HUB_TRANSACTION, MD_START_DT),
	constraint FK_SAT_ACTIVITY_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_APPLICATION (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CASE_NAME VARCHAR(255),
	CASE_NUMBER VARCHAR(255),
	APPLICATION_AUTOMATIC_APPROVAL VARCHAR(255),
	APPLICATION_RECEPTION_DATE VARCHAR(255),
	UNDERWRITING_APPROVAL_DATE VARCHAR(255),
	DEPOSIT_WITH_APPLICATION_AMOUNT NUMBER(38,2),
	APPLICATION_INPUT_MODE VARCHAR(255),
	APPLICATION_ELECTRONIC_SIGNATURE VARCHAR(255),
	APPLICATION_SOURCE VARCHAR(255),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_COMMISSION (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COMMISSION_SHARE VARCHAR(255),
	constraint PK_SAT_COMMISSION primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT),
	constraint FK_SAT_COMMISSION_LINK_COMMISSIONABLE_ADVISOR foreign key (HK_LINK_COMMISSIONABLE_ADVISOR) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.LINK_COMMISSIONABLE_ADVISOR(HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,0),
	CURRENT_FACE_AMOUNT NUMBER(38,0),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,2),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,2),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,2),
	DISTRIBUTED_POLICY_FEES NUMBER(38,2),
	FACTOR_P NUMBER(38,14),
	COVERAGE_NCPI_ITD NUMBER(38,2),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,14),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_COVERAGE_UPDATED VARCHAR(255),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_BENEFICIARY (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	BENEFICIARY_LEGAL_SUCCESSION VARCHAR(255),
	BENEFICIARY_REVOCABLE VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_TYPE VARCHAR(255),
	BENEFICIARY_RELATIONSHIP_TO_INSURED VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_PERCENT NUMBER(38,2),
	constraint PK_SAT_COVERAGE_BENEFICIARY primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_BENEFICIARY_LINK_COVERAGE_BENEFICIARY foreign key (HK_LINK_COVERAGE_BENEFICIARY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.LINK_COVERAGE_BENEFICIARY(HK_LINK_COVERAGE_BENEFICIARY),
	constraint FK_SAT_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (DK_HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_INSURED (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	FIRST_NAME VARCHAR(255),
	LAST_NAME VARCHAR(255),
	POSTAL_CODE VARCHAR(255),
	PROVINCE VARCHAR(255),
	COUNTRY VARCHAR(255),
	constraint PK_SAT_COVERAGE_INSURED primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_INSURED_LINK_COVERAGE_INSURED foreign key (HK_LINK_COVERAGE_INSURED) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.LINK_COVERAGE_INSURED(HK_LINK_COVERAGE_INSURED)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,2),
	POLICY_ANNUAL_PREMIUM NUMBER(38,2),
	POLICY_MODAL_PREMIUM NUMBER(38,2),
	ANNUAL_POLICY_FEES NUMBER(38,2),
	MODAL_POLICY_FEES NUMBER(38,2),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_OWNER (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CORRESPONDENCE_INDICATOR VARCHAR(5),
	PARTY_TYPE VARCHAR(255),
	AMERICAN_RESIDENT_INDICATOR VARCHAR(255),
	LANGUAGE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (DK_HK_HUB_POLICY, MD_START_DT)
);
create or replace TABLE SAT_POLICY_SERVICING_AGENCY (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	constraint PK_SAT_POLICY_SERVICING_AGENCY primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_SERVICING_AGENCY_LINK_POLICY_SERVICING_AGENCY foreign key (HK_LINK_POLICY_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.LINK_POLICY_SERVICING_AGENCY(HK_LINK_POLICY_SERVICING_AGENCY)
);
create or replace TABLE SAT_REINSURANCE_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_COVERAGE_YEAR NUMBER(38,0),
	REINSURANCE_NAAR_FACTOR NUMBER(38,2),
	REINSURANCE_STOPPED_INDICATOR VARCHAR(255),
	REINSURANCE_STOP_DATE VARCHAR(255),
	RETAINED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_FACE_AMOUNT_AT_ACTIVATION NUMBER(38,2),
	REMAINING_FACE_AMOUNT_CEDED_SHARE NUMBER(38,2),
	REINSURANCE_REFERENCE_DATE VARCHAR(255),
	REINSURANCE_EFFECTIVE_DATE VARCHAR(255),
	INITIAL_TERM_DURATION VARCHAR(255),
	constraint PK_SAT_REINSURANCE_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_INSURED (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_ISSUE_AGE VARCHAR(255),
	REINSURANCE_GENDER VARCHAR(255),
	REINSURANCE_TOBACCO_USE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_INSURED primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_GROUP_CODE VARCHAR(255),
	CESSION_MODE VARCHAR(255),
	REINSURANCE_TYPE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY, MD_START_DT),
	constraint FK_SAT_REINSURANCE_TREATY_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	NAME VARCHAR(255),
	constraint PK_SAT_REINSURER primary key (HK_HUB_REINSURER, MD_START_DT),
	constraint FK_SAT_REINSURER_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.HUB_REINSURER(HK_HUB_REINSURER)
);
create or replace TABLE SAT_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_NAAR NUMBER(38,2),
	REINSURED_FACE_AMOUNT_SHARE NUMBER(38,2),
	RISK_CESSION_DATE VARCHAR(255),
	REINSURANCE_GROSS_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	RISK_CESSION_ADJUSTEMENT_ORIGIN VARCHAR(255),
	constraint PK_SAT_RISK_CESSION primary key (HK_LINK_RISK_CESSION, MD_START_DT),
	constraint FK_SAT_RISK_CESSION_LINK_RISK_CESSION foreign key (HK_LINK_RISK_CESSION) references DB_AV_DEV_DWH.RDV_CLONE_IB_PT.LINK_RISK_CESSION(HK_LINK_RISK_CESSION)
);
create or replace view VW_INFORMATION_TABLES(
	TABLE_CATALOG,
	TABLE_SCHEMA,
	TABLE_NAME,
	COLUMN_NAME,
	ORDINAL_POSITION,
	DATA_TYPE,
	LENGTH,
	SCALE,
	TABLE_COMMENT,
	COLUMN_COMMENT
) as

SELECT 
T.TABLE_CATALOG, T.TABLE_SCHEMA, T.TABLE_NAME,  
C.COLUMN_NAME, C.ORDINAL_POSITION, 
C.DATA_TYPE, 
COALESCE (C.CHARACTER_MAXIMUM_LENGTH, C.NUMERIC_PRECISION) AS LENGTH,
COALESCE (C.NUMERIC_SCALE, C.DATETIME_PRECISION) AS SCALE,
T.COMMENT AS TABLE_COMMENT, C.COMMENT AS COLUMN_COMMENT
FROM INFORMATION_SCHEMA.TABLES T
INNER JOIN INFORMATION_SCHEMA.COLUMNS C
	ON T.TABLE_CATALOG    = C.TABLE_CATALOG
	AND T.TABLE_SCHEMA    = C.TABLE_SCHEMA
	AND T.TABLE_NAME      = C.TABLE_NAME
WHERE T.TABLE_TYPE = 'BASE TABLE' AND T.TABLE_SCHEMA = 'RDV_CLONE_IB_PT';
create or replace view VW_SAT_ACTIVITY_LAST_ROW(
	HK_HUB_TRANSACTION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_TRANSACTION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_TRANSACTION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_ACTIVITY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_APPLICATION_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_APPLICATION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COMMISSION_LAST_ROW(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COMMISSIONABLE_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COMMISSIONABLE_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_COMMISSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_BENEFICIARY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_BENEFICIARY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_COVERAGE_BENEFICIARY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_INSURED_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_INSURED,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_INSURED,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_COVERAGE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_OWNER_LAST_ROW(
	DK_HK_HUB_POLICY,
	HK_LINK_POLICY_OWNER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_POLICY,
            HK_LINK_POLICY_OWNER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_POLICY_OWNER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_SERVICING_AGENCY_LAST_ROW(
	DK_HK_HUB_POLICY,
	HK_LINK_POLICY_SERVICING_AGENCY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_POLICY,
            HK_LINK_POLICY_SERVICING_AGENCY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_POLICY_SERVICING_AGENCY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_REINSURANCE_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_INSURED_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_REINSURANCE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_TREATY_LAST_ROW(
	HK_HUB_REINSURANCE_TREATY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURANCE_TREATY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURANCE_TREATY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_REINSURANCE_TREATY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURER_LAST_ROW(
	HK_HUB_REINSURER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_REINSURER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_RISK_CESSION_LAST_ROW(
	HK_LINK_RISK_CESSION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_RISK_CESSION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_RISK_CESSION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_CLONE_IB_PT.SAT_RISK_CESSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
CREATE OR REPLACE FUNCTION "GHOSTVALUE"()
RETURNS VARCHAR(40)
LANGUAGE SQL
AS '
    REPEAT(''0'',40)
';
create or replace schema RDV_GP;

create or replace TABLE DUMMY (
	COLUMN1 VARCHAR(255)
);
create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	ADVISOR_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	ADVISOR_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURANCE_TREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	REINSURANCE_SUBTREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE HUB_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURER_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURER primary key (HK_HUB_REINSURER)
);
create or replace TABLE HUB_SERVICING_AGENCY (
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	AGENCY_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_SERVICING_AGENCY primary key (HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE HUB_TRANSACTION (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	TRANSACTION_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	CORRELATION_ID VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_TRANSACTION primary key (HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_GP.HUB_ADVISOR(HK_HUB_ADVISOR)
);
create or replace TABLE LINK_COVERAGE_BENEFICIARY (
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY primary key (HK_LINK_COVERAGE_BENEFICIARY),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_GP.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED),
	constraint FK_LINK_COVERAGE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_LINK_COVERAGE_INSURED_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_GP.HUB_CLIENT(HK_HUB_CLIENT)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_GP.HUB_POLICY(HK_HUB_POLICY),
	constraint FK_LINK_POLICY_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_GP.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_POLICY_OWNER_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_GP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_SERVICING_AGENCY foreign key (HK_HUB_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_GP.HUB_SERVICING_AGENCY(HK_HUB_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_GP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_TRANSACTION (
	HK_LINK_POLICY_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_TRANSACTION primary key (HK_LINK_POLICY_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_GP.HUB_TRANSACTION(HK_HUB_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_GP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION primary key (HK_LINK_RISK_CESSION),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_GP.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_GP.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_RISK_CESSION_TRANSACTION (
	HK_LINK_RISK_CESSION_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION_TRANSACTION primary key (HK_LINK_RISK_CESSION_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_GP.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_GP.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_GP.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_ACTIVITY (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ACTIVITY_EFFECTIVE_DATE VARCHAR(255),
	ACTIVITY_TYPE VARCHAR(255),
	TRANSACTION_NAME VARCHAR(255),
	ACTIVITY_PROCESSED_DATE VARCHAR(255),
	constraint PK_SAT_ACTIVITY primary key (HK_HUB_TRANSACTION, MD_START_DT),
	constraint FK_SAT_ACTIVITY_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_GP.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_APPLICATION (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CASE_NAME VARCHAR(255),
	CASE_NUMBER VARCHAR(255),
	APPLICATION_AUTOMATIC_APPROVAL VARCHAR(255),
	APPLICATION_RECEPTION_DATE VARCHAR(255),
	UNDERWRITING_APPROVAL_DATE VARCHAR(255),
	DEPOSIT_WITH_APPLICATION_AMOUNT NUMBER(38,2),
	APPLICATION_INPUT_MODE VARCHAR(255),
	APPLICATION_ELECTRONIC_SIGNATURE VARCHAR(255),
	APPLICATION_SOURCE VARCHAR(255),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_GP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_COMMISSION (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COMMISSION_SHARE VARCHAR(255),
	constraint PK_SAT_COMMISSION primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT),
	constraint FK_SAT_COMMISSION_LINK_COMMISSIONABLE_ADVISOR foreign key (HK_LINK_COMMISSIONABLE_ADVISOR) references DB_AV_DEV_DWH.RDV_GP.LINK_COMMISSIONABLE_ADVISOR(HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,0),
	CURRENT_FACE_AMOUNT NUMBER(38,0),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,2),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,2),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,2),
	DISTRIBUTED_POLICY_FEES NUMBER(38,2),
	FACTOR_P NUMBER(38,14),
	COVERAGE_NCPI_ITD NUMBER(38,2),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,14),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_COVERAGE_UPDATED VARCHAR(255),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_BENEFICIARY (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	BENEFICIARY_LEGAL_SUCCESSION VARCHAR(255),
	BENEFICIARY_REVOCABLE VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_TYPE VARCHAR(255),
	BENEFICIARY_RELATIONSHIP_TO_INSURED VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_PERCENT NUMBER(38,2),
	constraint PK_SAT_COVERAGE_BENEFICIARY primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (DK_HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_SAT_COVERAGE_BENEFICIARY_LINK_COVERAGE_BENEFICIARY foreign key (HK_LINK_COVERAGE_BENEFICIARY) references DB_AV_DEV_DWH.RDV_GP.LINK_COVERAGE_BENEFICIARY(HK_LINK_COVERAGE_BENEFICIARY)
);
create or replace TABLE SAT_COVERAGE_INSURED (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	FIRST_NAME VARCHAR(255),
	LAST_NAME VARCHAR(255),
	POSTAL_CODE VARCHAR(255),
	PROVINCE VARCHAR(255),
	COUNTRY VARCHAR(255),
	constraint PK_SAT_COVERAGE_INSURED primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_INSURED_LINK_COVERAGE_INSURED foreign key (HK_LINK_COVERAGE_INSURED) references DB_AV_DEV_DWH.RDV_GP.LINK_COVERAGE_INSURED(HK_LINK_COVERAGE_INSURED)
);
create or replace TABLE SAT_DEATH_CLAIM (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CLAIM_NUMBER VARCHAR(255),
	CLAIM_STATUS VARCHAR(255),
	DEATH_DATE VARCHAR(255),
	DEATH_TYPE VARCHAR(255),
	CLAIM_SETTLEMENT_TYPE VARCHAR(255),
	constraint PK_SAT_DEATH_CLAIM primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_DEATH_CLAIM_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,2),
	POLICY_ANNUAL_PREMIUM NUMBER(38,2),
	POLICY_MODAL_PREMIUM NUMBER(38,2),
	ANNUAL_POLICY_FEES NUMBER(38,2),
	MODAL_POLICY_FEES NUMBER(38,2),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_GP.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_OWNER (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CORRESPONDENCE_INDICATOR VARCHAR(5),
	PARTY_TYPE VARCHAR(255),
	AMERICAN_RESIDENT_INDICATOR VARCHAR(255),
	LANGUAGE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_OWNER_LINK_POLICY_OWNER foreign key (HK_LINK_POLICY_OWNER) references DB_AV_DEV_DWH.RDV_GP.LINK_POLICY_OWNER(HK_LINK_POLICY_OWNER)
);
create or replace TABLE SAT_POLICY_SERVICING_AGENCY (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	constraint PK_SAT_POLICY_SERVICING_AGENCY primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_SERVICING_AGENCY_LINK_POLICY_SERVICING_AGENCY foreign key (HK_LINK_POLICY_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_GP.LINK_POLICY_SERVICING_AGENCY(HK_LINK_POLICY_SERVICING_AGENCY)
);
create or replace TABLE SAT_REINSURANCE_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_COVERAGE_YEAR NUMBER(38,0),
	REINSURANCE_NAAR_FACTOR NUMBER(38,2),
	REINSURANCE_STOPPED_INDICATOR VARCHAR(255),
	REINSURANCE_STOP_DATE VARCHAR(255),
	RETAINED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_FACE_AMOUNT_AT_ACTIVATION NUMBER(38,2),
	REMAINING_FACE_AMOUNT_CEDED_SHARE NUMBER(38,2),
	REINSURANCE_REFERENCE_DATE VARCHAR(255),
	REINSURANCE_EFFECTIVE_DATE VARCHAR(255),
	INITIAL_TERM_DURATION VARCHAR(255),
	constraint PK_SAT_REINSURANCE_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_INSURED (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_ISSUE_AGE VARCHAR(255),
	REINSURANCE_GENDER VARCHAR(255),
	REINSURANCE_TOBACCO_USE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_INSURED primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_GP.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_GROUP_CODE VARCHAR(255),
	CESSION_MODE VARCHAR(255),
	REINSURANCE_TYPE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY, MD_START_DT),
	constraint FK_SAT_REINSURANCE_TREATY_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_GP.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	NAME VARCHAR(255),
	constraint PK_SAT_REINSURER primary key (HK_HUB_REINSURER, MD_START_DT),
	constraint FK_SAT_REINSURER_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_GP.HUB_REINSURER(HK_HUB_REINSURER)
);
create or replace TABLE SAT_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_NAAR NUMBER(38,2),
	REINSURED_FACE_AMOUNT_SHARE NUMBER(38,2),
	RISK_CESSION_DATE VARCHAR(255),
	REINSURANCE_GROSS_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	RISK_CESSION_ADJUSTEMENT_ORIGIN VARCHAR(255),
	constraint PK_SAT_RISK_CESSION primary key (HK_LINK_RISK_CESSION, MD_START_DT),
	constraint FK_SAT_RISK_CESSION_LINK_RISK_CESSION foreign key (HK_LINK_RISK_CESSION) references DB_AV_DEV_DWH.RDV_GP.LINK_RISK_CESSION(HK_LINK_RISK_CESSION)
);
create or replace view VW_INFORMATION_TABLES(
	TABLE_CATALOG,
	TABLE_SCHEMA,
	TABLE_NAME,
	COLUMN_NAME,
	ORDINAL_POSITION,
	DATA_TYPE,
	LENGTH,
	SCALE,
	TABLE_COMMENT,
	COLUMN_COMMENT
) as

SELECT 
T.TABLE_CATALOG, T.TABLE_SCHEMA, T.TABLE_NAME,  
C.COLUMN_NAME, C.ORDINAL_POSITION, 
C.DATA_TYPE, 
COALESCE (C.CHARACTER_MAXIMUM_LENGTH, C.NUMERIC_PRECISION) AS LENGTH,
COALESCE (C.NUMERIC_SCALE, C.DATETIME_PRECISION) AS SCALE,
T.COMMENT AS TABLE_COMMENT, C.COMMENT AS COLUMN_COMMENT
FROM INFORMATION_SCHEMA.TABLES T
INNER JOIN INFORMATION_SCHEMA.COLUMNS C
	ON T.TABLE_CATALOG    = C.TABLE_CATALOG
	AND T.TABLE_SCHEMA    = C.TABLE_SCHEMA
	AND T.TABLE_NAME      = C.TABLE_NAME
WHERE T.TABLE_TYPE = 'BASE TABLE' AND T.TABLE_SCHEMA = 'RDV';
create or replace view VW_SAT_ACTIVITY_LAST_ROW(
	HK_HUB_TRANSACTION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_TRANSACTION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_TRANSACTION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_ACTIVITY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_APPLICATION_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_APPLICATION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COMMISSION_LAST_ROW(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COMMISSIONABLE_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COMMISSIONABLE_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COMMISSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_BENEFICIARY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_BENEFICIARY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_BENEFICIARY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_INSURED_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_INSURED,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_INSURED,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW_GP(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_GP.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_SERVICING_AGENCY_LAST_ROW(
	DK_HK_HUB_POLICY,
	HK_LINK_POLICY_SERVICING_AGENCY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_POLICY,
            HK_LINK_POLICY_SERVICING_AGENCY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY_SERVICING_AGENCY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_TREATY_LAST_ROW(
	HK_HUB_REINSURANCE_TREATY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURANCE_TREATY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURANCE_TREATY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_TREATY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURER_LAST_ROW(
	HK_HUB_REINSURER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_RISK_CESSION_LAST_ROW(
	HK_LINK_RISK_CESSION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_RISK_CESSION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_RISK_CESSION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_RISK_CESSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace schema RDV_OZ;

create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	ADVISOR_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	ADVISOR_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURANCE_TREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	REINSURANCE_SUBTREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE HUB_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURER_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURER primary key (HK_HUB_REINSURER)
);
create or replace TABLE HUB_SERVICING_AGENCY (
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	AGENCY_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_SERVICING_AGENCY primary key (HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE HUB_TRANSACTION (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	TRANSACTION_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	CORRELATION_ID VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_TRANSACTION primary key (HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_OZ.HUB_ADVISOR(HK_HUB_ADVISOR)
);
create or replace TABLE LINK_COVERAGE_BENEFICIARY (
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY primary key (HK_LINK_COVERAGE_BENEFICIARY),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_OZ.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED),
	constraint FK_LINK_COVERAGE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_LINK_COVERAGE_INSURED_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_OZ.HUB_CLIENT(HK_HUB_CLIENT)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_OZ.HUB_POLICY(HK_HUB_POLICY),
	constraint FK_LINK_POLICY_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_OZ.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_POLICY_OWNER_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_OZ.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_SERVICING_AGENCY foreign key (HK_HUB_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_OZ.HUB_SERVICING_AGENCY(HK_HUB_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_OZ.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_TRANSACTION (
	HK_LINK_POLICY_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_TRANSACTION primary key (HK_LINK_POLICY_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_OZ.HUB_TRANSACTION(HK_HUB_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_OZ.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION primary key (HK_LINK_RISK_CESSION),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_OZ.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_OZ.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_RISK_CESSION_TRANSACTION (
	HK_LINK_RISK_CESSION_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION_TRANSACTION primary key (HK_LINK_RISK_CESSION_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_OZ.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_OZ.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_OZ.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_ACTIVITY (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ACTIVITY_EFFECTIVE_DATE VARCHAR(255),
	ACTIVITY_TYPE VARCHAR(255),
	TRANSACTION_NAME VARCHAR(255),
	ACTIVITY_PROCESSED_DATE VARCHAR(255),
	constraint PK_SAT_ACTIVITY primary key (HK_HUB_TRANSACTION, MD_START_DT),
	constraint FK_SAT_ACTIVITY_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_OZ.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_APPLICATION (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CASE_NAME VARCHAR(255),
	CASE_NUMBER VARCHAR(255),
	APPLICATION_AUTOMATIC_APPROVAL VARCHAR(255),
	APPLICATION_RECEPTION_DATE VARCHAR(255),
	UNDERWRITING_APPROVAL_DATE VARCHAR(255),
	DEPOSIT_WITH_APPLICATION_AMOUNT NUMBER(38,2),
	APPLICATION_INPUT_MODE VARCHAR(255),
	APPLICATION_ELECTRONIC_SIGNATURE VARCHAR(255),
	APPLICATION_SOURCE VARCHAR(255),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_OZ.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_COMMISSION (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COMMISSION_SHARE VARCHAR(255),
	constraint PK_SAT_COMMISSION primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT),
	constraint FK_SAT_COMMISSION_LINK_COMMISSIONABLE_ADVISOR foreign key (HK_LINK_COMMISSIONABLE_ADVISOR) references DB_AV_DEV_DWH.RDV_OZ.LINK_COMMISSIONABLE_ADVISOR(HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,0),
	CURRENT_FACE_AMOUNT NUMBER(38,0),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,2),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,2),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,2),
	DISTRIBUTED_POLICY_FEES NUMBER(38,2),
	FACTOR_P NUMBER(38,14),
	COVERAGE_NCPI_ITD NUMBER(38,2),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,14),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_COVERAGE_UPDATED VARCHAR(255),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_BENEFICIARY (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	BENEFICIARY_LEGAL_SUCCESSION VARCHAR(255),
	BENEFICIARY_REVOCABLE VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_TYPE VARCHAR(255),
	BENEFICIARY_RELATIONSHIP_TO_INSURED VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_PERCENT NUMBER(38,2),
	constraint PK_SAT_COVERAGE_BENEFICIARY primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (DK_HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_SAT_COVERAGE_BENEFICIARY_LINK_COVERAGE_BENEFICIARY foreign key (HK_LINK_COVERAGE_BENEFICIARY) references DB_AV_DEV_DWH.RDV_OZ.LINK_COVERAGE_BENEFICIARY(HK_LINK_COVERAGE_BENEFICIARY)
);
create or replace TABLE SAT_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	FIRST_NAME VARCHAR(255),
	LAST_NAME VARCHAR(255),
	POSTAL_CODE VARCHAR(255),
	PROVINCE VARCHAR(255),
	COUNTRY VARCHAR(255),
	constraint PK_SAT_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED, MD_START_DT),
	constraint FK_SAT_COVERAGE_INSURED_LINK_COVERAGE_INSURED foreign key (HK_LINK_COVERAGE_INSURED) references DB_AV_DEV_DWH.RDV_OZ.LINK_COVERAGE_INSURED(HK_LINK_COVERAGE_INSURED)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,2),
	POLICY_ANNUAL_PREMIUM NUMBER(38,2),
	POLICY_MODAL_PREMIUM NUMBER(38,2),
	ANNUAL_POLICY_FEES NUMBER(38,2),
	MODAL_POLICY_FEES NUMBER(38,2),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_OZ.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	POLICY_OWNER_CORRESPONDENCE_INDICATOR VARCHAR(5),
	POLICY_PARTY_TYPE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER, MD_START_DT),
	constraint FK_SAT_POLICY_OWNER_LINK_POLICY_OWNER foreign key (HK_LINK_POLICY_OWNER) references DB_AV_DEV_DWH.RDV_OZ.LINK_POLICY_OWNER(HK_LINK_POLICY_OWNER)
);
create or replace TABLE SAT_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	constraint PK_SAT_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY, MD_START_DT),
	constraint FK_SAT_POLICY_SERVICING_AGENCY_LINK_POLICY_SERVICING_AGENCY foreign key (HK_LINK_POLICY_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_OZ.LINK_POLICY_SERVICING_AGENCY(HK_LINK_POLICY_SERVICING_AGENCY)
);
create or replace TABLE SAT_REINSURANCE_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_COVERAGE_YEAR NUMBER(38,0),
	REINSURANCE_NAAR_FACTOR NUMBER(38,2),
	REINSURANCE_STOPPED_INDICATOR VARCHAR(255),
	REINSURANCE_STOP_DATE VARCHAR(255),
	RETAINED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_FACE_AMOUNT_AT_ACTIVATION NUMBER(38,2),
	REMAINING_FACE_AMOUNT_CEDED_SHARE NUMBER(38,2),
	REINSURANCE_REFERENCE_DATE VARCHAR(255),
	REINSURANCE_EFFECTIVE_DATE VARCHAR(255),
	INITIAL_TERM_DURATION VARCHAR(255),
	constraint PK_SAT_REINSURANCE_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_INSURED (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_ISSUE_AGE VARCHAR(255),
	REINSURANCE_GENDER VARCHAR(255),
	REINSURANCE_TOBACCO_USE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_INSURED primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_OZ.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_GROUP_CODE VARCHAR(255),
	CESSION_MODE VARCHAR(255),
	REINSURANCE_TYPE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY, MD_START_DT),
	constraint FK_SAT_REINSURANCE_TREATY_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_OZ.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	NAME VARCHAR(255),
	constraint PK_SAT_REINSURER primary key (HK_HUB_REINSURER, MD_START_DT),
	constraint FK_SAT_REINSURER_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_OZ.HUB_REINSURER(HK_HUB_REINSURER)
);
create or replace TABLE SAT_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_NAAR NUMBER(38,2),
	REINSURED_FACE_AMOUNT_SHARE NUMBER(38,2),
	RISK_CESSION_DATE VARCHAR(255),
	REINSURANCE_GROSS_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	RISK_CESSION_ADJUSTEMENT_ORIGIN VARCHAR(255),
	constraint PK_SAT_RISK_CESSION primary key (HK_LINK_RISK_CESSION, MD_START_DT),
	constraint FK_SAT_RISK_CESSION_LINK_RISK_CESSION foreign key (HK_LINK_RISK_CESSION) references DB_AV_DEV_DWH.RDV_OZ.LINK_RISK_CESSION(HK_LINK_RISK_CESSION)
);
create or replace view VW_INFORMATION_TABLES(
	TABLE_CATALOG,
	TABLE_SCHEMA,
	TABLE_NAME,
	COLUMN_NAME,
	ORDINAL_POSITION,
	DATA_TYPE,
	LENGTH,
	SCALE,
	TABLE_COMMENT,
	COLUMN_COMMENT
) as

SELECT 
T.TABLE_CATALOG, T.TABLE_SCHEMA, T.TABLE_NAME,  
C.COLUMN_NAME, C.ORDINAL_POSITION, 
C.DATA_TYPE, 
COALESCE (C.CHARACTER_MAXIMUM_LENGTH, C.NUMERIC_PRECISION) AS LENGTH,
COALESCE (C.NUMERIC_SCALE, C.DATETIME_PRECISION) AS SCALE,
T.COMMENT AS TABLE_COMMENT, C.COMMENT AS COLUMN_COMMENT
FROM INFORMATION_SCHEMA.TABLES T
INNER JOIN INFORMATION_SCHEMA.COLUMNS C
	ON T.TABLE_CATALOG    = C.TABLE_CATALOG
	AND T.TABLE_SCHEMA    = C.TABLE_SCHEMA
	AND T.TABLE_NAME      = C.TABLE_NAME
WHERE T.TABLE_TYPE = 'BASE TABLE' AND T.TABLE_SCHEMA = 'RDV';
create or replace view VW_SAT_ACTIVITY_LAST_ROW(
	HK_HUB_TRANSACTION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_TRANSACTION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_TRANSACTION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_ACTIVITY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_APPLICATION_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_APPLICATION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COMMISSION_LAST_ROW(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COMMISSIONABLE_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COMMISSIONABLE_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COMMISSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_BENEFICIARY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_BENEFICIARY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_BENEFICIARY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_INSURED_LAST_ROW(
	HK_LINK_COVERAGE_INSURED,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COVERAGE_INSURED,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COVERAGE_INSURED ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_OWNER_LAST_ROW(
	HK_LINK_POLICY_OWNER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_POLICY_OWNER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_POLICY_OWNER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY_OWNER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_SERVICING_AGENCY_LAST_ROW(
	HK_LINK_POLICY_SERVICING_AGENCY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_POLICY_SERVICING_AGENCY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_POLICY_SERVICING_AGENCY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_POLICY_SERVICING_AGENCY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_INSURED_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_TREATY_LAST_ROW(
	HK_HUB_REINSURANCE_TREATY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURANCE_TREATY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURANCE_TREATY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURANCE_TREATY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURER_LAST_ROW(
	HK_HUB_REINSURER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_REINSURER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_RISK_CESSION_LAST_ROW(
	HK_LINK_RISK_CESSION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_RISK_CESSION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_RISK_CESSION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV.SAT_RISK_CESSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace schema RDV_SILO_0;

create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	ADVISOR_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	ADVISOR_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURANCE_TREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	REINSURANCE_SUBTREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE HUB_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURER_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURER primary key (HK_HUB_REINSURER)
);
create or replace TABLE HUB_SERVICING_AGENCY (
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	AGENCY_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_SERVICING_AGENCY primary key (HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE HUB_TRANSACTION (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	TRANSACTION_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	CORRELATION_ID VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_TRANSACTION primary key (HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_ADVISOR(HK_HUB_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_BENEFICIARY (
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_BENEFICIARY primary key (HK_LINK_COVERAGE_BENEFICIARY),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED),
	constraint FK_LINK_COVERAGE_INSURED_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE),
	constraint FK_LINK_POLICY_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_CLIENT(HK_HUB_CLIENT)
);
create or replace TABLE LINK_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_SERVICING_AGENCY foreign key (HK_HUB_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_SERVICING_AGENCY(HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE LINK_POLICY_TRANSACTION (
	HK_LINK_POLICY_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_TRANSACTION primary key (HK_LINK_POLICY_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION primary key (HK_LINK_RISK_CESSION),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE LINK_RISK_CESSION_TRANSACTION (
	HK_LINK_RISK_CESSION_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION_TRANSACTION primary key (HK_LINK_RISK_CESSION_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_TRANSACTION(HK_HUB_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_ACTIVITY (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ACTIVITY_EFFECTIVE_DATE VARCHAR(255),
	ACTIVITY_TYPE VARCHAR(255),
	TRANSACTION_NAME VARCHAR(255),
	ACTIVITY_PROCESSED_DATE VARCHAR(255),
	constraint PK_SAT_ACTIVITY primary key (HK_HUB_TRANSACTION, MD_START_DT),
	constraint FK_SAT_ACTIVITY_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_APPLICATION (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CASE_NAME VARCHAR(255),
	CASE_NUMBER VARCHAR(255),
	APPLICATION_AUTOMATIC_APPROVAL VARCHAR(255),
	APPLICATION_RECEPTION_DATE VARCHAR(255),
	UNDERWRITING_APPROVAL_DATE VARCHAR(255),
	DEPOSIT_WITH_APPLICATION_AMOUNT NUMBER(38,2),
	APPLICATION_INPUT_MODE VARCHAR(255),
	APPLICATION_ELECTRONIC_SIGNATURE VARCHAR(255),
	APPLICATION_SOURCE VARCHAR(255),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT)
);
create or replace TABLE SAT_COMMISSION (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COMMISSION_SHARE VARCHAR(255),
	constraint PK_SAT_COMMISSION primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT),
	constraint FK_SAT_COMMISSION_LINK_COMMISSIONABLE_ADVISOR foreign key (HK_LINK_COMMISSIONABLE_ADVISOR) references DB_AV_DEV_DWH.RDV_SILO_0.LINK_COMMISSIONABLE_ADVISOR(HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,0),
	CURRENT_FACE_AMOUNT NUMBER(38,0),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,2),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,2),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,2),
	DISTRIBUTED_POLICY_FEES NUMBER(38,2),
	FACTOR_P NUMBER(38,14),
	COVERAGE_NCPI_ITD NUMBER(38,2),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,14),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_COVERAGE_UPDATED VARCHAR(255),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_BENEFICIARY (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_BENEFICIARY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	BENEFICIARY_LEGAL_SUCCESSION VARCHAR(255),
	BENEFICIARY_REVOCABLE VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_TYPE VARCHAR(255),
	BENEFICIARY_RELATIONSHIP_TO_INSURED VARCHAR(255),
	BENEFICIARY_BENEFIT_SHARE_PERCENT NUMBER(38,2),
	constraint PK_SAT_COVERAGE_BENEFICIARY primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_BENEFICIARY_LINK_COVERAGE_BENEFICIARY foreign key (HK_LINK_COVERAGE_BENEFICIARY) references DB_AV_DEV_DWH.RDV_SILO_0.LINK_COVERAGE_BENEFICIARY(HK_LINK_COVERAGE_BENEFICIARY),
	constraint FK_SAT_COVERAGE_BENEFICIARY_HUB_COVERAGE foreign key (DK_HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_INSURED (
	DK_HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	FIRST_NAME VARCHAR(255),
	LAST_NAME VARCHAR(255),
	POSTAL_CODE VARCHAR(255),
	PROVINCE VARCHAR(255),
	COUNTRY VARCHAR(255),
	constraint PK_SAT_COVERAGE_INSURED primary key (DK_HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_INSURED_LINK_COVERAGE_INSURED foreign key (HK_LINK_COVERAGE_INSURED) references DB_AV_DEV_DWH.RDV_SILO_0.LINK_COVERAGE_INSURED(HK_LINK_COVERAGE_INSURED)
);
create or replace TABLE SAT_DEATH_CLAIM (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CLAIM_NUMBER VARCHAR(255),
	CLAIM_STATUS VARCHAR(255),
	DEATH_DATE VARCHAR(255),
	DEATH_TYPE VARCHAR(255),
	CLAIM_SETTLEMENT_TYPE VARCHAR(255),
	constraint PK_SAT_DEATH_CLAIM primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_DEATH_CLAIM_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,2),
	POLICY_ANNUAL_PREMIUM NUMBER(38,2),
	POLICY_MODAL_PREMIUM NUMBER(38,2),
	ANNUAL_POLICY_FEES NUMBER(38,2),
	MODAL_POLICY_FEES NUMBER(38,2),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	CORRESPONDENCE_INDICATOR VARCHAR(5),
	PARTY_TYPE VARCHAR(255),
	AMERICAN_RESIDENT_INDICATOR VARCHAR(255),
	LANGUAGE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER, MD_START_DT),
	constraint FK_SAT_POLICY_OWNER_LINK_POLICY_OWNER foreign key (HK_LINK_POLICY_OWNER) references DB_AV_DEV_DWH.RDV_SILO_0.LINK_POLICY_OWNER(HK_LINK_POLICY_OWNER)
);
create or replace TABLE SAT_POLICY_SERVICING_AGENCY (
	DK_HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'DRIVINGKEY',
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	constraint PK_SAT_POLICY_SERVICING_AGENCY primary key (DK_HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_SERVICING_AGENCY_LINK_POLICY_SERVICING_AGENCY foreign key (HK_LINK_POLICY_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_SILO_0.LINK_POLICY_SERVICING_AGENCY(HK_LINK_POLICY_SERVICING_AGENCY)
);
create or replace TABLE SAT_REINSURANCE_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_COVERAGE_YEAR NUMBER(38,0),
	REINSURANCE_NAAR_FACTOR NUMBER(38,2),
	REINSURANCE_STOPPED_INDICATOR VARCHAR(255),
	REINSURANCE_STOP_DATE VARCHAR(255),
	RETAINED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_FACE_AMOUNT_AT_ACTIVATION NUMBER(38,2),
	REMAINING_FACE_AMOUNT_CEDED_SHARE NUMBER(38,2),
	REINSURANCE_REFERENCE_DATE VARCHAR(255),
	REINSURANCE_EFFECTIVE_DATE VARCHAR(255),
	INITIAL_TERM_DURATION VARCHAR(255),
	constraint PK_SAT_REINSURANCE_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_INSURED (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_ISSUE_AGE VARCHAR(255),
	REINSURANCE_GENDER VARCHAR(255),
	REINSURANCE_TOBACCO_USE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_INSURED primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_GROUP_CODE VARCHAR(255),
	CESSION_MODE VARCHAR(255),
	REINSURANCE_TYPE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY, MD_START_DT),
	constraint FK_SAT_REINSURANCE_TREATY_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	NAME VARCHAR(255),
	constraint PK_SAT_REINSURER primary key (HK_HUB_REINSURER, MD_START_DT),
	constraint FK_SAT_REINSURER_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_SILO_0.HUB_REINSURER(HK_HUB_REINSURER)
);
create or replace TABLE SAT_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURED_FACE_AMOUNT NUMBER(38,2),
	REINSURANCE_NAAR NUMBER(38,2),
	REINSURED_FACE_AMOUNT_SHARE NUMBER(38,2),
	RISK_CESSION_DATE VARCHAR(255),
	REINSURANCE_GROSS_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_GROSS_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM_ADJUSTMENT NUMBER(38,2),
	RISK_CESSION_ADJUSTEMENT_ORIGIN VARCHAR(255),
	constraint PK_SAT_RISK_CESSION primary key (HK_LINK_RISK_CESSION, MD_START_DT),
	constraint FK_SAT_RISK_CESSION_LINK_RISK_CESSION foreign key (HK_LINK_RISK_CESSION) references DB_AV_DEV_DWH.RDV_SILO_0.LINK_RISK_CESSION(HK_LINK_RISK_CESSION)
);
create or replace view VW_INFORMATION_TABLES(
	TABLE_CATALOG,
	TABLE_SCHEMA,
	TABLE_NAME,
	COLUMN_NAME,
	ORDINAL_POSITION,
	DATA_TYPE,
	LENGTH,
	SCALE,
	TABLE_COMMENT,
	COLUMN_COMMENT
) as

SELECT 
T.TABLE_CATALOG, T.TABLE_SCHEMA, T.TABLE_NAME,  
C.COLUMN_NAME, C.ORDINAL_POSITION, 
C.DATA_TYPE, 
COALESCE (C.CHARACTER_MAXIMUM_LENGTH, C.NUMERIC_PRECISION) AS LENGTH,
COALESCE (C.NUMERIC_SCALE, C.DATETIME_PRECISION) AS SCALE,
T.COMMENT AS TABLE_COMMENT, C.COMMENT AS COLUMN_COMMENT
FROM INFORMATION_SCHEMA.TABLES T
INNER JOIN INFORMATION_SCHEMA.COLUMNS C
	ON T.TABLE_CATALOG    = C.TABLE_CATALOG
	AND T.TABLE_SCHEMA    = C.TABLE_SCHEMA
	AND T.TABLE_NAME      = C.TABLE_NAME
WHERE T.TABLE_TYPE = 'BASE TABLE' AND T.TABLE_SCHEMA = 'RDV_SILO_0';
create or replace view VW_SAT_ACTIVITY_LAST_ROW(
	HK_HUB_TRANSACTION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_TRANSACTION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_TRANSACTION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_ACTIVITY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_APPLICATION_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_APPLICATION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COMMISSION_LAST_ROW(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COMMISSIONABLE_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COMMISSIONABLE_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_COMMISSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_BENEFICIARY_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_BENEFICIARY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_BENEFICIARY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
	FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_COVERAGE_BENEFICIARY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_INSURED_LAST_ROW(
	DK_HK_HUB_COVERAGE,
	HK_LINK_COVERAGE_INSURED,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_COVERAGE,
            HK_LINK_COVERAGE_INSURED,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_COVERAGE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_DEATH_CLAIM_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_DEATH_CLAIM
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_OWNER_LAST_ROW(
	HK_LINK_POLICY_OWNER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_POLICY_OWNER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_POLICY_OWNER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_POLICY_OWNER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_SERVICING_AGENCY_LAST_ROW(
	DK_HK_HUB_POLICY,
	HK_LINK_POLICY_SERVICING_AGENCY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DK_HK_HUB_POLICY,
            HK_LINK_POLICY_SERVICING_AGENCY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY DK_HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_POLICY_SERVICING_AGENCY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_REINSURANCE_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_INSURED_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_REINSURANCE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_TREATY_LAST_ROW(
	HK_HUB_REINSURANCE_TREATY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURANCE_TREATY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURANCE_TREATY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_REINSURANCE_TREATY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURER_LAST_ROW(
	HK_HUB_REINSURER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_REINSURER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_RISK_CESSION_LAST_ROW(
	HK_LINK_RISK_CESSION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_RISK_CESSION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_RISK_CESSION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0.SAT_RISK_CESSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
CREATE OR REPLACE FUNCTION "GHOSTVALUE"()
RETURNS VARCHAR(40)
LANGUAGE SQL
AS '
    REPEAT(''0'',40)
';
create or replace schema RDV_SILO_0_DH;

create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	ADVISOR_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	ADVISOR_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_REINSURANCE_TREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURANCE_TREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	REINSURANCE_SUBTREATY_CODE VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURANCE_TREATY primary key (HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE HUB_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	REINSURER_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_REINSURER primary key (HK_HUB_REINSURER)
);
create or replace TABLE HUB_SERVICING_AGENCY (
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	AGENCY_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_SERVICING_AGENCY primary key (HK_HUB_SERVICING_AGENCY)
);
create or replace TABLE HUB_TRANSACTION (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	TRANSACTION_TYPE VARCHAR(255) COMMENT 'BUSINESS KEY',
	CORRELATION_ID VARCHAR(255) COMMENT 'BUSINESS KEY',
	constraint PK_HUB_TRANSACTION primary key (HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_ADVISOR(HK_HUB_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED),
	constraint FK_LINK_COVERAGE_INSURED_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_COVERAGE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_POLICY_COVERAGE),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_POLICY(HK_HUB_POLICY),
	constraint FK_LINK_POLICY_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_CLIENT VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_CLIENT(HK_HUB_CLIENT),
	constraint FK_LINK_POLICY_OWNER_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_SERVICING_AGENCY (
	HK_LINK_POLICY_SERVICING_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_SERVICING_AGENCY VARCHAR(40) NOT NULL,
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_SERVICING_AGENCY primary key (HK_LINK_POLICY_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_SERVICING_AGENCY foreign key (HK_HUB_SERVICING_AGENCY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_SERVICING_AGENCY(HK_HUB_SERVICING_AGENCY),
	constraint FK_LINK_POLICY_SERVICING_AGENCY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_TRANSACTION (
	HK_LINK_POLICY_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_TRANSACTION primary key (HK_LINK_POLICY_TRANSACTION),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_POLICY(HK_HUB_POLICY),
	constraint FK_LINK_POLICY_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE LINK_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION primary key (HK_LINK_RISK_CESSION),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE LINK_RISK_CESSION_TRANSACTION (
	HK_LINK_RISK_CESSION_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL,
	HK_HUB_REINSURER VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_HK_LINK_RISK_CESSION_TRANSACTION primary key (HK_LINK_RISK_CESSION_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_TRANSACTION(HK_HUB_TRANSACTION),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_REINSURER(HK_HUB_REINSURER),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_COVERAGE(HK_HUB_COVERAGE),
	constraint FK_HK_LINK_RISK_CESSION_TRANSACTION_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_ACTIVITY (
	HK_HUB_TRANSACTION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ACTIVITY_EFFECTIVE_DATE VARCHAR(255),
	ACTIVITY_TYPE VARCHAR(255),
	TRANSACTION_NAME VARCHAR(255),
	ACTIVITY_PROCESSED_DATE VARCHAR(255),
	constraint PK_SAT_ACTIVITY primary key (HK_HUB_TRANSACTION, MD_START_DT),
	constraint FK_SAT_ACTIVITY_HUB_TRANSACTION foreign key (HK_HUB_TRANSACTION) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_TRANSACTION(HK_HUB_TRANSACTION)
);
create or replace TABLE SAT_COMMISSION (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COMMISSION_SHARE VARCHAR(255),
	constraint PK_SAT_COMMISSION primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT),
	constraint FK_SAT_COMMISSION_LINK_COMMISSIONABLE_ADVISOR foreign key (HK_LINK_COMMISSIONABLE_ADVISOR) references DB_AV_DEV_DWH.RDV_SILO_0_DH.LINK_COMMISSIONABLE_ADVISOR(HK_LINK_COMMISSIONABLE_ADVISOR)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,5),
	CURRENT_FACE_AMOUNT NUMBER(38,5),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,5),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,5),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,5),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,5),
	DISTRIBUTED_POLICY_FEES NUMBER(38,5),
	FACTOR_P NUMBER(38,19),
	COVERAGE_NCPI_ITD NUMBER(38,5),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,5),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,5),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_INSURED_INFORMATION (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	FIRST_NAME VARCHAR(255),
	LAST_NAME VARCHAR(255),
	constraint PK_SAT_INSURED_INFORMATION primary key (HK_LINK_COVERAGE_INSURED, MD_START_DT),
	constraint FK_SAT_INSURED_INFORMATION_LINK_COVERAGE_INSURED foreign key (HK_LINK_COVERAGE_INSURED) references DB_AV_DEV_DWH.RDV_SILO_0_DH.LINK_COVERAGE_INSURED(HK_LINK_COVERAGE_INSURED)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,5),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,5),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,5),
	POLICY_ANNUAL_PREMIUM NUMBER(38,5),
	POLICY_MODAL_PREMIUM NUMBER(38,5),
	ANNUAL_POLICY_FEES NUMBER(38,5),
	MODAL_POLICY_FEES NUMBER(38,5),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	POLICY_OWNER_CORRESPONDENCE_INDICATOR VARCHAR(5),
	POLICY_PARTY_TYPE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER, MD_START_DT),
	constraint FK_SAT_POLICY_OWNER_LINK_POLICY_OWNER foreign key (HK_LINK_POLICY_OWNER) references DB_AV_DEV_DWH.RDV_SILO_0_DH.LINK_POLICY_OWNER(HK_LINK_POLICY_OWNER)
);
create or replace TABLE SAT_REINSURANCE_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_COVERAGE_YEAR NUMBER(38,0),
	REINSURANCE_STOPPED_INDICATOR VARCHAR(255),
	REINSURANCE_STOP_DATE VARCHAR(255),
	RETAINED_FACE_AMOUNT NUMBER(38,0),
	REINSURANCE_FACE_AMOUNT_AT_ACTIVATION NUMBER(38,0),
	REMAINING_FACE_AMOUNT_CEDED_SHARE NUMBER(38,2),
	REINSURANCE_REFERENCE_DATE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_INSURED (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURANCE_ISSUE_AGE VARCHAR(255),
	REINSURANCE_GENDER VARCHAR(255),
	REINSURANCE_TOBACCO_USE VARCHAR(255),
	REINSURANCE_INSURED_NAME VARCHAR(255),
	constraint PK_SAT_REINSURANCE_INSURED primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_REINSURANCE_INSURED_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_REINSURANCE_SUBTREATY (
	HK_HUB_REINSURANCE_TREATY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_GROUP_CODE VARCHAR(255),
	CESSION_MODE VARCHAR(255),
	REINSURANCE_TYPE VARCHAR(255),
	constraint PK_SAT_REINSURANCE_SUBTREATY primary key (HK_HUB_REINSURANCE_TREATY, MD_START_DT),
	constraint FK_SAT_REINSURANCE_SUBTREATY_HUB_REINSURANCE_TREATY foreign key (HK_HUB_REINSURANCE_TREATY) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_REINSURANCE_TREATY(HK_HUB_REINSURANCE_TREATY)
);
create or replace TABLE SAT_REINSURER (
	HK_HUB_REINSURER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	NAME VARCHAR(255),
	constraint PK_SAT_REINSURER primary key (HK_HUB_REINSURER, MD_START_DT),
	constraint FK_SAT_REINSURER_HUB_REINSURER foreign key (HK_HUB_REINSURER) references DB_AV_DEV_DWH.RDV_SILO_0_DH.HUB_REINSURER(HK_HUB_REINSURER)
);
create or replace TABLE SAT_RISK_CESSION (
	HK_LINK_RISK_CESSION VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	REINSURED_FACE_AMOUNT NUMBER(38,0),
	REINSURANCE_NAAR NUMBER(38,2),
	REINSURED_FACE_AMOUNT_SHARE NUMBER(38,2),
	REINSURANCE_GROSS_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_NET_ANNUAL_PREMIUM NUMBER(38,2),
	REINSURANCE_TAX_ON_ANNUAL_PREMIUM NUMBER(38,2),
	RISK_CESSION_DATE VARCHAR(255),
	constraint PK_SAT_RISK_CESSION primary key (HK_LINK_RISK_CESSION, MD_START_DT),
	constraint FK_SAT_RISK_CESSION_LINK_RISK_CESSION foreign key (HK_LINK_RISK_CESSION) references DB_AV_DEV_DWH.RDV_SILO_0_DH.LINK_RISK_CESSION(HK_LINK_RISK_CESSION)
);
create or replace view VW_SAT_ACTIVITY_LAST_ROW(
	HK_HUB_TRANSACTION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_TRANSACTION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_TRANSACTION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_ACTIVITY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COMMISSION_LAST_ROW(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COMMISSIONABLE_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COMMISSIONABLE_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_COMMISSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_INSURED_INFORMATION_LAST_ROW(
	HK_LINK_COVERAGE_INSURED,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COVERAGE_INSURED,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COVERAGE_INSURED ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_INSURED_INFORMATION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_OWNER_LAST_ROW(
	HK_LINK_POLICY_OWNER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_POLICY_OWNER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_POLICY_OWNER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_POLICY_OWNER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_REINSURANCE_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_INSURED_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_REINSURANCE_INSURED
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURANCE_SUBTREATY_LAST_ROW(
	HK_HUB_REINSURANCE_TREATY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURANCE_TREATY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURANCE_TREATY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_REINSURANCE_SUBTREATY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REINSURER_LAST_ROW(
	HK_HUB_REINSURER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REINSURER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REINSURER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_REINSURER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_RISK_CESSION_LAST_ROW(
	HK_LINK_RISK_CESSION,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_RISK_CESSION,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_RISK_CESSION ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_AV_DEV_DWH.RDV_SILO_0_DH.SAT_RISK_CESSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
CREATE OR REPLACE FUNCTION "GHOSTVALUE"()
RETURNS VARCHAR(40)
LANGUAGE SQL
AS '
    REPEAT(''0'',40)
';
create or replace schema RDV_UT;

create or replace TABLE HUB_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	ADVISOR_CODE VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_ADVISOR primary key (HK_HUB_ADVISOR)
);
create or replace TABLE HUB_AGENCY (
	HK_HUB_AGENCY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	AGENCY_NUMBER VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_AGENCY primary key (HK_HUB_AGENCY)
);
create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_PRODUCT (
	HK_HUB_PRODUCT VARCHAR(255) NOT NULL,
	PRODUCT_VERSION_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	RATES_REFERENCE_DATE VARCHAR(255),
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	constraint PK_HUB_PRODUCT primary key (HK_HUB_PRODUCT)
);
create or replace TABLE HUB_REF_DOMAINE_VALEUR (
	HK_HUB_REF_DOMAINE_VALEUR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	DOMAINE_VALEUR_CD VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	ELEMENT_VALEUR_CD VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_REF_DOMAINE_VALEUR primary key (HK_HUB_REF_DOMAINE_VALEUR)
);
create or replace TABLE HUB_SERVICE_UNIT (
	HK_HUB_SERVICE_UNIT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	SERVICE_UNIT_NUMBER VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_SERVICE_UNIT primary key (HK_HUB_SERVICE_UNIT)
);
create or replace TABLE LINK_AGENCY_POLICY (
	HK_LINK_AGENCY_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_AGENCY VARCHAR(40),
	HK_HUB_POLICY VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_AGENCY_POLICY primary key (HK_LINK_AGENCY_POLICY),
	constraint FK_LINK_AGENCY_POLICY_HUB_AGENCY foreign key (HK_HUB_AGENCY) references DB_AV_DEV_DWH.RDV_UT.HUB_AGENCY(HK_HUB_AGENCY)
);
create or replace TABLE LINK_AGENCY_SERVICE_UNIT (
	HK_LINK_AGENCY_SERVICE_UNIT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_AGENCY VARCHAR(40),
	HK_HUB_SERVICE_UNIT VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_AGENCY_SERVICE_UNIT primary key (HK_LINK_AGENCY_SERVICE_UNIT),
	constraint FK_LINK_AGENCY_SERVICE_UNIT_HUB_AGENCY foreign key (HK_HUB_AGENCY) references DB_AV_DEV_DWH.RDV_UT.HUB_AGENCY(HK_HUB_AGENCY),
	constraint FK_LINK_AGENCY_SERVICE_UNIT_HUB_SERVICE_UNIT foreign key (HK_HUB_SERVICE_UNIT) references DB_AV_DEV_DWH.RDV_UT.HUB_SERVICE_UNIT(HK_HUB_SERVICE_UNIT)
);
create or replace TABLE LINK_COMMISSIONABLE_ADVISOR (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_ADVISOR VARCHAR(40),
	HK_HUB_COVERAGE VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_COMMISSIONABLE_ADVISOR primary key (HK_LINK_COMMISSIONABLE_ADVISOR),
	constraint FK_LINK_COMMISSIONABLE_AGENT_HUB_ADVISOR foreign key (HK_HUB_ADVISOR) references DB_AV_DEV_DWH.RDV_UT.HUB_ADVISOR(HK_HUB_ADVISOR)
);
create or replace TABLE LINK_COVERAGE_INSURED (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_COVERAGE VARCHAR(40),
	HK_HUB_CLIENT VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_COVERAGE_INSURED primary key (HK_LINK_COVERAGE_INSURED),
	constraint FK_LINK_COVERAGE_INSURED_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_UT.HUB_CLIENT(HK_HUB_CLIENT)
);
create or replace TABLE LINK_COVERAGE_POLICY (
	HK_LINK_COVERAGE_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40),
	HK_HUB_COVERAGE VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_COVERAGE_POLICY),
	constraint FK_LINK_POLICY_COVERAGE_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_UT.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE LINK_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40),
	HK_HUB_CLIENT VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER),
	constraint FK_LINK_POLICY_OWNER_HUB_CLIENT foreign key (HK_HUB_CLIENT) references DB_AV_DEV_DWH.RDV_UT.HUB_CLIENT(HK_HUB_CLIENT)
);
create or replace TABLE LINK_PRODUCT_COVERAGE (
	HK_LINK_PRODUCT_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_PRODUCT VARCHAR(40),
	HK_HUB_COVERAGE VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_LINK_PRODUCT_COVERAGE primary key (HK_LINK_PRODUCT_COVERAGE)
);
create or replace TABLE SAT_ADVISOR (
	HK_HUB_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	ADVISOR_TYPE VARCHAR(255),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_SAT_ADVISOR primary key (HK_HUB_ADVISOR, MD_START_DT)
);
create or replace TABLE SAT_COMMISSION (
	HK_LINK_COMMISSIONABLE_ADVISOR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	COMMISSION_SHARE VARCHAR(255),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_SAT_COMMISSION primary key (HK_LINK_COMMISSIONABLE_ADVISOR, MD_START_DT)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX VARCHAR(255),
	BASE_COVERAGE VARCHAR(255),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,5),
	CURRENT_FACE_AMOUNT NUMBER(38,5),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,5),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,5),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,5),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,5),
	DISTRIBUTED_POLICY_FEES NUMBER(38,5),
	FACTOR_P NUMBER(38,19),
	COVERAGE_NCPI_ITD NUMBER(30,5),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,5),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(30,5),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_UT.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_BACK_UP_SELMANE (
	HK_HUB_COVERAGE VARCHAR(40),
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX VARCHAR(255),
	BASE_COVERAGE VARCHAR(255),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,5),
	CURRENT_FACE_AMOUNT NUMBER(38,5),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,5),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,5),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,5),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,5),
	DISTRIBUTED_POLICY_FEES NUMBER(38,5),
	FACTOR_P NUMBER(38,19),
	COVERAGE_NCPI_ITD NUMBER(30,5),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,5),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(30,5),
	MD_IS_ACTIVE NUMBER(2,0),
	MD_HASHDIFF VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(250),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_USER VARCHAR(255)
);
create or replace TABLE SAT_INSURED_INFORMATION (
	HK_LINK_COVERAGE_INSURED VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	ISSUE_AGE VARCHAR(255),
	TOBACCO_USE VARCHAR(255),
	UNDERWRITING_GENDER VARCHAR(255),
	CURRENT_UNDERWRITING_AGE VARCHAR(255),
	CURRENT_UNDERWRITING_TOBACCO_USE VARCHAR(255),
	DATE_OF_BIRTH VARCHAR(255),
	constraint PK_SAT_INSURED_INFORMATION primary key (HK_LINK_COVERAGE_INSURED, MD_START_DT)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_EVENT_TYPE VARCHAR(255),
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENTMETHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,5),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,5),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,5),
	POLICY_ANNUAL_PREMIUM NUMBER(38,5),
	POLICY_MODAL_PREMIUM NUMBER(38,5),
	ANNUAL_POLICY_FEES NUMBER(38,5),
	MODAL_POLICY_FEES NUMBER(38,5),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT),
	constraint FK_SAT_POLICY_HUB_POLICY foreign key (HK_HUB_POLICY) references DB_AV_DEV_DWH.RDV_UT.HUB_POLICY(HK_HUB_POLICY)
);
create or replace TABLE SAT_POLICY_CLEAN (
	HK_HUB_COVERAGE VARCHAR(40),
	COVERAGE_CODE VARCHAR(50),
	COVERAGE_VERSION_CODE VARCHAR(50),
	COVERAGE_TYPE VARCHAR(2),
	COVERAGE_YEAR NUMBER(4,0),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(4),
	COVERAGE_EFFECTIVE_DATE DATE,
	LAST_RENEWAL_DATE DATE,
	NEXT_RENEWAL_DATE DATE,
	COVERAGE_TERMINATE_DATE DATE,
	EXPIRY_DATE DATE,
	MATURITY_DATE DATE,
	COVERAGE_STATUS VARCHAR(2),
	COVERAGE_SUB_STATUS VARCHAR(2),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(2),
	TAXATION_TOBACCO_USE VARCHAR(2),
	INITIAL_TERME_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(19,2),
	CURRENT_FACE_AMOUNT NUMBER(19,2),
	COVERAGE_ANNUAL_PREMIUM NUMBER(19,2),
	RATES_REFERENCE_DATE DATE,
	COVERAGE_MODAL_PREMIUM NUMBER(19,2),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(19,2),
	PAID_UP_DATE DATE,
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(19,2),
	DISTRIBUTED_POLICY_FEES NUMBER(19,2),
	FACTOR_P NUMBER(19,19),
	COVERAGE_NCPI_ITD NUMBER(19,2),
	COVERAGE_TAXATION_DURATION NUMBER(4,0),
	COVERAGE_NPR_FACTOR NUMBER(19,2),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(19,2),
	HK_HUB_POLICY VARCHAR(40),
	POLICY_EVENT_TYPE VARCHAR(100),
	PRODUCT_CODE VARCHAR(50),
	PRODUCT_VERSION_CODE VARCHAR(50),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(4),
	ISSUE_STATE VARCHAR(4),
	POLICY_EFFECTIVE_DATE DATE,
	LAST_REINSTATEMENT_DATE DATE,
	POLICY_STATUS VARCHAR(2),
	POLICY_SUB_STATUS VARCHAR(2),
	PAYEMENT_FREQUENCY VARCHAR(2),
	NEXT_PREMIUM_DUE_DATE DATE,
	PAYMENT_METHOD VARCHAR(2),
	BILLING_STATUS VARCHAR(2),
	PAID_TO_DATE DATE,
	BILLING_SUSPENSION_REASON VARCHAR(255),
	BILLING_SUSPENSION_REQUESTOR VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE DATE,
	POLICY_ACB NUMBER(19,2),
	POLICY_ACB_MODAL_PREMIUM NUMBER(19,2),
	POLICY_ACB_PREMIUM_ITD NUMBER(19,2),
	POLICY_ANNUAL_PREMIUM NUMBER(19,2),
	POLICY_MODAL_PREMIUM NUMBER(19,2),
	ANNUAL_POLICY_FEES NUMBER(19,2),
	MODAL_POLICY_FEES NUMBER(19,2),
	MD_IS_ACTIVE NUMBER(1,0),
	MD_HASHDIFF VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_USER VARCHAR(255)
);
create or replace TABLE SAT_POLICY_OWNER (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_OWNER_CORRESPONDANCE_INDICATOR VARCHAR(255),
	POLICY_PARTY_TYPE VARCHAR(255),
	constraint PK_SAT_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER, MD_START_DT)
);
create or replace TABLE SAT_POLICY_OWNER_IS_ACTIVE (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	IND_IS_ACTIVE NUMBER(1,0),
	constraint PK_SAT_POLICY_OWNER_IS_ACTIV primary key (HK_LINK_POLICY_OWNER, MD_START_DT)
);
create or replace TABLE SAT_REF_DOMAINE_VALEUR (
	HK_HUB_REF_DOMAINE_VALEUR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	DESCRIPTION_FR VARCHAR(255),
	DESCRIPTION_EN VARCHAR(255),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL COMMENT 'COLUMN INDICATING IF THE OCCURRENCE IS ACTIVE OR INACTIVE',
	MD_HASHDIFF VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_REF_DOMAINE_VALEUR primary key (HK_HUB_REF_DOMAINE_VALEUR, MD_START_DT),
	constraint FK_SAT_REF_DOMAINE_VALEUR_HUB_REF_DOMAINE_VALEUR foreign key (HK_HUB_REF_DOMAINE_VALEUR) references DB_AV_DEV_DWH.RDV_UT.HUB_REF_DOMAINE_VALEUR(HK_HUB_REF_DOMAINE_VALEUR)
);
create or replace TABLE TMP_HUB_PRODUCT (
	ID_CORRESPONDANCE_CODE_PLAN VARCHAR(255),
	PDF_PLAN_NAME VARCHAR(255),
	PDF_VERSION_DATE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	RATES_REFERENCE_DATE VARCHAR(255),
	CODE_CIE VARCHAR(255),
	CODE_CATEGORIE VARCHAR(255)
);
create or replace TABLE TMP_HUB_PRODUCT_1 (
	HK_HUB_PRODUCT VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	RATES_REFERENCE_DATE VARCHAR(255),
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE'
);
create or replace view VW_SAT_ADVISOR_LAST_ROW(
	HK_HUB_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM SAT_ADVISOR
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COMMISSION_LAST_ROW(
	HK_LINK_COMMISSIONABLE_ADVISOR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_COMMISSIONABLE_ADVISOR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_COMMISSIONABLE_ADVISOR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM SAT_COMMISSION
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM RDV.SAT_COVERAGE
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM RDV.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_OWNER_LAST_ROW(
	HK_LINK_POLICY_OWNER,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_LINK_POLICY_OWNER,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_LINK_POLICY_OWNER ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM RDV.SAT_POLICY_OWNER
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
CREATE OR REPLACE FUNCTION "GHOSTVALUE"()
RETURNS VARCHAR(40)
LANGUAGE SQL
AS '
    REPEAT(''0'',40)';
create or replace schema RDV_V0;

create or replace TABLE HUB_CLIENT (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_CLIENT_TEST (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	PARTY_ID VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_CLIENT primary key (HK_HUB_CLIENT)
);
create or replace TABLE HUB_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID VARCHAR(255) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_COVERAGE_TEST (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	COVERAGE_IDENTIFIER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_COVERAGE primary key (HK_HUB_COVERAGE)
);
create or replace TABLE HUB_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_DT VARCHAR(255) COMMENT 'CREATION DATE',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_POLICY_TEST (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	POLICY_NUMBER VARCHAR(255) NOT NULL COMMENT 'BUSINESS KEY',
	constraint PK_HUB_POLICY primary key (HK_HUB_POLICY)
);
create or replace TABLE HUB_PRODUCT (
	HK_HUB_PRODUCT VARCHAR(40) NOT NULL,
	PRODUCT_VERSION_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	RATES_REFERENCE_DATE VARCHAR(255),
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT VARCHAR(255),
	constraint PK_HUB_PRODUCT primary key (HK_HUB_PRODUCT)
);
create or replace TABLE HUB_PRODUCT_CSV (
	HK_HUB_PRODUCT_TGT VARCHAR(3000),
	PRODUCT_VERSION_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	RATES_REFERENCE_DATE VARCHAR(255),
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT VARCHAR(255)
);
create or replace TABLE HUB_REF_DOMAINE_VALEUR (
	HK_HUB_REF_DOMAINE_VALEUR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	DOMAINE_VALEUR_CD VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	ELEMENT_VALEUR_CD VARCHAR(255) NOT NULL COMMENT 'NATURAL KEY',
	MD_SOURCE VARCHAR(255) COMMENT 'SOURCE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_HUB_REF_DOMAINE_VALEUR primary key (HK_HUB_REF_DOMAINE_VALEUR)
);
create or replace TABLE LINK_COVERAGE_POLICY_TEST (
	HK_LINK_COVERAGE_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40) NOT NULL,
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL,
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	constraint PK_LINK_POLICY_COVERAGE primary key (HK_LINK_COVERAGE_POLICY)
);
create or replace TABLE LINK_POLICY_COVERAGE (
	HK_LINK_POLICY_OWNER VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_POLICY VARCHAR(40),
	HK_HUB_COVERAGE VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_LINK_POLICY_OWNER primary key (HK_LINK_POLICY_OWNER)
);
create or replace TABLE LINK_PRODUCT_COVERAGE (
	HK_LINK_PRODUCT_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	HK_HUB_PRODUCT VARCHAR(40),
	HK_HUB_COVERAGE VARCHAR(40),
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	constraint PK_LINK_PRODUCT_COVERAGE primary key (HK_LINK_PRODUCT_COVERAGE),
	constraint FK_LINK_PRODUCT_COVERAGE_HUB_PRODUCT foreign key (HK_HUB_PRODUCT) references DB_AV_DEV_DWH.RDV_V0.HUB_PRODUCT(HK_HUB_PRODUCT)
);
create or replace TABLE SAT_CLIENT_ADDRESS (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	REGION_CODE VARCHAR(255),
	COUNTRY_CODE VARCHAR(255),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_CLIENT_ADDRESS primary key (HK_HUB_CLIENT, MD_START_DT)
);
create or replace TABLE SAT_CLIENT_INFORMATION (
	HK_HUB_CLIENT VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	CLIENT_DATE_OF_BIRTH VARCHAR(255),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_CLIENT_INFORMATION primary key (HK_HUB_CLIENT, MD_START_DT)
);
create or replace TABLE SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX VARCHAR(255),
	BASE_COVERAGE VARCHAR(255),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATE_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERME_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,5),
	CURRENT_FACE_AMOUNT NUMBER(38,5),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,5),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,5),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,5),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,5),
	DISTRIBUTED_POLICY_FEES NUMBER(38,5),
	FACTOR_P NUMBER(38,19),
	COVERAGE_NCPI_ITD NUMBER(30,5),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,5),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(30,5),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT VARCHAR(250) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT),
	constraint FK_SAT_COVERAGE_HUB_COVERAGE foreign key (HK_HUB_COVERAGE) references DB_AV_DEV_DWH.RDV_V0.HUB_COVERAGE(HK_HUB_COVERAGE)
);
create or replace TABLE SAT_COVERAGE_TEST (
	HK_HUB_COVERAGE VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX NUMBER(2,0),
	BASE_COVERAGE VARCHAR(5),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATION_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERM_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,5),
	CURRENT_FACE_AMOUNT NUMBER(38,5),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,5),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,5),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,5),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,5),
	DISTRIBUTED_POLICY_FEES NUMBER(38,5),
	FACTOR_P NUMBER(38,19),
	COVERAGE_NCPI_ITD NUMBER(38,5),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,5),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(38,5),
	constraint PK_SAT_COVERAGE primary key (HK_HUB_COVERAGE, MD_START_DT)
);
create or replace TABLE SAT_POLICY (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	POLICY_EVENT_TYPE VARCHAR(255),
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYEMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENTMETHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,5),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,5),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,5),
	POLICY_ANNUAL_PREMIUM NUMBER(38,5),
	POLICY_MODAL_PREMIUM NUMBER(38,5),
	ANNUAL_POLICY_FEES NUMBER(38,5),
	MODAL_POLICY_FEES NUMBER(38,5),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT)
);
create or replace TABLE SAT_POLICY_TEST (
	HK_HUB_POLICY VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_SOURCE VARCHAR(255) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'CREATION DATE',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_IS_ACTIVE NUMBER(1,0) NOT NULL,
	MD_HASHDIFF VARCHAR(40) NOT NULL,
	POLICY_EVENT_TYPE VARCHAR(255),
	PRODUCT_CODE VARCHAR(255),
	PRODUCT_VERSION_CODE VARCHAR(255),
	POLICY_OWNER_RESIDENCE_STATE VARCHAR(255),
	POLICY_YEAR NUMBER(4,0),
	POLICY_CURRENCY VARCHAR(255),
	ISSUE_STATE VARCHAR(255),
	POLICY_EFFECTIVE_DATE VARCHAR(255),
	LAST_REINSTATEMENT_DATE VARCHAR(255),
	POLICY_STATUS VARCHAR(255),
	POLICY_SUB_STATUS VARCHAR(255),
	PAYMENT_FREQUENCY VARCHAR(255),
	NEXT_PREMIUM_DUE_DATE VARCHAR(255),
	PAYMENT_METHOD VARCHAR(255),
	BILLING_STATUS VARCHAR(255),
	PAID_TO_DATE VARCHAR(255),
	BILLING_INTERRUPTION_REASON VARCHAR(255),
	ANTICIPATE_BILLING_RESUME_DATE VARCHAR(255),
	POLICY_ACB NUMBER(38,5),
	POLICY_ACB_MODAL_PREMIUM NUMBER(38,5),
	POLICY_ACB_PREMIUM_ITD NUMBER(38,5),
	POLICY_ANNUAL_PREMIUM NUMBER(38,5),
	POLICY_MODAL_PREMIUM NUMBER(38,5),
	ANNUAL_POLICY_FEES NUMBER(38,5),
	MODAL_POLICY_FEES NUMBER(38,5),
	constraint PK_SAT_POLICY primary key (HK_HUB_POLICY, MD_START_DT)
);
create or replace TABLE SAT_PRODUCT (
	MD_CREATION_DT VARCHAR(255),
	MD_SOURCE VARCHAR(255),
	MD_START_DT VARCHAR(255),
	MD_IS_ACTIVE VARCHAR(255),
	MD_HASHDIFF VARCHAR(255),
	HK_HUB_PRODUCT VARCHAR(255),
	PDF_PLAN_NAME VARCHAR(255),
	PDF_VERSION_DATE VARCHAR(255),
	CODE_CIE VARCHAR(255),
	CODE_CATEGORIE VARCHAR(255)
);
create or replace TABLE SAT_REF_DOMAINE_VALEUR (
	HK_HUB_REF_DOMAINE_VALEUR VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	DESCRIPTION_FR VARCHAR(255),
	DESCRIPTION_EN VARCHAR(255),
	MD_IS_ACTIVE NUMBER(2,0) NOT NULL COMMENT 'COLUMN INDICATING IF THE OCCURRENCE IS ACTIVE OR INACTIVE',
	MD_HASHDIFF VARCHAR(40) NOT NULL COMMENT 'HASHKEY',
	MD_START_DT TIMESTAMP_NTZ(9) NOT NULL COMMENT 'START DATE',
	MD_SOURCE VARCHAR(250) NOT NULL COMMENT 'SOURCE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'CREATION DATE',
	MD_CREATION_AUDIT_ID NUMBER(38,0) COMMENT 'CREATION AUDIT ID',
	MD_USER VARCHAR(255) COMMENT 'EVENT USER CODE',
	constraint PK_SAT_REF_DOMAINE_VALEUR primary key (HK_HUB_REF_DOMAINE_VALEUR, MD_START_DT),
	constraint FK_SAT_REF_DOMAINE_VALEUR_HUB_REF_DOMAINE_VALEUR foreign key (HK_HUB_REF_DOMAINE_VALEUR) references DB_AV_DEV_DWH.RDV_V0.HUB_REF_DOMAINE_VALEUR(HK_HUB_REF_DOMAINE_VALEUR)
);
create or replace TABLE TEST_HUB_AGENCY_TEST_IB (
	HK_HUB_AGENCY VARCHAR(40),
	AGENCY_NUMBER VARCHAR(255),
	MD_SOURCE VARCHAR(255),
	MD_CREATION_DT VARCHAR(255)
);
create or replace TABLE TEST_SAT_COVERAGE (
	HK_HUB_COVERAGE VARCHAR(40),
	COVERAGE_CODE VARCHAR(255),
	COVERAGE_VERSION_CODE VARCHAR(255),
	COVERAGE_TYPE VARCHAR(255),
	COVERAGE_YEAR VARCHAR(255),
	COVERAGE_INDEX VARCHAR(255),
	BASE_COVERAGE VARCHAR(255),
	COVERAGE_EFFECTIVE_DATE VARCHAR(255),
	LAST_RENEWAL_DATE VARCHAR(255),
	NEXT_RENEWAL_DATE VARCHAR(255),
	COVERAGE_TERMINATE_DATE VARCHAR(255),
	EXPIRY_DATE VARCHAR(255),
	MATURITY_DATE VARCHAR(255),
	COVERAGE_STATUS VARCHAR(255),
	COVERAGE_SUB_STATUS VARCHAR(255),
	TAXATION_AGE NUMBER(3,0),
	TAXATION_GENDER VARCHAR(255),
	TAXATION_TOBACCO_USE VARCHAR(255),
	INITIAL_TERME_DURATION NUMBER(3,0),
	INITIAL_FACE_AMOUNT NUMBER(38,5),
	CURRENT_FACE_AMOUNT NUMBER(38,5),
	COVERAGE_ANNUAL_PREMIUM NUMBER(38,5),
	RATES_REFERENCE_DATE VARCHAR(255),
	COVERAGE_MODAL_PREMIUM NUMBER(38,5),
	COVERAGE_ANNUAL_BASIC_PREMIUM NUMBER(38,5),
	PAID_UP_DATE VARCHAR(255),
	COMMISSIONABLE_ANNUAL_PREMIUM NUMBER(38,5),
	DISTRIBUTED_POLICY_FEES NUMBER(38,5),
	FACTOR_P NUMBER(38,19),
	COVERAGE_NCPI_ITD NUMBER(30,5),
	COVERAGE_TAXATION_DURATION NUMBER(38,0),
	COVERAGE_NPR_FACTOR NUMBER(38,5),
	COVERAGE_ACB_MODAL_PREMIUM NUMBER(30,5),
	MD_IS_ACTIVE NUMBER(2,0),
	MD_HASHDIFF VARCHAR(40),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(250),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	MD_USER VARCHAR(255)
);
create or replace view VW_SAT_COVERAGE_LAST_ROW(
	HK_HUB_COVERAGE,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  DISTINCT HK_HUB_COVERAGE,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_COVERAGE ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM "DB_AV_DEV_DWH"."RDV_V0"."SAT_COVERAGE"
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_POLICY_LAST_ROW(
	HK_HUB_POLICY,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_POLICY,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_POLICY ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM RDV_V0.SAT_POLICY
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_PRODUCT_LAST_ROW(
	HK_HUB_PRODUCT,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_PRODUCT,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_PRODUCT ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM RDV_V0.SAT_PRODUCT
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;
create or replace view VW_SAT_REF_DOMAINE_VALEUR_LAST_ROW(
	HK_HUB_REF_DOMAINE_VALEUR,
	MD_HASHDIFF,
	MD_START_DT,
	IND_LAST_ROW
) as
WITH LAST_ROW AS (
    SELECT  HK_HUB_REF_DOMAINE_VALEUR,
            MD_HASHDIFF,
            MD_START_DT,
            IFF(ROW_NUMBER() OVER (PARTITION BY HK_HUB_REF_DOMAINE_VALEUR ORDER BY MD_START_DT DESC) = 1,1,0) IND_LAST_ROW
    FROM RDV_v0.SAT_REF_DOMAINE_VALEUR
)
SELECT *
FROM LAST_ROW
WHERE IND_LAST_ROW = 1;