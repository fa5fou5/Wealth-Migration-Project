create or replace database DB_AC_DEV_DM;

create or replace schema ACCESS_LOG;

create or replace schema ENROLLMENT;

create or replace TABLE FACT_PLATFORM_ENROLLMENT (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the Fact',
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Security Type ',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	OPEN_SHOPPING_PERIOD_ID NUMBER(38,0) COMMENT 'Open Shopping Period Id from platform',
	EMPLOYEE_ID NUMBER(38,0) COMMENT 'Dimension Employee id ',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Organization id from platform',
	CAMPAIGN_ID NUMBER(38,0) COMMENT 'Dimension Campaign id',
	foreign key (EMPLOYEE_ID) references DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE(ID),
	foreign key (CAMPAIGN_ID) references DB_AC_DEV_DM.SHARED.DIM_CAMPAIGN(ID)
);
create or replace TABLE FACT_PLATFORM_ENROLLMENT_TEST (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the Fact',
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Security Type ',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	OPEN_SHOPPING_PERIOD_ID NUMBER(38,0) COMMENT 'Open Shopping Period Id from platform',
	EMPLOYEE_ID NUMBER(38,0) COMMENT 'Dimension Employee id ',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Organization id from platform',
	CAMPAIGN_ID NUMBER(38,0) COMMENT 'Dimension Campaign id',
	foreign key (EMPLOYEE_ID) references DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE(ID),
	foreign key (CAMPAIGN_ID) references DB_AC_DEV_DM.SHARED.DIM_CAMPAIGN(ID)
);
CREATE OR REPLACE PROCEDURE "LOADDM_SHARED_RDV_TO_DM_ENROLLMENT_FACT_ENROLLMENT"("ENV" VARCHAR(16777216), "SECURITY_TYPE" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =   "INSERT INTO DB_AC_DEV_DM.ENROLLMENT.FACT_PLATFORM_ENROLLMENT(HK_LINK	, " +	
"MD_START_DT,	" +
"MD_CREATION_DT	,	" +
"MD_CREATION_AUDIT_ID	,	" +
"MD_SECURITY_TYPE,	" +
"MD_SOURCE	," +
"OPEN_SHOPPING_PERIOD_ID	,	" +
"EMPLOYEE_ID	," +
"ORGANIZATION_ID	,	" +
"CAMPAIGN_ID	) " +
"WITH T1 AS (select hK_HUB_CAMPAIGN,DTLS.ID AS EMP_ID,HK_LINK,MSTR.MD_CREATION_DT AS MD_CREATION_DT,MSTR.MD_SOURCE MD_SOURCE,OPEN_SHOPPING_PERIOD_ID,ORGANIZATION_ID " +
 "     from DB_AC_DEV_DWH.ENROLLMENT_RDV.VW_SAT_LINK_ENROLLMENT MSTR JOIN DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE AS DTLS ON HK_HUB = HK_HUB_WORKER WHERE MSTR.MD_CREATION_DT<=SYSDATE()) " +
"SELECT HK_LINK, MSTR.MD_CREATION_DT,SYSTIMESTAMP(), " +
"''" + AUDIT_ID +"''," +
"''" + SECURITY_TYPE +"'',"+
"MSTR.MD_SOURCE,OPEN_SHOPPING_PERIOD_ID, " +
"EMP_ID,MSTR.ORGANIZATION_ID,ID " +
"FROM T1 MSTR JOIN DB_AC_DEV_DM.SHARED.DIM_CAMPAIGN AS DTLS ON HK_HUB = HK_HUB_CAMPAIGN";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_ENROLLMENT_FACT_ENROLLMENT"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "insert into DB_AC_"+ENV+"_DM.ENROLLMENT.FACT_PLATFORM_ENROLLMENT (ID,HK_LINK,MD_START_DT,MD_CREATION_DT,MD_CREATION_AUDIT_ID,MD_SECURITY_TYPE,MD_SOURCE,OPEN_SHOPPING_PERIOD_ID,EMPLOYEE_ID,ORGANIZATION_ID,CAMPAIGN_ID)  \\n \\
(SELECT Emp.ID ID,Link.HK_LINK HK_LINK," + "''" + io_DATA_START_DATE + "''" + " as o_MD_START_DT,"  + "''" + SESSSTARTTIME + "''" + " as MD_CREATION_DT,"  + "''" + i_Job_Audit_Id + "''" + " as o_MD_CREATION_AUDIT_ID,"  + "''" + i_Security_Type + "''" + " as o_MD_SECURITY_TYPE,Emp.MD_SOURCE MD_SOURCE,Link.OPEN_SHOPPING_PERIOD_ID OPEN_SHOPPING_PERIOD_ID,NULL AS EMPLOYEE_ID,Link.ORGANIZATION_ID ORGANIZATION_ID,Link.CAMPAIGN_ID CAMPAIGN_ID \\n \\
FROM DB_AC_"+ENV+"_DWH.ENROLLMENT_RDV.VW_SAT_LINK_ENROLLMENT Link \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.SHARED.DIM_EMPLOYEE Emp ON Link.HK_HUB_WORKER=Emp.HK_HUB \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.SHARED.DIM_CAMPAIGN Camp ON Link.HK_HUB_CAMPAIGN=Camp.HK_HUB \\n \\
 WHERE Link.MD_CREATION_DT<=currenttimestamp)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_ENROLLMENT_FACT_ENROLLMENT"("ENV" VARCHAR(1000), "I_JOB_AUDIT_ID" VARCHAR(1000), "I_SECURITY_TYPE" VARCHAR(1000), "IO_DATA_START_DATE" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "insert into DB_AC_"+ENV+"_DM.ENROLLMENT.FACT_PLATFORM_ENROLLMENT (ID,HK_LINK,MD_START_DT,MD_CREATION_DT,MD_CREATION_AUDIT_ID,MD_SECURITY_TYPE,MD_SOURCE,OPEN_SHOPPING_PERIOD_ID,EMPLOYEE_ID,ORGANIZATION_ID,CAMPAIGN_ID)  \\n \\
(SELECT Emp.ID ID,\\n \\
Link.HK_LINK HK_LINK,\\n \\
Emp.MD_START_DT MD_START_DT,\\n \\
" + "''" + SESSSTARTTIME + "''" + " as MD_CREATION_DT,\\n \\
Link.MD_CREATION_DT MD_CREATION_DT,\\n \\
Emp.MD_SECURITY_TYPE MD_SECURITY_TYPE,\\n \\
Emp.MD_SOURCE MD_SOURCE,\\n \\
Link.OPEN_SHOPPING_PERIOD_ID OPEN_SHOPPING_PERIOD_ID,\\n \\
NULL AS EMPLOYEE_ID,\\n \\
Link.ORGANIZATION_ID ORGANIZATION_ID,\\n \\
Link.CAMPAIGN_ID CAMPAIGN_ID \\n \\
FROM DB_AC_"+ENV+"_DWH.ENROLLMENT_RDV.VW_SAT_LINK_ENROLLMENT Link \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.SHARED.DIM_EMPLOYEE Emp ON Link.HK_HUB_WORKER=Emp.HK_HUB \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.SHARED.DIM_CAMPAIGN Camp ON Link.HK_HUB_CAMPAIGN=Camp.HK_HUB \\n \\
 WHERE Link.MD_CREATION_DT<=currenttimestamp)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_ENROLLMENT_FACT_ENROLLMENT"("ENV" VARCHAR(16777216), "SECURITY_TYPE" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =   "INSERT INTO DB_AC_DEV_DM.ENROLLMENT.FACT_PLATFORM_ENROLLMENT(HK_LINK	, " +	
"MD_START_DT,	" +
"MD_CREATION_DT	,	" +
"MD_CREATION_AUDIT_ID	,	" +
"MD_SECURITY_TYPE,	" +
"MD_SOURCE	," +
"OPEN_SHOPPING_PERIOD_ID	,	" +
"EMPLOYEE_ID	," +
"ORGANIZATION_ID	,	" +
"CAMPAIGN_ID	) " +
"WITH T1 AS (select hK_HUB_CAMPAIGN,DTLS.ID AS EMP_ID,HK_LINK,MSTR.MD_CREATION_DT AS MD_CREATION_DT,MSTR.MD_SOURCE MD_SOURCE,OPEN_SHOPPING_PERIOD_ID,ORGANIZATION_ID " +
 "     from DB_AC_DEV_DWH.ENROLLMENT_RDV.VW_SAT_LINK_ENROLLMENT MSTR JOIN DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE AS DTLS ON HK_HUB = HK_HUB_WORKER WHERE MSTR.MD_CREATION_DT<=SYSDATE()) " +
"SELECT HK_LINK, MSTR.MD_CREATION_DT,SYSTIMESTAMP(), " +
"''" + AUDIT_ID +"''," +
"''" + SECURITY_TYPE +"'',"+
"MSTR.MD_SOURCE,OPEN_SHOPPING_PERIOD_ID, " +
"EMP_ID,MSTR.ORGANIZATION_ID,ID " +
"FROM T1 MSTR JOIN DB_AC_DEV_DM.SHARED.DIM_CAMPAIGN AS DTLS ON HK_HUB = HK_HUB_CAMPAIGN";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_ENROLLMENT_FACT_ENROLLMENT"("ENV" VARCHAR(1000), "SESSSTARTTIME" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "insert into DB_AC_"+ENV+"_DM.ENROLLMENT.FACT_PLATFORM_ENROLLMENT (ID,HK_LINK,MD_START_DT,MD_CREATION_DT,MD_CREATION_AUDIT_ID,MD_SECURITY_TYPE,MD_SOURCE,OPEN_SHOPPING_PERIOD_ID,EMPLOYEE_ID,ORGANIZATION_ID,CAMPAIGN_ID)  \\n \\
(SELECT Emp.ID ID,\\n \\
Link.HK_LINK HK_LINK,\\n \\
Emp.MD_START_DT MD_START_DT,\\n \\
" + "''" + SESSSTARTTIME + "''" + " as MD_CREATION_DT,\\n \\
Link.MD_CREATION_DT MD_CREATION_DT,\\n \\
Emp.MD_SECURITY_TYPE MD_SECURITY_TYPE,\\n \\
Emp.MD_SOURCE MD_SOURCE,\\n \\
Link.OPEN_SHOPPING_PERIOD_ID OPEN_SHOPPING_PERIOD_ID,\\n \\
NULL AS EMPLOYEE_ID,\\n \\
Link.ORGANIZATION_ID ORGANIZATION_ID,\\n \\
Link.CAMPAIGN_ID CAMPAIGN_ID \\n \\
FROM DB_AC_"+ENV+"_DWH.ENROLLMENT_RDV.VW_SAT_LINK_ENROLLMENT Link \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.SHARED.DIM_EMPLOYEE Emp ON Link.HK_HUB_WORKER=Emp.HK_HUB \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.SHARED.DIM_CAMPAIGN Camp ON Link.HK_HUB_CAMPAIGN=Camp.HK_HUB \\n \\
 WHERE Link.MD_CREATION_DT<=SYSDATE())";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_ENROLLMENT_FACT_ENROLLMENT"("ENV" VARCHAR(1000), "SESSSTARTTIME" VARCHAR(1000), "i_Job_Audit_Id" VARCHAR(1000), "io_DATA_START_DATE" VARCHAR(1000), "i_Security_Type" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var 
var sql_command = "insert into DB_AC_"+ENV+"_DM.ENROLLMENT.FACT_PLATFORM_ENROLLMENT (ID,HK_LINK,MD_START_DT,MD_CREATION_DT,MD_CREATION_AUDIT_ID,MD_SECURITY_TYPE,MD_SOURCE,OPEN_SHOPPING_PERIOD_ID,EMPLOYEE_ID,ORGANIZATION_ID,CAMPAIGN_ID)  \\n \\
 (SELECT Emp.ID ID,Link.HK_LINK HK_LINK," + "''" + io_DATA_START_DATE + "''" + " as o_MD_START_DT,"  + "''" + SESSSTARTTIME + "''" + "as o_MD_CREATION_DT,"  + "''" + i_Job_Audit_Id + "''" + " as o_MD_CREATION_AUDIT_ID,"  + "''" + i_Security_Type + "''" + " as o_MD_SECURITY_TYPE,Emp.MD_SOURCE MD_SOURCE,Link.OPEN_SHOPPING_PERIOD_ID OPEN_SHOPPING_PERIOD_ID,NULL AS EMPLOYEE_ID,Link.ORGANIZATION_ID ORGANIZATION_ID,Link.CAMPAIGN_ID CAMPAIGN_ID \\n \\
FROM DB_AC_"+ENV+"_DWH.ENROLLMENT_RDV.VW_SAT_LINK_ENROLLMENT Link \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.SHARED.DIM_EMPLOYEE Emp ON Link.HK_HUB_WORKER	=	Emp.HK_HUB \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.SHARED.DIM_CAMPAIGN Camp ON Link.HK_HUB_CAMPAIGN =	Camp.HK_HUB \\n \\
 WHERE Link.MD_CREATION_DT<=currenttimestamp )";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_SCD_UPDATE"("MAPPING" VARCHAR(16777216), "TGT_TABLE" VARCHAR(16777216), "SRC_TABLE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =  "update " + TGT_TBL + " SET " + MAPPING + 
" from " + SRC_TBL + 
" AS SRC LEFT OUTER JOIN " + TGT_TBL + 
" as dim   ON src.MD_HASH_NAT_KEYS = DIM.MD_HASH_NAT_KEYS where "  + 
" dim.md_end_dt is null and src.MD_HASH_NAT_KEYS is not NULL AND dim.MD_HASH_NAT_KEYS is not null AND (src.MD_HASHDIFF_TYPE2=dim.MD_HASHDIFF_TYPE2) AND (src.MD_HASHDIFF_TYPE1<>dim.MD_HASHDIFF_TYPE1)";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
var result2_scan = sql_statement2.execute(); 
';
create or replace schema PRODUCT;

create or replace TABLE DIM_PERSONAL_INTEREST (
	ID NUMBER(38,0) NOT NULL autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'MD Hash NAT key for the Hub',
	MD_HASHDIFF_TYPE1 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	NAME_FR VARCHAR(16777216) COMMENT ' Interest Name in French',
	NAME_EN VARCHAR(16777216) COMMENT 'Interest Name in English',
	TAGS VARCHAR(16777216) COMMENT 'Tag list related to the personal Interest',
	primary key (ID)
);
create or replace TABLE DIM_PRODUCT (
	ID NUMBER(38,0) NOT NULL autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'MD Hash NAT key for the Hub',
	MD_HASHDIFF_TYPE1 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CATEGORY VARCHAR(16777216) COMMENT 'Column description',
	NAME_FR VARCHAR(16777216) COMMENT ' Product Name in French',
	NAME_EN VARCHAR(16777216) COMMENT 'Product Name in English',
	DESCRIPTION_FR VARCHAR(16777216) COMMENT 'Product Description in French',
	DESCRIPTION_EN VARCHAR(16777216) COMMENT 'Product Description in English',
	TYPE VARCHAR(16777216) COMMENT 'Type of product',
	COVERAGE_TYPE VARCHAR(16777216) COMMENT 'Coverage type',
	AVAILABILITY_START_DATE DATE COMMENT 'Product availability start date',
	AVAILABILITY_END_DATE DATE COMMENT 'Product availability end date',
	SKU VARCHAR(16777216),
	TAGS VARCHAR(16777216) COMMENT 'Tag list related to the product',
	IS_PACKAGE VARCHAR(16777216),
	primary key (ID)
);
create or replace view VW_DIM_PERSONAL_INTEREST(
	ID,
	"Data_start_date",
	"Data_end_date",
	"Creation_date",
	"Modify_date",
	"Source",
	"Creaton_Audit_ID",
	"Modify_Audit_ID",
	"Security_Type",
	"Name_FR",
	"Name_EN",
	TAGS
) as 

SELECT  ID AS  "ID",
             MD_START_DT AS  "Data_start_date", 
             MD_END_DT AS  "Data_end_date" ,
             MD_CREATION_DT AS  "Creation_date" ,
             MD_MODIFY_DT AS  "Modify_date",
             MD_SOURCE AS  "Source",
             MD_CREATION_AUDIT_ID AS "Creaton_Audit_ID" ,
             MD_MODIFY_AUDIT_ID AS "Modify_Audit_ID",
             MD_SECURITY_TYPE AS "Security_Type" ,
             NAME_FR AS "Name_FR" , 
             NAME_EN AS "Name_EN" , 
             TAGS AS  "TAGS" 
FROM DB_AC_DEV_DM.PRODUCT.DIM_PERSONAL_INTEREST;
create or replace view VW_DIM_PRODUCT(
	ID,
	"Start_Date",
	"End_Date",
	"Creation_Date",
	"Modify_Date",
	"Source",
	"Creation_Audit_ID",
	"Modify_Audit_ID",
	"Security_Type",
	"Category",
	"Name_FR ",
	"Name_EN",
	"Description_FR",
	"Description_EN",
	"Type_of_Product",
	"Coverage_Type",
	"Availability_Start_Date",
	"Availablity_nd_Date"
) as 

SELECT ID AS "ID", -- To validate
    MD_START_DT AS "Start_Date", -- To validate
	MD_END_DT AS "End_Date", -- To validate
	MD_CREATION_DT AS "Creation_Date", -- To validate
	MD_MODIFY_DT AS "Modify_Date", -- To validate
	MD_SOURCE AS "Source", -- To validate
	MD_CREATION_AUDIT_ID AS "Creation_Audit _ID", -- To validate
	MD_MODIFY_AUDIT_ID AS "Modify_Audit_ID", -- To validate
	MD_SECURITY_TYPE AS "Security_Type", -- To validate
	CATEGORY AS "Category", -- To validate
	NAME_FR AS "Name_FR", -- To validate
	NAME_EN AS "Name_EN", -- To validate
	DESCRIPTION_FR AS "Description_FR", -- To validate
	DESCRIPTION_EN AS "Description_EN", -- To validate
	TYPE AS "Type_of_Product", -- To validate
    COVERAGE_TYPE AS "Coverage_Type", -- To validate
	AVAILABILITY_START_DATE AS "Availability_Start_Date", -- To validate
	AVAILABILITY_END_DATE AS "Availablity_nd_Date" -- To validate
    
FROM DB_AC_DEV_DM.PRODUCT.DIM_PRODUCT;
create or replace schema PRODUCT_WT;

create or replace TABLE WT_DIM_PERSONAL_INTEREST (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	PERSONAL_INTEREST_ID VARCHAR(16777216) COMMENT 'Personal Interest plateform ID',
	NAME_FR VARCHAR(16777216) COMMENT ' Personal Interest  Name in French',
	NAME_EN VARCHAR(16777216) COMMENT 'Personal Interest  Name in English',
	TAGS VARCHAR(16777216) COMMENT 'Tag list related to the Personal Interest'
);
create or replace TABLE WT_DIM_PRODUCT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product plateform ID',
	CATEGORY VARCHAR(16777216) COMMENT 'Column description',
	NAME_FR VARCHAR(16777216) COMMENT ' Product Name in French',
	NAME_EN VARCHAR(16777216) COMMENT 'Product Name in English',
	DESCRIPTION_FR VARCHAR(16777216) COMMENT 'Product Description in French',
	DESCRIPTION_EN VARCHAR(16777216) COMMENT 'Product Description in English',
	TYPE VARCHAR(16777216) COMMENT 'Type of Product',
	COVERAGE_TYPE VARCHAR(16777216) COMMENT 'Coverage type',
	AVAILABILITY_START_DATE DATE COMMENT 'Product availability start date',
	AVAILABILITY_END_DATE DATE COMMENT 'Product availability end date',
	SKU VARCHAR(16777216),
	TAGS VARCHAR(16777216) COMMENT 'Tag list related to the product',
	IS_PACKAGE VARCHAR(16777216)
);
create or replace view VW_DIM_WT_PERSONAL_INTEREST(
	HK_HUB,
	MD_START_DT,
	MD_END_DT,
	MD_HASH_NAT_KEYS,
	MD_HASHDIFF_TYPE1,
	MD_HASHDIFF_TYPE2,
	MD_CREATION_DT,
	MD_MODIFY_DT,
	MD_SOURCE,
	MD_CREATION_AUDIT_ID,
	MD_MODIFY_AUDIT_ID,
	MD_SECURITY_TYPE,
	PERSONAL_INTEREST_ID,
	NAME_FR,
	NAME_EN,
	TAGS
) as  (
    
  SELECT 
	HK_HUB ,
	MD_START_DT,
	MD_END_DT ,
    HK_HUB AS MD_HASH_NAT_KEYS,  
	'N/A' AS MD_HASHDIFF_TYPE1 ,    -- WT_DIM
	SHA1( 
                UPPER(                     
                    NVL(RTRIM(LTRIM(NAME_FR)),'#NULL#')                  
                    || '|' ||
                    NVL(RTRIM(LTRIM(NAME_EN)),'#NULL#')                  
                    || '|' ||
                    NVL(RTRIM(LTRIM(TAGS)),'#NULL#')                                                                  
                ) 
           )::string AS MD_HASHDIFF_TYPE2, 
	CURRENT_TIMESTAMP AS MD_CREATION_DT,
	MD_MODIFY_DT ,
	MD_SOURCE ,
	MD_CREATION_AUDIT_ID ,
	MD_MODIFY_AUDIT_ID ,
	MD_SECURITY_TYPE,    
    PERSONAL_INTEREST_ID,  
    NAME_FR,
    NAME_EN,
    TAGS
  from DB_AC_DEV_DM.PRODUCT_WT.WT_DIM_PERSONAL_INTEREST);
create or replace view VW_DIM_WT_PRODUCT(
	HK_HUB,
	MD_START_DT,
	MD_END_DT,
	MD_HASH_NAT_KEYS,
	MD_HASHDIFF_TYPE1,
	MD_HASHDIFF_TYPE2,
	MD_CREATION_DT,
	MD_MODIFY_DT,
	MD_SOURCE,
	MD_CREATION_AUDIT_ID,
	MD_MODIFY_AUDIT_ID,
	MD_SECURITY_TYPE,
	PRODUCT_ID,
	CATEGORY,
	NAME_FR,
	NAME_EN,
	DESCRIPTION_FR,
	DESCRIPTION_EN,
	TYPE,
	COVERAGE_TYPE,
	AVAILABILITY_START_DATE,
	AVAILABILITY_END_DATE,
	SKU,
	TAGS,
	IS_PACKAGE
) as  (
    
  SELECT 
	HK_HUB ,
	MD_START_DT,
	MD_END_DT ,
    HK_HUB AS MD_HASH_NAT_KEYS,  
	'TEST' AS MD_HASHDIFF_TYPE1 ,    -- WT_DIM
	SHA1( 
                UPPER(                     
                    NVL(RTRIM(LTRIM(CATEGORY)),'#NULL#')                    
                   || '|' ||
                    NVL(RTRIM(LTRIM(NAME_FR)),'#NULL#')                  
                   || '|' ||
                    NVL(RTRIM(LTRIM(NAME_EN)),'#NULL#')                  
                   || '|' ||
                    NVL(RTRIM(LTRIM(DESCRIPTION_FR)),'#NULL#')
                   || '|' ||
                    NVL(RTRIM(LTRIM(DESCRIPTION_EN)),'#NULL#')
                   || '|' ||
                    NVL(RTRIM(LTRIM(TYPE)),'#NULL#')
                   || '|' ||
                    NVL(RTRIM(LTRIM(COVERAGE_TYPE)),'#NULL#')
                   || '|' ||
                    NVL(RTRIM(LTRIM(AVAILABILITY_START_DATE)),'#NULL#')
                   || '|' ||
                    NVL(RTRIM(LTRIM(AVAILABILITY_END_DATE)),'#NULL#')                                    
                    || '|' ||
                    NVL(RTRIM(LTRIM(TAGS)),'#NULL#')                                    
                    || '|' ||
                    NVL(RTRIM(LTRIM(SKU)),'#NULL#')
                    || '|' ||
                    NVL(RTRIM(LTRIM(IS_PACKAGE)),'#NULL#')                                     
                ) 
           )::string AS MD_HASHDIFF_TYPE2, 
	CURRENT_TIMESTAMP AS MD_CREATION_DT,
	MD_MODIFY_DT ,
	MD_SOURCE ,
	MD_CREATION_AUDIT_ID ,
	MD_MODIFY_AUDIT_ID ,
	MD_SECURITY_TYPE,    
    PRODUCT_ID,  
	CATEGORY,
    NAME_FR,
    NAME_EN,
    DESCRIPTION_FR,
    DESCRIPTION_EN,
    TYPE,
    COVERAGE_TYPE,
    AVAILABILITY_START_DATE,
    AVAILABILITY_END_DATE,
	SKU,
    TAGS,
    IS_PACKAGE
  from DB_AC_DEV_DM.PRODUCT_WT.WT_DIM_PRODUCT);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_PRODUCT_RDV_TO_DM_PRODUCT_WT_DIM_PERSONAL_INTEREST"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216), "SECURITY_TYPE" VARCHAR(16777216), "MD_SORUCE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
DEL_QUERY =  "DELETE FROM DB_AC_DEV_DM.PRODUCT_WT.WT_DIM_PERSONAL_INTEREST WHERE 1=1";
var DEL_QUERY_ENV = DEL_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement1 = snowflake.createStatement({
  sqlText: DEL_QUERY_ENV
});
var result2_scan = sql_statement1.execute(); 
INS_QUERY =   "INSERT INTO DB_AC_DEV_DM.PRODUCT_WT.WT_DIM_PERSONAL_INTEREST( " +
"HK_HUB,	" +
"MD_START_DT,	" +
"MD_CREATION_DT,	" +	
"MD_MODIFY_DT,		" +
"MD_SOURCE,		" +
"MD_CREATION_AUDIT_ID," +		
"MD_MODIFY_AUDIT_ID,	" +
"MD_SECURITY_TYPE,	" +
"PERSONAL_INTEREST_ID,	" +
"NAME_FR	," +
"NAME_EN,	" +
"TAGS	)" +
"WITH T1 AS(select MSTR.HK_HUB AS SAT_HK_HUB,MSTR.INTEREST_ID AS SAT_INTERST_ID,MSTR.NAME_FR AS NAME_FR, MSTR.NAME_EN AS NAME_EN from " + 
" DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PERSONAL_INTEREST_PLT MSTR JOIN ( " +
"  select HK_HUB,max(md_start_dt) as max_md_start_dt from  DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PERSONAL_INTEREST_PLT where MD_START_DT <= " +
" TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_HUB) as dtls " +
"  on mstr.HK_HUB = dtls.hk_HUB and mstr.md_start_dt = dtls.max_md_start_dt), " +
"  T2 AS(SELECT * FROM DB_AC_DEV_DWH.PRODUCT_RDV.HUB_PERSONAL_INTEREST AS MSTR LEFT OUTER JOIN T1 ON MSTR.HK_HUB = SAT_HK_HUB), " +
"  T3 AS(select MSTR.HK_HUB AS S_HK_HUB,MSTR.TAGS AS TAGS from DB_AC_DEV_DWH.PRODUCT_RDV.VW_LINK_LOAD_PERSONAL_INTEREST_TAG MSTR JOIN ( " +
"  select HK_HUB,max(md_start_dt) as max_md_start_dt from  DB_AC_DEV_DWH.PRODUCT_RDV.VW_LINK_LOAD_PERSONAL_INTEREST_TAG " + 
" where MD_START_DT <= " +
" TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_HUB) as dtls " +
"  on mstr.HK_HUB = dtls.hk_HUB and mstr.md_start_dt = dtls.max_md_start_dt) " +
"  SELECT SAT_HK_HUB,  " +
"''" + IO_START_DT + "''," +
"  SYSTIMESTAMP(), " +
"  SYSTIMESTAMP(), " +
"''" + MD_SORUCE + "''," +
"''" + AUDIT_ID + "''," +
"''" + AUDIT_ID + "''," +
"''" + SECURITY_TYPE + "''," +
"  SAT_INTERST_ID, " +
"  NAME_FR, " +
"  NAME_EN, " +
"  TAGS " +
"   FROM T2 LEFT OUTER JOIN T3 ON S_HK_HUB = Hk_HUB ";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SHARED_WT_DIM_CAMPAIGN"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216), "SECURITY_TYPE" VARCHAR(16777216), "MD_SORUCE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
DEL_QUERY =  "DELETE FROM DB_AC_DEV_DM.SHARED_WT.WT_DIM_CAMPAIGN WHERE 1=1";
var DEL_QUERY_ENV = DEL_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement1 = snowflake.createStatement({
  sqlText: DEL_QUERY_ENV
});
var result2_scan = sql_statement1.execute(); 
INS_QUERY =   "INSERT INTO DB_AC_DEV_DM.SHARED_WT.WT_DIM_CAMPAIGN( " +
"HK_HUB,		" +
"MD_START_DT,	" +
"MD_CREATION_DT,	" +
"MD_MODIFY_DT	," +
"MD_SOURCE		," +
"MD_CREATION_AUDIT_ID	," +
"MD_MODIFY_AUDIT_ID		," +
"MD_SECURITY_TYPE		," +
"CAMPAIGN_ID	," +
"TYPE		," +
"ORGANIZATION_ID," +	
"WORKER_GROUP	,	" +
"JOB_CATEGORY	,	" +
"GROUP_TYPE_CODE	," +
"GROUP_REFERENCES,		" +
"SCHEDULED_TIME	,	" +
"BEGINS_ON		," +
"ENDS_ON	," +
"BENEFITS_EFFECTIVE_DATE	,	" +
"ELIGIBILITY_RULE_SET	,	" +
"IS_STARTED	)" +
"select MSTR.HK_HUB," +
"TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')," +
"Systimestamp()," +
"Systimestamp()," +
"DTLS.MD_SOURCE," +
"  ''" + AUDIT_ID + "'' , " +
"  ''" + AUDIT_ID + "'' , " +
"  ''" + SECURITY_TYPE + "'' , " +
"CAMPAIGN_ID," +
"TYPE		," +
"ORGANIZATION_ID	," + 
"WORKER_GROUP	," +
"JOB_CATEGORY ," +
"GROUP_TYPE_CODE," +
"GROUP_REFERENCES ," +
" SCHEDULED_TIME ," +
" BEGINS_ON ," +
" ENDS_ON ," +
"  BENEFITS_EFFECTIVE_DATE," +
"  ELIGIBILITY_RULE_SET," +
"  IS_STARTED" +
 " from DB_AC_DEV_Dwh.shopping_rdv.HUB_CAMPAIGN  mstr join DB_AC_DEV_Dwh.shopping_rdv.SAT_CAMPAIGN dtls on mstr.hk_hub = dtls.hk_hub" ;
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SHARED_WT_DIM_PRODUCT"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216), "SECURITY_TYPE" VARCHAR(16777216), "MD_SORUCE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
DEL_QUERY =  "DELETE FROM DB_AC_DEV_DM.PRODUCT_WT.WT_DIM_PRODUCT WHERE 1=1";
var DEL_QUERY_ENV = DEL_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement1 = snowflake.createStatement({
  sqlText: DEL_QUERY_ENV
});
var result2_scan = sql_statement1.execute(); 
INS_QUERY =   "INSERT INTO DB_AC_DEV_DM.PRODUCT_WT.WT_DIM_PRODUCT(HK_HUB,"+	
"MD_START_DT	,	"+
"MD_CREATION_DT,		"+
"MD_MODIFY_DT	,	"+
"MD_SOURCE		,"+
"MD_CREATION_AUDIT_ID, "+		
"MD_MODIFY_AUDIT_ID	,	"+
"MD_SECURITY_TYPE	,	"+
"PRODUCT_ID		,"+
"CATEGORY		,"+
"NAME_FR		,"+
"NAME_EN		,"+
"DESCRIPTION_FR,	"+
"DESCRIPTION_EN	,	"+
"TYPE	,"+
"COVERAGE_TYPE	, "+
"AVAILABILITY_START_DATE	,	"+
"AVAILABILITY_END_DATE	,"+
"SKU		,"+
"TAGS	,	"+
"IS_PACKAGE	) "+
"WITH T1 AS(select sat_hk_hub,CATEGORY,NAME_FR,NAME_EN,DESCRIPTION_FR,DESCRIPTION_EN,TYPE,COVERAGE_TYPE,AVAILABILITY_START_DATE,AVAILABILITY_END_DATE,SKU,IS_PACKAGE "+ 
" from DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PRODUCT_INFO_PLT MSTR JOIN ( " +
"  select HK_HUB AS SAT_HK_HUB,max(md_start_dt) as max_md_start_dt from  DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PRODUCT_INFO_PLT " +
" where MD_START_DT <= TO_DATE(''2020-01-01'',''YYYY-MM-DD'') group by HK_HUB) as dtls  " +
"  on mstr.HK_HUB = SAT_HK_HUB and mstr.md_start_dt = dtls.max_md_start_dt), " +
"  T2 AS(SELECT * FROM DB_AC_DEV_DWH.PRODUCT_RDV.HUB_PRODUCT AS MSTR LEFT OUTER JOIN T1 ON MSTR.HK_HUB = SAT_HK_HUB), " +
" T3 AS(select MSTR.HK_HUB AS S_HK_HUB,MSTR.TAGS AS TAGS from DB_AC_DEV_DWH.PRODUCT_RDV.VW_LINK_LOAD_PRODUCT_TAG MSTR JOIN ( " +
" select HK_HUB as lnk_hk_hub,max(md_start_dt) as max_md_start_dt from  DB_AC_DEV_DWH.PRODUCT_RDV.VW_LINK_LOAD_PRODUCT_TAG " + 
" where MD_START_DT <= TO_DATE(''2020-01-01'',''YYYY-MM-DD'') group by HK_HUB) as dtls " + 
"  on mstr.HK_HUB = dtls.lnk_hk_hub and mstr.md_start_dt = dtls.max_md_start_dt) " +
"  SELECT hk_hub,''" + IO_START_DT + "''," +
"  SYSTIMESTAMP(), " +
"  SYSTIMESTAMP(), " +
"  md_source, " +
"  ''" + AUDIT_ID + "'' , " +
"  ''" + AUDIT_ID + "'' , " +
"  ''" + SECURITY_TYPE + "'' , " +
"  product_id, " +
"  CATEGORY, " +
"  NAME_EN, " +
"  NAME_FR , " +
"   DESCRIPTION_FR, " +
"    DESCRIPTION_EN, " +
"    TYPE	, " +
"COVERAGE_TYPE	, " +
"AVAILABILITY_START_DATE	,	" +
"AVAILABILITY_END_DATE	, " +
"SKU		, " +
"TAGS	,	" +
"IS_PACKAGE	" +
"   FROM T2 LEFT OUTER JOIN T3 ON S_HK_HUB = sat_HK_HUB ";    

var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
create or replace schema PUBLIC;

create or replace schema SHARED;

create or replace TABLE DIM_CAMPAIGN (
	ID NUMBER(38,0) NOT NULL autoincrement COMMENT 'Surrogate key of the Fact',
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'MD Hash NAT key for the Hub',
	MD_HASHDIFF_TYPE1 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CAMPAIGN_ID VARCHAR(16777216) COMMENT 'Campaign plateform ID',
	TYPE VARCHAR(16777216) COMMENT 'Campaign Type',
	WORKER_GROUP VARCHAR(16777216) COMMENT 'Name of worker group',
	JOB_CATEGORY VARCHAR(16777216) COMMENT 'the name of job category',
	GROUP_TYPE_CODE VARCHAR(16777216) COMMENT 'group type code',
	GROUP_REFERENCES VARCHAR(16777216) COMMENT ' group references',
	SCHEDULED_TIME TIME(7),
	BEGINS_ON TIMESTAMP_NTZ(9) COMMENT 'campaign start date',
	ENDS_ON TIMESTAMP_NTZ(9) COMMENT 'campaign end date',
	BENEFITS_EFFECTIVE_DATE DATE COMMENT 'The date on which benefits will start',
	ELIGIBILITY_RULE_SET VARCHAR(16777216) COMMENT 'rule for eligibility of the benefits',
	IS_STARTED BOOLEAN COMMENT 'campaign is on way or not',
	primary key (ID)
);
create or replace TABLE DIM_CUSTOMER (
	ID NUMBER(38,0) NOT NULL autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'MD Hash NAT key for the Hub',
	MD_HASHDIFF_TYPE1 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	AGE_GROUP VARCHAR(16777216) COMMENT 'Age group',
	AGE_GROUP_SORT NUMBER(38,0) COMMENT 'sort order for the age group attribute',
	GENDER VARCHAR(16777216) COMMENT 'Individual Gender',
	POSTAL_CODE_PARTIAL VARCHAR(16777216) COMMENT 'Personal address partial postal code',
	PROVINCE VARCHAR(16777216) COMMENT 'Personal address Province',
	COUNTRY VARCHAR(16777216) COMMENT 'Personal address Counrty',
	primary key (ID)
);
create or replace TABLE DIM_DATE (
	ID_DIM_DATE NUMBER(38,0) NOT NULL COMMENT 'Identifiant Date du jour',
	ID_DATE DATE NOT NULL COMMENT 'Date en format date',
	SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Date en format court français selon les paramètres régionaux, ex: 2016-02-14',
	SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Date en format court anglais selon les paramètres régionaux, ex: 02/14/2016',
	NAME_FR VARCHAR(50) NOT NULL COMMENT 'Date en format long français selon les paramètres régionaux, ex: 14 février 2016',
	NAME_EN VARCHAR(50) NOT NULL COMMENT 'Date en format long anglais selon les paramètres régionaux, ex: Saturday, February 14, 2016',
	WEEK_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro de journée dans la semaine ISO (Lundi=1, Dimanche=7)',
	MONTH_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le mois (1 à 31)',
	QUARTER_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le trimestre (1 à 91)',
	SEMESTER_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le semestre (1 à 184)',
	YEAR_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans l''année (1 à 366)',
	DAY_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom abrégé français de la journée de la semaine, ex: dim.',
	DAY_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom abrégé anglais de la journée de la semaine, ex: Sun',
	DAY_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la journée de la semaine, ex: \"\"dimanche\"\"',
	DAY_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la journée de la semaine, ex: \"\"Sunday\"\"',
	WEEKEND_IND BOOLEAN NOT NULL COMMENT 'Indique si la journée est un jour de fin de semaine (samedi ou dimanche)',
	WEEK_CD VARCHAR(10) NOT NULL COMMENT 'Code de la semaine sous la forme aaaaSnn, ex: 2016S01',
	WEEK_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro de la semaine dans l''année; 53 possible',
	WEEK_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français de la semaine, ex: \"\"Sem. 12\"\"',
	WEEK_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais de la semaine, ex: \"\"Wk 12\"\"',
	WEEK_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la semaine, ex: \"\"Semaine 12\"\"',
	WEEK_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la semaine, ex: \"\"Week 12\"\"',
	WEEK_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français de la semaine dans l''année, ex: \"\"2016, Sem. 12\"\"',
	WEEK_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais de la semaine dans l''année, ex: \"\"2016, Wk. 12\"\"',
	WEEK_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la semaine dans l''année, ex: \"\"2016, Semaine 12\"\"',
	WEEK_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la semaine dans l''année, ex: \"\"2016, Week 12\"\"',
	WEEK_START_DT DATE NOT NULL COMMENT 'Date du début de la semaine ',
	WEEK_END_DT DATE NOT NULL COMMENT 'Date de la fin de la semaine ',
	WEEK_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours de la semaine ',
	MONTH_CD VARCHAR(10) NOT NULL COMMENT 'Code du mois sous la forme aaaaMnn, ex: 2016M05',
	MONTH_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du mois (1 à 12)',
	MONTH_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du mois, ex: \"\"janv.\"\"',
	MONTH_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du mois,  ex: \"\"Jan\"\"',
	MONTH_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du mois, ex: Janvier\"\"',
	MONTH_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du mois, ex: January\"\"',
	MONTH_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du mois de l''année, ex: \"\"janv. 2016\"\"',
	MONTH_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du mois de l''année, ex: \"\"Jan 2016\"\"',
	MONTH_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du mois de l''année, ex: \"\"janvier 2016\"\"',
	MONTH_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du mois de l''année, ex: \"\"January 2016\"\"',
	MONTH_START_DT DATE NOT NULL COMMENT 'Date du début du mois',
	MONTH_END_DT DATE NOT NULL COMMENT 'Date de fin du mois',
	MONTH_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours du mois',
	QUARTER_CD VARCHAR(10) NOT NULL COMMENT 'Code du trimestre sous la forme aaaaQnn, ex: 2016Q03',
	QUARTER_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du trimestre (1 à 4)',
	QUARTER_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du trimestre, ex : \"\"T1\"\"',
	QUARTER_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du trimestre, ex : \"\"Q1\"\"',
	QUARTER_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du trimestre, ex : \"\"Trimestre 1\"\"',
	QUARTER_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du trimestre, ex : \"\"Quarter 1\"\"',
	QUARTER_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du trimestre de l''année , ex : \"\"T1, 2016\"\"',
	QUARTER_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du trimestre de l''année, ex : \"\"Q1, 2016\"\"',
	QUARTER_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du trimestre de l''année , ex : \"\"Trimestre 1, 2016\"\"',
	QUARTER_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du trimestre de l''année , ex : \"\"Quarter 1, 2016\"\"',
	QUARTER_START_DT DATE NOT NULL COMMENT 'Date de début du trimestre',
	QUARTER_END_DT DATE NOT NULL COMMENT 'Date de fin du trimestre',
	QUARTER_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours dans le trimeste (90, 91 ou 92)',
	SEMESTER_CD VARCHAR(10) NOT NULL COMMENT 'Code de semestre sous la forme aaaaSnn, ex: 2016S01 ou 2016S02 (du 1 janvier au 30 juin et 1 juillet au 31 décembre)',
	SEMESTER_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du semestre (1 ou 2)',
	SEMESTER_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du semestre, ex: \"\"S1\"\"',
	SEMESTER_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du semestre, ex: \"\"S1\"\"',
	SEMESTER_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du semestre, ex: \"\"Semestre 1\"\"',
	SEMESTER_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du semestre, ex: \"\"Semester 1\"\"',
	SEMESTER_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du semestre dans l''année, ex: \"\"S1, 2016\"\"',
	SEMESTER_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du semestre dans l''année, ex: \"\"S1, 2016\"\"',
	SEMESTER_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du semestre dans l''année, ex: \"\"Semestre 1, 2016\"\"',
	SEMESTER_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du semestre dans l''année, ex: \"\"Semester 1, 2016\"\"',
	SEMESTER_START_DT DATE NOT NULL COMMENT 'Date de début du semestre',
	SEMESTER_END_DT DATE NOT NULL COMMENT 'Date de fin du semestre',
	SEMESTER_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours dans le semestre (183 ou 184)',
	YEAR_CD NUMBER(38,0) NOT NULL COMMENT 'Code de l''année sous la forme aaaa',
	YEAR_SHORT_NAME_FR VARCHAR(4) NOT NULL COMMENT 'Nom court français de l''année, ex: 2016',
	YEAR_SHORT_NAME_EN VARCHAR(4) NOT NULL COMMENT 'Nom court anglais de l''année, ex: 2016',
	YEAR_NAME_FR VARCHAR(4) NOT NULL COMMENT 'Nom long français de l''année, ex: 2016',
	YEAR_NAME_EN VARCHAR(4) NOT NULL COMMENT 'Nom long anglais de l''année, ex: 2016',
	YEAR_START_DT DATE NOT NULL COMMENT 'Date de début de l''année, ex: 2016-01-01',
	YEAR_END_DT DATE NOT NULL COMMENT 'Date de fin de l''année, ex: 2016-12-31',
	YEAR_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours de l''année',
	constraint PK_DIM_DATE primary key (ID_DIM_DATE)
);
create or replace TABLE DIM_EMPLOYEE (
	ID NUMBER(38,0) NOT NULL autoincrement COMMENT 'Surrogate key of the dimension',
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'MD Hash NAT key for the Hub',
	MD_HASHDIFF_TYPE1 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	HIRE_DATE DATE COMMENT 'Employee hire DATE',
	ORIGINAL_HIRED_DATE DATE COMMENT 'Employee original hired date',
	PROVINCE_OF_EMPLOYMENT VARCHAR(16777216) COMMENT 'Employee Province of employement',
	REMUNERATION_TYPE VARCHAR(16777216) COMMENT 'Employee remuneration type',
	HOURS_PER_WEEK NUMBER(38,2) COMMENT 'Employee hours per week',
	PAY_PERIOD VARCHAR(16777216) COMMENT 'Employee pay periode',
	WORK_PATTERN VARCHAR(16777216) COMMENT 'Employee work pattern',
	JOB_PERMANENCY VARCHAR(16777216) COMMENT 'Employee job permanency',
	JOB_CATEGORY VARCHAR(16777216) COMMENT 'Employee job Category ',
	LOCATION VARCHAR(16777216) COMMENT 'Employee Location',
	IS_MANAGER VARCHAR(16777216) COMMENT 'Employee is a manager',
	ORGANIZATION_NAME VARCHAR(16777216) COMMENT 'organization name',
	TERMINATED VARCHAR(16777216) COMMENT 'Terminated predicate',
	TERMINATION_DATE DATE COMMENT 'Termination DATE',
	TERMINATION_REASON_CODE VARCHAR(16777216) COMMENT 'Termination reason code',
	SALARY NUMBER(38,2) COMMENT 'Salary',
	SALARY_EFFECTIVE_DATE DATE COMMENT 'Salary effective DATE',
	ON_LEAVE VARCHAR(16777216) COMMENT 'On leave predicate',
	LEAVE_START_DATE DATE COMMENT 'Leave start DATE',
	LEAVE_END_DATE DATE COMMENT 'Leave end DATE',
	LEAVE_REASON_CODE VARCHAR(16777216) COMMENT 'Leave reason code',
	WORK_PERMIT_TYPE VARCHAR(16777216) COMMENT ' Work permit type',
	WORK_PERMIT_START_DATE DATE COMMENT 'Work permit start DATE',
	WORK_PERMIT_END_DATE DATE COMMENT 'Work permit end DATE',
	RETIRED VARCHAR(16777216) COMMENT 'Retired predicate',
	RETIREMENT_DATE DATE COMMENT 'Retirement date',
	RETIREMENT_EXPECTED VARCHAR(16777216) COMMENT 'Retirement expected predicate',
	EXPECTED_RETIREMENT_DATE DATE COMMENT 'Expected retirement date',
	primary key (ID)
);
create or replace TABLE DIM_HOUR (
	ID_DIM_HOUR NUMBER(38,0) NOT NULL COMMENT 'Identifiant Heure',
	HOUR_OF_DAY NUMBER(38,0) NOT NULL COMMENT 'Heure (0-23) en format integer',
	HOUR_12H_FORMAT_SHORT VARCHAR(20) NOT NULL COMMENT 'Heure en format court am/pm  ex: 03 pm',
	HOUR_12H_FORMAT VARCHAR(20) NOT NULL COMMENT 'Heure en format heure:minute am/pm ex: 03:00 pm',
	HOUR_24H_FORMAT VARCHAR(20) NOT NULL COMMENT 'Heure en format heure:minute ex: 15:00',
	START_TIME TIME(3) NOT NULL COMMENT 'Début de l''heure en format time',
	END_TIME TIME(3) NOT NULL COMMENT 'Fin de l''heure en format time',
	PART_OF_DAY_FR VARCHAR(20) NOT NULL COMMENT 'Descriptif partie de la journée (regroupement) - français',
	PART_OF_DAY_EN VARCHAR(20) NOT NULL COMMENT 'Descriptif partie de la journée (regroupement) - anglais',
	constraint PK_DIM_HOUR primary key (ID_DIM_HOUR)
);
create or replace TABLE DIM_ORGANISATION (
	ID_NUMBER NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the Fact',
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_HASH_NAT_KEYS VARCHAR(64) COMMENT 'MD Hash NAT key for the Hub',
	MD_HASHDIFF_TYPE1 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 1 attributes to be historized for an occurrence',
	MD_HASHDIFF_TYPE2 VARCHAR(64) COMMENT 'Represents the whole set of hashed type 2 attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	ORGANIZATION_ID VARCHAR(100) COMMENT 'name of the organization'
);
create or replace view VW_DIM_CUSTOMER(
	ID,
	"Data_start_date",
	"Data_end_date",
	"Age_group",
	"Age_group_sort_order",
	"Gender",
	"Postal_code_region",
	"Province",
	"Country"
) as 

SELECT  ID,
		MD_START_DT AS "Data_start_date", 
		MD_END_DT AS "Data_end_date", 
		AGE_GROUP AS  "Age_group",
        AGE_GROUP_SORT AS  "Age_group_sort_order",
		GENDER AS "Gender", 
		POSTAL_CODE_PARTIAL AS   "Postal_code_region", 
		PROVINCE AS  "Province", 
		COUNTRY AS "Country"
FROM DB_AC_DEV_DM.SHARED.DIM_CUSTOMER;
create or replace view VW_DIM_DATE(
	"ID Date",
	"Nom court français",
	"Nom court anglais",
	"Nom français",
	"Nom anglais",
	"Numéro jour de semaine",
	"Numéro jour du mois",
	"Numéro jour de trimestre",
	"Numéro jour de semestre",
	"Numéro jour de l'année",
	"Nom court jour français",
	"Nom court jour anglais",
	"Nom jour français",
	"Nom jour anglais",
	"Weekend indicator",
	"Week code",
	"Week number",
	"Week short name french",
	"Week short name english",
	"Week name french",
	"Week name english",
	"Week year short name french",
	"Week year short name english",
	"Week year name french",
	"Week year name english",
	"Week start date",
	"Week end date",
	"Week number date",
	"Month code",
	"Month number",
	"Month short name french",
	"Month short name english",
	"Month name french",
	"Month name english",
	"Month year short name french",
	"Mon year short nanme english",
	"Month year name french",
	"Month year name english",
	"Month start date",
	"Month end date",
	"Month number day",
	"Quarter code",
	"Quarter number",
	"Quarter short name english",
	"Quarter short name french",
	"Quater name french",
	"Quarter name english",
	"Quarter year short name french",
	"Quarter year short name english",
	"Quarter year name french",
	"Quarter year name english",
	"Quarter start date",
	"Quarter end date",
	"Quarter number day",
	"Semester code",
	"Semester number",
	"Semester short name french",
	"Semester short name english",
	"Semester name french ",
	"Semester name english",
	"Semester year short name french",
	"Semester year short name english",
	"Semester year name french",
	"Semester year name english",
	"Semester start date",
	"Semester end date",
	"Semester number day",
	"Year code",
	"Year short name french",
	"Year short name english",
	"Year name french",
	"Year name english",
	"Year start date",
	"Year end date",
	"Year number day"
) as 
SELECT ID_DATE AS "ID Date", -- To validate
             SHORT_NAME_FR AS "Nom court français", -- To validate
             SHORT_NAME_EN AS "Nom court anglais", -- To validate
             NAME_FR AS "Nom français", -- To validate
             NAME_EN AS "Nom anglais", -- To validate
             WEEK_DAY_NO AS "Numéro jour de semaine", -- To validate
             MONTH_DAY_NO AS "Numéro jour du mois", -- To validate
             QUARTER_DAY_NO AS "Numéro jour de trimestre", -- To validate
             SEMESTER_DAY_NO AS "Numéro jour de semestre", -- To validate
             YEAR_DAY_NO AS "Numéro jour de l'année", -- To validate
             DAY_SHORT_NAME_FR AS "Nom court jour français", -- To validate
             DAY_SHORT_NAME_EN AS "Nom court jour anglais", -- To validate
             DAY_NAME_FR AS "Nom jour français", -- To validate
             DAY_NAME_EN AS "Nom jour anglais", -- To validate
             WEEKEND_IND AS "Weekend indicator", -- To validate
             WEEK_CD AS "Week code", -- To validate
             WEEK_NO AS "Week number", -- To validate
             WEEK_SHORT_NAME_FR AS "Week short name french", -- To validate
             WEEK_SHORT_NAME_EN AS "Week short name english", -- To validate
             WEEK_NAME_FR AS "Week name french", -- To validate
             WEEK_NAME_EN AS "Week name english", -- To validate
             WEEK_YEAR_SHORT_NAME_FR AS "Week year short name french", -- To validate
             WEEK_YEAR_SHORT_NAME_EN AS "Week year short name english", -- To validate
             WEEK_YEAR_NAME_FR AS "Week year name french", -- To validate
             WEEK_YEAR_NAME_EN AS "Week year name english", -- To validate
             WEEK_START_DT AS "Week start date", -- To validate
             WEEK_END_DT AS "Week end date", -- To validate
             WEEK_NB_DAY AS "Week number date", -- To validate
             MONTH_CD AS "Month code", -- To validate
             MONTH_NO AS "Month number", -- To validate
             MONTH_SHORT_NAME_FR AS "Month short name french", -- To validate
             MONTH_SHORT_NAME_EN AS "Month short name english", -- To validate
             MONTH_NAME_FR AS "Month name french", -- To validate
             MONTH_NAME_EN AS "Month name english", -- To validate
             MONTH_YEAR_SHORT_NAME_FR AS "Month year short name french", -- To validate
             MONTH_YEAR_SHORT_NAME_EN AS "Mon year short nanme english", -- To validate
             MONTH_YEAR_NAME_FR AS "Month year name french", -- To validate
             MONTH_YEAR_NAME_EN AS "Month year name english", -- To validate
             MONTH_START_DT AS "Month start date", -- To validate
             MONTH_END_DT AS "Month end date", -- To validate
             MONTH_NB_DAY AS "Month number day", -- To validate
             QUARTER_CD AS "Quarter code", -- To validate
             QUARTER_NO AS "Quarter number", -- To validate
             QUARTER_SHORT_NAME_FR AS "Quarter short name english", -- To validate
             QUARTER_SHORT_NAME_EN AS "Quarter short name french", -- To validate
             QUARTER_NAME_FR AS "Quater name french", -- To validate
             QUARTER_NAME_EN AS "Quarter name english", -- To validate
             QUARTER_YEAR_SHORT_NAME_FR AS "Quarter year short name french", -- To validate
             QUARTER_YEAR_SHORT_NAME_EN AS "Quarter year short name english", -- To validate
             QUARTER_YEAR_NAME_FR AS "Quarter year name french", -- To validate
             QUARTER_YEAR_NAME_EN AS "Quarter year name english", -- To validate
             QUARTER_START_DT AS "Quarter start date", -- To validate
             QUARTER_END_DT AS "Quarter end date", -- To validate
             QUARTER_NB_DAY AS "Quarter number day", -- To validate
             SEMESTER_CD AS "Semester code", -- To validate
             SEMESTER_NO AS "Semester number", -- To validate
             SEMESTER_SHORT_NAME_FR AS "Semester short name french", -- To validate
             SEMESTER_SHORT_NAME_EN AS "Semester short name english", -- To validate
             SEMESTER_NAME_FR AS "Semester name french ", -- To validate
             SEMESTER_NAME_EN AS "Semester name english", -- To validate
             SEMESTER_YEAR_SHORT_NAME_FR AS "Semester year short name french", -- To validate
             SEMESTER_YEAR_SHORT_NAME_EN AS "Semester year short name english", -- To validate
             SEMESTER_YEAR_NAME_FR AS "Semester year name french", -- To validate
             SEMESTER_YEAR_NAME_EN AS "Semester year name english", -- To validate
             SEMESTER_START_DT AS "Semester start date", -- To validate
             SEMESTER_END_DT AS "Semester end date", -- To validate
             SEMESTER_NB_DAY AS "Semester number day", -- To validate
             YEAR_CD AS "Year code", -- To validate
             YEAR_SHORT_NAME_FR AS "Year short name french", -- To validate
             YEAR_SHORT_NAME_EN AS "Year short name english", -- To validate
             YEAR_NAME_FR AS "Year name french", -- To validate
             YEAR_NAME_EN AS "Year name english", -- To validate
             YEAR_START_DT AS "Year start date", -- To validate
             YEAR_END_DT AS "Year end date", -- To validate
             YEAR_NB_DAY AS "Year number day" -- To validate
FROM DB_AC_DEV_DM."SHARED".DIM_DATE;
create or replace view VW_DIM_EMPLOYEE(
	ID,
	"Data_start_date",
	"Data_end_date",
	"Hire_date",
	"Original_hired_date",
	"Province_of_employment",
	" Remuneration_type",
	"Hours_per_week",
	"Pay_period",
	"Work_pattern",
	"Job_permanency",
	"Job_category",
	"Location",
	"Manager",
	"Organization_name",
	"Terminated",
	"Termination_date",
	"Termination_reason_code",
	"Salary",
	"Salary_effective_date",
	"On_leave",
	"Leave_start_date",
	"Leave_end_date",
	"Leave_reason_code",
	"Work_permit_type",
	"Work_permit_start_date",
	"Work_permit_end_date",
	"Retired",
	"Retirement_Date",
	"Retirement_expected",
	"Expected_Retirement_date"
) as 

SELECT ID,
       MD_START_DT AS "Data_start_date",
       MD_END_DT AS "Data_end_date",
       HIRE_DATE AS "Hire_date",
       ORIGINAL_HIRED_DATE AS "Original_hired_date",  -- To validate
       PROVINCE_OF_EMPLOYMENT AS "Province_of_employment", 
       REMUNERATION_TYPE AS " Remuneration_type",
       HOURS_PER_WEEK AS "Hours_per_week", 
       PAY_PERIOD AS "Pay_period",
       WORK_PATTERN As "Work_pattern", -- To validate
       JOB_PERMANENCY AS "Job_permanency", 
       JOB_CATEGORY AS "Job_category", 
       LOCATION AS "Location",
       IS_MANAGER AS "Manager", -- To validate
       ORGANIZATION_NAME As "Organization_name", 
       TERMINATED AS "Terminated",
       TERMINATION_DATE As "Termination_date", 
       TERMINATION_REASON_CODE AS "Termination_reason_code", -- To validate 
       SALARY AS "Salary",
       SALARY_EFFECTIVE_DATE AS "Salary_effective_date", -- To validate
       ON_LEAVE AS "On_leave", -- To validate 
       LEAVE_START_DATE AS "Leave_start_date", -- To validate
       LEAVE_END_DATE AS "Leave_end_date", -- To validate
       LEAVE_REASON_CODE AS "Leave_reason_code", -- To validate
       WORK_PERMIT_TYPE As  "Work_permit_type",
       WORK_PERMIT_START_DATE AS "Work_permit_start_date",
       WORK_PERMIT_END_DATE AS "Work_permit_end_date", 
       RETIRED AS "Retired", -- To validate 
       RETIREMENT_DATE AS "Retirement_Date", -- To validate
       RETIREMENT_EXPECTED AS "Retirement_expected", -- To validate
       EXPECTED_RETIREMENT_DATE AS "Expected_Retirement_date" -- To validate


FROM DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE;
create or replace view VW_DIM_HOUR(
	"ID_hour",
	"Hour_of_day",
	"Hour_12h_format_short",
	"Hour_12h_format",
	"Hour_24h_format",
	"Start_time",
	"End_time",
	"Part_of_day_FR",
	"Part_of_day_EN"
) as 

SELECT ID_DIM_HOUR AS "ID_hour", -- To validate
             HOUR_OF_DAY AS "Hour_of_day", -- To validate
             HOUR_12H_FORMAT_SHORT AS "Hour_12h_format_short", -- To validate
             HOUR_12H_FORMAT AS "Hour_12h_format", -- To validate
             HOUR_24H_FORMAT AS "Hour_24h_format", -- To validate
             START_TIME AS "Start_time", -- To validate
             END_TIME AS "End_time", -- To validate
             PART_OF_DAY_FR AS "Part_of_day_FR", -- To validate
             PART_OF_DAY_EN AS "Part_of_day_EN" -- To validate
FROM DB_AC_DEV_DM.SHARED.DIM_HOUR;
create or replace schema SHARED_EXPLORATION;

create or replace view DIM_EMPLOYEE(
	ID,
	MD_START_DT,
	MD_END_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HIRE_DATE,
	YEARS_OF_SERVICE,
	PROVINCE_OF_EMPLOYMENT,
	REMUNERATION_TYPE,
	BASE_SALARY,
	SALARY_BRACKET,
	SALARY_BRACKET_ORDER,
	HOURS_PER_WEEK,
	PAY_PERIOD,
	WORK_PATTERN,
	JOB_PERMANENCY,
	JOB_CATEGORY,
	LOCATION,
	ORGANIZATION_NAME,
	WORKER_NUMBER,
	WORK_PERMIT_TYPE,
	WORK_PERMIT_START_DATE,
	WORK_PERMIT_END_DATE
) as (
  SELECT 
    e.ID as ID,
    e.MD_START_DT AS MD_START_DT, --'Start Date of the image/version',
    NULL AS MD_END_DT, --  'End Date of the image/version'
    CURRENT_TIMESTAMP as MD_CREATION_DT, -- 'Creation Date Time of the occurrence'
    e.MD_SOURCE AS MD_SOURCE, -- 'Represents the source system, file, etc. of the instance'
    HIRE_DATE as hire_date,
    TOOLS.age_in_years(TO_DATE(HIRE_DATE), CURRENT_DATE ) as years_of_service,
    PROVINCE_OF_EMPLOYMENT as province_of_employment,
    REMUNERATION_TYPE as remuneration_type,
    BASE_SALARY as base_salary,
    CASE WHEN BASE_SALARY < 20000
            THEN '< 20000$'
          WHEN BASE_SALARY >= 20000 and BASE_SALARY < 50000
            THEN '20000$ to 50000$'
          WHEN BASE_SALARY >= 50000 and BASE_SALARY < 80000
            THEN '50000$ to 80000$'
          WHEN BASE_SALARY >= 80000 and BASE_SALARY < 120000
            THEN '80000$ to 120000$'
          ELSE '120000$ or more'
    END as salary_bracket,
       CASE WHEN BASE_SALARY < 20000
            THEN '1'
          WHEN BASE_SALARY >= 20000 and BASE_SALARY < 50000
            THEN '2'
          WHEN BASE_SALARY >= 50000 and BASE_SALARY < 80000
            THEN '3'
          WHEN BASE_SALARY >= 80000 and BASE_SALARY < 120000
            THEN '4'
          ELSE '5'
    END as salary_bracket_order,
    HOURS_PER_WEEK as hours_per_week,
    PAY_PERIOD as pay_period,
    WORK_PATTERN as work_pattern,
    JOB_PERMANENCY as job_permanency,
    JOB_CATEGORY as job_category,
    coalesce(LOCATION,'unknown') as location,
    ORGANIZATION_NAME as organization_name,
    coalesce(WORKER_NUMBER,'not specified') as worker_number,
    coalesce(TYPE,'not specified') as work_permit_type,
    coalesce(LEFT(START_DATE,10),'unknown') as work_permit_start_date,
    coalesce(LEFT(END_DATE,10),'unknown') as work_permit_end_date
  FROM DB_AC_DEV_STG.PLT_MODEL_SHARED_EXPL.VW_EMPLOYEE_EXPL e
  LEFT JOIN DB_AC_DEV_STG.PLT_MODEL_SHARED_EXPL.VW_WORKPERMIT_EXPL p on e.ID = p.WORKER_ID
);
create or replace view DIM_PERIOD(
	ID,
	MD_CREATION_DT,
	MD_SOURCE,
	DATE,
	YEAR,
	MONTH,
	DAY,
	MONTH_NAME,
	MONTH_FULL_NAME,
	MONTH_YEARS,
	YYYYMM,
	DAY_OF_WEEK,
	DAY_OF_WEEK_NAME,
	IS_WEEKEND,
	QUARTER,
	QUARTER_NO,
	DAY_OF_YEAR,
	WEEK_OF_YEAR,
	FIRST_DAY_OF_MONTH,
	LAST_DAY_OF_MONTH,
	FIRST_DAY_OF_QUARTER,
	LAST_DAY_OF_QUARTER
) as (
   WITH CTE_MY_DATE AS (
      SELECT DATEADD(DAY, SEQ4(), '2018-01-01') AS MY_DATE
      FROM TABLE(GENERATOR(ROWCOUNT=>5000))  -- Number of days after reference date in previous line
  )

select MY_DATE as ID,
       CURRENT_TIMESTAMP as MD_CREATION_DT,
       'script generated' as MD_SOURCE,
       MY_DATE as date,
       YEAR(MY_DATE) as year,
       MONTH(MY_DATE) as month,
       DAY(MY_DATE) as day,
       MONTHNAME(MY_DATE) as month_name,
       case 
           when MONTHNAME(MY_DATE) = 'Jan' then 'January'
           when MONTHNAME(MY_DATE) = 'Feb' then 'February'
           when MONTHNAME(MY_DATE) = 'Mar' then 'March'
           when MONTHNAME(MY_DATE) = 'Apr' then 'April'
           when MONTHNAME(MY_DATE) = 'Jun' then 'June'
           when MONTHNAME(MY_DATE) = 'Jul' then 'July'
           when MONTHNAME(MY_DATE) = 'Aug' then 'August'
           when MONTHNAME(MY_DATE) = 'Sep' then 'September'
           when MONTHNAME(MY_DATE) = 'Oct' then 'October'
           when MONTHNAME(MY_DATE) = 'Nov' then 'November'
           when MONTHNAME(MY_DATE) = 'Dec' then 'December'
           else MONTHNAME(MY_DATE)
       end as month_full_name,
       MONTHNAME(MY_DATE)||'. '||YEAR(MY_DATE) as month_years, 
       YEAR(MY_DATE) * 100 + MONTH(MY_DATE) as yyyymm ,
       DAYOFWEEK(MY_DATE) as day_of_week,
       DAYNAME(MY_DATE) as day_of_week_name,
       case
        when DAYOFWEEK(MY_DATE) between 1 and 5 then 0
        else 1
       end as is_weekend,
       'Q'||QUARTER(MY_DATE) as quarter,
       QUARTER(MY_DATE) as quarter_no,
       DAYOFYEAR(MY_DATE) as day_of_year,
       WEEKOFYEAR(MY_DATE) as week_of_year,
       DATE_TRUNC('month',MY_DATE) as first_day_of_month,
       LAST_DAY(MY_DATE,'month') as last_day_of_month,
       DATE_TRUNC('quarter',MY_DATE) as first_day_of_quarter,
       LAST_DAY(MY_DATE,'quarter') as last_day_of_quarter
from CTE_MY_DATE
  );
create or replace view DIM_PERSONAL_INTEREST(
	ID,
	MD_START_DT,
	MD_END_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	NAME_FR,
	NAME_EN,
	TAGS
) as 
SELECT   
        INTEREST_ID as ID,
        MD_START_DT,                                    -- 'Start Date of the image/version'
        NULL as MD_END_DT,                                              -- 'End Date of the image/version' 
        CURRENT_TIMESTAMP as MD_CREATION_DT,                            -- 'Creation Date Time of the occurrence'
        MD_SOURCE,                              -- 'Represents the source system, file, etc. of the instance',                      
        NAME_FR as name_fr,       
        NAME_EN as name_en,
        Tags        
   FROM DB_AC_DEV_STG.PLATEFORME_RECEPTION.VW_U_PERSONAL_INTEREST;
create or replace view DIM_PRODUCT(
	ID,
	MD_START_DT,
	MD_END_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	SKU,
	NAME_EN,
	NAME_FR,
	APPENDIXES,
	AVAILABILITY_START_DATE,
	AVAILABILITY_END_DATE,
	AVAILABLE_FOR,
	BASE_PRICE,
	CATEGORY,
	COVERAGE_TYPE,
	COVERAGE_TYPE_FR,
	DISPLAY_ORDER,
	IS_PACKAGE,
	MIN_PRICE,
	MAX_PRICE,
	NOTES_EN,
	NOTES_FR,
	ORGANIZATION_NAME,
	PACKAGE_CONTENT,
	COVERAGE_TYPE_EN,
	PRODUCT_CATALOG_NAME,
	PROVIDER_ID,
	TAGS,
	CHARACTERISTICS
) as 
SELECT   
        product_Id as ID,
        MD_START_DT,                                    -- 'Start Date of the image/version'
        NULL as MD_END_DT,                                              -- 'End Date of the image/version' 
        CURRENT_TIMESTAMP as MD_CREATION_DT,                            -- 'Creation Date Time of the occurrence'
        MD_SOURCE,                              -- 'Represents the source system, file, etc. of the instance',
        SKU as sku,
        name_en as name_en,
        name_fr as name_fr,
        APPENDIXES as appendixes, 
        availability_Start_Date as availability_start_date,
        availability_End_Date as availability_end_date,  
        available_For as available_for,                  
        base_price as base_price,
        category as category,
        coverage_type as coverage_type,  
        coverage_type_fr as coverage_type_fr,
        display_order as display_order,
        is_package as is_package,
        min_price as min_price,
        max_price as max_price,
        notes_en as notes_en,
        notes_fr as notes_fr,
        organization_name as organization_name,
        package_content as package_content,
        coverage_type_en as coverage_type_en,
        product_catalog_name as product_catalog_name, 
        provider_id as provider_id,
        tags as tags,
        characteristics as characteristics        
   FROM DB_AC_DEV_STG.PLT_MODEL_SHARED_EXPL.VW_PRODUCT_EXPL;
create or replace view FACT_CUSTOMER_PERSONAL_INTEREST(
	ID,
	MD_START_DT,
	MD_END_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	INTEREST_ID,
	CUSTOMER_ID,
	EMPLOYEE_ID
) as 
    SELECT   
            CONCAT(dimCustomer.ID,dimPersonalInterest.ID) as ID,
            customer.MD_START_DT,                                    -- 'Start Date of the image/version'
            NULL as MD_END_DT,                                              -- 'End Date of the image/version' 
            CURRENT_TIMESTAMP as MD_CREATION_DT,                            -- 'Creation Date Time of the occurrence'
            customer.MD_SOURCE,                             -- 'Represents the source system, file, etc. of the instance',                      
            dimPersonalInterest.ID AS INTEREST_ID,
            dimCustomer.ID AS CUSTOMER_ID,        
            dimEmployee.ID AS EMPLOYEE_ID
       FROM DB_AC_DEV_STG.PLATEFORME_RECEPTION.VW_U_CUSTOMER_PERSONAL_INTEREST customer
 INNER JOIN DB_AC_DEV_DWH.SUBSCRIPTION_RDV.LINK_SUBSCRIPTION subscription
         ON subscription.CUSTOMER_ID = customer.CUSTOMER_ID
 INNER JOIN DB_AC_DEV_DM.SHARED.DIM_CUSTOMER dimCustomer
         ON subscription.HK_HUB_CUSTOMER = dimCustomer.HK_HUB
        AND dimCustomer.MD_END_DT IS NULL
 INNER JOIN DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE dimEmployee
         ON subscription.HK_HUB_WORKER = dimEmployee.HK_HUB
        AND dimEmployee.MD_END_DT IS NULL
 INNER JOIN DB_AC_DEV_DM.SHARED_EXPLORATION.DIM_PERSONAL_INTEREST dimPersonalInterest
         ON dimPersonalInterest.ID = customer.INTEREST_ID;
create or replace view VW_DIM_ADMINISTRATIVE_ENTITIE_PARTIAL(
	POSTAL_CODE_PARTIAL,
	ADMINISTRATIVE_REGION
) as
(
    SELECT DISTINCT sat.POSTAL_CODE_ABBR as POSTAL_CODE_PARTIAL, sat.ADMINISTRATIVE_REGION
      FROM DB_AC_DEV_DWH.SHARED_RDV.HUB_ADMINISTRATIVE_ENTITIES hub
 INNER JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_ADMINISTRATIVE_ENTITIES sat
        ON hub.HK_HUB = sat.HK_HUB
     WHERE sat.POSTAL_CODE_ABBR NOT IN (SELECT POSTAL_CODE_ABBR 
                                             FROM DB_AC_DEV_STG.DATALAKE.VW_U_ADMINISTRATIVE_ENTITIES_RECEP
                                            WHERE POSTAL_CODE_ABBR 
                                               IN (
                                                    SELECT POSTAL_CODE_ABBR 
                                                      FROM (
                                                            SELECT POSTAL_CODE_ABBR, sum(cpt) AS compte_total 
                                                              FROM (
                                                                    SELECT POSTAL_CODE_ABBR, ADMINISTRATIVE_REGION, 1 AS cpt  
                                                                    FROM DB_AC_DEV_STG.DATALAKE.VW_U_ADMINISTRATIVE_ENTITIES_RECEP
                                                                    GROUP BY POSTAL_CODE_ABBR, ADMINISTRATIVE_REGION) test
                                                           GROUP BY POSTAL_CODE_ABBR) totale
                                                              WHERE compte_total > 1
                                                           )
                                          GROUP BY POSTAL_CODE_ABBR)    
);
create or replace schema SHARED_WT;

create or replace TABLE WT_DIM_CAMPAIGN (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	CAMPAIGN_ID VARCHAR(16777216) COMMENT 'Platform Shopping Request Id',
	TYPE VARCHAR(16777216) COMMENT 'Campaign Type',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Name of the organisation',
	WORKER_GROUP VARCHAR(16777216) COMMENT 'Name of worker group',
	JOB_CATEGORY VARCHAR(16777216) COMMENT 'the name of job category',
	GROUP_TYPE_CODE VARCHAR(16777216) COMMENT 'group type code',
	GROUP_REFERENCES VARCHAR(16777216) COMMENT ' group references',
	SCHEDULED_TIME TIME(7),
	BEGINS_ON TIMESTAMP_NTZ(9) COMMENT 'campaign start date',
	ENDS_ON TIMESTAMP_NTZ(9) COMMENT 'campaign end date',
	BENEFITS_EFFECTIVE_DATE DATE COMMENT 'The date on which benefits will start',
	ELIGIBILITY_RULE_SET VARCHAR(16777216) COMMENT 'rule for eligibility of the benefits',
	IS_STARTED BOOLEAN COMMENT 'campaign is on way or not'
);
create or replace TABLE WT_DIM_CUSTOMER (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	AGE_GROUP VARCHAR(16777216) COMMENT 'Age group',
	AGE_GROUP_SORT NUMBER(38,0) COMMENT 'sort order for the age group attribute',
	GENDER VARCHAR(16777216) COMMENT 'Individual Gender',
	POSTAL_CODE_PARTIAL VARCHAR(16777216) COMMENT 'Personal address partial postal code',
	PROVINCE VARCHAR(16777216) COMMENT 'Personal address Province',
	COUNTRY VARCHAR(16777216) COMMENT 'Personal address Counrty'
);
create or replace TABLE WT_DIM_EMPLOYEE (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_END_DT TIMESTAMP_NTZ(9) COMMENT 'End Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_MODIFY_DT TIMESTAMP_NTZ(9) COMMENT 'Modification Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_MODIFY_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Capabilities for RLS',
	HIRE_DATE DATE COMMENT 'Employee hire DATE',
	ORIGINAL_HIRED_DATE DATE COMMENT 'Employee original hired date',
	PROVINCE_OF_EMPLOYMENT VARCHAR(16777216) COMMENT 'Employee Province of employement',
	REMUNERATION_TYPE VARCHAR(16777216) COMMENT 'Employee remuneration type',
	HOURS_PER_WEEK NUMBER(38,2) COMMENT 'Employee hours per week',
	PAY_PERIOD VARCHAR(16777216) COMMENT 'Employee pay periode',
	WORK_PATTERN VARCHAR(16777216) COMMENT 'Employee work pattern',
	JOB_PERMANENCY VARCHAR(16777216) COMMENT 'Employee job permanency',
	JOB_CATEGORY VARCHAR(16777216) COMMENT 'Employee job Category ',
	LOCATION VARCHAR(16777216) COMMENT 'Employee Location',
	IS_MANAGER VARCHAR(16777216) COMMENT 'Employee is a manager',
	ORGANIZATION_NAME VARCHAR(16777216) COMMENT 'organization name',
	TERMINATED VARCHAR(16777216) COMMENT 'Terminated predicate',
	TERMINATION_DATE DATE COMMENT 'Termination DATE',
	TERMINATION_REASON_CODE VARCHAR(16777216) COMMENT 'Termination reason code',
	SALARY NUMBER(38,2) COMMENT 'Salary',
	SALARY_EFFECTIVE_DATE DATE COMMENT 'Salary effective DATE',
	ON_LEAVE VARCHAR(16777216) COMMENT 'On leave predicate',
	LEAVE_START_DATE DATE COMMENT 'Leave start DATE',
	LEAVE_END_DATE DATE COMMENT 'Leave end DATE',
	LEAVE_REASON_CODE VARCHAR(16777216) COMMENT 'Leave reason code',
	WORK_PERMIT_TYPE VARCHAR(16777216) COMMENT ' Work permit type',
	WORK_PERMIT_START_DATE DATE COMMENT 'Work permit start DATE',
	WORK_PERMIT_END_DATE DATE COMMENT 'Work permit end DATE',
	RETIRED VARCHAR(16777216) COMMENT 'Retired predicate',
	RETIREMENT_DATE DATE COMMENT 'Retirement date',
	RETIREMENT_EXPECTED VARCHAR(16777216) COMMENT 'Retirement expected predicate',
	EXPECTED_RETIREMENT_DATE DATE COMMENT 'Expected retirement date'
);
create or replace view VW_DIM_WT_CAMPAIGN(
	HK_HUB,
	MD_START_DT,
	MD_END_DT,
	MD_HASH_NAT_KEYS,
	MD_HASHDIFF_TYPE1,
	MD_HASHDIFF_TYPE2,
	MD_CREATION_DT,
	MD_MODIFY_DT,
	MD_SOURCE,
	MD_CREATION_AUDIT_ID,
	MD_MODIFY_AUDIT_ID,
	MD_SECURITY_TYPE,
	CAMPAIGN_ID,
	TYPE,
	ORGANIZATION_ID,
	WORKER_GROUP,
	JOB_CATEGORY,
	GROUP_TYPE_CODE,
	GROUP_REFERENCES,
	SCHEDULED_TIME,
	BEGINS_ON,
	ENDS_ON,
	BENEFITS_EFFECTIVE_DATE,
	ELIGIBILITY_RULE_SET,
	IS_STARTED
) as  (
    
  
  SELECT 
    
	HK_HUB ,
	MD_START_DT ,
	MD_END_DT ,
    HK_HUB AS MD_HASH_NAT_KEYS,
	'N/A' AS MD_HASHDIFF_TYPE1 ,    -- WT_DIM
	DB_AC_DEV_DM.SHARED_WT.UF_HASHDIFF_TYPE2_CAMPAIGN (TYPE,ORGANIZATION_ID, WORKER_GROUP,JOB_CATEGORY,GROUP_TYPE_CODE,GROUP_REFERENCES,SCHEDULED_TIME, BEGINS_ON,ENDS_ON,BENEFITS_EFFECTIVE_DATE ,ELIGIBILITY_RULE_SET, IS_STARTED) AS MD_HASHDIFF_TYPE2, 
	CURRENT_TIMESTAMP AS MD_CREATION_DT ,
	MD_MODIFY_DT ,
	MD_SOURCE ,
	MD_CREATION_AUDIT_ID ,
	MD_MODIFY_AUDIT_ID ,
	MD_SECURITY_TYPE ,
    CAMPAIGN_ID,
    TYPE,
	ORGANIZATION_ID,
	WORKER_GROUP,
	JOB_CATEGORY,
	GROUP_TYPE_CODE,
	GROUP_REFERENCES,
	SCHEDULED_TIME,
	BEGINS_ON,
	ENDS_ON,
	BENEFITS_EFFECTIVE_DATE,
	ELIGIBILITY_RULE_SET,
	IS_STARTED
    from DB_AC_DEV_DM.SHARED_WT.WT_DIM_CAMPAIGN);
create or replace view VW_DIM_WT_CUSTOMER(
	HK_HUB,
	MD_START_DT,
	MD_END_DT,
	MD_HASH_NAT_KEYS,
	MD_HASHDIFF_TYPE1,
	MD_HASHDIFF_TYPE2,
	MD_CREATION_DT,
	MD_MODIFY_DT,
	MD_SOURCE,
	MD_CREATION_AUDIT_ID,
	MD_MODIFY_AUDIT_ID,
	MD_SECURITY_TYPE,
	AGE_GROUP,
	AGE_GROUP_SORT,
	GENDER,
	POSTAL_CODE_PARTIAL,
	PROVINCE,
	COUNTRY
) as  (
    
  
  SELECT 
    
	HK_HUB ,
	MD_START_DT ,
	MD_END_DT ,
    HK_HUB AS MD_HASH_NAT_KEYS,
	'N/A' AS MD_HASHDIFF_TYPE1 ,    -- WT_DIM
	SHA1( 
                UPPER( 
                    
                    NVL(RTRIM(LTRIM(AGE_GROUP)),'#NULL#')  
                    || '|' ||
                    NVL(RTRIM(LTRIM(GENDER)),'#NULL#')
                    || '|' ||
                    NVL(RTRIM(LTRIM(POSTAL_CODE_PARTIAL)),'#NULL#')
                    || '|' ||
                    NVL(RTRIM(LTRIM(PROVINCE)),'#NULL#')
                    || '|' ||
                    NVL(RTRIM(LTRIM(COUNTRY)),'#NULL#')
                  
                ) 
           )::string AS MD_HASHDIFF_TYPE2, 
	CURRENT_TIMESTAMP AS MD_CREATION_DT ,
	MD_MODIFY_DT ,
	MD_SOURCE ,
	MD_CREATION_AUDIT_ID ,
	MD_MODIFY_AUDIT_ID ,
	MD_SECURITY_TYPE ,
  
	AGE_GROUP,
    AGE_GROUP_SORT,
	GENDER ,

	POSTAL_CODE_PARTIAL ,
	PROVINCE ,
	COUNTRY 
   from DB_AC_DEV_DM.SHARED_WT.WT_DIM_CUSTOMER);
create or replace view VW_DIM_WT_EMPLOYEE(
	HK_HUB,
	MD_START_DT,
	MD_END_DT,
	MD_HASH_NAT_KEYS,
	MD_HASHDIFF_TYPE1,
	MD_HASHDIFF_TYPE2,
	MD_CREATION_DT,
	MD_MODIFY_DT,
	MD_SOURCE,
	MD_CREATION_AUDIT_ID,
	MD_MODIFY_AUDIT_ID,
	MD_SECURITY_TYPE,
	HIRE_DATE,
	ORIGINAL_HIRED_DATE,
	PROVINCE_OF_EMPLOYMENT,
	REMUNERATION_TYPE,
	HOURS_PER_WEEK,
	PAY_PERIOD,
	WORK_PATTERN,
	JOB_PERMANENCY,
	JOB_CATEGORY,
	LOCATION,
	IS_MANAGER,
	ORGANIZATION_NAME,
	TERMINATED,
	TERMINATION_DATE,
	TERMINATION_REASON_CODE,
	SALARY,
	SALARY_EFFECTIVE_DATE,
	ON_LEAVE,
	LEAVE_START_DATE,
	LEAVE_END_DATE,
	LEAVE_REASON_CODE,
	WORK_PERMIT_TYPE,
	WORK_PERMIT_START_DATE,
	WORK_PERMIT_END_DATE,
	RETIRED,
	RETIREMENT_DATE,
	RETIREMENT_EXPECTED,
	EXPECTED_RETIREMENT_DATE
) as  ( 
  SELECT 
	HK_HUB,
	MD_START_DT,
	MD_END_DT,
    HK_HUB AS MD_HASH_NAT_KEYS,
	'N/A' AS MD_HASHDIFF_TYPE1 ,    -- WT_DIM
	SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(HIRE_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(ORIGINAL_HIRED_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(HOURS_PER_WEEK))),'#NULL#')  
                    || '|' ||
                    NVL(RTRIM(LTRIM(LOCATION)),'#NULL#')
                    || '|' ||
                    NVL(RTRIM(LTRIM(ORGANIZATION_NAME)),'#NULL#')
                    || '|' ||
                    NVL(RTRIM(LTRIM(JOB_CATEGORY)),'#NULL#') 
                    || '|' ||
                    NVL(RTRIM(LTRIM(JOB_PERMANENCY)),'#NULL#') 
                    || '|' ||
                    NVL(RTRIM(LTRIM(PAY_PERIOD)),'#NULL#') 
                    || '|' ||
                    NVL(RTRIM(LTRIM(PROVINCE_OF_EMPLOYMENT)),'#NULL#') 
                    || '|' ||
                    NVL(RTRIM(LTRIM(REMUNERATION_TYPE)),'#NULL#') 
                    || '|' ||
                    NVL(RTRIM(LTRIM(IS_MANAGER)),'#NULL#') 
                    || '|' ||
                    NVL(RTRIM(LTRIM(WORK_PATTERN)),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TERMINATED)),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(TERMINATION_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#')
                    || '|' || 
                    NVL(RTRIM(LTRIM(TERMINATION_REASON_CODE)),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(SALARY))),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(SALARY_EFFECTIVE_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#')
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(LEAVE_END_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(LEAVE_START_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#')  
                    || '|' || 
                    NVL(RTRIM(LTRIM(ON_LEAVE)),'#NULL#')
                    ||
                    NVL(RTRIM(LTRIM(LEAVE_REASON_CODE)),'#NULL#')
                    ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(WORK_PERMIT_END_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(WORK_PERMIT_START_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#')  
                    || '|' ||
                    NVL(RTRIM(LTRIM(WORK_PERMIT_TYPE)),'#NULL#')
                    || '|' || 
                    NVL(RTRIM(LTRIM(RETIRED)),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(RETIREMENT_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#')
                    || '|' || 
                    NVL(RTRIM(LTRIM(RETIREMENT_EXPECTED)),'#NULL#') 
                    || '|' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(EXPECTED_RETIREMENT_DATE, 'yyyy-mm-dd hh24:mi:ss.ff3'))),'#NULL#') 
                ) 
               )::string AS MD_HASHDIFF_TYPE2, 
	CURRENT_TIMESTAMP AS MD_CREATION_DT ,
	MD_MODIFY_DT ,
	MD_SOURCE ,
	MD_CREATION_AUDIT_ID ,
	MD_MODIFY_AUDIT_ID ,
	MD_SECURITY_TYPE ,
	HIRE_DATE,
    ORIGINAL_HIRED_DATE,
	PROVINCE_OF_EMPLOYMENT,
	REMUNERATION_TYPE,
	HOURS_PER_WEEK,
	PAY_PERIOD,
	WORK_PATTERN,
	JOB_PERMANENCY,
	JOB_CATEGORY,
	LOCATION,
    IS_MANAGER,
    
    ORGANIZATION_NAME,  
  
    TERMINATED,
	TERMINATION_DATE,
    TERMINATION_REASON_CODE,
    
    SALARY,
	SALARY_EFFECTIVE_DATE,
    
    ON_LEAVE,
	LEAVE_START_DATE,
	LEAVE_END_DATE,
    LEAVE_REASON_CODE,

    WORK_PERMIT_TYPE,
	WORK_PERMIT_START_DATE,
	WORK_PERMIT_END_DATE,
  
    RETIRED,
    RETIREMENT_DATE,
    RETIREMENT_EXPECTED,
    EXPECTED_RETIREMENT_DATE
    
 from DB_AC_DEV_DM.SHARED_WT.WT_DIM_EMPLOYEE);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SHARED_WT_DIM_CAMPAIGN"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216), "SECURITY_TYPE" VARCHAR(16777216), "MD_SORUCE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
DEL_QUERY =  "DELETE FROM DB_AC_DEV_DM.SHARED_WT.WT_DIM_CAMPAIGN WHERE 1=1";
var DEL_QUERY_ENV = DEL_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement1 = snowflake.createStatement({
  sqlText: DEL_QUERY_ENV
});
var result2_scan = sql_statement1.execute(); 
INS_QUERY =   "INSERT INTO DB_AC_DEV_DM.SHARED_WT.WT_DIM_CAMPAIGN( " +
"HK_HUB,		" +
"MD_START_DT,	" +
"MD_CREATION_DT,	" +
"MD_MODIFY_DT	," +
"MD_SOURCE		," +
"MD_CREATION_AUDIT_ID	," +
"MD_MODIFY_AUDIT_ID		," +
"MD_SECURITY_TYPE		," +
"CAMPAIGN_ID	," +
"TYPE		," +
"ORGANIZATION_ID," +	
"WORKER_GROUP	,	" +
"JOB_CATEGORY	,	" +
"GROUP_TYPE_CODE	," +
"GROUP_REFERENCES,		" +
"SCHEDULED_TIME	,	" +
"BEGINS_ON		," +
"ENDS_ON	," +
"BENEFITS_EFFECTIVE_DATE	,	" +
"ELIGIBILITY_RULE_SET	,	" +
"IS_STARTED	)" +
"select MSTR.HK_HUB," +
"TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')," +
"Systimestamp()," +
"Systimestamp()," +
"DTLS.MD_SOURCE," +
"  ''" + AUDIT_ID + "'' , " +
"  ''" + AUDIT_ID + "'' , " +
"  ''" + SECURITY_TYPE + "'' , " +
"CAMPAIGN_ID," +
"TYPE		," +
"ORGANIZATION_ID	," + 
"WORKER_GROUP	," +
"JOB_CATEGORY ," +
"GROUP_TYPE_CODE," +
"GROUP_REFERENCES ," +
" SCHEDULED_TIME ," +
" BEGINS_ON ," +
" ENDS_ON ," +
"  BENEFITS_EFFECTIVE_DATE," +
"  ELIGIBILITY_RULE_SET," +
"  IS_STARTED" +
 " from DB_AC_DEV_Dwh.shopping_rdv.HUB_CAMPAIGN  mstr join DB_AC_DEV_Dwh.shopping_rdv.SAT_CAMPAIGN dtls on mstr.hk_hub = dtls.hk_hub" ;
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SHARED_WT_DIM_CUSTOMER"("ENV" VARCHAR(1000), "IO_DATA_START_DATE" VARCHAR(1000), "I_MD_SOURCE" VARCHAR(1000), "I_JOB_AUDIT_ID" VARCHAR(1000), "I_MD_SECURITY_TYPE" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_PRE_DEL STRING;
INS_INSERT STRING;

BEGIN
IO_DATA_START_DATE :=CHAR(39)||IO_DATA_START_DATE||CHAR(39);
I_MD_SOURCE :=CHAR(39)||I_MD_SOURCE||CHAR(39);
I_MD_SECURITY_TYPE :=CHAR(39)||I_MD_SECURITY_TYPE||CHAR(39);
INS_PRE_DEL := ''DELETE FROM DB_AC_''||ENV||''_DM.SHARED_WT.WT_DIM_CUSTOMER WHERE 1=1'';
INS_INSERT := ''
INSERT INTO DB_AC_''||ENV||''_DM.SHARED_WT.WT_DIM_CUSTOMER ( 	
HK_HUB	
,MD_START_DT			
,MD_CREATION_DT		
,MD_MODIFY_DT		
,MD_SOURCE		
,MD_CREATION_AUDIT_ID		
,MD_MODIFY_AUDIT_ID		
,MD_SECURITY_TYPE		
,AGE_GROUP		
,AGE_GROUP_SORT		
,GENDER		
,POSTAL_CODE_PARTIAL		
,PROVINCE		
,COUNTRY )
SELECT
	rsh.HK_HUB	
	,TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''')		
	,CURRENT_TIMESTAMP	
	,CURRENT_TIMESTAMP	
	,''||I_MD_SOURCE||''	
	,''||I_JOB_AUDIT_ID||''	
	,''||I_JOB_AUDIT_ID||''	
	,''||I_MD_SECURITY_TYPE||''	
	,dt5.AGE_GROUP	
	,dt5.AGE_GROUP_SORT	
	,rss2.GENDER	
	,dt3.POSTAL_CODE_PARTIAL	
	,dt3.PROVINCE	
	,dt3.COUNTRY
	FROM (
	SELECT *
			FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_INDIVIDUAL_PLT ) rss2 
			JOIN 
			(
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_INDIVIDUAL_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt1 
			ON rss2.HK_HUB = dt1.HK_HUB AND rss2.MD_START_DT = dt1.MAX_MD_START_DT
			JOIN
				(SELECT HK_HUB FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.HUB_CUSTOMER) rsh ON rsh.HK_HUB = rss2.HK_HUB  
		LEFT JOIN
		(
			SELECT dt2.HK_HUB, POSTAL_CODE_PARTIAL, PROVINCE, COUNTRY
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_PERSONAL_ADDRESS_PLT ) rss
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_PERSONAL_ADDRESS_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt2 
			ON rss.HK_HUB = dt2.HK_HUB AND rss.MD_START_DT = dt2.MAX_MD_START_DT
			
		)dt3 ON rsh.HK_HUB = dt3.HK_HUB
		LEFT JOIN
		(
			SELECT dt4.HK_HUB,AGE_GROUP, AGE_GROUP_SORT	
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_BDV.SAT_INDIVIDUAL_PLT_COMPUTE ) sbs
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_BDV.SAT_INDIVIDUAL_PLT_COMPUTE 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt4 
			ON sbs.HK_HUB = dt4.HK_HUB AND sbs.MD_START_DT = dt4.MAX_MD_START_DT
			
		)dt5 ON rsh.HK_HUB = dt5.HK_HUB             
             '';

EXECUTE IMMEDIATE :INS_PRE_DEL;
EXECUTE IMMEDIATE :INS_INSERT;

END
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SHARED_WT_DIM_EMPLOYEE"("ENV" VARCHAR(1000), "IO_DATA_START_DATE" VARCHAR(1000), "I_MD_SOURCE" VARCHAR(1000), "I_JOB_AUDIT_ID" VARCHAR(1000), "I_MD_SECURITY_TYPE" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_PRE_DEL STRING;
INS_INSERT STRING;

BEGIN
IO_DATA_START_DATE :=CHAR(39)||IO_DATA_START_DATE||CHAR(39);
I_MD_SOURCE :=CHAR(39)||I_MD_SOURCE||CHAR(39);
I_MD_SECURITY_TYPE :=CHAR(39)||I_MD_SECURITY_TYPE||CHAR(39);
INS_PRE_DEL := ''DELETE FROM DB_AC_''||ENV||''_DM.SHARED_WT.WT_DIM_EMPLOYEE WHERE 1=1'';
INS_INSERT := ''
INSERT INTO DB_AC_''||ENV||''_DM.SHARED_WT.WT_DIM_EMPLOYEE ( 	
HK_HUB		
,MD_START_DT		
,MD_CREATION_DT		
,MD_MODIFY_DT		
,MD_SOURCE		
,MD_CREATION_AUDIT_ID		
,MD_MODIFY_AUDIT_ID		
,MD_SECURITY_TYPE		
,HIRE_DATE		
,ORIGINAL_HIRED_DATE		
,PROVINCE_OF_EMPLOYMENT		
,REMUNERATION_TYPE		
,HOURS_PER_WEEK		
,PAY_PERIOD		
,WORK_PATTERN		
,JOB_PERMANENCY		
,JOB_CATEGORY		
,LOCATION		
,IS_MANAGER		
,ORGANIZATION_NAME		
,TERMINATED		
,TERMINATION_DATE		
,TERMINATION_REASON_CODE		
,SALARY		
,SALARY_EFFECTIVE_DATE		
,ON_LEAVE		
,LEAVE_START_DATE		
,LEAVE_END_DATE		
,LEAVE_REASON_CODE		
,WORK_PERMIT_TYPE		
,WORK_PERMIT_START_DATE		
,WORK_PERMIT_END_DATE		
,RETIRED		
,RETIREMENT_DATE		
,RETIREMENT_EXPECTED		
,EXPECTED_RETIREMENT_DATE )
SELECT
	rsh.HK_HUB	
	,TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''')	
	,CURRENT_TIMESTAMP	
	,CURRENT_TIMESTAMP	
	,''||I_MD_SOURCE||''	
	,''||I_JOB_AUDIT_ID||''	
	,''||I_JOB_AUDIT_ID||''	
	,''||I_MD_SECURITY_TYPE||''	
	,rss.HIRE_DATE	
	,rss.ORIGINAL_HIRED_DATE	
	,rss.PROVINCE_OF_EMPLOYMENT	
	,rss.REMUNERATION_TYPE	
	,rss.HOURS_PER_WEEK	
	,rss.PAY_PERIOD	
	,rss.WORK_PATTERN	
	,rss.JOB_PERMANENCY	
	,rss.JOB_CATEGORY	
	,rss.LOCATION	
	,rss.IS_MANAGER	
	,dt11.ORGANIZATION_ID	
	,dt5.TERMINATED	
	,dt5.TERMINATION_DATE	
	,dt5.REASON_CODE	
	,dt3.SALARY	
	,dt3.SALARY_EFFECTIVE_DATE	
	,dt7.ON_LEAVE	
	,dt7.LEAVE_START_DATE	
	,dt7.LEAVE_END_DATE	
	,dt7.REASON_CODE	
	,dt9.TYPE	
	,dt9.START_DATE	
	,dt9.END_DATE	
	,dt15.RETIRED	
	,dt15.RETIREMENT_DATE	
	,dt15.EXPECTED	
	,dt15.EXPECTED_RETIREMENT_DATE
	FROM (
	SELECT *
			FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_EMPLOYMENT_INFO_PLT ) rss
			JOIN 
			(
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_EMPLOYMENT_INFO_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt1 
			ON rss.HK_HUB = dt1.HK_HUB AND rss.MD_START_DT = dt1.MAX_MD_START_DT
			JOIN
				(SELECT HK_HUB FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.HUB_WORKER) rsh ON rsh.HK_HUB = rss.HK_HUB  
		JOIN
		(
			SELECT drs2.HK_HUB, SALARY, SALARY_EFFECTIVE_DATE
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_SALARY_PLT ) drs2
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_SALARY_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt2 
			ON drs2.HK_HUB = dt2.HK_HUB AND drs2.MD_START_DT = dt2.MAX_MD_START_DT
			
		)dt3 ON rsh.HK_HUB = dt3.HK_HUB
		LEFT JOIN
		(
			SELECT rss3.HK_HUB, TERMINATED, TERMINATION_DATE, REASON_CODE
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_TERMINATION_STATUS_PLT ) rss3
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_TERMINATION_STATUS_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt4 
			ON rss3.HK_HUB = dt4.HK_HUB AND rss3.MD_START_DT = dt4.MAX_MD_START_DT
			
		)dt5 ON rsh.HK_HUB = dt5.HK_HUB  
		JOIN
		(
			SELECT rss2.HK_HUB, ON_LEAVE, LEAVE_START_DATE, LEAVE_END_DATE, REASON_CODE
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_LEAVE_STATUS_PLT ) rss2
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_LEAVE_STATUS_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt6 
			ON rss2.HK_HUB = dt6.HK_HUB AND rss2.MD_START_DT = dt6.MAX_MD_START_DT
			
		)dt7 ON rsh.HK_HUB = dt7.HK_HUB
		LEFT JOIN
		(
			SELECT drs3.HK_HUB, TYPE, START_DATE, END_DATE
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_WORKER_PERMIT_PLT ) drs3
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_WORKER_PERMIT_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt8 
			ON drs3.HK_HUB = dt8.HK_HUB AND drs3.MD_START_DT = dt8.MAX_MD_START_DT
			
		)dt9 ON rsh.HK_HUB = dt9.HK_HUB
		LEFT JOIN
		(
			SELECT srl.HK_HUB_WORKER, ORGANIZATION_ID
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SUBSCRIPTION_RDV.LINK_SUBSCRIPTION ) srl
			JOIN (
				SELECT HK_HUB_WORKER, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SUBSCRIPTION_RDV.LINK_SUBSCRIPTION 
				WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB_WORKER) AS dt10 
			ON srl.HK_HUB_WORKER = dt10.HK_HUB_WORKER AND srl.MD_START_DT = dt10.MAX_MD_START_DT
			
		)dt11 ON rsh.HK_HUB = dt11.HK_HUB_WORKER
		LEFT JOIN
		(
			SELECT dt12.HK_HUB, RETIRED, RETIREMENT_DATE, EXPECTED, EXPECTED_RETIREMENT_DATE
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_RETIREMENT_STATUS_PLT ) drs
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_RETIREMENT_STATUS_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt12 
			ON drs.HK_HUB = dt12.HK_HUB AND drs.MD_START_DT = dt12.MAX_MD_START_DT
			
		)dt15 ON rsh.HK_HUB = dt15.HK_HUB
             '';

EXECUTE IMMEDIATE :INS_PRE_DEL;
EXECUTE IMMEDIATE :INS_INSERT;

END
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_TYPE2_CAMPAIGN"("TYPE" VARCHAR(16777216), "ORGANIZATION_ID" VARCHAR(16777216), "WORKER_GROUP" VARCHAR(16777216), "JOB_CATEGORY" VARCHAR(16777216), "GROUP_TYPE_CODE" VARCHAR(16777216), "GROUP_REFERENCES" VARCHAR(16777216), "SCHEDULED_TIME" TIME(9), "BEGINS_ON" TIMESTAMP_NTZ(9), "ENDS_ON" TIMESTAMP_NTZ(9), "BENEFITS_EFFECTIVE_DATE" DATE, "ELIGIBILITY_RULE_SET" VARCHAR(16777216), "IS_STARTED" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TYPE)),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(WORKER_GROUP)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(JOB_CATEGORY)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(GROUP_TYPE_CODE)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(GROUP_REFERENCES)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(SCHEDULED_TIME, ''hh24:mi:ss''))),''#NULL#'')  
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(BEGINS_ON, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(ENDS_ON, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(BENEFITS_EFFECTIVE_DATE, ''yyyy-mm-dd''))),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(ELIGIBILITY_RULE_SET)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(IS_STARTED)),''#NULL#'') 
                     
                )  
               )::string

';
create or replace schema SHOPPING;

create or replace TABLE FACT_PLATFORM_ORDER_ITEM (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the Fact',
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Security Type ',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	PLT_ORDER_ID VARCHAR(16777216) COMMENT 'Platform Order ID',
	PLT_PRODUCT_ID VARCHAR(16777216) COMMENT 'Platform Product ID ',
	PLT_CUSTOMER_ID VARCHAR(16777216) COMMENT 'Platform Customer ID',
	PLT_EMPLOYEE_ID VARCHAR(16777216) COMMENT 'Platform Employee ID',
	PRODUCT_ID NUMBER(38,0) COMMENT 'Dimention Product ID',
	CUSTOMER_ID NUMBER(38,0) COMMENT 'Dimension Customer ID',
	EMPLOYEE_ID NUMBER(38,0) COMMENT 'Dimension Employee ID',
	CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Date of the  Order Creation in the platform',
	QUANTITY NUMBER(38,0) COMMENT 'Quantity of the Order item',
	AMOUNT NUMBER(14,2) COMMENT 'Product amount',
	STATUS_DT TIMESTAMP_NTZ(9) COMMENT 'Date of the Order Status in the platform',
	STATUS VARCHAR(50) COMMENT 'Order Status',
	foreign key (EMPLOYEE_ID) references DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE(ID)
);
create or replace TABLE FACT_PLATFORM_SHOPPING_REQUEST (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the Fact',
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Security Type ',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	PLT_SHOPPING_REQUEST_ID VARCHAR(16777216) COMMENT 'Platform Shopping Request ID',
	PLT_PRODUCT_ID VARCHAR(16777216) COMMENT 'Platform Product ID ',
	PLT_CUSTOMER_ID VARCHAR(16777216) COMMENT 'Platform Customer ID',
	PLT_EMPLOYEE_ID VARCHAR(16777216) COMMENT 'Platform Employee ID',
	PRODUCT_ID NUMBER(38,0) COMMENT 'Dimention Product ID',
	CUSTOMER_ID NUMBER(38,0) COMMENT 'Dimension Customer ID',
	EMPLOYEE_ID NUMBER(38,0) COMMENT 'Dimension Employee ID',
	QUANTITY NUMBER(38,0) COMMENT 'Quantity if the shopping request item',
	STATUS_DT TIMESTAMP_NTZ(9) COMMENT 'Date of the Shopping Request in the platform',
	STATUS VARCHAR(50) COMMENT 'Shopping Request Status',
	foreign key (EMPLOYEE_ID) references DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE(ID)
);
create or replace view VW_FACT_PLATFORM_ORDER_ITEM(
	ID,
	START_DATE,
	CREATION_DATE,
	CREATION_AUDIT_ID,
	SECURITY_TYPE,
	SOURCE,
	PLATFORM_ORDER_ID,
	PLATFORM_PRODUCT_ID,
	PLATFORM_CUSTOMER_ID,
	PLATFORME_EMPLOYEE_ID,
	PRODUCT_ID,
	CUSTOMER_ID,
	EMPLOYEE_ID,
	QUANTITY,
	AMOUNT,
	STATUS_DATE,
	STATUS_HOUR,
	STATUS
) as 
SELECT  ID AS ID, -- To validate
             MD_START_DT AS Start_date, -- To validate
             MD_CREATION_DT AS Creation_date,  -- To validate
             MD_CREATION_AUDIT_ID AS Creation_audit_ID, -- To validate
             MD_SECURITY_TYPE AS Security_type, -- To validate
             MD_SOURCE AS Source, -- To validate
             PLT_ORDER_ID AS Platform_Order_ID, -- To validate
             PLT_PRODUCT_ID AS Platform_product_ID, -- To validate
             PLT_CUSTOMER_ID AS Platform_customer_ID, -- To validate
             PLT_EMPLOYEE_ID AS Platforme_employee_ID, -- To validate
             PRODUCT_ID AS Product_ID, -- To validate
             CUSTOMER_ID AS Customer_ID, -- To validate
             EMPLOYEE_ID AS Employee_ID, -- To validate
             QUANTITY AS Quantity, -- To validate
             AMOUNT AS Amount,
             STATUS_DT  AS Status_date, -- To validate
             HOUR(STATUS_DT) AS Status_hour,
             STATUS AS Status -- To validate
FROM DB_AC_DEV_DM.SHOPPING.FACT_PLATFORM_ORDER_ITEM;
create or replace view VW_FACT_PLATFORM_SHOPPING_REQUEST(
	ID,
	START_DATE,
	CREATION_DATE,
	CREATION_AUDIT_ID,
	SECURITY_TYPE,
	SOURCE,
	PLATFORM_SHOPPING_REQUEST_ID,
	PLATFORM_PRODUCT_ID,
	PLATFORM_CUSTOMER_ID,
	PLATDORME_EMPLOYEE_ID,
	PRODUCT_ID,
	CUSTOMER_ID,
	EMPLOYEE_ID,
	QUANTITY,
	STATUS_DATE,
	STATUS_HOUR,
	STATUS
) as 

SELECT  ID AS ID, -- To validate
             MD_START_DT AS Start_date, -- To validate
             MD_CREATION_DT AS Creation_date,  -- To validate
             MD_CREATION_AUDIT_ID AS Creation_audit_ID, -- To validate
             MD_SECURITY_TYPE AS Security_type, -- To validate
             MD_SOURCE AS Source, -- To validate
             PLT_SHOPPING_REQUEST_ID AS Platform_Shopping_request_ID, -- To validate
             PLT_PRODUCT_ID AS Platform_product_ID, -- To validate
             PLT_CUSTOMER_ID AS Platform_customer_ID, -- To validate
             PLT_EMPLOYEE_ID AS Platdorme_employee_ID, -- To validate
             PRODUCT_ID AS Product_ID, -- To validate
             CUSTOMER_ID AS Customer_ID, -- To validate
             EMPLOYEE_ID AS Employee_ID, -- To validate
             QUANTITY AS Quantity, -- To validate
             STATUS_DT  AS Status_date, -- To validate
             HOUR(STATUS_DT) AS Status_hour,
             STATUS AS Status -- To validate

FROM DB_AC_DEV_DM.SHOPPING.FACT_PLATFORM_SHOPPING_REQUEST;
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHOPPING_RDV_TO_DM_SHOPPING_FACT_ORDER_ITEM"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =   "insert into DB_AC_DEV_Dm.shopping.FACT_PLATFORM_ORDER_ITEM(HK_LINK, " +
"MD_START_DT, " +
"MD_CREATION_DT, " +
"MD_CREATION_AUDIT_ID, " +
"MD_SOURCE, " +
"PLT_ORDER_ID, " +
"PLT_PRODUCT_ID, " +
"PLT_CUSTOMER_ID, " +
"PLT_EMPLOYEE_ID, " +
"PRODUCT_ID, " +
"CUSTOMER_ID, " +
"EMPLOYEE_ID, " +
"CREATION_DT, " +
"QUANTITY, " +
"AMOUNT, " +
"STATUS_DT, " +
"STATUS) " +
"with t1 as (select dtls.hk_hub_customer as lnk_customer,mstr.hk_link as order_hk_link,hk_hub_product as HK_order_HUB_PRODUCT,mstr.ORDER_ID as PLT_ORDER_ID, " +
"mstr.product_id as PLT_PRODUCT_ID,dtls.customer_id as PLT_customer_ID, " +
"dtls.MD_SOURCE as lnk_order_MD_SOURCE from  " +
"DB_AC_DEV_DWH.shopping_rdv.LINK_ORDER_ITEM mstr join DB_AC_DEV_DWH.shopping_rdv.LINK_ORDER_CUSTOMER dtls on mstr.hk_hub_order = dtls.hk_hub_order  " +
"where mstr.MD_CREATION_DT>= ''" + IO_START_DT + "'' AND mstr.MD_CREATION_DT <''" + IO_START_DT + "''), " +
" t2 as(select lnk_customer, order_hk_link,dtls.worker_id as plt_employee_ID ,HK_order_HUB_PRODUCT , PLT_ORDER_ID,PLT_PRODUCT_ID,PLT_customer_ID, lnk_order_MD_SOURCE, hk_hub_worker from t1  " +
" mstr left outer join DB_AC_DEV_DWH.SUBSCRIPTION_rdv.LINK_SUBSCRIPTION dtls on hk_hub_customer =  lnk_customer), " +
" t3 as(select QUANTITY  as link_order_quantity,lnk_order_hk_LINK,amount as sat_link_amount from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_ORDER_ITEM_PLT MSTR JOIN ( " +
"  select HK_LINK as lnk_order_hk_LINK,max(md_start_dt) as max_md_start_dt from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_ORDER_ITEM_PLT  " +
"  where MD_START_DT <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_LINK) as dtls  " +
"  on mstr.HK_LINK = lnk_order_hk_LINK and mstr.md_start_dt = dtls.max_md_start_dt), " +
" t4 as(SELECT * FROM t2 join T3 on order_hk_link  = lnk_order_hk_LINK), " +
" t5 as(select mstr.creation_date as sat_order_plt_creation_dt,lnk_sat_order_hk_hub from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_PLT MSTR JOIN ( " +
"  select HK_hub as lnk_sat_order_hk_hub,max(md_start_dt) as max_md_start_dt from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_PLT  " +
"  where MD_START_DT <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_hub) as dtls  " +
"  on mstr.HK_hub = lnk_sat_order_hk_hub and mstr.md_start_dt = dtls.max_md_start_dt), " +
"  t6 as(select * from t4 join t5 on order_hk_link = lnk_sat_order_hk_hub), " +
"  t7 as(select lnk_sat_order_status_hk_hub, status, status_date from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_STATUS_PLT MSTR JOIN ( " +
"  select HK_hub as lnk_sat_order_status_hk_hub,max(md_start_dt) as max_md_start_dt from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_STATUS_PLT  " +
"  where MD_START_DT <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_hub) as dtls  " +
"  on mstr.HK_hub = lnk_sat_order_status_hk_hub and mstr.md_start_dt = dtls.max_md_start_dt), " +
"  t8 as(select * from t6 join t7 on lnk_sat_order_status_hk_hub = lnk_sat_order_status_hk_hub), " +
"  t9 as(select * from t8 left outer join (select hk_hub, id as employee_id from DB_AC_DEV_DM.SHared.DIM_EMPLOYEE) dtls on hk_hub_worker = dtls.hk_hub), " +
"  t10 as (select * FROM t9 left outer join (select hk_hub, id as customer_id  from DB_AC_DEV_DM.SHared.DIM_CUSTOMER) dtls on lnk_customer = dtls.hk_hub) " +
"  select order_hk_link, " +
"  ''" + IO_START_DT + "'', " +
"   systimestamp(), " +
"   ''" + AUDIT_ID + "'', " +
"   lnk_order_MD_SOURCE, " +
"   PLT_ORDER_ID, " +
"   PLT_PRODUCT_ID, " +
"   plt_customer_id, " +
"   plt_employee_id, " +
"   iff(dtls.id is null,-1,dtls.id), " +
"   iff(customer_id is null,-1,customer_id), " +
"   iff(employee_id is null,-1,employee_id), " +
"   sat_order_plt_creation_dt, " +
"   link_order_quantity, " +
"   sat_link_amount, " +
"   status, " +
"   status_date " +
"  from t10 left outer join DB_AC_DEV_DM.product.DIM_PRODUCT dtls on HK_order_HUB_PRODUCT  = dtls.hk_hub where (dtls.ID is null or dtls.md_start_dt <= ''" + IO_START_DT + "'' ) " +
"    and ((dtls.md_end_dt is null and ''" + IO_START_DT + "'' < to_date(''2099-12-31'',''YYYY-MM-DD'') or not(dtls.md_end_dt is null  and ''" + IO_START_DT + "'' < dtls.md_end_dt))) ";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHOPPING_RDV_TO_DM_SHOPPING_FACT_ORDER_ITEM"("ENV" VARCHAR(16777216), "PREV_IO_START_DT" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =   "insert into DB_AC_DEV_Dm.shopping.FACT_PLATFORM_ORDER_ITEM(HK_LINK, " +
"MD_START_DT, " +
"MD_CREATION_DT, " +
"MD_CREATION_AUDIT_ID, " +
"MD_SOURCE, " +
"PLT_ORDER_ID, " +
"PLT_PRODUCT_ID, " +
"PLT_CUSTOMER_ID, " +
"PLT_EMPLOYEE_ID, " +
"PRODUCT_ID, " +
"CUSTOMER_ID, " +
"EMPLOYEE_ID, " +
"CREATION_DT, " +
"QUANTITY, " +
"AMOUNT, " +
"STATUS_DT, " +
"STATUS) " +
"with t1 as (select dtls.hk_hub_customer as lnk_customer,mstr.hk_link as order_hk_link,hk_hub_product as HK_order_HUB_PRODUCT,mstr.ORDER_ID as PLT_ORDER_ID, " +
"mstr.product_id as PLT_PRODUCT_ID,dtls.customer_id as PLT_customer_ID, " +
"dtls.MD_SOURCE as lnk_order_MD_SOURCE from  " +
"DB_AC_DEV_DWH.shopping_rdv.LINK_ORDER_ITEM mstr join DB_AC_DEV_DWH.shopping_rdv.LINK_ORDER_CUSTOMER dtls on mstr.hk_hub_order = dtls.hk_hub_order  " +
"where mstr.MD_CREATION_DT>= TO_DATE(''" + PREV_IO_START_DT + "'',''YYYY-MM-DD'') AND mstr.MD_CREATION_DT < TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')), " +
" t2 as(select lnk_customer, order_hk_link,dtls.worker_id as plt_employee_ID ,HK_order_HUB_PRODUCT , PLT_ORDER_ID,PLT_PRODUCT_ID,PLT_customer_ID, lnk_order_MD_SOURCE, hk_hub_worker from t1  " +
" mstr left outer join DB_AC_DEV_DWH.SUBSCRIPTION_rdv.LINK_SUBSCRIPTION dtls on hk_hub_customer =  lnk_customer), " +
" t3 as(select QUANTITY  as link_order_quantity,lnk_order_hk_LINK,amount as sat_link_amount from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_ORDER_ITEM_PLT MSTR JOIN ( " +
"  select HK_LINK as lnk_order_hk_LINK,max(md_start_dt) as max_md_start_dt from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_ORDER_ITEM_PLT  " +
"  where MD_START_DT <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_LINK) as dtls  " +
"  on mstr.HK_LINK = lnk_order_hk_LINK and mstr.md_start_dt = dtls.max_md_start_dt), " +
" t4 as(SELECT * FROM t2 join T3 on order_hk_link  = lnk_order_hk_LINK), " +
" t5 as(select mstr.creation_date as sat_order_plt_creation_dt,lnk_sat_order_hk_hub from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_PLT MSTR JOIN ( " +
"  select HK_hub as lnk_sat_order_hk_hub,max(md_start_dt) as max_md_start_dt from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_PLT  " +
"  where MD_START_DT <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_hub) as dtls  " +
"  on mstr.HK_hub = lnk_sat_order_hk_hub and mstr.md_start_dt = dtls.max_md_start_dt), " +
"  t6 as(select * from t4 join t5 on order_hk_link = lnk_sat_order_hk_hub), " +
"  t7 as(select lnk_sat_order_status_hk_hub, status, status_date from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_STATUS_PLT MSTR JOIN ( " +
"  select HK_hub as lnk_sat_order_status_hk_hub,max(md_start_dt) as max_md_start_dt from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_STATUS_PLT  " +
"  where MD_START_DT <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_hub) as dtls  " +
"  on mstr.HK_hub = lnk_sat_order_status_hk_hub and mstr.md_start_dt = dtls.max_md_start_dt), " +
"  t8 as(select * from t6 join t7 on lnk_sat_order_status_hk_hub = lnk_sat_order_status_hk_hub), " +
"  t9 as(select * from t8 left outer join (select hk_hub, id as employee_id from DB_AC_DEV_DM.SHared.DIM_EMPLOYEE) dtls on hk_hub_worker = dtls.hk_hub), " +
"  t10 as (select * FROM t9 left outer join (select hk_hub, id as customer_id  from DB_AC_DEV_DM.SHared.DIM_CUSTOMER) dtls on lnk_customer = dtls.hk_hub) " +
"  select order_hk_link, " +
" TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD''), " +
"   systimestamp(), " +
"   ''" + AUDIT_ID + "'', " +
"   lnk_order_MD_SOURCE, " +
"   PLT_ORDER_ID, " +
"   PLT_PRODUCT_ID, " +
"   plt_customer_id, " +
"   plt_employee_id, " +
"   iff(dtls.id is null,-1,dtls.id), " +
"   iff(customer_id is null,-1,customer_id), " +
"   iff(employee_id is null,-1,employee_id), " +
"   sat_order_plt_creation_dt, " +
"   link_order_quantity, " +
"   sat_link_amount, " +
"   status, " +
"   status_date " +
"  from t10 left outer join DB_AC_DEV_DM.product.DIM_PRODUCT dtls on HK_order_HUB_PRODUCT  = dtls.hk_hub where (dtls.ID is null or dtls.md_start_dt <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')) " +
"    and ((dtls.md_end_dt is null and TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') < to_date(''2099-12-31'',''YYYY-MM-DD'') or not(dtls.md_end_dt is null  and TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') < dtls.md_end_dt))) ";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHOPPING_RDV_TO_DM_SHOPPING_FACT_SHOPPING_REQUEST"("ENV" VARCHAR(16777216), "PREV_IO_START_DT" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =   "INSERT INTO DB_AC_DEV_Dm.shopping.FACT_PLATFORM_SHOPPING_REQUEST(HK_LINK, "+
"MD_START_DT,"+
"MD_CREATION_DT, "+
"MD_CREATION_AUDIT_ID, "+
"MD_SOURCE, "+
"PLT_SHOPPING_REQUEST_ID, "+
"PLT_PRODUCT_ID, "+
"PLT_CUSTOMER_ID, "+
"PLT_EMPLOYEE_ID, "+
"PRODUCT_ID, "+
"CUSTOMER_ID, "+
"EMPLOYEE_ID, "+
"QUANTITY, "+
"STATUS_DT, "+
"STATUS) "+
"with t1 as (select dtls.hk_hub_customer as lnk_customer,DTLS.HK_LINK AS  order_hk_linK ,MSTR.PRODUCT_ID AS PLT_PRODUCT_ID,HK_HUB_PRODUCT AS HK_order_HUB_PRODUCT, "+
"MSTR.MD_SOURCE AS SHOPPING_MD_SOURCE,MSTR.SHOPPING_REQUEST_ID AS SHOPPITNG_REQUEST_ID,dtls.customer_id as PLT_customer_ID from  "+
"DB_AC_DEV_DWH.shopping_rdv.LINK_SHOPPING_ITEM mstr join DB_AC_DEV_DWH.shopping_rdv.LINK_SHOPPING_CUSTOMER dtls on mstr.hk_hub_SHOPPING_REQUEST = dtls.hk_hub_SHOPPING_REQUEST  "+
"where mstr.MD_CREATION_DT>= to_date(''" + PREV_IO_START_DT + "'',''YYYY-MM-DD'') AND mstr.MD_CREATION_DT < TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')),  "+
" t2 as(select lnk_customer, order_hk_link,dtls.worker_id as plt_employee_ID ,HK_order_HUB_PRODUCT ,SHOPPITNG_REQUEST_ID,PLT_PRODUCT_ID,PLT_customer_ID, SHOPPING_MD_SOURCE, hk_hub_worker from t1  "+
" mstr left outer join DB_AC_DEV_DWH.SUBSCRIPTION_rdv.LINK_SUBSCRIPTION dtls on hk_hub_customer =  lnk_customer),  "+
" t3 as(select QUANTITY  as link_order_quantity,lnk_order_hk_LINK from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_SHOPPING_ITEM_PLT MSTR JOIN (  "+
"  select HK_LINK as lnk_order_hk_LINK,max(md_start_dt) as max_md_start_dt from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_SHOPPING_ITEM_PLT "+
"  where MD_START_DT <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_LINK) as dtls  "+
"  on mstr.HK_LINK = lnk_order_hk_LINK and mstr.md_start_dt = dtls.max_md_start_dt), "+
" T4 AS( SELECT * FROM t2 join T3 on order_hk_link  = lnk_order_hk_LINK), "+
" T5 AS( select  lnk_sat_order_hk_hub,CREATION_DATE AS status_Dt,STATUS from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_SHOPPING_REQUEST_PLT MSTR JOIN ( "+
"  select HK_hub as lnk_sat_order_hk_hub,max(md_start_dt) as max_md_start_dt from DB_AC_DEV_DWH.SHOPPING_RDV.SAT_SHOPPING_REQUEST_PLT "+
"  where MD_START_DT <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_hub) as dtls  "+
"  on mstr.HK_hub = lnk_sat_order_hk_hub and mstr.md_start_dt = dtls.max_md_start_dt), "+
"  T6 AS(SELECT * FROM T4 JOIN T5 ON lnk_sat_order_hk_hub = order_hk_link), "+
"  t7 as(select * from t6 left outer join (select hk_hub, id as employee_id from DB_AC_DEV_DM.SHared.DIM_EMPLOYEE) dtls on hk_hub_worker = dtls.hk_hub), "+
"  t8 as (select * FROM t7 left outer join (select hk_hub, id as customer_id  from DB_AC_DEV_DM.SHared.DIM_CUSTOMER) dtls on lnk_customer = dtls.hk_hub) "+
"  SELECT order_hk_link, "+
"  TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD''), "+
"  SYSTIMESTAMP(), "+
"  ''"+AUDIT_ID+"'' , "+
"  SHOPPING_MD_SOURCE, "+
"  SHOPPITNG_REQUEST_ID, "+
"   HK_order_HUB_PRODUCT, "+
"   PLT_customer_ID, "+
"   PLT_EMPLOYEE_ID, "+
"   iff(dtls.id is null,-1,dtls.id), "+
"   iff(customer_id is null,-1,customer_id), "+
"   iff(employee_id is null,-1,employee_id), "+
"   link_order_quantity, "+
"   STATUS_DT, "+
"   STATUS "+
"   from t8 left outer join DB_AC_DEV_DM.product.DIM_PRODUCT dtls on HK_order_HUB_PRODUCT  = dtls.hk_hub where (dtls.ID is null or dtls.md_start_dt <= TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') ) "+
"    and ((dtls.md_end_dt is null and TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') < to_date(''2099-12-31'',''YYYY-MM-DD'') or not(dtls.md_end_dt is null  and TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') < dtls.md_end_dt))) ";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
var result2_scan = sql_statement2.execute(); 
';
create or replace schema SHOPPING_EXPLORATION;

create or replace schema SUBSCRIPTION;

create or replace TABLE FACT_PLATFORM_CUSTOMER_PERSONAL_INTEREST_MONTHLY (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the Fact',
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Security Type ',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	PLT_CUSTOMER_ID VARCHAR(16777216) COMMENT 'Platform Customer ID',
	PLT_EMPLOYEE_ID VARCHAR(16777216) COMMENT 'Platform Employee ID',
	PLT_PERSONAL_INTEREST_ID VARCHAR(16777216) COMMENT 'Platform Personal Interest ID',
	CUSTOMER_ID NUMBER(38,0) COMMENT 'Dimension Customer ID',
	EMPLOYEE_ID NUMBER(38,0) COMMENT 'Dimension Employee ID',
	PERSONAL_INTEREST_ID NUMBER(38,0) COMMENT 'Dimension Personal Interest ID',
	PLT_UPDATE_DT TIMESTAMP_NTZ(9) COMMENT 'Date of the update in the platform',
	foreign key (EMPLOYEE_ID) references DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE(ID),
	foreign key (PERSONAL_INTEREST_ID) references DB_AC_DEV_DM.PRODUCT.DIM_PERSONAL_INTEREST(ID)
);
create or replace TABLE FACT_PLATFORM_USER_SUBSCRIPTION (
	ID NUMBER(38,0) autoincrement COMMENT 'Surrogate key of the Fact',
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_SECURITY_TYPE VARCHAR(1000) COMMENT 'Security Type ',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	CUSTOMER_ID NUMBER(38,0) COMMENT 'Dimension Customer ID',
	EMPLOYEE_ID NUMBER(38,0) COMMENT 'Dimension Employee ID',
	SUBSCRIPTION_DT TIMESTAMP_NTZ(9) COMMENT 'Date of the subscription in the platform',
	foreign key (EMPLOYEE_ID) references DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE(ID)
);
create or replace TABLE FACT_PLATFORM_USER_SUBSCRIPTION_TMP_BKP (
	ID NUMBER(38,0),
	HK_LINK VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_CREATION_AUDIT_ID VARCHAR(1000),
	MD_SECURITY_TYPE VARCHAR(1000),
	MD_SOURCE VARCHAR(1000),
	CUSTOMER_ID VARCHAR(16777216),
	EMPLOYEE_ID VARCHAR(16777216),
	SUBSCRIPTION_DT TIMESTAMP_NTZ(9)
);
create or replace view VW_FACT_PLATFORM_CUSTOMER_PERSONAL_INTEREST_MONTHLY(
	ID,
	START_DATE,
	CREATION_DATE,
	CREATION_AUDIT_ID,
	SECURITY_TYPE,
	SOURCE,
	PLT_CUSTOMER_ID,
	PLT_EMPLOYEE_ID,
	PLT_PERSONAL_INTEREST_ID,
	CUSTOMER_ID,
	EMPLOYEE_ID,
	PERSONAL_INTEREST_ID,
	PLT_UPDATE_DATE,
	PLT_UPDATE_HOUR
) as
SELECT  ID AS ID,
		MD_START_DT AS Start_date,
        MD_CREATION_DT AS Creation_date,
        MD_CREATION_AUDIT_ID AS Creation_audit_ID,
        MD_SECURITY_TYPE AS Security_type,
        MD_SOURCE AS Source,
        PLT_CUSTOMER_ID AS PLT_Customer_ID,
        PLT_EMPLOYEE_ID AS PLT_Employee_ID,
        PLT_PERSONAL_INTEREST_ID AS PLT_Personal_Interest_ID,
        CUSTOMER_ID AS Customer_ID,
        EMPLOYEE_ID AS Employee_ID,
        PERSONAL_INTEREST_ID AS Personal_Interest_ID,
        PLT_UPDATE_DT AS PLT_Update_date,
        hour(PLT_UPDATE_DT) AS PLT_Update_hour                
FROM DB_AC_DEV_DM.SUBSCRIPTION.FACT_PLATFORM_CUSTOMER_PERSONAL_INTEREST_MONTHLY;
create or replace view VW_FACT_PLATFORM_USER_SUBSCRIPTION(
	ID,
	DATA_START_DATE,
	CUSTOMER_DIMENSION_ID,
	EMPLOYEE_DIMENSION_ID,
	SUBSCRIPTION_DATE,
	SUBSCRIPTION_HOUR
) as
SELECT 	ID, 
		MD_START_DT AS Data_start_date,
		CUSTOMER_ID AS Customer_dimension_ID, 
		EMPLOYEE_ID AS Employee_dimension_ID,
        TO_DATE(SUBSCRIPTION_DT) AS Subscription_Date,
        DATE_PART('HOUR',SUBSCRIPTION_DT ) AS Subscription_Hour
FROM DB_AC_DEV_DM.SUBSCRIPTION.FACT_PLATFORM_USER_SUBSCRIPTION;
create or replace view VW_FACT_PLATFORM_USER_SUBSCRIPTION_TMP_BKP(
	ID,
	START_DATE,
	CREATION_DATE,
	CREATION_AUDIT_DATE,
	SOURCE,
	CUSTOMER_ID,
	EMPLOYEE_ID,
	SUBSCIPTION_DATE
) as 

SELECT ID AS ID, -- To validate, 
             MD_START_DT  AS Start_Date, -- To validate, 
             MD_CREATION_DT AS Creation_Date, -- To validate, 
             MD_CREATION_AUDIT_ID AS Creation_Audit_Date, -- To validate, 
             MD_SOURCE AS Source, -- To validate, 
             CUSTOMER_ID AS Customer_ID, -- To validate, 
             EMPLOYEE_ID AS Employee_ID, -- To validate, 
             SUBSCRIPTION_DT AS Subsciption_Date -- To validate, 
FROM DB_AC_DEV_DM.SUBSCRIPTION.FACT_PLATFORM_USER_SUBSCRIPTION_TMP_BKP;
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SUBSCRIPTION_FACT_CUSTOMER_PERSONAL_INTEREST_MONTHLY"("ENV" VARCHAR(16777216), "IO_DATA_START_DATE" VARCHAR(16777216), "I_JOB_AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
var sql_statement ="INSERT INTO DB_AC_DEV_DM.SUBSCRIPTION.FACT_PLATFORM_CUSTOMER_PERSONAL_INTEREST_MONTHLY(ID,HK_LINK,MD_START_DT,MD_CREATION_DT,MD_CREATION_AUDIT_ID,MD_SECURITY_TYPE,MD_SOURCE,PLT_CUSTOMER_ID,PLT_EMPLOYEE_ID,PLT_PERSONAL_INTEREST_ID,CUSTOMER_ID,EMPLOYEE_ID,PERSONAL_INTEREST_ID,PLT_UPDATE_DT)\\\\n \\\\
WITH T1 AS \\\\n \\\\
(select P1.HK_LINK,P1.MD_CREATION_DT,P1.MD_SOURCE,P1.MD_CREATION_AUDIT_ID,P1.HK_HUB_CUSTOMER,P1.HK_HUB_PERSONAL_INTEREST,P1.LINK_CUSTOMER_PERSONAL_INTEREST,P1.CUSTOMER_ID,P1.LINK_CUSTOMER_PERSONAL_INTEREST,P1.INTEREST_ID\\\\n \\\\
FROM DB_AC_DEV_DWH.SUBSCRIPTION_RDV.LINK_CUSTOMER_PERSONAL_INTEREST P1 JOIN DB_AC_DEV_DWH.SUBSCRIPTION_RDV.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT P2 ON P1.LNK_CUST_INTEREST_HK_LINK=P2.SAT_LINK_HK_LINK\\\\n \\\\
WHERE P1.LNK_CUST_INTEREST_HK_HUB_CUSTOMER=P1.Recent_HK_HUB_CUSTOMER AND P2.MD_START_DT=P2.Recent_Start_Date),\\\\n \\\\
WITH T2 AS \\\\n \\\\
(select P2.HK_LINK,P2.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT,P2.MD_START_DT,P2.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT,P2.MD_HASHDIFF,P2.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT,P2.MD_CREATION_DT,P2.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT,P2.MD_SOURCE,P2.MD_CREATION_AUDIT_ID FROM DB_AC_DEV_DWH.SUBSCRIPTION_RDV.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT P2 WHERE MD_START_DT  <= "  + "''" +io_DATA_START_DATE+ "''" + "),\\\\n \\\\
WITH T3 AS \\\\n \\\\
(select \\\\n \\\\
P1.HK_LINK,P1.MD_CREATION_DT,P1.MD_SOURCE,P1.MD_CREATION_AUDIT_ID,P1.HK_HUB_CUSTOMER,P1.HK_HUB_PERSONAL_INTEREST,P1.CUSTOMER_ID,P1.INTEREST_ID FROM DB_AC_DEV_DWH.SUBSCRIPTION_RDV.LINK_CUSTOMER_PERSONAL_INTEREST P1 JOIN DB_AC_DEV_DWH.SUBSCRIPTION_RDV.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT P2 ON P1.LNK_CUST_INTEREST_HK_LINK=P2.SAT_LINK_HK_LINK),\\\\n \\\\
WITH T4 AS \\\\n \\\\
(select P2.HK_LINK,P2.MD_START_DT,P2.MD_HASHDIFF,P2.MD_CREATION_DT,P2.MD_SOURCE,P2.MD_CREATION_AUDIT_ID FROM DB_AC_DEV_DWH.SUBSCRIPTION_RDV.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT\\\\n \\\\ 
WHERE P2.MD_START_DT  <= ''" +io_DATA_START_DATE+ "'' GROUP BY P1.LNK_CUST_INTEREST_HK_HUB_CUSTOMER),\\\\n \\\\
WITH T5 AS \\\\n \\\\
(select P3.HK_LINK,P3.MD_START_DT,P3.MD_SOURCE,P3.MD_CREATION_DT,P3.MD_CREATION_AUDIT_ID,P3.HK_HUB_WORKER,P3.HK_HUB_CUSTOMER,P3.HK_HUB_ORGANIZATION,P3.WORKER_ID,P3.CUSTOMER_ID,P3.ORGANIZATION_ID FROM DB_AC_DEV_DWH.SUBSCRIPTION_RDV.LINK_SUBSCRIPTION P3 JOIN DB_AC_DEV_DWH.SUBSCRIPTION_RDV.LINK_CUSTOMER_PERSONAL_INTEREST P1 ON P3.LNK_SUBSCRIPTION_HK_HUB_CUSTOMER = P1.LNK_CUST_INTEREST_HK_HUB_CUSTOMER),\\\\n \\\\
WITH T6 AS \\\\n \\\\
(select P4.ID,\\\\n \\\\
P4.HK_HUB,P4.MD_START_DT,P4.MD_END_DT,P4.MD_HASH_NAT_KEYS,  P4.MD_HASHDIFF_TYPE1,P4.MD_HASHDIFF_TYPE2,P4.MD_CREATION_DT,P4.MD_MODIFY_DT,P4.MD_SOURCE,P4.MD_CREATION_AUDIT_ID,P4.MD_MODIFY_AUDIT_ID,P4.MD_SECURITY_TYPE,P4.HIRE_DATE,P4.PROVINCE_OF_EMPLOYMENT,P4.REMUNERATION_TYPE,P4.HOURS_PER_WEEK,P4.PAY_PERIOD,P4.WORK_PATTERN,P4.JOB_PERMANENCY,P4.JOB_CATEGORY,P4.LOCATION,P4.ORGANIZATION_NAME,P4.TERMINATED,P4.TERMINATION_DATE,P4.SALARY,P4.SALARY_EFFECTIVE_DATE,P4.ON_LEAVE,P4.LEAVE_START_DATE,P4.LEAVE_END_DATE,P4.WORK_PERMIT_TYPE,P4.WORK_PERMIT_START_DATE,P4.WORK_PERMIT_END_DATE FROM DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE P4 JOIN DB_AC_DEV_DWH.SUBSCRIPTION_RDV.LINK_SUBSCRIPTION P3 ON P3.LNK_SUBSCRIPTION_HK_HUB_WORKER=P4.Emp_MD_HASH_NAT_KEYS \\\\n \\\\
WHERE ''" +io_DATA_START_DATE+ "'' >= P4.MD_START_DT AND(( ISNULL(P4.MD_END_DT) AND ''" +io_DATA_START_DATE+ "''<  TO_DATE(''2099-12-31'',''YYYY-MM-DD'') ) OR ( NOT ISNULL(P4.MD_END_DT) AND ''" +io_DATA_START_DATE+ "''< P4.MD_END_DT ) )),\\\\n \\\\
WITH T7 AS \\\\n \\\\
(select P5.ID,P5.HK_HUB,P5.MD_START_DT,P5.MD_END_DT,P5.MD_HASH_NAT_KEYS,P5.MD_HASHDIFF_TYPE1,P5.MD_HASHDIFF_TYPE2,P5.MD_CREATION_DT,P5.MD_MODIFY_DT,P5.MD_SOURCE,P5.MD_CREATION_AUDIT_ID,P5.MD_MODIFY_AUDIT_ID,P5.MD_SECURITY_TYPE,P5.MONTH_OF_BIRTH,P5.GENDER,P5.POSTAL_CODE_PARTIAL,P5.PROVINCE,P5.COUNTRY FROM DB_AC_DEV_DM.SHARED.DIM_CUSTOMER P5 JOIN DB_AC_DEV_DWH.SUBSCRIPTION_RDV.LINK_CUSTOMER_PERSONAL_INTEREST P1 ON P1.LNK_CUST_INTEREST_HK_HUB_CUSTOMER=P5.Cust_MD_HASH_NAT_KEYS\\\\n \\\\
WHERE ''" +io_DATA_START_DATE+ "'' >= P5.MD_START_DT AND(( ISNULL(P5.MD_END_DT) AND ''" +io_DATA_START_DATE+ "''<  TO_DATE(''2099-12-31'',''YYYY-MM-DD'') ) OR ( NOT ISNULL(P5.MD_END_DT) AND ''" +io_DATA_START_DATE+ "''< P5.MD_END_DT ) )),\\\\n \\\\
WITH T8 AS \\\\n \\\\
(select P6.ID,P6.HK_HUB,P6.MD_START_DT,P6.MD_END_DT,P6.MD_HASH_NAT_KEYS,P6.MD_HASHDIFF_TYPE1,P6.MD_HASHDIFF_TYPE2,P6.MD_CREATION_DT,P6.MD_MODIFY_DT,P6.MD_SOURCE,P6.MD_CREATION_AUDIT_ID,P6.MD_MODIFY_AUDIT_ID,P6.MD_SECURITY_TYPE,P6.NAME_FR,P6.NAME_EN,P6.TAGS DB_AC_DEV_DM.SHARED.DIM_PERSONAL_INTEREST P6 JOIN DB_AC_DEV_DWH.SUBSCRIPTION_RDV.LINK_CUSTOMER_PERSONAL_INTEREST P1 ON P1.LNK_CUST_INTEREST_HK_HUB_PERSONAL_INTEREST=P6.Int_MD_HASH_NAT_KEYS\\\\n \\\\
WHERE ''" +io_DATA_START_DATE+ "''>= P6.MD_START_DT AND(( ISNULL(P6.MD_END_DT) AND ''" +io_DATA_START_DATE+ "''<  TO_DATE(''2099-12-31'',''YYYY-MM-DD'') ) OR ( NOT ISNULL(P6.MD_END_DT) AND ''" +io_DATA_START_DATE+ "''< P6.MD_END_DT ) ))";\\\\n \\\\
try {
    var sql_statement = snowflake.createStatement({sqlText: sql_statement });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return sql_statement;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SUBSCRIPTION_FACT_CUSTOMER_PERSONAL_INTEREST_MONTHLY"("ENV" VARCHAR(1000), "I_DATA_START_DATE" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_PRE_DEL STRING;
INS_INSERT STRING;


BEGIN
i_DATA_START_DATE :=CHAR(39)||i_DATA_START_DATE||CHAR(39);
INS_PRE_DEL := ''DELETE FROM DB_AC_''||ENV||''_DM.SUBSCRIPTION.FACT_PLATFORM_CUSTOMER_PERSONAL_INTEREST_MONTHLY WHERE MD_START_DT < TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''') AND DAY(MD_START_DT) > 1  '';
INS_INSERT := ''
INSERT INTO DB_AC_''||ENV||''_DM.SUBSCRIPTION.FACT_PLATFORM_CUSTOMER_PERSONAL_INTEREST_MONTHLY
(
HK_LINK
,MD_START_DT
,MD_CREATION_DT
,MD_CREATION_AUDIT_ID
,MD_SECURITY_TYPE
,MD_SOURCE
,PLT_CUSTOMER_ID
,PLT_EMPLOYEE_ID
,PLT_PERSONAL_INTEREST_ID
,CUSTOMER_ID
,EMPLOYEE_ID
,PERSONAL_INTEREST_ID
,PLT_UPDATE_DT
)
SELECT
LNK_CUST_INTEREST_HK_LINK
,TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''')
,CURRENT_TIMESTAMP
,''''-1''''
,Int_MD_SECURITY_TYPE
,SAT_LINK_MD_SOURCE
,LNK_CUST_INTEREST_CUSTOMER_ID
,LNK_SUBSCRIPTION_WORKER_ID
,LNK_CUST_INTEREST_INTEREST_ID
,Cust_ID
,Emp_ID
,Int_ID
,MD_START_DT
FROM
(
SELECT * FROM
(
SELECT
SAT_LINK.MD_START_DT AS  MD_START_DT
,SAT_LINK.HK_LINK AS SAT_LINK_HK_LINK
,SAT_LINK.MD_SOURCE AS SAT_LINK_MD_SOURCE
,LNK_CUST_INTEREST.CUSTOMER_ID LNK_CUST_INTEREST_CUSTOMER_ID
,LNK_CUST_INTEREST.HK_HUB_CUSTOMER AS LNK_CUST_INTEREST_HK_HUB_CUSTOMER
,LNK_CUST_INTEREST.HK_HUB_PERSONAL_INTEREST AS LNK_CUST_INTEREST_HK_HUB_PERSONAL_INTEREST
,LNK_CUST_INTEREST.HK_LINK AS LNK_CUST_INTEREST_HK_LINK
,LNK_CUST_INTEREST.INTEREST_ID AS LNK_CUST_INTEREST_INTEREST_ID
,LNK_CUST_INTEREST.MD_CREATION_AUDIT_ID AS  LNK_CUST_INTEREST_MD_CREATION_AUDIT_ID
,LNK_CUST_INTEREST.MD_CREATION_DT AS LNK_CUST_INTEREST_MD_CREATION_DT
,LNK_CUST_INTEREST.MD_SOURCE AS LNK_CUST_INTEREST_MD_SOURCE
,ROW_NUMBER() OVER(PARTITION BY LNK_CUST_INTEREST.HK_HUB_CUSTOMER ORDER BY LNK_CUST_INTEREST.MD_START_DT DESC) RN
FROM
DB_AC_''||ENV||''_DWH.SUBSCRIPTION_RDV.LINK_CUSTOMER_PERSONAL_INTEREST LNK_CUST_INTEREST
JOIN
(SELECT * FROM DB_AC_''||ENV||''_DWH.SUBSCRIPTION_RDV.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT WHERE MD_START_DT <= TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''')) SAT_LINK
ON
LNK_CUST_INTEREST.HK_LINK = SAT_LINK.HK_LINK
) SAT_LINK_CUST_INTEREST WHERE SAT_LINK_CUST_INTEREST.RN = 1
) SAT_LINK_CUST_INTEREST
LEFT JOIN
(
SELECT
LNK_SUBSCRIPTION.CUSTOMER_ID AS LNK_SUBSCRIPTION_CUSTOMER_ID
,LNK_SUBSCRIPTION.HK_HUB_CUSTOMER AS LNK_SUBSCRIPTION_HK_HUB_CUSTOMER
,LNK_SUBSCRIPTION.HK_HUB_ORGANIZATION AS LNK_SUBSCRIPTION_HK_HUB_ORGANIZATION
,LNK_SUBSCRIPTION.HK_HUB_WORKER AS LNK_SUBSCRIPTION_HK_HUB_WORKER
,LNK_SUBSCRIPTION.HK_LINK AS LNK_SUBSCRIPTION_HK_LINK
,LNK_SUBSCRIPTION.MD_CREATION_AUDIT_ID AS LNK_SUBSCRIPTION_MD_CREATION_AUDIT_ID
,LNK_SUBSCRIPTION.MD_CREATION_DT AS LNK_SUBSCRIPTION_MD_CREATION_DT
,LNK_SUBSCRIPTION.MD_SOURCE AS LNK_SUBSCRIPTION_MD_SOURCE
,LNK_SUBSCRIPTION.MD_START_DT AS LNK_SUBSCRIPTION_MD_START_DT
,LNK_SUBSCRIPTION.ORGANIZATION_ID AS LNK_SUBSCRIPTION_ORGANIZATION_ID
,LNK_SUBSCRIPTION.WORKER_ID AS LNK_SUBSCRIPTION_WORKER_ID
FROM
DB_AC_''||ENV||''_DWH.SUBSCRIPTION_RDV.LINK_SUBSCRIPTION LNK_SUBSCRIPTION
) LINK_SUBSCRIPTION_DT
ON
SAT_LINK_CUST_INTEREST.LNK_CUST_INTEREST_HK_HUB_CUSTOMER = LINK_SUBSCRIPTION_DT.LNK_SUBSCRIPTION_HK_HUB_CUSTOMER
LEFT JOIN
(
SELECT
Emp.HIRE_DATE AS Emp_HIRE_DATE
,Emp.HK_HUB AS Emp_HK_HUB
,Emp.HOURS_PER_WEEK AS Emp_HOURS_PER_WEEK
,Emp.ID AS Emp_ID
,Emp.JOB_CATEGORY AS Emp_JOB_CATEGORY
,Emp.JOB_PERMANENCY AS Emp_JOB_PERMANENCY
,Emp.LEAVE_END_DATE AS Emp_LEAVE_END_DATE
,Emp.LEAVE_START_DATE AS Emp_LEAVE_START_DATE
,Emp.LOCATION AS Emp_LOCATION
,Emp.MD_CREATION_AUDIT_ID AS Emp_MD_CREATION_AUDIT_ID
,Emp.MD_CREATION_DT AS Emp_MD_CREATION_DT
,Emp.MD_END_DT AS Emp_MD_END_DT
,Emp.MD_HASH_NAT_KEYS AS Emp_MD_HASH_NAT_KEYS
,Emp.MD_HASHDIFF_TYPE1 AS Emp_MD_HASHDIFF_TYPE1
,Emp.MD_HASHDIFF_TYPE2 AS Emp_MD_HASHDIFF_TYPE2
,Emp.MD_MODIFY_AUDIT_ID AS Emp_MD_MODIFY_AUDIT_ID
,Emp.MD_MODIFY_DT AS Emp_MD_MODIFY_DT
,Emp.MD_SECURITY_TYPE AS Emp_MD_SECURITY_TYPE
,Emp.MD_SOURCE AS Emp_MD_SOURCE
,Emp.MD_START_DT AS Emp_MD_START_DT
,Emp.ON_LEAVE AS Emp_ON_LEAVE
,Emp.ORGANIZATION_NAME AS Emp_ORGANIZATION_NAME
,Emp.PAY_PERIOD AS Emp_PAY_PERIOD
,Emp.PROVINCE_OF_EMPLOYMENT AS Emp_PROVINCE_OF_EMPLOYMENT
,Emp.REMUNERATION_TYPE AS Emp_REMUNERATION_TYPE
,Emp.SALARY AS Emp_SALARY
,Emp.SALARY_EFFECTIVE_DATE AS Emp_SALARY_EFFECTIVE_DATE
,Emp.TERMINATED AS Emp_TERMINATED
,Emp.TERMINATION_DATE AS Emp_TERMINATION_DATE
,Emp.WORK_PATTERN AS Emp_WORK_PATTERN
,Emp.WORK_PERMIT_END_DATE AS Emp_WORK_PERMIT_END_DATE
,Emp.WORK_PERMIT_START_DATE AS Emp_WORK_PERMIT_START_DATE
,Emp.WORK_PERMIT_TYPE AS Emp_WORK_PERMIT_TYPE
FROM
DB_AC_''||ENV||''_DM.SHARED.DIM_EMPLOYEE Emp WHERE
TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''') >= Emp_MD_START_DT AND(( Emp_MD_END_DT IS NULL AND TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''') <  TO_DATE(''''2099-12-31'''',''''YYYY-MM-DD'''') ) OR ( (Emp_MD_END_DT)  IS NOT NULL AND TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''') < Emp_MD_END_DT ) )
) Emp
ON
LINK_SUBSCRIPTION_DT.LNK_SUBSCRIPTION_HK_HUB_WORKER = Emp.Emp_MD_HASH_NAT_KEYS
JOIN
(
SELECT
Cust.COUNTRY AS Cust_COUNTRY
,Cust.GENDER AS Cust_GENDER
,Cust.HK_HUB AS Cust_HK_HUB
,Cust.ID AS Cust_ID
,Cust.MD_CREATION_AUDIT_ID AS Cust_MD_CREATION_AUDIT_ID
,Cust.MD_CREATION_DT AS Cust_MD_CREATION_DT
,Cust.MD_END_DT AS Cust_MD_END_DT
,Cust.MD_HASH_NAT_KEYS AS Cust_MD_HASH_NAT_KEYS
,Cust.MD_HASHDIFF_TYPE1 AS Cust_MD_HASHDIFF_TYPE1
,Cust.MD_HASHDIFF_TYPE2 AS Cust_MD_HASHDIFF_TYPE2
,Cust.MD_MODIFY_AUDIT_ID AS Cust_MD_MODIFY_AUDIT_ID
,Cust.MD_MODIFY_DT AS Cust_MD_MODIFY_DT
,Cust.MD_SECURITY_TYPE AS Cust_MD_SECURITY_TYPE
,Cust.MD_SOURCE AS Cust_MD_SOURCE
,Cust.MD_START_DT AS Cust_MD_START_DT
,Cust.POSTAL_CODE_PARTIAL AS Cust_POSTAL_CODE_PARTIAL
,Cust.PROVINCE AS Cust_PROVINCE
FROM
DB_AC_''||ENV||''_DM.SHARED.DIM_CUSTOMER Cust
WHERE
TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''')>= Cust_MD_START_DT AND(( (Cust_MD_END_DT) IS NULL AND TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''')<  TO_DATE(''''2099-12-31'''',''''YYYY-MM-DD'''') ) OR ( (Cust_MD_END_DT) IS NOT NULL AND TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''')< Cust_MD_END_DT ) )
) Cust
LEFT JOIN
(
SELECT
Int.HK_HUB AS Int_HK_HUB
,Int.ID AS Int_ID
,Int.MD_CREATION_AUDIT_ID AS Int_MD_CREATION_AUDIT_ID
,Int.MD_CREATION_DT AS Int_MD_CREATION_DT
,Int.MD_END_DT AS Int_MD_END_DT
,Int.MD_HASH_NAT_KEYS AS Int_MD_HASH_NAT_KEYS
,Int.MD_HASHDIFF_TYPE1 AS Int_MD_HASHDIFF_TYPE1
,Int.MD_HASHDIFF_TYPE2 AS Int_MD_HASHDIFF_TYPE2
,Int.MD_MODIFY_AUDIT_ID AS Int_MD_MODIFY_AUDIT_ID
,Int.MD_MODIFY_DT AS Int_MD_MODIFY_DT
,Int.MD_SECURITY_TYPE AS Int_MD_SECURITY_TYPE
,Int.MD_SOURCE AS Int_MD_SOURCE
,Int.MD_START_DT AS Int_MD_START_DT
,Int.NAME_EN AS Int_NAME_EN
,Int.NAME_FR AS Int_NAME_FR
,Int.TAGS AS Int_TAGS
FROM
DB_AC_''||ENV||''_DM.PRODUCT.DIM_PERSONAL_INTEREST Int
WHERE
TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''')>= Int_MD_START_DT AND(( (Int_MD_END_DT) IS NULL AND TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''')<  TO_DATE(''''2099-12-31'''',''''YYYY-MM-DD'''') ) OR ( (Int_MD_END_DT) IS NOT NULL AND TO_DATE(''||i_DATA_START_DATE||'',''''YYYY-MM-DD'''')< Int_MD_END_DT ) )
) Int
'';
EXECUTE IMMEDIATE :INS_PRE_DEL;
EXECUTE IMMEDIATE :INS_INSERT;


END
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SUBSCRIPTION_FACT_SUBSCRIPTION"("ENV" VARCHAR(16777216), "PREV_IO_START_DT" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command ="INSERT INTO  DB_AC_" + ENV + "_DM.SUBSCRIPTION.FACT_PLATFORM_USER_SUBSCRIPTION(HK_LINK,MD_SOURCE,CUSTOMER_ID,EMPLOYEE_ID,SUBSCRIPTION_DT,MD_CREATION_DT,MD_START_DT,MD_CREATION_AUDIT_ID)SELECT LS.HK_LINK, LS.MD_SOURCE, DC.ID, DE.ID, LS.MD_START_DT, CURRENT_TIMESTAMP, TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD''), " + AUDIT_ID + " FROM  DB_AC_" + ENV + "_DWH.SUBSCRIPTION_RDV.LINK_SUBSCRIPTION LS left join DB_AC_" + ENV + "_DM.SHARED.DIM_EMPLOYEE DE on DE.HK_HUB = LS.HK_HUB_WORKER LEFT JOIN DB_AC_" + ENV + "_DM.SHARED.DIM_CUSTOMER DC ON DC.HK_HUB = LS.HK_HUB_CUSTOMER WHERE  LS.MD_CREATION_DT >= TO_DATE(''" + PREV_IO_START_DT + "'',''YYYY-MM-DD'') AND LS.MD_CREATION_DT < TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')  AND  TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') >= DE.MD_START_DT AND ((DE.MD_END_DT IS NULL AND TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')  < TO_DATE(''2099-12-31'',''YYYY-MM-DD'') ) OR ( DE.MD_END_DT IS NOT NULL AND TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')  < DE.MD_END_DT ) ) AND TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') >= DC.MD_START_DT AND(( DC.MD_END_DT IS NULL AND TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') <  TO_DATE(''2099-12-31'',''YYYY-MM-DD'') ) OR ( DC.MD_END_DT IS NOT NULL AND TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'')  < DC.MD_END_DT ) );";
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
  result = "Succeeded!";
}
catch (err) {
    result = "Failed: Code: " + err.code + " \\n State: " + err.state;
    result += " \\n Message: " + err.message;
    result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
    throw result;
  }
 return result;
';
create or replace schema SUBSCRIPTION_EXPLORATION;

create or replace view FACT_PLATFORM_USER_SUBSCRIPTION(
	ID,
	MD_START_DT,
	MD_END_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	EMPLOYEE_ID,
	NB_OF_USERS
) as (
SELECT 
    ROW_NUMBER() over (ORDER BY c.ID) as ID,
    C.MD_START_DT AS MD_START_DT, --'Start Date of the image/version',
    NULL AS MD_END_DT, --  'End Date of the image/version'
    CURRENT_TIMESTAMP as MD_CREATION_DT, -- 'Creation Date Time of the occurrence'
    C.MD_SOURCE AS MD_SOURCE, -- 'Represents the source system, file, etc. of the instance'
    c.ID as CUSTOMER_ID,
    e.ID as EMPLOYEE_ID,
    1 as nb_of_users
FROM DB_AC_DEV_STG.PLT_MODEL_SHARED_EXPL.VW_CUSTOMER_EXPL c
LEFT JOIN DB_AC_DEV_STG.PLT_MODEL_SHARED_EXPL.VW_EMPLOYEE_EXPL e on c.ID = e.CUSTOMER_ID
);