create or replace database DB_AC_DEV_STG;

create or replace schema DATALAKE;

create or replace TABLE ADMINISTRATIVE_ENTITIES_STG (
	POSTAL_CODE VARCHAR(6),
	ELECTORAL_DIVISION_CODE VARCHAR(3),
	ELECTORAL_DIVISION VARCHAR(30),
	MUNICIPALITIE_CODE VARCHAR(9),
	MUNICIPALITIE VARCHAR(58),
	MUNICIPALITIE_DESIGNATION_CODE VARCHAR(2),
	MRC_CODE VARCHAR(5),
	MRC VARCHAR(60),
	ADMINISTRATIVE_REGION_CODE VARCHAR(2),
	ADMINISTRATIVE_REGION VARCHAR(60)
);
create or replace view VW_U_ADMINISTRATIVE_ENTITIES_RECEP(
	POSTAL_CODE_ID,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	POSTAL_CODE,
	POSTAL_CODE_ABBR,
	ELECTORAL_DIVISION_CODE,
	ELECTORAL_DIVISION,
	MUNICIPALITIE_CODE,
	MUNICIPALITIE,
	MUNICIPALITIE_DESIGNATION_CODE,
	MRC_CODE,
	MRC,
	ADMINISTRATIVE_REGION_CODE,
	ADMINISTRATIVE_REGION
) as 
(
    SELECT 
    POSTAL_CODE AS POSTAL_CODE_ID,
    CURRENT_TIMESTAMP()::timestamp_ntz  AS MD_START_DT,
    CURRENT_TIMESTAMP()::timestamp_ntz AS MD_CREATION_DT,
    'region_csv_grouv_quebec' AS MD_SOURCE,
    POSTAL_CODE,
    LEFT(POSTAL_CODE,3) AS POSTAL_CODE_ABBR,
    ELECTORAL_DIVISION_CODE,
    ELECTORAL_DIVISION,
    MUNICIPALITIE_CODE,
    MUNICIPALITIE,
    MUNICIPALITIE_DESIGNATION_CODE,
    MRC_CODE,
    MRC,
    ADMINISTRATIVE_REGION_CODE,
    ADMINISTRATIVE_REGION
    FROM DATALAKE.ADMINISTRATIVE_ENTITIES_STG
);
create or replace schema GOV_MODEL_REFERENCE;

create or replace TRANSIENT TABLE ADMINISTRATIVE_ENTITIES (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	POSTAL_CODE_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	POSTAL_CODE VARCHAR(6),
	POSTAL_CODE_ABBR VARCHAR(3),
	ELECTORAL_DIVISION_CODE VARCHAR(3),
	ELECTORAL_DIVISION VARCHAR(30),
	MUNICIPALITIE_CODE VARCHAR(9),
	MUNICIPALITIE VARCHAR(58),
	MUNICIPALITIE_DESIGNATION_CODE VARCHAR(2),
	MRC_CODE VARCHAR(5),
	MRC VARCHAR(60),
	ADMINISTRATIVE_REGION_CODE VARCHAR(2),
	ADMINISTRATIVE_REGION VARCHAR(60)
);
create or replace view VW_ADMINISTRATIVE_ENTITIE(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	POSTAL_CODE_ID,
	POSTAL_CODE,
	POSTAL_CODE_ABBR,
	ELECTORAL_DIVISION_CODE,
	ELECTORAL_DIVISION,
	MUNICIPALITIE_CODE,
	MUNICIPALITIE,
	MUNICIPALITIE_DESIGNATION_CODE,
	MRC_CODE,
	MRC,
	ADMINISTRATIVE_REGION_CODE,
	ADMINISTRATIVE_REGION
) as
(
  SELECT
                SHA1( 
                   NVL(RTRIM(LTRIM(POSTAL_CODE_ID)),'#NULL#') 
                ) AS HK_HUB,                
                MD_START_DT,
               SHA1( 
                UPPER( 
                    
                    NVL(POSTAL_CODE,'#NULL#')  
                    || '|' ||
                    NVL(POSTAL_CODE_ABBR,'#NULL#')
                   || '|' ||
                    NVL(ELECTORAL_DIVISION_CODE,'#NULL#')
                   || '|' ||
                    NVL(ELECTORAL_DIVISION,'#NULL#')
                   || '|' ||
                    NVL(MUNICIPALITIE_CODE,'#NULL#')
                   || '|' ||
                    NVL(MUNICIPALITIE,'#NULL#')
                   || '|' ||
                    NVL(MUNICIPALITIE_DESIGNATION_CODE,'#NULL#')
                   || '|' ||
                    NVL(MRC_CODE,'#NULL#')
                   || '|' ||
                    NVL(MRC,'#NULL#')
                   || '|' ||
                    NVL(ADMINISTRATIVE_REGION_CODE,'#NULL#')
                   || '|' ||
                    NVL(ADMINISTRATIVE_REGION,'#NULL#')
                ) 
                )::string AS MD_HASHDIFF,             
                MD_CREATION_DT,
                MD_SOURCE,
                POSTAL_CODE_ID,
                POSTAL_CODE,
                POSTAL_CODE_ABBR,
                ELECTORAL_DIVISION_CODE,
                ELECTORAL_DIVISION,
                MUNICIPALITIE_CODE,
                MUNICIPALITIE,
                MUNICIPALITIE_DESIGNATION_CODE,
                MRC_CODE,
                MRC,
                ADMINISTRATIVE_REGION_CODE,
                ADMINISTRATIVE_REGION
                FROM DB_AC_DEV_STG.GOV_MODEL_REFERENCE.ADMINISTRATIVE_ENTITIES

);
create or replace schema PLATEFORME_RECEPTION;

create or replace TABLE CUSTOMER (
	DATA VARIANT
);
create or replace TABLE CUSTOMER_PERSONAL_INTEREST (
	DATA VARIANT
);
create or replace TABLE PERSONAL_INTEREST (
	DATA VARIANT
);
create or replace TABLE PRODUCT (
	DATA VARIANT
);
create or replace TABLE PRODUCT_CATALOG (
	DATA VARIANT
);
create or replace TABLE SHOPPING_CART_ITEMS (
	DATA VARIANT
);
create or replace TABLE SHOPPING_REQUEST (
	DATA VARIANT
);
create or replace TABLE TEST_ALEX (
	DATA VARIANT
);
create or replace TABLE WORKER (
	DATA VARIANT
);
create or replace view VW_U_CUSTOMER_PERSONAL_INTEREST(
	CUSTOMER_ID,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	INTEREST_ID
) as 
(
    SELECT distinct
    DATA:data:customerId::STRING AS CUSTOMER_ID,
    CURRENT_TIMESTAMP()::timestamp_ntz  AS MD_START_DT,
    CURRENT_TIMESTAMP()::timestamp_ntz AS MD_CREATION_DT,
    'customer.personalInterestUpdated' AS MD_SOURCE,
    vm.value:interestId::STRING AS INTEREST_ID
    FROM PLATEFORME_RECEPTION.CUSTOMER_PERSONAL_INTEREST a,   
    lateral flatten(input => DATA:data:interestList) vm  
);
create or replace view VW_U_PERSONAL_INTEREST(
	INTEREST_ID,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	NAME_FR,
	NAME_EN,
	TAGS
) as 
(
    SELECT
    DATA:data:interestId::STRING AS INTEREST_ID,
    CURRENT_TIMESTAMP()::timestamp_ntz  AS MD_START_DT,
    CURRENT_TIMESTAMP()::timestamp_ntz AS MD_CREATION_DT,
    'personalInterest.updated' AS MD_SOURCE,
    DATA:data:nameFr::STRING AS NAME_FR,
    DATA:data:nameEn::STRING AS NAME_EN,
    DATA:data:tags::STRING AS TAGS
    FROM PLATEFORME_RECEPTION.PERSONAL_INTEREST
);
create or replace schema PLT_EVENTS_CAMPAIGN;

create or replace TABLE UPLOADED (
	CAMPAIGN_ID VARCHAR(16777216) COMMENT 'Campaign plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace view VW_CAMPAIGN(
	HK_HUB COMMENT 'Hash of the business keys',
	MD_START_DT COMMENT 'Event plateforme date',
	MD_HASHDIFF COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT COMMENT 'Row creation date and time',
	MD_SOURCE COMMENT 'Source JSON file full name',
	CAMPAIGN_ID COMMENT 'Campaign plateform ID',
	TYPE COMMENT 'Campaign Type',
	ORGANIZATION_ID COMMENT 'Name of the organisation',
	WORKER_GROUP COMMENT 'Name of worker group',
	JOB_CATEGORY COMMENT 'the name of job category',
	GROUP_TYPE_CODE COMMENT 'group type code',
	GROUP_REFERENCES COMMENT ' group references',
	SCHEDULED_TIME,
	BEGINS_ON COMMENT 'campaign start date',
	ENDS_ON COMMENT 'campaign end date',
	BENEFITS_EFFECTIVE_DATE COMMENT 'The date on which benefits will start',
	ELIGIBILITY_RULE_SET COMMENT 'rule for eligibility of the benefits',
	IS_STARTED COMMENT 'campaign is on way or not'
) as
(
        SELECT 
				DB_AC_DEV_STG.PLT_MODEL_SHARED.UF_HASH_HK_HUB_CAMPAIGN(CAMPAIGN_ID) AS HK_HUB,
				MD_START_DT,
                DB_AC_DEV_STG.PLT_MODEL_SHARED.UF_HASHDIFF_CAMPAIGN(TYPE,ORGANIZATION_ID, WORKER_GROUP,JOB_CATEGORY,GROUP_TYPE_CODE,GROUP_REFERENCES,SCHEDULED_TIME, BEGINS_ON,ENDS_ON,BENEFITS_EFFECTIVE_DATE ,ELIGIBILITY_RULE_SET, IS_STARTED) AS MD_HASHDIFF,
				CURRENT_TIMESTAMP AS MD_CREATION_DT,
				MD_SOURCE,
				CAMPAIGN_ID,
				TYPE,
				ORGANIZATION_ID,
				WORKER_GROUP,
				JOB_CATEGORY,
				GROUP_TYPE_CODE,
				GROUP_REFERENCES,
				SCHEDULED_TIME,
				BEGINS_ON,
				ENDS_ON,
				BENEFITS_EFFECTIVE_DATE,
				ELIGIBILITY_RULE_SET,
				IS_STARTED
        FROM (SELECT        
               CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,
			   CONTENT:data:campaignId::STRING AS CAMPAIGN_ID,
               MD_SOURCE,
               CONTENT:data:type::STRING AS TYPE,
               CONTENT:data:organizationId::STRING AS ORGANIZATION_ID,
			   CONTENT:data:workerGroup::STRING AS WORKER_GROUP,
			   CONTENT:data:jobCategory::STRING AS JOB_CATEGORY,
			   CONTENT:data:groupTypeCode::STRING AS GROUP_TYPE_CODE,
			   CONTENT:data:groupReferences::STRING AS GROUP_REFERENCES,
			   CONTENT:data:scheduledTime::TIME AS SCHEDULED_TIME,
			   CONTENT:data:beginsOn::TIMESTAMP AS BEGINS_ON,
			   CONTENT:data:endsOn::TIMESTAMP AS ENDS_ON,
			   CONTENT:data:benefitsEffectiveDate::DATE AS BENEFITS_EFFECTIVE_DATE,
			   CONTENT:data:eligibilityRuleSet::STRING AS ELIGIBILITY_RULE_SET,
			   CONTENT:data:isStarted::STRING AS IS_STARTED
        FROM DB_AC_DEV_STG.PLT_EVENTS_CAMPAIGN.UPLOADED) 
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_CAMPAIGN_U"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var DEL_QUERY = "DELETE FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_CAMPAIGN.UPLOADED;";
var COPY_QUERY = "INSERT INTO DB_AC_"+ ENV +"_STG.PLT_EVENTS_CAMPAIGN.UPLOADED (CAMPAIGN_ID, MD_START_DT, MD_CREATION_DT, MD_SOURCE,CONTENT) SELECT ''01c997d1-a2b8-47cd-a846-10373bff8f8e'',null,null,''platform'',PARSE_JSON(''{\\"data\\":{\\"timestamp\\":\\"2022-11-16 00:00:00\\",\\"campaignId\\":\\"01c997d1-a2b8-47cd-a846-10373bff8f8e\\",\\"type\\":\\"RenewalBenefitsCampaign\\",\\"organizationId\\":\\"Polytechnic\\",\\"workerGroup\\":\\"0000028778-00005-502\\",\\"jobCategory\\":null,\\"groupTypeCode\\":null,\\"groupReferences\\":null,\\"scheduledTime\\":\\"00:00:00\\",\\"beginsOn\\":\\"2020-08-23T00:00:00\\",\\"endsOn\\":\\"2020-10-12\\",\\"benefitsEffectiveDate\\":\\"2020-11-01\\",\\"eligibilityRuleSet\\":null,\\"isStarted\\":true}}'')AS JSON; ";

   var sql_statement = snowflake.createStatement(
          {
          sqlText: DEL_QUERY
          }
       );
   var result_scan = sql_statement.execute();
       
      
   
   
   var sql_statement = snowflake.createStatement(
          {
          sqlText: COPY_QUERY
          }
       );
   var result_scan = sql_statement.execute();
   


';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_CAMPAIGN_U_TEST"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var COPY_QUERY = ''INSERT INTO DB_AC_''+ ENV +''_STG.PLT_EVENTS_CAMPAIGN.UPLOADED (CAMPAIGN_ID, MD_START_DT, MD_CREATION_DT, MD_SOURCE,CONTENT) SELECT "01c997d1-a2b8-47cd-a846-10373bff8f8e",null,null,"platform",PARSE_JSON(''\\{"data":{"timestamp":"2022-11-16 00:00:00","campaignId":"01c997d1-a2b8-47cd-a846-10373bff8f8e","type":"RenewalBenefitsCampaign","organizationId":"Polytechnic","workerGroup":"0000028778-00005-502","jobCategory":null,"groupTypeCode":null,"groupReferences":null,"scheduledTime":"00:00:00","beginsOn":"2020-08-23T00:00:00","endsOn":"2020-10-12","benefitsEffectiveDate":"2020-11-01","eligibilityRuleSet":null,"isStarted":true}}''\\)AS JSON; ''; 
return COPY_QUERY
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_SHOPPING_REQUEST_ABANDONED"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var DEL_QUERY = "DELETE FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_CAMPAIGN.UPLOADED;";
var COPY_QUERY = "INSERT INTO DB_AC_DEV_STG.PLT_EVENTS_CAMPAIGN.UPLOADED (CAMPAIGN_ID, MD_START_DT, MD_CREATION_DT, MD_SOURCE,CONTENT) SELECT ''01c997d1-a2b8-47cd-a846-10373bff8f8e'',null,null,''platform'',PARSE_JSON(''{\\"data\\":{\\"timestamp\\":\\"2022-11-16 00:00:00\\",\\"campaignId\\":\\"01c997d1-a2b8-47cd-a846-10373bff8f8e\\",\\"type\\":\\"RenewalBenefitsCampaign\\",\\"organizationId\\":\\"Polytechnic\\",\\"workerGroup\\":\\"0000028778-00005-502\\",\\"jobCategory\\":null,\\"groupTypeCode\\":null,\\"groupReferences\\":null,\\"scheduledTime\\":\\"00:00:00\\",\\"beginsOn\\":\\"2020-08-23T00:00:00\\",\\"endsOn\\":\\"2020-10-12\\",\\"benefitsEffectiveDate\\":\\"2020-11-01\\",\\"eligibilityRuleSet\\":null,\\"isStarted\\":true}}'')AS JSON; ";

   var sql_statement = snowflake.createStatement(
          {
          sqlText: DEL_QUERY
          }
       );
   var result_scan = sql_statement.execute();
       
      
   
   
   var sql_statement = snowflake.createStatement(
          {
          sqlText: COPY_QUERY
          }
       );
   var result_scan = sql_statement.execute();
   


';
create or replace schema PLT_EVENTS_CUSTOMER;

create or replace TRANSIENT TABLE ORDER_CREATED (
	ORDER_ID VARCHAR(16777216) COMMENT 'Order plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE ORDER_UPLOADED (
	ORDER_ID VARCHAR(16777216) COMMENT 'Order plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE PERSONAL_INFO_UPDATED (
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE PERSONAL_INTEREST_UPDATED (
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE SHOPPING_REQUEST_ABANDONED (
	SHOPPING_REQUEST_ID VARCHAR(16777216) COMMENT 'Shopping Request plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace view VW_OC_ORDER_CUSTOMER(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_ORDER_ID,
	HK_HUB_CUSTOMER_ID,
	MD_HASHDIFF,
	ORDER_ID,
	CUSTOMER_ID,
	CREATION_DT,
	AMOUNT,
	AMOUNT_AFTER_TAX
) as
(
SELECT 
 
    PLT_MODEL_SHOPPING.UF_HASH_HK_LINK_ORDER_CUSTOMER(ORDER_ID,CUSTOMER_ID) AS HK_LINK,
    MD_START_DT,               
    CURRENT_TIMESTAMP AS MD_CREATION_DT,
    MD_SOURCE,                
    PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_ORDER(ORDER_ID) AS HK_HUB_ORDER_ID,
    PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB_CUSTOMER_ID , 
    PLT_MODEL_SHOPPING.UF_HASHDIFF_ORDER(CREATION_DT,AMOUNT,AMOUNT_AFTER_TAX) AS MD_HASHDIFF,
    ORDER_ID,
    CUSTOMER_ID,
    CREATION_DT,
    AMOUNT,
    AMOUNT_AFTER_TAX
    
 FROM (
   SELECT 
          CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,               
          MD_SOURCE,
          CONTENT:data:order:orderId::STRING AS ORDER_ID,
          CONTENT:data:customerId::STRING  AS CUSTOMER_ID,
          CONTENT:data:order:creationDate::DATE  AS CREATION_DT,
          CONTENT:data:order:amount::NUMERIC(14,2) AS AMOUNT,
          CONTENT:data:order:amountAfterTax::NUMERIC(14,2) AS AMOUNT_AFTER_TAX
   FROM PLT_EVENTS_CUSTOMER.ORDER_CREATED
    )
 );
create or replace view VW_OC_ORDER_SELECTED_PRODUCTS(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_ORDER_ID,
	HK_HUB_PRODUCT_ID,
	MD_HASHDIFF,
	ORDER_ID,
	PRODUCT_ID,
	QUANTITY,
	AMOUNT
) as
(
SELECT 
         PLT_MODEL_SHOPPING.UF_HASH_HK_LINK_ORDER_ITEM(ORDER_ID,SELECTED_PRODUCT_ID) AS HK_LINK,
         MD_START_DT,               
         CURRENT_TIMESTAMP AS MD_CREATION_DT,
		 MD_SOURCE,
                
         PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_ORDER(ORDER_ID) AS HK_HUB_ORDER_ID,
         PLT_MODEL_SHARED.UF_HASH_HK_HUB_PRODUCT(SELECTED_PRODUCT_ID) AS HK_HUB_PRODUCT_ID, 
         PLT_MODEL_SHOPPING.UF_HASHDIFF_ORDER_ITEM(QUANTITY,AMOUNT) AS MD_HASHDIFF,
         ORDER_ID,
         SELECTED_PRODUCT_ID AS PRODUCT_ID,
         QUANTITY,
         AMOUNT
 FROM ( 
        SELECT CONTENT:data:order:orderId::STRING as ORDER_ID,
            value:productId::STRING as SELECTED_PRODUCT_ID,
            CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,
            MD_SOURCE,
            value:quantity::NUMBER AS QUANTITY,
            value:amount::NUMERIC(14,2) AS AMOUNT
        FROM  PLT_EVENTS_CUSTOMER.ORDER_CREATED,
              LATERAL FLATTEN(input => CONTENT:data:order:orderItems)
        WHERE value:productId::STRING IS NOT NULL 
   )
);
create or replace view VW_OC_ORDER_STATUS(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	ORDER_ID,
	STATUS,
	STATUS_DATE
) as
(
                   
SELECT 
            PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_ORDER(ORDER_ID) AS HK_HUB,
            MD_START_DT,
            PLT_MODEL_SHOPPING.UF_HASHDIFF_ORDER_STATUS(STATUS,STATUS_DATE) AS MD_HASHDIFF,
            CURRENT_TIMESTAMP AS MD_CREATION_DT,
	        MD_SOURCE ,
            ORDER_ID,
            STATUS,
            STATUS_DATE             
FROM (
   SELECT 
          CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,               
          MD_SOURCE,
          CONTENT:data:order:orderId::STRING AS ORDER_ID,
          CONTENT:data:customerId::STRING  AS CUSTOMER_ID,
          CONTENT:data.order.orderStatus.status::STRING  AS STATUS ,
          CONTENT:data.order.orderStatus.statusDate::DATE AS STATUS_DATE 
   FROM PLT_EVENTS_CUSTOMER.ORDER_CREATED
    ) 
);
create or replace view VW_OU_ORDER_CUSTOMER(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_ORDER_ID,
	HK_HUB_CUSTOMER_ID,
	MD_HASHDIFF,
	ORDER_ID,
	CUSTOMER_ID,
	CREATION_DT,
	AMOUNT,
	AMOUNT_AFTER_TAX
) as
(
SELECT 
 
    PLT_MODEL_SHOPPING.UF_HASH_HK_LINK_ORDER_CUSTOMER(ORDER_ID,CUSTOMER_ID) AS HK_LINK,
    MD_START_DT,               
    CURRENT_TIMESTAMP AS MD_CREATION_DT,
    MD_SOURCE,                
    PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_ORDER(ORDER_ID) AS HK_HUB_ORDER_ID,
    PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB_CUSTOMER_ID , 
    PLT_MODEL_SHOPPING.UF_HASHDIFF_ORDER(CREATION_DT,AMOUNT,AMOUNT_AFTER_TAX) AS MD_HASHDIFF,
    ORDER_ID,
    CUSTOMER_ID,
    CREATION_DT,
    AMOUNT,
    AMOUNT_AFTER_TAX
 FROM (
   SELECT 
          CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,               
          MD_SOURCE,
          CONTENT:data:order:orderId::STRING AS ORDER_ID,
          CONTENT:data:customerId::STRING  AS CUSTOMER_ID,
          CONTENT:data:order:creationDate::DATE  AS CREATION_DT,
          CONTENT:data:order:amount::NUMERIC(14,2) AS AMOUNT,
          CONTENT:data:order:amountAfterTax::NUMERIC(14,2) AS AMOUNT_AFTER_TAX   
   FROM PLT_EVENTS_CUSTOMER.ORDER_UPLOADED
    )
 );
create or replace view VW_OU_ORDER_SELECTED_PRODUCTS(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_ORDER_ID,
	HK_HUB_PRODUCT_ID,
	MD_HASHDIFF,
	ORDER_ID,
	PRODUCT_ID,
	QUANTITY,
	AMOUNT
) as
(
SELECT 
         PLT_MODEL_SHOPPING.UF_HASH_HK_LINK_ORDER_ITEM(ORDER_ID,SELECTED_PRODUCT_ID) AS HK_LINK,
         MD_START_DT,               
         CURRENT_TIMESTAMP AS MD_CREATION_DT,
		 MD_SOURCE,                
         PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_ORDER(ORDER_ID) AS HK_HUB_ORDER_ID,
         PLT_MODEL_SHARED.UF_HASH_HK_HUB_PRODUCT(SELECTED_PRODUCT_ID) AS HK_HUB_PRODUCT_ID, 
         PLT_MODEL_SHOPPING.UF_HASHDIFF_ORDER_ITEM(QUANTITY) AS MD_HASHDIFF,
         ORDER_ID,
         SELECTED_PRODUCT_ID AS PRODUCT_ID,
         QUANTITY,
         AMOUNT
 FROM ( 
        SELECT CONTENT:data:order:orderId::STRING as ORDER_ID,
            value:productId::STRING as SELECTED_PRODUCT_ID,
            CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,
            MD_SOURCE,
            value:quantity::NUMBER AS QUANTITY,
            value:amount::NUMERIC(14,2) AS AMOUNT
        FROM  PLT_EVENTS_CUSTOMER.ORDER_UPLOADED,
              LATERAL FLATTEN(input => CONTENT:data:order:orderItems)
        WHERE value:productId::STRING IS NOT NULL 
   )
);
create or replace view VW_OU_ORDER_STATUS(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	ORDER_ID,
	STATUS,
	STATUS_DATE
) as
(
                   
SELECT 
            PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_ORDER(ORDER_ID) AS HK_HUB,
            MD_START_DT,
            PLT_MODEL_SHOPPING.UF_HASHDIFF_ORDER_STATUS(STATUS,STATUS_DATE) AS MD_HASHDIFF,
            CURRENT_TIMESTAMP AS MD_CREATION_DT,
	        MD_SOURCE ,
            ORDER_ID,
            STATUS,
            STATUS_DATE             
FROM (
   SELECT 
          CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,               
          MD_SOURCE,
          CONTENT:data:order:orderId::STRING AS ORDER_ID,
          CONTENT:data:customerId::STRING  AS CUSTOMER_ID,
          CONTENT:data.order.orderStatus.status::STRING  AS STATUS ,
          CONTENT:data.order.orderStatus.statusDate::DATE AS STATUS_DATE 
   FROM PLT_EVENTS_CUSTOMER.ORDER_UPLOADED
    ) 
);
create or replace view VW_PIU_CUSTOMER_PERSONAL_INTEREST(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_CUSTOMER_ID,
	HK_HUB_INTEREST_ID,
	CUSTOMER_ID,
	INTEREST_ID
) as
(
  SELECT  PLT_MODEL_SUBSCRIPTION.UF_HASH_HK_LINK_CUSTOMER_PERSONAL_INTEREST(CUSTOMER_ID,INTEREST_ID) AS HK_LINK,
		MD_START_DT, 
		PLT_MODEL_SUBSCRIPTION.UF_HASHDIFF_CUSTOMER_PERSONAL_INTEREST(MD_START_DT) AS MD_HASHDIFF,
        CURRENT_TIMESTAMP AS MD_CREATION_DT,
		MD_SOURCE,
        PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB_CUSTOMER_ID , 
        PLT_MODEL_PRODUCT.UF_HASH_HK_HUB_PERSONAL_INTEREST(INTEREST_ID) AS HK_HUB_INTEREST_ID , 
		CUSTOMER_ID,
        INTEREST_ID
    FROM ( SELECT  
        CONTENT:data:customerId::STRING as CUSTOMER_ID,
        CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
        MD_SOURCE,
        value:interestId::STRING as INTEREST_ID
        FROM PLT_EVENTS_CUSTOMER.PERSONAL_INTEREST_UPDATED, 
            lateral flatten(input => CONTENT:data:interestList)      
        )
);
create or replace view VW_PIU_PERSONAL_INFO(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	MONTH_OF_BIRTH,
	GENDER
) as
(
  SELECT  PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB,
            MD_START_DT,       
			PLT_MODEL_SHARED.UF_HASHDIFF_PERSONAL_INFO(MONTH_OF_BIRTH,GENDER) AS MD_HASHDIFF,
			CURRENT_TIMESTAMP AS MD_CREATION_DT,
			MD_SOURCE,
            CUSTOMER_ID,
            MONTH_OF_BIRTH,
            GENDER
	FROM (  SELECT  
               CONTENT:data:customerId::STRING as CUSTOMER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:personalInfo:dateOfBirth::DATE as MONTH_OF_BIRTH,
               CONTENT:data:personalInfo:gender::STRING AS GENDER
            FROM PLT_EVENTS_CUSTOMER.PERSONAL_INFO_UPDATED 
         ) 
);
create or replace view VW_PIU_PERSONAL_INFO_ADDRESS(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	POSTAL_CODE_PARTIAL,
	PROVINCE,
	COUNTRY
) as
(
  SELECT  PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB,
		MD_START_DT, 
		PLT_MODEL_SHARED.UF_HASHDIFF_ADDRESS(POSTAL_CODE_PARTIAL,PROVINCE,COUNTRY) AS MD_HASHDIFF,
        CURRENT_TIMESTAMP AS MD_CREATION_DT,
		MD_SOURCE,
		CUSTOMER_ID,
        POSTAL_CODE_PARTIAL,
        PROVINCE,
        COUNTRY
    FROM ( SELECT  
        CONTENT:data:customerId::STRING as CUSTOMER_ID,
        CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
        MD_SOURCE,
        CONTENT:data:personalInfo:address:postalCodePartial::STRING as POSTAL_CODE_PARTIAL,
        CONTENT:data:personalInfo:address:province::STRING AS PROVINCE,
        CONTENT:data:personalInfo:address:country::STRING AS COUNTRY
      FROM PLT_EVENTS_CUSTOMER.PERSONAL_INFO_UPDATED 
    )
);
create or replace view VW_SRA_ORDER_STATUS(
	ORDER_ID,
	EVENT_TIMESTAMP,
	STATUS,
	STATUS_DATE
) as
(
       SELECT CONTENT:data:orderId::STRING as ORDER_ID,
              CONTENT:eventTimestamp::TIMESTAMP as EVENT_TIMESTAMP,
              CONTENT:data:orderStatus:status::STRING as STATUS,
              CONTENT:data:orderStatus:statusDate::DATE AS STATUS_DATE
       FROM PLT_EVENTS_CUSTOMER.SHOPPING_REQUEST_ABANDONED
);
create or replace view VW_SRA_SELECTED_PRODUCT(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_SHOPPING_REQUEST,
	HK_HUB_PRODUCT,
	MD_HASHDIFF,
	SHOPPING_REQUEST_ID,
	PRODUCT_ID,
	QUANTITY
) as
(
        SELECT 
                PLT_MODEL_SHOPPING.UF_HASH_HK_LINK_SHOPPING_ITEM(SHOPPING_REQUEST_ID,SELECTED_PRODUCT_ID) AS HK_LINK,
                MD_START_DT,               
                CURRENT_TIMESTAMP AS MD_CREATION_DT,
			    MD_SOURCE, 
                PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_SHOPPING_REQUEST(SHOPPING_REQUEST_ID) AS HK_HUB_SHOPPING_REQUEST,
                PLT_MODEL_SHARED.UF_HASH_HK_HUB_PRODUCT(SELECTED_PRODUCT_ID)  AS HK_HUB_PRODUCT,  
                PLT_MODEL_SHOPPING.UF_HASHDIFF_SHOPPING_ITEM(QUANTITY) AS MD_HASHDIFF,
                SHOPPING_REQUEST_ID,
                SELECTED_PRODUCT_ID AS PRODUCT_ID,
                QUANTITY                
        FROM ( 
                SELECT CONTENT:data:shoppingRequest:shoppingRequestId::STRING AS SHOPPING_REQUEST_ID,
                value:productId::STRING as SELECTED_PRODUCT_ID,
                CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,
                MD_SOURCE,
                value:quantity::NUMBER AS QUANTITY               
             FROM  PLT_EVENTS_CUSTOMER.SHOPPING_REQUEST_ABANDONED,
             LATERAL FLATTEN(input => CONTENT:data:shoppingRequest:selectedProducts)
             WHERE value:productId::STRING IS NOT NULL 
   )
);
create or replace view VW_SRA_SHOPPING_REQUEST(
	HK_LINK,
	MD_START_DT,
	HK_HUB_SHOPPING_REQUEST,
	HK_HUB_CUSTOMER,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	SHOPPING_REQUEST_ID,
	CUSTOMER_ID,
	CREATION_DATE,
	STATUS
) as
(
        SELECT 
            PLT_MODEL_SHOPPING.UF_HASH_HK_LINK_SHOPPING_CUSTOMER(SHOPPING_REQUEST_ID,CUSTOMER_ID) AS HK_LINK,
            MD_START_DT,
            PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_SHOPPING_REQUEST(SHOPPING_REQUEST_ID) AS HK_HUB_SHOPPING_REQUEST,
            PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB_CUSTOMER,
            PLT_MODEL_SHOPPING.UF_HASHDIFF_SHOPPING_REQUEST(CREATION_DATE, STATUS) AS MD_HASHDIFF, 
            CURRENT_TIMESTAMP AS MD_CREATION_DT,
            MD_SOURCE,      
            SHOPPING_REQUEST_ID,
            CUSTOMER_ID,
            CREATION_DATE,                     
            STATUS     
        FROM (     
            SELECT 
                    CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,               
                    MD_SOURCE,
                    CONTENT:data:customerId::STRING  AS CUSTOMER_ID,
                    CONTENT:data:shoppingRequest:shoppingRequestId::STRING AS SHOPPING_REQUEST_ID,
                    CONTENT:data:shoppingRequest:creationDate::DATE AS CREATION_DATE,
                    'Abandoned' AS STATUS
             FROM PLT_EVENTS_CUSTOMER.SHOPPING_REQUEST_ABANDONED
        )
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_CUSTOMER_OC"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var DEL_QUERY = "DELETE FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_CUSTOMER.ORDER_CREATED;";
var COPY_QUERY = "COPY INTO DB_AC_"+ ENV +"_STG.PLT_EVENTS_CUSTOMER.ORDER_CREATED(ORDER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT)  FROM ( SELECT t.$1:data.order.orderId, t.$1:data.timestamp, current_timestamp(),  metadata$filename , t.$1 FROM @DATALAKE.RAW/CUSTOMER/ t) PATTERN=''.*customer.orderCreated.*json'' FILE_FORMAT = ( TYPE = JSON) FORCE = false; ";

   var sql_statement = snowflake.createStatement(
          {
          sqlText: DEL_QUERY
          }
       );
   var result_scan = sql_statement.execute();
       
      
   
   
   var sql_statement = snowflake.createStatement(
          {
          sqlText: COPY_QUERY
          }
       );
   var result_scan = sql_statement.execute();
   


';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_CUSTOMER_PERSONAL_INFO_UPDATED"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var DEL_QUERY = "DELETE FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_CUSTOMER.PERSONAL_INFO_UPDATED;";
var COPY_QUERY = "COPY INTO DB_AC_"+ ENV +"_STG.PLT_EVENTS_CUSTOMER.PERSONAL_INFO_UPDATED(CUSTOMER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE,CONTENT)  FROM ( SELECT  t.$1:data.customerId,  t.$1:data.timestamp,  current_timestamp(), metadata$filename ,  t.$1  FROM @DATALAKE.RAW/CUSTOMER/ t)  PATTERN=''.*customer.personalInfoUpdated.*json''  FILE_FORMAT = ( TYPE = JSON) FORCE = false; ";

   var sql_statement = snowflake.createStatement(
          {
          sqlText: DEL_QUERY
          }
       );
   var result_scan = sql_statement.execute();
       
      
   
   
   var sql_statement = snowflake.createStatement(
          {
          sqlText: COPY_QUERY
          }
       );
   var result_scan = sql_statement.execute();
   


';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_CUSTOMER_PIU"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '



var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_CUSTOMER.PERSONAL_INTEREST_UPDATED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_CUSTOMER.PERSONAL_INTEREST_UPDATED (CUSTOMER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT CUSTOMER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_CUSTOMER.PERSONAL_INTEREST_UPDATED \\n \\
WHERE  CUSTOMER_ID= -1 )";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_CUSTOMER.PERSONAL_INTEREST_UPDATED(CUSTOMER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.customerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/CUSTOMER/ t) \\n \\
PATTERN=''.*customer.personalInterestUpdated.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 

try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_SHOPPING_REQUEST_ABANDONED"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var DEL_QUERY = "DELETE FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_CUSTOMER.SHOPPING_REQUEST_ABANDONED;";
var COPY_QUERY = "COPY INTO DB_AC_"+ ENV +"_STG.PLT_EVENTS_CUSTOMER.SHOPPING_REQUEST_ABANDONED(SHOPPING_REQUEST_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE,CONTENT) FROM ( SELECT t.$1:data.shoppingRequest.shoppingRequestId, t.$1:data.timestamp, current_timestamp(), metadata$filename , t.$1 FROM @DATALAKE.RAW/CUSTOMER/ t) PATTERN=''.*customer.shoppingRequestAbandoned.*json'' FILE_FORMAT = ( TYPE = JSON) FORCE = false; ";

   var sql_statement = snowflake.createStatement(
          {
          sqlText: DEL_QUERY
          }
       );
   var result_scan = sql_statement.execute();
       
      
   
   
   var sql_statement = snowflake.createStatement(
          {
          sqlText: COPY_QUERY
          }
       );
   var result_scan = sql_statement.execute();
   


';
create or replace schema PLT_EVENTS_OPEN_SHOPPING_PERIOD;

create or replace TABLE UPLOADED (
	OPEN_SHOPPING_PERIOD_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	CONTENT VARIANT
);
create or replace view VW_U_ENROLLMENT(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	OPEN_SHOPPING_PERIOD_ID,
	HK_HUB_OPEN_SHOPPING_PERIOD,
	HK_HUB_PRODUCT_CATALOG,
	HK_HUB_PREVIOUS_PRODUCT_CATALOG,
	HK_HUB_WORKER,
	HK_HUB_CUSTOMER,
	HK_HUB_ORGANIZATION,
	HK_HUB_CAMPAIGN,
	HK_HUB_LIFE_EVENT,
	PRODUCT_CATALOG_ID,
	PREVIOUS_PRODUCT_CATALOG_ID,
	WORKER_ID,
	CUSTOMER_ID,
	ORGANIZATION_ID,
	CAMPAIGN_ID,
	LIFE_EVENT_ID
) as (        
        SELECT 
             PLT_MODEL_SHOPPING.UF_HASH_HK_LINK_ENROLLED(OPEN_SHOPPING_PERIOD_ID,PRODUCT_CATALOG_ID,PREVIOUS_PRODUCT_CATALOG_ID,WORKER_ID,CUSTOMER_ID,ORGANIZATION_ID,CAMPAIGN_ID,LIFE_EVENT_ID) AS HK_LINK,
             MD_START_DT,
             CURRENT_TIMESTAMP as MD_CREATION_DT,
             MD_SOURCE,
             OPEN_SHOPPING_PERIOD_ID,             
             PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_OPEN_SHOPPING_PERIOD_ID(OPEN_SHOPPING_PERIOD_ID) AS HK_HUB_OPEN_SHOPPING_PERIOD,
             PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_PRODUCT_CATALOG_ID(PRODUCT_CATALOG_ID) AS HK_HUB_PRODUCT_CATALOG,
             PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_PREVIOUS_PRODUCT_CATALOG_ID(PREVIOUS_PRODUCT_CATALOG_ID) AS HK_HUB_PREVIOUS_PRODUCT_CATALOG,
             PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB_WORKER,
             PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB_CUSTOMER,
             PLT_MODEL_SHARED.UF_HASH_HK_HUB_ORGANIZATION(ORGANIZATION_ID) AS HK_HUB_ORGANIZATION,
             PLT_MODEL_SHARED.UF_HASH_HK_HUB_CAMPAIGN(CAMPAIGN_ID) AS HK_HUB_CAMPAIGN,
             PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_LIFE_EVENT(LIFE_EVENT_ID) AS HK_HUB_LIFE_EVENT,            
             PRODUCT_CATALOG_ID,
             PREVIOUS_PRODUCT_CATALOG_ID,
             WORKER_ID,
             CUSTOMER_ID,
             ORGANIZATION_ID,            
             CAMPAIGN_ID,
             LIFE_EVENT_ID
             FROM (SELECT 
                  CONTENT:data:openShoppingPeriodId::NUMBER AS OPEN_SHOPPING_PERIOD_ID,                 
                  CONTENT:data:productCatalogId::STRING AS PRODUCT_CATALOG_ID,
                  CONTENT:data:previousProductCatalogId::STRING AS PREVIOUS_PRODUCT_CATALOG_ID,
                  CONTENT:data:workerId::STRING AS WORKER_ID,
                  CONTENT:data:customerId::STRING AS CUSTOMER_ID,
                  CONTENT:data:organizationId::STRING AS ORGANIZATION_ID,                  
                  CONTENT:data:campaignId::STRING AS CAMPAIGN_ID,
                  CONTENT:data:lifeEventId::STRING AS LIFE_EVENT_ID,
                  CONTENT:data:timestamp::TIMESTAMP as MD_START_DT, 
                  MD_SOURCE
                  FROM PLT_EVENTS_OPEN_SHOPPING_PERIOD.UPLOADED
                  ) js
                  );
create or replace view VW_U_OPEN_SHOPPING_PERIOD(
	HK_HUB,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	OPEN_SHOPPING_PERIOD_ID,
	REASON,
	BEGINSON,
	ENDSON,
	EFFECTIVE_DATE,
	EXPIRATION_DATE,
	STATUS,
	MD_HASHDIFF
) as ( SELECT 
        PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_OPEN_SHOPPING_PERIOD_ID(OPEN_SHOPPING_PERIOD_ID) AS HK_HUB,        
        MD_START_DT,
        CURRENT_TIMESTAMP as MD_CREATION_DT,
        MD_SOURCE,
        OPEN_SHOPPING_PERIOD_ID,    
        REASON,
        BEGINSON,
        ENDSON, 
        EFFECTIVE_DATE,
        EXPIRATION_DATE,
        STATUS,
        PLT_MODEL_SHOPPING.UF_HASHDIFF_OPEN_SHOPPING_PERIOD(REASON,BEGINSON,ENDSON,EFFECTIVE_DATE,EXPIRATION_DATE,STATUS ) AS MD_HASHDIFF        
        FROM (SELECT distinct 
                  CONTENT:data:openShoppingPeriodId::NUMBER AS OPEN_SHOPPING_PERIOD_ID,                  
                  CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
                  CONTENT:data:reason::STRING AS REASON,
                  CONTENT:data:beginsOn::DATE AS BEGINSON,
                  CONTENT:data:endsOn::DATE AS ENDSON,
                  CONTENT:data:effectiveDate::DATE AS EFFECTIVE_DATE,
                  CONTENT:data:expirationDate::DATE AS EXPIRATION_DATE,
                  CONTENT:data:status::STRING AS STATUS,
                  MD_SOURCE                  
                  FROM PLT_EVENTS_OPEN_SHOPPING_PERIOD.UPLOADED) js);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_OPEN_SHOPPING_PERIOD"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var DEL_QUERY = "DELETE FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_OPEN_SHOPPING_PERIOD.UPLOADED;";
var COPY_QUERY = "COPY INTO DB_AC_"+ ENV +"_STG.PLT_EVENTS_OPEN_SHOPPING_PERIOD.UPLOADED(OPEN_SHOPPING_PERIOD_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT)  FROM ( SELECT  t.$1:data.order.orderId,  t.$1:data.timestamp,  current_timestamp(),  metadata$filename ,  t.$1  FROM @DATALAKE.RAW/OPENSHOPPINGPERIOD/ t)  PATTERN=''.*openShoppingPeriod.uploaded.*json''  FILE_FORMAT = ( TYPE = JSON) FORCE = false; ";

   var sql_statement = snowflake.createStatement(
          {
          sqlText: DEL_QUERY
          }
       );
   var result_scan = sql_statement.execute();
       
      
   
   
   var sql_statement = snowflake.createStatement(
          {
          sqlText: COPY_QUERY
          }
       );
   var result_scan = sql_statement.execute();
   


';
create or replace schema PLT_EVENTS_PERSONAL_INTEREST;

create or replace TRANSIENT TABLE UPDATED (
	INTEREST_ID VARCHAR(16777216) COMMENT 'Interest plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace view VW_U_PERSONAL_INTEREST(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	INTEREST_ID,
	NAME_FR,
	NAME_EN
) as
(
  SELECT  PLT_MODEL_PRODUCT.UF_HASH_HK_HUB_PERSONAL_INTEREST(INTEREST_ID) AS HK_HUB , 
		MD_START_DT, 
		PLT_MODEL_PRODUCT.UF_HASHDIFF_PERSONAL_INTEREST(NAME_FR, NAME_EN) AS MD_HASHDIFF,
        CURRENT_TIMESTAMP AS MD_CREATION_DT,
		MD_SOURCE,
        INTEREST_ID,
        NAME_FR, 
		NAME_EN
    FROM ( SELECT  
        CONTENT:data:interestId::STRING as INTEREST_ID,
        CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
        MD_SOURCE,
        CONTENT:data:nameFr::STRING  as NAME_FR,
        CONTENT:data:nameEn::STRING  as NAME_EN
        FROM PLT_EVENTS_PERSONAL_INTEREST.UPDATED 
        )
);
create or replace view VW_U_PERSONAL_INTEREST_TAG(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_PERSONAL_INTEREST,
	HK_HUB_PRODUCT_TAG,
	INTEREST_ID,
	TAG
) as
(
  SELECT  PLT_MODEL_PRODUCT.UF_HASH_HK_LINK_PERSONAL_INTEREST_TAG(INTEREST_ID,TAG) AS HK_LINK,
		MD_START_DT, 
		PLT_MODEL_PRODUCT.UF_HASHDIFF_PERSONAL_INTEREST_TAG(MD_START_DT) AS MD_HASHDIFF,
        CURRENT_TIMESTAMP AS MD_CREATION_DT,
		MD_SOURCE,
        PLT_MODEL_PRODUCT.UF_HASH_HK_HUB_PERSONAL_INTEREST(INTEREST_ID) AS HK_HUB_PERSONAL_INTEREST,
        PLT_MODEL_PRODUCT.UF_HASH_HK_HUB_PRODUCT_TAG(TAG) AS HK_HUB_PRODUCT_TAG,
        INTEREST_ID,
        TAG
    FROM ( SELECT  
        CONTENT:data:interestId::STRING as INTEREST_ID,
        CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
        MD_SOURCE,
        value::STRING AS TAG
        FROM PLT_EVENTS_PERSONAL_INTEREST.UPDATED, 
             lateral flatten(input => CONTENT:data:tags))
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_PERSONAL_INTEREST_UPDATED"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_PERSONAL_INTEREST.UPDATED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_PERSONAL_INTEREST.UPDATED (INTEREST_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE) \\n \\
 (SELECT INTEREST_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_PERSONAL_INTEREST.UPDATED \\n \\
WHERE  INTEREST_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_PERSONAL_INTEREST.UPDATED(INTEREST_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.interestId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/PERSONAL_INTEREST/ t) \\n \\
PATTERN=''.*personalInterest.updated.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = FALSE"; 


try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
create or replace schema PLT_EVENTS_PLATFORM_ACCESS_LOG;

create or replace TRANSIENT TABLE UPLOADED (
	PLATFORM_ACCESS_ID VARCHAR(16777216) COMMENT 'Platform access log plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace view VW_U_PLATFORM_ACCESS_LOG(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_WORKER,
	HK_HUB_CUSTOMER,
	HK_HUB_ORGANIZATION,
	WORKER_ID,
	CUSTOMER_ID,
	ORGANIZATION_ID,
	ACCESS_DT,
	USER_AGENT
) as
(
       SELECT 
       PLT_MODEL_SHARED.UF_HASH_HK_LINK_SUBSCRIPTION(WORKER_ID,CUSTOMER_ID,ORGANIZATION_ID) AS HK_LINK, 
       MD_START_DT,
       CURRENT_TIMESTAMP AS MD_CREATION_DT,
       MD_SOURCE,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB_WORKER,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB_CUSTOMER,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_ORGANIZATION(ORGANIZATION_ID) AS HK_HUB_ORGANIZATION,
       WORKER_ID,
       CUSTOMER_ID,
       ORGANIZATION_ID,
       ACCESS_DT,
       USER_AGENT
       FROM (SELECT
               CONTENT:data:workerId::STRING AS WORKER_ID,
               CONTENT:data:customerId::STRING AS CUSTOMER_ID,
               CONTENT:data:organizationId::STRING AS ORGANIZATION_ID,
               CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,
               CONTENT:data:accessDate::TIMESTAMP AS ACCESS_DT,
               CONTENT:data:userAgentHeader::STRING AS USER_AGENT,
               MD_SOURCE
        FROM PLT_EVENTS_PLATFORM_ACCESS_LOG.UPLOADED ) js
);
create or replace schema PLT_EVENTS_PRODUCT;

create or replace TRANSIENT TABLE CATALOG_CREATED (
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Product Catalog platform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event platforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE UPLOADED (
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Order plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE VW_U_PACKAGE_PRODUCT_LIST (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	HK_HUB_PACKAGE_PRODUCT VARCHAR(16777216),
	HK_HUB_PRODUCT VARCHAR(16777216),
	PACKAGE_PRODUCT_ID VARCHAR(16777216) COMMENT 'Parent Product plateform ID',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Package product list Product id'
);
create or replace TRANSIENT TABLE VW_U_PRODUCT (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	HK_HUB_PRODUCT VARCHAR(16777216),
	HK_HUB_PROVIDER VARCHAR(16777216),
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product plateform Id',
	PROVIDER_ID VARCHAR(16777216) COMMENT 'Product provider Id'
);
create or replace TRANSIENT TABLE VW_U_PRODUCT_INFO (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product plateform ID',
	CATEGORY VARCHAR(16777216) COMMENT 'Product category',
	NAME_FR VARCHAR(16777216) COMMENT ' Product Name in French',
	NAME_EN VARCHAR(16777216) COMMENT 'Product Name in English',
	DESCRIPTION_FR VARCHAR(16777216) COMMENT 'Product Description in French',
	DESCRIPTION_EN VARCHAR(16777216) COMMENT 'Product Description in English',
	TYPE VARCHAR(16777216) COMMENT 'Type of Product',
	COVERAGE_TYPE VARCHAR(16777216) COMMENT 'Coverage type',
	AVAILABILITY_START_DATE DATE COMMENT 'Product availability start date',
	AVAILABILITY_END_DATE DATE COMMENT 'Product availability end date',
	IS_PACKAGE VARCHAR(16777216) COMMENT 'Product is package predicate',
	SKU VARCHAR(16777216) COMMENT 'Product sku'
);
create or replace TRANSIENT TABLE VW_U_PRODUCT_TAG (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_LTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	HK_HUB_PRODUCT VARCHAR(16777216),
	HK_HUB_PRODUCT_TAG VARCHAR(16777216),
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product id',
	TAG VARCHAR(16777216) COMMENT 'TAG related to the product'
);
create or replace view VW_CC_CATALOG_PRODUCT_LIST(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF_SAT_LINK,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_PRODUCT_CATALOG,
	HK_HUB_PRODUCT,
	PRODUCT_CATALOG_ID,
	PRODUCT_ID
) as
(
                   
SELECT 
            PLT_MODEL_PRODUCT.UF_HASH_HK_LINK_PRODUCT_CATALOG_PRODUCT(PRODUCT_CATALOG_ID,PRODUCT_ID) AS HK_LINK,
            MD_START_DT,
            PLT_MODEL_PRODUCT.UF_HASHDIFF_PRODUCT_CATALOG_PRODUCT_PLT(MD_START_DT)  AS MD_HASHDIFF_SAT_LINK,
            CURRENT_TIMESTAMP AS MD_CREATION_DT,
	        MD_SOURCE,
            PLT_MODEL_PRODUCT.UF_HASH_HK_HUB_PRODUCT_CATALOG(PRODUCT_CATALOG_ID) AS HK_HUB_PRODUCT_CATALOG,
            PLT_MODEL_PRODUCT.UF_HASH_HK_HUB_PRODUCT(PRODUCT_ID) AS HK_HUB_PRODUCT,
            PRODUCT_CATALOG_ID,
            PRODUCT_ID
FROM (
   SELECT CONTENT:data:productCatalog:productCatalogId::STRING as PRODUCT_CATALOG_ID,
          value:productId::STRING as PRODUCT_ID,
          CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,
          MD_SOURCE
    FROM  PLT_EVENTS_PRODUCT.CATALOG_CREATED,
          LATERAL FLATTEN(input => CONTENT:data:productCatalog:productList)
    WHERE value:productId::STRING IS NOT NULL 
    ) 
);
create or replace view VW_CC_PRODUCT_CATALOG(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF_SAT_PRODUCT_CATALOG,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_PRODUCT_CATALOG,
	HK_HUB_ORGANIZATION,
	PRODUCT_CATALOG_ID,
	ORGANIZATION_ID,
	NAME_FR,
	NAME_EN,
	DESCRIPTION_FR,
	DESCRIPTION_EN,
	START_DATE,
	END_DATE
) as
(
                   
SELECT 
            PLT_MODEL_PRODUCT.UF_HASH_HK_LINK_PRODUCT_CATALOG_ORGANIZATION(PRODUCT_CATALOG_ID, ORGANIZATION_ID) AS HK_LINK,
            MD_START_DT,
            PLT_MODEL_PRODUCT.UF_HASHDIFF_PRODUCT_CATALOG(NAME_FR,NAME_EN,DESCRIPTION_FR, DESCRIPTION_EN, START_DATE,END_DATE) AS MD_HASHDIFF_SAT_PRODUCT_CATALOG,
            CURRENT_TIMESTAMP AS MD_CREATION_DT,
	        MD_SOURCE ,
            PLT_MODEL_PRODUCT.UF_HASH_HK_HUB_PRODUCT_CATALOG(PRODUCT_CATALOG_ID) AS HK_HUB_PRODUCT_CATALOG,
            PLT_MODEL_SHARED.UF_HASH_HK_HUB_ORGANIZATION(ORGANIZATION_ID) AS HK_HUB_ORGANIZATION,
            PRODUCT_CATALOG_ID,
            ORGANIZATION_ID,
            NAME_FR,
            NAME_EN,
            DESCRIPTION_FR,
            DESCRIPTION_EN,
            START_DATE,
            END_DATE
FROM (
   SELECT 
          CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,               
          MD_SOURCE,
          CONTENT:data:productCatalog:productCatalogId::STRING AS PRODUCT_CATALOG_ID,
          CONTENT:data:productCatalog:organizationId::STRING AS ORGANIZATION_ID,
          CONTENT:data:productCatalog:nameFR::STRING  AS NAME_FR,
          CONTENT:data:productCatalog:nameEN::STRING  AS NAME_EN ,
          CONTENT:data:productCatalog:descriptionFR::STRING AS DESCRIPTION_FR,
          CONTENT:data:productCatalog:descriptionEN::STRING AS DESCRIPTION_EN,
          CONTENT:data:productCatalog:startDate::DATE AS START_DATE,
          CONTENT:data:productCatalog:endDate::DATE AS END_DATE
   FROM PLT_EVENTS_PRODUCT.CATALOG_CREATED
    ) 
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_PRODUCT_CATALOG_CREATED"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '


var pre_sql_command = "DELETE FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_PRODUCT.CATALOG_CREATED";


var sql_command = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_PRODUCT.CATALOG_CREATED (MD_CREATION_DT,MD_SOURCE,MD_START_DT,PRODUCT_CATALOG_ID) \\n \\
 (SELECT MD_CREATION_DT,MD_SOURCE,MD_START_DT,PRODUCT_CATALOG_ID FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_PRODUCT.CATALOG_CREATED \\n \\
WHERE  PRODUCT_CATALOG_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_PRODUCT.CATALOG_CREATED(PRODUCT_CATALOG_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
 FROM ( SELECT  \\n \\
 t.$1:data.productCatalog.productCatalogId,   \\n \\
 t.$1:data.timestamp,   \\n \\
 current_timestamp(),   \\n \\
 metadata$filename ,    \\n \\
 t.$1             \\n \\
 FROM @DATALAKE.RAW/PRODUCT/ t)  \\n \\
 PATTERN=''.*product.catalogCreated.*json''  \\n \\
 FILE_FORMAT = ( TYPE = JSON) FORCE = false";  

try {
	
    var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();

    var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_PRODUCT_UPLOADED"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_PRODUCT.UPLOADED"


var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_PRODUCT.UPLOADED (PRODUCT_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE) \\n \\
(SELECT PRODUCT_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_PRODUCT.UPLOADED \\n \\
WHERE  PRODUCT_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_PRODUCT.UPLOADED(PRODUCT_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
 FROM ( SELECT  \\n \\
 t.$1:data.productId, \\n \\
 t.$1:data.timestamp, \\n \\
 current_timestamp(), \\n \\
 metadata$filename ,  \\n \\
 t.$1             \\n \\
 FROM @DATALAKE.RAW/PRODUCT/ t)  \\n \\
 PATTERN=''.*product.uploaded.*json''  \\n \\
 FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 


try {

	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
	
	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
create or replace schema PLT_EVENTS_SHOPPING_REQUESTS;

create or replace TABLE UPLOADED (
	SHOPPING_REQUEST_ID NUMBER(38,0),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	CONTENT VARIANT
);
create or replace view VW_U_SHOPPING_REQUESTS(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_HASHDIFF,
	HK_HUB_PRODUCT_CATALOG,
	HK_HUB_OPEN_SHOPPING_PERIOD,
	HK_HUB_CUSTOMER,
	HK_HUB_WORKER,
	HK_HUB_SHOPPING_REQUEST,
	SHOPPING_REQUEST_ID,
	CUSTOMER_ID,
	CONTEXT,
	WORKER_ID,
	OPEN_SHOPPING_PERIOD_ID,
	PRODUCT_CATALOG_ID,
	STATUS,
	SUBMITTEDON
) as     
       ( SELECT PLT_MODEL_SHOPPING.UF_HASH_HK_LINK_SHOPPING_REQUESTS(CUSTOMER_ID, WORKER_ID, OPEN_SHOPPING_PERIOD_ID, PRODUCT_CATALOG_ID) as HK_LINK,
                 MD_START_DT,
                 CURRENT_TIMESTAMP as MD_CREATION_DT,
                 MD_SOURCE,
                 PLT_MODEL_SHOPPING.UF_HASHDIFF_SHOPPING_REQUEST(STATUS,SUBMITTEDON, CONTEXT) as MD_HASHDIFF,
                 PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_PRODUCT_CATALOG(PRODUCT_CATALOG_ID) as HK_HUB_PRODUCT_CATALOG, 
                 PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_OPEN_SHOPPING_PERIOD(OPEN_SHOPPING_PERIOD_ID) as HK_HUB_OPEN_SHOPPING_PERIOD, 
                 PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) as HK_HUB_CUSTOMER,
                 PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_WORKER(WORKER_ID) as HK_HUB_WORKER,   
                 PLT_MODEL_SHOPPING.UF_HASH_HK_HUB_SHOPPING_REQUEST(SHOPPING_REQUEST_ID) as HK_HUB_SHOPPING_REQUEST,
                 SHOPPING_REQUEST_ID,        
                 CUSTOMER_ID, 
                 CONTEXT , 
                 WORKER_ID, 
                 OPEN_SHOPPING_PERIOD_ID, 
                 PRODUCT_CATALOG_ID, 
                 STATUS, 
                 SUBMITTEDON
            FROM (SELECT  DISTINCT 
                    CONTENT:data:shoppingRequestId::NUMBER AS SHOPPING_REQUEST_ID,
                    CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
                    CONTENT:data:customerId::STRING AS CUSTOMER_ID,
                    CONTENT:data:context::STRING AS CONTEXT,
                    CONTENT:data:workerId::STRING AS WORKER_ID,
                    CONTENT:data:openShoppingPeriodId::NUMBER AS OPEN_SHOPPING_PERIOD_ID,
                    CONTENT:data:productCatalogId::STRING AS PRODUCT_CATALOG_ID,
                    CONTENT:data:status::STRING AS STATUS,
                    CONTENT:data:submittedOn::DATE AS SUBMITTEDON,
                    MD_SOURCE
            FROM PLT_EVENTS_SHOPPING_REQUESTS.UPLOADED));
create or replace schema PLT_EVENTS_WORKER;

create or replace TRANSIENT TABLE EMPLOYMENT_INFO_UPDATED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE HIRED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE LEAVE_CANCELLED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE LEAVE_ENDED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE LEAVE_STARTED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE LEAVE_UPDATED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE SALARY_UPDATED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE TERMINATED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE TERMINATION_CANCELLED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TRANSIENT TABLE UPLOADED (
	WORKER_ID VARCHAR(16777216) COMMENT 'Order plateform ID',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CONTENT VARIANT COMMENT 'JSON content'
);
create or replace TABLE VW_H_EMPLOYMENT_INFO (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	HIRE_DATE DATE,
	ORIGINAL_HIRED_DATE DATE,
	PROVINCE_OF_EMPLOYMENT VARCHAR(16777216),
	REMUNERATION_TYPE VARCHAR(16777216),
	HOURS_PER_WEEK NUMBER(38,2),
	PAY_PERIOD VARCHAR(16777216),
	WORK_PATTERN VARCHAR(16777216),
	JOB_PERMANENCY VARCHAR(16777216),
	JOB_CATEGORY VARCHAR(16777216),
	LOCATION VARCHAR(16777216),
	IS_MANAGER VARCHAR(16777216)
);
create or replace TABLE VW_H_EMPLOYMENT_INFO_SALARY (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	SALARY NUMBER(38,2),
	SALARY_EFFECTIVE_DATE DATE
);
create or replace TABLE VW_H_EMPLOYMENT_INFO_WORK_PERMIT (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	TYPE VARCHAR(16777216),
	START_DATE DATE,
	END_DATE DATE
);
create or replace TABLE VW_H_PERSONAL_INFO (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	CUSTOMER_ID VARCHAR(16777216),
	MONTH_OF_BIRTH DATE,
	GENDER VARCHAR(16777216)
);
create or replace TABLE VW_H_PERSONAL_INFO_ADDRESS (
	HK_HUB VARCHAR(64),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_HASHDIFF VARCHAR(64),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	CUSTOMER_ID VARCHAR(16777216),
	POSTAL_CODE_PARTIAL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	COUNTRY VARCHAR(16777216)
);
create or replace TABLE VW_H_WORKER (
	HK_LINK VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	HK_HUB_WORKER VARCHAR(16777216),
	HK_HUB_CUSTOMER VARCHAR(16777216),
	HK_HUB_ORGANIZATION VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	CUSTOMER_ID VARCHAR(16777216),
	ORGANIZATION_ID VARCHAR(16777216)
);
create or replace TABLE VW_LC_LEAVE_STATUS (
	HK_HUB VARCHAR(16777216),
	MD_HASHDIFF VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	MD_RESERVED BOOLEAN DEFAULT FALSE,
	WORKER_ID VARCHAR(16777216),
	ON_LEAVE VARCHAR(16777216),
	LEAVE_START_DATE DATE,
	LEAVE_END_DATE DATE,
	REASON_CODE VARCHAR(16777216),
	ORGANIZATION_ID VARCHAR(16777216)
);
create or replace TABLE VW_LE_LEAVE_STATUS (
	HK_HUB VARCHAR(16777216),
	MD_HASHDIFF VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	MD_RESERVED BOOLEAN DEFAULT FALSE,
	WORKER_ID VARCHAR(16777216),
	ORGANIZATION_ID VARCHAR(16777216),
	ON_LEAVE VARCHAR(16777216),
	LEAVE_START_DATE DATE,
	LEAVE_END_DATE DATE,
	REASON_CODE VARCHAR(16777216)
);
create or replace TABLE VW_LS_LEAVE_STATUS (
	HK_HUB VARCHAR(16777216),
	MD_HASHDIFF VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(16777216),
	MD_RESERVED BOOLEAN DEFAULT FALSE,
	WORKER_ID VARCHAR(16777216),
	ON_LEAVE VARCHAR(16777216),
	LEAVE_START_DATE DATE,
	LEAVE_END_DATE DATE,
	REASON_CODE VARCHAR(16777216),
	ORGANIZATION_ID VARCHAR(16777216)
);
create or replace TABLE VW_LU_LEAVE_STATUS (
	HK_HUB VARCHAR(16777216),
	MD_HASHDIFF VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	MD_RESERVED VARCHAR(5),
	WORKER_ID VARCHAR(16777216),
	ORGANIZATION_ID VARCHAR(16777216),
	ON_LEAVE VARCHAR(16777216),
	LEAVE_START_DATE DATE,
	LEAVE_END_DATE DATE,
	REASON_CODE VARCHAR(16777216)
);
create or replace TABLE VW_SU_SALARY (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	MD_RESERVED VARCHAR(5),
	WORKER_ID VARCHAR(16777216),
	SALARY NUMBER(38,0),
	SALARY_EFFECTIVE_DATE DATE
);
create or replace TABLE VW_TC_TERMINATION_STATUS (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	MD_RESERVED VARCHAR(5),
	WORKER_ID VARCHAR(16777216),
	TERMINATED VARCHAR(16777216),
	TERMINATION_DATE DATE,
	REASON_CODE VARCHAR(16777216)
);
create or replace TRANSIENT TABLE VW_T_TERMINATION_STATUS (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	TERMINATED VARCHAR(16777216) COMMENT 'Terminated predicate',
	TERMINATION_DATE DATE COMMENT 'Termination date',
	REASON_CODE VARCHAR(16777216) COMMENT 'Termination reason code'
);
create or replace TABLE VW_U_EMPLOYMENT_INFO (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	HIRE_DATE DATE,
	ORIGINAL_HIRED_DATE DATE,
	PROVINCE_OF_EMPLOYMENT VARCHAR(16777216),
	REMUNERATION_TYPE VARCHAR(16777216),
	HOURS_PER_WEEK NUMBER(38,2),
	PAY_PERIOD VARCHAR(16777216),
	WORK_PATTERN VARCHAR(16777216),
	JOB_PERMANENCY VARCHAR(16777216),
	JOB_CATEGORY VARCHAR(16777216),
	LOCATION VARCHAR(16777216),
	IS_MANAGER VARCHAR(16777216)
);
create or replace TABLE VW_U_EMPLOYMENT_INFO_SALARY (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	SALARY NUMBER(38,2),
	SALARY_EFFECTIVE_DATE DATE
);
create or replace TABLE VW_U_EMPLOYMENT_INFO_WORK_PERMIT (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	TYPE VARCHAR(16777216),
	START_DATE DATE,
	END_DATE DATE
);
create or replace TABLE VW_U_LEAVE_STATUS (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	ON_LEAVE VARCHAR(16777216),
	LEAVE_START_DATE DATE,
	LEAVE_END_DATE DATE,
	REASON_CODE VARCHAR(16777216)
);
create or replace TABLE VW_U_PERSONAL_INFO (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	CUSTOMER_ID VARCHAR(16777216),
	MONTH_OF_BIRTH DATE,
	GENDER VARCHAR(16777216)
);
create or replace TABLE VW_U_PERSONAL_INFO_ADDRESS (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	CUSTOMER_ID VARCHAR(16777216),
	POSTAL_CODE_PARTIAL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	COUNTRY VARCHAR(16777216)
);
create or replace TABLE VW_U_RETIREMENT_STATUS (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	RETIRED VARCHAR(16777216),
	RETIREMENT_DATE DATE,
	EXPECTED VARCHAR(16777216),
	EXPECTED_RETIREMENT_DATE DATE
);
create or replace TABLE VW_U_TERMINATION_STATUS (
	HK_HUB VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASHDIFF VARCHAR(16777216),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	TERMINATED VARCHAR(16777216),
	TERMINATION_DATE DATE,
	REASON_CODE VARCHAR(16777216)
);
create or replace TABLE VW_U_WORKER (
	HK_LINK VARCHAR(16777216),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(16777216),
	HK_HUB_WORKER VARCHAR(16777216),
	HK_HUB_CUSTOMER VARCHAR(16777216),
	HK_HUB_ORGANIZATION VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216),
	CUSTOMER_ID VARCHAR(16777216),
	ORGANIZATION_ID VARCHAR(16777216)
);
create or replace view VW_EIU_EMPLOYMENT_INFO(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	HIRE_DATE,
	ORIGINAL_HIRED_DATE,
	PROVINCE_OF_EMPLOYMENT,
	REMUNERATION_TYPE,
	HOURS_PER_WEEK,
	PAY_PERIOD,
	WORK_PATTERN,
	JOB_PERMANENCY,
	JOB_CATEGORY,
	LOCATION,
	IS_MANAGER
) as 

       SELECT 
              PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
              MD_START_DT,
              PLT_MODEL_SHARED.UF_HASHDIFF_EMPLOYMENT_INFO(HIRE_DATE, 
                                          ORIGINAL_HIRED_DATE,
                                          PROVINCE_OF_EMPLOYMENT,
                                          REMUNERATION_TYPE,
                                          HOURS_PER_WEEK,
                                          PAY_PERIOD,
                                          WORK_PATTERN,
                                          JOB_PERMANENCY,
                                          JOB_CATEGORY,
                                          LOCATION,
                                          IS_MANAGER) AS MD_HASHDIFF,
              CURRENT_TIMESTAMP AS MD_CREATION_DT,    
              MD_SOURCE,
              WORKER_ID,
              HIRE_DATE,
              ORIGINAL_HIRED_DATE,
              PROVINCE_OF_EMPLOYMENT,
              REMUNERATION_TYPE,
              HOURS_PER_WEEK,
              PAY_PERIOD,
              WORK_PATTERN,
              JOB_PERMANENCY,
              JOB_CATEGORY,
              LOCATION,
              IS_MANAGER
       FROM (SELECT        
              CONTENT:data:workerId::STRING as WORKER_ID,
              CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
              MD_SOURCE,
              CONTENT:data:employmentInfo:hireDate::DATE as HIRE_DATE,
              CONTENT:data:employmentInfo:originalHiredDate::DATE as ORIGINAL_HIRED_DATE,
              CONTENT:data:employmentInfo:provinceOfEmployment::STRING AS PROVINCE_OF_EMPLOYMENT,
              CONTENT:data:employmentInfo:remunerationType::STRING AS REMUNERATION_TYPE,
              CONTENT:data:employmentInfo:hoursPerWeek::NUMERIC(38,2) AS HOURS_PER_WEEK,
              CONTENT:data:employmentInfo:payPeriod::STRING AS PAY_PERIOD,
              CONTENT:data:employmentInfo:workPattern::STRING AS WORK_PATTERN,
              CONTENT:data:employmentInfo:jobPermanency::STRING AS JOB_PERMANENCY,
              CONTENT:data:employmentInfo:jobCategory::STRING AS JOB_CATEGORY,
              CONTENT:data:employmentInfo:location::STRING AS LOCATION,
              CONTENT:data:employmentInfo:isManager::STRING AS IS_MANAGER
       FROM PLT_EVENTS_WORKER.EMPLOYMENT_INFO_UPDATED) js;
create or replace view VW_EIU_SALARY(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	SALARY,
	SALARY_EFFECTIVE_DATE
) as
(
  
      SELECT 
              PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
              MD_START_DT,
              PLT_MODEL_SHARED.UF_HASHDIFF_SALARY(SALARY,
                                                  SALARY_EFFECTIVE_DATE) AS MD_HASHDIFF,
              CURRENT_TIMESTAMP AS MD_CREATION_DT,    
              MD_SOURCE,
              'FALSE' as MD_RESERVED,
              WORKER_ID,
              SALARY,
              SALARY_EFFECTIVE_DATE
  
  
  
  
       FROM (SELECT
              WORKER_ID,
              MD_START_DT,
              MD_SOURCE,
              CONTENT:data:employmentInfo:salaryInfo:salary::NUMERIC(38,2) AS SALARY,
              CONTENT:data:employmentInfo:salaryInfo:salaryEffectiveDate::DATE AS SALARY_EFFECTIVE_DATE
       FROM PLT_EVENTS_WORKER.EMPLOYMENT_INFO_UPDATED ) js
);
create or replace view VW_EIU_WORK_PERMIT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	TYPE,
	START_DATE,
	END_DATE
) as
(
        SELECT 
              PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
              MD_START_DT,
              PLT_MODEL_SHARED.UF_HASHDIFF_WORK_PERMIT(TYPE,
                                                       START_DATE,
                                                       END_DATE)  AS MD_HASHDIFF,
              CURRENT_TIMESTAMP AS MD_CREATION_DT,    
              MD_SOURCE,
              'FALSE' as MD_RESERVED,
              WORKER_ID,
              TYPE,
              START_DATE,
              END_DATE
  
  
        FROM(SELECT 
               WORKER_ID,
               MD_START_DT,
               MD_SOURCE,
               CONTENT:data:employmentInfo:workPermit:type::STRING AS TYPE,
               CONTENT:data:employmentInfo:workPermit:startDate::DATE AS START_DATE,
               CONTENT:data:employmentInfo:workPermit:endDate::DATE AS END_DATE
         FROM PLT_EVENTS_WORKER.EMPLOYMENT_INFO_UPDATED ) JS
);
create or replace view VW_H_EMPLOYMENT_INFO_ORIG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	HIRE_DATE,
	ORIGINAL_HIRED_DATE,
	PROVINCE_OF_EMPLOYMENT,
	REMUNERATION_TYPE,
	HOURS_PER_WEEK,
	PAY_PERIOD,
	WORK_PATTERN,
	JOB_PERMANENCY,
	JOB_CATEGORY,
	LOCATION,
	IS_MANAGER
) as
(
       SELECT 
              PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
              MD_START_DT,
              PLT_MODEL_SHARED.UF_HASHDIFF_EMPLOYMENT_INFO(HIRE_DATE, 
                                          ORIGINAL_HIRED_DATE,
                                          PROVINCE_OF_EMPLOYMENT,
                                          REMUNERATION_TYPE,
                                          HOURS_PER_WEEK,
                                          PAY_PERIOD,
                                          WORK_PATTERN,
                                          JOB_PERMANENCY,
                                          JOB_CATEGORY,
                                          LOCATION,
                                          IS_MANAGER) AS MD_HASHDIFF,
              CURRENT_TIMESTAMP AS MD_CREATION_DT,    
              MD_SOURCE,
              WORKER_ID,
              HIRE_DATE,
              ORIGINAL_HIRED_DATE,
              PROVINCE_OF_EMPLOYMENT,
              REMUNERATION_TYPE,
              HOURS_PER_WEEK,
              PAY_PERIOD,
              WORK_PATTERN,
              JOB_PERMANENCY,
              JOB_CATEGORY,
              LOCATION,
              IS_MANAGER
       FROM (SELECT        
              CONTENT:data:workerId::STRING as WORKER_ID,
              CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
              MD_SOURCE,
              CONTENT:data:employmentInfo:hireDate::DATE as HIRE_DATE,
              CONTENT:data:employmentInfo:originalHiredDate::DATE as ORIGINAL_HIRED_DATE,
              CONTENT:data:employmentInfo:provinceOfEmployment::STRING AS PROVINCE_OF_EMPLOYMENT,
              CONTENT:data:employmentInfo:remunerationType::STRING AS REMUNERATION_TYPE,
              CONTENT:data:employmentInfo:hoursPerWeek::NUMERIC(38,2) AS HOURS_PER_WEEK,
              CONTENT:data:employmentInfo:payPeriod::STRING AS PAY_PERIOD,
              CONTENT:data:employmentInfo:workPattern::STRING AS WORK_PATTERN,
              CONTENT:data:employmentInfo:jobPermanency::STRING AS JOB_PERMANENCY,
              CONTENT:data:employmentInfo:jobCategory::STRING AS JOB_CATEGORY,
              CONTENT:data:employmentInfo:location::STRING AS LOCATION,
              CONTENT:data:employmentInfo:isManager::STRING AS IS_MANAGER
       FROM PLT_EVENTS_WORKER.HIRED)
);
create or replace view VW_H_EMPLOYMENT_INFO_SALARY_ORIG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	SALARY,
	SALARY_EFFECTIVE_DATE
) as
(
        SELECT 
               PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
               MD_START_DT,
               PLT_MODEL_SHARED.UF_HASHDIFF_SALARY(SALARY,SALARY_EFFECTIVE_DATE) AS MD_HASHDIFF, 
               CURRENT_TIMESTAMP as MD_CREATION_DT,
               MD_SOURCE,
               WORKER_ID,
               SALARY,
               SALARY_EFFECTIVE_DATE
        FROM (SELECT        
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:employmentInfo:salaryInfo:salary::NUMBER(38,2) AS SALARY,
               CONTENT:data:employmentInfo:salaryInfo:salaryEffectiveDate::DATE AS SALARY_EFFECTIVE_DATE
        FROM PLT_EVENTS_WORKER.HIRED )
);
create or replace view VW_H_EMPLOYMENT_INFO_WORK_PERMIT_ORIG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	TYPE,
	START_DATE,
	END_DATE
) as
(
        SELECT 
               PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
               MD_START_DT,
               PLT_MODEL_SHARED.UF_HASHDIFF_WORK_PERMIT(TYPE,START_DATE,END_DATE) AS MD_HASHDIFF, 
               CURRENT_TIMESTAMP as MD_CREATION_DT,
               MD_SOURCE,
               WORKER_ID,
               TYPE,
               START_DATE,
               END_DATE
        FROM (SELECT   
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:employmentInfo:workPermit:type::STRING AS TYPE,
               CONTENT:data:employmentInfo:workPermit:startDate::DATE AS START_DATE,
               CONTENT:data:employmentInfo:workPermit:endDate::DATE AS END_DATE
        FROM PLT_EVENTS_WORKER.HIRED)
);
create or replace view VW_H_PERSONAL_INFO_ADDRESS_ORIG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	POSTAL_CODE_PARTIAL,
	PROVINCE,
	COUNTRY
) as 
(
SELECT  PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB,
		MD_START_DT, 
		PLT_MODEL_SHARED.UF_HASHDIFF_ADDRESS(POSTAL_CODE_PARTIAL,PROVINCE,COUNTRY) AS MD_HASHDIFF,
        CURRENT_TIMESTAMP AS MD_CREATION_DT,
		MD_SOURCE,
		CUSTOMER_ID,
        POSTAL_CODE_PARTIAL,
        PROVINCE,
        COUNTRY
FROM ( SELECT  
        CONTENT:data:customerId::STRING as CUSTOMER_ID,
        CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
        MD_SOURCE,
        CONTENT:data:personalInfo:address:postalCodePartial::STRING as POSTAL_CODE_PARTIAL,
        CONTENT:data:personalInfo:address:province::STRING AS PROVINCE,
        CONTENT:data:personalInfo:address:country::STRING AS COUNTRY
      FROM PLT_EVENTS_WORKER.HIRED 
    )
);
create or replace view VW_H_PERSONAL_INFO_ORIG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	MONTH_OF_BIRTH,
	GENDER
) as
(
	SELECT  PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB,
            MD_START_DT,       
			PLT_MODEL_SHARED.UF_HASHDIFF_PERSONAL_INFO(MONTH_OF_BIRTH,GENDER) AS MD_HASHDIFF,
			CURRENT_TIMESTAMP AS MD_CREATION_DT,
			MD_SOURCE,
            CUSTOMER_ID,
            MONTH_OF_BIRTH,
            GENDER
	FROM (  SELECT  
               CONTENT:data:customerId::STRING as CUSTOMER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:personalInfo:dateOfBirth::DATE as MONTH_OF_BIRTH,
               CONTENT:data:personalInfo:gender::STRING AS GENDER
            FROM PLT_EVENTS_WORKER.HIRED 
         ) 
);
create or replace view VW_H_WORKER_ORIG(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_WORKER,
	HK_HUB_CUSTOMER,
	HK_HUB_ORGANIZATION,
	WORKER_ID,
	CUSTOMER_ID,
	ORGANIZATION_ID
) as
(
       SELECT 
       PLT_MODEL_SHARED.UF_HASH_HK_LINK_SUBSCRIPTION(WORKER_ID,CUSTOMER_ID,ORGANIZATION_ID) AS HK_LINK, 
       MD_START_DT,
       CURRENT_TIMESTAMP as MD_CREATION_DT,
       MD_SOURCE,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB_WORKER,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB_CUSTOMER,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_ORGANIZATION(ORGANIZATION_ID) AS HK_HUB_ORGANIZATION,
       WORKER_ID,
       CUSTOMER_ID,
       ORGANIZATION_ID
       FROM (SELECT
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:customerId::STRING AS CUSTOMER_ID,
               CONTENT:data:organizationId::STRING AS ORGANIZATION_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE
        FROM PLT_EVENTS_WORKER.HIRED)
);
create or replace view VW_LC_LEAVE_STATUS_ORIG(
	HK_HUB,
	MD_HASHDIFF,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	ORGANIZATION_ID,
	ON_LEAVE,
	LEAVE_START_DATE,
	LEAVE_END_DATE,
	REASON_CODE
) as
(

   SELECT PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
         PLT_MODEL_SHARED.UF_HASHDIFF_LEAVE_STATUS(ON_LEAVE,
                                                   LEAVE_START_DATE,
                                                   LEAVE_END_DATE,
                                                   REASON_CODE)
         AS MD_HASHDIFF,
         MD_START_DT,
         MD_CREATION_DT,
         MD_SOURCE,
         MD_RESERVED,
         WORKER_ID,
         ORGANIZATION_ID,         
         ON_LEAVE,
         LEAVE_START_DATE,
         LEAVE_END_DATE,
         REASON_CODE
    FROM (SELECT CONTENT:data:workerId::STRING as WORKER_ID,
                 CONTENT:data:organizationId::STRING as ORGANIZATION_ID,
                 CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,         
                 CURRENT_TIMESTAMP AS MD_CREATION_DT,
                 MD_SOURCE,
                 'FALSE' as MD_RESERVED,
                 CONTENT:data:leaveStatus:onLeave::STRING as ON_LEAVE,
                 CONTENT:data:leaveStatus:leaveStartDate::DATE as LEAVE_START_DATE,
                 CONTENT:data:leaveStatus:leaveEndDate::DATE as LEAVE_END_DATE,
                 CONTENT:data:leaveStatus:reasonCode::STRING as REASON_CODE
            FROM PLT_EVENTS_WORKER.LEAVE_CANCELLED) 
);
create or replace view VW_LE_LEAVE_STATUS_ORIG(
	HK_HUB,
	MD_HASHDIFF,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	ORGANIZATION_ID,
	ON_LEAVE,
	LEAVE_START_DATE,
	LEAVE_END_DATE,
	REASON_CODE
) as
(
  SELECT PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
         PLT_MODEL_SHARED.UF_HASHDIFF_LEAVE_STATUS(ON_LEAVE,
                                                   LEAVE_START_DATE,
                                                   LEAVE_END_DATE,
                                                   REASON_CODE)
         AS MD_HASHDIFF,
         MD_START_DT,
         MD_CREATION_DT,
         MD_SOURCE,
         MD_RESERVED,
         WORKER_ID,
         ORGANIZATION_ID,         
         ON_LEAVE,
         LEAVE_START_DATE,
         LEAVE_END_DATE,
         REASON_CODE
    FROM (SELECT CONTENT:data:workerId::STRING as WORKER_ID,
                 CONTENT:data:organizationId::STRING as ORGANIZATION_ID,
                 CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,         
                 CURRENT_TIMESTAMP AS MD_CREATION_DT,
                 MD_SOURCE,
                 'FALSE' as MD_RESERVED,
                 CONTENT:data:leaveStatus:onLeave::STRING as ON_LEAVE,
                 CONTENT:data:leaveStatus:leaveStartDate::DATE as LEAVE_START_DATE,
                 CONTENT:data:leaveStatus:leaveEndDate::DATE as LEAVE_END_DATE,
                 CONTENT:data:leaveStatus:reasonCode::STRING as REASON_CODE
            FROM PLT_EVENTS_WORKER.LEAVE_ENDED) 
);
create or replace view VW_LS_LEAVE_STATUS_ORIG(
	HK_HUB,
	MD_HASHDIFF,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	ORGANIZATION_ID,
	ON_LEAVE,
	LEAVE_START_DATE,
	LEAVE_END_DATE,
	REASON_CODE
) as
(
  SELECT PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
         PLT_MODEL_SHARED.UF_HASHDIFF_LEAVE_STATUS(ON_LEAVE,
                                                   LEAVE_START_DATE,
                                                   LEAVE_END_DATE,
                                                   REASON_CODE)
         AS MD_HASHDIFF,
         MD_START_DT,
         MD_CREATION_DT,
         MD_SOURCE,
         MD_RESERVED,
         WORKER_ID,
         ORGANIZATION_ID,         
         ON_LEAVE,
         LEAVE_START_DATE,
         LEAVE_END_DATE,
         REASON_CODE
    FROM (SELECT CONTENT:data:workerId::STRING as WORKER_ID,
                 CONTENT:data:organizationId::STRING as ORGANIZATION_ID,
                 CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,         
                 CURRENT_TIMESTAMP AS MD_CREATION_DT,
                 MD_SOURCE,
                 'FALSE' as MD_RESERVED,
                 CONTENT:data:leaveStatus:onLeave::STRING as ON_LEAVE,
                 CONTENT:data:leaveStatus:leaveStartDate::DATE as LEAVE_START_DATE,
                 CONTENT:data:leaveStatus:leaveEndDate::DATE as LEAVE_END_DATE,
                 CONTENT:data:leaveStatus:reasonCode::STRING as REASON_CODE
            FROM PLT_EVENTS_WORKER.LEAVE_STARTED) 
);
create or replace view VW_LU_LEAVE_STATUS_ORG(
	HK_HUB,
	MD_HASHDIFF,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	ORGANIZATION_ID,
	ON_LEAVE,
	LEAVE_START_DATE,
	LEAVE_END_DATE,
	REASON_CODE
) as
(
      
  SELECT PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
         PLT_MODEL_SHARED.UF_HASHDIFF_LEAVE_STATUS(ON_LEAVE,
                                                   LEAVE_START_DATE,
                                                   LEAVE_END_DATE,
                                                   REASON_CODE)
         AS MD_HASHDIFF,
         MD_START_DT,
         MD_CREATION_DT,
         MD_SOURCE,
         MD_RESERVED,
         WORKER_ID,
         ORGANIZATION_ID,         
         ON_LEAVE,
         LEAVE_START_DATE,
         LEAVE_END_DATE,
         REASON_CODE
    FROM (SELECT CONTENT:data:workerId::STRING as WORKER_ID,
                 CONTENT:data:organizationId::STRING as ORGANIZATION_ID,
                 CONTENT:data:timestamp::TIMESTAMP AS MD_START_DT,         
                 CURRENT_TIMESTAMP AS MD_CREATION_DT,
                 MD_SOURCE,
                 'FALSE' as MD_RESERVED,
                 CONTENT:data:leaveStatus:onLeave::STRING as ON_LEAVE,
                 CONTENT:data:leaveStatus:leaveStartDate::DATE as LEAVE_START_DATE,
                 CONTENT:data:leaveStatus:leaveEndDate::DATE as LEAVE_END_DATE,
                 CONTENT:data:leaveStatus:reasonCode::STRING as REASON_CODE
            FROM PLT_EVENTS_WORKER.LEAVE_UPDATED) 
);
create or replace view VW_SU_SALARY_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	SALARY,
	SALARY_EFFECTIVE_DATE
) as
(      
       SELECT 
              PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
              MD_START_DT,
              PLT_MODEL_SHARED.UF_HASHDIFF_SALARY(SALARY,SALARY_EFFECTIVE_DATE)  AS MD_HASHDIFF,
              CURRENT_TIMESTAMP AS MD_CREATION_DT,    
              MD_SOURCE,
              'FALSE' as MD_RESERVED,
              WORKER_ID,
              SALARY,
              SALARY_EFFECTIVE_DATE
  
       FROM(SELECT 
                  WORKER_ID,
                  MD_START_DT,
                  MD_SOURCE,
                  CONTENT:data:salaryInfo:salary::INTEGER AS SALARY,
                  CONTENT:data:salaryInfo:salaryEffectiveDate::DATE AS SALARY_EFFECTIVE_DATE
       FROM PLT_EVENTS_WORKER.SALARY_UPDATED ) js
);
create or replace view VW_TC_TERMINATION_STATUS_ORIG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	TERMINATED,
	TERMINATION_DATE,
	REASON_CODE
) as
(
      SELECT      
              PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
              MD_START_DT,
              PLT_MODEL_SHARED.UF_HASHDIFF_TERMINATION_STATUS(TERMINATED,
                                                              TERMINATION_DATE,
                                                              REASON_CODE)  AS MD_HASHDIFF,
              CURRENT_TIMESTAMP AS MD_CREATION_DT,    
              MD_SOURCE,
              'FALSE' as MD_RESERVED,
              WORKER_ID,
              TERMINATED,
              TERMINATION_DATE,
              REASON_CODE
   
      
      FROM        (SELECT 
                        WORKER_ID,
                        MD_START_DT,
                        MD_SOURCE,
                        CONTENT:data:terminationStatus:terminated::STRING as TERMINATED,
                        CONTENT:data:terminationStatus:terminationDate::DATE as TERMINATION_DATE,
                        CONTENT:data:terminationStatus:reasonCode::STRING as REASON_CODE
                   FROM PLT_EVENTS_WORKER.TERMINATION_CANCELLED) js
);
create or replace view VW_T_TERMINATION_STATUS_ORIG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	WORKER_ID,
	TERMINATED,
	TERMINATION_DATE,
	REASON_CODE
) as
(
      SELECT      
              PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
              MD_START_DT,
              PLT_MODEL_SHARED.UF_HASHDIFF_TERMINATION_STATUS(TERMINATED,
                                                              TERMINATION_DATE,
                                                              REASON_CODE)  AS MD_HASHDIFF,
              CURRENT_TIMESTAMP AS MD_CREATION_DT,    
              MD_SOURCE,
              'FALSE' as MD_RESERVED,
              WORKER_ID,
              TERMINATED,
              TERMINATION_DATE,
              REASON_CODE
   
      
      FROM        (SELECT 
                        WORKER_ID,
                        MD_START_DT,
                        MD_SOURCE,
                        CONTENT:data:terminationStatus:terminated::STRING as TERMINATED,
                        CONTENT:data:terminationStatus:terminationDate::DATE as TERMINATION_DATE,
                        CONTENT:data:terminationStatus:reasonCode::STRING as REASON_CODE
                   FROM PLT_EVENTS_WORKER.TERMINATED) js
);
create or replace view VW_U_EMPLOYMENT_INFO_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	HIRE_DATE,
	ORIGINAL_HIRED_DATE,
	PROVINCE_OF_EMPLOYMENT,
	REMUNERATION_TYPE,
	HOURS_PER_WEEK,
	PAY_PERIOD,
	WORK_PATTERN,
	JOB_PERMANENCY,
	JOB_CATEGORY,
	LOCATION,
	IS_MANAGER
) as
(
       SELECT 
              PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
              MD_START_DT,
              PLT_MODEL_SHARED.UF_HASHDIFF_EMPLOYMENT_INFO(HIRE_DATE, 
                                          ORIGINAL_HIRED_DATE,
                                          PROVINCE_OF_EMPLOYMENT,
                                          REMUNERATION_TYPE,
                                          HOURS_PER_WEEK,
                                          PAY_PERIOD,
                                          WORK_PATTERN,
                                          JOB_PERMANENCY,
                                          JOB_CATEGORY,
                                          LOCATION,
                                          IS_MANAGER) AS MD_HASHDIFF,
              CURRENT_TIMESTAMP AS MD_CREATION_DT,    
              MD_SOURCE,
              WORKER_ID,
              HIRE_DATE,
              ORIGINAL_HIRED_DATE,
              PROVINCE_OF_EMPLOYMENT,
              REMUNERATION_TYPE,
              HOURS_PER_WEEK,
              PAY_PERIOD,
              WORK_PATTERN,
              JOB_PERMANENCY,
              JOB_CATEGORY,
              LOCATION,
              IS_MANAGER
       FROM (SELECT        
              CONTENT:data:workerId::STRING as WORKER_ID,
              CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
              MD_SOURCE,
              CONTENT:data:employmentInfo:hireDate::DATE as HIRE_DATE,
              CONTENT:data:employmentInfo:originalHiredDate::DATE as ORIGINAL_HIRED_DATE,
              CONTENT:data:employmentInfo:provinceOfEmployment::STRING AS PROVINCE_OF_EMPLOYMENT,
              CONTENT:data:employmentInfo:remunerationType::STRING AS REMUNERATION_TYPE,
              CONTENT:data:employmentInfo:hoursPerWeek::NUMERIC(38,2) AS HOURS_PER_WEEK,
              CONTENT:data:employmentInfo:payPeriod::STRING AS PAY_PERIOD,
              CONTENT:data:employmentInfo:workPattern::STRING AS WORK_PATTERN,
              CONTENT:data:employmentInfo:jobPermanency::STRING AS JOB_PERMANENCY,
              CONTENT:data:employmentInfo:jobCategory::STRING AS JOB_CATEGORY,
              CONTENT:data:employmentInfo:location::STRING AS LOCATION,
              CONTENT:data:employmentInfo:isManager::STRING AS IS_MANAGER
       FROM PLT_EVENTS_WORKER.UPLOADED) js
);
create or replace view VW_U_EMPLOYMENT_INFO_SALARY_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	SALARY,
	SALARY_EFFECTIVE_DATE
) as
(
        SELECT 
               PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
               MD_START_DT,
               PLT_MODEL_SHARED.UF_HASHDIFF_SALARY(SALARY,SALARY_EFFECTIVE_DATE) AS MD_HASHDIFF, 
               CURRENT_TIMESTAMP as MD_CREATION_DT,
               MD_SOURCE,
               WORKER_ID,
               SALARY,
               SALARY_EFFECTIVE_DATE
        FROM (SELECT        
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:employmentInfo:salaryInfo:salary::NUMBER(38,2) AS SALARY,
               CONTENT:data:employmentInfo:salaryInfo:salaryEffectiveDate::DATE AS SALARY_EFFECTIVE_DATE
        FROM PLT_EVENTS_WORKER.UPLOADED ) js
);
create or replace view VW_U_EMPLOYMENT_INFO_WORK_PERMIT_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	TYPE,
	START_DATE,
	END_DATE
) as
(
        SELECT 
               PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
               MD_START_DT,
               PLT_MODEL_SHARED.UF_HASHDIFF_WORK_PERMIT(TYPE,START_DATE,END_DATE) AS MD_HASHDIFF, 
               CURRENT_TIMESTAMP as MD_CREATION_DT,
               MD_SOURCE,
               WORKER_ID,
               TYPE,
               START_DATE,
               END_DATE
        FROM (SELECT   
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:employmentInfo:workPermit:type::STRING AS TYPE,
               CONTENT:data:employmentInfo:workPermit:startDate::DATE AS START_DATE,
               CONTENT:data:employmentInfo:workPermit:endDate::DATE AS END_DATE
        FROM PLT_EVENTS_WORKER.UPLOADED) js
);
create or replace view VW_U_LEAVE_STATUS_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	ON_LEAVE,
	LEAVE_START_DATE,
	LEAVE_END_DATE,
	REASON_CODE
) as
(
        SELECT PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
               MD_START_DT,
               PLT_MODEL_SHARED.UF_HASHDIFF_LEAVE_STATUS(ON_LEAVE,LEAVE_START_DATE,LEAVE_END_DATE,REASON_CODE) AS MD_HASHDIFF, 
               CURRENT_TIMESTAMP as MD_CREATION_DT,
               MD_SOURCE,
               WORKER_ID,
               ON_LEAVE,
               LEAVE_START_DATE,
               LEAVE_END_DATE,
               REASON_CODE
        FROM (SELECT  
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:leaveStatus:onLeave::STRING AS ON_LEAVE,
               CONTENT:data:leaveStatus:leaveStartDate::DATE AS LEAVE_START_DATE,
               CONTENT:data:leaveStatus:leaveEndDate::DATE AS LEAVE_END_DATE,
               CONTENT:data:leaveStatus:reasonCode::STRING AS REASON_CODE
        FROM PLT_EVENTS_WORKER.UPLOADED ) js
);
create or replace view VW_U_PERSONAL_INFO_ADDRESS_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	POSTAL_CODE_PARTIAL,
	PROVINCE,
	COUNTRY
) as 
(
SELECT  PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB,
		MD_START_DT, 
		PLT_MODEL_SHARED.UF_HASHDIFF_ADDRESS(POSTAL_CODE_PARTIAL,PROVINCE,COUNTRY) AS MD_HASHDIFF,
        CURRENT_TIMESTAMP AS MD_CREATION_DT,
		MD_SOURCE,
		CUSTOMER_ID,
        POSTAL_CODE_PARTIAL,
        PROVINCE,
        COUNTRY
FROM ( SELECT  
        CONTENT:data:customerId::STRING as CUSTOMER_ID,
        CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
        MD_SOURCE,
        CONTENT:data:personalInfo:address:postalCodePartial::STRING as POSTAL_CODE_PARTIAL,
        CONTENT:data:personalInfo:address:province::STRING AS PROVINCE,
        CONTENT:data:personalInfo:address:country::STRING AS COUNTRY
      FROM PLT_EVENTS_WORKER.UPLOADED 
    )
);
create or replace view VW_U_PERSONAL_INFO_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	MONTH_OF_BIRTH,
	GENDER
) as
(
	SELECT  PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB,
            MD_START_DT,       
			PLT_MODEL_SHARED.UF_HASHDIFF_PERSONAL_INFO(MONTH_OF_BIRTH,GENDER) AS MD_HASHDIFF,
			CURRENT_TIMESTAMP AS MD_CREATION_DT,
			MD_SOURCE,
            CUSTOMER_ID,
            MONTH_OF_BIRTH,
            GENDER
	FROM (  SELECT  
               CONTENT:data:customerId::STRING as CUSTOMER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:personalInfo:dateOfBirth::DATE as MONTH_OF_BIRTH,
               CONTENT:data:personalInfo:gender::STRING AS GENDER
            FROM PLT_EVENTS_WORKER.UPLOADED 
         ) 
);
create or replace view VW_U_RETIREMENT_STATUS_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	RETIRED,
	RETIREMENT_DATE,
	EXPECTED,
	EXPECTED_RETIREMENT_DATE
) as
(
        SELECT PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
               MD_START_DT,
               PLT_MODEL_SHARED.UF_HASHDIFF_RETIREMENT_STATUS(RETIRED,RETIREMENT_DATE,EXPECTED,EXPECTED_RETIREMENT_DATE) AS MD_HASHDIFF, 
               CURRENT_TIMESTAMP as MD_CREATION_DT,
               MD_SOURCE,
               WORKER_ID,
               RETIRED,
               RETIREMENT_DATE,
               EXPECTED,
               EXPECTED_RETIREMENT_DATE
        FROM (SELECT
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:retirementStatus:retired::STRING AS RETIRED,
               CONTENT:data:retirementStatus:retirementDate::DATE AS RETIREMENT_DATE,
               CONTENT:data:retirementStatus:expected::STRING AS EXPECTED,
               CONTENT:data:retirementStatus:expectedRetirementDate::DATE AS EXPECTED_RETIREMENT_DATE
        FROM PLT_EVENTS_WORKER.UPLOADED ) js
);
create or replace view VW_U_TERMINATION_STATUS_ORG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	TERMINATED,
	TERMINATION_DATE,
	REASON_CODE
) as
(
        SELECT PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB,
               MD_START_DT,
               PLT_MODEL_SHARED.UF_HASHDIFF_TERMINATION_STATUS(TERMINATED,TERMINATION_DATE,REASON_CODE) AS MD_HASHDIFF, 
               CURRENT_TIMESTAMP as MD_CREATION_DT,
               MD_SOURCE,
               WORKER_ID,
               TERMINATED,
               TERMINATION_DATE,
               REASON_CODE
        FROM (SELECT
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE,
               CONTENT:data:terminationStatus:terminated::STRING AS TERMINATED,
               CONTENT:data:terminationStatus:terminationDate::DATE AS TERMINATION_DATE,
               CONTENT:data:terminationStatus:reasonCode::STRING AS REASON_CODE
        FROM PLT_EVENTS_WORKER.UPLOADED ) js
);
create or replace view VW_U_WORKER_ORG(
	HK_LINK,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_WORKER,
	HK_HUB_CUSTOMER,
	HK_HUB_ORGANIZATION,
	WORKER_ID,
	CUSTOMER_ID,
	ORGANIZATION_ID
) as
(
       SELECT 
       PLT_MODEL_SHARED.UF_HASH_HK_LINK_SUBSCRIPTION(WORKER_ID,CUSTOMER_ID,ORGANIZATION_ID) AS HK_LINK, 
       MD_START_DT,
       CURRENT_TIMESTAMP as MD_CREATION_DT,
       MD_SOURCE,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_WORKER(WORKER_ID) AS HK_HUB_WORKER,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_CUSTOMER(CUSTOMER_ID) AS HK_HUB_CUSTOMER,
       PLT_MODEL_SHARED.UF_HASH_HK_HUB_ORGANIZATION(ORGANIZATION_ID) AS HK_HUB_ORGANIZATION,
       WORKER_ID,
       CUSTOMER_ID,
       ORGANIZATION_ID
       FROM (SELECT
               CONTENT:data:workerId::STRING as WORKER_ID,
               CONTENT:data:customerId::STRING AS CUSTOMER_ID,
               CONTENT:data:organizationId::STRING AS ORGANIZATION_ID,
               CONTENT:data:timestamp::TIMESTAMP as MD_START_DT,
               MD_SOURCE
        FROM PLT_EVENTS_WORKER.UPLOADED ) js
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_EIU"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.EMPLOYMENT_INFO_UPDATED"


var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.EMPLOYMENT_INFO_UPDATED (WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE ) \\n \\
(SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.EMPLOYMENT_INFO_UPDATED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.EMPLOYMENT_INFO_UPDATED (WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
 FROM ( SELECT  \\n \\
 t.$1:data.workerId,   \\n \\
 t.$1:data.timestamp,   \\n \\
 current_timestamp(),   \\n \\
 metadata$filename ,    \\n \\
 t.$1             \\n \\
 FROM @DATALAKE.RAW/WORKER/ t)  \\n \\
 PATTERN=''.*worker.employmentInfoUpdated.*json''  \\n \\
 FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 
 
try {

	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
	
	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_H"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.HIRED"


var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.HIRED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
(SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.HIRED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.HIRED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
 FROM ( SELECT  \\n \\
 t.$1:data.workerId,   \\n \\
 t.$1:data.timestamp,   \\n \\
 current_timestamp(),   \\n \\
 metadata$filename ,    \\n \\
 t.$1             \\n \\
 FROM @DATALAKE.RAW/WORKER/ t)  \\n \\
 PATTERN=''.*worker.hired.*json''  \\n \\
 FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 


try {

	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
	
	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_LC"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_CANCELLED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_CANCELLED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
(SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_ENDED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_CANCELLED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.workerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/WORKER/ t) \\n \\
PATTERN=''.*worker.leaveCancelled.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 

try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_LE"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_ENDED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_ENDED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_ENDED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_ENDED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.workerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/WORKER/ t) \\n \\
PATTERN=''.*worker.leaveEnded.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 


try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_LS"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_STARTED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_STARTED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_STARTED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_STARTED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.workerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/WORKER/ t) \\n \\
PATTERN=''.*worker.leaveStarted.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 


try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_LU"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_UPDATED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_UPDATED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_UPDATED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_UPDATED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.workerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/WORKER/ t) \\n \\
PATTERN=''.*worker.leaveUpdated.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = FALSE"; 


try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_SU"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.SALARY_UPDATED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.SALARY_UPDATED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.SALARY_UPDATED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.SALARY_UPDATED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.workerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/WORKER/ t) \\n \\
PATTERN=''.*worker.salaryUpdated.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 


try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_T"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '


var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
 FROM ( SELECT  \\n \\
 t.$1:data.workerId,   \\n \\
 t.$1:data.timestamp,   \\n \\
 current_timestamp(),   \\n \\
 metadata$filename ,    \\n \\
 t.$1             \\n \\
 FROM @DATALAKE.RAW/WORKER/ t)  \\n \\
 PATTERN=''.*worker.terminated.*json''  \\n \\
 FILE_FORMAT = ( TYPE = JSON) FORCE = false";  

try {
	
    var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();

    var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_TC"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '


var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
 FROM ( SELECT  \\n \\
 t.$1:data.workerId,   \\n \\
 t.$1:data.timestamp,   \\n \\
 current_timestamp(),   \\n \\
 metadata$filename ,    \\n \\
 t.$1             \\n \\
 FROM @DATALAKE.RAW/WORKER/ t)  \\n \\
 PATTERN=''.*worker.terminationCancelled.*json''  \\n \\
 FILE_FORMAT = ( TYPE = JSON) FORCE = false";  

try {
	
    var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();

    var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_U"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.UPLOADED";



var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.UPLOADED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT)(SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.UPLOADED WHERE WORKER_ID = ''always filter me'')";



var sql_command1 = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.UPLOADED (WORKER_ID, MD_START_DT, MD_CREATION_DT, MD_SOURCE,CONTENT) SELECT ''D9F8F4ED-1B35-4479-B305-6488ECCFFFBF'',null,null, ''TestData_RT--R-000001'', PARSE_JSON(''{\\"data\\":{\\"timestamp\\":\\"2022-03-22 05:20:21.2133333\\",\\"organizationId\\":\\"BNC\\",\\"customerId\\":\\"51EA52AF-A460-4C78-B2E2-5565E7544184\\",\\"workerId\\":\\"D9F8F4ED-1B35-4479-B305-6488ECCFFFBF\\",\\"personalInfo\\":{\\"dateOfBirth\\":\\"1997-01-21\\",\\"gender\\":null,\\"address\\":{\\"postalCodePartial\\":null,\\"province\\":null,\\"country\\":null}},\\"employmentInfo\\":{\\"hireDate\\":\\"2017-09-12\\",\\"originalHiredDate\\":null,\\"provinceOfEmployment\\":\\"QC\\",\\"remunerationType\\":null,\\"salaryInfo\\":{\\"salary\\":100000.0,\\"salaryEffectiveDate\\":\\"2017-09-12\\"},\\"hoursPerWeek\\":0,\\"payPeriod\\":\\"BIWEEKLY\\",\\"workPattern\\":null,\\"jobPermanency\\":\\"PERMANENT\\",\\"jobCategory\\":\\"BNC-J01\\",\\"location\\":\\"0001-1\\",\\"workPermit\\":{\\"type\\":null,\\"startDate\\":null,\\"endDate\\":null},\\"isManager\\":true},\\"leaveStatus\\":{\\"onLeave\\":false,\\"leaveStartDate\\":null,\\"leaveEndDate\\":null,\\"reasonCode\\":null},\\"terminationStatus\\":{\\"terminated\\":false,\\"terminationDate\\":null,\\"reasonCode\\":null},\\"retirementStatus\\":{\\"retired\\":false,\\"retirementDate\\":null,\\"expected\\":false,\\"expectedRetirementDate\\":null}}}'')"; 



var post_sql_command = "COPY INTO PLT_EVENTS_WORKER.UPLOADED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT)";  





  



try {

	

    var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });

    var result_scan1 = pre_sql_statement.execute();

    var sql_statement1 = snowflake.createStatement({sqlText: sql_command1 });

    var result_scan3 = sql_statement1.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });

    var result_scan2 = sql_statement.execute();


    var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });

    var result_scan3 = post_sql_statement.execute();

    result = "Succeeded!";

}



catch (err)  {

        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;

        result += " \\n Message: " + err.message;

        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;

        throw result; 

    }

     

 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_WORKER_H_TO_PLT_MODEL_SHARED"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.HIRED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.HIRED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.HIRED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.HIRED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.workerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/WORKER/ t) \\n \\
PATTERN=''.*worker.salaryUpdated.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 


try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOASTG_PSA_TO_PLT_EVENTS_WORKER_LC"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var pre_sql_command = "delete from DB_AC_"+ ENV +"_STG.PLT_EVENTS_WORKER.LEAVE_CANCELLED";
var sql_command = "insert into DB_AC_"+ ENV +"_STG.PLT_EVENTS_WORKER.LEAVE_CANCELLED(WORKER_ID, MD_CREATION_DT, MD_SOURCE, MD_START_DT) \\n \\
(SELECT WORKER_ID, MD_CREATION_DT, MD_SOURCE, MD_START_DT FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_WORKER.LEAVE_CANCELLED \\n \\
WHERE WORKER_ID = ''''always filter me'''')";
var post_sql_command = "COPY INTO DB_AC_"+ ENV +"_STG.PLT_EVENTS_WORKER.LEAVE_CANCELLED(WORKER_ID, MD_START_DT, MD_CREATION_DT, MD_SOURCE, CONTENT) \\n \\
FROM(SELECT \\n \\
t.$1:data.workerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/WORKER/ t) \\n \\
PATTERN=''''.*worker.leaveCancelled.*json'''' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 
try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err) {
        result = "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;

';
CREATE OR REPLACE PROCEDURE "SP_CONV_LoadSTG_PSA_To_PLT_EVENTS_WORKER_TC"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '


var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED";



var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) 
 
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED 
 
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) 
 
 FROM ( SELECT  
 
 t.$1:data.workerId,   
 
 t.$1:data.timestamp,   
 
 current_timestamp(),   
 
 metadata$filename ,    
 
 t.$1             
 
 FROM @DATALAKE.RAW/WORKER/ t)  
 
 PATTERN=''.*worker.terminationCancelled.*json''  
 
 FILE_FORMAT = ( TYPE = JSON) FORCE = false";  

try {
	
    var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();

    var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " 
 State: " + err.state;
        result += " 
 Message: " + err.message;
        result += " 
 Stack Trace: 
" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LoadSTG_PSA_To_PLT_EVENTS_WORKER_U"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "INSERT INTO  DB_AC_"+ ENV + "_STG.PLT_EVENTS_WORKER.UPLOADED (WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE) \\n \\
 (SELECT src.WORKER_ID WORKER_ID, \\n \\
src.MD_START_DT MD_START_DT, \\n \\
src.MD_CREATION_DT	MD_CREATION_DT, \\n \\
src.MD_SOURCE	MD_SOURCE, \\n \\
FROM DB_AC_"+ ENV + "_STG.PLT_EVENTS_WORKER.UPLOADED src ) WHERE  WORKER_ID= ''''always filter me'''')";;
try {

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE"("ENV" VARCHAR(1000), "s_VW_Event" VARCHAR(1000), "i_mapping_tgt_Model" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
    var mapping_json = JSON.parse(i_mapping_tgt_Model);
    trg_columns=object.keys(mapping_json).join()
    src_columns=object.values(mapping_json).join()
var sql_command = " INSERT INTO DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED."+T_INS_MODEL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER."+S_VW_EVENT;
try {
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\\\\\n State: " + err.state;
        result += " \\\\\\\\n Message: " + err.message;
        result += " \\\\\\\\n Stack Trace: \\\\\\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MT_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_LU"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_UPDATED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_UPDATED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_UPDATED \\n \\
WHERE  WORKER_ID= ''always filter me'')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.LEAVE_UPDATED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
FROM ( SELECT \\n \\
t.$1:data.workerId, \\n \\
t.$1:data.timestamp, \\n \\
current_timestamp(), \\n \\
metadata$filename , \\n \\
t.$1 \\n \\
FROM @DATALAKE.RAW/WORKER/ t) \\n \\
PATTERN=''.*worker.leaveUpdated.*json'' \\n \\
FILE_FORMAT = ( TYPE = JSON) FORCE = false"; 


try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

	var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_EMPLOYMENT_INFO"("HIRE_DATE" DATE, "ORIGINAL_HIRED_DATE" DATE, "PROVINCE_OF_EMPLOYMENT" VARCHAR(16777216), "REMUNERATION_TYPE" VARCHAR(16777216), "HOURS_PER_WEEK" NUMBER(38,2), "PAY_PERIOD" VARCHAR(16777216), "WORK_PATTERN" VARCHAR(16777216), "JOB_PERMANENCY" VARCHAR(16777216), "JOB_CATEGORY" VARCHAR(16777216), "LOCATION" VARCHAR(16777216), "IS_MANAGER" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(HIRE_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(HOURS_PER_WEEK))),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(IS_MANAGER)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(LOCATION)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(JOB_CATEGORY)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(JOB_PERMANENCY)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(ORIGINAL_HIRED_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(PAY_PERIOD)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(PROVINCE_OF_EMPLOYMENT)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(REMUNERATION_TYPE)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(WORK_PATTERN)),''#NULL#'') 
                     
                )  
               )::string

';
create or replace schema PLT_MODEL_PLATFORM_ACCESS_LOG;

create or replace TRANSIENT TABLE PLATFORM_ACCESS_LOG (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_WORKER VARCHAR(16777216),
	HK_HUB_CUSTOMER VARCHAR(16777216),
	HK_HUB_ORGANIZATION VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform Id',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform Id',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Organization plateform Id',
	ACCESS_DT TIMESTAMP_NTZ(9) COMMENT 'The acccess date when the user log on the plateforme',
	USER_AGENT VARCHAR(16777216) COMMENT 'The user agent from the user browser'
);
create or replace view VW_PLATFORM_ACCESS_LOG(
	HK_LINK,
	MD_START_DT,
	MD_SOURCE,
	MD_RESERVED,
	HK_HUB_WORKER,
	HK_HUB_CUSTOMER,
	HK_HUB_ORGANIZATION,
	WORKER_ID,
	CUSTOMER_ID,
	ORGANIZATION_ID,
	ACCESS_DT,
	USER_AGENT
) as
(
       SELECT        
        HK_LINK,
        MD_START_DT,	    
        MD_SOURCE,
        MD_RESERVED,
        HK_HUB_WORKER,
        HK_HUB_CUSTOMER,
        HK_HUB_ORGANIZATION,
        WORKER_ID,
        CUSTOMER_ID,
        ORGANIZATION_ID,
        ACCESS_DT,
        USER_AGENT
       FROM PLT_MODEL_PLATFORM_ACCESS_LOG.PLATFORM_ACCESS_LOG
);
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_OPEN_SHOPPING_PERIOD"("REASON" VARCHAR(16777216), "BEGINSON" DATE, "ENDSON" DATE, "EFFECTIVE_DATE" DATE, "EXPIRATION_DATE" DATE, "STATUS" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
SHA1(
	NVL(RTRIM(LTRIM(REASON)),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(TO_VARCHAR(BEGINSON,''yyyy-mm-dd hh24:mi:ss.ff3'' ))),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(TO_VARCHAR(ENDSON,''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(TO_VARCHAR(EFFECTIVE_DATE,''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(TO_VARCHAR(EXPIRATION_DATE,''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(STATUS)),''#NULL#'') 
)::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER"("CREATION_DATE" DATE, "AMOUNT" NUMBER(14,2), "AMOUNT_AFTER_TAX" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
					|| ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(AMOUNT))),''#NULL#'') 
                    || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(AMOUNT_AFTER_TAX))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER"("CREATION_DATE" DATE, "TOTAL_AMOUNT" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
					|| ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(TOTAL_AMOUNT))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER"("CREATION_DATE" TIMESTAMP_NTZ(9), "TOTAL_AMOUNT" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
					|| ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(TOTAL_AMOUNT))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER_ITEM"("QUANTITY" NUMBER(38,0))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(QUANTITY))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER_ITEM"("QUANTITY" NUMBER(38,0), "AMOUNT" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(QUANTITY))),''#NULL#'')  
                    || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(AMOUNT))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER_STATUS"("STATUS" VARCHAR(16777216), "STATUS_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
					NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                    || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(STATUS_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER_STATUS"("STATUS" VARCHAR(16777216), "STATUS_DATE" TIMESTAMP_NTZ(9))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
					NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                    || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(STATUS_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_ITEM"("QUANTITY" NUMBER(38,0))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(QUANTITY))),''#NULL#'')                       
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_ITEM"("QUANTITY" NUMBER(38,0), "AMOUNT" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(QUANTITY))),''#NULL#'')  
                     || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(AMOUNT))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_REQUEST"("CREATION_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_REQUEST"("CREATION_DATE" DATE, "STATUS" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_REQUEST"("CREATION_DATE" TIMESTAMP_NTZ(9), "STATUS" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_LIFE_EVENT"("LIFE_EVENT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(LIFE_EVENT_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_OPEN_SHOPPING_PERIOD_ID"("OPEN_SHOPPING_PERIOD_ID" NUMBER(38,0))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(TO_VARCHAR(OPEN_SHOPPING_PERIOD_ID))),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_ORDER"("ORDER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(ORDER_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PREVIOUS_PRODUCT_CATALOG_ID"("PREVIOUS_PRODUCT_CATALOG_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(PREVIOUS_PRODUCT_CATALOG_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCT_CATALOG_ID"("PRODUCT_CATALOG_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_SHOPPING_REQUEST"("SHOPPING_REQUEST_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(SHOPPING_REQUEST_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_ENROLLED"("OPEN_SHOPPING_PERIOD_ID" NUMBER(38,0), "PRODUCTCATALOG_ID" VARCHAR(16777216), "PREVIOUSPRODUCTCATALOG_ID" VARCHAR(16777216), "WORKER_ID" VARCHAR(1677216), "CUSTOMER_ID" VARCHAR(1677216), "ORGANIZATION_ID" VARCHAR(16777216), "CAMPAIGN_ID" VARCHAR(1677216), "LIFE_EVENT_ID" VARCHAR(1677216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
          NVL(RTRIM(LTRIM(TO_VARCHAR(OPEN_SHOPPING_PERIOD_ID))),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(PRODUCTCATALOG_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(PREVIOUSPRODUCTCATALOG_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(WORKER_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(CAMPAIGN_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(LIFE_EVENT_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_ENROLLED"("OPEN_SHOPPING_PERIOD_ID" VARCHAR(16777216), "PRODUCT_CATALOG_ID" VARCHAR(16777216), "PREVIOUS_PRODUCT_CATALOG_ID" VARCHAR(16777216), "WORKER_ID" VARCHAR(1677216), "CUSTOMER_ID" VARCHAR(1677216), "ORGANIZATION_ID" VARCHAR(16777216), "CAMPAIGN_ID" VARCHAR(1677216), "LIFEEVENT_ID" VARCHAR(1677216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
          NVL(RTRIM(LTRIM(OPEN_SHOPPING_PERIOD_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(PREVIOUS_PRODUCT_CATALOG_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(WORKER_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(CAMPAIGN_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(LIFEEVENT_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_ORDER_CUSTOMER"("ORDER_ID" VARCHAR(16777216), "CUSTOMER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(ORDER_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_ORDER_ITEM"("ORDER_ID" VARCHAR(16777216), "SELECTED_PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(ORDER_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(SELECTED_PRODUCT_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_SHOPPING_CUSTOMER"("SHOPPING_REQUEST_ID" VARCHAR(16777216), "CUSTOMER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(SHOPPING_REQUEST_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_SHOPPING_ITEM"("SHOPPING_REQUEST_ID" VARCHAR(16777216), "SELECTED_PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(SELECTED_PRODUCT_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(SHOPPING_REQUEST_ID)),''#NULL#'')
       )::string
';
create or replace schema PLT_MODEL_PRODUCT;

create or replace TRANSIENT TABLE CATALOG_PRODUCT_LIST (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_PRODUCT_CATALOG VARCHAR(16777216),
	HK_HUB_PRODUCT VARCHAR(16777216),
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Shopping Request id',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product id'
);
create or replace TRANSIENT TABLE PACKAGE_PRODUCT_LIST (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_PACKAGE_PRODUCT VARCHAR(16777216),
	HK_HUB_PRODUCT VARCHAR(16777216),
	PACKAGE_PRODUCT_ID VARCHAR(16777216) COMMENT 'Parent Product plateform ID',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Package product list Product id'
);
create or replace TRANSIENT TABLE PERSONAL_INTEREST (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(64) COMMENT ' Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	INTEREST_ID VARCHAR(16777216) COMMENT 'Interest plateform ID',
	NAME_FR VARCHAR(16777216) COMMENT 'Interest name in french',
	NAME_EN VARCHAR(16777216) COMMENT 'Interest name in english'
);
create or replace TRANSIENT TABLE PERSONAL_INTEREST_TAG (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_PERSONAL_INTEREST VARCHAR(16777216) COMMENT 'HASH of the personal interest business key',
	HK_HUB_PRODUCT_TAG VARCHAR(16777216) COMMENT 'HASH of the TAG',
	INTEREST_ID VARCHAR(16777216) COMMENT 'Interest plateform ID ',
	TAG VARCHAR(16777216) COMMENT 'TAG related to the personal interest'
);
create or replace TRANSIENT TABLE PRODUCT (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_PRODUCT VARCHAR(16777216),
	HK_HUB_PROVIDER VARCHAR(16777216),
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product plateform Id',
	PROVIDER_ID VARCHAR(16777216) COMMENT 'Product provider Id'
);
create or replace TRANSIENT TABLE PRODUCT_CATALOG (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF_SAT_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'Product Catalog hkhub',
	HK_HUB_ORGANIZATION VARCHAR(16777216) COMMENT 'Organization hkhub',
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Product Catalog id',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Organization id',
	NAME_FR VARCHAR(16777216) COMMENT 'Product Catalog Name (fr)',
	NAME_EN VARCHAR(16777216) COMMENT 'Product Catalog Name (en)',
	DESCRIPTION_EN VARCHAR(16777216) COMMENT 'Product Catalog Description (fr)',
	DESCRIPTION_FR VARCHAR(16777216) COMMENT 'Product Catalog Description (en)',
	START_DATE DATE COMMENT 'Product Catalog Start Date',
	END_DATE DATE COMMENT 'Product Catalog End Date'
);
create or replace TRANSIENT TABLE PRODUCT_INFO (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product plateform ID',
	CATEGORY VARCHAR(16777216) COMMENT 'Product category',
	NAME_FR VARCHAR(16777216) COMMENT ' Product Name in French',
	NAME_EN VARCHAR(16777216) COMMENT 'Product Name in English',
	DESCRIPTION_FR VARCHAR(16777216) COMMENT 'Product Description in French',
	DESCRIPTION_EN VARCHAR(16777216) COMMENT 'Product Description in English',
	TYPE VARCHAR(16777216) COMMENT 'Type of Product',
	COVERAGE_TYPE VARCHAR(16777216) COMMENT 'Coverage type',
	AVAILABILITY_START_DATE DATE COMMENT 'Product availability start date',
	AVAILABILITY_END_DATE DATE COMMENT 'Product availability end date',
	IS_PACKAGE VARCHAR(16777216) COMMENT 'Product is package predicate',
	SKU VARCHAR(16777216) COMMENT 'Product sku'
);
create or replace TRANSIENT TABLE PRODUCT_TAG (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_LTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_PRODUCT VARCHAR(16777216),
	HK_HUB_PRODUCT_TAG VARCHAR(16777216),
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product id',
	TAG VARCHAR(16777216) COMMENT 'TAG related to the product'
);
create or replace view VW_PRODUCT_CATALOG(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	PRODUCT_CATALOG_ID,
	NAME_FR,
	NAME_EN,
	DESCRIPTION_FR,
	DESCRIPTION_EN,
	START_DATE,
	END_DATE
) as 
(


SELECT 
      HK_HUB_PRODUCT_CATALOG AS HK_HUB, 
      MD_START_DT,
      MD_HASHDIFF_SAT_PRODUCT_CATALOG as MD_HASHDIFF,  
      CURRENT_TIMESTAMP AS MD_CREATION_DT,
      MD_SOURCE,
      MD_RESERVED, 
      PRODUCT_CATALOG_ID, 
      NAME_FR, 
      NAME_EN,
      DESCRIPTION_FR,
      DESCRIPTION_EN,
      START_DATE,
      END_DATE
FROM PLT_MODEL_PRODUCT.PRODUCT_CATALOG

  
);
create or replace view VW_PRODUCT_TAG(
	HK_HUB,
	MD_START_DT,
	MD_SOURCE,
	MD_RESERVED,
	TAG
) as
(
       SELECT
        distinct HK_HUB_PRODUCT_TAG as HK_HUB,
        MD_START_DT,
        MD_SOURCE,
        MD_RESERVED,
        TAG
       FROM PLT_MODEL_PRODUCT.PRODUCT_TAG
  
   UNION
  
       SELECT
        distinct HK_HUB_PRODUCT_TAG as HK_HUB,
        MD_START_DT,
        MD_SOURCE,
        MD_RESERVED,
        TAG
       FROM PLT_MODEL_PRODUCT.PERSONAL_INTEREST_TAG
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_PRODUCT_UPLOADED"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_PRE_QUERY STRING;
INS_QUERY STRING;
BEGIN
INS_PRE_QUERY :=''delete from DB_AC_''||ENV||''_STG.PLT_EVENTS_PRODUCT.UPLOADED'';
INS_QUERY := ''
COPY INTO PLT_EVENTS_PRODUCT.UPLOADED(PRODUCT_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT)
 FROM ( SELECT
 t.$1:data.productInfo.productId,
 t.$1:data.timestamp,
 current_timestamp(),
 metadata$filename ,
 t.$1
 FROM @DATALAKE.RAW/PRODUCT/ t)
 PATTERN=''''.*product.uploaded.*json''''
 FILE_FORMAT = ( TYPE = JSON) FORCE = false;
              '';
EXECUTE IMMEDIATE :INS_PRE_QUERY;
EXECUTE IMMEDIATE :INS_QUERY;
END
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE_PRODUCT"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_QUERY STRING;
BEGIN
INS_QUERY := ''
INSERT INTO DB_AC_''||ENV||''_STG.PLT_MODEL_PRODUCT.PRODUCT
(HK_LINK
,MD_START_DT
,MD_CREATION_DT
,MD_SOURCE
,MD_RESERVED
,HK_HUB_PRODUCT
,HK_HUB_PROVIDER
,PRODUCT_ID
,PROVIDER_ID)
SELECT
src.HK_LINK
,src.MD_START_DT
,CURRENT_TIMESTAMP
,src.MD_SOURCE
,0
,src.HK_HUB_PRODUCT
,src.HK_HUB_PROVIDER
,src.PRODUCT_ID
,src.PROVIDER_ID
FROM DB_AC_''||ENV||''_STG.PLT_EVENTS_PRODUCT.VW_U_PRODUCT src
              '';
EXECUTE IMMEDIATE :INS_QUERY;
END
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE_PRODUCT_INFO"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_QUERY STRING;
BEGIN
INS_QUERY := ''
INSERT INTO DB_AC_''||ENV||''_STG.PLT_MODEL_PRODUCT.PRODUCT_INFO
(HK_HUB
,MD_START_DT
,MD_HASHDIFF
,MD_CREATION_DT
,MD_SOURCE
,MD_RESERVED
,PRODUCT_ID
,CATEGORY
,NAME_FR
,NAME_EN
,DESCRIPTION_FR
,DESCRIPTION_EN
,TYPE
,COVERAGE_TYPE
,AVAILABILITY_START_DATE
,AVAILABILITY_END_DATE
,IS_PACKAGE
,SKU)
SELECT
HK_HUB
,src.MD_START_DT
,src.MD_HASHDIFF
,CURRENT_TIMESTAMP
,src.MD_SOURCE
,0
,src.PRODUCT_ID
,src.CATEGORY
,src.NAME_FR
,src.NAME_EN
,src.DESCRIPTION_FR
,src.DESCRIPTION_EN
,src.TYPE
,src.COVERAGE_TYPE
,src.AVAILABILITY_START_DATE
,src.AVAILABILITY_END_DATE
,src.IS_PACKAGE
,src.SKU
FROM DB_AC_''||ENV||''_STG.PLT_EVENTS_PRODUCT.VW_U_PRODUCT_INFO src
              '';
EXECUTE IMMEDIATE :INS_QUERY;
END
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE_PRODUCT_LIST"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_QUERY STRING;
BEGIN
INS_QUERY := ''
INSERT INTO DB_AC_''||ENV||''_STG.PLT_MODEL_PRODUCT.PACKAGE_PRODUCT_LIST
(HK_LINK
,MD_START_DT
,MD_CREATION_DT
,MD_SOURCE
,MD_RESERVED
,HK_HUB_PACKAGE_PRODUCT
,HK_HUB_PRODUCT
,PACKAGE_PRODUCT_ID
,PRODUCT_ID)
SELECT
src.HK_LINK
,src.MD_START_DT
,CURRENT_TIMESTAMP
,src.MD_SOURCE
,0
,src.HK_HUB_PACKAGE_PRODUCT
,src.HK_HUB_PRODUCT
,src.PACKAGE_PRODUCT_ID
,src.PRODUCT_ID
FROM DB_AC_''||ENV||''_STG.PLT_EVENTS_PRODUCT.VW_U_PACKAGE_PRODUCT_LIST src
              '';
EXECUTE IMMEDIATE :INS_QUERY;
END
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE_PRODUCT_TAG"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_QUERY STRING;
BEGIN
INS_QUERY := ''
INSERT INTO DB_AC_''||ENV||''_STG.PLT_MODEL_PRODUCT.PRODUCT_TAG
(HK_LINK
,MD_START_DT
,MD_HASHDIFF
,MD_CREATION_DT
,MD_SOURCE
,MD_RESERVED
,HK_HUB_PRODUCT
,HK_HUB_PRODUCT_TAG
,PRODUCT_ID
,TAG)
SELECT
src.HK_LINK
,src.MD_START_DT
,src.MD_HASHDIFF
,CURRENT_TIMESTAMP
,src.MD_SOURCE
,0
,src.HK_HUB_PRODUCT
,src.HK_HUB_PRODUCT_TAG
,src.PRODUCT_ID
,src.TAG
FROM DB_AC_''||ENV||''_STG.PLT_EVENTS_PRODUCT.VW_U_PRODUCT_TAG src
              '';
EXECUTE IMMEDIATE :INS_QUERY;
END
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_PERSONAL_INTEREST"("NAME_FR" VARCHAR(16777216), "NAME_EN" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(NAME_EN)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(NAME_FR)),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_PERSONAL_INTEREST_TAG"("MD_START_DT" TIMESTAMP_NTZ(9))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(MD_START_DT, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_PRODUCT_CATALOG"("NAME_FR" VARCHAR(16777216), "NAME_EN" VARCHAR(16777216), "DESCRIPTION_FR" VARCHAR(16777216), "DESCRIPTION_EN" VARCHAR(16777216), "START_DATE" DATE, "END_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                 NVL(RTRIM(LTRIM(DESCRIPTION_EN)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(DESCRIPTION_FR)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(TO_VARCHAR(END_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(NAME_EN)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(NAME_FR)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(TO_VARCHAR(START_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_PRODUCT_CATALOG_PRODUCT_PLT"("MD_START_DATE" TIMESTAMP_NTZ(9))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(MD_START_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_PRODUCT_INFO"("CATEGORY" VARCHAR(16777216), "NAME_FR" VARCHAR(16777216), "NAME_EN" VARCHAR(16777216), "DESCRIPTION_FR" VARCHAR(16777216), "DESCRIPTION_EN" VARCHAR(16777216), "TYPE" VARCHAR(16777216), "COVERAGE_TYPE" VARCHAR(16777216), "AVAILABILITY_START_DATE" DATE, "AVAILABILITY_END_DATE" DATE, "SKU" VARCHAR(16777216), "IS_PACKAGE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                    NVL(RTRIM(LTRIM(CATEGORY)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(NAME_FR)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(NAME_EN)),''#NULL#'')
                     || ''|'' ||  
                    NVL(RTRIM(LTRIM(DESCRIPTION_FR)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(DESCRIPTION_EN)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(TYPE)),''#NULL#'')
                    || ''|'' ||  
                     NVL(RTRIM(LTRIM(COVERAGE_TYPE)),''#NULL#'')
                    || ''|'' ||                                          
                    NVL(RTRIM(LTRIM(TO_VARCHAR(AVAILABILITY_START_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(TO_VARCHAR(AVAILABILITY_END_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(SKU)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(IS_PACKAGE)),''#NULL#'')                               
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_PRODUCT_TAG"("MD_START_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(MD_START_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_PRODUCT_TAG_PLT"("MD_START_DATE" TIMESTAMP_NTZ(9))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(MD_START_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PACKAGE_PRODUCT"("PACKAGE_PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(PACKAGE_PRODUCT_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PERSONAL_INTEREST"("INTEREST_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(INTEREST_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCT"("PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(PRODUCT_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCT_CATALOG"("PRODUCT_CATALOG_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCT_PROVIDER"("PROVIDER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(PROVIDER_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCT_TAG"("TAG" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(TAG)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_PACKAGE_PRODUCT_LIST"("PACKAGE_PRODUCT_ID" VARCHAR(16777216), "PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(PACKAGE_PRODUCT_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(PRODUCT_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_PERSONAL_INTEREST_TAG"("INTEREST_ID" VARCHAR(16777216), "TAG" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
         UPPER( 
           NVL(RTRIM(LTRIM(INTEREST_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(TAG)),''#NULL#'')
         )
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_PRODUCT"("PRODUCT_ID" VARCHAR(16777216), "PROVIDER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(PRODUCT_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(PROVIDER_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_PRODUCT_CATALOG_ORGANIZATION"("PRODUCT_CATALOG_ID" VARCHAR(16777216), "ORGANIZATION_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_PRODUCT_CATALOG_PRODUCT"("PRODUCT_CATALOG_ID" VARCHAR(16777216), "PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(PRODUCT_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_PRODUCT_TAG"("PRODUCT_ID" VARCHAR(16777216), "TAG" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(PRODUCT_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(TAG)),''#NULL#'')
       )::string
';
create or replace schema PLT_MODEL_SHARED;

create or replace TRANSIENT TABLE EMPLOYMENT_INFORMATION (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	HIRE_DATE DATE COMMENT 'Employee hire DATE',
	ORIGINAL_HIRED_DATE DATE COMMENT 'Employee original hired date',
	PROVINCE_OF_EMPLOYMENT VARCHAR(16777216) COMMENT 'Employee Province of employement',
	REMUNERATION_TYPE VARCHAR(16777216) COMMENT 'Employee remuneration type',
	HOURS_PER_WEEK NUMBER(38,2) COMMENT 'Employee hours per week',
	PAY_PERIOD VARCHAR(16777216) COMMENT 'Employee pay periode',
	WORK_PATTERN VARCHAR(16777216) COMMENT 'Employee work pattern',
	JOB_PERMANENCY VARCHAR(16777216) COMMENT 'Employee job permanency',
	JOB_CATEGORY VARCHAR(16777216) COMMENT 'Employee job Category ',
	LOCATION VARCHAR(16777216) COMMENT 'Employee Location',
	IS_MANAGER VARCHAR(16777216) COMMENT 'Employee is a manager'
);
create or replace TRANSIENT TABLE INDIVIDUAL (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(64) COMMENT ' Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform ID',
	MONTH_OF_BIRTH DATE COMMENT 'Month of birth',
	GENDER VARCHAR(16777216) COMMENT 'Individual Gender'
);
create or replace TRANSIENT TABLE LEAVE_STATUS (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	ON_LEAVE VARCHAR(16777216) COMMENT 'On leave predicate',
	LEAVE_START_DATE DATE COMMENT 'Leave start DATE',
	LEAVE_END_DATE DATE COMMENT 'Leave end DATE',
	REASON_CODE VARCHAR(16777216) COMMENT 'Leave reason code'
);
create or replace TRANSIENT TABLE PERSONAL_ADDRESS (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform ID',
	POSTAL_CODE_PARTIAL VARCHAR(16777216) COMMENT 'Personal address partial postal code ',
	PROVINCE VARCHAR(16777216) COMMENT 'Personal address Province',
	COUNTRY VARCHAR(16777216) COMMENT 'Personal address Counrty'
);
create or replace TRANSIENT TABLE RETIREMENT_STATUS (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	RETIRED VARCHAR(16777216) COMMENT 'Retired predicate',
	RETIREMENT_DATE DATE COMMENT 'Retirement date',
	EXPECTED VARCHAR(16777216) COMMENT 'Retirement expected predicate',
	EXPECTED_RETIREMENT_DATE DATE COMMENT 'Expected retirement date'
);
create or replace TRANSIENT TABLE SALARY (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	SALARY NUMBER(38,2) COMMENT 'Salary',
	SALARY_EFFECTIVE_DATE DATE COMMENT 'Salary effective DATE'
);
create or replace TRANSIENT TABLE TERMINATION_STATUS (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	TERMINATED VARCHAR(16777216) COMMENT 'Terminated predicate',
	TERMINATION_DATE DATE COMMENT 'Termination date',
	REASON_CODE VARCHAR(16777216) COMMENT 'Termination reason code'
);
create or replace TRANSIENT TABLE WORKER (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_WORKER VARCHAR(16777216) COMMENT 'HASH of the worker business key',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HASH of the cvustomer business key',
	HK_HUB_ORGANIZATION VARCHAR(16777216) COMMENT 'HASH of the organization business key',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Worker Customer id',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Worker organization id'
);
create or replace TRANSIENT TABLE WORK_PERMIT (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	TYPE VARCHAR(16777216) COMMENT ' Work permit type',
	START_DATE DATE COMMENT 'Work permit start DATE',
	END_DATE DATE COMMENT 'Work permit end DATE'
);
create or replace view VW_ORGANIZATION(
	HK_HUB,
	MD_START_DT,
	MD_SOURCE,
	MD_RESERVED,
	ORGANIZATION_ID
) as
(
       SELECT
        distinct HK_HUB_ORGANIZATION as HK_HUB,
        MD_START_DT,
        MD_SOURCE,
        MD_RESERVED,
        ORGANIZATION_ID
       FROM PLT_MODEL_SHARED.WORKER
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_CUSTOMER_PIU_TO_MODEL_SHARED_INDIVIDUAL"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var INS_QUERY = "INSERT INTO DB_AC_"+ ENV +"_STG.PLT_MODEL_SHARED.INDIVIDUAL ( HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,CUSTOMER_ID,MONTH_OF_BIRTH,GENDER ) SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,CURRENT_TIMESTAMP,MD_SOURCE,CUSTOMER_ID,MONTH_OF_BIRTH,GENDER FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_CUSTOMER.VW_PIU_PERSONAL_INFO ";

   
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();
   


';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_CUSTOMER_PIU_TO_MODEL_SHARED_PERSONAL_ADDRESS"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var INS_QUERY = "INSERT INTO DB_AC_"+ ENV +"_STG.PLT_MODEL_SHARED.PERSONAL_ADDRESS ( HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,CUSTOMER_ID,POSTAL_CODE_PARTIAL,PROVINCE,COUNTRY ) SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,CURRENT_TIMESTAMP,MD_SOURCE,CUSTOMER_ID,POSTAL_CODE_PARTIAL,PROVINCE,COUNTRY FROM DB_AC_"+ ENV +"_STG.PLT_EVENTS_CUSTOMER.VW_PIU_PERSONAL_INFO_ADDRESS ";

   
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();
   


';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_LE_TO_MODEL_SHARED_LEAVE_ENDED"("ENV" VARCHAR(1000), "S_VW_EVENT" VARCHAR(1000), "T_INS_MODEL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED."+T_INS_MODEL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER."+S_VW_EVENT;
try {
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_LU_TO_MODEL_SHARED_LEAVE_UPDATED"("ENV" VARCHAR(1000), "S_VW_EVENT" VARCHAR(1000), "T_INS_MODEL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED."+T_INS_MODEL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER."+S_VW_EVENT;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_SU_TO_MODEL_SHARED_SALARY"("ENV" VARCHAR(1000), "S_VW_EVENT" VARCHAR(1000), "T_INS_MODEL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED."+T_INS_MODEL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER."+S_VW_EVENT;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_TC_TO_MODEL_SHARED_TERMINATION_STATUS"("ENV" VARCHAR(1000), "S_VW_EVENT" VARCHAR(1000), "T_INS_MODEL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED."+T_INS_MODEL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER."+S_VW_EVENT;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_EMPLOYMENT_INFORMATION"("ENV" VARCHAR(1000), "S_VW_EVENT" VARCHAR(1000), "T_INS_MODEL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED."+T_INS_MODEL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER."+S_VW_EVENT;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_INDIVIDUAL"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED.INDIVIDUAL (HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,CUSTOMER_ID,MONTH_OF_BIRTH,GENDER) \\n \\
 (SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,current_timestamp AS o_MD_CREATION_DT,MD_SOURCE,CUSTOMER_ID,MONTH_OF_BIRTH,GENDER FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.VW_U_PERSONAL_INFO)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_LEAVE_STATUS"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED.LEAVE_STATUS (HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,MD_RESERVED,WORKER_ID,ON_LEAVE,LEAVE_START_DATE,LEAVE_END_DATE,REASON_CODE) \\n \\
 (SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,current_timestamp AS o_MD_CREATION_DT,MD_SOURCE,NULL AS MD_RESERVED,WORKER_ID,ON_LEAVE,LEAVE_START_DATE,LEAVE_END_DATE,REASON_CODE FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.VW_U_LEAVE_STATUS)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_PERSONAL_ADDRESS"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED.PERSONAL_ADDRESS (HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,CUSTOMER_ID,POSTAL_CODE_PARTIAL,PROVINCE,COUNTRY) \\n \\
 (SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,current_timestamp AS o_MD_CREATION_DT,MD_SOURCE,CUSTOMER_ID,POSTAL_CODE_PARTIAL,PROVINCE,COUNTRY FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.VW_U_PERSONAL_INFO_ADDRESS)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_RETIREMENT_STATUS"("ENV" VARCHAR(1000), "S_VW_EVENT" VARCHAR(1000), "T_INS_MODEL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED."+T_INS_MODEL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER."+S_VW_EVENT;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_SALARY"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED.SALARY (HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,WORKER_ID,SALARY,SALARY_EFFECTIVE_DATE) \\n \\
 (SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,current_timestamp AS o_MD_CREATION_DT,MD_SOURCE,WORKER_ID,SALARY,SALARY_EFFECTIVE_DATE FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.VW_U_EMPLOYMENT_INFO_SALARY)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_TERMINATION_STATUS"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED.TERMINATION_STATUS (HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,MD_RESERVED,WORKER_ID,TERMINATED,TERMINATION_DATE,REASON_CODE) \\n \\
 (SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,current_timestamp AS o_MD_CREATION_DT,MD_SOURCE,NULL AS MD_RESERVED,WORKER_ID,TERMINATED,TERMINATION_DATE,REASON_CODE FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.VW_U_TERMINATION_STATUS)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_WORKER"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED.WORKER (HK_LINK,MD_START_DT,MD_CREATION_DT,MD_SOURCE,HK_HUB_WORKER,HK_HUB_CUSTOMER,HK_HUB_ORGANIZATION,WORKER_ID,CUSTOMER_ID,ORGANIZATION_ID) \\n \\
 (SELECT HK_LINK,MD_START_DT,current_timestamp AS o_MD_CREATION_DT,MD_SOURCE,HK_HUB_WORKER,HK_HUB_CUSTOMER,HK_HUB_ORGANIZATION,WORKER_ID,CUSTOMER_ID,ORGANIZATION_ID FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.VW_U_WORKER)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_WORKER_U_TO_MODEL_SHARED_WORK_PERMIT"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED.WORK_PERMIT (HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,WORKER_ID,TYPE,START_DATE,END_DATE) \\n \\
 (SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,current_timestamp AS o_MD_CREATION_DT,MD_SOURCE,WORKER_ID,TYPE,START_DATE,END_DATE FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.VW_U_EMPLOYMENT_INFO_WORK_PERMIT)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PSA_TO_PLT_EVENTS_WORKER_U"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED.SALARY (HK_HUB,MD_START_DT,MD_HASHDIFF,MD_CREATION_DT,MD_SOURCE,WORKER_ID,SALARY,SALARY_EFFECTIVE_DATE) \\n \\
 (SELECT HK_HUB,MD_START_DT,MD_HASHDIFF,current_timestamp AS o_MD_CREATION_DT,MD_SOURCE,WORKER_ID,SALARY,SALARY_EFFECTIVE_DATE FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.VW_U_EMPLOYMENT_INFO_SALARY)";

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ADDRESS"("POSTAL_CODE_PARTIAL" VARCHAR(16777216), "PROVINCE" VARCHAR(16777216), "COUNTRY" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
                    UPPER( 
                    
                        NVL(RTRIM(LTRIM(COUNTRY)),''#NULL#'')
                        || ''|'' ||
						NVL(RTRIM(LTRIM(POSTAL_CODE_PARTIAL)),''#NULL#'')
						|| ''|'' ||
						NVL(RTRIM(LTRIM(PROVINCE)),''#NULL#'')
                  
					) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_CAMPAIGN"("TYPE" VARCHAR(16777216), "ORGANIZATION_ID" VARCHAR(16777216), "WORKER_GROUP" VARCHAR(16777216), "JOB_CATEGORY" VARCHAR(16777216), "GROUP_TYPE_CODE" VARCHAR(16777216), "GROUP_REFERENCES" VARCHAR(16777216), "SCHEDULED_TIME" TIME(9), "BEGINS_ON" TIMESTAMP_NTZ(9), "ENDS_ON" TIMESTAMP_NTZ(9), "BENEFITS_EFFECTIVE_DATE" DATE, "ELIGIBILITY_RULE_SET" VARCHAR(16777216), "IS_STARTED" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TYPE)),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(WORKER_GROUP)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(JOB_CATEGORY)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(GROUP_TYPE_CODE)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(GROUP_REFERENCES)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(SCHEDULED_TIME, ''hh24:mi:ss''))),''#NULL#'')  
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(BEGINS_ON, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(ENDS_ON, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(BENEFITS_EFFECTIVE_DATE, ''yyyy-mm-dd''))),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(ELIGIBILITY_RULE_SET)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(IS_STARTED)),''#NULL#'') 
                     
                )  
               )::string

';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_EMPLOYMENT_INFO"("HIRE_DATE" DATE, "ORIGINAL_HIRED_DATE" DATE, "PROVINCE_OF_EMPLOYMENT" DATE, "REMUNERATION_TYPE" VARCHAR(16777216), "HOURS_PER_WEEK" NUMBER(38,2), "PAY_PERIOD" VARCHAR(16777216), "WORK_PATTERN" VARCHAR(16777216), "JOB_PERMANENCY" VARCHAR(16777216), "JOB_CATEGORY" VARCHAR(16777216), "LOCATION" VARCHAR(16777216), "IS_MANAGER" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(HIRE_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(HOURS_PER_WEEK))),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(IS_MANAGER)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(LOCATION)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(JOB_CATEGORY)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(JOB_PERMANENCY)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(ORIGINAL_HIRED_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(PAY_PERIOD)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(PROVINCE_OF_EMPLOYMENT)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(REMUNERATION_TYPE)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(WORK_PATTERN)),''#NULL#'') 
                     
                )  
               )::string

';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_EMPLOYMENT_INFO"("HIRE_DATE" DATE, "ORIGINAL_HIRED_DATE" DATE, "PROVINCE_OF_EMPLOYMENT" VARCHAR(16777216), "REMUNERATION_TYPE" VARCHAR(16777216), "HOURS_PER_WEEK" NUMBER(38,2), "PAY_PERIOD" VARCHAR(16777216), "WORK_PATTERN" VARCHAR(16777216), "JOB_PERMANENCY" VARCHAR(16777216), "JOB_CATEGORY" VARCHAR(16777216), "LOCATION" VARCHAR(16777216), "IS_MANAGER" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(HIRE_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(HOURS_PER_WEEK))),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(IS_MANAGER)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(LOCATION)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(JOB_CATEGORY)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(JOB_PERMANENCY)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(ORIGINAL_HIRED_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(PAY_PERIOD)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(PROVINCE_OF_EMPLOYMENT)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(REMUNERATION_TYPE)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(WORK_PATTERN)),''#NULL#'') 
                     
                )  
               )::string

';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_LEAVE_STATUS"("ON_LEAVE" VARCHAR(16777216), "LEAVE_START_DATE" DATE, "LEAVE_END_DATE" DATE, "REASON_CODE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(LEAVE_END_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(LEAVE_START_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(ON_LEAVE)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(REASON_CODE)),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_PERSONAL_INFO"("DATE_OF_BIRTH" DATE, "GENDER" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
                UPPER( 
                    
                    NVL(RTRIM(LTRIM(DATE_OF_BIRTH)),''#NULL#'')  
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(GENDER)),''#NULL#'')
                  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_RETIREMENT_STATUS"("RETIRED" VARCHAR(16777216), "RETIREMENT_DATE" DATE, "EXPECTED" VARCHAR(16777216), "EXPECTED_RETIREMENT_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
                UPPER( 
                   
                    NVL(RTRIM(LTRIM(EXPECTED)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(EXPECTED_RETIREMENT_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                    || ''|'' || 
                     NVL(RTRIM(LTRIM(RETIRED)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(RETIREMENT_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SALARY"("SALARY" NUMBER(38,2), "SALARY_EFFECTIVE_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(SALARY))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(SALARY_EFFECTIVE_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_TERMINATION_STATUS"("TERMINATED" VARCHAR(16777216), "TERMINATION_DATE" DATE, "REASON_CODE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(REASON_CODE)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TERMINATED)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TO_VARCHAR(TERMINATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
               
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_WORK_PERMIT"("TYPE" VARCHAR(16777216), "START_DATE" DATE, "END_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(END_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(START_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(TYPE)),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_CAMPAIGN"("CAMPAIGN_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(CAMPAIGN_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_CUSTOMER"("CUSTOMER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
                   UPPER( 
                         NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'')
                        ) 
                    )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_ORGANIZATION"("ORGANIZATION_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PACKAGE_PRODUCT"("PACKAGE_PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(PACKAGE_PRODUCT_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PREVIOUSPRODUCTCATALOG"("PREVIOUSPRODUCTCATALOG_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(PREVIOUSPRODUCTCATALOG_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCT"("PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(PRODUCT_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCTCATALOG"("PRODUCTCATALOG_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(PRODUCTCATALOG_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_WORKER"("WORKER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(WORKER_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_PACKAGE_PRODUCT_LIST"("PACKAGE_PRODUCT_ID" VARCHAR(16777216), "PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(PACKAGE_PRODUCT_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(PRODUCT_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_SUBSCRIPTION"("WORKER_ID" VARCHAR(16777216), "CUSTOMER_ID" VARCHAR(16777216), "ORGANIZATION_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(WORKER_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'')
           || ''|'' ||
           NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'')
       )::string
';
create or replace schema PLT_MODEL_SHARED_EXPL;

create or replace view VW_ADDRESS_EXPL(
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	POSTAL_CODE_REGION,
	PROVINCE,
	COUNTRY
) as (
SELECT 
CURRENT_DATE as MD_START_DT, --'Start Date of the image/version'
CURRENT_TIMESTAMP as MD_CREATION_DT, -- 'Creation Date Time of the occurrence'
'PLATEFORME\\2020\\09\\03\\CUSTOMER.TXT' as MD_SOURCE, -- 'Represents the source system, file, etc. of the instance',  
DATA:customerId::STRING as CUSTOMER_ID, 
LEFT(DATA:personalInfo:address:postalCode::STRING,3) as POSTAL_CODE_REGION,
DATA:personalInfo:address:province::STRING as PROVINCE,
DATA:personalInfo:address:country::STRING as COUNTRY
FROM PLATEFORME_RECEPTION.CUSTOMER
WHERE DATA:customerId is not null);
create or replace view VW_CUSTOMER_EXPL(
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	ID,
	DATE_OF_BIRTH,
	GENDER,
	PREFERRED_LANGUAGE,
	PREFERRED_COMMUNICATION,
	MARITAL_STATUS,
	IS_SMOKER
) as (
SELECT 
CURRENT_DATE as MD_START_DT, --'Start Date of the image/version'
CURRENT_TIMESTAMP as MD_CREATION_DT, -- 'Creation Date Time of the occurrence'
'PLATEFORME\\2020\\09\\03\\CUSTOMER.TXT' as MD_SOURCE, -- 'Represents the source system, file, etc. of the instance',
DATA:customerId::STRING as ID,  
DATE_TRUNC('month',TO_DATE(DATA:personalInfo:dateOfBirth::STRING)) as DATE_OF_BIRTH,
DATA:personalInfo:gender::STRING as GENDER,
DATA:preferences:language::STRING as PREFERRED_LANGUAGE, 
DATA:preferences:communication::STRING as PREFERRED_COMMUNICATION,
DATA:personalInfo:maritalStatus::STRING as MARITAL_STATUS,
DATA:personalInfo:isSmoker::STRING as IS_SMOKER
FROM PLATEFORME_RECEPTION.CUSTOMER
WHERE DATA:customerId is not null);
create or replace view VW_EMPLOYEE_EXPL(
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	ID,
	CUSTOMER_ID,
	HIRE_DATE,
	PROVINCE_OF_EMPLOYMENT,
	REMUNERATION_TYPE,
	BASE_SALARY,
	HOURS_PER_WEEK,
	PAY_PERIOD,
	WORK_PATTERN,
	JOB_PERMANENCY,
	JOB_CATEGORY,
	LOCATION,
	ORGANIZATION_NAME,
	WORKER_NUMBER,
	WORKER_GROUP
) as (
SELECT  
        CURRENT_DATE as MD_START_DT, --'Start Date of the image/version'
        CURRENT_TIMESTAMP as MD_CREATION_DT, -- 'Creation Date Time of the occurrence'
        'PLATEFORME\\2020\\09\\03\\WORKER.TXT' as MD_SOURCE, -- 'Represents the source system, file, etc. of the instance',
        DATA:workerId::STRING as ID, 
        DATA:customerId::STRING as CUSTOMER_ID,
        TO_DATE(DATA:employmentInfo:hireDate::STRING) as HIRE_DATE,
        DATA:employmentInfo:provinceOfEmployment::STRING as PROVINCE_OF_EMPLOYMENT,
        DATA:employmentInfo:remunerationType::STRING as REMUNERATION_TYPE,
        DATA:employmentInfo:baseSalary::NUMBER(15,2)  as BASE_SALARY,
        DATA:employmentInfo:hoursPerWeek::NUMBER(4,2)  as HOURS_PER_WEEK,
        DATA:employmentInfo:payPeriod::STRING as PAY_PERIOD,
        DATA:employmentInfo:workPattern::STRING as WORK_PATTERN,
        DATA:employmentInfo:jobPermanency::STRING as JOB_PERMANENCY,
        DATA:employmentInfo:jobCategory::STRING as JOB_CATEGORY,
        DATA:employmentInfo:location::STRING as LOCATION,
        DATA:organizationId::STRING as ORGANIZATION_NAME,
        DATA:employmentInfo:workerNumber::STRING as WORKER_NUMBER,
        DATA:employmentInfo:workerGroup::STRING AS WORKER_GROUP
FROM PLATEFORME_RECEPTION.WORKER
WHERE DATA:workerId is not null);
create or replace view VW_PRODUCT_EXPL(
	PRODUCT_ID,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	SKU,
	NAME_EN,
	NAME_FR,
	APPENDIXES,
	AVAILABILITY_START_DATE,
	AVAILABILITY_END_DATE,
	AVAILABLE_FOR,
	BASE_PRICE,
	CATEGORY,
	COVERAGE_TYPE,
	COVERAGE_TYPE_FR,
	DISPLAY_ORDER,
	IS_PACKAGE,
	MIN_PRICE,
	MAX_PRICE,
	NOTES_EN,
	NOTES_FR,
	ORGANIZATION_NAME,
	PACKAGE_CONTENT,
	COVERAGE_TYPE_EN,
	PRODUCT_CATALOG_NAME,
	PROVIDER_ID,
	TAGS,
	CHARACTERISTICS
) as 
SELECT   
        DATA:productId::STRING as product_Id,        
        CURRENT_DATE as MD_START_DT,                                    -- 'Start Date of the image/version'    
        CURRENT_TIMESTAMP as MD_CREATION_DT,                            -- 'Creation Date Time of the occurrence'
        'PLATEFORME\2020\09\03\PRODUCT.TXT' as MD_SOURCE,               -- 'Represents the source system, file, etc. of the instance',        
        DATA:sku::STRING as SKU, 
        DATA:nameEn::STRING as NAME_EN,
        DATA:nameFr::STRING as NAME_FR,
        DATA:appendixes::STRING as appendixes,
        DATA:availabilityStartDate::DATE as availability_start_date,
        DATA:availabilityEndDate::DATE as availability_end_date,  
        DATA:availableFor::STRING as available_for,  
        DATA:basePrice::STRING as base_price,
        DATA:category::STRING as category,
        DATA:coverageType::STRING as coverage_type,  
        DATA:coverageTypeFr::STRING as coverage_type_fr,
        DATA:displayOrder::STRING as display_order,
        DATA:isPackage::STRING as is_package,
        DATA:minPrice::STRING as min_price,
        DATA:maxPrice::STRING as max_price,
        DATA:notesEn::STRING as notes_en,
        DATA:notesFr::STRING as notes_fr,
        DATA:organizationId::STRING as organization_name,
        DATA:packageContent::STRING as package_content,
        DATA:coverageTypeEn::STRING as coverage_type_en,
        DATA:productCatalogId::STRING as product_catalog_name, 
        DATA:providerId::STRING as provider_id,
        DATA:tags::STRING as tags,
        DATA:characteristics::STRING as characteristics
   FROM DB_AC_DEV_STG.PLATEFORME_RECEPTION.PRODUCT;
create or replace view VW_WORKPERMIT_EXPL(
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	WORKER_ID,
	TYPE,
	START_DATE,
	END_DATE
) as (
SELECT  CURRENT_DATE as MD_START_DT, --'Start Date of the image/version'
        CURRENT_TIMESTAMP as MD_CREATION_DT, -- 'Creation Date Time of the occurrence'
        'PLATEFORME\\2020\\09\\03\\WORKER.TXT' as MD_SOURCE, -- 'Represents the source system, file, etc. of the instance',
        DATA:workerId::STRING as WORKER_ID, 
        DATA:employmentInfo:workPermit:type::STRING as TYPE,
        DATA:employmentInfo:workPermit:startDate::STRING as START_DATE,
        DATA:employmentInfo:workPermit:endDate::STRING as END_DATE
FROM PLATEFORME_RECEPTION.WORKER
WHERE DATA:workerId is not null and DATA:employmentInfo:workPermit <> 'null' );
create or replace schema PLT_MODEL_SHOPPING;

create or replace TABLE CAMPAIGN (
	HK_HUB VARCHAR(64) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme date',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT DATE COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	CAMPAIGN_ID VARCHAR(16777216) COMMENT 'Campaign plateform ID',
	TYPE VARCHAR(16777216) COMMENT 'Campaign Type',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Name of the organisation',
	WORKER_GROUP VARCHAR(16777216) COMMENT 'Name of worker group',
	JOB_CATEGORY VARCHAR(16777216) COMMENT 'the name of job category',
	GROUP_TYPE_CODE VARCHAR(16777216) COMMENT 'group type code',
	GROUP_REFERENCES VARCHAR(16777216) COMMENT ' group references',
	SCHEDULED_TIME TIME(7),
	BEGINS_ON TIMESTAMP_NTZ(9) COMMENT 'campaign start date',
	ENDS_ON TIMESTAMP_NTZ(9) COMMENT 'campaign end date',
	BENEFITS_EFFECTIVE_DATE DATE COMMENT 'The date on which benefits will start',
	ELIGIBILITY_RULE_SET VARCHAR(16777216) COMMENT 'rule for eligibility of the benefits',
	IS_STARTED BOOLEAN COMMENT 'campaign is on way or not',
	ROW_SRC VARCHAR(50)
);
create or replace TRANSIENT TABLE ENROLLMENT (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	OPEN_SHOPPING_PERIOD_ID VARCHAR(16777216) COMMENT 'Open Shopping Period Plateform Id',
	HK_HUB_OPEN_SHOPPING_PERIOD VARCHAR(16777216) COMMENT 'HASH of the Open Shopping Period business key',
	HK_HUB_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'HASH of the product catalog business key',
	HK_HUB_PREVIOUS_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'HASH of the Previous product Catalog business key',
	HK_HUB_WORKER VARCHAR(16777216) COMMENT 'HASH of the worker business key',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HASH of the Customer Business key',
	HK_HUB_ORGANIZATION VARCHAR(16777216) COMMENT 'HASH of the organization business key',
	HK_HUB_CAMPAIGN VARCHAR(16777216) COMMENT 'HASH of the campaign business key',
	HK_HUB_LIFE_EVENT VARCHAR(16777216) COMMENT 'HASH of the lifevent business key',
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Product Catalog ID',
	PREVIOUS_PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Previous Product Catalog Id',
	WORKER_ID VARCHAR(16777216) COMMENT 'Open Shopping Period Worker Id',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Open Shopping Period Customer Id',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Open Shopping Period Organization id',
	CAMPAIGN_ID VARCHAR(16777216) COMMENT 'Open Shopping Period Campaign id',
	LIFE_EVENT_ID VARCHAR(16777216) COMMENT 'Open Shopping Period Lifeevent id'
);
create or replace TRANSIENT TABLE OPEN_SHOPPING_PERIOD (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	OPEN_SHOPPING_PERIOD_ID VARCHAR(16777216) COMMENT 'Open Shopping Period Plateform Id',
	REASON VARCHAR(255) COMMENT 'reason why the item was created',
	BEGINSON DATE COMMENT 'begin date of the item',
	ENDSON DATE COMMENT 'end date of the item',
	EFFECTIVE_DATE DATE COMMENT 'Effective date of the item',
	EXPIRATION_DATE DATE COMMENT 'Expiration date of the item',
	STATUS VARCHAR(255) COMMENT 'status of the current item',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence'
);
create or replace TRANSIENT TABLE ORDER_CUSTOMER (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_ORDER VARCHAR(16777216) COMMENT 'HK_HUB Order ID',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HK_HUB product ID',
	ORDER_ID VARCHAR(16777216) COMMENT 'Order plateform ID',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform ID',
	CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'order creation DATE',
	AMOUNT NUMBER(38,0) COMMENT 'Order total amount',
	AMOUNT_AFTER_TAX NUMBER(38,0) COMMENT 'Order total amount including taxes'
);
create or replace TRANSIENT TABLE ORDER_ITEM (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_ORDER VARCHAR(16777216) COMMENT 'HK_HUB Order ID',
	HK_HUB_PRODUCT VARCHAR(16777216) COMMENT 'HK_HUB product ID',
	ORDER_ID VARCHAR(16777216) COMMENT 'Order plateform ID',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product plateform ID',
	QUANTITY NUMBER(38,0) COMMENT 'Selected product quantity ',
	AMOUNT NUMBER(38,0) COMMENT 'Order total amount'
);
create or replace TRANSIENT TABLE ORDER_STATUS (
	HK_HUB VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	ORDER_ID VARCHAR(16777216) COMMENT 'Order plateform ID',
	STATUS VARCHAR(16777216) COMMENT 'Order status',
	STATUS_DATE TIMESTAMP_NTZ(9) COMMENT 'Order status DATE'
);
create or replace TRANSIENT TABLE SHOPPING_REQUEST (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	HK_HUB_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'Product Catalog Key',
	HK_HUB_OPEN_SHOPPING_PERIOD VARCHAR(16777216) COMMENT 'Open shopping period key',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'Customer key',
	HK_HUB_WORKER VARCHAR(16777216) COMMENT 'worker key',
	HK_HUB_SHOPPING_REQUEST VARCHAR(16777216) COMMENT 'shopping request key',
	SHOPPING_REQUEST_ID VARCHAR(16777216) COMMENT 'Shopping Request id',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'platform Customer id',
	CONTEXT VARCHAR(16777216),
	WORKER_ID VARCHAR(16777216) COMMENT 'Platform worker id',
	OPEN_SHOPPING_PERIOD_ID VARCHAR(16777216) COMMENT 'Platform open shopping period id',
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'platform product catalog id',
	STATUS VARCHAR(100) COMMENT 'Shopping request Status',
	SUBMITTEDON DATE
);
create or replace TRANSIENT TABLE SHOPPING_REQUEST_ITEM (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_SHOPPING_REQUEST VARCHAR(16777216),
	HK_HUB_PRODUCT VARCHAR(16777216),
	SHOPPING_REQUEST_ID VARCHAR(16777216) COMMENT 'Shopping Request id',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product id',
	QUANTITY NUMBER(38,0)
);
create or replace view VW_ORDER(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_RESERVED,
	ORDER_ID,
	CREATION_DT,
	AMOUNT,
	AMOUNT_AFTER_TAX
) as 
(


SELECT 
      HK_HUB_ORDER AS HK_HUB, 
      MD_START_DT,
      MD_HASHDIFF,  
       CURRENT_TIMESTAMP AS MD_CREATION_DT,
       MD_SOURCE,
       MD_RESERVED, 
       ORDER_ID, 
       CREATION_DT, 
       AMOUNT,
       AMOUNT_AFTER_TAX
FROM PLT_MODEL_SHOPPING.ORDER_CUSTOMER

  
);
create or replace view VW_SHOPPING_REQUEST(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	SHOPPING_REQUEST_ID,
	STATUS,
	SUBMITTEDON,
	CONTEXT
) as
(
    SELECT
    HK_HUB_SHOPPING_REQUEST AS HK_HUB,
    MD_START_DT,
    MD_HASHDIFF,
    MD_CREATION_DT,
    MD_SOURCE,    
    --MD_RESERVED,
    SHOPPING_REQUEST_ID,    
    STATUS, 
    SUBMITTEDON, 
    CONTEXT
    FROM PLT_MODEL_SHOPPING.SHOPPING_REQUEST
);
create or replace view VW_SHOPPING_REQUEST_ITEM(
	HK_HUB,
	MD_START_DT,
	MD_SOURCE,
	MD_RESERVED,
	PRODUCT_ID
) as
(
       SELECT
        distinct HK_HUB_PRODUCT as HK_HUB,
        MD_START_DT,
        MD_SOURCE,
        MD_RESERVED,
        PRODUCT_ID
       FROM PLT_MODEL_SHOPPING.SHOPPING_REQUEST_ITEM
);
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_OPEN_SHOPPING_PERIOD"("REASON" VARCHAR(16777216), "BEGINSON" DATE, "ENDSON" DATE, "EFFECTIVE_DATE" DATE, "EXPIRATION_DATE" DATE, "STATUS" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
SHA1(
	NVL(RTRIM(LTRIM(REASON)),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(TO_VARCHAR(BEGINSON,''yyyy-mm-dd hh24:mi:ss.ff3'' ))),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(TO_VARCHAR(ENDSON,''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(TO_VARCHAR(EFFECTIVE_DATE,''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(TO_VARCHAR(EXPIRATION_DATE,''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'') 
	|| ''|'' || 
	NVL(RTRIM(LTRIM(STATUS)),''#NULL#'') 
)::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER"("CREATION_DATE" DATE, "AMOUNT" NUMBER(14,2), "AMOUNT_AFTER_TAX" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
					|| ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(AMOUNT))),''#NULL#'') 
                    || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(AMOUNT_AFTER_TAX))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER"("CREATION_DATE" DATE, "TOTAL_AMOUNT" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
					|| ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(TOTAL_AMOUNT))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER"("CREATION_DATE" TIMESTAMP_NTZ(9), "TOTAL_AMOUNT" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
					|| ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(TOTAL_AMOUNT))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER_ITEM"("QUANTITY" NUMBER(38,0))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(QUANTITY))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER_ITEM"("QUANTITY" NUMBER(38,0), "AMOUNT" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(QUANTITY))),''#NULL#'')  
                    || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(AMOUNT))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER_STATUS"("STATUS" VARCHAR(16777216), "STATUS_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
					NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                    || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(STATUS_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_ORDER_STATUS"("STATUS" VARCHAR(16777216), "STATUS_DATE" TIMESTAMP_NTZ(9))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
					NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                    || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(STATUS_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_ITEM"("QUANTITY" NUMBER(38,0))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(QUANTITY))),''#NULL#'')                       
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_ITEM"("QUANTITY" NUMBER(38,0), "AMOUNT" NUMBER(14,2))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(QUANTITY))),''#NULL#'')  
                     || ''|'' ||  
					NVL(RTRIM(LTRIM(TO_VARCHAR(AMOUNT))),''#NULL#'') 
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_REQUEST"("CREATION_DATE" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_REQUEST"("CREATION_DATE" DATE, "STATUS" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_REQUEST"("CREATION_DATE" TIMESTAMP_NTZ(9), "STATUS" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(CREATION_DATE, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_REQUEST"("STATUS" VARCHAR(16777216), "SUBMITTEDON" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER(                     
                    NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(TO_VARCHAR(SUBMITTEDON, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_SHOPPING_REQUEST"("STATUS" VARCHAR(16777216), "SUBMITTEDON" DATE, "CONTEXT" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER(                     
                    NVL(RTRIM(LTRIM(STATUS)),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(TO_VARCHAR(SUBMITTEDON, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')
                    || ''|'' ||  
                    NVL(RTRIM(LTRIM(CONTEXT)),''#NULL#'')
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_CUSTOMER"("CUSTOMER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_LIFE_EVENT"("LIFE_EVENT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(LIFE_EVENT_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_OPEN_SHOPPING_PERIOD"("OPEN_SHOPPING_PERIOD_ID" NUMBER(38,0))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(TO_VARCHAR(OPEN_SHOPPING_PERIOD_ID))),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_OPEN_SHOPPING_PERIOD_I"("OPEN_SHOPPING_PERIOD_ID" NUMBER(38,0))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(TO_VARCHAR(OPEN_SHOPPING_PERIOD_ID))),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_OPEN_SHOPPING_PERIOD_ID"("OPEN_SHOPPING_PERIOD_ID" NUMBER(38,0))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(TO_VARCHAR(OPEN_SHOPPING_PERIOD_ID))),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_ORDER"("ORDER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(ORDER_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PREVIOUS_PRODUCT_CATALOG_ID"("PREVIOUS_PRODUCT_CATALOG_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(PREVIOUS_PRODUCT_CATALOG_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCT_CATALOG"("PRODUCT_CATALOG_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_PRODUCT_CATALOG_ID"("PRODUCT_CATALOG_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'') 
               )::string 
               
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_SHOPPING_REQUEST"("SHOPPING_REQUEST_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(SHOPPING_REQUEST_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_WORKER"("WORKER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SHA1( 
           NVL(RTRIM(LTRIM(WORKER_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_ENROLLED"("OPEN_SHOPPING_PERIOD_ID" NUMBER(38,0), "PRODUCTCATALOG_ID" VARCHAR(16777216), "PREVIOUSPRODUCTCATALOG_ID" VARCHAR(16777216), "WORKER_ID" VARCHAR(1677216), "CUSTOMER_ID" VARCHAR(1677216), "ORGANIZATION_ID" VARCHAR(16777216), "CAMPAIGN_ID" VARCHAR(1677216), "LIFE_EVENT_ID" VARCHAR(1677216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
          NVL(RTRIM(LTRIM(TO_VARCHAR(OPEN_SHOPPING_PERIOD_ID))),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(PRODUCTCATALOG_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(PREVIOUSPRODUCTCATALOG_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(WORKER_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(CAMPAIGN_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(LIFE_EVENT_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_ENROLLED"("OPEN_SHOPPING_PERIOD_ID" VARCHAR(16777216), "PRODUCT_CATALOG_ID" VARCHAR(16777216), "PREVIOUS_PRODUCT_CATALOG_ID" VARCHAR(16777216), "WORKER_ID" VARCHAR(1677216), "CUSTOMER_ID" VARCHAR(1677216), "ORGANIZATION_ID" VARCHAR(16777216), "CAMPAIGN_ID" VARCHAR(1677216), "LIFEEVENT_ID" VARCHAR(1677216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
          NVL(RTRIM(LTRIM(OPEN_SHOPPING_PERIOD_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(PREVIOUS_PRODUCT_CATALOG_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(WORKER_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(CAMPAIGN_ID)),''#NULL#'') 
          || ''|'' || 
          NVL(RTRIM(LTRIM(LIFEEVENT_ID)),''#NULL#'') 
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_ORDER_CUSTOMER"("ORDER_ID" VARCHAR(16777216), "CUSTOMER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(ORDER_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_ORDER_ITEM"("ORDER_ID" VARCHAR(16777216), "SELECTED_PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(ORDER_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(SELECTED_PRODUCT_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_SHOPPING_CUSTOMER"("SHOPPING_REQUEST_ID" VARCHAR(16777216), "CUSTOMER_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(SHOPPING_REQUEST_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_SHOPPING_ITEM"("SHOPPING_REQUEST_ID" VARCHAR(16777216), "SELECTED_PRODUCT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(SELECTED_PRODUCT_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(SHOPPING_REQUEST_ID)),''#NULL#'')
       )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_SHOPPING_REQUESTS"("CUSTOMER_ID" VARCHAR(1677216), "WORKER_ID" VARCHAR(1677216), "OPEN_SHOPPING_PERIOD_ID" NUMBER(38,0), "PRODUCT_CATALOG_ID" VARCHAR(1677216))
RETURNS VARCHAR(1677216)
LANGUAGE SQL
AS '
SELECT 
 SHA1( 
NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
||''|''||
NVL(RTRIM(LTRIM(WORKER_ID)),''#NULL#'') 
||''|''||
NVL(RTRIM(LTRIM(TO_VARCHAR(OPEN_SHOPPING_PERIOD_ID))),''#NULL#'')    
|| ''|'' || 
NVL(RTRIM(LTRIM(PRODUCT_CATALOG_ID)),''#NULL#'')  
)::string     
';
create or replace schema PLT_MODEL_SHOPPING_EXPL;

create or replace view VW_SHOPPING_CART_ITEMS_EXPL(
	SHOPPING_REQUEST_ID,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	PRODUCT_ID,
	SHOPPINGCARTITEMID,
	QUANTITY,
	AMOUNT,
	OPTIONS
) as (  
SELECT DATA:shoppingRequestId::INT  AS shopping_request_id,
       CURRENT_DATE as MD_START_DT, --'Start Date of the image/version'
       CURRENT_TIMESTAMP as MD_CREATION_DT, -- 'Creation Date Time of the occurrence'
      'PLATEFORME\\2020\\09\\03\\PRODUCT.TXT' as MD_SOURCE, -- 'Represents the source system, file, etc. of the instance',
       DATA:productId::STRING                    AS product_id,  
       DATA:shoppingCartItemId::STRING           AS shoppingCartItemId,
       DATA:quantity::STRING                     AS quantity,
       DATA:amount::STRING                       AS amount,
       DATA:options::STRING                      AS options
  FROM DB_AC_DEV_STG.PLATEFORME_RECEPTION.SHOPPING_CART_ITEMS     
 );
create or replace view VW_SHOPPING_REQUEST_EXPL(
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	CUSTOMER_ID,
	OPEN_SHOPPING_PERIOD_ID,
	PRODUCT_CATALOG_ID,
	SHOPPING_REQUEST_ID,
	WORKER_ID
) as (
SELECT 
      CURRENT_DATE as MD_START_DT, --'Start Date of the image/version'
      CURRENT_TIMESTAMP as MD_CREATION_DT, -- 'Creation Date Time of the occurrence'
      'PLATEFORME\\2020\\09\\03\\PRODUCT.TXT' as MD_SOURCE, -- 'Represents the source system, file, etc. of the instance',
      sr.DATA:customerId::STRING              AS customer_id,    
      sr.DATA:openShoppingPeriodId::INT       AS open_shopping_period_id, 
      sr.DATA:productCatalogId::STRING        AS product_catalog_id,        
      sr.DATA:shoppingRequestId::INT          AS shopping_request_id,
      e.ID                                    AS worker_id
FROM DB_AC_DEV_STG.PLATEFORME_RECEPTION.SHOPPING_REQUEST sr
LEFT JOIN  DB_AC_DEV_STG.PLT_MODEL_SHARED_EXPL.VW_EMPLOYEE_EXPL e
ON e.CUSTOMER_ID = sr.DATA:customerId
WHERE DATA:customerId is not null
);
create or replace schema PLT_MODEL_SUBSCRIPTION;

create or replace TRANSIENT TABLE CUSTOMER_PERSONAL_INTEREST (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash of the business keys',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Event plateforme DATE',
	MD_HASHDIFF VARCHAR(16777216) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Row creation date and time',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Source JSON file full name',
	MD_RESERVED BOOLEAN DEFAULT FALSE COMMENT 'Reserve the row by an ETL Process',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HASH of the customer business key',
	HK_HUB_PERSONAL_INTEREST VARCHAR(16777216) COMMENT 'HASH of the personal interest business key',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform ID',
	INTEREST_ID VARCHAR(16777216) COMMENT 'Interest plateform ID '
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADSTG_PLT_EVENTS_CST_PIU_TO_MDL_SCRTN_CST_PER_INT"("ENV" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_PRE_QUERY STRING;
INS_COPY_QUERY STRING;
INS_QUERY STRING;
BEGIN
INS_PRE_QUERY := ''delete from PLT_EVENTS_CUSTOMER.PERSONAL_INTEREST_UPDATED'';
INS_COPY_QUERY := ''
COPY INTO PLT_EVENTS_CUSTOMER.PERSONAL_INTEREST_UPDATED(CUSTOMER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT)
 FROM ( SELECT
 t.$1:data.customerId,
 t.$1:data.timestamp,
 current_timestamp(),
 metadata$filename ,
 t.$1
 FROM @DATALAKE.RAW/CUSTOMER/ t)
 PATTERN=''''.*customer.personalInterestUpdated.*json''''
 FILE_FORMAT = ( TYPE = JSON) FORCE = false
              '';
INS_QUERY := ''
INSERT INTO DB_AC_''||ENV||''_STG.PLT_MODEL_SUBSCRIPTION.CUSTOMER_PERSONAL_INTEREST
(HK_LINK,
MD_START_DT,
MD_HASHDIFF,
MD_CREATION_DT,
MD_SOURCE,
MD_RESERVED,
HK_HUB_CUSTOMER,
HK_HUB_PERSONAL_INTEREST,
CUSTOMER_ID,
INTEREST_ID)
SELECT
src.HK_LINK
,src.MD_START_DT
,src.MD_HASHDIFF
,CURRENT_TIMESTAMP
,src.MD_SOURCE
,0
,src.HK_HUB_CUSTOMER_ID
,src.HK_HUB_INTEREST_ID
,src.CUSTOMER_ID
,src.INTEREST_ID
FROM DB_AC_''||ENV||''_STG.PLT_EVENTS_CUSTOMER.VW_PIU_CUSTOMER_PERSONAL_INTEREST src
              '';
EXECUTE IMMEDIATE :INS_PRE_QUERY;
EXECUTE IMMEDIATE :INS_COPY_QUERY;
EXECUTE IMMEDIATE :INS_QUERY;
END
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_CUSTOMER_PERSONAL_INTEREST"("MD_START_DT" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(MD_START_DT, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_CUSTOMER_PERSONAL_INTEREST"("MD_START_DT" TIMESTAMP_NTZ(9))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(TO_VARCHAR(MD_START_DT, ''yyyy-mm-dd hh24:mi:ss.ff3''))),''#NULL#'')  
                ) 
               )::string
';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_LINK_CUSTOMER_PERSONAL_INTEREST"("CUSTOMER_ID" VARCHAR(16777216), "INTEREST_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS '
SELECT 
       SHA1( 
           NVL(RTRIM(LTRIM(CUSTOMER_ID)),''#NULL#'') 
           || ''|'' ||  
           NVL(RTRIM(LTRIM(INTEREST_ID)),''#NULL#'')
       )::string
';
create or replace schema PUBLIC;

create or replace TABLE TEST (
	ID NUMBER(38,0),
	NAME VARCHAR(20)
);
CREATE OR REPLACE PROCEDURE "SP_CONV_LoadSTG_PSA_To_PLT_EVENTS_WORKER_TC"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '


var pre_sql_command = "delete from DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED";

var sql_command = "insert into DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED (WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT) \\n \\
 (SELECT WORKER_ID,MD_CREATION_DT,MD_SOURCE,MD_START_DT FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED \\n \\
WHERE  WORKER_ID= ''''always filter me'''')";

var post_sql_command = "COPY INTO DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER.TERMINATION_CANCELLED(WORKER_ID,MD_START_DT,MD_CREATION_DT,MD_SOURCE, CONTENT) \\n \\
 FROM ( SELECT  \\n \\
 t.$1:data.workerId,   \\n \\
 t.$1:data.timestamp,   \\n \\
 current_timestamp(),   \\n \\
 metadata$filename ,    \\n \\
 t.$1             \\n \\
 FROM @DATALAKE.RAW/WORKER/ t)  \\n \\
 PATTERN=''''.*worker.terminationCancelled.*json''''  \\n \\
 FILE_FORMAT = ( TYPE = JSON) FORCE = false";  

try {
	
    var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();

    var post_sql_statement = snowflake.createStatement({sqlText: post_sql_command });
    var result_scan1 = post_sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "USP_TRUNCATE_MODEL_TABLES"()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

    try {
    
      var sqlCommand = "CALL USP_SCHEMA_TRUNCATE(''PLT_MODEL_SHARED'');";
      var stmt0 = snowflake.createStatement( {sqlText: sqlCommand} );    
      var res = stmt0.execute(); 
      
      sqlCommand = "CALL USP_SCHEMA_TRUNCATE(''PLT_MODEL_PRODUCT'');";
      stmt0 = snowflake.createStatement( {sqlText: sqlCommand} );   
      res = stmt0.execute(); 
      
      sqlCommand = "CALL USP_SCHEMA_TRUNCATE(''PLT_MODEL_SHOPPING'');";
      stmt0 = snowflake.createStatement( {sqlText: sqlCommand} );   
      res = stmt0.execute(); 
      
      return "Les tables MODELS ont été tronquées avec succès";

     } catch (error) {
    
        return "Erreur: " + error.message;
     
    };
';
create or replace schema STEWARDSHIP;

create or replace TABLE ORGANIZATION_STRUCTURE (
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'source du fichier',
	ENTITY_ID VARCHAR(16777216) COMMENT 'id entity',
	ENTITY_CODE VARCHAR(16777216) COMMENT 'code of entity',
	ENTITY_NAME_FR VARCHAR(16777216) COMMENT 'description in french',
	ENTITY_NAME_EN VARCHAR(16777216) COMMENT 'description in english',
	ENTITY_TYPE VARCHAR(16777216) COMMENT 'type of entity',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'id of oragnization',
	PARENT_ID VARCHAR(16777216) COMMENT 'parent id of entity'
);
create or replace view VW_ORGANIZATION_STRUCTURE(
	HK_HUB,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	ENTITY_ID,
	ENTITY_CODE,
	ENTITY_NAME_FR,
	ENTITY_NAME_EN,
	ENTITY_TYPE,
	ORGANIZATION_ID,
	PARENT_ID
) as 
    (
        SELECT
        DB_AC_DEV_STG.STEWARDSHIP.UF_HASH_HK_HUB_ORGANIZATION_STRUCTURE(ENTITY_ID) AS HK_HUB,
        DB_AC_DEV_STG.STEWARDSHIP.UF_HASHDIFF_TYPE2_ORGANIZATION_STRUCTURE (ENTITY_CODE,ENTITY_NAME_FR,ENTITY_NAME_EN,ENTITY_TYPE,ORGANIZATION_ID,PARENT_ID) AS MD_HASHDIFF,
		CURRENT_TIMESTAMP AS MD_CREATION_DT,
		MD_SOURCE,
        ENTITY_ID,
        ENTITY_CODE,
        ENTITY_NAME_FR ,
        ENTITY_NAME_EN ,
        ENTITY_TYPE ,
        ORGANIZATION_ID ,
        PARENT_ID 
        FROM DB_AC_DEV_STG.STEWARDSHIP.ORGANIZATION_STRUCTURE);
CREATE OR REPLACE FUNCTION "UF_HASHDIFF_TYPE2_ORGANIZATION_STRUCTURE"("ENTITY_CODE" VARCHAR(16777216), "ENTITY_NAME_FR" VARCHAR(16777216), "ENTITY_NAME_EN" VARCHAR(16777216), "ENTITY_TYPE" VARCHAR(16777216), "ORGANIZATION_ID" VARCHAR(16777216), "PARENT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                UPPER( 
                    NVL(RTRIM(LTRIM(ENTITY_CODE)),''#NULL#'') 
                    || ''|'' || 
                    NVL(RTRIM(LTRIM(ENTITY_NAME_FR)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(ENTITY_NAME_EN)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(ENTITY_TYPE)),''#NULL#'')
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(ORGANIZATION_ID)),''#NULL#'') 
                    || ''|'' ||
                    NVL(RTRIM(LTRIM(PARENT_ID)),''#NULL#'') 
                     
                )  
               )::string

';
CREATE OR REPLACE FUNCTION "UF_HASH_HK_HUB_ORGANIZATION_STRUCTURE"("ENTITY_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
AS ' 
SHA1( 
                   NVL(RTRIM(LTRIM(ENTITY_ID)),''#NULL#'') 
               )::string 
               
';
create or replace schema SYPHAX_ERC_DEMOSTATS;

create or replace TRANSIENT TABLE DEMOSTATS2018_18_GEO_P1 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYASQKM NUMBER(19,6),
	ECYALSQKM NUMBER(19,6),
	ECYBASPOP NUMBER(38,0),
	ECYBASHHD NUMBER(38,0),
	ECYBASHPOP NUMBER(38,0),
	ECYBAS12P NUMBER(38,0),
	ECYBAS15P NUMBER(38,0),
	ECYBAS18P NUMBER(38,0),
	ECYBAS19P NUMBER(38,0),
	ECYBAS12HP NUMBER(38,0),
	ECYBAS15HP NUMBER(38,0),
	ECYBAS18HP NUMBER(38,0),
	ECYBAS19HP NUMBER(38,0),
	ECYBASTNGH NUMBER(38,0),
	ECYBASADUH NUMBER(38,0),
	ECYBASCF NUMBER(38,0),
	ECYBASCFH NUMBER(38,0),
	ECYBASKID NUMBER(38,0),
	ECYBASLF NUMBER(38,0)
);
create or replace TRANSIENT TABLE DEMOSTATS2018_18_GEO_P2 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYPTAPOP NUMBER(38,0),
	ECYPTA_0_4 NUMBER(38,0),
	ECYPTA_5_9 NUMBER(38,0),
	ECYPTA1014 NUMBER(38,0),
	ECYPTA1519 NUMBER(38,0),
	ECYPTA2024 NUMBER(38,0),
	ECYPTA2529 NUMBER(38,0),
	ECYPTA3034 NUMBER(38,0),
	ECYPTA3539 NUMBER(38,0),
	ECYPTA4044 NUMBER(38,0),
	ECYPTA4549 NUMBER(38,0),
	ECYPTA5054 NUMBER(38,0),
	ECYPTA5559 NUMBER(38,0),
	ECYPTA6064 NUMBER(38,0),
	ECYPTA6569 NUMBER(38,0),
	ECYPTA7074 NUMBER(38,0),
	ECYPTA7579 NUMBER(38,0),
	ECYPTA8084 NUMBER(38,0),
	ECYPTA85P NUMBER(38,0),
	ECYPTAAVG NUMBER(12,2),
	ECYPTAMED NUMBER(12,2),
	ECYPMAPOP NUMBER(38,0),
	ECYPMA_0_4 NUMBER(38,0),
	ECYPMA_5_9 NUMBER(38,0),
	ECYPMA1014 NUMBER(38,0),
	ECYPMA1519 NUMBER(38,0),
	ECYPMA2024 NUMBER(38,0),
	ECYPMA2529 NUMBER(38,0),
	ECYPMA3034 NUMBER(38,0),
	ECYPMA3539 NUMBER(38,0),
	ECYPMA4044 NUMBER(38,0),
	ECYPMA4549 NUMBER(38,0),
	ECYPMA5054 NUMBER(38,0),
	ECYPMA5559 NUMBER(38,0),
	ECYPMA6064 NUMBER(38,0),
	ECYPMA6569 NUMBER(38,0),
	ECYPMA7074 NUMBER(38,0),
	ECYPMA7579 NUMBER(38,0),
	ECYPMA8084 NUMBER(38,0),
	ECYPMA85P NUMBER(38,0),
	ECYPMAAVG NUMBER(12,2),
	ECYPMAMED NUMBER(12,2),
	ECYPFAPOP NUMBER(38,0),
	ECYPFA_0_4 NUMBER(38,0),
	ECYPFA_5_9 NUMBER(38,0),
	ECYPFA1014 NUMBER(38,0),
	ECYPFA1519 NUMBER(38,0),
	ECYPFA2024 NUMBER(38,0),
	ECYPFA2529 NUMBER(38,0),
	ECYPFA3034 NUMBER(38,0),
	ECYPFA3539 NUMBER(38,0),
	ECYPFA4044 NUMBER(38,0),
	ECYPFA4549 NUMBER(38,0),
	ECYPFA5054 NUMBER(38,0),
	ECYPFA5559 NUMBER(38,0),
	ECYPFA6064 NUMBER(38,0),
	ECYPFA6569 NUMBER(38,0),
	ECYPFA7074 NUMBER(38,0),
	ECYPFA7579 NUMBER(38,0),
	ECYPFA8084 NUMBER(38,0),
	ECYPFA85P NUMBER(38,0),
	ECYPFAAVG NUMBER(12,2),
	ECYPFAMED NUMBER(12,2),
	ECYHTAHPOP NUMBER(38,0),
	ECYHTA_0_4 NUMBER(38,0),
	ECYHTA_5_9 NUMBER(38,0),
	ECYHTA1014 NUMBER(38,0),
	ECYHTA1519 NUMBER(38,0),
	ECYHTA2024 NUMBER(38,0),
	ECYHTA2529 NUMBER(38,0),
	ECYHTA3034 NUMBER(38,0),
	ECYHTA3539 NUMBER(38,0),
	ECYHTA4044 NUMBER(38,0),
	ECYHTA4549 NUMBER(38,0),
	ECYHTA5054 NUMBER(38,0),
	ECYHTA5559 NUMBER(38,0),
	ECYHTA6064 NUMBER(38,0),
	ECYHTA6569 NUMBER(38,0),
	ECYHTA7074 NUMBER(38,0),
	ECYHTA7579 NUMBER(38,0),
	ECYHTA8084 NUMBER(38,0),
	ECYHTA85P NUMBER(38,0),
	ECYHTAAVG NUMBER(12,2),
	ECYHTAMED NUMBER(12,2),
	ECYHMAHPOP NUMBER(38,0),
	ECYHMA_0_4 NUMBER(38,0),
	ECYHMA_5_9 NUMBER(38,0),
	ECYHMA1014 NUMBER(38,0),
	ECYHMA1519 NUMBER(38,0),
	ECYHMA2024 NUMBER(38,0),
	ECYHMA2529 NUMBER(38,0),
	ECYHMA3034 NUMBER(38,0),
	ECYHMA3539 NUMBER(38,0),
	ECYHMA4044 NUMBER(38,0),
	ECYHMA4549 NUMBER(38,0),
	ECYHMA5054 NUMBER(38,0),
	ECYHMA5559 NUMBER(38,0),
	ECYHMA6064 NUMBER(38,0),
	ECYHMA6569 NUMBER(38,0),
	ECYHMA7074 NUMBER(38,0),
	ECYHMA7579 NUMBER(38,0),
	ECYHMA8084 NUMBER(38,0),
	ECYHMA85P NUMBER(38,0),
	ECYHMAAVG NUMBER(12,2),
	ECYHMAMED NUMBER(12,2),
	ECYHFAHPOP NUMBER(38,0),
	ECYHFA_0_4 NUMBER(38,0),
	ECYHFA_5_9 NUMBER(38,0),
	ECYHFA1014 NUMBER(38,0),
	ECYHFA1519 NUMBER(38,0),
	ECYHFA2024 NUMBER(38,0),
	ECYHFA2529 NUMBER(38,0),
	ECYHFA3034 NUMBER(38,0),
	ECYHFA3539 NUMBER(38,0),
	ECYHFA4044 NUMBER(38,0),
	ECYHFA4549 NUMBER(38,0),
	ECYHFA5054 NUMBER(38,0),
	ECYHFA5559 NUMBER(38,0),
	ECYHFA6064 NUMBER(38,0),
	ECYHFA6569 NUMBER(38,0),
	ECYHFA7074 NUMBER(38,0),
	ECYHFA7579 NUMBER(38,0),
	ECYHFA8084 NUMBER(38,0),
	ECYHFA85P NUMBER(38,0),
	ECYHFAAVG NUMBER(12,2),
	ECYHFAMED NUMBER(12,2),
	ECYMTNHHD NUMBER(38,0),
	ECYMTN1524 NUMBER(38,0),
	ECYMTN2534 NUMBER(38,0),
	ECYMTN3544 NUMBER(38,0),
	ECYMTN4554 NUMBER(38,0),
	ECYMTN5564 NUMBER(38,0),
	ECYMTN6574 NUMBER(38,0),
	ECYMTN75P NUMBER(38,0),
	ECYMTNAVG NUMBER(12,2),
	ECYMTNMED NUMBER(12,2),
	ECYHSZHHD NUMBER(38,0),
	ECYHSZ1PER NUMBER(38,0),
	ECYHSZ2PER NUMBER(38,0),
	ECYHSZ3PER NUMBER(38,0),
	ECYHSZ4PER NUMBER(38,0),
	ECYHSZ5PER NUMBER(38,0),
	ECYHSZTPER NUMBER(38,0),
	ECYHSZAVG NUMBER(12,2),
	ECYHTYHHD NUMBER(38,0),
	ECYHTYFHT NUMBER(38,0),
	ECYHTY1FH NUMBER(38,0),
	ECYHTYMFH NUMBER(38,0),
	ECYHTYNFH NUMBER(38,0),
	ECYHTY1PH NUMBER(38,0),
	ECYHTYN65A NUMBER(38,0),
	ECYHTY2PPH NUMBER(38,0),
	ECYMARP15 NUMBER(38,0),
	ECYMARMCL NUMBER(38,0),
	ECYMARM NUMBER(38,0),
	ECYMARCL NUMBER(38,0),
	ECYMARNMCL NUMBER(38,0),
	ECYMARSING NUMBER(38,0),
	ECYMARSEP NUMBER(38,0),
	ECYMARDIV NUMBER(38,0),
	ECYMARWID NUMBER(38,0),
	ECYCFSCF NUMBER(38,0),
	ECYCFSC NUMBER(38,0),
	ECYCFSCNC NUMBER(38,0),
	ECYCFSCWC NUMBER(38,0),
	ECYCFSC1C NUMBER(38,0),
	ECYCFSC2C NUMBER(38,0),
	ECYCFSC3C NUMBER(38,0),
	ECYCFSM NUMBER(38,0),
	ECYCFSMNC NUMBER(38,0),
	ECYCFSMWC NUMBER(38,0),
	ECYCFSM1C NUMBER(38,0),
	ECYCFSM2C NUMBER(38,0),
	ECYCFSM3C NUMBER(38,0),
	ECYCFSCL NUMBER(38,0),
	ECYCFSCLNC NUMBER(38,0),
	ECYCFSCLWC NUMBER(38,0),
	ECYCFSCL1C NUMBER(38,0),
	ECYCFSCL2C NUMBER(38,0),
	ECYCFSCL3C NUMBER(38,0),
	ECYCFSLP NUMBER(38,0),
	ECYCFSLP1C NUMBER(38,0),
	ECYCFSLP2C NUMBER(38,0),
	ECYCFSLP3C NUMBER(38,0),
	ECYCFSFP NUMBER(38,0),
	ECYCFSFP1C NUMBER(38,0),
	ECYCFSFP2C NUMBER(38,0),
	ECYCFSFP3C NUMBER(38,0),
	ECYCFSMP NUMBER(38,0),
	ECYCFSMP1C NUMBER(38,0),
	ECYCFSMP2C NUMBER(38,0),
	ECYCFSMP3C NUMBER(38,0),
	ECYCFSNFP NUMBER(38,0),
	ECYHFSCF NUMBER(38,0),
	ECYHFSC NUMBER(38,0),
	ECYHFSCNC NUMBER(38,0),
	ECYHFSCWC NUMBER(38,0),
	ECYHFSC1C NUMBER(38,0),
	ECYHFSC2C NUMBER(38,0),
	ECYHFSC3C NUMBER(38,0),
	ECYHFSM NUMBER(38,0),
	ECYHFSMNC NUMBER(38,0),
	ECYHFSMWC NUMBER(38,0),
	ECYHFSM1C NUMBER(38,0),
	ECYHFSM2C NUMBER(38,0),
	ECYHFSM3C NUMBER(38,0),
	ECYHFSCL NUMBER(38,0),
	ECYHFSCLNC NUMBER(38,0),
	ECYHFSCLWC NUMBER(38,0),
	ECYHFSCL1C NUMBER(38,0),
	ECYHFSCL2C NUMBER(38,0),
	ECYHFSCL3C NUMBER(38,0),
	ECYHFSLP NUMBER(38,0),
	ECYHFSLP1C NUMBER(38,0),
	ECYHFSLP2C NUMBER(38,0),
	ECYHFSLP3C NUMBER(38,0),
	ECYHFSFP NUMBER(38,0),
	ECYHFSFP1C NUMBER(38,0),
	ECYHFSFP2C NUMBER(38,0),
	ECYHFSFP3C NUMBER(38,0),
	ECYHFSMP NUMBER(38,0),
	ECYHFSMP1C NUMBER(38,0),
	ECYHFSMP2C NUMBER(38,0),
	ECYHFSMP3C NUMBER(38,0),
	ECYCHAKIDS NUMBER(38,0),
	ECYCHA_0_4 NUMBER(38,0),
	ECYCHA_5_9 NUMBER(38,0),
	ECYCHA1014 NUMBER(38,0),
	ECYCHA1519 NUMBER(38,0),
	ECYCHA2024 NUMBER(38,0),
	ECYCHA25P NUMBER(38,0),
	ECYCHACFCH NUMBER(12,2),
	ECYCHAFHCH NUMBER(12,2),
	ECYCHAHHCH NUMBER(12,2)
);
create or replace TRANSIENT TABLE DEMOSTATS2018_18_GEO_P3 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYMOBHPOP NUMBER(38,0),
	ECYMOBNMOV NUMBER(38,0),
	ECYMOBMOV NUMBER(38,0),
	ECYTENHHD NUMBER(38,0),
	ECYTENOWN NUMBER(38,0),
	ECYTENRENT NUMBER(38,0),
	ECYTENBAND NUMBER(38,0),
	ECYPOCHHD NUMBER(38,0),
	ECYPOCP60 NUMBER(38,0),
	ECYPOC6180 NUMBER(38,0),
	ECYPOC8190 NUMBER(38,0),
	ECYPOC9100 NUMBER(38,0),
	ECYPOC0105 NUMBER(38,0),
	ECYPOC0610 NUMBER(38,0),
	ECYPOC1116 NUMBER(38,0),
	ECYPOC17P NUMBER(38,0),
	ECYSTYHHD NUMBER(38,0),
	ECYSTYHOUS NUMBER(38,0),
	ECYSTYSING NUMBER(38,0),
	ECYSTYSEMI NUMBER(38,0),
	ECYSTYROW NUMBER(38,0),
	ECYSTYAPT NUMBER(38,0),
	ECYSTYAP5P NUMBER(38,0),
	ECYSTYAPU5 NUMBER(38,0),
	ECYSTYDUPL NUMBER(38,0),
	ECYSTYOTHR NUMBER(38,0),
	ECYSTYOATT NUMBER(38,0),
	ECYSTYMOVE NUMBER(38,0),
	ECYCDOHHD NUMBER(38,0),
	ECYCDOIC NUMBER(38,0),
	ECYCDOICAP NUMBER(38,0),
	ECYCDOAPOW NUMBER(38,0),
	ECYCDOAPRE NUMBER(38,0),
	ECYCDOICOT NUMBER(38,0),
	ECYCDOOTOW NUMBER(38,0),
	ECYCDOOTRE NUMBER(38,0),
	ECYCDONIC NUMBER(38,0),
	ECYCDOOW NUMBER(38,0),
	ECYCDOOWHO NUMBER(38,0),
	ECYCDOOWOT NUMBER(38,0),
	ECYCDORE NUMBER(38,0),
	ECYCDOREHO NUMBER(38,0),
	ECYCDOREOT NUMBER(38,0),
	ECYCDOBAND NUMBER(38,0),
	ECYHRIHHD NUMBER(38,0),
	ECYHRI_010 NUMBER(38,0),
	ECYHRI1020 NUMBER(38,0),
	ECYHRI2030 NUMBER(38,0),
	ECYHRI3040 NUMBER(38,0),
	ECYHRI4050 NUMBER(38,0),
	ECYHRI5060 NUMBER(38,0),
	ECYHRI6070 NUMBER(38,0),
	ECYHRI7080 NUMBER(38,0),
	ECYHRI8090 NUMBER(38,0),
	ECYHRIX100 NUMBER(38,0),
	ECYHRI100P NUMBER(38,0),
	ECYHRIX125 NUMBER(38,0),
	ECYHRIX150 NUMBER(38,0),
	ECYHRIX175 NUMBER(38,0),
	ECYHRIX200 NUMBER(38,0),
	ECYHRIX250 NUMBER(38,0),
	ECYHRI250P NUMBER(38,0),
	ECYHRIAVG NUMBER(19,2),
	ECYHRIMED NUMBER(19,2),
	ECYHRIAGG FLOAT,
	ECYHNIHHD NUMBER(38,0),
	ECYHNI_020 NUMBER(38,0),
	ECYHNI2040 NUMBER(38,0),
	ECYHNI4060 NUMBER(38,0),
	ECYHNI6080 NUMBER(38,0),
	ECYHNIX100 NUMBER(38,0),
	ECYHNI100P NUMBER(38,0),
	ECYHNIX125 NUMBER(38,0),
	ECYHNIX150 NUMBER(38,0),
	ECYHNIX200 NUMBER(38,0),
	ECYHNI200P NUMBER(38,0),
	ECYHNIAVG NUMBER(19,2),
	ECYHNIMED NUMBER(19,2),
	ECYHNIAGG FLOAT,
	ECYPNIHP15 NUMBER(38,0),
	ECYPNININ NUMBER(38,0),
	ECYPNIWIN NUMBER(38,0),
	ECYPNIAVG NUMBER(19,2),
	ECYEDUHP15 NUMBER(38,0),
	ECYEDUNCDD NUMBER(38,0),
	ECYEDUHSCE NUMBER(38,0),
	ECYEDUATCD NUMBER(38,0),
	ECYEDUCOLL NUMBER(38,0),
	ECYEDUUDBB NUMBER(38,0),
	ECYEDUUD NUMBER(38,0),
	ECYEDUUDBD NUMBER(38,0),
	ECYEDUUDBP NUMBER(38,0),
	ECYEDAHPWK NUMBER(38,0),
	ECYEDANCDD NUMBER(38,0),
	ECYEDAHSCE NUMBER(38,0),
	ECYEDAATCD NUMBER(38,0),
	ECYEDACOLL NUMBER(38,0),
	ECYEDAUDBB NUMBER(38,0),
	ECYEDAUD NUMBER(38,0),
	ECYEDAUDBD NUMBER(38,0),
	ECYEDAUDBP NUMBER(38,0),
	ECYACTHPL NUMBER(38,0),
	ECYACTINLF NUMBER(38,0),
	ECYACTEMP NUMBER(38,0),
	ECYACTUEMP NUMBER(38,0),
	ECYACTNOLF NUMBER(38,0),
	ECYACTPR NUMBER(12,2),
	ECYACTER NUMBER(12,2),
	ECYACTUR NUMBER(12,2),
	ECYOCCHPL NUMBER(38,0),
	ECYOCCINLF NUMBER(38,0),
	ECYOCCNA NUMBER(38,0),
	ECYOCCALL NUMBER(38,0),
	ECYOCCMGMT NUMBER(38,0),
	ECYOCCBFAD NUMBER(38,0),
	ECYOCCNSCI NUMBER(38,0),
	ECYOCCHLTH NUMBER(38,0),
	ECYOCCSSER NUMBER(38,0),
	ECYOCCARTS NUMBER(38,0),
	ECYOCCSERV NUMBER(38,0),
	ECYOCCTRAD NUMBER(38,0),
	ECYOCCPRIM NUMBER(38,0),
	ECYOCCSCND NUMBER(38,0),
	ECYINDHPL NUMBER(38,0),
	ECYINDINLF NUMBER(38,0),
	ECYINDNA NUMBER(38,0),
	ECYINDALL NUMBER(38,0),
	ECYINDAGRI NUMBER(38,0),
	ECYINDMINE NUMBER(38,0),
	ECYINDUTIL NUMBER(38,0),
	ECYINDCSTR NUMBER(38,0),
	ECYINDMANU NUMBER(38,0),
	ECYINDWHOL NUMBER(38,0),
	ECYINDRETL NUMBER(38,0),
	ECYINDTRAN NUMBER(38,0),
	ECYINDINFO NUMBER(38,0),
	ECYINDFINA NUMBER(38,0),
	ECYINDREAL NUMBER(38,0),
	ECYINDPROF NUMBER(38,0),
	ECYINDMGMT NUMBER(38,0),
	ECYINDADMN NUMBER(38,0),
	ECYINDEDUC NUMBER(38,0),
	ECYINDHLTH NUMBER(38,0),
	ECYINDARTS NUMBER(38,0),
	ECYINDACCO NUMBER(38,0),
	ECYINDOSER NUMBER(38,0),
	ECYINDPUBL NUMBER(38,0),
	ECYPOWHPL NUMBER(38,0),
	ECYPOWINLF NUMBER(38,0),
	ECYPOWEMP NUMBER(38,0),
	ECYPOWHOME NUMBER(38,0),
	ECYPOWOSCA NUMBER(38,0),
	ECYPOWNFIX NUMBER(38,0),
	ECYPOWUSUL NUMBER(38,0),
	ECYTRAHPL NUMBER(38,0),
	ECYTRAALL NUMBER(38,0),
	ECYTRADRIV NUMBER(38,0),
	ECYTRAPSGR NUMBER(38,0),
	ECYTRAPUBL NUMBER(38,0),
	ECYTRAWALK NUMBER(38,0),
	ECYTRABIKE NUMBER(38,0),
	ECYTRAOTHE NUMBER(38,0)
);
create or replace TRANSIENT TABLE RECEPTION__RAW_DEMOSTATS_P1 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYASQKM VARCHAR(16777216),
	ECYALSQKM VARCHAR(16777216),
	ECYBASPOP VARCHAR(16777216),
	ECYBASHHD VARCHAR(16777216),
	ECYBASHPOP VARCHAR(16777216),
	ECYBAS12P VARCHAR(16777216),
	ECYBAS15P VARCHAR(16777216),
	ECYBAS18P VARCHAR(16777216),
	ECYBAS19P VARCHAR(16777216),
	ECYBAS12HP VARCHAR(16777216),
	ECYBAS15HP VARCHAR(16777216),
	ECYBAS18HP VARCHAR(16777216),
	ECYBAS19HP VARCHAR(16777216),
	ECYBASTNGH VARCHAR(16777216),
	ECYBASADUH VARCHAR(16777216),
	ECYBASCF VARCHAR(16777216),
	ECYBASCFH VARCHAR(16777216),
	ECYBASKID VARCHAR(16777216),
	ECYBASLF VARCHAR(16777216)
);
create or replace TRANSIENT TABLE RECEPTION__RAW_DEMOSTATS_P2 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYPTAPOP VARCHAR(16777216),
	ECYPTA_0_4 VARCHAR(16777216),
	ECYPTA_5_9 VARCHAR(16777216),
	ECYPTA1014 VARCHAR(16777216),
	ECYPTA1519 VARCHAR(16777216),
	ECYPTA2024 VARCHAR(16777216),
	ECYPTA2529 VARCHAR(16777216),
	ECYPTA3034 VARCHAR(16777216),
	ECYPTA3539 VARCHAR(16777216),
	ECYPTA4044 VARCHAR(16777216),
	ECYPTA4549 VARCHAR(16777216),
	ECYPTA5054 VARCHAR(16777216),
	ECYPTA5559 VARCHAR(16777216),
	ECYPTA6064 VARCHAR(16777216),
	ECYPTA6569 VARCHAR(16777216),
	ECYPTA7074 VARCHAR(16777216),
	ECYPTA7579 VARCHAR(16777216),
	ECYPTA8084 VARCHAR(16777216),
	ECYPTA85P VARCHAR(16777216),
	ECYPTAAVG VARCHAR(16777216),
	ECYPTAMED VARCHAR(16777216),
	ECYPMAPOP VARCHAR(16777216),
	ECYPMA_0_4 VARCHAR(16777216),
	ECYPMA_5_9 VARCHAR(16777216),
	ECYPMA1014 VARCHAR(16777216),
	ECYPMA1519 VARCHAR(16777216),
	ECYPMA2024 VARCHAR(16777216),
	ECYPMA2529 VARCHAR(16777216),
	ECYPMA3034 VARCHAR(16777216),
	ECYPMA3539 VARCHAR(16777216),
	ECYPMA4044 VARCHAR(16777216),
	ECYPMA4549 VARCHAR(16777216),
	ECYPMA5054 VARCHAR(16777216),
	ECYPMA5559 VARCHAR(16777216),
	ECYPMA6064 VARCHAR(16777216),
	ECYPMA6569 VARCHAR(16777216),
	ECYPMA7074 VARCHAR(16777216),
	ECYPMA7579 VARCHAR(16777216),
	ECYPMA8084 VARCHAR(16777216),
	ECYPMA85P VARCHAR(16777216),
	ECYPMAAVG VARCHAR(16777216),
	ECYPMAMED VARCHAR(16777216),
	ECYPFAPOP VARCHAR(16777216),
	ECYPFA_0_4 VARCHAR(16777216),
	ECYPFA_5_9 VARCHAR(16777216),
	ECYPFA1014 VARCHAR(16777216),
	ECYPFA1519 VARCHAR(16777216),
	ECYPFA2024 VARCHAR(16777216),
	ECYPFA2529 VARCHAR(16777216),
	ECYPFA3034 VARCHAR(16777216),
	ECYPFA3539 VARCHAR(16777216),
	ECYPFA4044 VARCHAR(16777216),
	ECYPFA4549 VARCHAR(16777216),
	ECYPFA5054 VARCHAR(16777216),
	ECYPFA5559 VARCHAR(16777216),
	ECYPFA6064 VARCHAR(16777216),
	ECYPFA6569 VARCHAR(16777216),
	ECYPFA7074 VARCHAR(16777216),
	ECYPFA7579 VARCHAR(16777216),
	ECYPFA8084 VARCHAR(16777216),
	ECYPFA85P VARCHAR(16777216),
	ECYPFAAVG VARCHAR(16777216),
	ECYPFAMED VARCHAR(16777216),
	ECYHTAHPOP VARCHAR(16777216),
	ECYHTA_0_4 VARCHAR(16777216),
	ECYHTA_5_9 VARCHAR(16777216),
	ECYHTA1014 VARCHAR(16777216),
	ECYHTA1519 VARCHAR(16777216),
	ECYHTA2024 VARCHAR(16777216),
	ECYHTA2529 VARCHAR(16777216),
	ECYHTA3034 VARCHAR(16777216),
	ECYHTA3539 VARCHAR(16777216),
	ECYHTA4044 VARCHAR(16777216),
	ECYHTA4549 VARCHAR(16777216),
	ECYHTA5054 VARCHAR(16777216),
	ECYHTA5559 VARCHAR(16777216),
	ECYHTA6064 VARCHAR(16777216),
	ECYHTA6569 VARCHAR(16777216),
	ECYHTA7074 VARCHAR(16777216),
	ECYHTA7579 VARCHAR(16777216),
	ECYHTA8084 VARCHAR(16777216),
	ECYHTA85P VARCHAR(16777216),
	ECYHTAAVG VARCHAR(16777216),
	ECYHTAMED VARCHAR(16777216),
	ECYHMAHPOP VARCHAR(16777216),
	ECYHMA_0_4 VARCHAR(16777216),
	ECYHMA_5_9 VARCHAR(16777216),
	ECYHMA1014 VARCHAR(16777216),
	ECYHMA1519 VARCHAR(16777216),
	ECYHMA2024 VARCHAR(16777216),
	ECYHMA2529 VARCHAR(16777216),
	ECYHMA3034 VARCHAR(16777216),
	ECYHMA3539 VARCHAR(16777216),
	ECYHMA4044 VARCHAR(16777216),
	ECYHMA4549 VARCHAR(16777216),
	ECYHMA5054 VARCHAR(16777216),
	ECYHMA5559 VARCHAR(16777216),
	ECYHMA6064 VARCHAR(16777216),
	ECYHMA6569 VARCHAR(16777216),
	ECYHMA7074 VARCHAR(16777216),
	ECYHMA7579 VARCHAR(16777216),
	ECYHMA8084 VARCHAR(16777216),
	ECYHMA85P VARCHAR(16777216),
	ECYHMAAVG VARCHAR(16777216),
	ECYHMAMED VARCHAR(16777216),
	ECYHFAHPOP VARCHAR(16777216),
	ECYHFA_0_4 VARCHAR(16777216),
	ECYHFA_5_9 VARCHAR(16777216),
	ECYHFA1014 VARCHAR(16777216),
	ECYHFA1519 VARCHAR(16777216),
	ECYHFA2024 VARCHAR(16777216),
	ECYHFA2529 VARCHAR(16777216),
	ECYHFA3034 VARCHAR(16777216),
	ECYHFA3539 VARCHAR(16777216),
	ECYHFA4044 VARCHAR(16777216),
	ECYHFA4549 VARCHAR(16777216),
	ECYHFA5054 VARCHAR(16777216),
	ECYHFA5559 VARCHAR(16777216),
	ECYHFA6064 VARCHAR(16777216),
	ECYHFA6569 VARCHAR(16777216),
	ECYHFA7074 VARCHAR(16777216),
	ECYHFA7579 VARCHAR(16777216),
	ECYHFA8084 VARCHAR(16777216),
	ECYHFA85P VARCHAR(16777216),
	ECYHFAAVG VARCHAR(16777216),
	ECYHFAMED VARCHAR(16777216),
	ECYMTNHHD VARCHAR(16777216),
	ECYMTN1524 VARCHAR(16777216),
	ECYMTN2534 VARCHAR(16777216),
	ECYMTN3544 VARCHAR(16777216),
	ECYMTN4554 VARCHAR(16777216),
	ECYMTN5564 VARCHAR(16777216),
	ECYMTN6574 VARCHAR(16777216),
	ECYMTN75P VARCHAR(16777216),
	ECYMTNAVG VARCHAR(16777216),
	ECYMTNMED VARCHAR(16777216),
	ECYHSZHHD VARCHAR(16777216),
	ECYHSZ1PER VARCHAR(16777216),
	ECYHSZ2PER VARCHAR(16777216),
	ECYHSZ3PER VARCHAR(16777216),
	ECYHSZ4PER VARCHAR(16777216),
	ECYHSZ5PER VARCHAR(16777216),
	ECYHSZTPER VARCHAR(16777216),
	ECYHSZAVG VARCHAR(16777216),
	ECYHTYHHD VARCHAR(16777216),
	ECYHTYFHT VARCHAR(16777216),
	ECYHTY1FH VARCHAR(16777216),
	ECYHTYMFH VARCHAR(16777216),
	ECYHTYNFH VARCHAR(16777216),
	ECYHTY1PH VARCHAR(16777216),
	ECYHTYN65A VARCHAR(16777216),
	ECYHTY2PPH VARCHAR(16777216),
	ECYMARP15 VARCHAR(16777216),
	ECYMARMCL VARCHAR(16777216),
	ECYMARM VARCHAR(16777216),
	ECYMARCL VARCHAR(16777216),
	ECYMARNMCL VARCHAR(16777216),
	ECYMARSING VARCHAR(16777216),
	ECYMARSEP VARCHAR(16777216),
	ECYMARDIV VARCHAR(16777216),
	ECYMARWID VARCHAR(16777216),
	ECYCFSCF VARCHAR(16777216),
	ECYCFSC VARCHAR(16777216),
	ECYCFSCNC VARCHAR(16777216),
	ECYCFSCWC VARCHAR(16777216),
	ECYCFSC1C VARCHAR(16777216),
	ECYCFSC2C VARCHAR(16777216),
	ECYCFSC3C VARCHAR(16777216),
	ECYCFSM VARCHAR(16777216),
	ECYCFSMNC VARCHAR(16777216),
	ECYCFSMWC VARCHAR(16777216),
	ECYCFSM1C VARCHAR(16777216),
	ECYCFSM2C VARCHAR(16777216),
	ECYCFSM3C VARCHAR(16777216),
	ECYCFSCL VARCHAR(16777216),
	ECYCFSCLNC VARCHAR(16777216),
	ECYCFSCLWC VARCHAR(16777216),
	ECYCFSCL1C VARCHAR(16777216),
	ECYCFSCL2C VARCHAR(16777216),
	ECYCFSCL3C VARCHAR(16777216),
	ECYCFSLP VARCHAR(16777216),
	ECYCFSLP1C VARCHAR(16777216),
	ECYCFSLP2C VARCHAR(16777216),
	ECYCFSLP3C VARCHAR(16777216),
	ECYCFSFP VARCHAR(16777216),
	ECYCFSFP1C VARCHAR(16777216),
	ECYCFSFP2C VARCHAR(16777216),
	ECYCFSFP3C VARCHAR(16777216),
	ECYCFSMP VARCHAR(16777216),
	ECYCFSMP1C VARCHAR(16777216),
	ECYCFSMP2C VARCHAR(16777216),
	ECYCFSMP3C VARCHAR(16777216),
	ECYCFSNFP VARCHAR(16777216),
	ECYHFSCF VARCHAR(16777216),
	ECYHFSC VARCHAR(16777216),
	ECYHFSCNC VARCHAR(16777216),
	ECYHFSCWC VARCHAR(16777216),
	ECYHFSC1C VARCHAR(16777216),
	ECYHFSC2C VARCHAR(16777216),
	ECYHFSC3C VARCHAR(16777216),
	ECYHFSM VARCHAR(16777216),
	ECYHFSMNC VARCHAR(16777216),
	ECYHFSMWC VARCHAR(16777216),
	ECYHFSM1C VARCHAR(16777216),
	ECYHFSM2C VARCHAR(16777216),
	ECYHFSM3C VARCHAR(16777216),
	ECYHFSCL VARCHAR(16777216),
	ECYHFSCLNC VARCHAR(16777216),
	ECYHFSCLWC VARCHAR(16777216),
	ECYHFSCL1C VARCHAR(16777216),
	ECYHFSCL2C VARCHAR(16777216),
	ECYHFSCL3C VARCHAR(16777216),
	ECYHFSLP VARCHAR(16777216),
	ECYHFSLP1C VARCHAR(16777216),
	ECYHFSLP2C VARCHAR(16777216),
	ECYHFSLP3C VARCHAR(16777216),
	ECYHFSFP VARCHAR(16777216),
	ECYHFSFP1C VARCHAR(16777216),
	ECYHFSFP2C VARCHAR(16777216),
	ECYHFSFP3C VARCHAR(16777216),
	ECYHFSMP VARCHAR(16777216),
	ECYHFSMP1C VARCHAR(16777216),
	ECYHFSMP2C VARCHAR(16777216),
	ECYHFSMP3C VARCHAR(16777216),
	ECYCHAKIDS VARCHAR(16777216),
	ECYCHA_0_4 VARCHAR(16777216),
	ECYCHA_5_9 VARCHAR(16777216),
	ECYCHA1014 VARCHAR(16777216),
	ECYCHA1519 VARCHAR(16777216),
	ECYCHA2024 VARCHAR(16777216),
	ECYCHA25P VARCHAR(16777216),
	ECYCHACFCH VARCHAR(16777216),
	ECYCHAFHCH VARCHAR(16777216),
	ECYCHAHHCH VARCHAR(16777216)
);
create or replace TRANSIENT TABLE RECEPTION__RAW_DEMOSTATS_P3 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYMOBHPOP VARCHAR(16777216),
	ECYMOBNMOV VARCHAR(16777216),
	ECYMOBMOV VARCHAR(16777216),
	ECYTENHHD VARCHAR(16777216),
	ECYTENOWN VARCHAR(16777216),
	ECYTENRENT VARCHAR(16777216),
	ECYTENBAND VARCHAR(16777216),
	ECYPOCHHD VARCHAR(16777216),
	ECYPOCP60 VARCHAR(16777216),
	ECYPOC6180 VARCHAR(16777216),
	ECYPOC8190 VARCHAR(16777216),
	ECYPOC9100 VARCHAR(16777216),
	ECYPOC0105 VARCHAR(16777216),
	ECYPOC0610 VARCHAR(16777216),
	ECYPOC1116 VARCHAR(16777216),
	ECYPOC17P VARCHAR(16777216),
	ECYSTYHHD VARCHAR(16777216),
	ECYSTYHOUS VARCHAR(16777216),
	ECYSTYSING VARCHAR(16777216),
	ECYSTYSEMI VARCHAR(16777216),
	ECYSTYROW VARCHAR(16777216),
	ECYSTYAPT VARCHAR(16777216),
	ECYSTYAP5P VARCHAR(16777216),
	ECYSTYAPU5 VARCHAR(16777216),
	ECYSTYDUPL VARCHAR(16777216),
	ECYSTYOTHR VARCHAR(16777216),
	ECYSTYOATT VARCHAR(16777216),
	ECYSTYMOVE VARCHAR(16777216),
	ECYCDOHHD VARCHAR(16777216),
	ECYCDOIC VARCHAR(16777216),
	ECYCDOICAP VARCHAR(16777216),
	ECYCDOAPOW VARCHAR(16777216),
	ECYCDOAPRE VARCHAR(16777216),
	ECYCDOICOT VARCHAR(16777216),
	ECYCDOOTOW VARCHAR(16777216),
	ECYCDOOTRE VARCHAR(16777216),
	ECYCDONIC VARCHAR(16777216),
	ECYCDOOW VARCHAR(16777216),
	ECYCDOOWHO VARCHAR(16777216),
	ECYCDOOWOT VARCHAR(16777216),
	ECYCDORE VARCHAR(16777216),
	ECYCDOREHO VARCHAR(16777216),
	ECYCDOREOT VARCHAR(16777216),
	ECYCDOBAND VARCHAR(16777216),
	ECYHRIHHD VARCHAR(16777216),
	ECYHRI_010 VARCHAR(16777216),
	ECYHRI1020 VARCHAR(16777216),
	ECYHRI2030 VARCHAR(16777216),
	ECYHRI3040 VARCHAR(16777216),
	ECYHRI4050 VARCHAR(16777216),
	ECYHRI5060 VARCHAR(16777216),
	ECYHRI6070 VARCHAR(16777216),
	ECYHRI7080 VARCHAR(16777216),
	ECYHRI8090 VARCHAR(16777216),
	ECYHRIX100 VARCHAR(16777216),
	ECYHRI100P VARCHAR(16777216),
	ECYHRIX125 VARCHAR(16777216),
	ECYHRIX150 VARCHAR(16777216),
	ECYHRIX175 VARCHAR(16777216),
	ECYHRIX200 VARCHAR(16777216),
	ECYHRIX250 VARCHAR(16777216),
	ECYHRI250P VARCHAR(16777216),
	ECYHRIAVG VARCHAR(16777216),
	ECYHRIMED VARCHAR(16777216),
	ECYHRIAGG VARCHAR(16777216),
	ECYHNIHHD VARCHAR(16777216),
	ECYHNI_020 VARCHAR(16777216),
	ECYHNI2040 VARCHAR(16777216),
	ECYHNI4060 VARCHAR(16777216),
	ECYHNI6080 VARCHAR(16777216),
	ECYHNIX100 VARCHAR(16777216),
	ECYHNI100P VARCHAR(16777216),
	ECYHNIX125 VARCHAR(16777216),
	ECYHNIX150 VARCHAR(16777216),
	ECYHNIX200 VARCHAR(16777216),
	ECYHNI200P VARCHAR(16777216),
	ECYHNIAVG VARCHAR(16777216),
	ECYHNIMED VARCHAR(16777216),
	ECYHNIAGG VARCHAR(16777216),
	ECYPNIHP15 VARCHAR(16777216),
	ECYPNININ VARCHAR(16777216),
	ECYPNIWIN VARCHAR(16777216),
	ECYPNIAVG VARCHAR(16777216),
	ECYEDUHP15 VARCHAR(16777216),
	ECYEDUNCDD VARCHAR(16777216),
	ECYEDUHSCE VARCHAR(16777216),
	ECYEDUATCD VARCHAR(16777216),
	ECYEDUCOLL VARCHAR(16777216),
	ECYEDUUDBB VARCHAR(16777216),
	ECYEDUUD VARCHAR(16777216),
	ECYEDUUDBD VARCHAR(16777216),
	ECYEDUUDBP VARCHAR(16777216),
	ECYEDAHPWK VARCHAR(16777216),
	ECYEDANCDD VARCHAR(16777216),
	ECYEDAHSCE VARCHAR(16777216),
	ECYEDAATCD VARCHAR(16777216),
	ECYEDACOLL VARCHAR(16777216),
	ECYEDAUDBB VARCHAR(16777216),
	ECYEDAUD VARCHAR(16777216),
	ECYEDAUDBD VARCHAR(16777216),
	ECYEDAUDBP VARCHAR(16777216),
	ECYACTHPL VARCHAR(16777216),
	ECYACTINLF VARCHAR(16777216),
	ECYACTEMP VARCHAR(16777216),
	ECYACTUEMP VARCHAR(16777216),
	ECYACTNOLF VARCHAR(16777216),
	ECYACTPR VARCHAR(16777216),
	ECYACTER VARCHAR(16777216),
	ECYACTUR VARCHAR(16777216),
	ECYOCCHPL VARCHAR(16777216),
	ECYOCCINLF VARCHAR(16777216),
	ECYOCCNA VARCHAR(16777216),
	ECYOCCALL VARCHAR(16777216),
	ECYOCCMGMT VARCHAR(16777216),
	ECYOCCBFAD VARCHAR(16777216),
	ECYOCCNSCI VARCHAR(16777216),
	ECYOCCHLTH VARCHAR(16777216),
	ECYOCCSSER VARCHAR(16777216),
	ECYOCCARTS VARCHAR(16777216),
	ECYOCCSERV VARCHAR(16777216),
	ECYOCCTRAD VARCHAR(16777216),
	ECYOCCPRIM VARCHAR(16777216),
	ECYOCCSCND VARCHAR(16777216),
	ECYINDHPL VARCHAR(16777216),
	ECYINDINLF VARCHAR(16777216),
	ECYINDNA VARCHAR(16777216),
	ECYINDALL VARCHAR(16777216),
	ECYINDAGRI VARCHAR(16777216),
	ECYINDMINE VARCHAR(16777216),
	ECYINDUTIL VARCHAR(16777216),
	ECYINDCSTR VARCHAR(16777216),
	ECYINDMANU VARCHAR(16777216),
	ECYINDWHOL VARCHAR(16777216),
	ECYINDRETL VARCHAR(16777216),
	ECYINDTRAN VARCHAR(16777216),
	ECYINDINFO VARCHAR(16777216),
	ECYINDFINA VARCHAR(16777216),
	ECYINDREAL VARCHAR(16777216),
	ECYINDPROF VARCHAR(16777216),
	ECYINDMGMT VARCHAR(16777216),
	ECYINDADMN VARCHAR(16777216),
	ECYINDEDUC VARCHAR(16777216),
	ECYINDHLTH VARCHAR(16777216),
	ECYINDARTS VARCHAR(16777216),
	ECYINDACCO VARCHAR(16777216),
	ECYINDOSER VARCHAR(16777216),
	ECYINDPUBL VARCHAR(16777216),
	ECYPOWHPL VARCHAR(16777216),
	ECYPOWINLF VARCHAR(16777216),
	ECYPOWEMP VARCHAR(16777216),
	ECYPOWHOME VARCHAR(16777216),
	ECYPOWOSCA VARCHAR(16777216),
	ECYPOWNFIX VARCHAR(16777216),
	ECYPOWUSUL VARCHAR(16777216),
	ECYTRAHPL VARCHAR(16777216),
	ECYTRAALL VARCHAR(16777216),
	ECYTRADRIV VARCHAR(16777216),
	ECYTRAPSGR VARCHAR(16777216),
	ECYTRAPUBL VARCHAR(16777216),
	ECYTRAWALK VARCHAR(16777216),
	ECYTRABIKE VARCHAR(16777216),
	ECYTRAOTHE VARCHAR(16777216)
);
create or replace schema SYPHAX_ERC_MORTALITY;

create or replace TRANSIENT TABLE E00_ATTRIBUTSPERTINENTSDEMOSTATS (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	TOTALAREA NUMBER(19,6),
	TOTALLANDAREA NUMBER(19,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(12,2),
	MED_AGE_CP NUMBER(12,2),
	AVG_AGEMALE_CP NUMBER(12,2),
	MED_AGEMALE_CP NUMBER(12,2),
	AVG_AGEFEM_CP NUMBER(12,2),
	MED_AGEFEM_CP NUMBER(12,2),
	AVG_NB_PRIVATEHOUSE NUMBER(12,2),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(12,2),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	AVG_INCOME NUMBER(19,2),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(12,2),
	UNEMPLOYMENT_RATE NUMBER(12,2),
	PROP_MANAGEMENT FLOAT,
	PROP_FINANCE FLOAT,
	PROP_SCIENCE FLOAT,
	PROP_HEALTH FLOAT,
	PROP_EDUCATION FLOAT,
	PROP_ART FLOAT,
	PROP_SERVICE FLOAT,
	PROP_TRADES FLOAT,
	PROP_PRIMARY_INDUS FLOAT,
	PROP_MANUFACTURE FLOAT
);
create or replace TRANSIENT TABLE E30_DATATEST (
	TYPEINDIVIDU VARCHAR(16777216),
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	SOMMERENTEIA_IAP FLOAT,
	RENTE_INDIVIDU FLOAT,
	SURVIVANTE VARCHAR(16777216),
	CODE_POSTAL VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	INDEX_CONSTANT VARCHAR(16777216),
	TYPE_DE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216)
);
create or replace TRANSIENT TABLE E30_DATATEST_EXTRACTED (
	TYPEINDIVIDU VARCHAR(16777216),
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	SOMMERENTEIA_IAP FLOAT,
	RENTE_INDIVIDU FLOAT,
	SURVIVANTE VARCHAR(16777216),
	CODE_POSTAL VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	INDEX_CONSTANT VARCHAR(16777216),
	TYPE_DE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216)
);
create or replace TRANSIENT TABLE E31_DATATEST (
	TYPEINDIVIDU VARCHAR(16777216),
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(9,0),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	SOMMERENTEIA_IAP FLOAT,
	AGE NUMBER(18,6),
	RENTE_INDIVIDU FLOAT,
	SURVIVANTE NUMBER(18,5),
	CODE_POSTAL VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	INDEX_CONSTANT VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT
);
create or replace TRANSIENT TABLE E40_DATATEST (
	TYPEINDIVIDU VARCHAR(16777216),
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	SOMMERENTEIA_IAP FLOAT,
	AGE NUMBER(18,6),
	RENTE_INDIVIDU FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	CODE_POSTAL VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216),
	MILIEURURAL VARCHAR(16777216),
	DENSITY NUMBER(36,20),
	TOTALAREA NUMBER(19,6),
	TOTALLANDAREA NUMBER(19,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(12,2),
	MED_AGE_CP NUMBER(12,2),
	AVG_AGEMALE_CP NUMBER(12,2),
	MED_AGEMALE_CP NUMBER(12,2),
	AVG_AGEFEM_CP NUMBER(12,2),
	MED_AGEFEM_CP NUMBER(12,2),
	AVG_NB_PRIVATEHOUSE NUMBER(12,2),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(12,2),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	AVG_INCOME NUMBER(19,2),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(12,2),
	UNEMPLOYMENT_RATE NUMBER(12,2)
);
create or replace TRANSIENT TABLE E50_CNA_DATATEST_TEST_DASHBOARD_ETL (
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATE_CALCUL_AGE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	MONTANTRENTE FLOAT,
	TYPE_COL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MONTANTRENTEIA_IAP_VIAG FLOAT,
	MONTANTRENTEIA_IAP_CONJ FLOAT,
	MONTANTRENTEIA_IAP_TOTAL FLOAT,
	MONTANTRENTEINDIVIDU_VIAG FLOAT,
	MONTANTRENTEINDIVIDU_CONJ FLOAT,
	MONTANTRENTEINDIVIDU_TOTAL FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	PSEUDO_ACTUAL_IBNR_LIM FLOAT,
	MILIEURURAL VARCHAR(6),
	DENSITY NUMBER(38,20),
	TOTALAREA NUMBER(38,6),
	TOTALLANDAREA NUMBER(38,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(38,6),
	MED_AGE_CP NUMBER(38,6),
	AVG_AGEMALE_CP NUMBER(38,6),
	MED_AGEMALE_CP NUMBER(38,6),
	AVG_AGEFEM_CP NUMBER(38,6),
	MED_AGEFEM_CP NUMBER(38,6),
	AVG_NB_PRIVATEHOUSE NUMBER(38,6),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(38,6),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(38,6),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(38,6),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(38,6),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(38,6),
	AVG_INCOME NUMBER(38,6),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(38,6),
	UNEMPLOYMENT_RATE NUMBER(38,6),
	QX_INDUSTRIE NUMBER(38,6),
	FORMERENTE VARCHAR(16777216),
	CATEGORIETARIF VARCHAR(25),
	AGEACHAT NUMBER(38,0),
	AGEATTEINT FLOAT
);
create or replace TRANSIENT TABLE E50_CNA_DATATEST_TEST_DASHBOARD_ETL_RAW (
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE VARCHAR(16777216),
	DATE_CALCUL_AGE VARCHAR(16777216),
	AGEARRONDI VARCHAR(16777216),
	MONTANTRENTE VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MONTANTRENTEIA_IAP_VIAG VARCHAR(16777216),
	MONTANTRENTEIA_IAP_CONJ VARCHAR(16777216),
	MONTANTRENTEIA_IAP_TOTAL VARCHAR(16777216),
	MONTANTRENTEINDIVIDU_VIAG VARCHAR(16777216),
	MONTANTRENTEINDIVIDU_CONJ VARCHAR(16777216),
	MONTANTRENTEINDIVIDU_TOTAL VARCHAR(16777216),
	SURVIVANTE VARCHAR(16777216),
	PSEUDO_ACTUAL VARCHAR(16777216),
	PSEUDO_ACTUAL_IBNR VARCHAR(16777216),
	PSEUDO_ACTUAL_IBNR_LIM VARCHAR(16777216),
	MILIEURURAL VARCHAR(16777216),
	DENSITY VARCHAR(16777216),
	TOTALAREA VARCHAR(16777216),
	TOTALLANDAREA VARCHAR(16777216),
	TOTALPOPULATION VARCHAR(16777216),
	NB_INLABOURFORCE VARCHAR(16777216),
	PROP_INLABOURFORCE VARCHAR(16777216),
	AVG_AGE_CP VARCHAR(16777216),
	MED_AGE_CP VARCHAR(16777216),
	AVG_AGEMALE_CP VARCHAR(16777216),
	MED_AGEMALE_CP VARCHAR(16777216),
	AVG_AGEFEM_CP VARCHAR(16777216),
	MED_AGEFEM_CP VARCHAR(16777216),
	AVG_NB_PRIVATEHOUSE VARCHAR(16777216),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE VARCHAR(16777216),
	NB_IN_COUPLE VARCHAR(16777216),
	PROP_IN_COUPLE VARCHAR(16777216),
	PROP_MARRIED VARCHAR(16777216),
	PROP_COMMONLAW VARCHAR(16777216),
	NB_WIDOWED VARCHAR(16777216),
	PROP_WIDOWED VARCHAR(16777216),
	AVG_CHILDREN_PER_HOUSEHOULD VARCHAR(16777216),
	NON_MOVERS VARCHAR(16777216),
	MOVERS VARCHAR(16777216),
	OWNED VARCHAR(16777216),
	RENTED VARCHAR(16777216),
	BAND_HOUSING VARCHAR(16777216),
	AVG_HOUSEHOLD_INCOME_2015 VARCHAR(16777216),
	MED_HOUSEHOLD_INCOME_2015 VARCHAR(16777216),
	AVG_HOUSEHOLD_INCOME_CURR VARCHAR(16777216),
	MED_HOUSEHOLD_INCOME_CURR VARCHAR(16777216),
	AVG_INCOME VARCHAR(16777216),
	PROP_OVER_15_NO_DIPLOMA VARCHAR(16777216),
	PROP_OVER_15_HIGH_SCHOOL VARCHAR(16777216),
	PROP_OVER_15_APPRENTICESHIP VARCHAR(16777216),
	PROP_OVER_15_CEGEP VARCHAR(16777216),
	PROP_OVER_15_BELOW_BACH VARCHAR(16777216),
	PROP_OVER_15_UNIVERSITY VARCHAR(16777216),
	PROP_25_64_NO_DIPLOMA VARCHAR(16777216),
	PROP_25_64_HIGH_SCHOOL VARCHAR(16777216),
	PROP_25_64_APPRENTICESHIP VARCHAR(16777216),
	PROP_25_64_CEGEP VARCHAR(16777216),
	PROP_25_64_BELOW_BACH VARCHAR(16777216),
	PROP_25_64_UNIVERSITY VARCHAR(16777216),
	EMPLOYMENT_RATE VARCHAR(16777216),
	UNEMPLOYMENT_RATE VARCHAR(16777216),
	QX_INDUSTRIE VARCHAR(16777216),
	FORMERENTE VARCHAR(16777216),
	CATEGORIETARIF VARCHAR(16777216),
	AGEACHAT VARCHAR(16777216),
	AGEATTEINT VARCHAR(16777216)
);
create or replace TRANSIENT TABLE E50_DATATEST (
	ANNEEETUDE VARCHAR(16777216),
	INDEX VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATE_CALCUL_AGE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	MONTANTRENTE FLOAT,
	TYPE_COL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MONTANTRENTEIA_IAP_VIAG FLOAT,
	MONTANTRENTEIA_IAP_CONJ FLOAT,
	MONTANTRENTEIA_IAP_TOTAL FLOAT,
	MONTANTRENTEINDIVIDU_VIAG FLOAT,
	MONTANTRENTEINDIVIDU_CONJ FLOAT,
	MONTANTRENTEINDIVIDU_TOTAL FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	PSEUDO_ACTUAL_IBNR_LIM FLOAT,
	MILIEURURAL VARCHAR(6),
	DENSITY NUMBER(38,20),
	TOTALAREA NUMBER(38,6),
	TOTALLANDAREA NUMBER(38,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(38,6),
	MED_AGE_CP NUMBER(38,6),
	AVG_AGEMALE_CP NUMBER(38,6),
	MED_AGEMALE_CP NUMBER(38,6),
	AVG_AGEFEM_CP NUMBER(38,6),
	MED_AGEFEM_CP NUMBER(38,6),
	AVG_NB_PRIVATEHOUSE NUMBER(38,6),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(38,6),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(38,6),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(38,6),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(38,6),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(38,6),
	AVG_INCOME NUMBER(38,6),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(38,6),
	UNEMPLOYMENT_RATE NUMBER(38,6),
	QX_INDUSTRIE NUMBER(38,6),
	FORMERENTE VARCHAR(16777216),
	CATEGORIETARIF VARCHAR(25),
	AGEACHAT NUMBER(38,0),
	AGEATTEINT FLOAT
);
create or replace TRANSIENT TABLE E50_DATATEST_INCL_GROUP (
	GROUPE VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATE_CALCUL_AGE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	MONTANTRENTE FLOAT,
	TYPE_COL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MONTANTRENTEIA_IAP_VIAG FLOAT,
	MONTANTRENTEIA_IAP_CONJ FLOAT,
	MONTANTRENTEIA_IAP_TOTAL FLOAT,
	MONTANTRENTEINDIVIDU_VIAG FLOAT,
	MONTANTRENTEINDIVIDU_CONJ FLOAT,
	MONTANTRENTEINDIVIDU_TOTAL FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	PSEUDO_ACTUAL_IBNR_LIM FLOAT,
	MILIEURURAL VARCHAR(6),
	DENSITY NUMBER(38,20),
	TOTALAREA NUMBER(38,6),
	TOTALLANDAREA NUMBER(38,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(38,6),
	MED_AGE_CP NUMBER(38,6),
	AVG_AGEMALE_CP NUMBER(38,6),
	MED_AGEMALE_CP NUMBER(38,6),
	AVG_AGEFEM_CP NUMBER(38,6),
	MED_AGEFEM_CP NUMBER(38,6),
	AVG_NB_PRIVATEHOUSE NUMBER(38,6),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(38,6),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(38,6),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(38,6),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(38,6),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(38,6),
	AVG_INCOME NUMBER(38,6),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(38,6),
	UNEMPLOYMENT_RATE NUMBER(38,6),
	QX_INDUSTRIE NUMBER(38,6),
	FORMERENTE VARCHAR(16777216),
	CATEGORIETARIF VARCHAR(25),
	AGEACHAT NUMBER(38,0),
	AGEATTEINT FLOAT
);
create or replace TRANSIENT TABLE E50_DATATEST_TEST_DASHBOARD_ETL (
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATE_CALCUL_AGE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	MONTANTRENTE FLOAT,
	TYPE_COL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MONTANTRENTEIA_IAP_VIAG FLOAT,
	MONTANTRENTEIA_IAP_CONJ FLOAT,
	MONTANTRENTEIA_IAP_TOTAL FLOAT,
	MONTANTRENTEINDIVIDU_VIAG FLOAT,
	MONTANTRENTEINDIVIDU_CONJ FLOAT,
	MONTANTRENTEINDIVIDU_TOTAL FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	PSEUDO_ACTUAL_IBNR_LIM FLOAT,
	MILIEURURAL VARCHAR(6),
	DENSITY NUMBER(38,20),
	TOTALAREA NUMBER(38,6),
	TOTALLANDAREA NUMBER(38,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(38,6),
	MED_AGE_CP NUMBER(38,6),
	AVG_AGEMALE_CP NUMBER(38,6),
	MED_AGEMALE_CP NUMBER(38,6),
	AVG_AGEFEM_CP NUMBER(38,6),
	MED_AGEFEM_CP NUMBER(38,6),
	AVG_NB_PRIVATEHOUSE NUMBER(38,6),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(38,6),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(38,6),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(38,6),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(38,6),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(38,6),
	AVG_INCOME NUMBER(38,6),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(38,6),
	UNEMPLOYMENT_RATE NUMBER(38,6),
	QX_INDUSTRIE NUMBER(38,6),
	FORMERENTE VARCHAR(16777216),
	CATEGORIETARIF VARCHAR(25),
	AGEACHAT NUMBER(38,0),
	AGEATTEINT FLOAT
);
create or replace TRANSIENT TABLE E50_DATATEST_TEST_DASHBOARD_ETL_RAW (
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE VARCHAR(16777216),
	DATE_CALCUL_AGE VARCHAR(16777216),
	AGEARRONDI VARCHAR(16777216),
	MONTANTRENTE VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MONTANTRENTEIA_IAP_VIAG VARCHAR(16777216),
	MONTANTRENTEIA_IAP_CONJ VARCHAR(16777216),
	MONTANTRENTEIA_IAP_TOTAL VARCHAR(16777216),
	MONTANTRENTEINDIVIDU_VIAG VARCHAR(16777216),
	MONTANTRENTEINDIVIDU_CONJ VARCHAR(16777216),
	MONTANTRENTEINDIVIDU_TOTAL VARCHAR(16777216),
	SURVIVANTE VARCHAR(16777216),
	PSEUDO_ACTUAL VARCHAR(16777216),
	PSEUDO_ACTUAL_IBNR VARCHAR(16777216),
	PSEUDO_ACTUAL_IBNR_LIM VARCHAR(16777216),
	MILIEURURAL VARCHAR(16777216),
	DENSITY VARCHAR(16777216),
	TOTALAREA VARCHAR(16777216),
	TOTALLANDAREA VARCHAR(16777216),
	TOTALPOPULATION VARCHAR(16777216),
	NB_INLABOURFORCE VARCHAR(16777216),
	PROP_INLABOURFORCE VARCHAR(16777216),
	AVG_AGE_CP VARCHAR(16777216),
	MED_AGE_CP VARCHAR(16777216),
	AVG_AGEMALE_CP VARCHAR(16777216),
	MED_AGEMALE_CP VARCHAR(16777216),
	AVG_AGEFEM_CP VARCHAR(16777216),
	MED_AGEFEM_CP VARCHAR(16777216),
	AVG_NB_PRIVATEHOUSE VARCHAR(16777216),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE VARCHAR(16777216),
	NB_IN_COUPLE VARCHAR(16777216),
	PROP_IN_COUPLE VARCHAR(16777216),
	PROP_MARRIED VARCHAR(16777216),
	PROP_COMMONLAW VARCHAR(16777216),
	NB_WIDOWED VARCHAR(16777216),
	PROP_WIDOWED VARCHAR(16777216),
	AVG_CHILDREN_PER_HOUSEHOULD VARCHAR(16777216),
	NON_MOVERS VARCHAR(16777216),
	MOVERS VARCHAR(16777216),
	OWNED VARCHAR(16777216),
	RENTED VARCHAR(16777216),
	BAND_HOUSING VARCHAR(16777216),
	AVG_HOUSEHOLD_INCOME_2015 VARCHAR(16777216),
	MED_HOUSEHOLD_INCOME_2015 VARCHAR(16777216),
	AVG_HOUSEHOLD_INCOME_CURR VARCHAR(16777216),
	MED_HOUSEHOLD_INCOME_CURR VARCHAR(16777216),
	AVG_INCOME VARCHAR(16777216),
	PROP_OVER_15_NO_DIPLOMA VARCHAR(16777216),
	PROP_OVER_15_HIGH_SCHOOL VARCHAR(16777216),
	PROP_OVER_15_APPRENTICESHIP VARCHAR(16777216),
	PROP_OVER_15_CEGEP VARCHAR(16777216),
	PROP_OVER_15_BELOW_BACH VARCHAR(16777216),
	PROP_OVER_15_UNIVERSITY VARCHAR(16777216),
	PROP_25_64_NO_DIPLOMA VARCHAR(16777216),
	PROP_25_64_HIGH_SCHOOL VARCHAR(16777216),
	PROP_25_64_APPRENTICESHIP VARCHAR(16777216),
	PROP_25_64_CEGEP VARCHAR(16777216),
	PROP_25_64_BELOW_BACH VARCHAR(16777216),
	PROP_25_64_UNIVERSITY VARCHAR(16777216),
	EMPLOYMENT_RATE VARCHAR(16777216),
	UNEMPLOYMENT_RATE VARCHAR(16777216),
	QX_INDUSTRIE VARCHAR(16777216),
	FORMERENTE VARCHAR(16777216),
	CATEGORIETARIF VARCHAR(16777216),
	AGEACHAT VARCHAR(16777216),
	AGEATTEINT VARCHAR(16777216)
);
create or replace TABLE E50_TMP (
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATE_CALCUL_AGE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	MONTANTRENTE FLOAT,
	TYPE_COL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MONTANTRENTEIA_IAP_VIAG FLOAT,
	MONTANTRENTEIA_IAP_CONJ FLOAT,
	MONTANTRENTEIA_IAP_TOTAL FLOAT,
	MONTANTRENTEINDIVIDU_VIAG FLOAT,
	MONTANTRENTEINDIVIDU_CONJ FLOAT,
	MONTANTRENTEINDIVIDU_TOTAL FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	PSEUDO_ACTUAL_IBNR_LIM FLOAT,
	MILIEURURAL VARCHAR(16777216),
	DENSITY NUMBER(38,20),
	TOTALAREA NUMBER(37,12),
	TOTALLANDAREA NUMBER(37,12),
	TOTALPOPULATION NUMBER(38,6),
	NB_INLABOURFORCE NUMBER(38,6),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(30,8),
	MED_AGE_CP NUMBER(30,8),
	AVG_AGEMALE_CP NUMBER(30,8),
	MED_AGEMALE_CP NUMBER(30,8),
	AVG_AGEFEM_CP NUMBER(30,8),
	MED_AGEFEM_CP NUMBER(30,8),
	AVG_NB_PRIVATEHOUSE NUMBER(30,8),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,6),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,6),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(30,8),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(37,8),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(37,8),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(37,8),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(37,8),
	AVG_INCOME NUMBER(37,8),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(30,8),
	UNEMPLOYMENT_RATE NUMBER(30,8),
	QX_INDUSTRIE NUMBER(38,6),
	FORMERENTE VARCHAR(4),
	CATEGORIETARIF VARCHAR(25),
	AGEACHAT NUMBER(1,0)
);
create or replace TRANSIENT TABLE E60_DASHBOARD_DISTRIB_V3 (
	GPE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MILIEURURAL VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	AGE FLOAT,
	FORMERENTE VARCHAR(16777216),
	SURVIVANTE NUMBER(38,0),
	CATEGORIETARIF VARCHAR(16777216),
	AVG_INCOME NUMBER(15,2),
	MONTANTRENTEIA_IAP_TOTAL NUMBER(15,2),
	DENSITY NUMBER(10,2),
	PROP_MARRIED FLOAT,
	PROP_INLABOURFORCE FLOAT,
	MOVERS FLOAT,
	RGPT_AVG_INCOME VARCHAR(16777216),
	RGPT_AVG_INCOME_TRI NUMBER(38,0),
	RGPT_MONTANTRENTE VARCHAR(16777216),
	RGPT_MONTANTRENTE_TRI NUMBER(38,0),
	RGPT_DENSITY VARCHAR(16777216),
	RGPT_DENSITY_TRI NUMBER(38,0),
	RGPT_PROP_MARRIED VARCHAR(16777216),
	RGPT_PROP_INLABOURFORCE VARCHAR(16777216),
	RGPT_MOVERS VARCHAR(16777216),
	RGPT_EMPLOYMENT_RATE VARCHAR(16777216),
	SEXE_SURVIVANT VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216)
);
create or replace TRANSIENT TABLE E60_DASHBOARD_TARIF (
	NUMERO VARCHAR(16777216),
	GPE VARCHAR(16777216),
	PRIX_BASE NUMBER(38,6),
	PRIX_AJUSTE NUMBER(38,6),
	PRIX_PREDICTIF NUMBER(38,6),
	FORMERENTE VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	AGE NUMBER(38,6),
	AGECONJOINT NUMBER(38,6),
	MONTANTRENTE NUMBER(38,6),
	PROVINCE VARCHAR(16777216),
	SURVIVANT VARCHAR(16777216),
	DENSITY NUMBER(38,6),
	MILIEURURAL VARCHAR(16777216),
	PROPINLABOURFORCE NUMBER(38,6),
	PROPMARRIED NUMBER(38,6),
	MOVERS NUMBER(38,6),
	AVG_INCOME NUMBER(38,6),
	PROP_OVER_15_UNIVERSITY NUMBER(38,6),
	EMPLOYMENT_RATE NUMBER(38,6),
	PRIX_VITA NUMBER(38,6),
	TYPE_COL VARCHAR(16777216)
);
create or replace TRANSIENT TABLE E60_TEST_DASHBOARD_DISTRIB_V3 (
	GPE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MILIEURURAL VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	AGE FLOAT,
	FORMERENTE VARCHAR(16777216),
	SURVIVANTE NUMBER(38,0),
	CATEGORIETARIF VARCHAR(16777216),
	AVG_INCOME NUMBER(15,2),
	MONTANTRENTEIA_IAP_TOTAL NUMBER(15,2),
	DENSITY NUMBER(10,2),
	PROP_MARRIED FLOAT,
	PROP_INLABOURFORCE FLOAT,
	MOVERS FLOAT,
	RGPT_AVG_INCOME VARCHAR(16777216),
	RGPT_AVG_INCOME_TRI NUMBER(38,0),
	RGPT_MONTANTRENTE VARCHAR(16777216),
	RGPT_MONTANTRENTE_TRI NUMBER(38,0),
	RGPT_DENSITY VARCHAR(16777216),
	RGPT_DENSITY_TRI NUMBER(38,0),
	RGPT_PROP_MARRIED VARCHAR(16777216),
	RGPT_PROP_INLABOURFORCE VARCHAR(16777216),
	RGPT_MOVERS VARCHAR(16777216),
	RGPT_EMPLOYMENT_RATE VARCHAR(16777216),
	SEXE_SURVIVANT VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216)
);
create or replace TRANSIENT TABLE E60_TEST_DASHBOARD_DISTRIB_V3_RAW (
	GPE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MILIEURURAL VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	AGE VARCHAR(16777216),
	FORMERENTE VARCHAR(16777216),
	SURVIVANTE VARCHAR(16777216),
	CATEGORIETARIF VARCHAR(16777216),
	AVG_INCOME VARCHAR(16777216),
	MONTANTRENTEIA_IAP_TOTAL VARCHAR(16777216),
	DENSITY VARCHAR(16777216),
	PROP_MARRIED VARCHAR(16777216),
	PROP_INLABOURFORCE VARCHAR(16777216),
	MOVERS VARCHAR(16777216),
	RGPT_AVG_INCOME VARCHAR(16777216),
	RGPT_AVG_INCOME_TRI VARCHAR(16777216),
	RGPT_MONTANTRENTE VARCHAR(16777216),
	RGPT_MONTANTRENTE_TRI VARCHAR(16777216),
	RGPT_DENSITY VARCHAR(16777216),
	RGPT_DENSITY_TRI VARCHAR(16777216),
	RGPT_PROP_MARRIED VARCHAR(16777216),
	RGPT_PROP_INLABOURFORCE VARCHAR(16777216),
	RGPT_MOVERS VARCHAR(16777216),
	RGPT_EMPLOYMENT_RATE VARCHAR(16777216),
	SEXE_SURVIVANT VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216)
);
create or replace TRANSIENT TABLE ECART_TARIF (
	GROUPE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	PRIX_IA_STANDARD FLOAT,
	PRIX_PREDICTIF FLOAT,
	PRIX_BASE FLOAT
);
create or replace TRANSIENT TABLE ECART_TARIF_RAW (
	GROUPE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	PRIX_IA_STANDARD VARCHAR(16777216),
	PRIX_PREDICTIF VARCHAR(16777216),
	PRIX_BASE VARCHAR(16777216)
);
create or replace TABLE MENSUEL (
	TYPEINDIVIDU VARCHAR(16777216),
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	SOMMERENTEIA_IAP FLOAT,
	AGE NUMBER(18,6),
	RENTE_INDIVIDU FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	CODE_POSTAL VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216),
	MILIEURURAL VARCHAR(16777216),
	DENSITY NUMBER(36,20),
	TOTALAREA NUMBER(19,6),
	TOTALLANDAREA NUMBER(19,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(12,2),
	MED_AGE_CP NUMBER(12,2),
	AVG_AGEMALE_CP NUMBER(12,2),
	MED_AGEMALE_CP NUMBER(12,2),
	AVG_AGEFEM_CP NUMBER(12,2),
	MED_AGEFEM_CP NUMBER(12,2),
	AVG_NB_PRIVATEHOUSE NUMBER(12,2),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(12,2),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	AVG_INCOME NUMBER(19,2),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(12,2),
	UNEMPLOYMENT_RATE NUMBER(12,2),
	MONTANTRENTEIA_IAP_VIAG FLOAT,
	MONTANTRENTEIA_IAP_CONJ FLOAT,
	MONTANTRENTEINDIVIDU_VIAG FLOAT,
	MONTANTRENTEINDIVIDU_CONJ FLOAT,
	RENTEINDIVIDU_MENSUEL FLOAT,
	NB_OCCURANCES_DDN_INDEX NUMBER(18,0),
	NB_OCCURANCES_INDEX NUMBER(18,0),
	DATE_CALCUL_AGE TIMESTAMP_NTZ(9),
	PROVINCE_NULL VARCHAR(16777216)
);
create or replace TRANSIENT TABLE PREDICTION_OUTPUT (
	VAL NUMBER(38,20)
);
create or replace TRANSIENT TABLE PREDICTION_OUTPUT_RAW (
	VALEURE VARCHAR(16777216)
);
create or replace TRANSIENT TABLE RAW_RCPT_DATATEST (
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE VARCHAR(16777216),
	DATEACHAT VARCHAR(16777216),
	DATERETRAITE VARCHAR(16777216),
	MONTANTRENTE VARCHAR(16777216),
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	SEXECONJOINT VARCHAR(16777216),
	DATENAISSANCECONJOINT VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	RENTEPARTICIPANT VARCHAR(16777216),
	RENTECONJOINT VARCHAR(16777216),
	SURVIVANTE VARCHAR(16777216),
	CODE_POSTAL VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	TYPE_DE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216)
);
create or replace TRANSIENT TABLE RCPT_DATATEST (
	GROUPE NUMBER(38,0),
	PREFIX VARCHAR(16777216),
	DIVISION NUMBER(38,0),
	CERTIFICAT NUMBER(38,0),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	SEXECONJOINT VARCHAR(16777216),
	DATENAISSANCECONJOINT VARCHAR(16777216),
	PROVINCE FLOAT,
	RENTEPARTICIPANT FLOAT,
	RENTECONJOINT FLOAT,
	SURVIVANTE NUMBER(38,0),
	CODE_POSTAL VARCHAR(16777216),
	INDEXS NUMBER(38,0),
	ANNEEETUDE NUMBER(38,0),
	TYPE_DE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216)
);
create or replace TABLE TABLEAALIMENTER (
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATE_CALCUL_AGE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	MONTANTRENTE FLOAT,
	TYPE_COL VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	MONTANTRENTEIA_IAP_VIAG FLOAT,
	MONTANTRENTEIA_IAP_CONJ FLOAT,
	MONTANTRENTEIA_IAP_TOTAL FLOAT,
	MONTANTRENTEINDIVIDU_VIAG FLOAT,
	MONTANTRENTEINDIVIDU_CONJ FLOAT,
	MONTANTRENTEINDIVIDU_TOTAL FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	PSEUDO_ACTUAL_IBNR_LIM FLOAT,
	MILIEURURAL VARCHAR(16777216),
	DENSITY NUMBER(38,20),
	TOTALAREA NUMBER(37,12),
	TOTALLANDAREA NUMBER(37,12),
	TOTALPOPULATION NUMBER(38,6),
	NB_INLABOURFORCE NUMBER(38,6),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(30,8),
	MED_AGE_CP NUMBER(30,8),
	AVG_AGEMALE_CP NUMBER(30,8),
	MED_AGEMALE_CP NUMBER(30,8),
	AVG_AGEFEM_CP NUMBER(30,8),
	MED_AGEFEM_CP NUMBER(30,8),
	AVG_NB_PRIVATEHOUSE NUMBER(30,8),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,6),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,6),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(30,8),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(37,8),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(37,8),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(37,8),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(37,8),
	AVG_INCOME NUMBER(37,8),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(30,8),
	UNEMPLOYMENT_RATE NUMBER(30,8),
	QX_INDUSTRIE NUMBER(38,6),
	FORMERENTE VARCHAR(4),
	CATEGORIETARIF VARCHAR(25),
	AGEACHAT NUMBER(18,0),
	AGEATTEINT FLOAT
);
create or replace view VW_E50_DATATEST(
	ANNEEETUDE,
	INDEX,
	SEXE,
	DATENAISSANCE,
	DATE_CALCUL_AGE,
	AGEARRONDI,
	MONTANTRENTE,
	TYPE_COL,
	PROVINCE,
	MONTANTRENTEIA_IAP_VIAG,
	MONTANTRENTEIA_IAP_CONJ,
	MONTANTRENTEIA_IAP_TOTAL,
	MONTANTRENTEINDIVIDU_VIAG,
	MONTANTRENTEINDIVIDU_CONJ,
	MONTANTRENTEINDIVIDU_TOTAL,
	SURVIVANTE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR,
	PSEUDO_ACTUAL_IBNR_LIM,
	MILIEURURAL,
	DENSITY,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE,
	QX_INDUSTRIE,
	FORMERENTE,
	CATEGORIETARIF,
	AGEACHAT,
	AGEATTEINT
) as (






SELECT ANNEEETUDE,
 INDEX,
 SEXE,
 to_date(DATENAISSANCE) AS DATENAISSANCE,
 to_date(DATE_CALCUL_AGE) AS DATE_CALCUL_AGE ,
 AGEARRONDI,
 MONTANTRENTE,
 TYPE_COL,
 PROVINCE,
 MONTANTRENTEIA_IAP_VIAG,
 MONTANTRENTEIA_IAP_CONJ,
 MONTANTRENTEIA_IAP_TOTAL,
 MONTANTRENTEINDIVIDU_VIAG,
 MONTANTRENTEINDIVIDU_CONJ,
 MONTANTRENTEINDIVIDU_TOTAL,
 SURVIVANTE,
 PSEUDO_ACTUAL,
 PSEUDO_ACTUAL_IBNR,
 PSEUDO_ACTUAL_IBNR_LIM,
 MILIEURURAL,
 DENSITY,
 TOTALAREA,
 TOTALLANDAREA,
 TOTALPOPULATION,
 NB_INLABOURFORCE,
 PROP_INLABOURFORCE,
 AVG_AGE_CP,
 MED_AGE_CP,
 AVG_AGEMALE_CP,
 MED_AGEMALE_CP,
 AVG_AGEFEM_CP,
 MED_AGEFEM_CP,
 AVG_NB_PRIVATEHOUSE,
 PROP_65_YEARS_OR_OVER_LIVING_ALONE,
 NB_IN_COUPLE,
 PROP_IN_COUPLE,
 PROP_MARRIED,
 PROP_COMMONLAW,
 NB_WIDOWED,
 PROP_WIDOWED,
 AVG_CHILDREN_PER_HOUSEHOULD,
 NON_MOVERS,
 MOVERS,
 OWNED,
 RENTED,
 BAND_HOUSING,
 AVG_HOUSEHOLD_INCOME_2015,
 MED_HOUSEHOLD_INCOME_2015,
 AVG_HOUSEHOLD_INCOME_CURR,
 MED_HOUSEHOLD_INCOME_CURR,
 AVG_INCOME,
 PROP_OVER_15_NO_DIPLOMA,
 PROP_OVER_15_HIGH_SCHOOL,
 PROP_OVER_15_APPRENTICESHIP,
 PROP_OVER_15_CEGEP,
 PROP_OVER_15_BELOW_BACH,
 PROP_OVER_15_UNIVERSITY,
 PROP_25_64_NO_DIPLOMA,
 PROP_25_64_HIGH_SCHOOL,
 PROP_25_64_APPRENTICESHIP,
 PROP_25_64_CEGEP,
 PROP_25_64_BELOW_BACH,
 PROP_25_64_UNIVERSITY,
 EMPLOYMENT_RATE,
 UNEMPLOYMENT_RATE,
 QX_INDUSTRIE,
 FORMERENTE,
 CATEGORIETARIF,
 AGEACHAT,
 AGEATTEINT
FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY.E50_DATATEST
);
create or replace view VW_E50_DATATEST_TO_DELETE(
	ANNEEETUDE,
	INDEXS,
	SEXE,
	DATENAISSANCE,
	DATE_CALCUL_AGE,
	AGEARRONDI,
	MONTANTRENTE,
	TYPE_COL,
	PROVINCE,
	MONTANTRENTEIA_IAP_VIAG,
	MONTANTRENTEIA_IAP_CONJ,
	MONTANTRENTEIA_IAP_TOTAL,
	MONTANTRENTEINDIVIDU_VIAG,
	MONTANTRENTEINDIVIDU_CONJ,
	MONTANTRENTEINDIVIDU_TOTAL,
	SURVIVANTE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR,
	PSEUDO_ACTUAL_IBNR_LIM,
	MILIEURURAL,
	DENSITY,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE,
	QX_INDUSTRIE,
	FORMERENTE,
	CATEGORIETARIF,
	AGEACHAT,
	AGEATTEINT
) as (

SELECT 
 ANNEEETUDE,
 INDEXS,
 SEXE,
 to_date(DATENAISSANCE) AS DATENAISSANCE,   
to_date(DATE_CALCUL_AGE) AS DATE_CALCUL_AGE,
 AGEARRONDI,
 MONTANTRENTE,
 TYPE_COL,
 PROVINCE,
 MONTANTRENTEIA_IAP_VIAG,
 MONTANTRENTEIA_IAP_CONJ,
 MONTANTRENTEIA_IAP_TOTAL,
 MONTANTRENTEINDIVIDU_VIAG,
 MONTANTRENTEINDIVIDU_CONJ,
 MONTANTRENTEINDIVIDU_TOTAL,
 SURVIVANTE,
 PSEUDO_ACTUAL,
 PSEUDO_ACTUAL_IBNR,
 PSEUDO_ACTUAL_IBNR_LIM,
 MILIEURURAL,
 DENSITY,
 TOTALAREA,
 TOTALLANDAREA,
 TOTALPOPULATION,
 NB_INLABOURFORCE,
 PROP_INLABOURFORCE,
 AVG_AGE_CP,
 MED_AGE_CP,
 AVG_AGEMALE_CP,
 MED_AGEMALE_CP,
 AVG_AGEFEM_CP,
 MED_AGEFEM_CP,
 AVG_NB_PRIVATEHOUSE,
 PROP_65_YEARS_OR_OVER_LIVING_ALONE,
 NB_IN_COUPLE,
 PROP_IN_COUPLE,
 PROP_MARRIED,
 PROP_COMMONLAW,
 NB_WIDOWED,
 PROP_WIDOWED,
 AVG_CHILDREN_PER_HOUSEHOULD,
 NON_MOVERS,
 MOVERS,
 OWNED,
 RENTED,
 BAND_HOUSING,
 AVG_HOUSEHOLD_INCOME_2015,
 MED_HOUSEHOLD_INCOME_2015,
 AVG_HOUSEHOLD_INCOME_CURR,
 MED_HOUSEHOLD_INCOME_CURR,
 AVG_INCOME,
 PROP_OVER_15_NO_DIPLOMA,
 PROP_OVER_15_HIGH_SCHOOL,
 PROP_OVER_15_APPRENTICESHIP,
 PROP_OVER_15_CEGEP,
 PROP_OVER_15_BELOW_BACH,
 PROP_OVER_15_UNIVERSITY,
 PROP_25_64_NO_DIPLOMA,
 PROP_25_64_HIGH_SCHOOL,
 PROP_25_64_APPRENTICESHIP,
 PROP_25_64_CEGEP,
 PROP_25_64_BELOW_BACH,
 PROP_25_64_UNIVERSITY,
 EMPLOYMENT_RATE,
 UNEMPLOYMENT_RATE,
 QX_INDUSTRIE,
 FORMERENTE,
 CATEGORIETARIF,
 AGEACHAT,
 AGEATTEINT
FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY.E50_DATATEST_TEST_DASHBOARD_ETL
 order BY INDEXS, AGEATTEINT
);
create or replace schema SYPHAX_ERC_MORTALITY_V2;

create or replace TRANSIENT TABLE DEMOSTATS2018_18_GEO_P1 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYASQKM NUMBER(19,6),
	ECYALSQKM NUMBER(19,6),
	ECYBASPOP NUMBER(38,0),
	ECYBASHHD NUMBER(38,0),
	ECYBASHPOP NUMBER(38,0),
	ECYBAS12P NUMBER(38,0),
	ECYBAS15P NUMBER(38,0),
	ECYBAS18P NUMBER(38,0),
	ECYBAS19P NUMBER(38,0),
	ECYBAS12HP NUMBER(38,0),
	ECYBAS15HP NUMBER(38,0),
	ECYBAS18HP NUMBER(38,0),
	ECYBAS19HP NUMBER(38,0),
	ECYBASTNGH NUMBER(38,0),
	ECYBASADUH NUMBER(38,0),
	ECYBASCF NUMBER(38,0),
	ECYBASCFH NUMBER(38,0),
	ECYBASKID NUMBER(38,0),
	ECYBASLF NUMBER(38,0)
);
create or replace TRANSIENT TABLE DEMOSTATS2018_18_GEO_P2 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYPTAPOP NUMBER(38,0),
	ECYPTA_0_4 NUMBER(38,0),
	ECYPTA_5_9 NUMBER(38,0),
	ECYPTA1014 NUMBER(38,0),
	ECYPTA1519 NUMBER(38,0),
	ECYPTA2024 NUMBER(38,0),
	ECYPTA2529 NUMBER(38,0),
	ECYPTA3034 NUMBER(38,0),
	ECYPTA3539 NUMBER(38,0),
	ECYPTA4044 NUMBER(38,0),
	ECYPTA4549 NUMBER(38,0),
	ECYPTA5054 NUMBER(38,0),
	ECYPTA5559 NUMBER(38,0),
	ECYPTA6064 NUMBER(38,0),
	ECYPTA6569 NUMBER(38,0),
	ECYPTA7074 NUMBER(38,0),
	ECYPTA7579 NUMBER(38,0),
	ECYPTA8084 NUMBER(38,0),
	ECYPTA85P NUMBER(38,0),
	ECYPTAAVG NUMBER(12,2),
	ECYPTAMED NUMBER(12,2),
	ECYPMAPOP NUMBER(38,0),
	ECYPMA_0_4 NUMBER(38,0),
	ECYPMA_5_9 NUMBER(38,0),
	ECYPMA1014 NUMBER(38,0),
	ECYPMA1519 NUMBER(38,0),
	ECYPMA2024 NUMBER(38,0),
	ECYPMA2529 NUMBER(38,0),
	ECYPMA3034 NUMBER(38,0),
	ECYPMA3539 NUMBER(38,0),
	ECYPMA4044 NUMBER(38,0),
	ECYPMA4549 NUMBER(38,0),
	ECYPMA5054 NUMBER(38,0),
	ECYPMA5559 NUMBER(38,0),
	ECYPMA6064 NUMBER(38,0),
	ECYPMA6569 NUMBER(38,0),
	ECYPMA7074 NUMBER(38,0),
	ECYPMA7579 NUMBER(38,0),
	ECYPMA8084 NUMBER(38,0),
	ECYPMA85P NUMBER(38,0),
	ECYPMAAVG NUMBER(12,2),
	ECYPMAMED NUMBER(12,2),
	ECYPFAPOP NUMBER(38,0),
	ECYPFA_0_4 NUMBER(38,0),
	ECYPFA_5_9 NUMBER(38,0),
	ECYPFA1014 NUMBER(38,0),
	ECYPFA1519 NUMBER(38,0),
	ECYPFA2024 NUMBER(38,0),
	ECYPFA2529 NUMBER(38,0),
	ECYPFA3034 NUMBER(38,0),
	ECYPFA3539 NUMBER(38,0),
	ECYPFA4044 NUMBER(38,0),
	ECYPFA4549 NUMBER(38,0),
	ECYPFA5054 NUMBER(38,0),
	ECYPFA5559 NUMBER(38,0),
	ECYPFA6064 NUMBER(38,0),
	ECYPFA6569 NUMBER(38,0),
	ECYPFA7074 NUMBER(38,0),
	ECYPFA7579 NUMBER(38,0),
	ECYPFA8084 NUMBER(38,0),
	ECYPFA85P NUMBER(38,0),
	ECYPFAAVG NUMBER(12,2),
	ECYPFAMED NUMBER(12,2),
	ECYHTAHPOP NUMBER(38,0),
	ECYHTA_0_4 NUMBER(38,0),
	ECYHTA_5_9 NUMBER(38,0),
	ECYHTA1014 NUMBER(38,0),
	ECYHTA1519 NUMBER(38,0),
	ECYHTA2024 NUMBER(38,0),
	ECYHTA2529 NUMBER(38,0),
	ECYHTA3034 NUMBER(38,0),
	ECYHTA3539 NUMBER(38,0),
	ECYHTA4044 NUMBER(38,0),
	ECYHTA4549 NUMBER(38,0),
	ECYHTA5054 NUMBER(38,0),
	ECYHTA5559 NUMBER(38,0),
	ECYHTA6064 NUMBER(38,0),
	ECYHTA6569 NUMBER(38,0),
	ECYHTA7074 NUMBER(38,0),
	ECYHTA7579 NUMBER(38,0),
	ECYHTA8084 NUMBER(38,0),
	ECYHTA85P NUMBER(38,0),
	ECYHTAAVG NUMBER(12,2),
	ECYHTAMED NUMBER(12,2),
	ECYHMAHPOP NUMBER(38,0),
	ECYHMA_0_4 NUMBER(38,0),
	ECYHMA_5_9 NUMBER(38,0),
	ECYHMA1014 NUMBER(38,0),
	ECYHMA1519 NUMBER(38,0),
	ECYHMA2024 NUMBER(38,0),
	ECYHMA2529 NUMBER(38,0),
	ECYHMA3034 NUMBER(38,0),
	ECYHMA3539 NUMBER(38,0),
	ECYHMA4044 NUMBER(38,0),
	ECYHMA4549 NUMBER(38,0),
	ECYHMA5054 NUMBER(38,0),
	ECYHMA5559 NUMBER(38,0),
	ECYHMA6064 NUMBER(38,0),
	ECYHMA6569 NUMBER(38,0),
	ECYHMA7074 NUMBER(38,0),
	ECYHMA7579 NUMBER(38,0),
	ECYHMA8084 NUMBER(38,0),
	ECYHMA85P NUMBER(38,0),
	ECYHMAAVG NUMBER(12,2),
	ECYHMAMED NUMBER(12,2),
	ECYHFAHPOP NUMBER(38,0),
	ECYHFA_0_4 NUMBER(38,0),
	ECYHFA_5_9 NUMBER(38,0),
	ECYHFA1014 NUMBER(38,0),
	ECYHFA1519 NUMBER(38,0),
	ECYHFA2024 NUMBER(38,0),
	ECYHFA2529 NUMBER(38,0),
	ECYHFA3034 NUMBER(38,0),
	ECYHFA3539 NUMBER(38,0),
	ECYHFA4044 NUMBER(38,0),
	ECYHFA4549 NUMBER(38,0),
	ECYHFA5054 NUMBER(38,0),
	ECYHFA5559 NUMBER(38,0),
	ECYHFA6064 NUMBER(38,0),
	ECYHFA6569 NUMBER(38,0),
	ECYHFA7074 NUMBER(38,0),
	ECYHFA7579 NUMBER(38,0),
	ECYHFA8084 NUMBER(38,0),
	ECYHFA85P NUMBER(38,0),
	ECYHFAAVG NUMBER(12,2),
	ECYHFAMED NUMBER(12,2),
	ECYMTNHHD NUMBER(38,0),
	ECYMTN1524 NUMBER(38,0),
	ECYMTN2534 NUMBER(38,0),
	ECYMTN3544 NUMBER(38,0),
	ECYMTN4554 NUMBER(38,0),
	ECYMTN5564 NUMBER(38,0),
	ECYMTN6574 NUMBER(38,0),
	ECYMTN75P NUMBER(38,0),
	ECYMTNAVG NUMBER(12,2),
	ECYMTNMED NUMBER(12,2),
	ECYHSZHHD NUMBER(38,0),
	ECYHSZ1PER NUMBER(38,0),
	ECYHSZ2PER NUMBER(38,0),
	ECYHSZ3PER NUMBER(38,0),
	ECYHSZ4PER NUMBER(38,0),
	ECYHSZ5PER NUMBER(38,0),
	ECYHSZTPER NUMBER(38,0),
	ECYHSZAVG NUMBER(12,2),
	ECYHTYHHD NUMBER(38,0),
	ECYHTYFHT NUMBER(38,0),
	ECYHTY1FH NUMBER(38,0),
	ECYHTYMFH NUMBER(38,0),
	ECYHTYNFH NUMBER(38,0),
	ECYHTY1PH NUMBER(38,0),
	ECYHTYN65A NUMBER(38,0),
	ECYHTY2PPH NUMBER(38,0),
	ECYMARP15 NUMBER(38,0),
	ECYMARMCL NUMBER(38,0),
	ECYMARM NUMBER(38,0),
	ECYMARCL NUMBER(38,0),
	ECYMARNMCL NUMBER(38,0),
	ECYMARSING NUMBER(38,0),
	ECYMARSEP NUMBER(38,0),
	ECYMARDIV NUMBER(38,0),
	ECYMARWID NUMBER(38,0),
	ECYCFSCF NUMBER(38,0),
	ECYCFSC NUMBER(38,0),
	ECYCFSCNC NUMBER(38,0),
	ECYCFSCWC NUMBER(38,0),
	ECYCFSC1C NUMBER(38,0),
	ECYCFSC2C NUMBER(38,0),
	ECYCFSC3C NUMBER(38,0),
	ECYCFSM NUMBER(38,0),
	ECYCFSMNC NUMBER(38,0),
	ECYCFSMWC NUMBER(38,0),
	ECYCFSM1C NUMBER(38,0),
	ECYCFSM2C NUMBER(38,0),
	ECYCFSM3C NUMBER(38,0),
	ECYCFSCL NUMBER(38,0),
	ECYCFSCLNC NUMBER(38,0),
	ECYCFSCLWC NUMBER(38,0),
	ECYCFSCL1C NUMBER(38,0),
	ECYCFSCL2C NUMBER(38,0),
	ECYCFSCL3C NUMBER(38,0),
	ECYCFSLP NUMBER(38,0),
	ECYCFSLP1C NUMBER(38,0),
	ECYCFSLP2C NUMBER(38,0),
	ECYCFSLP3C NUMBER(38,0),
	ECYCFSFP NUMBER(38,0),
	ECYCFSFP1C NUMBER(38,0),
	ECYCFSFP2C NUMBER(38,0),
	ECYCFSFP3C NUMBER(38,0),
	ECYCFSMP NUMBER(38,0),
	ECYCFSMP1C NUMBER(38,0),
	ECYCFSMP2C NUMBER(38,0),
	ECYCFSMP3C NUMBER(38,0),
	ECYCFSNFP NUMBER(38,0),
	ECYHFSCF NUMBER(38,0),
	ECYHFSC NUMBER(38,0),
	ECYHFSCNC NUMBER(38,0),
	ECYHFSCWC NUMBER(38,0),
	ECYHFSC1C NUMBER(38,0),
	ECYHFSC2C NUMBER(38,0),
	ECYHFSC3C NUMBER(38,0),
	ECYHFSM NUMBER(38,0),
	ECYHFSMNC NUMBER(38,0),
	ECYHFSMWC NUMBER(38,0),
	ECYHFSM1C NUMBER(38,0),
	ECYHFSM2C NUMBER(38,0),
	ECYHFSM3C NUMBER(38,0),
	ECYHFSCL NUMBER(38,0),
	ECYHFSCLNC NUMBER(38,0),
	ECYHFSCLWC NUMBER(38,0),
	ECYHFSCL1C NUMBER(38,0),
	ECYHFSCL2C NUMBER(38,0),
	ECYHFSCL3C NUMBER(38,0),
	ECYHFSLP NUMBER(38,0),
	ECYHFSLP1C NUMBER(38,0),
	ECYHFSLP2C NUMBER(38,0),
	ECYHFSLP3C NUMBER(38,0),
	ECYHFSFP NUMBER(38,0),
	ECYHFSFP1C NUMBER(38,0),
	ECYHFSFP2C NUMBER(38,0),
	ECYHFSFP3C NUMBER(38,0),
	ECYHFSMP NUMBER(38,0),
	ECYHFSMP1C NUMBER(38,0),
	ECYHFSMP2C NUMBER(38,0),
	ECYHFSMP3C NUMBER(38,0),
	ECYCHAKIDS NUMBER(38,0),
	ECYCHA_0_4 NUMBER(38,0),
	ECYCHA_5_9 NUMBER(38,0),
	ECYCHA1014 NUMBER(38,0),
	ECYCHA1519 NUMBER(38,0),
	ECYCHA2024 NUMBER(38,0),
	ECYCHA25P NUMBER(38,0),
	ECYCHACFCH NUMBER(12,2),
	ECYCHAFHCH NUMBER(12,2),
	ECYCHAHHCH NUMBER(12,2)
);
create or replace TRANSIENT TABLE DEMOSTATS2018_18_GEO_P3 (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	ECYMOBHPOP NUMBER(38,0),
	ECYMOBNMOV NUMBER(38,0),
	ECYMOBMOV NUMBER(38,0),
	ECYTENHHD NUMBER(38,0),
	ECYTENOWN NUMBER(38,0),
	ECYTENRENT NUMBER(38,0),
	ECYTENBAND NUMBER(38,0),
	ECYPOCHHD NUMBER(38,0),
	ECYPOCP60 NUMBER(38,0),
	ECYPOC6180 NUMBER(38,0),
	ECYPOC8190 NUMBER(38,0),
	ECYPOC9100 NUMBER(38,0),
	ECYPOC0105 NUMBER(38,0),
	ECYPOC0610 NUMBER(38,0),
	ECYPOC1116 NUMBER(38,0),
	ECYPOC17P NUMBER(38,0),
	ECYSTYHHD NUMBER(38,0),
	ECYSTYHOUS NUMBER(38,0),
	ECYSTYSING NUMBER(38,0),
	ECYSTYSEMI NUMBER(38,0),
	ECYSTYROW NUMBER(38,0),
	ECYSTYAPT NUMBER(38,0),
	ECYSTYAP5P NUMBER(38,0),
	ECYSTYAPU5 NUMBER(38,0),
	ECYSTYDUPL NUMBER(38,0),
	ECYSTYOTHR NUMBER(38,0),
	ECYSTYOATT NUMBER(38,0),
	ECYSTYMOVE NUMBER(38,0),
	ECYCDOHHD NUMBER(38,0),
	ECYCDOIC NUMBER(38,0),
	ECYCDOICAP NUMBER(38,0),
	ECYCDOAPOW NUMBER(38,0),
	ECYCDOAPRE NUMBER(38,0),
	ECYCDOICOT NUMBER(38,0),
	ECYCDOOTOW NUMBER(38,0),
	ECYCDOOTRE NUMBER(38,0),
	ECYCDONIC NUMBER(38,0),
	ECYCDOOW NUMBER(38,0),
	ECYCDOOWHO NUMBER(38,0),
	ECYCDOOWOT NUMBER(38,0),
	ECYCDORE NUMBER(38,0),
	ECYCDOREHO NUMBER(38,0),
	ECYCDOREOT NUMBER(38,0),
	ECYCDOBAND NUMBER(38,0),
	ECYHRIHHD NUMBER(38,0),
	ECYHRI_010 NUMBER(38,0),
	ECYHRI1020 NUMBER(38,0),
	ECYHRI2030 NUMBER(38,0),
	ECYHRI3040 NUMBER(38,0),
	ECYHRI4050 NUMBER(38,0),
	ECYHRI5060 NUMBER(38,0),
	ECYHRI6070 NUMBER(38,0),
	ECYHRI7080 NUMBER(38,0),
	ECYHRI8090 NUMBER(38,0),
	ECYHRIX100 NUMBER(38,0),
	ECYHRI100P NUMBER(38,0),
	ECYHRIX125 NUMBER(38,0),
	ECYHRIX150 NUMBER(38,0),
	ECYHRIX175 NUMBER(38,0),
	ECYHRIX200 NUMBER(38,0),
	ECYHRIX250 NUMBER(38,0),
	ECYHRI250P NUMBER(38,0),
	ECYHRIAVG NUMBER(19,2),
	ECYHRIMED NUMBER(19,2),
	ECYHRIAGG FLOAT,
	ECYHNIHHD NUMBER(38,0),
	ECYHNI_020 NUMBER(38,0),
	ECYHNI2040 NUMBER(38,0),
	ECYHNI4060 NUMBER(38,0),
	ECYHNI6080 NUMBER(38,0),
	ECYHNIX100 NUMBER(38,0),
	ECYHNI100P NUMBER(38,0),
	ECYHNIX125 NUMBER(38,0),
	ECYHNIX150 NUMBER(38,0),
	ECYHNIX200 NUMBER(38,0),
	ECYHNI200P NUMBER(38,0),
	ECYHNIAVG NUMBER(19,2),
	ECYHNIMED NUMBER(19,2),
	ECYHNIAGG FLOAT,
	ECYPNIHP15 NUMBER(38,0),
	ECYPNININ NUMBER(38,0),
	ECYPNIWIN NUMBER(38,0),
	ECYPNIAVG NUMBER(19,2),
	ECYEDUHP15 NUMBER(38,0),
	ECYEDUNCDD NUMBER(38,0),
	ECYEDUHSCE NUMBER(38,0),
	ECYEDUATCD NUMBER(38,0),
	ECYEDUCOLL NUMBER(38,0),
	ECYEDUUDBB NUMBER(38,0),
	ECYEDUUD NUMBER(38,0),
	ECYEDUUDBD NUMBER(38,0),
	ECYEDUUDBP NUMBER(38,0),
	ECYEDAHPWK NUMBER(38,0),
	ECYEDANCDD NUMBER(38,0),
	ECYEDAHSCE NUMBER(38,0),
	ECYEDAATCD NUMBER(38,0),
	ECYEDACOLL NUMBER(38,0),
	ECYEDAUDBB NUMBER(38,0),
	ECYEDAUD NUMBER(38,0),
	ECYEDAUDBD NUMBER(38,0),
	ECYEDAUDBP NUMBER(38,0),
	ECYACTHPL NUMBER(38,0),
	ECYACTINLF NUMBER(38,0),
	ECYACTEMP NUMBER(38,0),
	ECYACTUEMP NUMBER(38,0),
	ECYACTNOLF NUMBER(38,0),
	ECYACTPR NUMBER(12,2),
	ECYACTER NUMBER(12,2),
	ECYACTUR NUMBER(12,2),
	ECYOCCHPL NUMBER(38,0),
	ECYOCCINLF NUMBER(38,0),
	ECYOCCNA NUMBER(38,0),
	ECYOCCALL NUMBER(38,0),
	ECYOCCMGMT NUMBER(38,0),
	ECYOCCBFAD NUMBER(38,0),
	ECYOCCNSCI NUMBER(38,0),
	ECYOCCHLTH NUMBER(38,0),
	ECYOCCSSER NUMBER(38,0),
	ECYOCCARTS NUMBER(38,0),
	ECYOCCSERV NUMBER(38,0),
	ECYOCCTRAD NUMBER(38,0),
	ECYOCCPRIM NUMBER(38,0),
	ECYOCCSCND NUMBER(38,0),
	ECYINDHPL NUMBER(38,0),
	ECYINDINLF NUMBER(38,0),
	ECYINDNA NUMBER(38,0),
	ECYINDALL NUMBER(38,0),
	ECYINDAGRI NUMBER(38,0),
	ECYINDMINE NUMBER(38,0),
	ECYINDUTIL NUMBER(38,0),
	ECYINDCSTR NUMBER(38,0),
	ECYINDMANU NUMBER(38,0),
	ECYINDWHOL NUMBER(38,0),
	ECYINDRETL NUMBER(38,0),
	ECYINDTRAN NUMBER(38,0),
	ECYINDINFO NUMBER(38,0),
	ECYINDFINA NUMBER(38,0),
	ECYINDREAL NUMBER(38,0),
	ECYINDPROF NUMBER(38,0),
	ECYINDMGMT NUMBER(38,0),
	ECYINDADMN NUMBER(38,0),
	ECYINDEDUC NUMBER(38,0),
	ECYINDHLTH NUMBER(38,0),
	ECYINDARTS NUMBER(38,0),
	ECYINDACCO NUMBER(38,0),
	ECYINDOSER NUMBER(38,0),
	ECYINDPUBL NUMBER(38,0),
	ECYPOWHPL NUMBER(38,0),
	ECYPOWINLF NUMBER(38,0),
	ECYPOWEMP NUMBER(38,0),
	ECYPOWHOME NUMBER(38,0),
	ECYPOWOSCA NUMBER(38,0),
	ECYPOWNFIX NUMBER(38,0),
	ECYPOWUSUL NUMBER(38,0),
	ECYTRAHPL NUMBER(38,0),
	ECYTRAALL NUMBER(38,0),
	ECYTRADRIV NUMBER(38,0),
	ECYTRAPSGR NUMBER(38,0),
	ECYTRAPUBL NUMBER(38,0),
	ECYTRAWALK NUMBER(38,0),
	ECYTRABIKE NUMBER(38,0),
	ECYTRAOTHE NUMBER(38,0)
);
create or replace TRANSIENT TABLE E00_ATTRIBUTSPERTINENTSDEMOSTATS (
	CODE VARCHAR(16777216),
	GEO VARCHAR(16777216),
	TOTALAREA NUMBER(19,6),
	TOTALLANDAREA NUMBER(19,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(12,2),
	MED_AGE_CP NUMBER(12,2),
	AVG_AGEMALE_CP NUMBER(12,2),
	MED_AGEMALE_CP NUMBER(12,2),
	AVG_AGEFEM_CP NUMBER(12,2),
	MED_AGEFEM_CP NUMBER(12,2),
	AVG_NB_PRIVATEHOUSE NUMBER(12,2),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(12,2),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	AVG_INCOME NUMBER(19,2),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(12,2),
	UNEMPLOYMENT_RATE NUMBER(12,2),
	PROP_MANAGEMENT FLOAT,
	PROP_FINANCE FLOAT,
	PROP_SCIENCE FLOAT,
	PROP_HEALTH FLOAT,
	PROP_EDUCATION FLOAT,
	PROP_ART FLOAT,
	PROP_SERVICE FLOAT,
	PROP_TRADES FLOAT,
	PROP_PRIMARY_INDUS FLOAT,
	PROP_MANUFACTURE FLOAT
);
create or replace TRANSIENT TABLE E30_DATATEST (
	TYPEINDIVIDU VARCHAR(16777216),
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	SOMMERENTEIA_IAP FLOAT,
	RENTE_INDIVIDU FLOAT,
	SURVIVANTE VARCHAR(16777216),
	CODE_POSTAL VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	INDEX_CONSTANT VARCHAR(16777216),
	TYPE_DE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216)
);
create or replace TRANSIENT TABLE E31_DATATEST (
	TYPEINDIVIDU VARCHAR(16777216),
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(9,0),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	SOMMERENTEIA_IAP FLOAT,
	AGE NUMBER(17,6),
	RENTE_INDIVIDU FLOAT,
	SURVIVANTE NUMBER(18,5),
	CODE_POSTAL VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	INDEX_CONSTANT VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT
);
create or replace TRANSIENT TABLE E40_DATATEST (
	TYPEINDIVIDU VARCHAR(16777216),
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	AGEARRONDI NUMBER(38,0),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	SOMMERENTEIA_IAP FLOAT,
	AGE NUMBER(18,6),
	RENTE_INDIVIDU FLOAT,
	SURVIVANTE NUMBER(38,0),
	PSEUDO_ACTUAL FLOAT,
	PSEUDO_ACTUAL_IBNR FLOAT,
	CODE_POSTAL VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	TYPE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216),
	MILIEURURAL VARCHAR(16777216),
	DENSITY NUMBER(36,20),
	TOTALAREA NUMBER(19,6),
	TOTALLANDAREA NUMBER(19,6),
	TOTALPOPULATION NUMBER(38,0),
	NB_INLABOURFORCE NUMBER(38,0),
	PROP_INLABOURFORCE FLOAT,
	AVG_AGE_CP NUMBER(12,2),
	MED_AGE_CP NUMBER(12,2),
	AVG_AGEMALE_CP NUMBER(12,2),
	MED_AGEMALE_CP NUMBER(12,2),
	AVG_AGEFEM_CP NUMBER(12,2),
	MED_AGEFEM_CP NUMBER(12,2),
	AVG_NB_PRIVATEHOUSE NUMBER(12,2),
	PROP_65_YEARS_OR_OVER_LIVING_ALONE FLOAT,
	NB_IN_COUPLE NUMBER(38,0),
	PROP_IN_COUPLE FLOAT,
	PROP_MARRIED FLOAT,
	PROP_COMMONLAW FLOAT,
	NB_WIDOWED NUMBER(38,0),
	PROP_WIDOWED FLOAT,
	AVG_CHILDREN_PER_HOUSEHOULD NUMBER(12,2),
	NON_MOVERS FLOAT,
	MOVERS FLOAT,
	OWNED FLOAT,
	RENTED FLOAT,
	BAND_HOUSING FLOAT,
	AVG_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_2015 NUMBER(19,2),
	AVG_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	MED_HOUSEHOLD_INCOME_CURR NUMBER(19,2),
	AVG_INCOME NUMBER(19,2),
	PROP_OVER_15_NO_DIPLOMA FLOAT,
	PROP_OVER_15_HIGH_SCHOOL FLOAT,
	PROP_OVER_15_APPRENTICESHIP FLOAT,
	PROP_OVER_15_CEGEP FLOAT,
	PROP_OVER_15_BELOW_BACH FLOAT,
	PROP_OVER_15_UNIVERSITY FLOAT,
	PROP_25_64_NO_DIPLOMA FLOAT,
	PROP_25_64_HIGH_SCHOOL FLOAT,
	PROP_25_64_APPRENTICESHIP FLOAT,
	PROP_25_64_CEGEP FLOAT,
	PROP_25_64_BELOW_BACH FLOAT,
	PROP_25_64_UNIVERSITY FLOAT,
	EMPLOYMENT_RATE NUMBER(12,2),
	UNEMPLOYMENT_RATE NUMBER(12,2)
);
create or replace TRANSIENT TABLE RECEPTION_V01__RAW_DATA (
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO VARCHAR(16777216),
	SEXE VARCHAR(16777216),
	DATENAISSANCE VARCHAR(16777216),
	DATEACHAT VARCHAR(16777216),
	DATERETRAITE VARCHAR(16777216),
	MONTANTRENTE VARCHAR(16777216),
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	SEXECONJOINT VARCHAR(16777216),
	DATE_NAISSANCE_CONJOINT VARCHAR(16777216),
	PROVINCE VARCHAR(16777216),
	RENTEPARTICIPANT VARCHAR(16777216),
	RENTECONJOINT VARCHAR(16777216),
	SURVIVANTE VARCHAR(16777216),
	CODE_POSTAL VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	TYPE_DE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216),
	AJUSTEMENTBANDEMORTALITE VARCHAR(16777216)
);
create or replace TRANSIENT TABLE RECEPTION_V01__TYPED_DATA (
	GROUPE VARCHAR(16777216),
	PREFIX VARCHAR(16777216),
	DIVISION VARCHAR(16777216),
	CERTIFICAT VARCHAR(16777216),
	NUMERO NUMBER(38,0),
	SEXE VARCHAR(16777216),
	DATENAISSANCE TIMESTAMP_NTZ(9),
	DATEACHAT TIMESTAMP_NTZ(9),
	DATERETRAITE TIMESTAMP_NTZ(9),
	MONTANTRENTE FLOAT,
	FORMERENTE VARCHAR(16777216),
	FREQUENCE VARCHAR(16777216),
	SEXECONJOINT VARCHAR(16777216),
	DATENAISSANCECONJOINT TIMESTAMP_NTZ(9),
	PROVINCE VARCHAR(16777216),
	RENTEPARTICIPANT FLOAT,
	RENTECONJOINT FLOAT,
	SURVIVANTE VARCHAR(16777216),
	CODE_POSTAL VARCHAR(16777216),
	INDEXS VARCHAR(16777216),
	ANNEEETUDE VARCHAR(16777216),
	TYPE_DE_COL VARCHAR(16777216),
	INDUSTRIE VARCHAR(16777216),
	AJUSTEMENTBANDEMORTALITE VARCHAR(16777216)
);
create or replace view RECEPTION_V01__VW_TYPED_DATA(
	GROUPE,
	PREFIX,
	DIVISION,
	CERTIFICAT,
	NUMERO,
	SEXE,
	DATENAISSANCE,
	DATEACHAT,
	DATERETRAITE,
	MONTANTRENTE,
	FORMERENTE,
	FREQUENCE,
	PROVINCE,
	SEXECONJOINT,
	DATENAISSANCECONJOINT,
	RENTEPARTICIPANT,
	RENTECONJOINT,
	SURVIVANTE,
	CODE_POSTAL,
	INDEXS,
	ANNEEETUDE,
	TYPE_DE_COL,
	INDUSTRIE,
	AJUSTEMENTBANDEMORTALITE
) as 
( 
  SELECT 
  Groupe ,
  PreFix  ,
  Division ,
  Certificat ,
  Numero::INT AS Numero,
  Sexe ,
  to_timestamp_ntz (DateNaissance,'MM/DD/YYYY')AS DateNaissance,    
  to_timestamp_ntz(DateAchat, 'MM/DD/YYYY') AS DateAchat,           
  to_timestamp_ntz(DateRetraite, 'MM/DD/YYYY')AS DateRetraite,      
  MontantRente::FLOAT  AS MontantRente,
  FormeRente ,
  Frequence ,
  Province,
  SexeConjoint ,
  iff(Date_Naissance_Conjoint != '1/0/1900', Date_Naissance_Conjoint::timestamp_ntz, to_timestamp_ntz('01/01/1900')) AS DateNaissanceConjoint, 
  RenteParticipant::FLOAT AS RenteParticipant ,
  RenteConjoint::FLOAT AS RenteConjoint,
  Survivante ,
  Code_Postal ,
  Indexs ,
  AnneeEtude ,
  TYPE_DE_COL  ,
  Industrie, 
  AjustementBandeMortalite 
   FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.RECEPTION_v01__RAW_DATA
);
create or replace view TRANSFORMATION_V01__VW_E00_ATTRIBUTSPERTINENTSDEMOSTATS(
	CODE,
	GEO,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE,
	PROP_MANAGEMENT,
	PROP_FINANCE,
	PROP_SCIENCE,
	PROP_HEALTH,
	PROP_EDUCATION,
	PROP_ART,
	PROP_SERVICE,
	PROP_TRADES,
	PROP_PRIMARY_INDUS,
	PROP_MANUFACTURE
) as (
select 
      p1.CODE
	, p1.GEO
		  --GEO P1
	  ,ECYASQKM as TotalArea
      ,ECYALSQKM as TotalLandArea
      ,ECYBASPOP as TotalPopulation
      ,ECYBASLF as Nb_InLabourForce
	  ,case when ECYBASPOP<>0 then round(100*cast(ECYBASLF as float)/cast(ECYBASPOP as float),2) else null end as Prop_InLabourForce
	  --GEO_P2
      ,ECYPTAAVG as Avg_Age_CP
      ,ECYPTAMED as Med_Age_CP
      ,ECYPMAAVG as Avg_AgeMale_CP
      ,ECYPMAMED as Med_AgeMale_CP
      ,ECYPFAAVG as Avg_AgeFem_CP
      ,ECYPFAMED as Med_AgeFem_CP
      ,ECYHSZAVG as Avg_nb_PrivateHouse
     -- ,ECYHTYHHD as Total_Households 
      --,ECYHTYFHT as Total_Family_Households
      --,ECYHTYNFH as Non_Family_Households
      --,ECYHTY1PH as One_Person_Households
      --,ECYHTYN65A as Peopl_65_Years_Or_Over_Living_Alone
	  ,case when ECYHTYHHD<>0 then round(100*cast(ECYHTYN65A as float)/cast(ECYHTYHHD as float),2) else null end as Prop_65_Years_Or_Over_Living_Alone
      ,ECYMARMCL as Nb_In_couple
	  ,case when ECYMARP15<>0 then round(100*cast(ECYMARMCL as float)/cast(ECYMARP15 as float),2) else null end as Prop_In_couple --Married or in common law
	  ,case when ECYMARP15<>0 then round(100*cast(ECYMARM as float)/cast(ECYMARP15 as float),2) else null end as Prop_Married
	  ,case when ECYMARP15<>0 then round(100*cast(ECYMARCL as float)/cast(ECYMARP15 as float),2) else null end as Prop_CommonLaw
      ,ECYMARWID as Nb_Widowed  
	  ,case when ECYMARP15<>0 then round(100*cast(ECYMARWID as float)/cast(ECYMARP15 as float),2) else null end as Prop_Widowed     
      ,ECYCHAHHCH as Avg_children_per_househould
	  --GEO P3
      ,case when ECYMOBHPOP<>0 then round(100*cast(ECYMOBNMOV as float)/cast(ECYMOBHPOP as float),2) else null end as Non_Movers
      ,case when ECYMOBHPOP<>0 then round(100*cast(ECYMOBMOV as float)/cast(ECYMOBHPOP as float),2)else null end as Movers
      ,case when ECYTENHHD<>0 then round(100*cast(ECYTENOWN as float)/cast(ECYTENHHD as float),2)else null end as Owned
      ,case when ECYTENHHD<>0 then round(100*cast(ECYTENRENT as float)/cast(ECYTENHHD as float),2)else null end as Rented
      ,case when ECYTENHHD<>0 then round(100*cast(ECYTENBAND as float)/cast(ECYTENHHD as float),2) else null end as Band_Housing
      ,ECYHRIAVG as Avg_Household_Income_2015
      ,ECYHRIMED as Med_Household_Income_2015
      ,ECYHNIAVG as Avg_Household_Income_Curr
      ,ECYHNIMED as Med_Household_Income_Curr
      ,ECYPNIAVG as Avg_Income
      ,case when ECYEDUHP15<>0 then round(100*cast(ECYEDUNCDD as float)/cast(ECYEDUHP15 as float),2) else null end  as prop_over_15_No_diploma
      ,case when ECYEDUHP15<>0 then round(100*cast(ECYEDUHSCE as float)/cast(ECYEDUHP15 as float),2) else null end  as prop_over_15_High_School
      ,case when ECYEDUHP15<>0 then round(100*cast(ECYEDUATCD as float)/cast(ECYEDUHP15 as float),2) else null end  as prop_over_15_Apprenticeship
      ,case when ECYEDUHP15<>0 then round(100*cast(ECYEDUCOLL as float)/cast(ECYEDUHP15 as float),2) else null end  as prop_over_15_CEGEP
	  ,case when ECYEDUHP15<>0 then round(100*cast(ECYEDUUDBB as float)/cast(ECYEDUHP15 as float),2) else null end as prop_over_15_Below_Bach
      ,case when ECYEDUHP15<>0 then round(100*cast(ECYEDUUD as float)/cast(ECYEDUHP15 as float),2) else null end as prop_over_15_University
      ,case when ECYEDAHPWK<>0 then round(100*cast(ECYEDANCDD as float)/cast(ECYEDAHPWK as float),2) else null end as prop_25_64_No_diploma
      ,case when ECYEDAHPWK<>0 then round(100*cast(ECYEDAHSCE as float)/cast(ECYEDAHPWK as float),2) else null end as prop_25_64_High_School
      ,case when ECYEDAHPWK<>0 then round(100*cast(ECYEDAATCD as float)/cast(ECYEDAHPWK as float),2) else null end as prop_25_64_Apprenticeship
      ,case when ECYEDAHPWK<>0 then round(100*cast(ECYEDACOLL as float)/cast(ECYEDAHPWK as float),2) else null end as prop_25_64_CEGEP
	  ,case when ECYEDAHPWK<>0 then round(100*cast(ECYEDAUDBB as float)/cast(ECYEDAHPWK as float),2) else null end as prop_25_64_Below_Bach
      ,case when ECYEDAHPWK<>0 then round(100*cast(ECYEDAUD as float)/cast(ECYEDAHPWK as float),2) else null end as prop_25_64_University
      ,ECYACTER as Employment_Rate
      ,ECYACTUR as Unemployment_Rate
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCMGMT as float)/cast(ECYOCCALL as float),2) else null end as prop_Management
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCBFAD as float)/cast(ECYOCCALL as float),2) else null end as prop_Finance
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCNSCI as float)/cast(ECYOCCALL as float),2) else null end as prop_Science
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCHLTH as float)/cast(ECYOCCALL as float),2) else null end as prop_Health
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCSSER as float)/cast(ECYOCCALL as float),2) else null end as prop_Education
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCARTS as float)/cast(ECYOCCALL as float),2) else null end as prop_Art
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCSERV as float)/cast(ECYOCCALL as float),2) else null end as prop_Service
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCTRAD as float)/cast(ECYOCCALL as float),2) else null end as prop_Trades
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCPRIM as float)/cast(ECYOCCALL as float),2) else null end as prop_Primary_Indus
	  ,case when ECYOCCALL<>0 then round(100*cast(ECYOCCSCND as float)/cast(ECYOCCALL as float),2) else null end as prop_Manufacture
from DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.DEMOSTATS2018_18_GEO_P1 p1     
left join  DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.DEMOSTATS2018_18_GEO_P2 p2 on (p2.CODE = p1.CODE and p2.GEO = p1.GEO)
left join  DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.DEMOSTATS2018_18_GEO_P3 p3 on (p3.CODE = p1.CODE and p3.GEO = p1.GEO)
);
create or replace view TRANSFORMATION_V01__VW_E30_SEPARERPARTICIPANTSCONJOINTS_DATASET(
	TYPEINDIVIDU,
	GROUPE,
	PREFIX,
	DIVISION,
	CERTIFICAT,
	NUMERO,
	SEXE,
	DATENAISSANCE,
	DATEACHAT,
	DATERETRAITE,
	MONTANTRENTE,
	FORMERENTE,
	FREQUENCE,
	PROVINCE,
	SOMMERENTEIA_IAP,
	RENTE_INDIVIDU,
	SURVIVANTE,
	CODE_POSTAL,
	ANNEEETUDE,
	INDEXS,
	INDEX_CONSTANT,
	TYPE_DE_COL,
	INDUSTRIE
) as(
SELECT * 
FROM
(
	SELECT
          'P' as TypeIndividu
		  ,Groupe
		  ,PreFix
		  ,Division
		  ,Certificat
		  ,Numero
		  ,Sexe
		  ,DateNaissance
		  ,DateAchat
		  ,DateRetraite
		  ,MontantRente
		  ,FormeRente
		  ,Frequence
		  ,Province
		  ,MontantRente as SommeRenteIA_IAP
		  ,RenteParticipant as Rente_Individu
		  ,Survivante --Statut survivant du participant
		  ,Code_Postal
		  ,AnneeEtude
		  ,Indexs
		  ,Indexs as Index_constant
		  ,TYPE_DE_COL
		  ,Industrie
	  FROM  DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.RECEPTION_v01__TYPED_DATA
      
      
    UNION  
      
      
      
      SELECT 
          'C' as TypePersonne
		  ,Groupe
		  ,PreFix
		  ,Division
		  ,Certificat
		  ,Numero
		  ,SexeConjoint as Sexe
		  ,DateNaissanceConjoint as DateNaissance
		  ,DateAchat
		  ,DateRetraite
		  ,MontantRente
		  ,FormeRente
		  ,Frequence
		  ,Province
		  ,MontantRente as SommeRenteIA_IAP
		  ,RenteConjoint as Rente_Individu
		  ,'0' as Survivante -- Le conjoint n est necessairement pas un survivant
		  ,Code_Postal
		  ,AnneeEtude
		  ,'C'||Indexs  as Indexs
		  ,'C'||Indexs  as Index_constant
		  ,'Ne sait pas' as Type_col --Info non dispo pour le conjoint
		  ,'Ne sait pas' as Industrie --Info non dispo pour le conjoint
	  FROM   DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.RECEPTION_v01__TYPED_DATA
	  where FormeRente = 'CONJ'
    
  ) 
  );
create or replace view TRANSFORMATION_V01__VW_E31_CLEANING_DATATEST_SIMPLIFIE(
	TYPEINDIVIDU,
	GROUPE,
	PREFIX,
	DIVISION,
	CERTIFICAT,
	NUMERO,
	SEXE,
	DATENAISSANCE,
	AGEARRONDI,
	DATEACHAT,
	DATERETRAITE,
	MONTANTRENTE,
	FORMERENTE,
	FREQUENCE,
	PROVINCE,
	SOMMERENTEIA_IAP,
	AGE,
	RENTE_INDIVIDU,
	SURVIVANTE,
	CODE_POSTAL,
	ANNEEETUDE,
	INDEXS,
	INDEX_CONSTANT,
	TYPE_COL,
	INDUSTRIE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR
) as (






SELECT 

 TYPEINDIVIDU,
 GROUPE,
 PREFIX,
 DIVISION,
 CERTIFICAT,
 c.NUMERO,
 SEXE,
 DATENAISSANCE,
 AGEARRONDI,
 DATEACHAT,
 DATERETRAITE,
 MONTANTRENTE,
 FORMERENTE,
 FREQUENCE,
 PROVINCE,
 SOMMERENTEIA_IAP,
 AGE,
 RENTE_INDIVIDU,
 SURVIVANTE,
 CODE_POSTAL,
 ANNEEETUDE,
 (CASE
    WHEN  corr.INDEXS IS  NOT  NULL  AND corr.NUMERO  IS  NOT  NULL AND TypeIndividu = 'P'
           THEN  'P'||c.Indexs
  
  ELSE   c.Indexs
END )AS Indexs ,
 INDEX_CONSTANT,
 Type_col,
 INDUSTRIE,
 PSEUDO_ACTUAL,
 PSEUDO_ACTUAL AS Pseudo_Actual_IBNR
 

from DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.TRANSFORMATION_v01__VW_E31_Cleaning_DataTest_simplifie_TABLE_A_ALIMENTER c
LEFT  OUTER  join  DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.TRANSFORMATION_v01__VW_E31_Cleaning_DataTest_simplifie_Correction_Index corr 
on c.Numero = corr.Numero OR c.Indexs =  corr.Indexs

  );
create or replace view TRANSFORMATION_V01__VW_E31_CLEANING_DATATEST_SIMPLIFIE_CORRECTION_INDEX(
	INDEXS,
	NUMERO
) as (

  SELECT  

Indexs,
Numero 

FROM
  ---------------               Debut TABLE A ALIMENTER 
(

  
SELECT 
 TypeIndividu
,Groupe
,PreFix
,Division
,Certificat
,Numero
,Sexe
,DateNaissance
,(CASE
    WHEN DateAchat >= DateRetraite  AND (to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DATEACHAT) 
         THEN DATEDIFF(YEAR,DateNaissance, DateAchat)
    when DateAchat >= DateRetraite and (to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DATEACHAT)
		 then DATEDIFF(YEAR,  DateNaissance,  to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss'))  
	when DateAchat < DateRetraite and (to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DateRetraite )
		 then DATEDIFF(YEAR, DateNaissance, DateRetraite) 
	when DateAchat < DateRetraite and (to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DateRetraite )
		then DATEDIFF(YEAR, DateNaissance, to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')) 
END) AS AgeArrondi
,DateAchat
,DateRetraite
,MontantRente
,FormeRente
,Frequence
,(CASE
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1) in ('K','L','M','N','P') 
         THEN 'ON'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1) in ('G','H','J') 
         THEN 'QC'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'A' 
         THEN 'NL'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'B' 
         THEN 'NS'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'C' 
         THEN 'PE'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'E' 
         THEN 'NB'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'R' 
         THEN 'MB'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'S' 
         THEN 'SK'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'T' 
         THEN 'AB'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'V' 
         THEN 'BC'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'X' 
         THEN 'NT'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'Y' 
         THEN 'YT'
   ELSE        '0'
END) AS Province
,MontantRente as SommeRenteIA_IAP
,(case                  
when DateAchat>=DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DateAchat 
		then DATEDIFF(DAY,DateNaissance , DateAchat ) /365.25 
when DateAchat>=DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DateAchat 
		then DATEDIFF(DAY, DateNaissance , to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')) /365.25
when DateAchat<DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DateRetraite
		then DATEDIFF(DAY, DateNaissance , DateRetraite ) /365.25
when DateAchat<DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DateRetraite 
		then DATEDIFF(DAY, DateNaissance, to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')) /365.25
end) as Age

,Rente_Individu
,(case WHEN Survivante = 9 
           THEN -1 
      ELSE Survivante end) as Survivante
,Code_Postal
,AnneeEtude
,Indexs
,Indexs as Index_constant
,TYPE_DE_COL AS Type_col 
,Industrie
,Rente_Individu*(case Frequence when 'ANNU' then 1
							    when 'SEME' then 2 
							    when 'TRIM' then 4 
								when 'MENS' then 12 
								when 'HEBD' then 52 end) as Pseudo_Actual
FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.E30_DataTest

 
) ---------------             FIN   TABLE A ALIMENTER 

 group by Indexs, Numero 
 having count(distinct TypeIndividu)>1
   
);
create or replace view TRANSFORMATION_V01__VW_E31_CLEANING_DATATEST_SIMPLIFIE_TABLE_A_ALIMENTER(
	TYPEINDIVIDU,
	GROUPE,
	PREFIX,
	DIVISION,
	CERTIFICAT,
	NUMERO,
	SEXE,
	DATENAISSANCE,
	AGEARRONDI,
	DATEACHAT,
	DATERETRAITE,
	MONTANTRENTE,
	FORMERENTE,
	FREQUENCE,
	PROVINCE,
	SOMMERENTEIA_IAP,
	AGE,
	RENTE_INDIVIDU,
	SURVIVANTE,
	CODE_POSTAL,
	ANNEEETUDE,
	INDEXS,
	INDEX_CONSTANT,
	TYPE_COL,
	INDUSTRIE,
	PSEUDO_ACTUAL
) as (

   
SELECT 
 TypeIndividu
,Groupe
,PreFix
,Division
,Certificat
,Numero
,Sexe
,DateNaissance
,(CASE
    WHEN DateAchat >= DateRetraite  AND (to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DATEACHAT) 
         THEN DATEDIFF(YEAR,DateNaissance, DateAchat)
    when DateAchat >= DateRetraite and (to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DATEACHAT)
		 then DATEDIFF(YEAR,  DateNaissance,  to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss'))  
	when DateAchat < DateRetraite and (to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DateRetraite )
		 then DATEDIFF(YEAR, DateNaissance, DateRetraite) 
	when DateAchat < DateRetraite and (to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DateRetraite )
		then DATEDIFF(YEAR, DateNaissance, to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')) 
END) AS AgeArrondi
,DateAchat
,DateRetraite
,MontantRente
,FormeRente
,Frequence
,(CASE
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1) in ('K','L','M','N','P') 
         THEN 'ON'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1) in ('G','H','J') 
         THEN 'QC'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'A' 
         THEN 'NL'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'B' 
         THEN 'NS'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'C' 
         THEN 'PE'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'E' 
         THEN 'NB'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'R' 
         THEN 'MB'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'S' 
         THEN 'SK'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'T' 
         THEN 'AB'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'V' 
         THEN 'BC'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'X' 
         THEN 'NT'
 WHEN REGEXP_LIKE(replace(Code_Postal, ' ',''),'[A-Z][0-9][A-Z][0-9][A-Z][0-9]') AND substr(replace(Code_Postal, ' ',''), 1, 1)  = 'Y' 
         THEN 'YT'
   ELSE        '0'
END) AS Province
,MontantRente as SommeRenteIA_IAP
,(case                  
when DateAchat>=DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DateAchat 
		then DATEDIFF(DAY,DateNaissance , DateAchat ) /365.25 
when DateAchat>=DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DateAchat 
		then DATEDIFF(DAY, DateNaissance , to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')) /365.25
when DateAchat<DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DateRetraite
		then DATEDIFF(DAY, DateNaissance , DateRetraite ) /365.25
when DateAchat<DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DateRetraite 
		then DATEDIFF(DAY, DateNaissance, to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')) /365.25
end) as Age

,Rente_Individu
,(case WHEN Survivante = 9 
           THEN -1 
      ELSE Survivante end) as Survivante
,Code_Postal
,AnneeEtude
,Indexs
,Indexs as Index_constant
,TYPE_DE_COL AS Type_col 
,Industrie
,Rente_Individu*(case Frequence when 'ANNU' then 1
							    when 'SEME' then 2 
							    when 'TRIM' then 4 
								when 'MENS' then 12 
								when 'HEBD' then 52 end) as Pseudo_Actual
FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.E30_DataTest

  
);
create or replace view TRANSFORMATION_V01__VW_E40_ADD_DEMOSTATS_DATATEST_SIMPLIFIE(
	TYPEINDIVIDU,
	GROUPE,
	PREFIX,
	DIVISION,
	CERTIFICAT,
	NUMERO,
	SEXE,
	DATENAISSANCE,
	AGEARRONDI,
	DATEACHAT,
	DATERETRAITE,
	MONTANTRENTE,
	FORMERENTE,
	FREQUENCE,
	PROVINCE,
	SOMMERENTEIA_IAP,
	AGE,
	RENTE_INDIVIDU,
	SURVIVANTE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR,
	CODE_POSTAL,
	ANNEEETUDE,
	INDEXS,
	TYPE_COL,
	INDUSTRIE,
	MILIEURURAL,
	DENSITY,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE
) as (

SELECT 
              TypeIndividu
			  ,Groupe
			  ,PreFix
			  ,Division
			  ,Certificat
			  ,Numero
			  ,Sexe
			  ,DateNaissance
			  ,AgeArrondi
			  ,DateAchat
			  ,DateRetraite
			  ,MontantRente
			  ,FormeRente
			  ,Frequence
			  ,Province
			  ,SommeRenteIA_IAP
			  ,Age
			  ,Rente_Individu
			  ,Survivante
			  , Pseudo_Actual
			  , Pseudo_Actual_IBNR
			  ,Code_Postal
			  ,AnneeEtude
			  ,Indexs
			  ,Type_col
			  ,Industrie
         , case when ch3.CODE is not null and substring(de.Code_postal,2,1) = '0' 
                     then 'Rural'
			    when ch3.CODE is not null and substring(de.Code_postal,2,1) <> '0' 
                     then 'Urbain'
			    else null end as MilieuRural
             
        ,  case when ch3.TotalLandArea<>0 then ch3.TotalPopulation/ch3.TotalLandArea end  AS density
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.TotalArea), ch6.TotalArea)  AS TotalArea  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.TotalLandArea), ch6.TotalLandArea) AS TotalLandArea  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.TotalPopulation), ch6.TotalPopulation) AS TotalPopulation 
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Nb_InLabourForce), ch6.Nb_InLabourForce)AS Nb_InLabourForce 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Prop_InLabourForce), ch6.Prop_InLabourForce)AS Prop_InLabourForce  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Avg_Age_CP), ch6.Avg_Age_CP)AS Avg_Age_CP  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Med_Age_CP), ch6.Med_Age_CP)AS  Med_Age_CP  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Avg_AgeMale_CP), ch6.Avg_AgeMale_CP)AS  Avg_AgeMale_CP  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Med_AgeMale_CP), ch6.Med_AgeMale_CP)AS Med_AgeMale_CP 
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Avg_AgeFem_CP), ch6.Avg_AgeFem_CP)AS Avg_AgeFem_CP 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Med_AgeFem_CP), ch6.Med_AgeFem_CP)AS Med_AgeFem_CP  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Avg_nb_PrivateHouse), ch6.Avg_nb_PrivateHouse)AS  Avg_nb_PrivateHouse 
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Prop_65_Years_Or_Over_Living_Alone), ch6.Prop_65_Years_Or_Over_Living_Alone)AS  Prop_65_Years_Or_Over_Living_Alone 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Nb_In_couple), ch6.Nb_In_couple)AS Nb_In_couple  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Prop_In_couple), ch6.Prop_In_couple)AS Prop_In_couple  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Prop_Married), ch6.Prop_Married)AS Prop_Married 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Prop_CommonLaw), ch6.Prop_CommonLaw)AS Prop_CommonLaw 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Nb_Widowed), ch6.Nb_Widowed)AS Nb_Widowed  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Prop_Widowed), ch6.Prop_Widowed)AS Prop_Widowed  
		,IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Avg_children_per_househould), ch6.Avg_children_per_househould)AS  Avg_children_per_househould  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Non_Movers), ch6.Non_Movers)AS Non_Movers 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Movers), ch6.Movers)AS Movers  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Owned), ch6.Owned)AS Owned  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Rented), ch6.Rented)AS Rented 
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Band_Housing), ch6.Band_Housing)AS Band_Housing 
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Avg_Household_Income_2015), ch6.Avg_Household_Income_2015)AS Avg_Household_Income_2015 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Med_Household_Income_2015), ch6.Med_Household_Income_2015)AS Med_Household_Income_2015  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Avg_Household_Income_Curr), ch6.Avg_Household_Income_Curr)AS Avg_Household_Income_Curr 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Med_Household_Income_Curr), ch6.Med_Household_Income_Curr)AS Med_Household_Income_Curr  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Avg_Income), ch6.Avg_Income)AS Avg_Income  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_over_15_No_diploma), ch6.prop_over_15_No_diploma)AS prop_over_15_No_diploma 
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_over_15_High_School), ch6.prop_over_15_High_School)AS prop_over_15_High_School 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_over_15_Apprenticeship), ch6.prop_over_15_Apprenticeship)AS prop_over_15_Apprenticeship  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_over_15_CEGEP), ch6.prop_over_15_CEGEP)AS prop_over_15_CEGEP  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_over_15_Below_Bach), ch6.prop_over_15_Below_Bach)AS prop_over_15_Below_Bach 
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_over_15_University), ch6.prop_over_15_University)AS prop_over_15_University 
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_25_64_No_diploma), ch6.prop_25_64_No_diploma)AS  prop_25_64_No_diploma  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_25_64_High_School), ch6.prop_25_64_High_School)AS prop_25_64_High_School  
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_25_64_Apprenticeship), ch6.prop_25_64_Apprenticeship)AS prop_25_64_Apprenticeship  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_25_64_CEGEP), ch6.prop_25_64_CEGEP)AS  prop_25_64_CEGEP 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_25_64_Below_Bach), ch6.prop_25_64_Below_Bach)AS  prop_25_64_Below_Bach 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.prop_25_64_University), ch6.prop_25_64_University)AS  prop_25_64_University  
		,  IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Employment_Rate), ch6.Employment_Rate)AS Employment_Rate 
		, IFF(ch6.GEO is null, IFF(ch3.GEO is null, null, ch3.Unemployment_Rate), ch6.Unemployment_Rate)AS Unemployment_Rate  
		
          
              
FROM      DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.E31_DataTest de
left join DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.E00_ATTRIBUTSPERTINENTSDEMOSTATS ch6 
      on (ch6.CODE = REPLACE(de.Code_postal, ' ' , '') and ch6.GEO = 'FSALDU' and ch6.TotalPopulation is not null and ch6.TotalPopulation > 0)
left join DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.E00_ATTRIBUTSPERTINENTSDEMOSTATS ch3 
      on (ch3.CODE = substring(de.Code_Postal, 1, 3) and ch3.GEO = 'FSAQ417')
  );
create or replace view TRANSFORMATION_V01__VW_E50_TEMPS_MENSUEL(
	TYPEINDIVIDU,
	GROUPE,
	PREFIX,
	DIVISION,
	CERTIFICAT,
	NUMERO,
	SEXE,
	DATENAISSANCE,
	AGEARRONDI,
	DATEACHAT,
	DATERETRAITE,
	MONTANTRENTE,
	FORMERENTE,
	FREQUENCE,
	PROVINCE,
	SOMMERENTEIA_IAP,
	AGE,
	RENTE_INDIVIDU,
	SURVIVANTE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR,
	CODE_POSTAL,
	ANNEEETUDE,
	INDEXS,
	TYPE_COL,
	INDUSTRIE,
	MILIEURURAL,
	DENSITY,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE,
	MONTANTRENTEIA_IAP_VIAG,
	MONTANTRENTEIA_IAP_CONJ,
	MONTANTRENTEINDIVIDU_VIAG,
	MONTANTRENTEINDIVIDU_CONJ,
	RENTEINDIVIDU_MENSUEL,
	NB_OCCURANCES_DDN_INDEX,
	NB_OCCURANCES_INDEX,
	DATE_CALCUL_AGE,
	PROVINCE_NULL
) as 
(

 SELECT  *
	  ,case when FormeRente = 'VIAG' then SommeRenteIA_IAP else 0 end as MontantRenteIA_IAP_VIAG -- Déjà mensuel
      ,case when FormeRente = 'CONJ' then SommeRenteIA_IAP else 0 end as MontantRenteIA_IAP_CONJ -- Déjà mensuel

	  ,case when FormeRente = 'VIAG' and Frequence = 'ANNU' then Rente_Individu/12 
			when FormeRente = 'VIAG' and Frequence = 'SEME' then Rente_Individu/6 
			when FormeRente = 'VIAG' and Frequence = 'TRIM' then Rente_Individu/3 
			when FormeRente = 'VIAG' and Frequence = 'MENS' then Rente_Individu 
			when FormeRente = 'VIAG' and Frequence = 'HEBD' then Rente_Individu*52/12 
			else 0 end as MontantRenteIndividu_VIAG

	  ,case when FormeRente = 'CONJ' and Frequence = 'ANNU' then Rente_Individu/12 
			when FormeRente = 'CONJ' and Frequence = 'SEME' then Rente_Individu/6 
			when FormeRente = 'CONJ' and Frequence = 'TRIM' then Rente_Individu/3 
			when FormeRente = 'CONJ' and Frequence = 'MENS' then Rente_Individu 
			when FormeRente = 'CONJ' and Frequence = 'HEBD' then Rente_Individu*52/12 
			else 0 end as MontantRenteIndividu_CONJ

	  ,case when Frequence = 'ANNU' then Rente_Individu/12 
			when Frequence = 'SEME' then Rente_Individu/6 
			when Frequence = 'TRIM' then Rente_Individu/3 
			when Frequence = 'MENS' then Rente_Individu 
			when Frequence = 'HEBD' then Rente_Individu*52/12 
			else 0 end as RenteIndividu_Mensuel
      ,count(1) over (partition by Indexs, Sexe, DateNaissance, AnneeEtude) as Nb_occurances_DDN_Index
	  ,count(1) over (partition by Indexs, Sexe) as Nb_occurances_Index
      
      ,case 
    when DateAchat>=DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DateAchat
	      then DateAchat  
	when DateAchat>=DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DateAchat 
			then to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')
	when DateAchat<DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') < DateRetraite 
			then DateRetraite 
	when DateAchat<DateRetraite and to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss') >= DateRetraite 
			then to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')
	else to_timestamp_ntz( ANNEEETUDE||'-01-01 00:00:00', 'yyyy-mm-dd hh:mi:ss')
end as Date_Calcul_Age
     ,case when Province = 'Ne sait pas' then  null else Province end as Province_null

FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.E40_DataTest
  );
create or replace view TRANSFORMATION_V01__VW_E50_TMP(
	ANNEEETUDE,
	INDEXS,
	SEXE,
	DATENAISSANCE,
	DATE_CALCUL_AGE,
	AGEARRONDI,
	MONTANTRENTE,
	TYPE_COL,
	PROVINCE,
	MONTANTRENTEIA_IAP_VIAG,
	MONTANTRENTEIA_IAP_CONJ,
	MONTANTRENTEIA_IAP_TOTAL,
	MONTANTRENTEINDIVIDU_VIAG,
	MONTANTRENTEINDIVIDU_CONJ,
	MONTANTRENTEINDIVIDU_TOTAL,
	SURVIVANTE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR,
	PSEUDO_ACTUAL_IBNR_LIM,
	MILIEURURAL,
	DENSITY,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE,
	QX_INDUSTRIE,
	FORMERENTE,
	CATEGORIETARIF,
	AGEACHAT
) as (


SELECT  
      AnneeEtude
      ,Indexs
	  ,Sexe
      ,DateNaissance as DateNaissance
	  ,max(Date_Calcul_Age) as Date_Calcul_Age
      ,min(AgeArrondi) as AgeArrondi
      ,sum(MontantRente) as MontantRente

	  ,Type_col as Type_col
	  ,Province
      ,sum(MontantRenteIA_IAP_VIAG) as MontantRenteIA_IAP_VIAG    
      ,sum(MontantRenteIA_IAP_CONJ) as MontantRenteIA_IAP_CONJ
	  ,sum(SommeRenteIA_IAP) as MontantRenteIA_IAP_Total
	  ,sum(MontantRenteIndividu_VIAG) as MontantRenteIndividu_VIAG    
      ,sum(MontantRenteIndividu_CONJ) as MontantRenteIndividu_CONJ
	  ,sum(RenteIndividu_Mensuel) as MontantRenteIndividu_Total
      ,max(Survivante) as Survivante--permet de selectionner la meilleure valeur pour un meme individu
	  ,sum(Pseudo_Actual) as Pseudo_Actual
	  ,sum(Pseudo_Actual_IBNR) as Pseudo_Actual_IBNR
	  ,sum(Pseudo_Actual_IBNR) as Pseudo_Actual_IBNR_lim
	  ,min(milieuRural) as milieuRural --Si deux codes postaux avec Urbain et rural sont liés a la meme personne, on choisi Rural
	  ,avg(density) as density
      ,avg(TotalArea) as TotalArea
      ,avg(TotalLandArea) as TotalLandArea
      ,avg(TotalPopulation) as TotalPopulation
      ,avg(Nb_InLabourForce) as Nb_InLabourForce
      ,avg(Prop_InLabourForce) as Prop_InLabourForce
      ,avg(Avg_Age_CP) as Avg_Age_CP
      ,avg(Med_Age_CP) as Med_Age_CP
      ,avg(Avg_AgeMale_CP) as Avg_AgeMale_CP
      ,avg(Med_AgeMale_CP) as Med_AgeMale_CP
      ,avg(Avg_AgeFem_CP) as Avg_AgeFem_CP
      ,avg(Med_AgeFem_CP) as Med_AgeFem_CP
      ,avg(Avg_nb_PrivateHouse) as Avg_nb_PrivateHouse
      ,avg(Prop_65_Years_Or_Over_Living_Alone) as Prop_65_Years_Or_Over_Living_Alone
      ,avg(Nb_In_couple) as Nb_In_couple
      ,avg(Prop_In_couple) as Prop_In_couple
	  ,avg(Prop_Married) as Prop_Married
	  ,avg(Prop_CommonLaw) as Prop_CommonLaw
      ,avg(Nb_Widowed) as Nb_Widowed
      ,avg(Prop_Widowed) as Prop_Widowed
      ,avg(Avg_children_per_househould) as Avg_children_per_househould
      ,avg(Non_Movers) as Non_Movers
      ,avg(Movers) as Movers
      ,avg(Owned) as Owned
      ,avg(Rented) as Rented
      ,avg(Band_Housing) as Band_Housing
      ,avg(Avg_Household_Income_2015) as Avg_Household_Income_2015
      ,avg(Med_Household_Income_2015) as Med_Household_Income_2015
      ,avg(Avg_Household_Income_Curr) as Avg_Household_Income_Curr
      ,avg(Med_Household_Income_Curr) as Med_Household_Income_Curr
      ,avg(Avg_Income) as Avg_Income
      ,avg(prop_over_15_No_diploma) as prop_over_15_No_diploma
      ,avg(prop_over_15_High_School) as prop_over_15_High_School
      ,avg(prop_over_15_Apprenticeship) as prop_over_15_Apprenticeship
      ,avg(prop_over_15_CEGEP) as prop_over_15_CEGEP 
      ,avg(prop_over_15_Below_Bach) as prop_over_15_Below_Bach
      ,avg(prop_over_15_University) as prop_over_15_University
      ,avg(prop_25_64_No_diploma) as prop_25_64_No_diploma
      ,avg(prop_25_64_High_School) as prop_25_64_High_School
      ,avg(prop_25_64_Apprenticeship) as prop_25_64_Apprenticeship
      ,avg(prop_25_64_CEGEP) as prop_25_64_CEGEP
      ,avg(prop_25_64_Below_Bach) as prop_25_64_Below_Bach
      ,avg(prop_25_64_University) as prop_25_64_University
      ,avg(Employment_Rate) as Employment_Rate
      ,avg(Unemployment_Rate) as Unemployment_Rate
	  ,cast(null as numeric(38,6)) as Qx_Industrie
	  ,'    ' as FormeRente
	  ,'                         ' as CategorieTarif
	  ,0 as AgeAchat 

  FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.TRANSFORMATION_v01__VW_E50_TEMPS_MENSUEL
  group  by
       AnneeEtude
      ,Indexs
	  ,Sexe
	  ,DateNaissance
	  ,Province
	  ,Type_col
	
  );
create or replace view TRANSFORMATION_V01__VW_E50_TMP_BEFORE_QX_DE_LINDUSTRIE(
	ANNEEETUDE,
	INDEXS,
	SEXE,
	DATENAISSANCE,
	DATE_CALCUL_AGE,
	AGEARRONDI,
	MONTANTRENTE,
	TYPE_COL,
	PROVINCE,
	MONTANTRENTEIA_IAP_VIAG,
	MONTANTRENTEIA_IAP_CONJ,
	MONTANTRENTEIA_IAP_TOTAL,
	MONTANTRENTEINDIVIDU_VIAG,
	MONTANTRENTEINDIVIDU_CONJ,
	MONTANTRENTEINDIVIDU_TOTAL,
	SURVIVANTE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR,
	PSEUDO_ACTUAL_IBNR_LIM,
	MILIEURURAL,
	DENSITY,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE,
	QX_INDUSTRIE,
	FORMERENTE,
	CATEGORIETARIF,
	AGEACHAT,
	AGE,
	AGEATTEINT
) as

(
  
  
  
  

SELECT * 
       ,  ar.Age as AgeAtteint

FROM 
(      ------ E50_TEMP  UPDATED 
SELECT * 
     ,(case 
     when MontantRenteIA_IAP_VIAG > MontantRenteIA_IAP_CONJ  then 'VIAG' 
     else 'CONJ' 
     end ) AS FormeRente  
	 ,( case when MontantRenteIA_IAP_CONJ >= MontantRenteIA_IAP_VIAG then 'CONJ'  when Survivante=1 then 'VIAG Survivant' else 'VIAG Non-Survivant' end) AS CategorieTarif
     ,DATEDIFF(DAY,DateNaissance,Date_Calcul_Age) /365.25  AS AgeAchat



FROM 
     (      -- E50_TEMP


      SELECT  
      AnneeEtude
      ,Indexs
	  ,Sexe
      ,DateNaissance as DateNaissance
	  ,max(Date_Calcul_Age) as Date_Calcul_Age
      ,min(AgeArrondi) as AgeArrondi
      ,sum(MontantRente) as MontantRente

	  ,Type_col as Type_col
	  ,Province
      ,sum(MontantRenteIA_IAP_VIAG) as MontantRenteIA_IAP_VIAG    
      ,sum(MontantRenteIA_IAP_CONJ) as MontantRenteIA_IAP_CONJ
	  ,sum(SommeRenteIA_IAP) as MontantRenteIA_IAP_Total
	  ,sum(MontantRenteIndividu_VIAG) as MontantRenteIndividu_VIAG    
      ,sum(MontantRenteIndividu_CONJ) as MontantRenteIndividu_CONJ
	  ,sum(RenteIndividu_Mensuel) as MontantRenteIndividu_Total
      ,max(Survivante) as Survivante--permet de selectionner la meilleure valeur pour un meme individu
	  ,sum(Pseudo_Actual) as Pseudo_Actual
	  ,sum(Pseudo_Actual_IBNR) as Pseudo_Actual_IBNR
	  ,sum(Pseudo_Actual_IBNR) as Pseudo_Actual_IBNR_lim
	  ,min(milieuRural) as milieuRural --Si deux codes postaux avec Urbain et rural sont liés a la meme personne, on choisi Rural
	  ,avg(density) as density
      ,avg(TotalArea) as TotalArea
      ,avg(TotalLandArea) as TotalLandArea
      ,avg(TotalPopulation) as TotalPopulation
      ,avg(Nb_InLabourForce) as Nb_InLabourForce
      ,avg(Prop_InLabourForce) as Prop_InLabourForce
      ,avg(Avg_Age_CP) as Avg_Age_CP
      ,avg(Med_Age_CP) as Med_Age_CP
      ,avg(Avg_AgeMale_CP) as Avg_AgeMale_CP
      ,avg(Med_AgeMale_CP) as Med_AgeMale_CP
      ,avg(Avg_AgeFem_CP) as Avg_AgeFem_CP
      ,avg(Med_AgeFem_CP) as Med_AgeFem_CP
      ,avg(Avg_nb_PrivateHouse) as Avg_nb_PrivateHouse
      ,avg(Prop_65_Years_Or_Over_Living_Alone) as Prop_65_Years_Or_Over_Living_Alone
      ,avg(Nb_In_couple) as Nb_In_couple
      ,avg(Prop_In_couple) as Prop_In_couple
	  ,avg(Prop_Married) as Prop_Married
	  ,avg(Prop_CommonLaw) as Prop_CommonLaw
      ,avg(Nb_Widowed) as Nb_Widowed
      ,avg(Prop_Widowed) as Prop_Widowed
      ,avg(Avg_children_per_househould) as Avg_children_per_househould
      ,avg(Non_Movers) as Non_Movers
      ,avg(Movers) as Movers
      ,avg(Owned) as Owned
      ,avg(Rented) as Rented
      ,avg(Band_Housing) as Band_Housing
      ,avg(Avg_Household_Income_2015) as Avg_Household_Income_2015
      ,avg(Med_Household_Income_2015) as Med_Household_Income_2015
      ,avg(Avg_Household_Income_Curr) as Avg_Household_Income_Curr
      ,avg(Med_Household_Income_Curr) as Med_Household_Income_Curr
      ,avg(Avg_Income) as Avg_Income
      ,avg(prop_over_15_No_diploma) as prop_over_15_No_diploma
      ,avg(prop_over_15_High_School) as prop_over_15_High_School
      ,avg(prop_over_15_Apprenticeship) as prop_over_15_Apprenticeship
      ,avg(prop_over_15_CEGEP) as prop_over_15_CEGEP 
      ,avg(prop_over_15_Below_Bach) as prop_over_15_Below_Bach
      ,avg(prop_over_15_University) as prop_over_15_University
      ,avg(prop_25_64_No_diploma) as prop_25_64_No_diploma
      ,avg(prop_25_64_High_School) as prop_25_64_High_School
      ,avg(prop_25_64_Apprenticeship) as prop_25_64_Apprenticeship
      ,avg(prop_25_64_CEGEP) as prop_25_64_CEGEP
      ,avg(prop_25_64_Below_Bach) as prop_25_64_Below_Bach
      ,avg(prop_25_64_University) as prop_25_64_University
      ,avg(Employment_Rate) as Employment_Rate
      ,avg(Unemployment_Rate) as Unemployment_Rate
	  ,cast(null as numeric(38,6)) as Qx_Industrie
	  --,'    ' as FormeRente
	  --,'                         ' as CategorieTarif
	  --,0 as AgeAchat 

  FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.TRANSFORMATION_v01__VW_E50_TEMPS_MENSUEL
  group  by
       AnneeEtude
      ,Indexs
	  ,Sexe
	  ,DateNaissance
	  ,Province
	  ,Type_col
	
  ) -- END E50_TEMP
  ) E50   -- E50_TEMP  UPDATED 
  left join DB_AC_DEV_STG.SYPHAX_ERC_REFERENCE.AGERANGE ar on 1 = 1 ---E50.AgeAchat <= ar.Age --Produit cartésien'

  );
create or replace view TRANSFORMATION_V01__VW_E50_TMP_FINAL(
	ANNEEETUDE,
	INDEXS,
	SEXE,
	DATENAISSANCE,
	DATE_CALCUL_AGE,
	AGEARRONDI,
	MONTANTRENTE,
	TYPE_COL,
	PROVINCE,
	MONTANTRENTEIA_IAP_VIAG,
	MONTANTRENTEIA_IAP_CONJ,
	MONTANTRENTEIA_IAP_TOTAL,
	MONTANTRENTEINDIVIDU_VIAG,
	MONTANTRENTEINDIVIDU_CONJ,
	MONTANTRENTEINDIVIDU_TOTAL,
	SURVIVANTE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR,
	PSEUDO_ACTUAL_IBNR_LIM,
	MILIEURURAL,
	DENSITY,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE,
	QX_INDUSTRIE,
	FORMERENTE,
	CATEGORIETARIF,
	AGEACHAT,
	AGE,
	AGEATTEINT
) as

(
SELECT  

ANNEEETUDE,
 INDEXS,
 SEXE,
 DATENAISSANCE,
 DATE_CALCUL_AGE,
 AGEARRONDI,
 MONTANTRENTE,
 TYPE_COL,
 PROVINCE,
 MONTANTRENTEIA_IAP_VIAG,
 MONTANTRENTEIA_IAP_CONJ,
 MONTANTRENTEIA_IAP_TOTAL,
 MONTANTRENTEINDIVIDU_VIAG,
 MONTANTRENTEINDIVIDU_CONJ,
 MONTANTRENTEINDIVIDU_TOTAL,
 SURVIVANTE,
 PSEUDO_ACTUAL,
 PSEUDO_ACTUAL_IBNR,
 PSEUDO_ACTUAL_IBNR_LIM,
 MILIEURURAL,
 DENSITY,
 TOTALAREA,
 TOTALLANDAREA,
 TOTALPOPULATION,
 NB_INLABOURFORCE,
 PROP_INLABOURFORCE,
 AVG_AGE_CP,
 MED_AGE_CP,
 AVG_AGEMALE_CP,
 MED_AGEMALE_CP,
 AVG_AGEFEM_CP,
 MED_AGEFEM_CP,
 AVG_NB_PRIVATEHOUSE,
 PROP_65_YEARS_OR_OVER_LIVING_ALONE,
 NB_IN_COUPLE,
 PROP_IN_COUPLE,
 PROP_MARRIED,
 PROP_COMMONLAW,
 NB_WIDOWED,
 PROP_WIDOWED,
 AVG_CHILDREN_PER_HOUSEHOULD,
 NON_MOVERS,
 MOVERS,
 OWNED,
 RENTED,
 BAND_HOUSING,
 AVG_HOUSEHOLD_INCOME_2015,
 MED_HOUSEHOLD_INCOME_2015,
 AVG_HOUSEHOLD_INCOME_CURR,
 MED_HOUSEHOLD_INCOME_CURR,
 AVG_INCOME,
 PROP_OVER_15_NO_DIPLOMA,
 PROP_OVER_15_HIGH_SCHOOL,
 PROP_OVER_15_APPRENTICESHIP,
 PROP_OVER_15_CEGEP,
 PROP_OVER_15_BELOW_BACH,
 PROP_OVER_15_UNIVERSITY,
 PROP_25_64_NO_DIPLOMA,
 PROP_25_64_HIGH_SCHOOL,
 PROP_25_64_APPRENTICESHIP,
 PROP_25_64_CEGEP,
 PROP_25_64_BELOW_BACH,
 PROP_25_64_UNIVERSITY,
 EMPLOYMENT_RATE,
 UNEMPLOYMENT_RATE,
--QX_INDUSTRIE,         ----
  case when d.Sexe = 'M' then tm.Lx_Hommes else tm.Lx_Femmes end AS Qx_Industrie ,
 FORMERENTE,
 CATEGORIETARIF,
 AGEACHAT,
 AGE,
 d.AGEATTEINT


FROM DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY_V2.TRANSFORMATION_v01__VW_E50_TMP_before_QX_de_Lindustrie d
left join DB_AC_DEV_STG.SYPHAX_ERC_REFERENCE.GAC2012 tm on d.AgeAtteint = tm.AGEATTE
);
create or replace schema SYPHAX_ERC_MORTALITY_WKT;

create or replace schema SYPHAX_ERC_REFERENCE;

create or replace TRANSIENT TABLE AGERANGE (
	AGE FLOAT
);
create or replace TRANSIENT TABLE GAC2012 (
	AGEATTE NUMBER(38,0),
	LX_FEMMES FLOAT,
	LX_HOMMES FLOAT
);
create or replace view VW_E50_DATATEST_TO_DELETE(
	ANNEEETUDE,
	INDEXS,
	SEXE,
	DATENAISSANCE,
	DATE_CALCUL_AGE,
	AGEARRONDI,
	MONTANTRENTE,
	TYPE_COL,
	PROVINCE,
	MONTANTRENTEIA_IAP_VIAG,
	MONTANTRENTEIA_IAP_CONJ,
	MONTANTRENTEIA_IAP_TOTAL,
	MONTANTRENTEINDIVIDU_VIAG,
	MONTANTRENTEINDIVIDU_CONJ,
	MONTANTRENTEINDIVIDU_TOTAL,
	SURVIVANTE,
	PSEUDO_ACTUAL,
	PSEUDO_ACTUAL_IBNR,
	PSEUDO_ACTUAL_IBNR_LIM,
	MILIEURURAL,
	DENSITY,
	TOTALAREA,
	TOTALLANDAREA,
	TOTALPOPULATION,
	NB_INLABOURFORCE,
	PROP_INLABOURFORCE,
	AVG_AGE_CP,
	MED_AGE_CP,
	AVG_AGEMALE_CP,
	MED_AGEMALE_CP,
	AVG_AGEFEM_CP,
	MED_AGEFEM_CP,
	AVG_NB_PRIVATEHOUSE,
	PROP_65_YEARS_OR_OVER_LIVING_ALONE,
	NB_IN_COUPLE,
	PROP_IN_COUPLE,
	PROP_MARRIED,
	PROP_COMMONLAW,
	NB_WIDOWED,
	PROP_WIDOWED,
	AVG_CHILDREN_PER_HOUSEHOULD,
	NON_MOVERS,
	MOVERS,
	OWNED,
	RENTED,
	BAND_HOUSING,
	AVG_HOUSEHOLD_INCOME_2015,
	MED_HOUSEHOLD_INCOME_2015,
	AVG_HOUSEHOLD_INCOME_CURR,
	MED_HOUSEHOLD_INCOME_CURR,
	AVG_INCOME,
	PROP_OVER_15_NO_DIPLOMA,
	PROP_OVER_15_HIGH_SCHOOL,
	PROP_OVER_15_APPRENTICESHIP,
	PROP_OVER_15_CEGEP,
	PROP_OVER_15_BELOW_BACH,
	PROP_OVER_15_UNIVERSITY,
	PROP_25_64_NO_DIPLOMA,
	PROP_25_64_HIGH_SCHOOL,
	PROP_25_64_APPRENTICESHIP,
	PROP_25_64_CEGEP,
	PROP_25_64_BELOW_BACH,
	PROP_25_64_UNIVERSITY,
	EMPLOYMENT_RATE,
	UNEMPLOYMENT_RATE,
	QX_INDUSTRIE,
	FORMERENTE,
	CATEGORIETARIF,
	AGEACHAT,
	AGEATTEINT
) as (

SELECT top 5 * FROM  DB_AC_DEV_STG.SYPHAX_ERC_MORTALITY.VW_E50_DATATEST 
);
create or replace schema SYPHAX_ERC_TEST_IBM_OUTPUT;

create or replace schema SYPHAX_ERC_TOOLS;

create or replace schema TOOLS;

create or replace TABLE PLATEFORME_SCHEMA (
	BD_NAME VARCHAR(500),
	SCHEMA_NAME VARCHAR(500),
	STAGING_NAME VARCHAR(500),
	DWH_NAME VARCHAR(500),
	DM_NAME VARCHAR(500)
);
CREATE OR REPLACE PROCEDURE "SP_CONV_TOOLS_DELETE_MODELS"()
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "CALL DB_AC_DEV_STG.TOOLS.USP_TRUNCATE_MODEL_TABLES();"

 
try {

	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();
   	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "USP_TRUNCATE_MODEL_TABLES"()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

    try {
    
      var sqlCommand = "CALL USP_SCHEMA_TRUNCATE(''PLT_MODEL_SHARED'');";
      var stmt0 = snowflake.createStatement( {sqlText: sqlCommand} );    
      var res = stmt0.execute(); 
      
      sqlCommand = "CALL USP_SCHEMA_TRUNCATE(''PLT_MODEL_PRODUCT'');";
      stmt0 = snowflake.createStatement( {sqlText: sqlCommand} );   
      res = stmt0.execute(); 
      
      sqlCommand = "CALL USP_SCHEMA_TRUNCATE(''PLT_MODEL_SHOPPING'');";
      stmt0 = snowflake.createStatement( {sqlText: sqlCommand} );   
      res = stmt0.execute(); 
      
      return "Les tables MODELS ont été tronquées avec succès";

     } catch (error) {
    
        return "Erreur: " + error.message;
     
    };
';