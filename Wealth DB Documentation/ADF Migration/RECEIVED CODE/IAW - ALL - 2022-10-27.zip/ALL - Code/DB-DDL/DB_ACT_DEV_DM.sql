create or replace database DB_ACT_DEV_DM;

create or replace schema DATALAKE;

create or replace schema DM_ERC;

create or replace TABLE DIM_DATE (
	ID_DIM_DATE NUMBER(8,0) NOT NULL COMMENT 'Identifiant Date du jour',
	SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Date en format court français selon les paramêtres régionaux, ex: 2016-02-14',
	SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Date en format court anglais selon les paramêtres régionaux, ex: 02/14/2016',
	NAME_FR VARCHAR(50) NOT NULL COMMENT 'Date en format long français selon les paramêtres régionaux, ex: 14 février 2016',
	NAME_EN VARCHAR(50) NOT NULL COMMENT 'Date en format long anglais selon les paramêtres régionaux, ex: Saturday, February 14, 2016',
	WEEK_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro de journée dans la semaine ISO (Lundi=1, Dimanche=7)',
	MONTH_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le mois (1 à 31)',
	QUARTER_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le trimestre (1 à 91)',
	SEMESTER_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le semestre (1 à 184)',
	YEAR_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans l''année (1 à 366)',
	DAY_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom abrégé français de la journée de la semaine, ex: dim.',
	DAY_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom abrégé anglais de la journée de la semaine, ex: Sun',
	DAY_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la journée de la semaine, ex: \"\"dimanche\"\"',
	DAY_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la journée de la semaine, ex: \"\"Sunday\"\"',
	WEEKEND_IND BOOLEAN NOT NULL COMMENT 'Indique si la journée est un jour de fin de semaine (samedi ou dimanche)',
	WEEK_CD VARCHAR(10) NOT NULL COMMENT 'Code de la semaine sous la forme aaaaSnn, ex: 2016S01',
	WEEK_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro de la semaine dans l''année; 53 possible',
	WEEK_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français de la semaine, ex: \"\"Sem. 12\"\"',
	WEEK_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais de la semaine, ex: \"\"Wk 12\"\"',
	WEEK_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la semaine, ex: \"\"Semaine 12\"\"',
	WEEK_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la semaine, ex: \"\"Week 12\"\"',
	WEEK_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français de la semaine dans l''année, ex: \"\"2016, Sem. 12\"\"',
	WEEK_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais de la semaine dans l''année, ex: \"\"2016, Wk. 12\"\"',
	WEEK_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la semaine dans l''année, ex: \"\"2016, Semaine 12\"\"',
	WEEK_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la semaine dans l''année, ex: \"\"2016, Week 12\"\"',
	WEEK_START_DT DATE NOT NULL COMMENT 'Date du début de la semaine ',
	WEEK_END_DT DATE NOT NULL COMMENT 'Date de la fin de la semaine ',
	WEEK_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours de la semaine ',
	MONTH_CD VARCHAR(10) NOT NULL COMMENT 'Code du mois sous la forme aaaaMnn, ex: 2016M05',
	MONTH_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du mois (1 à 12)',
	MONTH_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du mois, ex: \"\"janv.\"\"',
	MONTH_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du mois,  ex: \"\"Jan\"\"',
	MONTH_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du mois, ex: Janvier\"\"',
	MONTH_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du mois, ex: January\"\"',
	MONTH_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du mois de l''année, ex: \"\"janv. 2016\"\"',
	MONTH_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du mois de l''année, ex: \"\"Jan 2016\"\"',
	MONTH_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du mois de l''année, ex: \"\"janvier 2016\"\"',
	MONTH_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du mois de l''année, ex: \"\"January 2016\"\"',
	MONTH_START_DT DATE NOT NULL COMMENT 'Date du début du mois',
	MONTH_END_DT DATE NOT NULL COMMENT 'Date de fin du mois',
	MONTH_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours du mois',
	QUARTER_CD VARCHAR(10) NOT NULL COMMENT 'Code du trimestre sous la forme aaaaQnn, ex: 2016Q03',
	QUARTER_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du trimestre (1 à 4)',
	QUARTER_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du trimestre, ex : \"\"T1\"\"',
	QUARTER_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du trimestre, ex : \"\"Q1\"\"',
	QUARTER_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du trimestre, ex : \"\"Trimestre 1\"\"',
	QUARTER_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du trimestre, ex : \"\"Quarter 1\"\"',
	QUARTER_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du trimestre de l''année , ex : \"\"T1, 2016\"\"',
	QUARTER_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du trimestre de l''année, ex : \"\"Q1, 2016\"\"',
	QUARTER_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du trimestre de l''année , ex : \"\"Trimestre 1, 2016\"\"',
	QUARTER_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du trimestre de l''année , ex : \"\"Quarter 1, 2016\"\"',
	QUARTER_START_DT DATE NOT NULL COMMENT 'Date de début du trimestre',
	QUARTER_END_DT DATE NOT NULL COMMENT 'Date de fin du trimestre',
	QUARTER_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours dans le trimeste (90, 91 ou 92)',
	SEMESTER_CD VARCHAR(10) NOT NULL COMMENT 'Code de semestre sous la forme aaaaSnn, ex: 2016S01 ou 2016S02 (du 1 janvier au 30 juin et 1 juillet au 31 décembre)',
	SEMESTER_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du semestre (1 ou 2)',
	SEMESTER_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du semestre, ex: \"\"S1\"\"',
	SEMESTER_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du semestre, ex: \"\"S1\"\"',
	SEMESTER_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du semestre, ex: \"\"Semestre 1\"\"',
	SEMESTER_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du semestre, ex: \"\"Semester 1\"\"',
	SEMESTER_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du semestre dans l''année, ex: \"\"S1, 2016\"\"',
	SEMESTER_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du semestre dans l''année, ex: \"\"S1, 2016\"\"',
	SEMESTER_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du semestre dans l''année, ex: \"\"Semestre 1, 2016\"\"',
	SEMESTER_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du semestre dans l''année, ex: \"\"Semester 1, 2016\"\"',
	SEMESTER_START_DT DATE NOT NULL COMMENT 'Date de début du semestre',
	SEMESTER_END_DT DATE NOT NULL COMMENT 'Date de fin du semestre',
	SEMESTER_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours dans le semestre (183 ou 184)',
	YEAR_CD NUMBER(38,0) NOT NULL COMMENT 'Code de l''année sous la forme aaaa',
	YEAR_SHORT_NAME_FR VARCHAR(4) NOT NULL COMMENT 'Nom court français de l''année, ex: 2016',
	YEAR_SHORT_NAME_EN VARCHAR(4) NOT NULL COMMENT 'Nom court anglais de l''année, ex: 2016',
	YEAR_NAME_FR VARCHAR(4) NOT NULL COMMENT 'Nom long français de l''année, ex: 2016',
	YEAR_NAME_EN VARCHAR(4) NOT NULL COMMENT 'Nom long anglais de l''année, ex: 2016',
	YEAR_START_DT DATE NOT NULL COMMENT 'Date de début de l''année, ex: 2016-01-01',
	YEAR_END_DT DATE NOT NULL COMMENT 'Date de fin de l''année, ex: 2016-12-31',
	YEAR_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours de l''année',
	constraint PK_DIM_DATE primary key (ID_DIM_DATE)
);
create or replace TABLE DIM_EVENEMENT_AU_DECES (
	SK_ID_DIM_EVENEMENT_AU_DECES NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	CD_EVENEMENT_AU_DECES VARCHAR(50) NOT NULL COMMENT 'Code évènement au décès',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_STATUS primary key (SK_ID_DIM_EVENEMENT_AU_DECES)
)COMMENT='Table de dimension contenant la liste des Code évènement au décès.'
;
create or replace TABLE DIM_GROUPE_CSM (
	SK_ID_DIM_GROUPE_CSM NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	GROUPE_CSM_NOM VARCHAR(100) NOT NULL COMMENT 'Nom du groupe CSM',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_GROUPE_CSM primary key (SK_ID_DIM_GROUPE_CSM)
)COMMENT='Table de dimension contenant la liste des groupes CSM (Marge de Service Contractuelle) assignés aux couvertures (directe et réssurance) lors de leur première valorisation.'
;
create or replace TABLE DIM_PARTICIPANT_RENTES (
	SK_ID_DIM_PARTICIPANT_RENTES NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	CONTRAT_NO VARCHAR(5) NOT NULL COMMENT 'Numero de contrat d''assurance',
	CONTRAT_PREFIXE_CD VARCHAR(2) NOT NULL COMMENT 'Prefixe code de contrat d''assurance',
	DIVISION_NO VARCHAR(3) NOT NULL COMMENT 'Numero de division.',
	PARTICIPANT_NO VARCHAR(10) NOT NULL COMMENT 'Numero participant.',
	RENTE_NO VARCHAR(20) NOT NULL COMMENT 'Numero de rentes,',
	COMPANIE_CD VARCHAR(3) NOT NULL COMMENT 'Companie code.',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_PARTICIPANT_RENTES primary key (SK_ID_DIM_PARTICIPANT_RENTES)
)COMMENT='Table de dimension contenant la liste des participants et des rentes.'
;
create or replace TABLE DIM_POLICE (
	SK_ID_DIM_POLICE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	POLICY_ID VARCHAR(50) NOT NULL COMMENT 'Identifiant unique de la police.  Clé d''affaire de la police dans la table de dimension pour faciliter les requêtes.',
	POLICY_ID_EX VARCHAR(50) NOT NULL COMMENT 'Identifiant complémentaire de la police utilisé par AXIS (fait le pont avec l''entrepôt et les systèmes admin)',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_POLICE primary key (SK_ID_DIM_POLICE)
)COMMENT='Table de dimension contenant la liste des policy.'
;
create or replace TABLE DIM_PRODUIT (
	SK_ID_DIM_PRODUIT NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	PRODUIT VARCHAR(100) NOT NULL COMMENT 'Produit',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_PRODUIT primary key (SK_ID_DIM_PRODUIT)
)COMMENT='Table de dimension contenant la liste des produits.'
;
create or replace TABLE DIM_REASSUREUR (
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	REASSUREUR_CD VARCHAR(4) NOT NULL COMMENT 'Cod de reassureur.',
	REASSUREUR_NOM VARCHAR(50) NOT NULL COMMENT 'Nom de reassureur.',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_REASSUREUR primary key (SK_ID_DIM_REASSUREUR)
)COMMENT='Table de dimension contenant la liste des identifiants des compagnies de réassurance.'
;
create or replace TABLE DIM_SEX (
	SK_ID_DIM_SEX NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	SEX_CD VARCHAR(10) NOT NULL COMMENT 'Code identifiant le genre de l''assuré.',
	SEXE_NOM VARCHAR(50) NOT NULL COMMENT 'Nom du genre de l''assuré',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_SEX_PK primary key (SK_ID_DIM_SEX)
);
create or replace TABLE DIM_STATUS (
	SK_ID_DIM_STATUS NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	STATUS VARCHAR(50) NOT NULL COMMENT 'Status',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_STATUS primary key (SK_ID_DIM_STATUS)
)COMMENT='Table de dimension contenant la liste des status.'
;
create or replace TABLE DIM_TERRITOIRE (
	SK_ID_DIM_TERRITOIRE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	PAYS_CD VARCHAR(10) NOT NULL COMMENT 'Code identifiant le pays',
	PAYS_NOM VARCHAR(50) NOT NULL COMMENT 'Nom du pays',
	PROVINCE_ETAT_CD VARCHAR(10) NOT NULL COMMENT 'Code province ou état',
	PROVINCE_ETAT_NOM VARCHAR(50) NOT NULL COMMENT 'Nom province ou état',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_TERRITOIRE primary key (SK_ID_DIM_TERRITOIRE)
)COMMENT='Cette table contient la liste des  provinces/états groupés par pays.'
;
create or replace TABLE DIM_TRANSACTION_CODE (
	SK_ID_DIM_TRANSACTION_CODE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	TRANSACTION_CD NUMBER(4,0) NOT NULL COMMENT 'Code identifiant le code de transaction',
	TRANSACTION_DESCRIPTION VARCHAR(100) NOT NULL COMMENT 'Description de transaction',
	TRANSACTION_CATEGORIE VARCHAR(100) NOT NULL COMMENT 'Code province ou état',
	TRANSACTION_DEFINITION VARCHAR(100) NOT NULL COMMENT 'Definition de transaction',
	TRANSACTION_CATEGORIE_SOE VARCHAR(50) NOT NULL COMMENT 'Categorie source of epagne de transaction',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_DIM_TRANSACTION_CODE primary key (SK_ID_DIM_TRANSACTION_CODE)
)COMMENT='Cette table contient la liste des codes des transations.'
;
create or replace TABLE FT_SOE_LIBERATION_RESERVE (
	SK_ID_FT_SOE_LIBERATION_RESERVE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_POLICE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_POLICE en utilisant la POLICY_ID',
	SK_ID_DIM_GROUPE_CSM NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_GROUPE_CSM en utilisant le GROUPE_CSM_NOM',
	ID_DIM_DATE_EMISSION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''émission',
	ID_DIM_DATE_DECES_1 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès 1',
	ID_DIM_DATE_DECES_SAISIE_1 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès saisi 1',
	SK_ID_DIM_EVENEMENT_AU_DECES_1 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_EVENEMENT_AU_DECES en utilisant le CD_EVENEMENT_AU_DECES',
	ID_DIM_DATE_DECES_2 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès 2',
	ID_DIM_DATE_DECES_SAISIE_2 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès saisi 2',
	SK_ID_DIM_EVENEMENT_AU_DECES_2 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_EVENEMENT_AU_DECES en utilisant le CD_EVENEMENT_AU_DECES',
	SK_ID_DIM_TRANSACTION_CODE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TRANSACTION_CODE en utilisant le TRANSACTION_CD',
	SK_ID_DIM_PARTICIPANT_RENTES NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table PARTICIPANT_RENTES en utilisant les champs CONTRAT_NO,CONTRAT_PREFIXE_CD,DIVISION_NO,PARTICIPANT_NO,RENTE_NO,COMPANIE_CD,',
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_REASSUREUR  en utilisant REASSUREUR_CD',
	SK_ID_DIM_TERRITOIRE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TERRITOIRE en utilisant PROVINCE_ETAT_CD',
	SK_ID_DIM_PRODUIT NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_PRODUIT en utilisant le PRODUIT',
	SK_ID_DIM_STATUS NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_STATUS en utilisant le STATUS',
	SK_ID_DIM_SEX_LIFE_1 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_SEX en utilisant le SEX_1ST_LIFE',
	SK_ID_DIM_SEX_LIFE_2 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_SEX en utilisant le SEX_2ST_LIFE',
	LIBERATION_RESERVE_DIRECTE_REELLE_BEL_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_REASSURANCE_REELLE_BEL_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_ATTENDUE_DIRECTE_BEL_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_ATTENDUE_REASSURANCE_BEL_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECTE_REELLE_RA_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_REASSURANCE_REELLE_RA_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_ATTENDUE_DIRECTE_RA_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_ATTENDUE_REASSURANCE_RA_MORTALITE NUMBER(28,10) NOT NULL,
	ECARTS_EXPERIENCE_DIRECT_MORTALITE NUMBER(28,10) NOT NULL,
	ECARTS_EXPERIENCE_REASSURANCE_MORTALITE NUMBER(28,10) NOT NULL,
	ECARTS_EXPERIENCE_NET_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_LIC_DIRECTE_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_LIC_REASSURANCE_MORTALITE NUMBER(28,10) NOT NULL,
	NOMBRE_DECES_REELS NUMBER(38,0) NOT NULL,
	NOMBRE_DECES_ATTENDUS NUMBER(38,0) NOT NULL,
	LIBERATION_MARGE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECT_REELLE_BEL_AUTRES_MOUVEMENTS NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_REASSURANCE_REELLE_BEL_AUTRES_MOUVEMENTS NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECT_REELLE_RA_AUTRES_MOUVEMENTS NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_REASSURANCE_REELLE_RA_AUTRES_MOUVEMENTS NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_CLAIMS_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_INVESTMENT_COMPONENT_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_REASSUREE_CLAIMS_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_DIRECTE_CLAIMS_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_REASSURANCE_CLAIMS_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_DIRECTE_INVESTMENT_COMPONENT_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_RETOUR_DE_PRIMES NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_REASSUREE_RETOUR_PRIMES NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECTE_REELLE_BEL_RETOUR_PRIMES NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECTE_REELLE_RA_RETOUR_PRIMES NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_REASSUREE_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_DIRECTE_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_REASSUREE_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_DIRECTE_INVESTMENT_COMPONENT_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_INVESTMENT_COMPONENT_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRIME_REELLE_DIRECTE NUMBER(28,10) NOT NULL,
	PRIME_REELLE_REASSURANCE NUMBER(28,10) NOT NULL,
	PRIME_ATTENDUE_DIRECTE NUMBER(28,10) NOT NULL,
	PRIME_ATTENDUE_REASSURANCE NUMBER(28,10) NOT NULL,
	CSM_LOSS_COMPONENT_EMISSION NUMBER(28,10) NOT NULL,
	FRAIS_ACQUISITION_ATTENDUS NUMBER(28,10) NOT NULL,
	FRAIS_ACQUISITION_REELS NUMBER(28,10) NOT NULL,
	COMMISSIONS_ATTENDUES NUMBER(28,10) NOT NULL,
	COMMISSIONS_REELLES NUMBER(28,10) NOT NULL,
	FRAIS_ADMINISTRATION_ATTRIBUABLES_ATTENDUS NUMBER(28,10) NOT NULL,
	FRAIS_ADMINISTRATION_ATTRIBUABLES_REELS NUMBER(28,10) NOT NULL,
	INTERET_SOMMES_EN_DEPOTS_REELS NUMBER(28,10) NOT NULL,
	MONTANT_RENTE NUMBER(28,10) NOT NULL,
	MONTANT_RENTE_TOTAL NUMBER(28,10) NOT NULL,
	VOLUME_PAYOUT NUMBER(28,10) NOT NULL,
	TOTAL_PAYOUT NUMBER(28,10) NOT NULL,
	AGE_1ST_LIFE_AT_ISS NUMBER(10,6) NOT NULL,
	AGE_1ST_LIFE NUMBER(10,6) NOT NULL,
	AGE_2ND_LIFE_AT_ISS NUMBER(10,6) NOT NULL,
	AGE_2ND_LIFE NUMBER(10,6) NOT NULL,
	FORM_OF_PENSION VARCHAR(4) NOT NULL,
	CD_CIE VARCHAR(1),
	STATE VARCHAR(4) NOT NULL,
	CD_TYPE_ACHAT VARCHAR(2) NOT NULL,
	POSITIVE_RESERVE VARCHAR(3) NOT NULL,
	INDICATEUR_IPC BOOLEAN NOT NULL,
	IND_BULK_CHECK BOOLEAN NOT NULL,
	IND_RENTE_NEGATIVE BOOLEAN NOT NULL,
	INDICATEUR_REASSURANCE BOOLEAN NOT NULL,
	INDICATEUR_RGDE BOOLEAN NOT NULL,
	INDICATEUR_SUIVI_ITROUVABLE_ADMIN BOOLEAN NOT NULL,
	INDICATEUR_NON_CODE BOOLEAN NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_FT_SOE_LIBERATION_RESERVE primary key (SK_ID_FT_SOE_LIBERATION_RESERVE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_DATE_ID_DIM_DATE_EMISION foreign key (ID_DIM_DATE_EMISSION) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_DATE_ID_DIM_DATE_DECES_1 foreign key (ID_DIM_DATE_DECES_1) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_DATE_ID_DIM_DATE_DECES_SAISIE_1 foreign key (ID_DIM_DATE_DECES_SAISIE_1) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_DATE_ID_DIM_DATE_DECES_2 foreign key (ID_DIM_DATE_DECES_2) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_DATE_ID_DIM_DATE_DECES_SAISIE_2 foreign key (ID_DIM_DATE_DECES_SAISIE_2) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_DIM_POLICE_SK_ID_DIM_POLICE foreign key (SK_ID_DIM_POLICE) references DB_ACT_DEV_DM.DM_ERC.DIM_POLICE(SK_ID_DIM_POLICE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_GROUPE_CSM_SK_ID_GROUPE_CSM foreign key (SK_ID_DIM_GROUPE_CSM) references DB_ACT_DEV_DM.DM_ERC.DIM_GROUPE_CSM(SK_ID_DIM_GROUPE_CSM),
	constraint FK_FT_SOE_LIBERATION_RESERVE_TRANSACTION_CODE_SK_ID_TRANSACTION_CODE foreign key (SK_ID_DIM_TRANSACTION_CODE) references DB_ACT_DEV_DM.DM_ERC.DIM_TRANSACTION_CODE(SK_ID_DIM_TRANSACTION_CODE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_PARTICIPANT_RENTES_SK_ID_PARTICIPANT_RENTES foreign key (SK_ID_DIM_PARTICIPANT_RENTES) references DB_ACT_DEV_DM.DM_ERC.DIM_PARTICIPANT_RENTES(SK_ID_DIM_PARTICIPANT_RENTES),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_REASSUREUR_SK_ID_DIM_REASSUREUR foreign key (SK_ID_DIM_REASSUREUR) references DB_ACT_DEV_DM.DM_ERC.DIM_REASSUREUR(SK_ID_DIM_REASSUREUR),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_TERRITOIRE_SK_ID_DIM_TERRITOIRE foreign key (SK_ID_DIM_TERRITOIRE) references DB_ACT_DEV_DM.DM_ERC.DIM_TERRITOIRE(SK_ID_DIM_TERRITOIRE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_PRODUIT_SK_ID_DIM_PRODUIT foreign key (SK_ID_DIM_PRODUIT) references DB_ACT_DEV_DM.DM_ERC.DIM_PRODUIT(SK_ID_DIM_PRODUIT),
	constraint FK_SOE_LIBERATION_RESERVE_DIM_STATUS_SK_ID_DIM_STATUS foreign key (SK_ID_DIM_STATUS) references DB_ACT_DEV_DM.DM_ERC.DIM_STATUS(SK_ID_DIM_STATUS),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_SEX_SK_ID_DIM_SEX_LIFE_1 foreign key (SK_ID_DIM_SEX_LIFE_1) references DB_ACT_DEV_DM.DM_ERC.DIM_SEX(SK_ID_DIM_SEX),
	constraint FK_FT_SOE_LIBERATION_RESERVE_DIM_SEX_SK_ID_DIM_SEX_LIFE_2 foreign key (SK_ID_DIM_SEX_LIFE_2) references DB_ACT_DEV_DM.DM_ERC.DIM_SEX(SK_ID_DIM_SEX)
)COMMENT='Table de faits permettant d''analyser les montants liberation reserve BRUT pour Besoin#2 .'
;
create or replace TABLE FT_SOE_LIBERATION_RESERVE_BRUT (
	SK_ID_FT_SOE_LIBERATION_RESERVE_BRUT NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	ID_DIM_DATE_EMISSION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''émission',
	ID_DIM_DATE_DECES_1 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès',
	ID_DIM_DATE_DECES_SAISIE_1 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès saisi',
	ID_DIM_DATE_DECES_2 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès',
	ID_DIM_DATE_DECES_SAISIE_2 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès saisi',
	SK_ID_DIM_POLICE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_POLICE en utilisant la POLICY_ID',
	SK_ID_DIM_GROUPE_CSM NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_GROUPE_CSM en utilisant le GROUPE_CSM_NOM',
	SK_ID_DIM_TRANSACTION_CODE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TRANSACTION_CODE en utilisant le TRANSACTION_CD',
	SK_ID_DIM_PARTICIPANT_RENTES NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table PARTICIPANT_RENTES en utilisant les champs CONTRAT_NO,CONTRAT_PREFIXE_CD,DIVISION_NO,PARTICIPANT_NO,RENTE_NO,COMPANIE_CD,',
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_REASSUREUR  en utilisant REASSUREUR_CD',
	SK_ID_DIM_TERRITOIRE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TERRITOIRE en utilisant PROVINCE_ETAT_CD',
	SK_ID_DIM_PRODUIT NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_PRODUIT en utilisant le PRODUIT',
	SK_ID_DIM_STATUS NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_STATUS en utilisant le STATUS',
	SK_ID_DIM_EVENEMENT_AU_DECES_1 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_EVENEMENT_AU_DECES en utilisant le CD_EVENEMENT_AU_DECES',
	SK_ID_DIM_EVENEMENT_AU_DECES_2 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_EVENEMENT_AU_DECES en utilisant le CD_EVENEMENT_AU_DECES',
	RESERVE_MONTH_START_BEL NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_START_RA NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_START_LIC NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_START_RETRO_DIFF NUMBER(28,10) NOT NULL,
	PREMIUM_BEL NUMBER(28,10) NOT NULL,
	INITIAL_RECOGNITION_BEL NUMBER(28,10) NOT NULL,
	INITIAL_RECOGNITION_RA NUMBER(28,10) NOT NULL,
	ACQ_EPENSE_BEL NUMBER(28,10) NOT NULL,
	INTEREST_BEL NUMBER(28,10) NOT NULL,
	INTEREST_RA NUMBER(28,10) NOT NULL,
	CLAIMS_PAYOUT_BEL NUMBER(28,10) NOT NULL,
	CLAIMS_DEATH_BENEFIT_BEL NUMBER(28,10) NOT NULL,
	CLAIMS_RETRO_DIFF NUMBER(28,10) NOT NULL,
	INVESTMENT_COMPONENT_PAYOUT_BEL NUMBER(28,10) NOT NULL,
	INVESTMENT_COMPONENT_DEATH_BENEFIT_BEL NUMBER(28,10) NOT NULL,
	INVESTMENT_COMPONENT_RETRO_DIFF NUMBER(28,10) NOT NULL,
	EXPENSE_BEL NUMBER(28,10) NOT NULL,
	MORTALITY_COST_BEL NUMBER(28,10) NOT NULL,
	MORTALITY_COST_RA NUMBER(28,10) NOT NULL,
	DECES_RACHAT_BEL NUMBER(28,10) NOT NULL,
	DECES_RACHAT_RA NUMBER(28,10) NOT NULL,
	EXPERIENCE_ADJUSTMENT_BEL NUMBER(28,10) NOT NULL,
	EXPERIENCE_ADJUSTMENT_RA NUMBER(28,10) NOT NULL,
	EXPERIENCE_ADJUSTMENT_RETRO_DIFF NUMBER(28,10) NOT NULL,
	BALANCE_BEL NUMBER(28,10) NOT NULL,
	BALANCE_RA NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_BEL NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_RA NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_LIC NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_RETRO_DIFF NUMBER(28,10) NOT NULL,
	PAYOUT_LIC NUMBER(28,10) NOT NULL,
	RELEASE_RA NUMBER(28,10) NOT NULL,
	RELEASE_LIC NUMBER(28,10) NOT NULL,
	NEW_CLAIMS_LIC NUMBER(28,10) NOT NULL,
	INDICATEUR_IPC BOOLEAN NOT NULL,
	INDICATEUR_REASSURANCE BOOLEAN NOT NULL,
	INDICATEUR_RGDE BOOLEAN NOT NULL,
	INDICATEUR_SUIVI_ITROUVABLE_ADMIN BOOLEAN NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_FT_SOE_LIBERATION_RESERVE_BRUT primary key (SK_ID_FT_SOE_LIBERATION_RESERVE_BRUT),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_DATE_ID_DIM_DATE_EMISION foreign key (ID_DIM_DATE_EMISSION) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_DATE_ID_DIM_DATE_DECES_1 foreign key (ID_DIM_DATE_DECES_1) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_DATE_ID_DIM_DATE_DECES_SAISIE_1 foreign key (ID_DIM_DATE_DECES_SAISIE_1) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_DATE_ID_DIM_DATE_DECES_2 foreign key (ID_DIM_DATE_DECES_2) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_DATE_ID_DIM_DATE_DECES_SAISIE_2 foreign key (ID_DIM_DATE_DECES_SAISIE_2) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_DIM_POLICE_SK_ID_DIM_POLICE foreign key (SK_ID_DIM_POLICE) references DB_ACT_DEV_DM.DM_ERC.DIM_POLICE(SK_ID_DIM_POLICE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_GROUPE_CSM_SK_ID_GROUPE_CSM foreign key (SK_ID_DIM_GROUPE_CSM) references DB_ACT_DEV_DM.DM_ERC.DIM_GROUPE_CSM(SK_ID_DIM_GROUPE_CSM),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_TRANSACTION_CODE_SK_ID_TRANSACTION_CODE foreign key (SK_ID_DIM_TRANSACTION_CODE) references DB_ACT_DEV_DM.DM_ERC.DIM_TRANSACTION_CODE(SK_ID_DIM_TRANSACTION_CODE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_PARTICIPANT_RENTES_SK_ID_PARTICIPANT_RENTES foreign key (SK_ID_DIM_PARTICIPANT_RENTES) references DB_ACT_DEV_DM.DM_ERC.DIM_PARTICIPANT_RENTES(SK_ID_DIM_PARTICIPANT_RENTES),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_POLICE_SK_ID_DIM_POLICE foreign key (SK_ID_DIM_POLICE) references DB_ACT_DEV_DM.DM_ERC.DIM_POLICE(SK_ID_DIM_POLICE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_GROUPE_CSM_SK_ID_DIM_GROUPE_CSM foreign key (SK_ID_DIM_GROUPE_CSM) references DB_ACT_DEV_DM.DM_ERC.DIM_GROUPE_CSM(SK_ID_DIM_GROUPE_CSM),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_TRANSACTION_CODE_SK_ID_DIM_TRANSACTION_CODE foreign key (SK_ID_DIM_TRANSACTION_CODE) references DB_ACT_DEV_DM.DM_ERC.DIM_TRANSACTION_CODE(SK_ID_DIM_TRANSACTION_CODE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_PARTICIPANT_RENTES_SK_ID_DIM_PARTICIPANT_RENTES foreign key (SK_ID_DIM_PARTICIPANT_RENTES) references DB_ACT_DEV_DM.DM_ERC.DIM_PARTICIPANT_RENTES(SK_ID_DIM_PARTICIPANT_RENTES),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_REASSUREUR_SK_ID_DIM_REASSUREUR foreign key (SK_ID_DIM_REASSUREUR) references DB_ACT_DEV_DM.DM_ERC.DIM_REASSUREUR(SK_ID_DIM_REASSUREUR),
	constraint FK_FT_SOE_LIBERATION_RESERVE_BRUT_DIM_TERRITOIRE_SK_ID_DIM_TERRITOIRE foreign key (SK_ID_DIM_TERRITOIRE) references DB_ACT_DEV_DM.DM_ERC.DIM_TERRITOIRE(SK_ID_DIM_TERRITOIRE)
)COMMENT='Table de faits permettant d''analyser les montants liberation reserve BRUT.'
;
create or replace TABLE FT_SOE_LIBERATION_RESERVE_NON_COD (
	SK_ID_FT_SOE_LIBERATION_RESERVE_NON_COD NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_POLICE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_POLICE en utilisant la POLICY_ID',
	SK_ID_DIM_GROUPE_CSM NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_GROUPE_CSM en utilisant le GROUPE_CSM_NOM',
	SK_ID_DIM_STATUS NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_STATUS en utilisant le STATUS',
	RESERVE_MONTH_START_BEL NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_START_RA NUMBER(28,10) NOT NULL,
	PREMIUM_BEL NUMBER(28,10) NOT NULL,
	INITIAL_RECOGNITION_BEL NUMBER(28,10) NOT NULL,
	INITIAL_RECOGNITION_RA NUMBER(28,10) NOT NULL,
	ACQ_EPENSE_BEL NUMBER(28,10) NOT NULL,
	INTEREST_BEL NUMBER(28,10) NOT NULL,
	INTEREST_RA NUMBER(28,10) NOT NULL,
	CLAIMS_BEL NUMBER(28,10) NOT NULL,
	INVESTMENT_COMPONENT_BEL NUMBER(28,10) NOT NULL,
	MORTALITY_COST_BEL NUMBER(28,10) NOT NULL,
	MORTALITY_COST_RA NUMBER(28,10) NOT NULL,
	EXPENSE_BEL NUMBER(28,10) NOT NULL,
	EXPERIENCE_ADJUSTMENT_BEL NUMBER(28,10) NOT NULL,
	EXPERIENCE_ADJUSTMENT_RA NUMBER(28,10) NOT NULL,
	BALANCE_BEL NUMBER(28,10) NOT NULL,
	BALANCE_RA NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_BEL NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_RA NUMBER(28,10) NOT NULL,
	RELEASE_RA NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_FT_SOE_LIBERATION_RESERVE_NON_COD primary key (SK_ID_FT_SOE_LIBERATION_RESERVE_NON_COD),
	constraint FK_FT_SOE_LIBERATION_RESERVE_NON_COD_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_NON_COD_DIM_DIM_POLICE_SK_ID_DIM_POLICE foreign key (SK_ID_DIM_POLICE) references DB_ACT_DEV_DM.DM_ERC.DIM_POLICE(SK_ID_DIM_POLICE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_NON_COD_DIM_GROUPE_CSM_SK_ID_GROUPE_CSM foreign key (SK_ID_DIM_GROUPE_CSM) references DB_ACT_DEV_DM.DM_ERC.DIM_GROUPE_CSM(SK_ID_DIM_GROUPE_CSM)
)COMMENT='Contient les montants (directe, réassurance, attendue direct, attendue réassurance des calculs de libération de réserves (Mortalité, Autres CH)'
;
create or replace TABLE FT_SOE_LIBERATION_RESERVE_REASSURANCE (
	SK_ID_FT_SOE_LIBERATION_RESERVE_REASSURANCE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	ID_DIM_DATE_EMISSION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''émission',
	ID_DIM_DATE_DECES_1 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès',
	ID_DIM_DATE_DECES_SAISIE_1 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès saisi',
	ID_DIM_DATE_DECES_2 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès',
	ID_DIM_DATE_DECES_SAISIE_2 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès saisi',
	SK_ID_DIM_POLICE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_POLICE en utilisant la POLICY_ID',
	SK_ID_DIM_GROUPE_CSM NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_GROUPE_CSM en utilisant le GROUPE_CSM_NOM',
	SK_ID_DIM_TRANSACTION_CODE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TRANSACTION_CODE en utilisant le TRANSACTION_CD',
	SK_ID_DIM_PARTICIPANT_RENTES NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table PARTICIPANT_RENTES en utilisant les champs CONTRAT_NO,CONTRAT_PREFIXE_CD,DIVISION_NO,PARTICIPANT_NO,RENTE_NO,COMPANIE_CD,',
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_REASSUREUR  en utilisant REASSUREUR_CD',
	SK_ID_DIM_TERRITOIRE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TERRITOIRE en utilisant PROVINCE_ETAT_CD',
	SK_ID_DIM_PRODUIT NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_PRODUIT en utilisant le PRODUIT',
	SK_ID_DIM_STATUS NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_STATUS en utilisant le STATUS',
	SK_ID_DIM_EVENEMENT_AU_DECES_1 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_EVENEMENT_AU_DECES en utilisant le CD_EVENEMENT_AU_DECES',
	SK_ID_DIM_EVENEMENT_AU_DECES_2 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_EVENEMENT_AU_DECES en utilisant le CD_EVENEMENT_AU_DECES',
	RESERVE_MONTH_START_BEL NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_START_RA NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_START_LIC NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_START_RETRO_DIFF NUMBER(28,10) NOT NULL,
	PREMIUM_BEL NUMBER(28,10) NOT NULL,
	INITIAL_RECOGNITION_BEL NUMBER(28,10) NOT NULL,
	INITIAL_RECOGNITION_RA NUMBER(28,10) NOT NULL,
	ACQ_EPENSE_BEL NUMBER(28,10) NOT NULL,
	INTEREST_BEL NUMBER(28,10) NOT NULL,
	INTEREST_RA NUMBER(28,10) NOT NULL,
	CLAIMS_PAYOUT_BEL NUMBER(28,10) NOT NULL,
	CLAIMS_DEATH_BENEFIT_BEL NUMBER(28,10) NOT NULL,
	PAYOUT_LIC NUMBER(28,10) NOT NULL,
	INVESTMENT_COMPONENT_RETRO_DIFF NUMBER(28,10) NOT NULL,
	EXPENSE_BEL NUMBER(28,10) NOT NULL,
	MORTALITY_COST_BEL NUMBER(28,10) NOT NULL,
	MORTALITY_COST_RA NUMBER(28,10) NOT NULL,
	DECES_RACHAT_BEL NUMBER(28,10) NOT NULL,
	DECES_RACHAT_RA NUMBER(28,10) NOT NULL,
	EXPERIENCE_ADJUSTMENT_BEL NUMBER(28,10) NOT NULL,
	EXPERIENCE_ADJUSTMENT_RA NUMBER(28,10) NOT NULL,
	EXPERIENCE_ADJUSTMENT_RETRO_DIFF NUMBER(28,10) NOT NULL,
	BALANCE_BEL NUMBER(28,10) NOT NULL,
	BALANCE_RA NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_BEL NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_RA NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_LIC NUMBER(28,10) NOT NULL,
	RESERVE_MONTH_END_RETRO_DIFF NUMBER(28,10) NOT NULL,
	RELEASE_RA NUMBER(28,10) NOT NULL,
	RELEASE_LIC NUMBER(28,10) NOT NULL,
	NEW_CLAIMS_LIC NUMBER(28,10) NOT NULL,
	CLAIMS_RETRO_DIFF NUMBER(28,10) NOT NULL,
	INDICATEUR_RGDE BOOLEAN NOT NULL,
	INDICATEUR_SUIVI_ITROUVABLE_ADMIN BOOLEAN NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint PK_FT_SOE_LIBERATION_RESERVE_REASSURANCE primary key (SK_ID_FT_SOE_LIBERATION_RESERVE_REASSURANCE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_DATE_ID_DIM_DATE_EMISSION foreign key (ID_DIM_DATE_EMISSION) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_DATE_ID_DIM_DATE_DECES_1 foreign key (ID_DIM_DATE_DECES_1) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_DATE_ID_DIM_DATE_DECES_SAISIE_1 foreign key (ID_DIM_DATE_DECES_SAISIE_1) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_DATE_ID_DIM_DATE_DECES_2 foreign key (ID_DIM_DATE_DECES_2) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_DATE_ID_DIM_DATE_DECES_SAISIE_2 foreign key (ID_DIM_DATE_DECES_SAISIE_2) references DB_ACT_DEV_DM.DM_ERC.DIM_DATE(ID_DIM_DATE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_DIM_REASSUREUR_SK_ID_DIM_REASSUREUR_SK_ID_DIM_REASSUREUR foreign key (SK_ID_DIM_REASSUREUR) references DB_ACT_DEV_DM.DM_ERC.DIM_REASSUREUR(SK_ID_DIM_REASSUREUR),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_DIM_POLICE_SK_ID_DIM_POLICE foreign key (SK_ID_DIM_POLICE) references DB_ACT_DEV_DM.DM_ERC.DIM_POLICE(SK_ID_DIM_POLICE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_GROUPE_CSM_SK_ID_GROUPE_CSM foreign key (SK_ID_DIM_GROUPE_CSM) references DB_ACT_DEV_DM.DM_ERC.DIM_GROUPE_CSM(SK_ID_DIM_GROUPE_CSM),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_TRANSACTION_CODE_SK_ID_TRANSACTION_CODE foreign key (SK_ID_DIM_TRANSACTION_CODE) references DB_ACT_DEV_DM.DM_ERC.DIM_TRANSACTION_CODE(SK_ID_DIM_TRANSACTION_CODE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_PARTICIPANT_RENTES_SK_ID_PARTICIPANT_RENTES foreign key (SK_ID_DIM_PARTICIPANT_RENTES) references DB_ACT_DEV_DM.DM_ERC.DIM_PARTICIPANT_RENTES(SK_ID_DIM_PARTICIPANT_RENTES),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_POLICE_SK_ID_DIM_POLICE foreign key (SK_ID_DIM_POLICE) references DB_ACT_DEV_DM.DM_ERC.DIM_POLICE(SK_ID_DIM_POLICE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_GROUPE_CSM_SK_ID_DIM_GROUPE_CSM foreign key (SK_ID_DIM_GROUPE_CSM) references DB_ACT_DEV_DM.DM_ERC.DIM_GROUPE_CSM(SK_ID_DIM_GROUPE_CSM),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_TRANSACTION_CODE_SK_ID_DIM_TRANSACTION_CODE foreign key (SK_ID_DIM_TRANSACTION_CODE) references DB_ACT_DEV_DM.DM_ERC.DIM_TRANSACTION_CODE(SK_ID_DIM_TRANSACTION_CODE),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_PARTICIPANT_RENTES_SK_ID_DIM_PARTICIPANT_RENTES foreign key (SK_ID_DIM_PARTICIPANT_RENTES) references DB_ACT_DEV_DM.DM_ERC.DIM_PARTICIPANT_RENTES(SK_ID_DIM_PARTICIPANT_RENTES),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_REASSUREUR_SK_ID_DIM_REASSUREUR foreign key (SK_ID_DIM_REASSUREUR) references DB_ACT_DEV_DM.DM_ERC.DIM_REASSUREUR(SK_ID_DIM_REASSUREUR),
	constraint FK_FT_SOE_LIBERATION_RESERVE_REASSURANCE_DIM_TERRITOIRE_SK_ID_DIM_TERRITOIRE foreign key (SK_ID_DIM_TERRITOIRE) references DB_ACT_DEV_DM.DM_ERC.DIM_TERRITOIRE(SK_ID_DIM_TERRITOIRE)
)COMMENT='Contient les montants (directe, réassurance, attendue direct, attendue réassurance des calculs de libération de réserves (Mortalité, Autres CH)'
;
CREATE OR REPLACE PROCEDURE "SP_CONV_DIMENSION_TABLE_ERC_INS"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "LKP_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "INSERT INTO "+ TGT_TBL + " (" + INSERT_COLS + ") SELECT " + SELECT_COLS + " FROM " + SRC_TBL + " SRC LEFT JOIN "+ LKP_TBL +" LKP ON SRC.MD_HASH_NAT_KEY = LKP.MD_HASH_NAT_KEY WHERE LKP.MD_OBSOLESCENCE_DT>=To_Date(''2999-12-30 00:00:00'' ,''YYYY-MM-DD HH24:MI:SS'') AND (LKP.MD_HASH_NAT_KEY IS NULL) OR (LKP.MD_HASHDIFF_TYPE_2 <> SRC.MD_HASHDIFF_TYPE_2);"
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";"
if (TRUNC_TBL == ''Y'')
    {
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
	
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';
CREATE OR REPLACE PROCEDURE "SP_CONV_DIMENSION_TABLE_ERC_SCD1_UPD"("ENV" VARCHAR(1000), "INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "UPD_COLS" VARCHAR(16777216), "MER_SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "MERGE INTO "+ TGT_TBL +" TGT USING ( SELECT "+ SELECT_COLS +" FROM "+ SRC_TBL +" SRC LEFT JOIN "+ TGT_TBL +" TGT ON SRC.MD_HASH_NAT_KEY = TGT.MD_HASH_NAT_KEY WHERE SRC.MD_HASH_NAT_KEY IS NOT NULL AND TGT.MD_HASH_NAT_KEY IS NOT NULL AND SRC.MD_HASHDIFF_TYPE_2 = TGT.MD_HASHDIFF_TYPE_2 AND SRC.MD_HASHDIFF_TYPE_1 <> TGT.MD_HASHDIFF_TYPE_1 AND Date_Part(YEAR, TGT.MD_OBSOLESCENCE_DT) = 2999 AND Substr(TGT.MD_HASH_NAT_KEY, 1, 1) <> ''''''''-'''''''' ) MER ON MER.MD_HASH_NAT_KEY = TGT.MD_HASH_NAT_KEY WHEN MATCHED THEN UPDATE SET "+ UPD_COLS +" WHEN NOT MATCHED THEN INSERT ("+ INSERT_COLS +") VALUES ("+ MER_SELECT_COLS +");";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";
if (TRUNC_TBL == ''Y'')
    {
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';
CREATE OR REPLACE PROCEDURE "SP_CONV_DIMENSION_TABLE_ERC_SCD2_UPD"("ENV" VARCHAR(1000), "INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "UPD_COLS" VARCHAR(16777216), "MER_SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "MERGE INTO "+ TGT_TBL +" TGT USING ( SELECT "+ SELECT_COLS +" FROM "+ SRC_TBL +" SRC LEFT JOIN "+ TGT_TBL +" TGT ON SRC.MD_HASH_NAT_KEYS = TGT.MD_HASH_NAT_KEYS WHERE SRC.MD_HASHDIFF_TYPE_2 <> TGT.MD_HASHDIFF_TYPE_2 AND TGT.MD_ACTIVATION_DT < SRC.MD_START_DT AND Date_Part(YEAR,TGT.MD_OBSOLESCENCE_DT) = 2999 AND Substr(TGT.MD_HASH_NAT_KEY, 1, 1) <> ''''-'''' ) MER ON MER.MD_HASH_NAT_KEYS = TGT.MD_HASH_NAT_KEYS WHEN MATCHED THEN UPDATE SET "+ UPD_COLS +" WHEN NOT MATCHED THEN INSERT ("+ INSERT_COLS +") VALUES ("+ MER_SELECT_COLS +");";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";

if (TRUNC_TBL == ''Y'')
    {
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';
CREATE OR REPLACE PROCEDURE "SP_CONV_FAIT_TABLE_ERC_UPD"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "UPD_COLS" VARCHAR(16777216), "MER_SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "MERGE INTO "+ TGT_TBL +" TGT USING ( SELECT "+ SELECT_COLS +" FROM "+ SRC_TBL +" SRC ) MER ON MER.MD_HASH_NAT_KEY = TGT.MD_HASH_NAT_KEY WHEN MATCHED THEN UPDATE SET "+ UPD_COLS +" WHEN NOT MATCHED THEN INSERT ("+ INSERT_COLS +") VALUES ("+ MER_SELECT_COLS +"); ";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";
if (TRUNC_TBL == ''Y'')
    {
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';
create or replace schema DM_ERC_TRAVAIL;

create or replace TABLE VW_ERC_DIM_GROUPE_CSM (
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL,
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL,
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL,
	GROUPE_CSM_NOM VARCHAR(100) NOT NULL,
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(100),
	MD_IS_ACTIVE VARCHAR(100),
	INDGARDERLIGNE VARCHAR(100)
);
create or replace TABLE VW_ERC_DIM_PARTICIPANT_RENTES (
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL,
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL,
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL,
	CONTRAT_NO VARCHAR(5) NOT NULL,
	CONTRAT_PREFIXE_CD VARCHAR(2) NOT NULL,
	DIVISION_NO VARCHAR(3) NOT NULL,
	PARTICIPANT_NO VARCHAR(10),
	RENTE_NO VARCHAR(20) NOT NULL,
	COMPANIE_CD VARCHAR(3) NOT NULL,
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(100),
	MD_IS_ACTIVE VARCHAR(100),
	IND_GARDER_LIGNE VARCHAR(100)
);
create or replace TABLE VW_ERC_DIM_POLICE (
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL,
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL,
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL,
	POLICY_ID VARCHAR(50) NOT NULL,
	POLICY_ID_EX VARCHAR(50) NOT NULL,
	MD_START_DT TIMESTAMP_LTZ(9) NOT NULL,
	MD_CREATION_DT TIMESTAMP_LTZ(9) NOT NULL,
	MD_SOURCE VARCHAR(1000) NOT NULL,
	MD_IS_ACTIVE VARCHAR(1000) NOT NULL,
	INDGARDERLIGNE VARCHAR(1000) NOT NULL
);
create or replace TABLE VW_ERC_DIM_PRODUIT (
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL,
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL,
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL,
	PRODUIT VARCHAR(100) NOT NULL,
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(100),
	MD_IS_ACTIVE VARCHAR(100),
	INDGARDERLIGNE VARCHAR(100)
);
create or replace TABLE VW_ERC_DIM_TRANSACTION_CODE (
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL,
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL,
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL,
	TRANSACTION_CD NUMBER(4,0) NOT NULL,
	TRANSACTION_DESCRIPTION VARCHAR(100) NOT NULL,
	TRANSACTION_CATEGORIE VARCHAR(100) NOT NULL,
	TRANSACTION_DEFINITION VARCHAR(100) NOT NULL,
	TRANSACTION_CATEGORIE_SOE VARCHAR(50) NOT NULL,
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(100) NOT NULL,
	MD_IS_ACTIVE VARCHAR(100) NOT NULL
);
create or replace TABLE VW_ERC_FT_SOE_LIBERATION_RESERVE (
	SK_ID_FT_SOE_LIBERATION_RESERVE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_POLICE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_POLICE en utilisant la POLICY_ID',
	SK_ID_DIM_GROUPE_CSM NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_GROUPE_CSM en utilisant le GROUPE_CSM_NOM',
	ID_DIM_DATE_EMISSION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''émission',
	ID_DIM_DATE_DECES_1 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès 1',
	ID_DIM_DATE_DECES_SAISIE_1 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès saisi 1',
	SK_ID_DIM_EVENEMENT_AU_DECES_1 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_EVENEMENT_AU_DECES en utilisant le CD_EVENEMENT_AU_DECES',
	ID_DIM_DATE_DECES_2 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès 2',
	ID_DIM_DATE_DECES_SAISIE_2 NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de décès saisi 2',
	SK_ID_DIM_EVENEMENT_AU_DECES_2 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_EVENEMENT_AU_DECES en utilisant le CD_EVENEMENT_AU_DECES',
	SK_ID_DIM_TRANSACTION_CODE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TRANSACTION_CODE en utilisant le TRANSACTION_CD',
	SK_ID_DIM_PARTICIPANT_RENTES NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table PARTICIPANT_RENTES en utilisant les champs CONTRAT_NO,CONTRAT_PREFIXE_CD,DIVISION_NO,PARTICIPANT_NO,RENTE_NO,COMPANIE_CD,',
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_REASSUREUR  en utilisant REASSUREUR_CD',
	SK_ID_DIM_TERRITOIRE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TERRITOIRE en utilisant PROVINCE_ETAT_CD',
	SK_ID_DIM_PRODUIT NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_PRODUIT en utilisant le PRODUIT',
	SK_ID_DIM_STATUS NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_STATUS en utilisant le STATUS',
	SK_ID_DIM_SEX_LIFE_1 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_SEX en utilisant le SEX_1ST_LIFE',
	SK_ID_DIM_SEX_LIFE_2 NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_SEX en utilisant le SEX_2ST_LIFE',
	LIBERATION_RESERVE_DIRECTE_REELLE_BEL_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_REASSURANCE_REELLE_BEL_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_ATTENDUE_DIRECTE_BEL_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_ATTENDUE_REASSURANCE_BEL_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECTE_REELLE_RA_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_REASSURANCE_REELLE_RA_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_ATTENDUE_DIRECTE_RA_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_ATTENDUE_REASSURANCE_RA_MORTALITE NUMBER(28,10) NOT NULL,
	ECARTS_EXPERIENCE_DIRECT_MORTALITE NUMBER(28,10) NOT NULL,
	ECARTS_EXPERIENCE_REASSURANCE_MORTALITE NUMBER(28,10) NOT NULL,
	ECARTS_EXPERIENCE_NET_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_LIC_DIRECTE_MORTALITE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_LIC_REASSURANCE_MORTALITE NUMBER(28,10) NOT NULL,
	NOMBRE_DECES_REELS NUMBER(38,0) NOT NULL,
	NOMBRE_DECES_ATTENDUS NUMBER(38,0) NOT NULL,
	LIBERATION_MARGE NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECT_REELLE_BEL_AUTRES_MOUVEMENTS NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_REASSURANCE_REELLE_BEL_AUTRES_MOUVEMENTS NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECT_REELLE_RA_AUTRES_MOUVEMENTS NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_REASSURANCE_REELLE_RA_AUTRES_MOUVEMENTS NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_CLAIMS_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_INVESTMENT_COMPONENT_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_REASSUREE_CLAIMS_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_DIRECTE_CLAIMS_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_REASSURANCE_CLAIMS_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_DIRECTE_INVESTMENT_COMPONENT_ASSURANCE NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_RETOUR_DE_PRIMES NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_REASSUREE_RETOUR_PRIMES NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECTE_REELLE_BEL_RETOUR_PRIMES NUMBER(28,10) NOT NULL,
	LIBERATION_RESERVE_DIRECTE_REELLE_RA_RETOUR_PRIMES NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_REASSUREE_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_DIRECTE_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_REASSUREE_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_ATTENDUE_DIRECTE_INVESTMENT_COMPONENT_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRESTATION_REELLE_DIRECTE_INVESTMENT_COMPONENT_VERSEMENT_RENTES NUMBER(28,10) NOT NULL,
	PRIME_REELLE_DIRECTE NUMBER(28,10) NOT NULL,
	PRIME_REELLE_REASSURANCE NUMBER(28,10) NOT NULL,
	PRIME_ATTENDUE_DIRECTE NUMBER(28,10) NOT NULL,
	PRIME_ATTENDUE_REASSURANCE NUMBER(28,10) NOT NULL,
	CSM_LOSS_COMPONENT_EMISSION NUMBER(28,10) NOT NULL,
	FRAIS_ACQUISITION_ATTENDUS NUMBER(28,10) NOT NULL,
	FRAIS_ACQUISITION_REELS NUMBER(28,10) NOT NULL,
	COMMISSIONS_ATTENDUES NUMBER(28,10) NOT NULL,
	COMMISSIONS_REELLES NUMBER(28,10) NOT NULL,
	FRAIS_ADMINISTRATION_ATTRIBUABLES_ATTENDUS NUMBER(28,10) NOT NULL,
	FRAIS_ADMINISTRATION_ATTRIBUABLES_REELS NUMBER(28,10) NOT NULL,
	INTERET_SOMMES_EN_DEPOTS_REELS NUMBER(28,10) NOT NULL,
	MONTANT_RENTE NUMBER(28,10) NOT NULL,
	MONTANT_RENTE_TOTAL NUMBER(28,10) NOT NULL,
	VOLUME_PAYOUT NUMBER(28,10) NOT NULL,
	TOTAL_PAYOUT NUMBER(28,10) NOT NULL,
	AGE_1ST_LIFE_AT_ISS NUMBER(10,6) NOT NULL,
	AGE_1ST_LIFE NUMBER(10,6) NOT NULL,
	AGE_2ND_LIFE_AT_ISS NUMBER(10,6) NOT NULL,
	AGE_2ND_LIFE NUMBER(10,6) NOT NULL,
	FORM_OF_PENSION VARCHAR(4) NOT NULL,
	CD_CIE VARCHAR(1),
	STATE VARCHAR(4) NOT NULL,
	CD_TYPE_ACHAT VARCHAR(2) NOT NULL,
	POSITIVE_RESERVE VARCHAR(3) NOT NULL,
	INDICATEUR_IPC BOOLEAN NOT NULL,
	IND_BULK_CHECK BOOLEAN NOT NULL,
	IND_RENTE_NEGATIVE BOOLEAN NOT NULL,
	INDICATEUR_REASSURANCE BOOLEAN NOT NULL,
	INDICATEUR_RGDE BOOLEAN NOT NULL,
	INDICATEUR_SUIVI_ITROUVABLE_ADMIN BOOLEAN NOT NULL,
	INDICATEUR_NON_CODE BOOLEAN NOT NULL,
	MD_START_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.'
);
create or replace view VW_ERC_AJUSTEMENT_MANUEL(
	SOURCE,
	ID_DIM_DATE_EVALUATION,
	SK_ID_DIM_POLICE,
	SK_ID_DIM_GROUPE_CSM,
	SK_ID_DIM_GROUPE_CSM_DIRECT_ASSOCIE,
	SK_ID_DIM_REASSUREUR,
	POLICY_ID,
	CHAMP_SCALAR,
	IFRS_GROUP_CODE,
	UNDERLYING_IFRS_GROUP_CODE,
	RUN_NUMBER,
	VARIABLE_NAME,
	TRANSACTION_CURRENCY_CODE,
	CUSTOM_DIM_1,
	CUSTOM_DIM_2,
	FCF_COMPONENT,
	AMOUNT,
	CH,
	MD_START_DT
) as
SELECT 
	IFF(UNDERLYING_IFRS_GROUP_CODE IS NULL, 'DIRECT','REAS')  AS SOURCE
	,NVL(DT_EVAl.ID_DIM_DATE,19000101) 					              AS ID_DIM_DATE_EVALUATION
	,NVL(DT_POl.SK_ID_DIM_POLICE,-1) 						              AS SK_ID_DIM_POLICE 
	,NVL(DT_GR_CSM.SK_ID_DIM_GROUPE_CSM,-1) 				          AS SK_ID_DIM_GROUPE_CSM
	,NVL(DT_GR_CSM_DIR.SK_ID_DIM_GROUPE_CSM,-1) 			        AS SK_ID_DIM_GROUPE_CSM_DIRECT_ASSOCIE	
	,(CASE 
		  WHEN IFRS_GROUP_CODE LIKE '%DBB%' THEN 1  
		  WHEN IFRS_GROUP_CODE LIKE '%RGA%' THEN 2
		  ELSE -1
	  END)::INT												                        AS SK_ID_DIM_REASSUREUR
    ,FT.POLICY_ID
    ,CHAMP_SCALAR
    ,IFRS_GROUP_CODE
    ,UNDERLYING_IFRS_GROUP_CODE
    ,RUN_NUMBER
    ,VARIABLE_NAME
    ,TRANSACTION_CURRENCY_CODE
    ,CUSTOM_DIM_1
    ,CUSTOM_DIM_2
    ,FCF_COMPONENT
    ,AMOUNT
    ,DECODE(SOURCE,'DIRECT',NVL(CH_Direct.CH,45), 'REAS',NVL(CH_Reas.CH,45)) AS CH
    ,FT.MD_START_DT::DATE AS MD_START_DT
FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_AJUSTEMENT_MANUEL AS FT
LEFT JOIN DM_ERC.DIM_DATE AS DT_EVAl ON (FT.MD_START_DT::DATE=DT_EVAl.SHORT_NAME_FR::DATE)
LEFT JOIN DM_ERC.DIM_POLICE AS DT_POl ON (NVL(FT.POLICY_ID,'-1')= DT_POl.POLICY_ID)
LEFT JOIN DM_ERC.DIM_GROUPE_CSM AS DT_GR_CSM ON(FT.IFRS_GROUP_CODE = DT_GR_CSM.GROUPE_CSM_NOM)
LEFT JOIN DM_ERC.DIM_GROUPE_CSM AS DT_GR_CSM_DIR ON(FT.UNDERLYING_IFRS_GROUP_CODE = DT_GR_CSM_DIR.GROUPE_CSM_NOM)
LEFT JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_BRUT AS CH_Direct ON (FT.POLICY_ID = IFF(CH_Direct.POLICY_ID_OLD_MM='0',CH_Direct.POLICY_ID_OLD_MM_1,CH_Direct.POLICY_ID_OLD_MM)  AND FT.MD_START_DT::DATE=CH_Direct.MD_START_DT::DATE)
LEFT JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_VARIABLE AS CH_Reas ON (FT.POLICY_ID = IFF(CH_Reas.POLICY_ID_OLD_MM='0',CH_Reas.POLICY_ID_OLD_MM_1,CH_Reas.POLICY_ID_OLD_MM)  AND FT.MD_START_DT::DATE=CH_Reas.MD_START_DT::DATE);
create or replace view VW_ERC_DIM_POLICE_ORIGN(
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2,
	POLICY_ID,
	POLICY_ID_EX,
	MD_START_DT,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_IS_ACTIVE,
	INDGARDERLIGNE
) as 
WITH 
	Tbl_SRC_DIM_POLICE  AS (
		                            
								SELECT Policy_ID AS POLICY_ID, POLICY_ID_Extra AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,1 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_RENTES_BRUT 
								
								UNION
								
								SELECT Policy_ID AS POLICY_ID, POLICY_ID_Extra AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,1 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_RENTES_VARIABLE 
																								
								UNION
								
								SELECT POLICY_ID_MM  AS POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,2 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_BRUT 
								
								UNION
								
								SELECT POLICY_ID_MM_1  AS POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,2 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_BRUT 
								
                                UNION
        
								SELECT POLICY_ID_OLD_MM_1  AS POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,2 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_BRUT 
								
								UNION
								
								SELECT POLICY_ID_OLD_MM  AS POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,2 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_BRUT 
								
								UNION								 
								
								SELECT POLICY_ID_MM  AS POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,2 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_VARIABLE 
								
								UNION
								
								SELECT POLICY_ID_MM_1 AS POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,2 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_VARIABLE 
								
								UNION
								
								SELECT POLICY_ID_OLD_MM_1 AS POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,2 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_VARIABLE 
								
								UNION
								
								SELECT POLICY_ID_OLD_MM AS POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,2 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_VARIABLE 
								
								UNION								
								
								SELECT 	POLICY_ID, POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,3 AS IND_PRIORITE  FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LIC_DIRECT 
								
								UNION
								
								SELECT 	POLICY_ID, POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,3 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LIC_REASSURANCE 
								
								UNION
								
								SELECT 	POLICY_ID, POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,3 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_RETRO_DIRECT 
								
								UNION
								
								SELECT 	POLICY_ID, POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,3 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_RETRO_REASSURANCE 
								
								UNION
								
								SELECT POLICY_ID, POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,3 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_DIRECT 
								
								UNION
								
								SELECT POLICY_ID, POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,3 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_NON_CODE 
								
								UNION
								
								SELECT POLICY_ID, POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,3 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_REASSURANCE 
								
								UNION
								
								SELECT POLICY_ID, POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,3 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_SWAPFIXED_REASSURANCE 
								
								UNION
								
								SELECT POLICY_ID, '' AS POLICY_ID_EX, MD_START_DT, MD_CREATION_DT, MD_SOURCE, MD_IS_ACTIVE,4 AS IND_PRIORITE FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_AJUSTEMENT_MANUEL WHERE  POLICY_ID IS NOT NULL
								)
SELECT
    SHA1(NVL(POLICY_ID::STRING, '#NULL#'))      AS MD_HASH_NAT_KEY     
    ,SHA1(NVL(POLICY_ID_EX::STRING, '#NULL#'))  AS MD_HASHDIFF_TYPE_1          
    ,'0'    									AS MD_HASHDIFF_TYPE_2           
    ,NVL(POLICY_ID,'') 							AS POLICY_ID
    ,NVL(POLICY_ID_EX,'') 						AS POLICY_ID_EX  
    ,MD_START_DT
    ,MD_CREATION_DT
    ,MD_SOURCE
    ,MD_IS_ACTIVE    
    /* IndGarderLigne =Indicateur pour garder une ligne par Police. s'il y plus d'un POLICY_ID on garder celui ayant un POLICY_ID_EX alimente. */
    ,ROW_NUMBER() OVER(PARTITION BY  POLICY_ID ORDER BY IND_PRIORITE,MD_START_DT ASC,  DECODE(POLICY_ID_EX,'', 1,-1) ASC, POLICY_ID_EX ASC) AS IndGarderLigne 
FROM Tbl_SRC_DIM_POLICE		
QUALIFY IndGarderLigne= 1;
create or replace view VW_ERC_EXTRAIT_BULK(
	SOURCE,
	ID_DIM_DATE_EVALUATION,
	SK_ID_DIM_GROUPE_CSM,
	SK_ID_DIM_GROUPE_CSM_DIRECT_ASSOCIE,
	SK_ID_DIM_POLICE,
	SK_ID_DIM_REASSUREUR,
	PERIODE,
	NO_RUN,
	GROUPE_CSM,
	GROUPE_CSM_DIRECT_ASSOCIE,
	NOM_VARIABLE,
	CUSTOM_DIM_1,
	CUSTOM_DIM_2,
	CD_DEVISE,
	MNT_RESERVE,
	MD_START_DT
) as
SELECT 
	IFF(GROUPE_CSM_DIRECT_ASSOCIE IS NULL, 'DIRECT','REAS') AS SOURCE
	,NVL(DT_EVAl.ID_DIM_DATE,19000101) 						AS ID_DIM_DATE_EVALUATION
	,NVL(DT_GR_CSM.SK_ID_DIM_GROUPE_CSM,-1) 				AS SK_ID_DIM_GROUPE_CSM 
	,NVL(DT_GR_CSM_DIR.SK_ID_DIM_GROUPE_CSM,-1) 			AS SK_ID_DIM_GROUPE_CSM_DIRECT_ASSOCIE
	,-1 													AS SK_ID_DIM_POLICE 
	,(CASE 
		WHEN FT.GROUPE_CSM LIKE '%DBB%' THEN 1  
		WHEN FT.GROUPE_CSM LIKE '%RGA%' THEN 2
		ELSE -1
	 END)::INT												AS SK_ID_DIM_REASSUREUR
	,PERIODE,NO_RUN,GROUPE_CSM,GROUPE_CSM_DIRECT_ASSOCIE,NOM_VARIABLE,CUSTOM_DIM_1,CUSTOM_DIM_2,CD_DEVISE,MNT_RESERVE,MD_START_DT::DATE AS MD_START_DT
FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_EXTRAIT_BULK AS FT
LEFT JOIN DM_ERC.DIM_DATE AS DT_EVAl ON (FT.MD_START_DT::DATE=DT_EVAl.SHORT_NAME_FR::DATE)					
LEFT JOIN DM_ERC.DIM_GROUPE_CSM AS DT_GR_CSM ON(FT.GROUPE_CSM = DT_GR_CSM.GROUPE_CSM_NOM)
LEFT JOIN DM_ERC.DIM_GROUPE_CSM AS DT_GR_CSM_DIR ON(FT.GROUPE_CSM_DIRECT_ASSOCIE = DT_GR_CSM_DIR.GROUPE_CSM_NOM);
create or replace view VW_ERC_FT_SOE_LIBERATION_RESERVE_BRUT(
	ID_DIM_DATE_EVALUATION,
	ID_DIM_DATE_EMISSION,
	ID_DIM_DATE_DECES_1,
	ID_DIM_DATE_DECES_SAISIE_1,
	ID_DIM_DATE_DECES_2,
	ID_DIM_DATE_DECES_SAISIE_2,
	SK_ID_DIM_REASSUREUR,
	SK_ID_DIM_POLICE,
	SK_ID_DIM_GROUPE_CSM,
	SK_ID_DIM_TRANSACTION_CODE,
	SK_ID_DIM_PARTICIPANT_RENTES,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_PRODUIT,
	SK_ID_DIM_STATUS,
	SK_ID_DIM_EVENEMENT_AU_DECES_1,
	SK_ID_DIM_EVENEMENT_AU_DECES_2,
	RESERVE_MONTH_START_BEL,
	PREMIUM_BEL,
	INITIAL_RECOGNITION_BEL,
	ACQ_EPENSE_BEL,
	INTEREST_BEL,
	CLAIMS_PAYOUT_BEL,
	INVESTMENT_COMPONENT_PAYOUT_BEL,
	CLAIMS_DEATH_BENEFIT_BEL,
	INVESTMENT_COMPONENT_DEATH_BENEFIT_BEL,
	EXPENSE_BEL,
	MORTALITY_COST_BEL,
	DECES_RACHAT_BEL,
	EXPERIENCE_ADJUSTMENT_BEL,
	BALANCE_BEL,
	RESERVE_MONTH_END_BEL,
	RESERVE_MONTH_START_RA,
	INITIAL_RECOGNITION_RA,
	INTEREST_RA,
	RELEASE_RA,
	MORTALITY_COST_RA,
	DECES_RACHAT_RA,
	EXPERIENCE_ADJUSTMENT_RA,
	BALANCE_RA,
	RESERVE_MONTH_END_RA,
	RESERVE_MONTH_START_LIC,
	PAYOUT_LIC,
	RELEASE_LIC,
	NEW_CLAIMS_LIC,
	RESERVE_MONTH_END_LIC,
	RESERVE_MONTH_START_RETRO_DIFF,
	EXPERIENCE_ADJUSTMENT_RETRO_DIFF,
	INVESTMENT_COMPONENT_RETRO_DIFF,
	CLAIMS_RETRO_DIFF,
	RESERVE_MONTH_END_RETRO_DIFF,
	INDICATEUR_IPC,
	INDICATEUR_REASSURANCE,
	INDICATEUR_RGDE,
	INDICATEUR_SUIVI_ITROUVABLE_ADMIN,
	SEX_1ST_LIFE,
	SEX_2ND_LIFE,
	AGE_1ST_LIFE_AT_ISS,
	AGE_1ST_LIFE,
	AGE_2ND_LIFE_AT_ISS,
	AGE_2ND_LIFE,
	FORM_OF_PENSION,
	VOLUME_PAYOUT,
	TOTAL_PAYOUT,
	POSITIVE_RESERVE,
	STATE,
	CD_TYPE_ACHAT,
	ISS_YEAR_ORIG,
	ISS_MONTH_ORIG,
	CD_DIVISION_PROVINCE_COMPTABLE,
	IND_BULK_CHECK,
	POLICY_ID,
	GROUPE_CSM,
	CH,
	CD_CIE,
	MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS,
	MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG,
	SK_ID_DIM_SEX_LIFE_1,
	SK_ID_DIM_SEX_LIFE_2,
	MD_START_DT,
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2,
	MD_ROW_IS_VALID
) as	
WITH 
      -- Obtenir les POLICY_ID a evaluer : utiliser la combinaison  Scalar + LIC + Rétro diff
         TBL_POLICY_ID_VALUATION  AS (
							  			SELECT MD_START_DT AS DATE_EVALUATION ,POLICY_ID   FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_DIRECT  
										UNION
										SELECT MD_START_DT AS DATE_EVALUATION ,POLICY_ID   FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LIC_DIRECT   
										UNION
										SELECT MD_START_DT AS DATE_EVALUATION ,POLICY_ID   FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_RETRO_DIRECT 
							   		)

    -- Pivoter le DRILLDOWN_OUTPUT_IFRS17  pour avoir la Granularité police
	,TBL_DRILLDOWN_OUTPUT_IFRS17 AS (
									SELECT
									      MD_START_DT, POLICY_ID
									    , SUM(CASE WHEN RELEASE_TYPE_NAME = 'BEL' AND ROW_DESC = 'Expected Release on Death' THEN NVL(AMOUNT, 0) ELSE 0  END )  AS BEL_MORTALITY_COST
									    , SUM(CASE WHEN RELEASE_TYPE_NAME = 'BEL' AND ROW_DESC = 'Actual Release on Death' THEN NVL(AMOUNT, 0) ELSE 0  END)     AS BEL_DECES_RACHAT
									    , SUM(CASE WHEN RELEASE_TYPE_NAME = 'RA' AND ROW_DESC = 'Expected Release on Death' THEN NVL(AMOUNT, 0) ELSE 0  END)    AS RA_MORTALITY_COST
									    , SUM(CASE WHEN RELEASE_TYPE_NAME = 'RA' AND ROW_DESC = 'Actual Release on Death' THEN NVL(AMOUNT, 0) ELSE 0  END)      AS RA_DECES_RACHAT
									FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_DRILLDOWN_OUTPUT_IFRS17
									GROUP BY MD_START_DT, POLICY_ID
									)
									
	,TBL_SOE_CF_OUTPUT_IFRS17_RPU AS (
									SELECT
									      MD_START_DT, POLICY_ID
									    , SUM(CASE WHEN ROW_DESC = 'Death benefit - Assurance(*)' THEN NVL(AMOUNT, 0) ELSE 0 END )          AS DEATH_BENEFIT_ASSURANCE
									    , SUM(CASE WHEN ROW_DESC = 'Death benefit - Investment component' THEN NVL(AMOUNT, 0) ELSE 0 END)   AS DEATH_BENEFIT_INVESTMENT_COMPONENT
									    , SUM(CASE WHEN ROW_DESC = 'Death benefit - Total' THEN NVL(AMOUNT, 0) ELSE 0 END)                  AS DEATH_BENEFIT_TOTAL
									    , SUM(CASE WHEN ROW_DESC = 'Payout - Assurance(*)' THEN NVL(AMOUNT, 0) ELSE 0 END)                  AS PAYOUT_ASSURANCE
									    , SUM(CASE WHEN ROW_DESC = 'Payout - Investment component' THEN NVL(AMOUNT, 0) ELSE 0 END)          AS PAYOUT_INVESTMENT_COMPONENT
									    , SUM(CASE WHEN ROW_DESC = 'Payout - Total' THEN NVL(AMOUNT, 0) ELSE 0 END)                         AS PAYOUT_TOTAL
									FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SOE_CF_OUTPUT_IFRS17_RPU
									GROUP BY MD_START_DT, POLICY_ID
									)
      ,TBL_STATS_ETATS_FINANCIERS AS (
 									   SELECT 
									      FTI.*,CONCAT(GROUPE,NVL(PREFIXE,''),DIVISION,CERTIFICAT) AS CLE_PARTICIPANT
									       --IND_GARDER_LIGNE : Pour garder une seule ligne par CLE_PARTICIPANT et DatDATE_REGLEE 
								           ,ROW_NUMBER() OVER(PARTITION BY FTI.MD_START_DT::DATE,CLE_PARTICIPANT ORDER BY IFF(MONTANT_DU_TROPPAYE<>0 OR DATE_DECES <>'0',1,2) ASC,  TO_DATE(FTI.DATE_CREATION_DECES, 'YYYYMMDD') ASC) AS IND_GARDER_LIGNE    
								          FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_STATS_ETATS_FINANCIERS AS FTI
								          QUALIFY IND_GARDER_LIGNE=1
                                        )
,TBL_SRC AS (
              SELECT
                  TO_VARCHAR(POL_EVAL.DATE_EVALUATION::DATE,'YYYYMMDD')::NUMBER(8,0)                                	AS ID_DIM_DATE_EVALUATION             
                  ,NVL((RB.ISS_YEAR || RIGHT('0'||RB.ISS_MONTH,2) || RIGHT('0'||RB.ISS_DAY,2)),'19000101')::NUMBER(8,0) AS ID_DIM_DATE_EMISSION
                  ,NVL(TO_VARCHAR(DECES_1.PART_DT_DECES::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0)                      AS ID_DIM_DATE_DECES_1
                  ,NVL(TO_VARCHAR(DECES_1.PART_DECES_DT_SAISIE::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0)    		AS ID_DIM_DATE_DECES_SAISIE_1
                  ,NVL(TO_VARCHAR(DECES_2.PART_DT_DECES::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0)                      AS ID_DIM_DATE_DECES_2
                  ,NVL(TO_VARCHAR(DECES_2.PART_DECES_DT_SAISIE::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0)               AS ID_DIM_DATE_DECES_SAISIE_2
            
                -- champs de lookup
                , CASE 
                      WHEN  RB.STATUS = 4 THEN 'RETR' ELSE
                            'DIFF'
                      END                                                           AS STATUS
                , RB.CD_DIVISION_PROVINCE_COMPTABLE                                 AS CD_DIVISION_PROVINCE_COMPTABLE
                , CASE WHEN  RB.CD_DIVISION_PROVINCE_COMPTABLE = 'ZZ' THEN 'ZZ'
                      ELSE 'CA' END                                                 AS PAYS_CD
                , SHA1( NVL( POL_EVAL.POLICY_ID::STRING, '#NULL#') )                AS NK_POLICE
                , SHA1( NVL( COALESCE(SCA_D.GROUPE_CSM,LIC_D.GROUPE_CSM ,RET_D.GROUPE_CSM)::STRING, '#NULL#' ))                  AS NK_GROUPE_CSM 
                , SHA1( NVL( RB.NO_CONTRAT::STRING,         '#NULL#')   || '|' ||
                        NVL( RB.CD_PREFIXE_CONTRAT::STRING, '#NULL#')   || '|' ||
                        NVL( RB.NO_DIV::STRING,             '#NULL#')   || '|' ||
                        NVL( RB.NO_PARTICIPANT::STRING,     '#NULL#')   || '|' ||
                        NVL( RB.NO_RENTE::STRING,           '#NULL#')   || '|' ||
                        NVL( RB.CD_CIE::STRING,             '#NULL#') 
              )											     	AS NK_PARTICIPANT_RENTES
                , SHA1( NVL( RB.PRODUCT::STRING, '#NULL') )                         AS NK_PRODUIT
                , SHA1( NVL( CH.CH::STRING, '45' ))                                 AS NK_TRANSACTION_CODE
                ,DECES_1.EVENT_CD_AU_DECES AS CD_EVENEMENT_AU_DECES_1
                ,DECES_2.EVENT_CD_AU_DECES AS CD_EVENEMENT_AU_DECES_2
                -- mesures
                , NVL(SCA_D.MNT_BEL_CURRDISC_CURRNFA_PPE , 0)                                                                                                                                                                   AS RESERVE_MONTH_START_BEL
                , NVL(SCA_D.MNT_RA_CURR_DISC_CURR_NFA_PPE, 0)                                                                                                                                                                   AS RESERVE_MONTH_START_RA
                , NVL(LIC_D.MNT_LIC, 0)                                                                                                                                                                                         AS RESERVE_MONTH_START_LIC
                , NVL(RET_D.MNT_BEL_CURR_DISC_CURR_NFA, 0)  + NVL(RET_D.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL, 0)  - NVL(RET_D.MNT_EXPECTED_INVESTMENT_COMPONENT_PAID, 0)  - NVL(RET_D.MNT_REVENUE_EXPECTED_CLAIMS, 0)        AS RESERVE_MONTH_START_RETRO_DIFF
                , NVL(SCA_D.MNT_EXPECTED_PREMIUM, 0)                                                                                                                                                                            AS PREMIUM_BEL
                , (NVL(SCA_D.MNT_PV_CLAIM_AND_NON_ACQ_EXP_INIT_RECOG, 0) - NVL(SCA_D.MNT_PV_PREM_AND_RELATED_CFS_INIT_RECOG, 0) + NVL(SCA_D.MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG, 0))                                           AS INITIAL_RECOGNITION_BEL
                , NVL(SCA_D.MNT_RA_AT_INITIAL_RECOGNITION, 0)                                                                                                                                                                   AS INITIAL_RECOGNITION_RA
                , (NVL(SCA_D.MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS, 0) - NVL(SCA_D.MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG, 0))                                                                                                   AS ACQ_EPENSE_BEL
                , (NVL(SCA_D.MNT_EXPECTED_INTEREST_ON_BEL, 0) - NVL(SCA_D.MNT_PE_CHANGE_IN_FA_CHANGE_IN_BEL, 0) - NVL(SCA_D.MNT_PS_CHANGE_IN_FA_CHANGE_IN_BEL, 0))                                                              AS INTEREST_BEL
                , (NVL(SCA_D.MNT_EXPECTED_INTEREST_ON_RA, 0) -  NVL(SCA_D.MNT_PE_CHANGE_IN_FA_CHANGE_IN_RA, 0) - NVL(SCA_D.MNT_PS_CHANGE_IN_FA_CHANGE_IN_RA, 0))                                                                AS INTEREST_RA
                , NVL(CF.PAYOUT_ASSURANCE, 0)  * IFF(RB.POSITIVE_RESERVE = 'Y' , -1 , 1)                                                                                                                                        AS CLAIMS_PAYOUT_BEL 
                , NVL(CF.DEATH_BENEFIT_ASSURANCE, 0) * IFF(RB.POSITIVE_RESERVE = 'Y' , -1 , 1)                                                                                                                                  AS CLAIMS_DEATH_BENEFIT_BEL
                , NVL(RET_D.MNT_REVENUE_EXPECTED_CLAIMS, 0)                                                                                                                                                                     AS CLAIMS_RETRO_DIFF
                , NVL(CF.PAYOUT_INVESTMENT_COMPONENT, 0) * IFF(RB.POSITIVE_RESERVE = 'Y' , -1 , 1)                                                                                                                              AS INVESTMENT_COMPONENT_PAYOUT_BEL
                , NVL(CF.DEATH_BENEFIT_INVESTMENT_COMPONENT, 0) * IFF(RB.POSITIVE_RESERVE = 'Y' , -1 , 1)                                                                                                                       AS INVESTMENT_COMPONENT_DEATH_BENEFIT_BEL
                , NVL(RET_D.MNT_EXPECTED_INVESTMENT_COMPONENT_PAID, 0)                                                                                                                                                          AS INVESTMENT_COMPONENT_RETRO_DIFF
                , NVL(SCA_D.MNT_REVENUE_EXPECTED_EXPENSES, 0)                                                                                                                                                                   AS EXPENSE_BEL
                , NVL(DD.BEL_MORTALITY_COST * IFF(RB.POSITIVE_RESERVE = 'Y' , 1 , -1), 0)                                                                                                                                       AS MORTALITY_COST_BEL
                , NVL(DD.RA_MORTALITY_COST * IFF(RB.POSITIVE_RESERVE =  'Y' , 1 , -1), 0)                                                                                                                                       AS MORTALITY_COST_RA
                , NVL(DD.BEL_DECES_RACHAT * IFF(RB.POSITIVE_RESERVE = 'Y' , -1 , 1), 0)                                                                                                                                         AS DECES_RACHAT_BEL
                , NVL(DD.RA_DECES_RACHAT * IFF(RB.POSITIVE_RESERVE = 'Y' , -1 , 1), 0)                                                                                                                                          AS DECES_RACHAT_RA
                , NVL(-RET_D.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL,0)                                                                                                                                                         AS EXPERIENCE_ADJUSTMENT_RETRO_DIFF
                , NVL(SCA_D.MNT_BEL_CURR_DISC_CURR_NFA, 0)                                                                                                                                                                      AS RESERVE_MONTH_END_BEL
                , NVL(SCA_D.MNT_RA_CURR_DISC_CURR_NFA, 0)                                                                                                                                                                       AS RESERVE_MONTH_END_RA
                , NVL(LIC_D.MNT_BEL_B_LIC_160, 0)                                                                                                                                                                               AS RESERVE_MONTH_END_LIC
                , NVL(RET_D.MNT_BEL_CURR_DISC_CURR_NFA, 0)                                                                                                                                                                      AS RESERVE_MONTH_END_RETRO_DIFF
                , NVL(-SCA_D.MNT_EXPECTED_RA_RELEASE, 0)                                                                                                                                                                        AS RELEASE_RA
                , NVL(-LIC_D.MNT_EXP_B_PAID_PAST, 0)                                                                                                                                                                            AS PAYOUT_LIC
                , NVL(LIC_D.MNT_BEL_B_LIC_160 - LIC_D.MNT_BEL_B_LIC_140 ,0)                                                                                                                                                     AS NEW_CLAIMS_LIC
                , IFF(RB.PCT_IPC <> 0 , 1 , 0)                                                                                                                                                                                  AS INDICATEUR_IPC
                , IFF(RB.IND_RGA = 1, 1, IFF(RB.IND_BOMBARDIER = 1, 1, 0))                                                                                                                                                      AS INDICATEUR_REASSURANCE
                , NVL(RB.IND_REGLEMENT_DECES, 0)                                                                                                                                                                                AS INDICATEUR_RGDE
                  
                  -- les colonnes ci-dessous dependent des colonnes calculé ci-Haut.
                 , NVL(RESERVE_MONTH_END_LIC,0) - (NVL(RESERVE_MONTH_START_LIC,0) + NVL(PAYOUT_LIC,0) + NVL(NEW_CLAIMS_LIC,0))                                                                                                  AS RELEASE_LIC
                , (-NVL(SCA_D.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL, 0) - MORTALITY_COST_BEL - DECES_RACHAT_BEL)                                                                                                              AS EXPERIENCE_ADJUSTMENT_BEL
                , (RESERVE_MONTH_END_BEL - (RESERVE_MONTH_START_BEL + PREMIUM_BEL + INITIAL_RECOGNITION_BEL + ACQ_EPENSE_BEL + INTEREST_BEL + CLAIMS_PAYOUT_BEL +
                        CLAIMS_DEATH_BENEFIT_BEL + INVESTMENT_COMPONENT_PAYOUT_BEL + INVESTMENT_COMPONENT_DEATH_BENEFIT_BEL + EXPENSE_BEL + MORTALITY_COST_BEL + DECES_RACHAT_BEL + EXPERIENCE_ADJUSTMENT_BEL))                 AS BALANCE_BEL
                
                , (-NVL(SCA_D.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_RA, 0) - MORTALITY_COST_RA - DECES_RACHAT_RA)                                                                                                                 AS EXPERIENCE_ADJUSTMENT_RA
                , (RESERVE_MONTH_END_RA - (RESERVE_MONTH_START_RA + INITIAL_RECOGNITION_RA + INTEREST_RA + RELEASE_RA + MORTALITY_COST_RA + DECES_RACHAT_RA + EXPERIENCE_ADJUSTMENT_RA))                                        AS BALANCE_RA
            
                , POL_EVAL.DATE_EVALUATION                                                                                                                                                                                      AS MD_START_DT
                , CASE WHEN FTI.CLE_PARTICIPANT  IS NOT NULL AND UPPER(NVL(FTI.INTROUVABLE,'')) = 'VRAI' THEN 1 ELSE 0 END 														  												AS INDICATEUR_SUIVI_ITROUVABLE_ADMIN
                
				-- les colonnes ci-dessous ajoute pour le Besoin#2
                , RB.SEX_1ST_LIFE 	                                                                                                                                            				                               	AS SEX_1ST_LIFE
		        , RB.SEX_2ND_LIFE			                                                                                                                                            			                            AS SEX_2ND_LIFE 	
		        , RB.AGE_1ST_LIFE_AT_ISS					                                                                                                                                                                    AS AGE_1ST_LIFE_AT_ISS
                , RB.AGE_1ST_LIFE				                                                                                                                                            		                            AS AGE_1ST_LIFE
                , RB.AGE_2ND_LIFE_AT_ISS			                                                                                                                                            		                        AS AGE_2ND_LIFE_AT_ISS
                , RB.AGE_2ND_LIFE					                                                                                                                                            	                            AS AGE_2ND_LIFE
                , RB.FORM_OF_PENSION		                                                                                                                                            				                        AS FORM_OF_PENSION
                , RB.VOLUME_PAYOUT			                                                                                                                                            			                            AS VOLUME_PAYOUT
                , RB.TOTAL_PAYOUT			                                                                                                                                            		                            	AS TOTAL_PAYOUT	
                , RB.POSITIVE_RESERVE		                                                                                                                                            			                            AS POSITIVE_RESERVE
                , RB.STATE					                                                                                                                                                		                            AS STATE
                , RB.CD_TYPE_ACHAT				                                                                                                                                                    		                    AS CD_TYPE_ACHAT
                , RB.ISS_YEAR_ORIG						                                                                                                                                                                        AS ISS_YEAR_ORIG
                , RB.ISS_MONTH_ORIG						                                                                                                                                                                        AS ISS_MONTH_ORIG
                , RB.IND_BULK_CHECK	                                                                                                                                                                                            AS IND_BULK_CHECK	
                , POL_EVAL.POLICY_ID
                , NVL(CH.CH ,45) AS CH
                , COALESCE(SCA_D.GROUPE_CSM,LIC_D.GROUPE_CSM ,RET_D.GROUPE_CSM) AS GROUPE_CSM
                , CD_CIE
                , SCA_D.MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS
                , SCA_D.MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG
          FROM TBL_POLICY_ID_VALUATION AS POL_EVAL
          LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_RENTES_BRUT AS RB ON(POL_EVAL.POLICY_ID=RB.POLICY_ID AND POL_EVAL.DATE_EVALUATION=RB.MD_START_DT)		  
          LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LIC_DIRECT AS LIC_D ON (POL_EVAL.POLICY_ID = LIC_D.POLICY_ID AND POL_EVAL.DATE_EVALUATION=LIC_D.MD_START_DT)		  
          LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_RETRO_DIRECT AS RET_D ON (POL_EVAL.POLICY_ID = RET_D.POLICY_ID AND POL_EVAL.DATE_EVALUATION=RET_D.MD_START_DT)		  
          LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_DIRECT AS SCA_D ON (POL_EVAL.POLICY_ID = SCA_D.POLICY_ID AND POL_EVAL.DATE_EVALUATION=SCA_D.MD_START_DT)		
          LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_BRUT AS CH ON (POL_EVAL.POLICY_ID = IFF(CH.POLICY_ID_OLD_MM='0',CH.POLICY_ID_OLD_MM_1,CH.POLICY_ID_OLD_MM) AND POL_EVAL.DATE_EVALUATION=CH.MD_START_DT )		  
          LEFT OUTER JOIN TBL_DRILLDOWN_OUTPUT_IFRS17 AS DD ON (POL_EVAL.POLICY_ID = DD.POLICY_ID AND POL_EVAL.DATE_EVALUATION=DD.MD_START_DT)		
          LEFT OUTER JOIN TBL_SOE_CF_OUTPUT_IFRS17_RPU AS CF ON (POL_EVAL.POLICY_ID = CF.POLICY_ID AND POL_EVAL.DATE_EVALUATION=CF.MD_START_DT)		  
          LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LISTE_DECES AS DECES_1  ON (DECES_1.RENTE_NO_ORI IS NULL AND POL_EVAL.POLICY_ID=DECES_1.RENTE_NO AND MONTH(POL_EVAL.DATE_EVALUATION)=MONTH(DECES_1.PART_DECES_DT_SAISIE) AND YEAR(POL_EVAL.DATE_EVALUATION)= YEAR(DECES_1.PART_DECES_DT_SAISIE) AND POL_EVAL.DATE_EVALUATION=DECES_1.MD_START_DT)
          LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LISTE_DECES AS DECES_2  ON (DECES_2.RENTE_NO_ORI IS NOT NULL AND POL_EVAL.POLICY_ID = DECES_2.RENTE_NO_ORI AND MONTH(POL_EVAL.DATE_EVALUATION)= MONTH(DECES_2.PART_DECES_DT_SAISIE) AND YEAR(POL_EVAL.DATE_EVALUATION)= YEAR(DECES_2.PART_DECES_DT_SAISIE) AND POL_EVAL.DATE_EVALUATION=DECES_2.MD_START_DT)
          LEFT OUTER JOIN TBL_STATS_ETATS_FINANCIERS AS FTI ON (CONCAT(RB.NO_CONTRAT,NVL(RB.CD_PREFIXE_CONTRAT,''),RB.NO_DIV,RB.NO_PARTICIPANT)=FTI.CLE_PARTICIPANT
 																		AND DATE_TRUNC('MONTH', RB.MD_START_DT) = DATE_TRUNC('MONTH', TO_DATE(FTI.DATE_CREATION_DECES, 'YYYYMMDD'))  
 													 					AND RB.MD_START_DT::DATE=FTI.MD_START_DT::DATE  
																		) 
          )
SELECT
      NVL(ID_DIM_DATE_EVALUATION, -1)       AS ID_DIM_DATE_EVALUATION
      , NVL(ID_DIM_DATE_EMISSION, -1)         AS ID_DIM_DATE_EMISSION
      , NVL(ID_DIM_DATE_DECES_1, -1)          AS ID_DIM_DATE_DECES_1
      , NVL(ID_DIM_DATE_DECES_SAISIE_1, -1)   AS ID_DIM_DATE_DECES_SAISIE_1
      , NVL(ID_DIM_DATE_DECES_2, -1)          AS ID_DIM_DATE_DECES_2
      , NVL(ID_DIM_DATE_DECES_SAISIE_2, -1)   AS ID_DIM_DATE_DECES_SAISIE_2
      , -1                                    AS SK_ID_DIM_REASSUREUR
      , NVL(SK_ID_DIM_POLICE, -1)             AS SK_ID_DIM_POLICE
      , NVL(SK_ID_DIM_GROUPE_CSM, -1)         AS SK_ID_DIM_GROUPE_CSM
      , NVL(SK_ID_DIM_TRANSACTION_CODE, -1)   AS SK_ID_DIM_TRANSACTION_CODE
      , NVL(SK_ID_DIM_PARTICIPANT_RENTES, -1) AS SK_ID_DIM_PARTICIPANT_RENTES
      , NVL(SK_ID_DIM_TERRITOIRE, -1)         AS SK_ID_DIM_TERRITOIRE
      , NVL(SK_ID_DIM_PRODUIT, -1)            AS SK_ID_DIM_PRODUIT
      , NVL(SK_ID_DIM_STATUS, -1)             AS SK_ID_DIM_STATUS
      , NVL(DT_DECES_1.SK_ID_DIM_EVENEMENT_AU_DECES, -1)             AS SK_ID_DIM_EVENEMENT_AU_DECES_1
      , NVL(DT_DECES_2.SK_ID_DIM_EVENEMENT_AU_DECES, -1)             AS SK_ID_DIM_EVENEMENT_AU_DECES_2
      , RESERVE_MONTH_START_BEL
      , PREMIUM_BEL
      , INITIAL_RECOGNITION_BEL
      , ACQ_EPENSE_BEL
      , INTEREST_BEL
      , CLAIMS_PAYOUT_BEL
      , INVESTMENT_COMPONENT_PAYOUT_BEL
      , CLAIMS_DEATH_BENEFIT_BEL
      , INVESTMENT_COMPONENT_DEATH_BENEFIT_BEL
      , EXPENSE_BEL
      , MORTALITY_COST_BEL
      , DECES_RACHAT_BEL
      , EXPERIENCE_ADJUSTMENT_BEL
      , BALANCE_BEL
      , RESERVE_MONTH_END_BEL
      , RESERVE_MONTH_START_RA
      , INITIAL_RECOGNITION_RA
      , INTEREST_RA
      , RELEASE_RA
      , MORTALITY_COST_RA
      , DECES_RACHAT_RA
      , EXPERIENCE_ADJUSTMENT_RA
      , BALANCE_RA
      , RESERVE_MONTH_END_RA
      , RESERVE_MONTH_START_LIC
      , PAYOUT_LIC
      , RELEASE_LIC
      , NEW_CLAIMS_LIC
      , RESERVE_MONTH_END_LIC
      , RESERVE_MONTH_START_RETRO_DIFF
      , EXPERIENCE_ADJUSTMENT_RETRO_DIFF
      , INVESTMENT_COMPONENT_RETRO_DIFF
      , CLAIMS_RETRO_DIFF
      , RESERVE_MONTH_END_RETRO_DIFF
      , INDICATEUR_IPC
      , INDICATEUR_REASSURANCE
      , INDICATEUR_RGDE
      , INDICATEUR_SUIVI_ITROUVABLE_ADMIN
      , SEX_1ST_LIFE
      , SEX_2ND_LIFE 	
      , AGE_1ST_LIFE_AT_ISS
      , AGE_1ST_LIFE
      , AGE_2ND_LIFE_AT_ISS
      , AGE_2ND_LIFE
      , FORM_OF_PENSION
      , VOLUME_PAYOUT
      , TOTAL_PAYOUT	
      , POSITIVE_RESERVE
      , STATE
      , CD_TYPE_ACHAT
      , ISS_YEAR_ORIG
      , ISS_MONTH_ORIG
      , CD_DIVISION_PROVINCE_COMPTABLE
      , IND_BULK_CHECK				
      , SRC.POLICY_ID
	, GROUPE_CSM
      , CH
      , CD_CIE
      , MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS
      , MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG
      , DECODE(SEX_1ST_LIFE , 'F' , 1 , 'M' , 2 , -1)  AS SK_ID_DIM_SEX_LIFE_1
      , DECODE(SEX_2ND_LIFE , 'F' , 1 , 'M' , 2 , -1)  AS SK_ID_DIM_SEX_LIFE_2
      , SRC.MD_START_DT
      , '0' AS MD_HASH_NAT_KEY
      , '0' AS MD_HASHDIFF_TYPE_1
      , '0' AS MD_HASHDIFF_TYPE_2
      , CASE WHEN ID_DIM_DATE_EVALUATION = '19000101'
                OR SK_ID_DIM_POLICE < 0
                OR SK_ID_DIM_GROUPE_CSM < 0
                OR SK_ID_DIM_TRANSACTION_CODE < 0
                OR SK_ID_DIM_PARTICIPANT_RENTES< 0
                OR SK_ID_DIM_REASSUREUR < 0
                OR SK_ID_DIM_TERRITOIRE < 0
                OR SK_ID_DIM_PRODUIT < 0
            THEN 0 ELSE 1 END AS MD_ROW_IS_VALID
/*  Lookup sur les dimensions */
FROM TBL_SRC AS SRC
LEFT OUTER JOIN DM_ERC.DIM_POLICE AS D_POL ON (D_POL.MD_HASH_NAT_KEY = SRC.NK_POLICE AND SRC.MD_START_DT BETWEEN D_POL.MD_ACTIVATION_DT AND D_POL.MD_OBSOLESCENCE_DT)
LEFT OUTER JOIN DM_ERC.DIM_STATUS AS D_STAT ON (SRC.STATUS = D_STAT.STATUS)
LEFT OUTER JOIN DM_ERC.DIM_TRANSACTION_CODE AS D_TRX ON (SRC.NK_TRANSACTION_CODE = D_TRX.MD_HASH_NAT_KEY)
LEFT OUTER JOIN DM_ERC.DIM_TERRITOIRE AS D_TER ON (SRC.CD_DIVISION_PROVINCE_COMPTABLE = D_TER.PROVINCE_ETAT_CD AND SRC.PAYS_CD = D_TER.PAYS_CD)
LEFT OUTER JOIN DM_ERC.DIM_PRODUIT D_PROD ON (SRC.NK_PRODUIT = D_PROD.MD_HASH_NAT_KEY)
LEFT OUTER JOIN DM_ERC.DIM_PARTICIPANT_RENTES AS D_PAR ON (SRC.NK_PARTICIPANT_RENTES = D_PAR.MD_HASH_NAT_KEY)
LEFT OUTER JOIN DM_ERC.DIM_GROUPE_CSM AS D_GR ON (SRC.NK_GROUPE_CSM = D_GR.MD_HASH_NAT_KEY)
LEFT OUTER JOIN DM_ERC.DIM_EVENEMENT_AU_DECES AS DT_DECES_1 ON (SRC.CD_EVENEMENT_AU_DECES_1=DT_DECES_1.CD_EVENEMENT_AU_DECES)
LEFT OUTER JOIN DM_ERC.DIM_EVENEMENT_AU_DECES AS DT_DECES_2 ON (SRC.CD_EVENEMENT_AU_DECES_2=DT_DECES_2.CD_EVENEMENT_AU_DECES);
create or replace view VW_ERC_FT_SOE_LIBERATION_RESERVE_NON_COD(
	ID_DIM_DATE_EVALUATION_DATE,
	SK_ID_DIM_POLICE,
	SK_ID_DIM_GROUPE_CSM,
	SK_ID_DIM_STATUS,
	RESERVE_MONTH_START_BEL,
	PREMIUM_BEL,
	INITIAL_RECOGNITION_BEL,
	ACQ_EPENSE_BEL,
	INTEREST_BEL,
	CLAIMS_BEL,
	INVESTMENT_COMPONENT_BEL,
	EXPENSE_BEL,
	MORTALITY_COST_BEL,
	EXPERIENCE_ADJUSTMENT_BEL,
	BALANCE_BEL,
	RESERVE_MONTH_END_BEL,
	RESERVE_MONTH_START_RA,
	INITIAL_RECOGNITION_RA,
	INTEREST_RA,
	RELEASE_RA,
	MORTALITY_COST_RA,
	EXPERIENCE_ADJUSTMENT_RA,
	BALANCE_RA,
	RESERVE_MONTH_END_RA,
	MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS,
	MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG,
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2,
	MD_START_DT,
	MD_ROW_IS_VALID
) as
WITH 
	NON_COD AS (
				SELECT
					TO_VARCHAR(SRCNC.MD_START_DT::DATE,'YYYYMMDD')::NUMBER(8, 0)    AS ID_DIM_DATE_EVALUATION_DATE
					-- champs de lookup
					,'Information introuvable'                                  AS STATUS
					, SHA1( NVL( SRCNC.POLICY_ID::STRING, '#NULL#') )           AS NK_POLICE
					, SHA1( NVL( SRCNC.GROUPE_CSM::STRING, '#NULL#') )          AS NK_GROUPE_CSM 
					-- mesures
					, NVL(SRCNC.MNT_BEL_CURRDISC_CURRNFA_PPE, 0)                                                                                                                            AS RESERVE_MONTH_START_BEL
					, NVL(SRCNC.MNT_EXPECTED_PREMIUM, 0)                                                                                                                                    AS PREMIUM_BEL
					, (NVL(SRCNC.MNT_PV_CLAIM_AND_NON_ACQ_EXP_INIT_RECOG, 0) - NVL(SRCNC.MNT_PV_PREM_AND_RELATED_CFS_INIT_RECOG, 0) + NVL(SRCNC.MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG, 0))   AS INITIAL_RECOGNITION_BEL
					, (NVL(SRCNC.MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS, 0) - NVL(SRCNC.MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG, 0))                                                           AS ACQ_EPENSE_BEL 
					, (NVL(SRCNC.MNT_EXPECTED_INTEREST_ON_BEL, 0) -  NVL(SRCNC.MNT_PE_CHANGE_IN_FA_CHANGE_IN_BEL, 0) - NVL(SRCNC.MNT_PS_CHANGE_IN_FA_CHANGE_IN_BEL, 0))                     AS INTEREST_BEL
					, NVL(SRCNC.MNT_REVENUE_EXPECTED_CLAIMS, 0)                                                                                                                             AS CLAIMS_BEL
					, NVL(SRCNC.MNT_EXPECTED_INVESTMENT_COMPONENT_PAID, 0)                                                                                                                  AS INVESTMENT_COMPONENT_BEL
					, NVL(SRCNC.MNT_REVENUE_EXPECTED_EXPENSES, 0)                                                                                                                           AS EXPENSE_BEL				
					, NVL(SRCNC.MNT_BEL_CURR_DISC_CURR_NFA, 0)                                                                                                                              AS RESERVE_MONTH_END_BEL
					, NVL(SRCNC.MNT_RA_CURR_DISC_CURR_NFA_PPE, 0)                                                                                                                           AS RESERVE_MONTH_START_RA
					, NVL(SRCNC.MNT_RA_AT_INITIAL_RECOGNITION, 0)                                                                                                                           AS INITIAL_RECOGNITION_RA
					, (NVL(SRCNC.MNT_EXPECTED_INTEREST_ON_RA, 0) -  NVL(SRCNC.MNT_PE_CHANGE_IN_FA_CHANGE_IN_RA, 0) - NVL(SRCNC.MNT_PS_CHANGE_IN_FA_CHANGE_IN_RA, 0))                        AS INTEREST_RA				
					, NVL(-SRCNC.MNT_EXPECTED_RA_RELEASE, 0)                                                                                                                                AS RELEASE_RA
					, NVL(SRCNC.MNT_RA_CURR_DISC_CURR_NFA, 0)                                                                                                                               AS RESERVE_MONTH_END_RA
					, 0                                                                                                                                      								AS MORTALITY_COST_BEL
				    , 0                                                                                                                                       								AS MORTALITY_COST_RA 
					
					-- les mesures plus bas ont une dependance sur les mesures en haut
					, ( - NVL(SRCNC.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL, 0) -  MORTALITY_COST_BEL)                                                                                      AS EXPERIENCE_ADJUSTMENT_BEL
					,  RESERVE_MONTH_END_BEL -  (RESERVE_MONTH_START_BEL + PREMIUM_BEL + INITIAL_RECOGNITION_BEL + ACQ_EPENSE_BEL + INTEREST_BEL +
							CLAIMS_BEL + INVESTMENT_COMPONENT_BEL + EXPENSE_BEL + MORTALITY_COST_BEL  + EXPERIENCE_ADJUSTMENT_BEL)                                                          AS  BALANCE_BEL
					, ( - NVL(SRCNC.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_RA, 0) - MORTALITY_COST_RA)                                                                                         AS EXPERIENCE_ADJUSTMENT_RA
					, ( RESERVE_MONTH_END_RA - (RESERVE_MONTH_START_RA + INITIAL_RECOGNITION_RA + INTEREST_RA +
									 RELEASE_RA + MORTALITY_COST_RA + EXPERIENCE_ADJUSTMENT_RA ))                                                                                           AS BALANCE_RA
					,SRCNC.MD_START_DT
	                ,NVL(SRCNC.MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS,0) AS MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS
	                ,NVL(SRCNC.MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG,0) AS MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG
				                  
	              FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_NON_CODE AS SRCNC  				
				)
SELECT 
    NVL(ID_DIM_DATE_EVALUATION_DATE, -1)    AS ID_DIM_DATE_EVALUATION_DATE
    , NVL(D_POL.SK_ID_DIM_POLICE, -1)       AS SK_ID_DIM_POLICE
    , NVL(D_GR.SK_ID_DIM_GROUPE_CSM, -1)    AS SK_ID_DIM_GROUPE_CSM
    , NVL(D_ST.SK_ID_DIM_STATUS, -1)        AS SK_ID_DIM_STATUS
    , RESERVE_MONTH_START_BEL
    , PREMIUM_BEL
    , INITIAL_RECOGNITION_BEL
    , ACQ_EPENSE_BEL
    , INTEREST_BEL
    , CLAIMS_BEL
    , INVESTMENT_COMPONENT_BEL
    , EXPENSE_BEL
    , MORTALITY_COST_BEL
    , EXPERIENCE_ADJUSTMENT_BEL
    , BALANCE_BEL
    , RESERVE_MONTH_END_BEL
    , RESERVE_MONTH_START_RA
    , INITIAL_RECOGNITION_RA
    , INTEREST_RA
    , RELEASE_RA
    , MORTALITY_COST_RA
    , EXPERIENCE_ADJUSTMENT_RA
    , BALANCE_RA
    , RESERVE_MONTH_END_RA
    , MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS
    , MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG
    , '0' AS MD_HASH_NAT_KEY
    , '0' AS MD_HASHDIFF_TYPE_1
    , '0' AS MD_HASHDIFF_TYPE_2
    , NC.MD_START_DT
    , CASE WHEN ID_DIM_DATE_EVALUATION_DATE = '19000101'
            OR D_POL.SK_ID_DIM_POLICE < 0
            OR D_GR.SK_ID_DIM_GROUPE_CSM < 0
            OR D_ST.SK_ID_DIM_STATUS < 0
            THEN 0 ELSE 1 END AS MD_ROW_IS_VALID
FROM NON_COD AS NC
LEFT JOIN DM_ERC.DIM_POLICE AS D_POL ON (NC.NK_POLICE = D_POL.MD_HASH_NAT_KEY AND NC.MD_START_DT BETWEEN D_POL.MD_ACTIVATION_DT AND D_POL.MD_OBSOLESCENCE_DT)
LEFT JOIN DM_ERC.DIM_STATUS AS D_ST ON (NC.STATUS = D_ST.STATUS)
LEFT JOIN DM_ERC.DIM_GROUPE_CSM AS D_GR ON (NC.NK_GROUPE_CSM = D_GR.MD_HASH_NAT_KEY);
create or replace view VW_ERC_FT_SOE_LIBERATION_RESERVE_REASSURANCE(
	ID_DIM_DATE_EVALUATION,
	ID_DIM_DATE_EMISSION,
	ID_DIM_DATE_DECES_1,
	ID_DIM_DATE_DECES_SAISIE_1,
	ID_DIM_DATE_DECES_2,
	ID_DIM_DATE_DECES_SAISIE_2,
	SK_ID_DIM_POLICE,
	SK_ID_DIM_GROUPE_CSM,
	SK_ID_DIM_TRANSACTION_CODE,
	SK_ID_DIM_PARTICIPANT_RENTES,
	SK_ID_DIM_REASSUREUR,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_PRODUIT,
	SK_ID_DIM_STATUS,
	SK_ID_DIM_EVENEMENT_AU_DECES_1,
	SK_ID_DIM_EVENEMENT_AU_DECES_2,
	RESERVE_MONTH_START_BEL,
	RESERVE_MONTH_START_RA,
	RESERVE_MONTH_START_LIC,
	RESERVE_MONTH_START_RETRO_DIFF,
	PREMIUM_BEL,
	INITIAL_RECOGNITION_BEL,
	INITIAL_RECOGNITION_RA,
	ACQ_EPENSE_BEL,
	INTEREST_BEL,
	INTEREST_RA,
	CLAIMS_PAYOUT_BEL,
	CLAIMS_DEATH_BENEFIT_BEL,
	PAYOUT_LIC,
	INVESTMENT_COMPONENT_RETRO_DIFF,
	EXPENSE_BEL,
	MORTALITY_COST_BEL,
	DECES_RACHAT_BEL,
	MORTALITY_COST_RA,
	DECES_RACHAT_RA,
	EXPERIENCE_ADJUSTMENT_RETRO_DIFF,
	RESERVE_MONTH_END_BEL,
	RESERVE_MONTH_END_RA,
	RESERVE_MONTH_END_LIC,
	RESERVE_MONTH_END_RETRO_DIFF,
	RELEASE_RA,
	NEW_CLAIMS_LIC,
	CLAIMS_RETRO_DIFF,
	INDICATEUR_RGDE,
	RELEASE_LIC,
	EXPERIENCE_ADJUSTMENT_BEL,
	EXPERIENCE_ADJUSTMENT_RA,
	BALANCE_BEL,
	BALANCE_RA,
	INDICATEUR_SUIVI_ITROUVABLE_ADMIN,
	SEX_1ST_LIFE,
	SEX_2ND_LIFE,
	AGE_1ST_LIFE_AT_ISS,
	AGE_1ST_LIFE,
	AGE_2ND_LIFE_AT_ISS,
	AGE_2ND_LIFE,
	FORM_OF_PENSION,
	VOLUME_PAYOUT,
	TOTAL_PAYOUT,
	POSITIVE_RESERVE,
	STATE,
	ISS_YEAR_ORIG,
	ISS_MONTH_ORIG,
	CD_DIVISION_PROVINCE_COMPTABLE,
	IND_BULK_CHECK,
	POLICY_ID,
	GROUPE_CSM,
	CH,
	CD_CIE,
	SK_ID_DIM_SEX_LIFE_1,
	SK_ID_DIM_SEX_LIFE_2,
	MD_START_DT,
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2,
	MD_ROW_IS_VALID
) as
WITH 	
  -- Obtenir les POLICY_ID a evaluer : utiliser la combinaison  Scalar + LIC + Rétro diff
  TBL_POLICY_ID_VALUATION  AS (
					  			SELECT MD_START_DT AS DATE_EVALUATION ,POLICY_ID   FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_REASSURANCE  
								UNION
								SELECT MD_START_DT AS DATE_EVALUATION ,POLICY_ID   FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LIC_REASSURANCE   
								UNION
								SELECT MD_START_DT AS DATE_EVALUATION ,POLICY_ID   FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_RETRO_REASSURANCE 
							   )

	-- Pivoter le DRILLDOWN_OUTPUT_IFRS17  pour avoir la Granularité police
	,TBL_DRILLDOWN_OUTPUT_IFRS17 AS ( 
									SELECT 
										MD_START_DT, POLICY_ID, 
										SUM(CASE WHEN RELEASE_TYPE_NAME = 'BEL' AND ROW_DESC ='Expected Release on Death' THEN NVL(AMOUNT, 0) ELSE 0 END) AS BEL_MORTALITY_COST,
										SUM(CASE WHEN RELEASE_TYPE_NAME = 'RA'  AND ROW_DESC ='Expected Release on Death' THEN NVL(AMOUNT, 0) ELSE 0 END) AS RA_MORTALITY_COST,
										SUM(CASE WHEN RELEASE_TYPE_NAME = 'BEL' AND ROW_DESC ='Actual Release on Death'   THEN NVL(AMOUNT, 0) ELSE 0 END) AS BEL_DECES_RACHAT,
										SUM(CASE WHEN RELEASE_TYPE_NAME = 'RA'  AND ROW_DESC ='Actual Release on Death'   THEN NVL(AMOUNT, 0) ELSE 0 END) AS RA_DECES_RACHAT
									FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_DRILLDOWN_OUTPUT_IFRS17
									WHERE RELEASE_TYPE_NAME IN ('BEL', 'RA')
									AND ROW_DESC IN ('Expected Release on Death', 'Actual Release on Death')
									GROUP BY MD_START_DT, POLICY_ID
									)
									
    ,TBL_SOE_CF_OUTPUT_IFRS17_RPU AS (
									SELECT  
										MD_START_DT, POLICY_ID, 
										SUM(CASE WHEN ROW_DESC IN ('Payout - Assurance(*)', 'Payout - Investment component') 				THEN NVL(AMOUNT, 0) ELSE 0 END)  AS BEL_CLAIMS_PAYOUT, 
										SUM(CASE WHEN ROW_DESC IN ('Death benefit - Assurance(*)', 'Death benefit - Investment component')  THEN NVL(AMOUNT, 0) ELSE 0 END)  AS BEL_CLAIMS_DEATHBENEFIT
									FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SOE_CF_OUTPUT_IFRS17_RPU
									GROUP BY MD_START_DT, POLICY_ID
								 )	
    ,TBL_STATS_ETATS_FINANCIERS AS (
 									   SELECT 
									      FTI.*,CONCAT(GROUPE,NVL(PREFIXE,''),DIVISION,CERTIFICAT) AS CLE_PARTICIPANT
									       --IND_GARDER_LIGNE : Pour garder une seule ligne par CLE_PARTICIPANT et DatDATE_REGLEE 
								           ,ROW_NUMBER() OVER(PARTITION BY FTI.MD_START_DT::DATE,CLE_PARTICIPANT ORDER BY IFF(MONTANT_DU_TROPPAYE<>0 OR DATE_DECES <>'0',1,2) ASC, TO_DATE(FTI.DATE_CREATION_DECES, 'YYYYMMDD') ASC) AS IND_GARDER_LIGNE    
								          FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_STATS_ETATS_FINANCIERS AS FTI
								          QUALIFY IND_GARDER_LIGNE=1
                                        )

							
SELECT
	/* ID Date peut etre obtenu sans  faire de jointure avec le Dim Date */
	 NVL(TO_VARCHAR(POL_EVAL.DATE_EVALUATION::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0) 				    AS ID_DIM_DATE_EVALUATION
	,NVL((RV.ISS_YEAR || RIGHT('0'||RV.ISS_MONTH,2) || RIGHT('0'||RV.ISS_DAY,2)),'19000101')::NUMBER(8,0)   AS ID_DIM_DATE_EMISSION
	,NVL(TO_VARCHAR(DECES_1.PART_DT_DECES::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0) 					    AS ID_DIM_DATE_DECES_1
	,NVL(TO_VARCHAR(DECES_1.PART_DECES_DT_SAISIE::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0)  				AS ID_DIM_DATE_DECES_SAISIE_1	
	,NVL(TO_VARCHAR(DECES_2.PART_DT_DECES::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0) 					    AS ID_DIM_DATE_DECES_2
	,NVL(TO_VARCHAR(DECES_2.PART_DECES_DT_SAISIE::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0)  				AS ID_DIM_DATE_DECES_SAISIE_2

	,NVL(DT_POL.SK_ID_DIM_POLICE,-1) 				AS SK_ID_DIM_POLICE
	,NVL(DT_GR_CSM.SK_ID_DIM_GROUPE_CSM,-1) 		AS SK_ID_DIM_GROUPE_CSM
	,NVL(DT_TR_CD.SK_ID_DIM_TRANSACTION_CODE,-1) 	AS SK_ID_DIM_TRANSACTION_CODE
	,NVL(DT_PA_RE.SK_ID_DIM_PARTICIPANT_RENTES,-1) 	AS SK_ID_DIM_PARTICIPANT_RENTES
	,NVL(DT_REAS.SK_ID_DIM_REASSUREUR,-1) 			AS SK_ID_DIM_REASSUREUR
	,NVL(DT_TER.SK_ID_DIM_TERRITOIRE,-1) 			AS SK_ID_DIM_TERRITOIRE
	,NVL(SK_ID_DIM_PRODUIT,-1) 						AS SK_ID_DIM_PRODUIT
	,NVL(SK_ID_DIM_STATUS,-1)                       AS SK_ID_DIM_STATUS	
	, NVL(DT_DECES_1.SK_ID_DIM_EVENEMENT_AU_DECES, -1)             AS SK_ID_DIM_EVENEMENT_AU_DECES_1
    , NVL(DT_DECES_2.SK_ID_DIM_EVENEMENT_AU_DECES, -1)             AS SK_ID_DIM_EVENEMENT_AU_DECES_2
	-- Colonnes Mesure
	,NVL(SR.MNT_BEL_CURRDISC_CURRNFA_PPE,0)																															AS RESERVE_MONTH_START_BEL
	,NVL(SR.MNTRA_CURRDISC_CURRNFA_PPE,0)																															AS RESERVE_MONTH_START_RA
	,NVL(LIC.MNT_LIC,0)																																				AS RESERVE_MONTH_START_LIC
	
	,(NVL(RR.MNT_BEL_CURR_DISC_CURR_NFA,0)
	  + NVL(RR.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL,0)
	  - NVL(RR.MNT_EXPECTED_INVESTMENT_COMPONENT_PAID,0)
	  - NVL(RR.MNT_REVENUE_EXPECTED_CLAIMS,0))																														AS RESERVE_MONTH_START_RETRO_DIFF	
	
	,NVL(SR.MNT_EXPECTED_PREMIUM,0)																																	AS PREMIUM_BEL
	
	,(NVL(SR.MNT_PV_CLAIM_AND_NON_ACQ_EXP_INIT_RECOG,0) 
	  - NVL(SR.MNT_PV_PREM_AND_RELATED_CFS_INIT_RECOG,0) 
	  + NVL(SR.MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG,0))																												AS INITIAL_RECOGNITION_BEL
	
	,NVL(SR.MNT_RA_AT_INITIAL_RECOGNITION,0)																														AS INITIAL_RECOGNITION_RA
	,NVL(SR.MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS,0) - NVL(SR.MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG,0)																AS ACQ_EPENSE_BEL 
	,NVL(SR.MNT_EXPECTED_INTEREST_ON_BEL,0) - NVL(SR.MNT_PE_CHANGE_IN_FA_CHANGE_IN_BEL,0) - NVL(SR.MNT_PS_CHANGE_IN_FA_CHANGE_IN_BEL,0)								AS INTEREST_BEL
	,NVL(SR.MNT_EXPECTED_INTEREST_ON_RA,0) - NVL(SR.MNT_PE_CHANGE_IN_FA_CHANGE_IN_RA,0) - NVL(SR.MNT_PS_CHANGE_IN_FA_CHANGE_IN_RA,0)								AS INTEREST_RA 
	,NVL(DECODE(RV.POSITIVE_RESERVE , 'Y', 1, -1 ) * CASH.BEL_CLAIMS_PAYOUT,0)																						AS CLAIMS_PAYOUT_BEL
	,NVL(DECODE(RV.POSITIVE_RESERVE , 'Y', 1, -1 ) *  CASH.BEL_CLAIMS_DEATHBENEFIT,0)																				AS CLAIMS_DEATH_BENEFIT_BEL  
	,NVL(-1*LIC.MNT_EXP_B_PAID_PAST,0)																																AS PAYOUT_LIC
	,NVL(RR.MNT_EXPECTED_INVESTMENT_COMPONENT_PAID,0)																												AS INVESTMENT_COMPONENT_RETRO_DIFF
	,NVL(SR.MNT_REVENUE_EXPECTED_EXPENSES,0)																														AS EXPENSE_BEL
	,NVL(DECODE(RV.POSITIVE_RESERVE , 'Y',-1,  1 ) * DRILL.BEL_MORTALITY_COST,0)																					AS MORTALITY_COST_BEL
	,NVL(DECODE(RV.POSITIVE_RESERVE , 'Y', 1, -1 ) * DRILL.BEL_DECES_RACHAT,0)																						AS DECES_RACHAT_BEL
	,NVL(DECODE(RV.POSITIVE_RESERVE , 'Y',-1,  1 ) * DRILL.RA_MORTALITY_COST,0)																						AS MORTALITY_COST_RA
	,NVL(DECODE(RV.POSITIVE_RESERVE , 'Y', 1, -1 ) * DRILL.RA_DECES_RACHAT,0) 																						AS DECES_RACHAT_RA
	,NVL(-RR.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL,0)																												AS EXPERIENCE_ADJUSTMENT_RETRO_DIFF
	,NVL(SR.MNT_BEL_CURR_DISC_CURR_NFA,0)																															AS RESERVE_MONTH_END_BEL	
	,NVL(SR.MNT_RA_CURR_DISC_CURR_NFA,0)																															AS RESERVE_MONTH_END_RA
	,NVL(LIC.MNT_BEL_B_LIC_160,0)																																	AS RESERVE_MONTH_END_LIC
	,NVL(RR.MNT_BEL_CURR_DISC_CURR_NFA,0)																															AS RESERVE_MONTH_END_RETRO_DIFF
	,NVL(-SR.MNT_EXPECTED_RA_RELEASE,0)																																AS RELEASE_RA 
	,(NVL(LIC.MNT_BEL_B_LIC_160,0)-NVL(LIC.MNT_BEL_B_LIC_140,0))																									AS NEW_CLAIMS_LIC
	,NVL(RR.MNT_REVENUE_EXPECTED_CLAIMS,0)																															AS CLAIMS_RETRO_DIFF
	,NVL(RV.IND_REGLEMENT_DECES,0) 																																	AS INDICATEUR_RGDE
	-- les colonnes ci-dessous dependent des colonnes calculé ci-Haut.
	, NVL(RESERVE_MONTH_END_LIC,0) - (NVL(RESERVE_MONTH_START_LIC,0) + NVL(PAYOUT_LIC,0) + NVL(NEW_CLAIMS_LIC,0))													AS RELEASE_LIC
	,(-NVL(SR.MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL,0) - MORTALITY_COST_BEL - DECES_RACHAT_BEL) 																	AS EXPERIENCE_ADJUSTMENT_BEL 
	
	,(-NVL(MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_RA,0)  - MORTALITY_COST_RA  - DECES_RACHAT_RA) 																		AS EXPERIENCE_ADJUSTMENT_RA 
	
	,RESERVE_MONTH_END_BEL - (RESERVE_MONTH_START_BEL   + PREMIUM_BEL + INITIAL_RECOGNITION_BEL  + ACQ_EPENSE_BEL + INTEREST_BEL  + CLAIMS_PAYOUT_BEL  
	  + CLAIMS_DEATH_BENEFIT_BEL  + EXPENSE_BEL  + MORTALITY_COST_BEL + DECES_RACHAT_BEL + EXPERIENCE_ADJUSTMENT_BEL) 				AS BALANCE_BEL
	
	 ,RESERVE_MONTH_END_RA - (RESERVE_MONTH_START_RA + INITIAL_RECOGNITION_RA + INTEREST_RA + RELEASE_RA 
	 	+ MORTALITY_COST_RA + DECES_RACHAT_RA + EXPERIENCE_ADJUSTMENT_RA) 																							AS BALANCE_RA
	
	
	, CASE WHEN FTI.CLE_PARTICIPANT  IS NOT NULL AND UPPER(NVL(FTI.INTROUVABLE,'')) = 'VRAI' THEN 1 ELSE 0 END 														AS INDICATEUR_SUIVI_ITROUVABLE_ADMIN
   
	-- les colonnes ci-dessous ajoute pour le Besoin#2
	,RV.SEX_1ST_LIFE 						AS SEX_1ST_LIFE
	,RV.SEX_2ND_LIFE			 			AS SEX_2ND_LIFE 	
	,RV.AGE_1ST_LIFE_AT_ISS					AS AGE_1ST_LIFE_AT_ISS
	,RV.AGE_1ST_LIFE						AS AGE_1ST_LIFE
	,RV.AGE_2ND_LIFE_AT_ISS					AS AGE_2ND_LIFE_AT_ISS
	,RV.AGE_2ND_LIFE						AS AGE_2ND_LIFE
	,RV.FORM_OF_PENSION						AS FORM_OF_PENSION
	,NVL(RV.VOLUME_PAYOUT,0)				AS VOLUME_PAYOUT
	,NVL(RV.TOTAL_PAYOUT,0)					AS TOTAL_PAYOUT	
	,RV.POSITIVE_RESERVE					AS POSITIVE_RESERVE
	,RV.STATE								AS STATE
	,RV.ISS_YEAR_ORIG						AS ISS_YEAR_ORIG
	,RV.ISS_MONTH_ORIG						AS ISS_MONTH_ORIG
	,RV.CD_DIVISION_PROVINCE_COMPTABLE		AS CD_DIVISION_PROVINCE_COMPTABLE
	,RV.IND_BULK_CHECK						AS IND_BULK_CHECK				
    ,POL_EVAL.POLICY_ID
	,COALESCE(SR.GROUPE_CSM,LIC.GROUPE_CSM ,RR.GROUPE_CSM) AS GROUPE_CSM
	,NVL(CH.CH,'45') 									   AS CH
    ,CD_CIE
	, DECODE(RV.SEX_1ST_LIFE , 'F' , 1 , 'M' , 2 , -1)  AS SK_ID_DIM_SEX_LIFE_1
    , DECODE(RV.SEX_2ND_LIFE , 'F' , 1 , 'M' , 2 , -1)  AS SK_ID_DIM_SEX_LIFE_2
	, POL_EVAL.DATE_EVALUATION AS MD_START_DT
    ,'0' AS MD_HASH_NAT_KEY 
	,'0' AS MD_HASHDIFF_TYPE_1
	,'0' AS MD_HASHDIFF_TYPE_2
    , CASE WHEN ID_DIM_DATE_EVALUATION = '19000101' -- a valider
                OR SK_ID_DIM_POLICE < 0
                OR SK_ID_DIM_GROUPE_CSM < 0
                OR SK_ID_DIM_TRANSACTION_CODE < 0 
                OR SK_ID_DIM_PARTICIPANT_RENTES <  0
                OR SK_ID_DIM_REASSUREUR < 0
                OR SK_ID_DIM_TERRITOIRE < 0
                OR SK_ID_DIM_PRODUIT < 0
            THEN 0 ELSE 1 END AS MD_ROW_IS_VALID        
FROM TBL_POLICY_ID_VALUATION AS POL_EVAL
LEFT JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_RENTES_VARIABLE AS RV ON (POL_EVAL.POLICY_ID=RV.POLICY_ID AND POL_EVAL.DATE_EVALUATION=RV.MD_START_DT)
LEFT JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_REASSURANCE AS SR ON (POL_EVAL.POLICY_ID=SR.POLICY_ID AND POL_EVAL.DATE_EVALUATION=SR.MD_START_DT)
LEFT JOIN TBL_DRILLDOWN_OUTPUT_IFRS17 AS DRILL ON (POL_EVAL.POLICY_ID = DRILL.POLICY_ID AND POL_EVAL.DATE_EVALUATION=DRILL.MD_START_DT)
LEFT JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LIC_REASSURANCE AS LIC ON (POL_EVAL.POLICY_ID=LIC.POLICY_ID AND POL_EVAL.DATE_EVALUATION=LIC.MD_START_DT)
LEFT JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_RETRO_REASSURANCE AS RR ON (POL_EVAL.POLICY_ID=RR.POLICY_ID AND POL_EVAL.DATE_EVALUATION=RR.MD_START_DT)
LEFT JOIN TBL_SOE_CF_OUTPUT_IFRS17_RPU AS CASH  ON  (POL_EVAL.POLICY_ID = CASH.POLICY_ID AND POL_EVAL.DATE_EVALUATION=CASH.MD_START_DT)
LEFT JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_INFORMATION_CH_VARIABLE AS CH  ON (POL_EVAL.POLICY_ID = IFF(CH.POLICY_ID_OLD_MM='0',CH.POLICY_ID_OLD_MM_1,CH.POLICY_ID_OLD_MM) AND POL_EVAL.DATE_EVALUATION=CH.MD_START_DT)
LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LISTE_DECES AS DECES_1  ON (DECES_1.RENTE_NO_ORI IS NULL AND REPLACE(REPLACE(POL_EVAL.POLICY_ID,'_V',''),'_B','')=DECES_1.RENTE_NO AND MONTH(POL_EVAL.DATE_EVALUATION)=MONTH(DECES_1.PART_DECES_DT_SAISIE) AND YEAR(POL_EVAL.DATE_EVALUATION)= YEAR(DECES_1.PART_DECES_DT_SAISIE) AND POL_EVAL.DATE_EVALUATION=DECES_1.MD_START_DT)
LEFT OUTER JOIN DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_LISTE_DECES AS DECES_2  ON (DECES_2.RENTE_NO_ORI IS NOT NULL AND REPLACE(REPLACE(POL_EVAL.POLICY_ID,'_V',''),'_B','')= DECES_2.RENTE_NO_ORI AND MONTH(POL_EVAL.DATE_EVALUATION)= MONTH(DECES_2.PART_DECES_DT_SAISIE) AND YEAR(POL_EVAL.DATE_EVALUATION)= YEAR(DECES_2.PART_DECES_DT_SAISIE) AND POL_EVAL.DATE_EVALUATION=DECES_2.MD_START_DT)
     

-- Lookup sur les dimensions
LEFT JOIN DM_ERC.DIM_POLICE AS DT_POL ON(POL_EVAL.POLICY_ID=DT_POL.POLICY_ID)
LEFT JOIN DM_ERC.DIM_REASSUREUR AS DT_REAS ON (DECODE(RIGHT(POL_EVAL.POLICY_ID,1), 'B' , 'DBB', 'RGA') = DT_REAS.REASSUREUR_CD)
LEFT JOIN DM_ERC.DIM_GROUPE_CSM AS DT_GR_CSM ON(COALESCE(SR.GROUPE_CSM,LIC.GROUPE_CSM ,RR.GROUPE_CSM)=DT_GR_CSM.GROUPE_CSM_NOM)
LEFT JOIN DM_ERC.DIM_TRANSACTION_CODE AS DT_TR_CD ON (NVL(CH.CH,'45')=DT_TR_CD.TRANSACTION_CD)
LEFT JOIN DM_ERC.DIM_PARTICIPANT_RENTES AS DT_PA_RE ON (RV.NO_CONTRAT=DT_PA_RE.CONTRAT_NO AND NVL(RV.CD_PREFIXE_CONTRAT,'')=DT_PA_RE.CONTRAT_PREFIXE_CD 
																		AND RV.NO_DIV=DT_PA_RE.DIVISION_NO AND RV.NO_PARTICIPANT=DT_PA_RE.PARTICIPANT_NO
																		AND RV.NO_RENTE=DT_PA_RE.RENTE_NO  AND RV.CD_CIE=DT_PA_RE.COMPANIE_CD)
LEFT JOIN DM_ERC.DIM_TERRITOIRE AS DT_TER ON (RV.CD_DIVISION_PROVINCE_COMPTABLE=DT_TER.PROVINCE_ETAT_CD)
LEFT JOIN DM_ERC.DIM_PRODUIT AS DT_PROD ON (RV.PRODUCT=DT_PROD.PRODUIT)	
LEFT JOIN DM_ERC.DIM_STATUS AS DT_STA ON (DECODE(RV.STATUS, 4 , 'RETR' , 'DIFF')=DT_STA.STATUS)
LEFT OUTER JOIN DM_ERC.DIM_EVENEMENT_AU_DECES AS DT_DECES_1 ON (DECES_1.EVENT_CD_AU_DECES=DT_DECES_1.CD_EVENEMENT_AU_DECES)
LEFT OUTER JOIN DM_ERC.DIM_EVENEMENT_AU_DECES AS DT_DECES_2 ON (DECES_2.EVENT_CD_AU_DECES=DT_DECES_2.CD_EVENEMENT_AU_DECES)
LEFT JOIN TBL_STATS_ETATS_FINANCIERS AS FTI ON (CONCAT(RV.NO_CONTRAT,NVL(RV.CD_PREFIXE_CONTRAT,''),RV.NO_DIV,RV.NO_PARTICIPANT)=FTI.CLE_PARTICIPANT
 														AND DATE_TRUNC('MONTH', RV.MD_START_DT) = DATE_TRUNC('MONTH', TO_DATE(FTI.DATE_CREATION_DECES, 'YYYYMMDD')) 
 														AND RV.MD_START_DT::DATE=FTI.MD_START_DT::DATE  
													 );
create or replace view VW_ERC_FT_SOE_LIBERATION_RESERVE_SWAPFIXED_REASSURANCE(
	ID_DIM_DATE_EVALUATION,
	SK_ID_DIM_POLICE,
	SK_ID_DIM_GROUPE_CSM,
	SK_ID_DIM_PARTICIPANT_RENTES,
	SK_ID_DIM_REASSUREUR,
	PERIODE,
	POLICY_ID,
	POLICY_ID_EX,
	CD_PREFIXE_CONTRAT,
	NO_CONTRAT,
	NO_DIV,
	NO_PARTICIPANT,
	NO_RENTE,
	GROUPE_CSM,
	GROUPE_CSM_DIRECT_ASSOCIE,
	MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG,
	MNT_ACTUAL_PREMIUM,
	MNT_ACTUAL_UNDERLYING_ITEMS_PAID,
	MNT_BEL_AT_INITIAL_RECOGNITION,
	MNT_BEL_CURR_DISC_CURR_NFA,
	MNT_BEL_CURRDISC_CURRNFA_PPE,
	MNT_CHANGE_IN_NFA_CHANGE_IN_BEL,
	MNT_CHANGE_IN_NFA_CHANGE_IN_RA,
	MNT_CONTRACTUAL_SERVICE_MARGIN_PPE,
	MNT_DECREASE_IN_VARIABLE_FEE,
	MNT_EXPECTED_INTEREST_ON_BEL,
	MNT_EXPECTED_INTEREST_ON_RA,
	MNT_EXPECTED_INV_INC_ON_UNDERLYING_ITEM,
	MNT_EXPECTED_PREMIUM,
	MNT_EXPECTED_RA_RELEASE,
	MNT_EXPECTED_UNDERLYING_ITEMS_PAID,
	MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL,
	MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_RA,
	MNT_INFORCE_NUMBER_OF_COVERAGES,
	MNT_LOSS_COMPONENT_PPE,
	MNT_LOSS_COMPONENT_ALLOCATION_BASIS,
	MNT_OTHER_ACTUAL_PREMIUM_RELATED_CFS,
	MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS,
	MNT_PE_CHANGE_IN_FA_CHANGE_IN_BEL,
	MNT_PE_CHANGE_IN_FA_CHANGE_IN_RA,
	MNT_PS_CHANGE_IN_FA_CHANGE_IN_BEL,
	MNT_PS_CHANGE_IN_FA_CHANGE_IN_RA,
	MNT_RA_AT_INITIAL_RECOGNITION,
	MNT_RA_CURR_DISC_CURR_NFA,
	MNT_RA_CURR_DISC_CURR_NFA_PPE,
	MNT_REVENUE_EXPECTED_CLAIMS,
	MNT_REVENUE_EXPECTED_EXPENSES,
	MNT_UNAMORTIZED_ACQUISITION_EXPENSE,
	MNT_ACTUAL_INVESTMENT_COMPONENT_PAID,
	MNT_EXPECTED_INVESTMENT_COMPONENT_PAID,
	QTE_CURRENT_SERVICE,
	QTE_FUTURE_SERVICE,
	MNT_PV_CLAIM_AND_NON_ACQ_EXP_INIT_RECOG,
	MNT_PV_OF_EXP_CLAIMS_ON_INITIAL_RECOG,
	MNT_PV_OF_EXPECTED_CLAIMS,
	MNT_PV_OF_EXPECTED_CLAIMS_PPE,
	MNT_PV_PREM_AND_RELATED_CFS_INIT_RECOG,
	MNT_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD,
	MNT_PV_ACQ_EXPENSE_AT_INIT_RECOG
) as
SELECT 
 NVL(TO_VARCHAR(SR.MD_START_DT::DATE,'YYYYMMDD'),'19000101')::NUMBER(8,0)	AS ID_DIM_DATE_EVALUATION
, NVL(DT_POL.SK_ID_DIM_POLICE,-1) 											AS SK_ID_DIM_POLICE
, NVL(DT_GR_CSM.SK_ID_DIM_GROUPE_CSM,-1) 									AS SK_ID_DIM_GROUPE_CSM		
, NVL(DT_PA_RE.SK_ID_DIM_PARTICIPANT_RENTES,-1) 							AS SK_ID_DIM_PARTICIPANT_RENTES
, NVL(DT_REAS.SK_ID_DIM_REASSUREUR,-1) 										AS SK_ID_DIM_REASSUREUR		
, PERIODE
, SR.POLICY_ID
, SR.POLICY_ID_EX
, CD_PREFIXE_CONTRAT
, NO_CONTRAT
, NO_DIV
, NO_PARTICIPANT
, NO_RENTE
, GROUPE_CSM
, GROUPE_CSM_DIRECT_ASSOCIE
, MNT_ACQ_EXPENSE_IN_FCF_AT_INIT_RECOG
, MNT_ACTUAL_PREMIUM
, MNT_ACTUAL_UNDERLYING_ITEMS_PAID
, MNT_BEL_AT_INITIAL_RECOGNITION
, MNT_BEL_CURR_DISC_CURR_NFA
, MNT_BEL_CURRDISC_CURRNFA_PPE
, MNT_CHANGE_IN_NFA_CHANGE_IN_BEL
, MNT_CHANGE_IN_NFA_CHANGE_IN_RA
, MNT_CONTRACTUAL_SERVICE_MARGIN_PPE
, MNT_DECREASE_IN_VARIABLE_FEE
, MNT_EXPECTED_INTEREST_ON_BEL
, MNT_EXPECTED_INTEREST_ON_RA
, MNT_EXPECTED_INV_INC_ON_UNDERLYING_ITEM
, MNT_EXPECTED_PREMIUM
, MNT_EXPECTED_RA_RELEASE
, MNT_EXPECTED_UNDERLYING_ITEMS_PAID
, MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_BEL
, MNT_EXPERIENCE_ADJUSTMENT_CHANGE_IN_RA
, MNT_INFORCE_NUMBER_OF_COVERAGES
, MNT_LOSS_COMPONENT_PPE
, MNT_LOSS_COMPONENT_ALLOCATION_BASIS
, MNT_OTHER_ACTUAL_PREMIUM_RELATED_CFS
, MNT_OTHER_EXPECTED_PREMIUM_RELATED_CFS
, MNT_PE_CHANGE_IN_FA_CHANGE_IN_BEL
, MNT_PE_CHANGE_IN_FA_CHANGE_IN_RA
, MNT_PS_CHANGE_IN_FA_CHANGE_IN_BEL
, MNT_PS_CHANGE_IN_FA_CHANGE_IN_RA
, MNT_RA_AT_INITIAL_RECOGNITION
, MNT_RA_CURR_DISC_CURR_NFA
, MNT_RA_CURR_DISC_CURR_NFA_PPE 
, MNT_REVENUE_EXPECTED_CLAIMS
, MNT_REVENUE_EXPECTED_EXPENSES
, MNT_UNAMORTIZED_ACQUISITION_EXPENSE
, MNT_ACTUAL_INVESTMENT_COMPONENT_PAID
, MNT_EXPECTED_INVESTMENT_COMPONENT_PAID
, QTE_CURRENT_SERVICE
, QTE_FUTURE_SERVICE
, MNT_PV_CLAIM_AND_NON_ACQ_EXP_INIT_RECOG
, MNT_PV_OF_EXP_CLAIMS_ON_INITIAL_RECOG
, MNT_PV_OF_EXPECTED_CLAIMS
, MNT_PV_OF_EXPECTED_CLAIMS_PPE
, MNT_PV_PREM_AND_RELATED_CFS_INIT_RECOG
, MNT_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD
, MNT_PV_ACQ_EXPENSE_AT_INIT_RECOG
FROM DB_ACT_DEV_STG.MODEL_ERC.VW_ERC_SCALARS_SWAPFIXED_REASSURANCE AS SR
-- Lookup sur les dimensions
LEFT JOIN DM_ERC.DIM_POLICE AS DT_POL ON(SR.POLICY_ID=DT_POL.POLICY_ID)
LEFT JOIN DM_ERC.DIM_REASSUREUR AS DT_REAS ON (DECODE(RIGHT(SR.POLICY_ID,1), 'B' , 'DBB', 'RGA') = DT_REAS.REASSUREUR_CD)
LEFT JOIN DM_ERC.DIM_GROUPE_CSM AS DT_GR_CSM ON(SR.GROUPE_CSM=DT_GR_CSM.GROUPE_CSM_NOM)
LEFT JOIN DM_ERC.DIM_PARTICIPANT_RENTES AS DT_PA_RE ON (SR.NO_CONTRAT=DT_PA_RE.CONTRAT_NO AND NVL(SR.CD_PREFIXE_CONTRAT,'')=DT_PA_RE.CONTRAT_PREFIXE_CD 
																		AND SR.NO_DIV=DT_PA_RE.DIVISION_NO AND SR.NO_PARTICIPANT=DT_PA_RE.PARTICIPANT_NO
																		AND SR.NO_RENTE=DT_PA_RE.RENTE_NO);
create or replace schema DM_US_VI;

create or replace TABLE DIM_AGENCY (
	SK_ID_DIM_AGENCY NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	AGENCY_CD VARCHAR(10) NOT NULL,
	AGENCY_NAME VARCHAR(100) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_SEX_PK primary key (SK_ID_DIM_AGENCY)
);
create or replace TABLE DIM_AGENT (
	SK_ID_DIM_AGENT NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	AGENT_CD VARCHAR(10) NOT NULL,
	AGENT_NAME VARCHAR(100) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_SEX_PK primary key (SK_ID_DIM_AGENT)
);
create or replace TABLE DIM_AGE_GROUP (
	SK_ID_DIM_AGE_GROUP NUMBER(4,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	AGE_GROUP_CODE VARCHAR(20) NOT NULL,
	AGE_GROUP_NAME VARCHAR(20) NOT NULL,
	AGE_GROUP_LABEL VARCHAR(50) NOT NULL,
	AGE_GROUP_MIN NUMBER(4,0) NOT NULL,
	AGE_GROUP_MAX NUMBER(4,0) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_AGE_GROUPING_PK primary key (SK_ID_DIM_AGE_GROUP)
)COMMENT='Cette table contient la liste d''âges possibles des assurés (0 à 150), regroupés selon des tranches d''âges pré-établies.'
;
create or replace TABLE DIM_COVERAGE (
	SK_ID_DIM_COVERAGE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	POLICY_ID VARCHAR(50) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la dimension, utilisé pour faire le lien entre les couvertures des systèmes adm et les résultats Axis',
	POLICY_NO VARCHAR(30) NOT NULL COMMENT 'Identifiant de la police à laquelle est ratachée la couverture.',
	COMPANY_CODE VARCHAR(3) NOT NULL COMMENT 'Code identifiant la compagnie émettrice de la couverture',
	PHASE VARCHAR(2) NOT NULL,
	SUB_PHASE VARCHAR(2) NOT NULL,
	COVERAGE_TYPE_CODE VARCHAR(1) NOT NULL,
	INTERNAL_COMPANY VARCHAR(10) NOT NULL,
	IND_ASSUMED VARCHAR(1) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COVERAGE_PK primary key (SK_ID_DIM_COVERAGE)
)COMMENT='Cette table devrait contenir l''ensemble des attributs de type 1 de la couverture.  Les attibuts de type 2 seront suivis dans la table Factless Fact table.'
;
create or replace TABLE DIM_COVERAGE_AXIS_MODULE (
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	COVERAGE_AXIS_MODULE_CODE VARCHAR(10) NOT NULL COMMENT 'Code identifiant le module utilisé dans Axis pour traiter la couverture.  Les valeurs possibles sont RL, PAR, UL, DI. Il s''agit également de la clé d''affaire',
	COVERAGE_AXIS_MODULE_NAME VARCHAR(50) NOT NULL COMMENT 'Nom du module Axis.  Pour l''instant le domaine de valeurs se limite à AN = Annuity, RL = Regular Life, UL = Universal Life, DI = Disability',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COVERAGE_AXIS_MODULE_PK primary key (SK_ID_DIM_COVERAGE_AXIS_MODULE)
);
create or replace TABLE DIM_COVERAGE_STATUS (
	SK_ID_DIM_COVERAGE_STATUS NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	COVERAGE_STATUS_CD VARCHAR(10) NOT NULL COMMENT 'Code identifiant le statut de la couverture',
	COVERAGE_STATUS_NAME VARCHAR(50) NOT NULL COMMENT 'nom du statut de la couverture',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COVERAGE_STATUS_PK primary key (SK_ID_DIM_COVERAGE_STATUS)
);
create or replace TABLE DIM_DATE (
	ID_DIM_DATE NUMBER(8,0) NOT NULL COMMENT 'Identifiant Date du jour',
	DAY_SHORT_DATE DATE COMMENT 'Champ en format date de la journée',
	SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Date en format court français selon les paramêtres régionaux, ex: 2016-02-14',
	SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Date en format court anglais selon les paramêtres régionaux, ex: 02/14/2016',
	NAME_FR VARCHAR(50) NOT NULL COMMENT 'Date en format long français selon les paramêtres régionaux, ex: 14 février 2016',
	NAME_EN VARCHAR(50) NOT NULL COMMENT 'Date en format long anglais selon les paramêtres régionaux, ex: Saturday, February 14, 2016',
	WEEK_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro de journée dans la semaine ISO (Lundi=1, Dimanche=7)',
	MONTH_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le mois (1 à 31)',
	QUARTER_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le trimestre (1 à 91)',
	SEMESTER_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le semestre (1 à 184)',
	YEAR_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans l''année (1 à 366)',
	DAY_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom abrégé français de la journée de la semaine, ex: dim.',
	DAY_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom abrégé anglais de la journée de la semaine, ex: Sun',
	DAY_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la journée de la semaine, ex: \"\"dimanche\"\"',
	DAY_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la journée de la semaine, ex: \"\"Sunday\"\"',
	WEEKEND_IND BOOLEAN NOT NULL COMMENT 'Indique si la journée est un jour de fin de semaine (samedi ou dimanche)',
	WEEK_CD VARCHAR(10) NOT NULL COMMENT 'Code de la semaine sous la forme aaaaSnn, ex: 2016S01',
	WEEK_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro de la semaine dans l''année; 53 possible',
	WEEK_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français de la semaine, ex: \"\"Sem. 12\"\"',
	WEEK_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais de la semaine, ex: \"\"Wk 12\"\"',
	WEEK_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la semaine, ex: \"\"Semaine 12\"\"',
	WEEK_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la semaine, ex: \"\"Week 12\"\"',
	WEEK_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français de la semaine dans l''année, ex: \"\"2016, Sem. 12\"\"',
	WEEK_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais de la semaine dans l''année, ex: \"\"2016, Wk. 12\"\"',
	WEEK_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la semaine dans l''année, ex: \"\"2016, Semaine 12\"\"',
	WEEK_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la semaine dans l''année, ex: \"\"2016, Week 12\"\"',
	WEEK_START_DT DATE NOT NULL COMMENT 'Date du début de la semaine ',
	WEEK_END_DT DATE NOT NULL COMMENT 'Date de la fin de la semaine ',
	WEEK_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours de la semaine ',
	MONTH_CD VARCHAR(10) NOT NULL COMMENT 'Code du mois sous la forme aaaaMnn, ex: 2016M05',
	MONTH_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du mois (1 à 12)',
	MONTH_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du mois, ex: \"\"janv.\"\"',
	MONTH_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du mois,  ex: \"\"Jan\"\"',
	MONTH_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du mois, ex: Janvier\"\"',
	MONTH_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du mois, ex: January\"\"',
	MONTH_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du mois de l''année, ex: \"\"janv. 2016\"\"',
	MONTH_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du mois de l''année, ex: \"\"Jan 2016\"\"',
	MONTH_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du mois de l''année, ex: \"\"janvier 2016\"\"',
	MONTH_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du mois de l''année, ex: \"\"January 2016\"\"',
	MONTH_START_DT DATE NOT NULL COMMENT 'Date du début du mois',
	MONTH_END_DT DATE NOT NULL COMMENT 'Date de fin du mois',
	MONTH_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours du mois',
	QUARTER_CD VARCHAR(10) NOT NULL COMMENT 'Code du trimestre sous la forme aaaaQnn, ex: 2016Q03',
	QUARTER_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du trimestre (1 à 4)',
	QUARTER_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du trimestre, ex : \"\"T1\"\"',
	QUARTER_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du trimestre, ex : \"\"Q1\"\"',
	QUARTER_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du trimestre, ex : \"\"Trimestre 1\"\"',
	QUARTER_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du trimestre, ex : \"\"Quarter 1\"\"',
	QUARTER_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du trimestre de l''année , ex : \"\"T1, 2016\"\"',
	QUARTER_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du trimestre de l''année, ex : \"\"Q1, 2016\"\"',
	QUARTER_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du trimestre de l''année , ex : \"\"Trimestre 1, 2016\"\"',
	QUARTER_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du trimestre de l''année , ex : \"\"Quarter 1, 2016\"\"',
	QUARTER_START_DT DATE NOT NULL COMMENT 'Date de début du trimestre',
	QUARTER_END_DT DATE NOT NULL COMMENT 'Date de fin du trimestre',
	QUARTER_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours dans le trimeste (90, 91 ou 92)',
	SEMESTER_CD VARCHAR(10) NOT NULL COMMENT 'Code de semestre sous la forme aaaaSnn, ex: 2016S01 ou 2016S02 (du 1 janvier au 30 juin et 1 juillet au 31 décembre)',
	SEMESTER_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du semestre (1 ou 2)',
	SEMESTER_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du semestre, ex: \"\"S1\"\"',
	SEMESTER_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du semestre, ex: \"\"S1\"\"',
	SEMESTER_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du semestre, ex: \"\"Semestre 1\"\"',
	SEMESTER_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du semestre, ex: \"\"Semester 1\"\"',
	SEMESTER_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du semestre dans l''année, ex: \"\"S1, 2016\"\"',
	SEMESTER_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du semestre dans l''année, ex: \"\"S1, 2016\"\"',
	SEMESTER_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du semestre dans l''année, ex: \"\"Semestre 1, 2016\"\"',
	SEMESTER_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du semestre dans l''année, ex: \"\"Semester 1, 2016\"\"',
	SEMESTER_START_DT DATE NOT NULL COMMENT 'Date de début du semestre',
	SEMESTER_END_DT DATE NOT NULL COMMENT 'Date de fin du semestre',
	SEMESTER_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours dans le semestre (183 ou 184)',
	YEAR_CD NUMBER(38,0) NOT NULL COMMENT 'Code de l''année sous la forme aaaa',
	YEAR_SHORT_NAME_FR VARCHAR(4) NOT NULL COMMENT 'Nom court français de l''année, ex: 2016',
	YEAR_SHORT_NAME_EN VARCHAR(4) NOT NULL COMMENT 'Nom court anglais de l''année, ex: 2016',
	YEAR_NAME_FR VARCHAR(4) NOT NULL COMMENT 'Nom long français de l''année, ex: 2016',
	YEAR_NAME_EN VARCHAR(4) NOT NULL COMMENT 'Nom long anglais de l''année, ex: 2016',
	YEAR_START_DT DATE NOT NULL COMMENT 'Date de début de l''année, ex: 2016-01-01',
	YEAR_END_DT DATE NOT NULL COMMENT 'Date de fin de l''année, ex: 2016-12-31',
	YEAR_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours de l''année',
	constraint PK_DIM_DATE primary key (ID_DIM_DATE)
);
create or replace TABLE DIM_DURATION_RANGE (
	SK_ID_DIM_DURATION_RANGE NUMBER(4,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	DURATION_RANGE_CODE VARCHAR(20) NOT NULL,
	DURATION_RANGE_NAME VARCHAR(20) NOT NULL,
	DURATION_RANGE_LABEL VARCHAR(50) NOT NULL,
	DURATION_RANGE_MIN NUMBER(4,0) NOT NULL,
	DURATION_RANGE_MAX NUMBER(4,0) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_DURATION_RANGE_PK primary key (SK_ID_DIM_DURATION_RANGE)
)COMMENT='Cette table contient la liste d''âges possibles des assurés (0 à 150), regroupés selon des tranches d''âges pré-établies.'
;
create or replace TABLE DIM_GL_CHART (
	SK_ID_DIM_GL_CHART NUMBER(20,0) NOT NULL autoincrement,
	CD_ENTITY VARCHAR(4) NOT NULL,
	CD_NATURE VARCHAR(6) NOT NULL,
	CD_ORIGIN VARCHAR(2) NOT NULL,
	CD_PERIODICITY VARCHAR(2) NOT NULL,
	CD_COST_CENTER VARCHAR(4) NOT NULL,
	CD_INTERCO VARCHAR(4) NOT NULL,
	CD_LINE_OF_BUSINESS VARCHAR(3) NOT NULL,
	CD_PRODUCT VARCHAR(4) NOT NULL,
	CD_PARTICIPATION VARCHAR(2) NOT NULL,
	CD_GEOGRAPHY VARCHAR(3) NOT NULL,
	CD_PROJECT VARCHAR(3) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_GL_CHART_PK primary key (SK_ID_DIM_GL_CHART)
);
create or replace TABLE DIM_GROUP_CSM (
	SK_ID_DIM_GROUP_CSM NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	NOM_GROUP_CSM VARCHAR(100) NOT NULL COMMENT 'Nom du groupe CSM',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_GROUPE_CSM_PK primary key (SK_ID_DIM_GROUP_CSM)
)COMMENT='Table de dimension contenant la liste des groupes CSM (Marge de Service Contractuelle) assignés aux couvertures (directe et réssurance) lors de leur première valorisation.'
;
create or replace TABLE DIM_MASTER_COA (
	SK_ID_DIM_MASTER_COA NUMBER(20,0) NOT NULL autoincrement,
	VARIABLE_CSM VARCHAR(300) NOT NULL,
	CUSTOM_DIM_1 VARCHAR(100) NOT NULL,
	CUSTOM_DIM_2 VARCHAR(100) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_MASTER_COA_PK primary key (SK_ID_DIM_MASTER_COA)
);
create or replace TABLE DIM_PFT (
	SK_ID_DIM_PFT NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	AXIS_PLAN_CODE VARCHAR(50) NOT NULL COMMENT 'Identifiant unique du plan.  Clé d''affaire de la dimension',
	CD_AXIS_CELL_NAME VARCHAR(255),
	CD_AXIS_MODULE VARCHAR(255),
	CD_PRM_PAYING_PERIOD_CODE VARCHAR(255),
	DESCRIPT VARCHAR(255),
	PRODUCT VARCHAR(255),
	GROUPE VARCHAR(255),
	SUB_GROUP VARCHAR(255),
	OTHER_BENEFIT_LINK_1 VARCHAR(255),
	OTHER_BENEFIT_LINK_2 VARCHAR(255),
	OTHER_BENEFIT_LINK_3 VARCHAR(255),
	REINSURANCE_TERMS_1 VARCHAR(255),
	BONUS_METHODS VARCHAR(255),
	CRV_MGM_PPAYMENT_PERIOD VARCHAR(255),
	RT_MODAL_PREMIUM_FACTORS_MONTHLY NUMBER(28,10),
	RT_MODAL_PREMIUM_FACTORS_PAC NUMBER(28,10),
	RT_MINIMUM_CREDITED_INTEREST NUMBER(28,10),
	RT_CREDITED_SPREAD NUMBER(28,10),
	RT_FLAT_FOR_CRVM_GUAR_MIN_CRI NUMBER(10,0),
	N_POLICY_FEE_WITH_EACH_PREMIUM_ANNUAL NUMBER(10,0),
	N_POLICY_FEE_WITH_EACH_PREMIUM_SEMIANNUAL NUMBER(10,0),
	N_POLICY_FEE_WITH_EACH_PREMIUM_QUATERLY NUMBER(10,0),
	N_POLICY_FEE_WITH_EACH_PREMIUM_MONTHLY NUMBER(10,0),
	N_POLICY_FEE_WITH_EACH_PREMIUM_PAC NUMBER(10,0),
	N_MODAL_PREMIUM_FACTORS_SEMIANNUAL NUMBER(10,0),
	N_MODAL_PREMIUM_FACTORS_QUATERLY NUMBER(10,0),
	N_FIRST_LIFE_DEFINITION NUMBER(10,0),
	N_FLAT_FOR_PROP_OF_POLICY_FEE_COMM NUMBER(10,0),
	N_MATURITY_VALUE_METHOD NUMBER(10,0),
	N_MULTIPLE_REINSURANCE NUMBER(10,0),
	N_FIRST_YEAR_COMMISSION NUMBER(10,0),
	N_PROP_OF_FIRST_YEAR_COMM_ADVANCE NUMBER(10,0),
	N_PERIOD_USING_COMM_ADVANCEMENT_SETTING NUMBER(10,0),
	N_GUARANTEED_PERIOD_FOR_NLG_CRITERIA_1 NUMBER(10,0),
	N_SINGLE_PREM_INDICATOR NUMBER(10,0),
	N_PREMIUM_SCHEDULE NUMBER(10,0),
	N_CRVM_ALTERNATIVE_GMP NUMBER(10,0),
	N_GMP_PREMIUM_MODE NUMBER(10,0),
	N_BENEFIT_PERIOD_CAUSE_1 NUMBER(10,0),
	N_ELIMINATION_PERIOD_CAUSE_1 NUMBER(10,0),
	N_MAXIMUM_BENEFIT_MONTHS_CAUSE_1 NUMBER(10,0),
	N_BENEFIT_PERIOD_METHOD NUMBER(10,0),
	N_FREQUENCY_OF_CHARGE_SMETHOD NUMBER(10,0),
	N_VANISHING_PREMIUM_METHOD NUMBER(10,0),
	N_VANISH_DURATION NUMBER(10,0),
	N_PRM_PAYING_PERIOD_AGE NUMBER(10,0),
	N_PRM_PAYING_PERIOD_DUR NUMBER(10,0),
	N_DI_BENEFIT_FACTOR NUMBER(10,0),
	N_MID_YEAR_CSV_METHOD NUMBER(10,0),
	N_PLAN_TYPE NUMBER(10,0),
	N_ANN_LIFE_STATUS NUMBER(10,0),
	N_MULT_FOR_FACE_AMOUNT NUMBER(10,0),
	TBL_PREMIUM VARCHAR(255),
	TBL_COMMISSION VARCHAR(255),
	TBL_CASH_VALUE VARCHAR(255),
	TBL_ROP VARCHAR(255),
	TBL_FACE_AMOUNT VARCHAR(255),
	TBL_BONUS_AND_CHARGE_BACK VARCHAR(255),
	TBL_DIVIDEND VARCHAR(255),
	TBL_PREMIUM_LOAD VARCHAR(255),
	TBL_GARANTEE_PREMIUMLOAD VARCHAR(255),
	TBL_EXPENSE_CHARGE VARCHAR(255),
	TBL_GARANTEE_EXPENSE_CHARGE VARCHAR(255),
	TBL_RISK_CHARGE VARCHAR(255),
	TBL_GARANTEED_RISK_CHARGE VARCHAR(255),
	TBL_SURRENDER_CHARGE VARCHAR(255),
	TBL_GARANTEED_PREMIUM VARCHAR(255),
	TBL_MIN_SURRENDER_VALUE VARCHAR(255),
	TBL_FUND_BONUS VARCHAR(255),
	TBL_CRVM_FUND_BONUS VARCHAR(255),
	TBL_CRVM_GMP VARCHAR(255),
	TBL_DUMPING_PREMIUM VARCHAR(255),
	TBL_PRICING_UTILIZATION VARCHAR(255),
	TBL_ANN_PAYOUT VARCHAR(255),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_PFT_PK primary key (SK_ID_DIM_PFT)
)COMMENT='Cette table contient les attributs provenant du fichier PFT (ou Product Features Table).  Il s''agit des caractéristiques reliées aux planx représentéx par un code de plan Axis.'
;
create or replace TABLE DIM_RATE_TYPE (
	SK_ID_DIM_RATE_TYPE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	RATE_TYPE_NAME VARCHAR(50) NOT NULL COMMENT 'Nom du type de taux d''intérêt utilisé pour les calculs dans AXIS.  Ex: Locked-In = Taux d''intérêt à l''émission de la couverture; CURRENT = Taux d''intérêt à la date d''évaluation.  Il s''agit également de la clé d''affaire',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_RATE_TYPE_PK primary key (SK_ID_DIM_RATE_TYPE)
)COMMENT='Liste des types de taux d''intérêt utilisés pour les calculs dans AXIS. Ex: Locked-In = Taux d''intérêt à l''émission de la couverture; CURRENT = Taux d''intérêt à la date d''évaluation.'
;
create or replace TABLE DIM_REASSUREUR (
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	REINSURANCE_COMPANY VARCHAR(3) NOT NULL,
	REINSURANCE_CONTRACT VARCHAR(3) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_REASSUREUR_PK primary key (SK_ID_DIM_REASSUREUR)
)COMMENT='Table de dimension contenant la liste des identifiants des compagnies de réassurance'
;
create or replace TABLE DIM_RESERVE_RELEASE_TYPE (
	SK_ID_DIM_RESERVE_RELEASE_TYPE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	RESERVE_RELEASE_TYPE VARCHAR(50) NOT NULL COMMENT 'Nom du type de liberation de reserve.  Il s''agit également de la clé d''affaire',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_TRESERVE_RELEASE_TYPE_PK primary key (SK_ID_DIM_RESERVE_RELEASE_TYPE)
)COMMENT='Contient la liste des type d''hypothèse de libération de réserve.  (RA ou BEL)'
;
create or replace TABLE DIM_SEX (
	SK_ID_DIM_SEX NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	SEX_CD VARCHAR(10) NOT NULL COMMENT 'Code identifiant le genre de l''assuré.',
	SEXE_NAME VARCHAR(50) NOT NULL COMMENT 'Nom du genre de l''assuré',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_SEX_PK primary key (SK_ID_DIM_SEX)
);
create or replace TABLE DIM_SMOKING_STATUS (
	SK_ID_DIM_SMOKING_STATUS NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	SMOKING_STATUS_CODE VARCHAR(10) NOT NULL COMMENT 'Code identifiant le statut fumeur',
	SMOKING_STATUS_NAME VARCHAR(50) NOT NULL COMMENT 'Nom du statut fumeur',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_SMOKING_STATUS_PK primary key (SK_ID_DIM_SMOKING_STATUS)
)COMMENT='Cette table contient la liste des différents statuts fumeur considérés lors de la taraification des couvertures.'
;
create or replace TABLE DIM_STATE (
	SK_ID_DIM_STATE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	STATE_CD VARCHAR(10) NOT NULL,
	STATE_NAME VARCHAR(100) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_SEX_PK primary key (SK_ID_DIM_STATE)
);
create or replace TABLE DIM_TERMINATION_REASON (
	SK_ID_DIM_TERMINATION_REASON NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	TERMINATION_REASON_CD VARCHAR(10) NOT NULL,
	TERMINATION_REASON VARCHAR(100) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_SEX_PK primary key (SK_ID_DIM_TERMINATION_REASON)
);
create or replace TABLE DIM_VAT (
	SK_ID_DIM_VAT NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	AXIS_PLAN_CODE VARCHAR(50) NOT NULL COMMENT 'Identifiant unique du plan.  Clé d''affaire de la dimension',
	CD_AXIS_CELL_NAME VARCHAR(255),
	CD_AXIS_MODULE VARCHAR(255),
	CD_ESCAP_TYPE VARCHAR(255),
	CD_ESCAP_CLASS VARCHAR(255),
	CD_ESC_PAR_BLOCK VARCHAR(255),
	DESCRIPT VARCHAR(255),
	PRODUCT VARCHAR(255) COMMENT 'Attribut utilisé pour regrouper les codes de plan.  Hierarchie par Groupe/Produit.',
	GROUPE VARCHAR(255) COMMENT 'Attribut utilisé pour regrouper les codes de plan.  Hierarchie par Groupe/Produit.',
	SUB_GROUP VARCHAR(255),
	BASE_CELL_NAME VARCHAR(255),
	STAT_RESERVE_METHOD_LINK VARCHAR(255),
	TAX_RESERVE_METHOD_LINK VARCHAR(255),
	SECOND_RESERVE_METHOD_LINK VARCHAR(255),
	ESCAP_ADJUS_TABLE_PRODUCT VARCHAR(255),
	ESCAP_DEATH_DESIGNATION VARCHAR(255),
	ESCAP_LAPSE_DESIGNATION VARCHAR(255),
	ESCAP_MORTALITY_GROUP VARCHAR(255),
	ESCAP_CSV_DEFICIENCY_GROUP VARCHAR(255),
	ESCAP_PFAD_EXCLUSION_GROUP VARCHAR(255),
	ESCAP_PAR_OR_ADJUSTABLEID VARCHAR(255),
	RT_FLAT_FOR_PREMIUM_TAX_RATE NUMBER(28,10),
	RT_STAT_RES_FLAT_FOR_FINAL_MORTALITY_MAD NUMBER(28,10),
	RT_STAT_RES_FLAT_FOR_LAPSE_PAD NUMBER(28,10),
	N_REINSURANCE_TERMS_1_PERCENTAGE NUMBER(10,0),
	N_PRICING_MULT_FOR_MORTALITY NUMBER(10,0),
	N_PRICING_MULT_FOR_LAPSE_RATE NUMBER(10,0),
	N_PRICING_MULT_FOR_OTHER_BENEFIT_RATES NUMBER(10,0),
	N_STAT_RES_MULT_FOR_MORTALITY NUMBER(10,0),
	N_STAT_RES_MULT_FOR_LAPSE_RATE NUMBER(10,0),
	N_STAT_RES_MULT_FOR_OTHER_BENEFIT_RATES NUMBER(10,0),
	N_STAT_RES_MULT_FOR_EXPENSES NUMBER(10,0),
	N_TAX_RES_MULT_FOR_OTHER_BENEFIT_RATES NUMBER(10,0),
	N_SECOND_RES_MULT_FOR_OTHER_BENEFIT_RATES NUMBER(10,0),
	N_TAX_RES_REVALUATION_METHOD NUMBER(10,0),
	N_STAT_RES_REVALUATIO_NMETHOD NUMBER(10,0),
	N_SCND_RES_REVALUATION_METHOD NUMBER(10,0),
	N_STAT_RES_MULT_FOR_CAUSE_1_QI NUMBER(10,0),
	N_STAT_RES_MULT_FOR_TERMINATION_CAUSE_1 NUMBER(10,0),
	N_PRICING_ANN_MULT_FOR_2ND_LIFE_Q NUMBER(10,0),
	N_STAT_RES_ANN_MULT_FOR_2ND_LIFE_Q NUMBER(10,0),
	TBL_AGE_DISTRIBUTION VARCHAR(255),
	TBL_PRICING_MORTALITY VARCHAR(255),
	TBL_PRICING_LAPSE_RATE VARCHAR(255),
	TBL_PRICING_OTHER_BENEFIT_RATES VARCHAR(255),
	TBL_PRICING_EXPENSES VARCHAR(255),
	TBL_PRICING_INTEREST VARCHAR(255),
	TBL_STAT_RES_MORTALITY VARCHAR(255),
	TBL_STAT_RES_LAPSERATE VARCHAR(255),
	TBL_STAT_RES_OTHER_BENEFIT_RATES VARCHAR(255),
	TBL_STAT_RES_EXPENSES VARCHAR(255),
	TBL_STAT_RES_INTEREST VARCHAR(255),
	TBL_TAX_RES_MORTALITY VARCHAR(255),
	TBL_TAX_RES_INTEREST VARCHAR(255),
	TBL_TAX_RES_OTHER_BENEFIT_RATES VARCHAR(255),
	TBL_TAX_INPUT_TERMINAL_RES_FACTORS VARCHAR(255),
	TBL_SECOND_RES_MORTALITY VARCHAR(255),
	TBL_SECOND_RES_INTEREST VARCHAR(255),
	TBL_SECOND_RES_ANN_INTEREST VARCHAR(255),
	TBL_SECOND_RES_OTHER_BENEFIT_RATES VARCHAR(255),
	TBL_SCND_INPUT_TERMINAL_RES_FACTORS VARCHAR(255),
	TBL_SECOND_RES_TOTAL_PREMIUM VARCHAR(255),
	TBL_PRICING_CAUSE_1_QI VARCHAR(255),
	TBL_PRICING_TERMINATION_CAUSE_1 VARCHAR(255),
	TBL_STAT_RES_CAUSE_1_QI VARCHAR(255),
	TBL_STAT_RES_TERMINATION_CAUSE_1 VARCHAR(255),
	TBL_PRICING_ANN_2ND_LIFE_Q VARCHAR(255),
	TBL_STAT_RES_ANN_2ND_LIFE_Q VARCHAR(255),
	TBL_TAX_RES_ANN_2ND_LIFE_Q VARCHAR(255),
	TBL_SECOND_RES_ANN_2ND_LIFE_Q VARCHAR(255),
	TBL_PRICING_2ND_LIFE_ANN_PROJ VARCHAR(255),
	TBL_STAT_RES_2ND_LIFE_ANN_PROJ VARCHAR(255),
	TBL_PRICING_ANN_PROJ VARCHAR(255),
	TBL_STAT_RES_ANN_PROJ VARCHAR(255),
	TBL_ESCAP_BASE_LAPSE VARCHAR(255),
	PBR NUMBER(10,0),
	VM20_CREDIBILITY NUMBER(10,0),
	VM20_YEAR_TO_BEGING_RADING NUMBER(10,0),
	VM20_YEAR_TO_GRADE_TO_INDUTRY NUMBER(10,0),
	THIRD_RESERVE_METHOD_LINK VARCHAR(255),
	VM20_DR_SR_INTEREST_TABLE VARCHAR(255),
	VM20_DR_SR_EXPENSES_TABLE VARCHAR(255),
	VM20_DR_SR_MULT_FOR_EXPENSES NUMBER(10,0),
	VM20_DR_SR_LAPSE_RATE_TABLE VARCHAR(255),
	VM20_DR_SR_FLATFORLAPSEPAD NUMBER(28,10),
	VM20_DR_SR_MORTALITY_TABLE VARCHAR(255),
	VM20_DR_SR_MORTALITY_PAD_TABLE VARCHAR(255),
	VM20_DR_SR_MULT_FOR_LAPSE_RATE NUMBER(10,0),
	VM20_DR_SR_MULT_FOR_MORTALITY NUMBER(10,0),
	VM20_DR_SR_MULT_FOR_OTHER_BENEFIT_RATES NUMBER(10,0),
	VM20_DR_SR_OTHER_BENEFIT_RATES_TABLE VARCHAR(255),
	FOURTH_RESERVE_METHOD_LINK VARCHAR(255),
	VM20_NPR_INTEREST_TABLE VARCHAR(255),
	VM20_NPR_LAPSE_RATE_TABLE VARCHAR(255),
	VM20_NPR_MORTALITY_TABLE VARCHAR(255),
	VM20_NPR_EXPENSES_TABLE VARCHAR(255),
	PROXY_FOR_STATUS VARCHAR(10),
	ANALYSIS_GROUPING VARCHAR(50),
	ANALYSIS_GROUPING_STATUS VARCHAR(50),
	STAT_INPUT_TERMINAL_RES_FACTORS_TABLE VARCHAR(50),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_VAT_PK primary key (SK_ID_DIM_VAT)
)COMMENT='Cette table contient les attributs provenant du fichier VAT (ou Valuation Assumptions Tables).  Il s''agit des caractéristiques reliées aux plan représentés par un code de plan Axis. En fait les dimensions DIM_CODE_PLAN_AXIS et DIM_VALUATION_ASSUMPTIONS_TABLES proviennent de la même source de données dont les colonnes ont été réparties entre les deux tables de dimension.'
;
create or replace TABLE FT_COVERAGE (
	SK_ID_FT_COVERAGE NUMBER(20,0) NOT NULL autoincrement,
	ID_DIM_ISSUE_DATE NUMBER(8,0) NOT NULL,
	ID_DIM_DOD_DATE NUMBER(8,0) NOT NULL,
	ID_DIM_CLOSE_DATE NUMBER(8,0) NOT NULL,
	SK_ID_DIM_COVERAGE NUMBER(20,0) NOT NULL,
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0) NOT NULL,
	SK_ID_DIM_PFT NUMBER(20,0) NOT NULL,
	SK_ID_DIM_SEX NUMBER(20,0) NOT NULL,
	SK_ID_ISSUE_AGE_GROUP NUMBER(4,0) NOT NULL,
	SK_ID_ATTEINED_AGE_GROUP NUMBER(4,0) NOT NULL,
	SK_ID_DIM_SMOKING_STATUS NUMBER(20,0) NOT NULL,
	SK_ID_DIM_DURATION_RANGE NUMBER(4,0) NOT NULL,
	SK_ID_DIM_VAT NUMBER(20,0) NOT NULL,
	SK_ID_DIM_COVERAGE_STATUS NUMBER(20,0) NOT NULL,
	SK_ID_DIM_ISSUE_STATE NUMBER(20,0) NOT NULL,
	SK_ID_DIM_RESIDENT_STATE NUMBER(20,0) NOT NULL,
	SK_ID_DIM_AGENT NUMBER(20,0) NOT NULL,
	SK_ID_DIM_AGENCY NUMBER(20,0) NOT NULL,
	SK_ID_DIM_TERMINATION_REASON NUMBER(20,0) NOT NULL,
	POLICY_ID VARCHAR(15) NOT NULL,
	AXIS_PLAN_CODE VARCHAR(50),
	ISSUE_AGE NUMBER(3,0) NOT NULL,
	ATTEINED_AGE NUMBER(3,0) NOT NULL,
	DURATION_IN_YEARS NUMBER(3,0) NOT NULL,
	AMT_CURRENT_DEATH_BENEFIT NUMBER(20,10) NOT NULL,
	AMT_CURRENT_FACE_AMOUNT NUMBER(20,10) NOT NULL,
	AMT_ORIGINAL_FACE_AMOUNT NUMBER(20,10) NOT NULL,
	AMT_CURRENT_BENEFIT_VALUE NUMBER(20,10) NOT NULL,
	ANT_CURRENT_CASH_VALUE NUMBER(20,10) NOT NULL,
	AMT_PREVIOUS_CASH_VALUE NUMBER(20,10) NOT NULL,
	CD_PAYMENT_MODE VARCHAR(10) NOT NULL,
	CD_DEATH_BENEFIT_OPTION VARCHAR(1) NOT NULL,
	CD_LINE_OF_BUSINESS VARCHAR(2) NOT NULL,
	IND_COUVERTURE_TERMINEE BOOLEAN COMMENT 'Indicateur (0/1)  1 --> Couverture terminée, 0 --> Couverture en vigueur',
	CD_PARTICIPATION_CODE VARCHAR(1) NOT NULL,
	CD_JOINT_TYPE VARCHAR(2) NOT NULL,
	CD_SUSPENSION VARCHAR(1) NOT NULL,
	CD_TAX_QUALIFIED_STATUS VARCHAR(2) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement. Égale à MD_ACTIVATION_DT à l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement ou de fin d''effectivité de l''enregistrement dans le cas d''une mise à jour d''un enregistrement existant.  La modification à un ou plusieurs attributs d''une factless fact table devraient déclencher la MAJ de cette date et l''insertion d''un nouvel enregistrement',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé à l''aide des attributs de la clé naturelle. (Une seule clé naturelle doit être considérée dans le cas où il en existe plus d''une.  Ex: AK1, AK2,...',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait ou de factless fact table.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Calculée en considérant tous les attributs de la table, à l''exception des champs de metadata et les champs constituant les clés naturelles.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint FT_COVERAGE_PK primary key (SK_ID_FT_COVERAGE),
	constraint FT_COVERAGE_FK_DIM_COVERAGE_SK_ID_COVERAGE foreign key (SK_ID_DIM_COVERAGE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE(SK_ID_DIM_COVERAGE),
	constraint FT_COVERAGE_FK_DIM_COVERAGE_AXIS_MODULE_SK_ID_DIM_COVERAGE_AXIS_MODULE foreign key (SK_ID_DIM_COVERAGE_AXIS_MODULE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE(SK_ID_DIM_COVERAGE_AXIS_MODULE),
	constraint FT_COVERAGE_FK_DIM_PFT_SK_ID_DIM_PFT foreign key (SK_ID_DIM_PFT) references DB_ACT_DEV_DM.DM_US_VI.DIM_PFT(SK_ID_DIM_PFT),
	constraint FT_COVERAGE_FK_DIM_SEX_SK_ID_DIM_SEX foreign key (SK_ID_DIM_SEX) references DB_ACT_DEV_DM.DM_US_VI.DIM_SEX(SK_ID_DIM_SEX),
	constraint FT_COVERAGE_FK_DIM_AGE_GROUP_SK_ID_DIM_ISSUE_AGE_GROUP foreign key (SK_ID_ISSUE_AGE_GROUP) references DB_ACT_DEV_DM.DM_US_VI.DIM_AGE_GROUP(SK_ID_DIM_AGE_GROUP),
	constraint FT_COVERAGE_FK_DIM_AGE_GROUP_SK_ID_DIM_ATTEINED_AGE_GROUP foreign key (SK_ID_ATTEINED_AGE_GROUP) references DB_ACT_DEV_DM.DM_US_VI.DIM_AGE_GROUP(SK_ID_DIM_AGE_GROUP),
	constraint FT_COVERAGE_FK_DIM_SMOKING_STATUS_SK_ID_DIM_SMOKING_STATUS foreign key (SK_ID_DIM_SMOKING_STATUS) references DB_ACT_DEV_DM.DM_US_VI.DIM_SMOKING_STATUS(SK_ID_DIM_SMOKING_STATUS),
	constraint FT_COVERAGE_FK_DIM_DURATION_RANGE_SK_ID_DIM_DURATION_RANGE foreign key (SK_ID_DIM_DURATION_RANGE) references DB_ACT_DEV_DM.DM_US_VI.DIM_DURATION_RANGE(SK_ID_DIM_DURATION_RANGE),
	constraint FT_COVERAGE_FK_DIM_VAT_SK_ID_DIM_VAT foreign key (SK_ID_DIM_VAT) references DB_ACT_DEV_DM.DM_US_VI.DIM_VAT(SK_ID_DIM_VAT),
	constraint FT_COVERAGE_FK_DIM_COVERAGE_STATUS_SK_ID_DIM_COVERAGE_STATUS foreign key (SK_ID_DIM_COVERAGE_STATUS) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_STATUS(SK_ID_DIM_COVERAGE_STATUS),
	constraint FT_COVERAGE_FK_DIM_ISSUE_STATE_SK_ID_DIM_ISSUE_STATE foreign key (SK_ID_DIM_ISSUE_STATE) references DB_ACT_DEV_DM.DM_US_VI.DIM_STATE(SK_ID_DIM_STATE),
	constraint FT_COVERAGE_FK_DIM_RESIDENT_STATE_SK_ID_DIM_RESIDENT_STATE foreign key (SK_ID_DIM_RESIDENT_STATE) references DB_ACT_DEV_DM.DM_US_VI.DIM_STATE(SK_ID_DIM_STATE),
	constraint FT_COVERAGE_FK_DIM_AGENT_SK_ID_DIM_AGENT foreign key (SK_ID_DIM_AGENT) references DB_ACT_DEV_DM.DM_US_VI.DIM_AGENT(SK_ID_DIM_AGENT),
	constraint FT_COVERAGE_FK_DIM_AGENCY_SK_ID_DIM_AGENCY foreign key (SK_ID_DIM_AGENCY) references DB_ACT_DEV_DM.DM_US_VI.DIM_AGENCY(SK_ID_DIM_AGENCY),
	constraint FT_COUVERTURE_FK_DIM_TERMINATION_REASON_SK_ID_DIM_TERMINATION_REASON foreign key (SK_ID_DIM_TERMINATION_REASON) references DB_ACT_DEV_DM.DM_US_VI.DIM_TERMINATION_REASON(SK_ID_DIM_TERMINATION_REASON)
)COMMENT='Table de type ''Factless'' qui est utilisée pour faire le suivi des modifications des couvertures.'
;
create or replace TABLE FT_COVERAGE_GROUP_CSM (
	SK_ID_FT_COVERAGE_GROUP_CSM NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_ASSIGNATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de l''assignation du groupe CSM à la couverture',
	SK_ID_DIM_COVERAGE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Identifiant unique de la  couverture).',
	SK_ID_DIM_GROUP_CSM NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table dimension DIM_GROUPE_CSM.  L''assignation à un groupe CSM se fera uniquement pour les couvertures en vigueur ou récemment terminées.',
	POLICY_NO VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Si l''enregistrement est inséré pour la première fois = 1900-01-01 Sinon mettre DateExecETL',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Si Nouvel enregistrement alors 2999-12-31 sinon ETL Date Execution - 1 ms',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basnat sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basnat sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL COMMENT 'Indicateur permettant d''identifier les lignes valides (=0) et les lignes présentant une ou plusieurs anomalies (!=0)',
	constraint FT_COUVERTURE_GROUPE_CSM_PK primary key (SK_ID_FT_COVERAGE_GROUP_CSM),
	constraint FT_COUVERTURE_GROUPE_CSM_FK1 foreign key (ID_DIM_DATE_ASSIGNATION) references DB_ACT_DEV_DM.DM_US_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_COUVERTURE_GROUPE_CSM_FK2 foreign key (SK_ID_DIM_COVERAGE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE(SK_ID_DIM_COVERAGE),
	constraint FT_COUVERTURE_GROUPE_CSM_FK4 foreign key (SK_ID_DIM_GROUP_CSM) references DB_ACT_DEV_DM.DM_US_VI.DIM_GROUP_CSM(SK_ID_DIM_GROUP_CSM)
)COMMENT='Table de faits permettant d''analyser les montants reliés aux bénéfices supplémentaires reliés aux couvertures de morbidité.'
;
create or replace TABLE FT_COVERAGE_REASSURANCE_GROUP_CSM (
	SK_ID_FT_COVERAGE_GROUP_CSM NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	ID_DIM_DATE_ASSIGNATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de l''assignation du groupe CSM à la couverture',
	SK_ID_DIM_COVERAGE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE. Basé sur le GEN_UID (Identifiant unique de la  couverture).',
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_REASSUREUR. Relie la couverture au réassureur.',
	SK_ID_DIM_GROUP_CSM_REASSURANCE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table dimension DIM_GROUPE_CSM. L''assignation à un groupe CSM se fera uniquement pour les couvertures en vigueur ou récemment terminées.',
	SK_ID_DIM_GROUP_CSM_DIRECT NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table dimension DIM_GROUPE_CSM. L''assignation à un groupe CSM se fera uniquement pour les couvertures en vigueur ou récemment terminées.',
	POLICY_NO VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	COMPANY_CODE VARCHAR(3) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	REINSURANCE_COMPANY VARCHAR(3) NOT NULL COMMENT 'Utilser dans Axis pour relier les mesures Axis avec la bonne couverture, dans certain cas. ',
	REINSURANCE_CONTRACT VARCHAR(3) NOT NULL COMMENT 'Code identifiant le réassureur.  Fait partie de la clé naturelle.',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basnat sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basnat sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement',
	constraint FT_COVERAGE_REASSURANCE_GROUP_CSM_PK primary key (SK_ID_FT_COVERAGE_GROUP_CSM),
	constraint FT_COVERAGE_REASSURANCE_GROUP_CSM_FK_DIM_DATE_ID_DIM_DATE_ASSIGNATION foreign key (ID_DIM_DATE_ASSIGNATION) references DB_ACT_DEV_DM.DM_US_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_COVERAGE_REASSURANCE_GROUP_CSM_FK_DIM_COVERAGE_SK_ID_DIM_COVERAGE foreign key (SK_ID_DIM_COVERAGE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE(SK_ID_DIM_COVERAGE),
	constraint FT_COVERAGE_REASSURANCE_GROUP_CSM_FK_DIM_REASSUREUR_SK_ID_DIM_REASSUREUR foreign key (SK_ID_DIM_REASSUREUR) references DB_ACT_DEV_DM.DM_US_VI.DIM_REASSUREUR(SK_ID_DIM_REASSUREUR),
	constraint FT_COVERAGE_REASSURANCE_GROUP_CSM_FK_DIM_GROUP_CSM_SK_ID_DIM_GROUP_CSM_REASSURANCE foreign key (SK_ID_DIM_GROUP_CSM_REASSURANCE) references DB_ACT_DEV_DM.DM_US_VI.DIM_GROUP_CSM(SK_ID_DIM_GROUP_CSM),
	constraint FT_COVERAGE_REASSURANCE_GROUP_CSM_FK_DIM_GROUP_CSM_SK_ID_DIM_GROUP_CSM_DIRECT foreign key (SK_ID_DIM_GROUP_CSM_DIRECT) references DB_ACT_DEV_DM.DM_US_VI.DIM_GROUP_CSM(SK_ID_DIM_GROUP_CSM)
);
create or replace TABLE FT_GL_BALANCE (
	SK_ID_FT_GL_BALANCE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_ACCOUNTING_PERIOD_DATE NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_GL_CHART NUMBER(20,0) NOT NULL,
	SK_ID_DIM_COVERAGE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0) NOT NULL,
	POLICY_ID VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	IND_ICOS VARCHAR(1) NOT NULL,
	CD_ORIGINE VARCHAR(2) NOT NULL,
	CD_SYSTEME_SOURCE VARCHAR(20) NOT NULL,
	DISAGG_BALANCE_AMT NUMBER(28,10) NOT NULL,
	BENEFIT_PAID_CURRENT_AMT NUMBER(28,10) NOT NULL,
	INVEST_COMP_PAID_CURRENT_AMT NUMBER(28,10) NOT NULL,
	SK_ID_DIM_MASTER_COA NUMBER(20,0) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL COMMENT 'Indicateur permettant d''identifier les lignes valides (=1) et les lignes présentant une ou plusieurs anomalies (=0)',
	MD_SOURCE_PROCESS_NAME VARCHAR(50) COMMENT 'Cette table est chargée à partir de deux traitements distincts: BENEFIT DESAGREGATION or PREMIUM/COMMISSION',
	constraint FT_GL_BALANCE_PK primary key (SK_ID_FT_GL_BALANCE),
	constraint FT_GL_BALANCE_FK_DIM_DATE_ID_DIM_EVALUATION_DATE foreign key (ID_DIM_ACCOUNTING_PERIOD_DATE) references DB_ACT_DEV_DM.DM_US_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_GL_BALANCE_FK_DIM_GL_CHART_SK_ID_DIM_GL_CHART foreign key (SK_ID_DIM_GL_CHART) references DB_ACT_DEV_DM.DM_US_VI.DIM_GL_CHART(SK_ID_DIM_GL_CHART),
	constraint FT_GL_BALANCE_FK_DIM_COVERAGE_SK_ID_DIM_COVERAGE foreign key (SK_ID_DIM_COVERAGE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE(SK_ID_DIM_COVERAGE),
	constraint FT_GL_BALANCE_FK_DIM_COVERAGE_AXIS_MODULE_SK_ID_DIM_COVERAGE_AXIS_MODULE foreign key (SK_ID_DIM_COVERAGE_AXIS_MODULE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE(SK_ID_DIM_COVERAGE_AXIS_MODULE)
)COMMENT='Table de faits permettant d''analyser les montants reliés à la libération de la réserve par source (ou risque) de SOE.'
;
create or replace TABLE FT_GL_BALANCE_AGGREGATED (
	SK_ID_FT_GL_BALANCE_AGGREGATED NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_ACCOUNTING_PERIOD_DATE NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_GL_CHART NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_GL_CHART.  Basée sur l''ensemble des segments composant la charte comptable',
	UDC VARCHAR(30) NOT NULL COMMENT 'Unité de comptabilisation ou UDC.  Correspond au numéro de police lorsqu''applicable',
	CD_ORIGINE VARCHAR(2) NOT NULL COMMENT 'Code d''origine identifiant les solde direct (11), ceded (12) ou manuel (13)',
	CD_SYSTEME_SOURCE VARCHAR(20) NOT NULL COMMENT 'Nom du système admin source',
	AGG_BALANCE_AMT NUMBER(28,10) NOT NULL COMMENT 'Montant du solde',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_NOT_VALID NUMBER(3,0) NOT NULL COMMENT 'Indicateur utilisé pour identifier rapidement les enregistrements qui comportent des anomalies',
	constraint FT_GL_BALANCE_AGGREGATED_PK primary key (SK_ID_FT_GL_BALANCE_AGGREGATED),
	constraint FT_GL_BALANCE_AGGREGATED_FK_DIM_DATE_ID_DIM_ACCOUNTING_PERIOD_DATE foreign key (ID_DIM_ACCOUNTING_PERIOD_DATE) references DB_ACT_DEV_DM.DM_US_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_GL_BALANCE_AGGREGATED_FK_DIM_GL_CHART_SK_ID_DIM_GL_CHART foreign key (SK_ID_DIM_GL_CHART) references DB_ACT_DEV_DM.DM_US_VI.DIM_GL_CHART(SK_ID_DIM_GL_CHART)
)COMMENT='Table de faits permettant d''analyser les montants des soldes GL avant la désaggrégation.  S''applique uniquement aux natures spécifiques aux calculs du SOE'
;
create or replace TABLE FT_GL_BALANCE_OLD (
	SK_ID_FT_GL_BALANCE NUMBER(20,0),
	ID_DIM_ACCOUNTING_PERIOD_DATE NUMBER(8,0),
	SK_ID_DIM_GL_CHART NUMBER(20,0),
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0),
	POLICY_ID VARCHAR(30),
	IND_ICOS VARCHAR(1),
	CD_ORIGINE VARCHAR(2),
	CD_SYSTEME_SOURCE VARCHAR(20),
	DISAGG_BALANCE_AMT NUMBER(28,10),
	BENEFIT_PAID_CURRENT_AMT NUMBER(28,10),
	INVEST_COMP_PAID_CURRENT_AMT NUMBER(28,10),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50),
	MD_CREATION_AUDIT_ID NUMBER(20,0)
);
create or replace TABLE FT_SOE_CASHFLOW (
	SK_ID_FT_SOE_CASHFLOW NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_EVALUATION_DATE NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_RESERVE_RELEASE_TYPE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_RESERVE_RELEASE_TYPE.  Basé sur le reserve release type (BEL / RA). ',
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_AXIS_COUVERTURE.  Ex:  RL, UL, AN, DI.  Est déduit à partir du nom du fichier source provenant d''Axis',
	SK_ID_DIM_COVERAGE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	POLICY_ID VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	POLICY_ID_EX VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	AXIS_INCREMENT VARCHAR(20) NOT NULL,
	CODE_LIGNE_AFFAIRE VARCHAR(10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_COMMISSION NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_EXPENSE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_MISCON NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_NOTTAKENUP NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_PREMIUM NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_PREMIUMTAX NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_COMMISSION NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_EXPENSE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_MISCON NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_NOTTAKENUP NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_PREMIUM NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_PREMIUMTAX NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT NUMBER(28,10) NOT NULL COMMENT 'Prestation attendue réassurance (abandon)',
	CEDED_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_COMMISSION NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_EXPENSE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_MISCOFF NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_MISCON NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_NOTTAKENUP NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_PREMIUM NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_PREMIUMTAX NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_PAYOUT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_COMMISSION NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_EXPENSE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_MISCOFF NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_MISCON NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_NOTTAKENUP NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_PREMIUM NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_PREMIUMTAX NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT NUMBER(28,10) NOT NULL COMMENT 'Prestation attendue directe (abandon)',
	GROSS_EXPECTED_CASHFLOW_PAYOUT NUMBER(28,10) NOT NULL,
	GROSS_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL,
	constraint FT_SOE_CASHFLOW_PK primary key (SK_ID_FT_SOE_CASHFLOW),
	constraint FT_SOE_CASHFLOW_FK_DIM_DATE_ID_DIM_EVALUATION_DATE foreign key (ID_DIM_EVALUATION_DATE) references DB_ACT_DEV_DM.DM_US_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOE_CASHFLOW_FK_DIM_RESERVE_RELEASE_TYPE_SK_ID_DIM_RESERVE_RELEASE_TYPE foreign key (SK_ID_DIM_RESERVE_RELEASE_TYPE) references DB_ACT_DEV_DM.DM_US_VI.DIM_RESERVE_RELEASE_TYPE(SK_ID_DIM_RESERVE_RELEASE_TYPE),
	constraint FT_SOE_CASHFLOW_FK_DIM_COVERAGE_AXIS_MODULE_SK_ID_DIM_COVERAGE_AXIS_MODULE foreign key (SK_ID_DIM_COVERAGE_AXIS_MODULE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE(SK_ID_DIM_COVERAGE_AXIS_MODULE),
	constraint FT_SOE_CASHFLOW_FK_DIM_COVERAGE_SK_ID_DIM_COVERAGE foreign key (SK_ID_DIM_COVERAGE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE(SK_ID_DIM_COVERAGE)
)COMMENT='Table de faits permettant d''analyser les montants de prestation (cashflow) par risque '
;
create or replace TABLE FT_SOE_INVESTMENT_COMPONENT (
	SK_ID_FT_SOE_INVESTMENT_COMPONENT NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_EVALUATION_DATE NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_AXIS_COUVERTURE.  Ex:  RL, UL, AN, DI.  Est déduit à partir du nom du fichier source provenant d''Axis',
	SK_ID_DIM_COVERAGE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	POLICY_ID VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	AXIS_INCREMENT VARCHAR(20) NOT NULL,
	CODE_LIGNE_AFFAIRE VARCHAR(10) NOT NULL,
	CEDED_ACTUAL_INVCOMP_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_INVCOMP_LAPSE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_INVCOMP_OTHERBEN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_INVCOMP_SURVIVORS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_LAPSE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_OTHERBEN NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_SURVIVORS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_LAPSE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_OTHERBEN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_SURVIVORS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_LAPSE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_OTHERBEN NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_SURVIVORS NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint FT_SOE_INVESTMENT_COMPONENT_PK primary key (SK_ID_FT_SOE_INVESTMENT_COMPONENT),
	constraint FT_SOE_INVESTMENT_COMPONENT_FK_DIM_COVERAGE_AXIS_MODULE_SK_ID_DIM_COVERAGE_AXIS_MODULE foreign key (SK_ID_DIM_COVERAGE_AXIS_MODULE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE(SK_ID_DIM_COVERAGE_AXIS_MODULE),
	constraint FT_SOE_INVESTMENT_COMPONENT_FK_DIM_COVERAGE_SK_ID_DIM_COVERAGE foreign key (SK_ID_DIM_COVERAGE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE(SK_ID_DIM_COVERAGE)
)COMMENT='Table de faits permettant d''analyser les montants de composantes d''investissement par risque '
;
create or replace TABLE FT_SOE_RESERVE_RELEASE (
	SK_ID_FT_SOE_RESERVE_RELEASE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_EVALUATION_DATE NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_RESERVE_RELEASE_TYPE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TYPE_LIBERATION_RESERVE en utilisant  le type de libération égale à RA ou BEL',
	SK_ID_DIM_RATE_TYPE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_RATE_TYPE',
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_AXIS_COUVERTURE.  Ex:  RL, UL, AN, DI.  Est déduit à partir du nom du fichier source provenant d''Axis',
	SK_ID_DIM_COVERAGE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	POLICY_ID VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	POLICY_ID_EX VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	AXIS_INCREMENT VARCHAR(20) NOT NULL,
	CODE_LIGNE_AFFAIRE VARCHAR(10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_LAPSE NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve directe RÉELLE - Abandon',
	GROSS_ACTUAL_RELEASE_ON_MISC_OFF NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_MISC_ON NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_LAPSE NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve directe attendue - Abandon',
	GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_LATENB NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_NEWCESSIONS NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_PEINFTRUEUP NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_TOTAL NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_POLICYCHANGES NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	GROSS_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_LAPSE NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve réassurance RÉELLE - Abadon ',
	CEDED_ACTUAL_RELEASE_ON_MISC_OFF NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_MISC_ON NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_RELEASE_ON_LAPSE NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve réassurance attendue - Abandon',
	CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_LATENB NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_NEWCESSIONS NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_PEINFTRUEUP NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_TOTAL NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_POLICYCHANGES NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_ON_RECOVERY NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL,
	constraint FT_SOE_RESERVE_RELEASE_PK primary key (SK_ID_FT_SOE_RESERVE_RELEASE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_DATE_ID_DIM_EVALUATION_DATE foreign key (ID_DIM_EVALUATION_DATE) references DB_ACT_DEV_DM.DM_US_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_RESERVE_RELEASE_TYPE_SK_ID_DIM_RESERVE_RELEASE_TYPE foreign key (SK_ID_DIM_RESERVE_RELEASE_TYPE) references DB_ACT_DEV_DM.DM_US_VI.DIM_RESERVE_RELEASE_TYPE(SK_ID_DIM_RESERVE_RELEASE_TYPE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_RATE_TYPE_SK_ID_DIM_RATE_TYPE foreign key (SK_ID_DIM_RATE_TYPE) references DB_ACT_DEV_DM.DM_US_VI.DIM_RATE_TYPE(SK_ID_DIM_RATE_TYPE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_COVERAGE_AXIS_MODULE_SK_ID_DIM_COVERAGE_AXIS_MODULE foreign key (SK_ID_DIM_COVERAGE_AXIS_MODULE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE(SK_ID_DIM_COVERAGE_AXIS_MODULE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_COVERAGE_SK_ID_DIM_COVERAGE foreign key (SK_ID_DIM_COVERAGE) references DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE(SK_ID_DIM_COVERAGE)
)COMMENT='Table de faits permettant d''analyser les montants reliés à la libération de la réserve par source (ou risque) de SOE.'
;
CREATE OR REPLACE PROCEDURE "SP_CONV_DIM_COVERAGE_UPD"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "update DB_ACT_"+ ENV +"_DM.DM_US_VI.DIM_COVERAGE cv set cv.COMPANY_CODE = res.new_cd_comp :: VARCHAR(3) from (with cov_term as (select a.*,b.INTERNAL_COMPANY,b.POLICY_NO,b.PHASE,b.SUB_PHASE,b.COMPANY_CODE,d.GROUPE from DB_ACT_"+ ENV +"_DM.DM_US_VI.FT_COVERAGE a inner join DB_ACT_"+ ENV +"_DM.DM_US_VI.DIM_COVERAGE b on a.SK_ID_DIM_COVERAGE = b.SK_ID_DIM_COVERAGE inner join DB_ACT_"+ ENV +"_DM.DM_US_VI.DIM_VAT d on a.SK_ID_DIM_VAT = d.SK_ID_DIM_VAT where a.CD_SUSPENSION <> ''0'' and COMPANY_CODE <> ''060''), covT as (select distinct a.SK_ID_DIM_COVERAGE,a.POLICY_ID, a.POLICY_NO,a.AXIS_PLAN_CODE,a.COMPANY_CODE,a.INTERNAL_COMPANY, case when GROUPE = ''Horizon Life'' and a.COMPANY_CODE in (''110'',''220'',''440'',''770'') then a.COMPANY_CODE+1 :: VARCHAR(3) when GROUPE <> ''Horizon Life'' and a.COMPANY_CODE in (''110'',''220'',''440'',''770'') then a.COMPANY_CODE+2 :: VARCHAR(3) else a.COMPANY_CODE end   as new_cd_comp from cov_term a inner join DB_ACT_"+ ENV +"_DM.DM_US_VI.DIM_COVERAGE b on a.POLICY_NO = b.POLICY_NO and a.PHASE = b.PHASE and a.SUB_PHASE = b.SUB_PHASE where b.INTERNAL_COMPANY in (''060''))select new_cd_comp, SK_ID_DIM_COVERAGE  from covT where INTERNAL_COMPANY <> (''060'') ) as res  where res.SK_ID_DIM_COVERAGE = cv.SK_ID_DIM_COVERAGE;";

try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan =  sql_statement.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result;
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_SUPPRIMER_DERNIEREDATE_DM_COMP_US"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command1 = "delete from DB_ACT_"+ ENV +"_DM.DM_US_VI.DIM_MASTER_COA  where MD_ACTIVATION_DT = (select max(MD_ACTIVATION_DT) from DB_ACT_"+ ENV +"_DM.DM_US_VI.DIM_MASTER_COA);";
var sql_command2 = "delete from DB_ACT_"+ ENV +"_DM.DM_US_VI.DIM_GL_CHART  where MD_ACTIVATION_DT = (select max(MD_ACTIVATION_DT) from DB_ACT_"+ ENV +"_DM.DM_US_VI.DIM_GL_CHART);";
var sql_command3 = "delete from DB_ACT_"+ ENV +"_DM.DM_US_VI.FT_GL_BALANCE where ID_DIM_ACCOUNTING_PERIOD_DATE = (select max(ID_DIM_ACCOUNTING_PERIOD_DATE) from DB_ACT_"+ ENV +"_DM.DM_US_VI.FT_GL_BALANCE);";
var sql_command4 = "delete from DB_ACT_"+ ENV +"_DM.DM_US_VI.FT_GL_BALANCE_AGGREGATED where ID_DIM_ACCOUNTING_PERIOD_DATE = (select max(ID_DIM_ACCOUNTING_PERIOD_DATE) from DB_ACT_"+ ENV +"_DM.DM_US_VI.FT_GL_BALANCE_AGGREGATED);";

try {
	var sql_statement1 = snowflake.createStatement({sqlText: sql_command1 });
    var result_scan =  sql_statement1.execute();
	var sql_statement2 = snowflake.createStatement({sqlText: sql_command2 });
    var result_scan =  sql_statement2.execute();
	var sql_statement3 = snowflake.createStatement({sqlText: sql_command3 });
    var result_scan =  sql_statement3.execute();
	var sql_statement4 = snowflake.createStatement({sqlText: sql_command4 });
    var result_scan =  sql_statement4.execute();
	result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result;
    }
     
 return result;
';
create or replace schema DM_US_VI_PUBLICATION;

create or replace view VW_DIM_ACCOUNTING_PERIOD_DATE(
	ID_DIM_ACCOUNTING_PERIOD_DATE,
	"Mois - Code",
	"Mois - Abbrév. FR",
	"Mois - Abbrév. EN",
	"Mois - Nom FR",
	"Mois - Nom EN",
	"Mois Année - Abbrév. FR",
	"Mois Année - Abbrév. EN",
	"Mois Année - Nom FR",
	"Mois Année - Nom EN",
	"Mois - Numéro",
	"Trimestre - Code",
	"Trimestre - Numéro",
	"Trimestre - Abbrév. FR",
	"Trimestre - Abbrév. EN",
	"Trimestre - Nom FR",
	"Trimestre - Nom EN",
	"Trimestre Année - Abbrév. FR",
	"Trimestre Année - Abbrév. EN",
	"Trimestre Année - Nom FR",
	"Trimestre Année - Nom EN",
	"Semestre - Code",
	"Semestre - Numéro ",
	"Semestre - Abbrév. FR",
	"Semestre - Abbrév. EN",
	"Semestre - Nom FR",
	"Semestre - Nom EN",
	"Semestre Année - Abbrév. FR",
	"Semestre Année - Abbrév. EN",
	"Semestre Année - Nom FR",
	"Semestre Année - Nom EN",
	"Année - Code",
	"Année - Abbrév. FR",
	"Année - Abbrév. EN",
	"Année - Nom FR",
	"Année - Nom EN"
) as

SELECT  
          ID_DIM_DATE                       AS "ID_DIM_ACCOUNTING_PERIOD_DATE"
        , MONTH_CD                          AS "Mois - Code"
        , MONTH_SHORT_NAME_FR               AS "Mois - Abbrév. FR"
        , MONTH_SHORT_NAME_EN               AS "Mois - Abbrév. EN"
        , MONTH_NAME_FR                     AS "Mois - Nom FR"
        , MONTH_NAME_EN                     AS "Mois - Nom EN"
        , MONTH_YEAR_SHORT_NAME_FR          AS "Mois Année - Abbrév. FR"
        , MONTH_YEAR_SHORT_NAME_EN          AS "Mois Année - Abbrév. EN"
        , MONTH_YEAR_NAME_FR                AS "Mois Année - Nom FR"
        , MONTH_YEAR_NAME_EN                AS "Mois Année - Nom EN"
        , MONTH_NO                          AS "Mois - Numéro"
        , QUARTER_CD                        AS "Trimestre - Code"
        , QUARTER_NO					    AS "Trimestre - Numéro"
        , QUARTER_SHORT_NAME_FR				AS "Trimestre - Abbrév. FR"
        , QUARTER_SHORT_NAME_EN				AS "Trimestre - Abbrév. EN"
        , QUARTER_NAME_FR					AS "Trimestre - Nom FR"
        , QUARTER_NAME_EN					AS "Trimestre - Nom EN"
        , QUARTER_YEAR_SHORT_NAME_FR		AS "Trimestre Année - Abbrév. FR"
        , QUARTER_YEAR_SHORT_NAME_EN		AS "Trimestre Année - Abbrév. EN"
        , QUARTER_YEAR_NAME_FR				AS "Trimestre Année - Nom FR"
        , QUARTER_YEAR_NAME_EN				AS "Trimestre Année - Nom EN"
        , SEMESTER_CD						AS "Semestre - Code"
        , SEMESTER_NO						AS "Semestre - Numéro "
        , SEMESTER_SHORT_NAME_FR			AS "Semestre - Abbrév. FR"
        , SEMESTER_SHORT_NAME_EN			AS "Semestre - Abbrév. EN"
        , SEMESTER_NAME_FR					AS "Semestre - Nom FR"
        , SEMESTER_NAME_EN					AS "Semestre - Nom EN"
        , SEMESTER_YEAR_SHORT_NAME_FR 		AS "Semestre Année - Abbrév. FR"
        , SEMESTER_YEAR_SHORT_NAME_EN 		AS "Semestre Année - Abbrév. EN"
        , SEMESTER_YEAR_NAME_FR				AS "Semestre Année - Nom FR"
        , SEMESTER_YEAR_NAME_EN				AS "Semestre Année - Nom EN"
        , YEAR_CD							AS "Année - Code"
        , YEAR_SHORT_NAME_FR				AS "Année - Abbrév. FR"
        , YEAR_SHORT_NAME_EN				AS "Année - Abbrév. EN"
        , YEAR_NAME_FR						AS "Année - Nom FR"
        , YEAR_NAME_EN						AS "Année - Nom EN"
       
FROM DM_US_VI.DIM_DATE;
create or replace view VW_DIM_AGENCY(
	SK_ID_DIM_AGENCY,
	AGENCY_CD,
	AGENCY_NAME
) as

SELECT
SK_ID_DIM_AGENCY
,AGENCY_CD	
,AGENCY_NAME	


FROM DM_US_VI.DIM_AGENCY;
create or replace view VW_DIM_AGENT(
	SK_ID_DIM_AGENT,
	AGENT_CD,
	AGENT_NAME
) as

SELECT
	SK_ID_DIM_AGENT
	,AGENT_CD	
	,AGENT_NAME	

FROM  DM_US_VI.DIM_AGENT;
create or replace view VW_DIM_AGE_GROUP(
	SK_ID_DIM_AGE_GROUP,
	AGE_GROUP_CODE,
	AGE_GROUP_NAME,
	AGE_GROUP_LABEL,
	AGE_GROUP_MIN,
	AGE_GROUP_MAX
) as

SELECT
    SK_ID_DIM_AGE_GROUP
    ,AGE_GROUP_CODE	
    ,AGE_GROUP_NAME	
    ,AGE_GROUP_LABEL	
    ,AGE_GROUP_MIN
    ,AGE_GROUP_MAX

FROM DM_US_VI.DIM_AGE_GROUP;
create or replace view VW_DIM_ATTEINTED_AGE(
	ID_DIM_ATTEINTED_AGE,
	ATTEINTED_AGE,
	ATTEINTED_AGE_GROUP_CODE,
	ATTEINTED_AGE_GROUP_NAME,
	ATTEINTED_AGE_GROUP_LABEL,
	ATTEINTED_AGE_GROUP_MIN,
	ATTEINTED_AGE_GROUP_MAX
) as

WITH COV_ATTEINTED_AGE
AS (
        SELECT ATTEINED_AGE, SK_ID_ATTEINED_AGE_GROUP, (SK_ID_ATTEINED_AGE_GROUP*1000) + ATTEINED_AGE AS SK_ID_DIM_ATTEINED_AGE
        FROM DM_US_VI.FT_COVERAGE
        GROUP BY ATTEINED_AGE, SK_ID_ATTEINED_AGE_GROUP
)

SELECT
     COV.SK_ID_DIM_ATTEINED_AGE             AS ID_DIM_ATTEINTED_AGE
    ,COV.ATTEINED_AGE                       AS ATTEINTED_AGE
    ,AGE_GROUP_CODE	                    AS ATTEINTED_AGE_GROUP_CODE
    ,AGE_GROUP_NAME	                    AS ATTEINTED_AGE_GROUP_NAMe
    ,AGE_GROUP_LABEL                        AS ATTEINTED_AGE_GROUP_LABEL	
    ,AGE_GROUP_MIN                          AS ATTEINTED_AGE_GROUP_MIN
    ,AGE_GROUP_MAX                          AS ATTEINTED_AGE_GROUP_MAX

FROM  COV_ATTEINTED_AGE COV
INNER JOIN  DM_US_VI.DIM_AGE_GROUP AG 
        ON COV.SK_ID_ATTEINED_AGE_GROUP = AG.SK_ID_DIM_AGE_GROUP;
create or replace view VW_DIM_ATTEINTED_AGE_GROUP(
	SK_ID_DIM_ATTEINTED_AGE_GROUP,
	AGE_GROUP_CODE,
	AGE_GROUP_NAME,
	AGE_GROUP_LABEL,
	AGE_GROUP_MIN,
	AGE_GROUP_MAX
) as

SELECT
    SK_ID_DIM_AGE_GROUP AS SK_ID_DIM_ATTEINTED_AGE_GROUP
    ,AGE_GROUP_CODE	
    ,AGE_GROUP_NAME	
    ,AGE_GROUP_LABEL	
    ,AGE_GROUP_MIN
    ,AGE_GROUP_MAX

FROM DM_US_VI.DIM_AGE_GROUP;
create or replace view VW_DIM_CLOSE_DATE(
	ID_DIM_CLOSE_DATE,
	"Mois - Code",
	"Mois - Abbrév. FR",
	"Mois - Abbrév. EN",
	"Mois - Nom FR",
	"Mois - Nom EN",
	"Mois Année - Abbrév. FR",
	"Mois Année - Abbrév. EN",
	"Mois Année - Nom FR",
	"Mois Année - Nom EN",
	"Mois - Numéro",
	"Trimestre - Code",
	"Trimestre - Numéro",
	"Trimestre - Abbrév. FR",
	"Trimestre - Abbrév. EN",
	"Trimestre - Nom FR",
	"Trimestre - Nom EN",
	"Trimestre Année - Abbrév. FR",
	"Trimestre Année - Abbrév. EN",
	"Trimestre Année - Nom FR",
	"Trimestre Année - Nom EN",
	"Semestre - Code",
	"Semestre - Numéro ",
	"Semestre - Abbrév. FR",
	"Semestre - Abbrév. EN",
	"Semestre - Nom FR",
	"Semestre - Nom EN",
	"Semestre Année - Abbrév. FR",
	"Semestre Année - Abbrév. EN",
	"Semestre Année - Nom FR",
	"Semestre Année - Nom EN",
	"Année - Code",
	"Année - Abbrév. FR",
	"Année - Abbrév. EN",
	"Année - Nom FR",
	"Année - Nom EN"
) as


SELECT  
          ID_DIM_DATE                       AS "ID_DIM_CLOSE_DATE"
        , MONTH_CD                          AS "Mois - Code"
        , MONTH_SHORT_NAME_FR               AS "Mois - Abbrév. FR"
        , MONTH_SHORT_NAME_EN               AS "Mois - Abbrév. EN"
        , MONTH_NAME_FR                     AS "Mois - Nom FR"
        , MONTH_NAME_EN                     AS "Mois - Nom EN"
        , MONTH_YEAR_SHORT_NAME_FR          AS "Mois Année - Abbrév. FR"
        , MONTH_YEAR_SHORT_NAME_EN          AS "Mois Année - Abbrév. EN"
        , MONTH_YEAR_NAME_FR                AS "Mois Année - Nom FR"
        , MONTH_YEAR_NAME_EN                AS "Mois Année - Nom EN"
        , MONTH_NO                          AS "Mois - Numéro"
        , QUARTER_CD                        AS "Trimestre - Code"
        , QUARTER_NO					    AS "Trimestre - Numéro"
        , QUARTER_SHORT_NAME_FR				AS "Trimestre - Abbrév. FR"
        , QUARTER_SHORT_NAME_EN				AS "Trimestre - Abbrév. EN"
        , QUARTER_NAME_FR					AS "Trimestre - Nom FR"
        , QUARTER_NAME_EN					AS "Trimestre - Nom EN"
        , QUARTER_YEAR_SHORT_NAME_FR		AS "Trimestre Année - Abbrév. FR"
        , QUARTER_YEAR_SHORT_NAME_EN		AS "Trimestre Année - Abbrév. EN"
        , QUARTER_YEAR_NAME_FR				AS "Trimestre Année - Nom FR"
        , QUARTER_YEAR_NAME_EN				AS "Trimestre Année - Nom EN"
        , SEMESTER_CD						AS "Semestre - Code"
        , SEMESTER_NO						AS "Semestre - Numéro "
        , SEMESTER_SHORT_NAME_FR			AS "Semestre - Abbrév. FR"
        , SEMESTER_SHORT_NAME_EN			AS "Semestre - Abbrév. EN"
        , SEMESTER_NAME_FR					AS "Semestre - Nom FR"
        , SEMESTER_NAME_EN					AS "Semestre - Nom EN"
        , SEMESTER_YEAR_SHORT_NAME_FR 		AS "Semestre Année - Abbrév. FR"
        , SEMESTER_YEAR_SHORT_NAME_EN 		AS "Semestre Année - Abbrév. EN"
        , SEMESTER_YEAR_NAME_FR				AS "Semestre Année - Nom FR"
        , SEMESTER_YEAR_NAME_EN				AS "Semestre Année - Nom EN"
        , YEAR_CD							AS "Année - Code"
        , YEAR_SHORT_NAME_FR				AS "Année - Abbrév. FR"
        , YEAR_SHORT_NAME_EN				AS "Année - Abbrév. EN"
        , YEAR_NAME_FR						AS "Année - Nom FR"
        , YEAR_NAME_EN						AS "Année - Nom EN"
       
FROM DM_US_VI.DIM_DATE;
create or replace view VW_DIM_COVERAGE(
	SK_ID_DIM_COVERAGE,
	POLICY_ID,
	POLICY_NO,
	COMPANY_CODE,
	PHASE,
	SUB_PHASE,
	COVERAGE_TYPE_CODE,
	INTERNAL_COMPANY,
	IND_ASSUMED,
	MD_ACTIVATION_DT,
	MD_MODIFICATION_DT,
	MD_OBSOLESCENCE_DT
) as

SELECT
    SK_ID_DIM_COVERAGE
    ,POLICY_ID	
    ,POLICY_NO	
    ,COMPANY_CODE	
    ,PHASE	
    ,SUB_PHASE	
    ,COVERAGE_TYPE_CODE	
    ,INTERNAL_COMPANY	
    ,IND_ASSUMED	
    ,MD_ACTIVATION_DT
    ,MD_MODIFICATION_DT
    ,MD_OBSOLESCENCE_DT

FROM DM_US_VI.DIM_COVERAGE;
create or replace view VW_DIM_COVERAGE_AXIS_MODULE(
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	COVERAGE_AXIS_MODULE_CODE,
	COVERAGE_AXIS_MODULE_NAME,
	MD_ACTIVATION_DT,
	MD_MODIFICATION_DT,
	MD_OBSOLESCENCE_DT
) as

SELECT
    SK_ID_DIM_COVERAGE_AXIS_MODULE
    ,COVERAGE_AXIS_MODULE_CODE	
    ,COVERAGE_AXIS_MODULE_NAME	
    ,MD_ACTIVATION_DT
    ,MD_MODIFICATION_DT
    ,MD_OBSOLESCENCE_DT

FROM DM_US_VI.DIM_COVERAGE_AXIS_MODULE;
create or replace view VW_DIM_COVERAGE_DURATION(
	ID_DIM_COVERAGE_DURATION,
	COVERAGE_DURATION_IN_YEARS,
	COVERAGE_DURATION_RANGE_CODE,
	COVERAGE_DURATION_RANGE_NAME,
	COVERAGE_DURATION_RANGE_LABEL,
	COVERAGE_DURATION_RANGE_MIN,
	COVERAGE_DURATION_RANGE_MAX
) as

WITH COV_DURATION
AS (
        SELECT DURATION_IN_YEARS, SK_ID_DIM_DURATION_RANGE, (SK_ID_DIM_DURATION_RANGE*1000) + DURATION_IN_YEARS AS SK_ID_DIM_COVERAGE_DURATION
        FROM DM_US_VI.FT_COVERAGE
        GROUP BY DURATION_IN_YEARS, SK_ID_DIM_DURATION_RANGE
)

SELECT
     COV.SK_ID_DIM_COVERAGE_DURATION             AS ID_DIM_COVERAGE_DURATION
    ,COV.DURATION_IN_YEARS                       AS COVERAGE_DURATION_IN_YEARS
    ,DURATION_RANGE_CODE	                 AS COVERAGE_DURATION_RANGE_CODE
    ,DURATION_RANGE_NAME	                 AS COVERAGE_DURATION_RANGE_NAMe
    ,DURATION_RANGE_LABEL                        AS COVERAGE_DURATION_RANGE_LABEL	
    ,DURATION_RANGE_MIN                          AS COVERAGE_DURATION_RANGE_MIN
    ,DURATION_RANGE_MAX                          AS COVERAGE_DURATION_RANGE_MAX

FROM  COV_DURATION COV
INNER JOIN  DM_US_VI.DIM_DURATION_RANGE DR 
        ON COV.SK_ID_DIM_DURATION_RANGE = DR.SK_ID_DIM_DURATION_RANGE;
create or replace view VW_DIM_COVERAGE_STATUS(
	SK_ID_DIM_COVERAGE_STATUS,
	COVERAGE_STATUS_CD,
	COVERAGE_STATUS_NAME
) as

SELECT
    SK_ID_DIM_COVERAGE_STATUS
    ,COVERAGE_STATUS_CD	
    ,COVERAGE_STATUS_NAME	

FROM DM_US_VI.DIM_COVERAGE_STATUS;
create or replace view VW_DIM_DATE(
	ID_DIM_DATE,
	SHORT_NAME_FR,
	SHORT_NAME_EN,
	NAME_FR,
	NAME_EN,
	WEEK_DAY_NO,
	MONTH_DAY_NO,
	QUARTER_DAY_NO,
	SEMESTER_DAY_NO,
	YEAR_DAY_NO,
	DAY_SHORT_NAME_FR,
	DAY_SHORT_NAME_EN,
	DAY_NAME_FR,
	DAY_NAME_EN,
	WEEK_CD,
	WEEK_NO,
	WEEK_SHORT_NAME_FR,
	WEEK_SHORT_NAME_EN,
	WEEK_NAME_FR,
	WEEK_NAME_EN,
	WEEK_YEAR_SHORT_NAME_FR,
	WEEK_YEAR_SHORT_NAME_EN,
	WEEK_YEAR_NAME_FR,
	WEEK_YEAR_NAME_EN,
	WEEK_NB_DAY,
	MONTH_CD,
	MONTH_NO,
	MONTH_SHORT_NAME_FR,
	MONTH_SHORT_NAME_EN,
	MONTH_NAME_FR,
	MONTH_NAME_EN,
	MONTH_YEAR_SHORT_NAME_FR,
	MONTH_YEAR_SHORT_NAME_EN,
	MONTH_YEAR_NAME_FR,
	MONTH_YEAR_NAME_EN,
	MONTH_NB_DAY,
	QUARTER_CD,
	QUARTER_NO,
	QUARTER_SHORT_NAME_FR,
	QUARTER_SHORT_NAME_EN,
	QUARTER_NAME_FR,
	QUARTER_NAME_EN,
	QUARTER_YEAR_SHORT_NAME_FR,
	QUARTER_YEAR_SHORT_NAME_EN,
	QUARTER_YEAR_NAME_FR,
	QUARTER_YEAR_NAME_EN,
	QUARTER_NB_DAY,
	SEMESTER_CD,
	SEMESTER_NO,
	SEMESTER_SHORT_NAME_FR,
	SEMESTER_SHORT_NAME_EN,
	SEMESTER_NAME_FR,
	SEMESTER_NAME_EN,
	SEMESTER_YEAR_SHORT_NAME_FR,
	SEMESTER_YEAR_SHORT_NAME_EN,
	SEMESTER_YEAR_NAME_FR,
	SEMESTER_YEAR_NAME_EN,
	SEMESTER_NB_DAY,
	YEAR_CD,
	YEAR_SHORT_NAME_FR,
	YEAR_SHORT_NAME_EN,
	YEAR_NAME_FR,
	YEAR_NAME_EN,
	YEAR_NB_DAY
) as


SELECT

    ID_DIM_DATE
    ,SHORT_NAME_FR	
    ,SHORT_NAME_EN	
    ,NAME_FR	
    ,NAME_EN	
    ,WEEK_DAY_NO
    ,MONTH_DAY_NO
    ,QUARTER_DAY_NO
    ,SEMESTER_DAY_NO
    ,YEAR_DAY_NO
    ,DAY_SHORT_NAME_FR	
    ,DAY_SHORT_NAME_EN	
    ,DAY_NAME_FR	
    ,DAY_NAME_EN	
    ,WEEK_CD	
    ,WEEK_NO
    ,WEEK_SHORT_NAME_FR	
    ,WEEK_SHORT_NAME_EN	
    ,WEEK_NAME_FR	
    ,WEEK_NAME_EN	
    ,WEEK_YEAR_SHORT_NAME_FR	
    ,WEEK_YEAR_SHORT_NAME_EN	
    ,WEEK_YEAR_NAME_FR	
    ,WEEK_YEAR_NAME_EN	
    ,WEEK_NB_DAY
    ,MONTH_CD	
    ,MONTH_NO
    ,MONTH_SHORT_NAME_FR	
    ,MONTH_SHORT_NAME_EN	
    ,MONTH_NAME_FR	
    ,MONTH_NAME_EN	
    ,MONTH_YEAR_SHORT_NAME_FR	
    ,MONTH_YEAR_SHORT_NAME_EN	
    ,MONTH_YEAR_NAME_FR	
    ,MONTH_YEAR_NAME_EN	
    ,MONTH_NB_DAY
    ,QUARTER_CD	
    ,QUARTER_NO
    ,QUARTER_SHORT_NAME_FR	
    ,QUARTER_SHORT_NAME_EN	
    ,QUARTER_NAME_FR	
    ,QUARTER_NAME_EN	
    ,QUARTER_YEAR_SHORT_NAME_FR	
    ,QUARTER_YEAR_SHORT_NAME_EN	
    ,QUARTER_YEAR_NAME_FR	
    ,QUARTER_YEAR_NAME_EN	
    ,QUARTER_NB_DAY
    ,SEMESTER_CD	
    ,SEMESTER_NO
    ,SEMESTER_SHORT_NAME_FR	
    ,SEMESTER_SHORT_NAME_EN	
    ,SEMESTER_NAME_FR	
    ,SEMESTER_NAME_EN	
    ,SEMESTER_YEAR_SHORT_NAME_FR	
    ,SEMESTER_YEAR_SHORT_NAME_EN	
    ,SEMESTER_YEAR_NAME_FR	
    ,SEMESTER_YEAR_NAME_EN	
    ,SEMESTER_NB_DAY
    ,YEAR_CD
    ,YEAR_SHORT_NAME_FR	
    ,YEAR_SHORT_NAME_EN	
    ,YEAR_NAME_FR	
    ,YEAR_NAME_EN	
    ,YEAR_NB_DAY

FROM DM_US_VI.DIM_DATE;
create or replace view VW_DIM_DOD_DATE(
	ID_DIM_DOD_DATE,
	"Mois - Code",
	"Mois - Abbrév. FR",
	"Mois - Abbrév. EN",
	"Mois - Nom FR",
	"Mois - Nom EN",
	"Mois Année - Abbrév. FR",
	"Mois Année - Abbrév. EN",
	"Mois Année - Nom FR",
	"Mois Année - Nom EN",
	"Mois - Numéro",
	"Trimestre - Code",
	"Trimestre - Numéro",
	"Trimestre - Abbrév. FR",
	"Trimestre - Abbrév. EN",
	"Trimestre - Nom FR",
	"Trimestre - Nom EN",
	"Trimestre Année - Abbrév. FR",
	"Trimestre Année - Abbrév. EN",
	"Trimestre Année - Nom FR",
	"Trimestre Année - Nom EN",
	"Semestre - Code",
	"Semestre - Numéro ",
	"Semestre - Abbrév. FR",
	"Semestre - Abbrév. EN",
	"Semestre - Nom FR",
	"Semestre - Nom EN",
	"Semestre Année - Abbrév. FR",
	"Semestre Année - Abbrév. EN",
	"Semestre Année - Nom FR",
	"Semestre Année - Nom EN",
	"Année - Code",
	"Année - Abbrév. FR",
	"Année - Abbrév. EN",
	"Année - Nom FR",
	"Année - Nom EN"
) as



SELECT  
          ID_DIM_DATE                       AS "ID_DIM_DOD_DATE"
        , MONTH_CD                          AS "Mois - Code"
        , MONTH_SHORT_NAME_FR               AS "Mois - Abbrév. FR"
        , MONTH_SHORT_NAME_EN               AS "Mois - Abbrév. EN"
        , MONTH_NAME_FR                     AS "Mois - Nom FR"
        , MONTH_NAME_EN                     AS "Mois - Nom EN"
        , MONTH_YEAR_SHORT_NAME_FR          AS "Mois Année - Abbrév. FR"
        , MONTH_YEAR_SHORT_NAME_EN          AS "Mois Année - Abbrév. EN"
        , MONTH_YEAR_NAME_FR                AS "Mois Année - Nom FR"
        , MONTH_YEAR_NAME_EN                AS "Mois Année - Nom EN"
        , MONTH_NO                          AS "Mois - Numéro"
        , QUARTER_CD                        AS "Trimestre - Code"
        , QUARTER_NO					    AS "Trimestre - Numéro"
        , QUARTER_SHORT_NAME_FR				AS "Trimestre - Abbrév. FR"
        , QUARTER_SHORT_NAME_EN				AS "Trimestre - Abbrév. EN"
        , QUARTER_NAME_FR					AS "Trimestre - Nom FR"
        , QUARTER_NAME_EN					AS "Trimestre - Nom EN"
        , QUARTER_YEAR_SHORT_NAME_FR		AS "Trimestre Année - Abbrév. FR"
        , QUARTER_YEAR_SHORT_NAME_EN		AS "Trimestre Année - Abbrév. EN"
        , QUARTER_YEAR_NAME_FR				AS "Trimestre Année - Nom FR"
        , QUARTER_YEAR_NAME_EN				AS "Trimestre Année - Nom EN"
        , SEMESTER_CD						AS "Semestre - Code"
        , SEMESTER_NO						AS "Semestre - Numéro "
        , SEMESTER_SHORT_NAME_FR			AS "Semestre - Abbrév. FR"
        , SEMESTER_SHORT_NAME_EN			AS "Semestre - Abbrév. EN"
        , SEMESTER_NAME_FR					AS "Semestre - Nom FR"
        , SEMESTER_NAME_EN					AS "Semestre - Nom EN"
        , SEMESTER_YEAR_SHORT_NAME_FR 		AS "Semestre Année - Abbrév. FR"
        , SEMESTER_YEAR_SHORT_NAME_EN 		AS "Semestre Année - Abbrév. EN"
        , SEMESTER_YEAR_NAME_FR				AS "Semestre Année - Nom FR"
        , SEMESTER_YEAR_NAME_EN				AS "Semestre Année - Nom EN"
        , YEAR_CD							AS "Année - Code"
        , YEAR_SHORT_NAME_FR				AS "Année - Abbrév. FR"
        , YEAR_SHORT_NAME_EN				AS "Année - Abbrév. EN"
        , YEAR_NAME_FR						AS "Année - Nom FR"
        , YEAR_NAME_EN						AS "Année - Nom EN"
       
FROM DM_US_VI.DIM_DATE;
create or replace view VW_DIM_DURATION_RANGE(
	SK_ID_DIM_DURATION_RANGE,
	DURATION_RANGE_CODE,
	DURATION_RANGE_NAME,
	DURATION_RANGE_LABEL,
	DURATION_RANGE_MIN,
	DURATION_RANGE_MAX
) as

SELECT
    SK_ID_DIM_DURATION_RANGE
    ,DURATION_RANGE_CODE	
    ,DURATION_RANGE_NAME	
    ,DURATION_RANGE_LABEL	
    ,DURATION_RANGE_MIN
    ,DURATION_RANGE_MAX

FROM DM_US_VI.DIM_DURATION_RANGE;
create or replace view VW_DIM_EVALUATION_DATE(
	ID_DIM_EVALUATION_DATE,
	"Date du jour",
	"Mois - Code",
	"Mois - Abbrév. FR",
	"Mois - Abbrév. EN",
	"Mois - Nom FR",
	"Mois - Nom EN",
	"Mois Année - Abbrév. FR",
	"Mois Année - Abbrév. EN",
	"Mois Année - Nom FR",
	"Mois Année - Nom EN",
	"Mois - Numéro",
	"Trimestre - Code",
	"Trimestre - Numéro",
	"Trimestre - Abbrév. FR",
	"Trimestre - Abbrév. EN",
	"Trimestre - Nom FR",
	"Trimestre - Nom EN",
	"Trimestre Année - Abbrév. FR",
	"Trimestre Année - Abbrév. EN",
	"Trimestre Année - Nom FR",
	"Trimestre Année - Nom EN",
	"Année - Code",
	"Année - Abbrév. FR",
	"Année - Abbrév. EN",
	"Année - Nom FR",
	"Année - Nom EN"
) as
WITH DISTINCT_EVAL_DATE
AS (
      SELECT  ID_DIM_EVALUATION_DATE FROM DM_US_VI.FT_SOE_CASHFLOW GROUP BY ID_DIM_EVALUATION_DATE
      UNION
      SELECT  ID_DIM_EVALUATION_DATE FROM DM_US_VI.FT_SOE_RESERVE_RELEASE GROUP BY ID_DIM_EVALUATION_DATE
      UNION
      SELECT  ID_DIM_EVALUATION_DATE FROM DM_US_VI.FT_SOE_INVESTMENT_COMPONENT GROUP BY ID_DIM_EVALUATION_DATE
      UNION 
      SELECT  ID_DIM_ACCOUNTING_PERIOD_DATE AS ID_DIM_EVALUATION_DATE FROM DM_US_VI.FT_GL_BALANCE GROUP BY ID_DIM_ACCOUNTING_PERIOD_DATE

)

SELECT  
          ID_DIM_DATE                       AS "ID_DIM_EVALUATION_DATE"
        , DAY_SHORT_DATE                    AS "Date du jour"  
        , MONTH_CD                          AS "Mois - Code"
        , MONTH_SHORT_NAME_FR               AS "Mois - Abbrév. FR"
        , MONTH_SHORT_NAME_EN               AS "Mois - Abbrév. EN"
        , MONTH_NAME_FR                     AS "Mois - Nom FR"
        , MONTH_NAME_EN                     AS "Mois - Nom EN"
        , MONTH_YEAR_SHORT_NAME_FR          AS "Mois Année - Abbrév. FR"
        , MONTH_YEAR_SHORT_NAME_EN          AS "Mois Année - Abbrév. EN"
        , MONTH_YEAR_NAME_FR                AS "Mois Année - Nom FR"
        , MONTH_YEAR_NAME_EN                AS "Mois Année - Nom EN"
        , MONTH_NO                          AS "Mois - Numéro"
        , QUARTER_CD                        AS "Trimestre - Code"
        , QUARTER_NO					    AS "Trimestre - Numéro"
        , QUARTER_SHORT_NAME_FR				AS "Trimestre - Abbrév. FR"
        , QUARTER_SHORT_NAME_EN				AS "Trimestre - Abbrév. EN"
        , QUARTER_NAME_FR					AS "Trimestre - Nom FR"
        , QUARTER_NAME_EN					AS "Trimestre - Nom EN"
        , QUARTER_YEAR_SHORT_NAME_FR		AS "Trimestre Année - Abbrév. FR"
        , QUARTER_YEAR_SHORT_NAME_EN		AS "Trimestre Année - Abbrév. EN"
        , QUARTER_YEAR_NAME_FR				AS "Trimestre Année - Nom FR"
        , QUARTER_YEAR_NAME_EN				AS "Trimestre Année - Nom EN"
        , YEAR_CD							AS "Année - Code"
        , YEAR_SHORT_NAME_FR				AS "Année - Abbrév. FR"
        , YEAR_SHORT_NAME_EN				AS "Année - Abbrév. EN"
        , YEAR_NAME_FR						AS "Année - Nom FR"
        , YEAR_NAME_EN						AS "Année - Nom EN"
       
FROM DM_US_VI.DIM_DATE D

INNER JOIN DISTINCT_EVAL_DATE CTE 
    ON D.ID_DIM_DATE = CTE.ID_DIM_EVALUATION_DATE;
create or replace view VW_DIM_GL_CHART(
	SK_ID_DIM_GL_CHART,
	CD_ENTITY,
	CD_NATURE,
	CD_ORIGIN,
	CD_PERIODICITY,
	CD_COST_CENTER,
	CD_INTERCO,
	CD_LINE_OF_BUSINESS,
	CD_PRODUCT,
	CD_PARTICIPATION,
	CD_GEOGRAPHY,
	CD_PROJECT
) as

SELECT
    SK_ID_DIM_GL_CHART
    ,CD_ENTITY	
    ,CD_NATURE	
    ,CD_ORIGIN	
    ,CD_PERIODICITY	
    ,CD_COST_CENTER	
    ,CD_INTERCO	
    ,CD_LINE_OF_BUSINESS	
    ,CD_PRODUCT	
    ,CD_PARTICIPATION	
    ,CD_GEOGRAPHY	
    ,CD_PROJECT	

FROM  DM_US_VI.DIM_GL_CHART;
create or replace view VW_DIM_ISSUE_AGE(
	ID_DIM_ISSUE_AGE,
	ISSUE_AGE,
	ISSUE_AGE_GROUP_CODE,
	ISSUE_AGE_GROUP_NAME,
	ISSUE_AGE_GROUP_LABEL,
	ISSUE_AGE_GROUP_MIN,
	ISSUE_AGE_GROUP_MAX
) as

WITH COV_ISSUE_AGE
AS (
        SELECT ISSUE_AGE, SK_ID_ISSUE_AGE_GROUP, (SK_ID_ISSUE_AGE_GROUP*1000) + ISSUE_AGE AS SK_ID_DIM_ISSUE_AGE
        FROM DM_US_VI.FT_COVERAGE
        GROUP BY ISSUE_AGE, SK_ID_ISSUE_AGE_GROUP
)

SELECT
     COV.SK_ID_DIM_ISSUE_AGE             AS ID_DIM_ISSUE_AGE
    ,COV.ISSUE_AGE                       AS ISSUE_AGE
    ,AGE_GROUP_CODE	                     AS ISSUE_AGE_GROUP_CODE
    ,AGE_GROUP_NAME	                     AS ISSUE_AGE_GROUP_NAMe
    ,AGE_GROUP_LABEL                     AS ISSUE_AGE_GROUP_LABEL	
    ,AGE_GROUP_MIN                       AS ISSUE_AGE_GROUP_MIN
    ,AGE_GROUP_MAX                       AS ISSUE_AGE_GROUP_MAX

FROM  COV_ISSUE_AGE COV
INNER JOIN  DM_US_VI.DIM_AGE_GROUP AG 
        ON COV.SK_ID_ISSUE_AGE_GROUP = AG.SK_ID_DIM_AGE_GROUP;
create or replace view VW_DIM_ISSUE_DATE(
	ID_DIM_ISSUE_DATE,
	"Mois - Code",
	"Mois - Abbrév. FR",
	"Mois - Abbrév. EN",
	"Mois - Nom FR",
	"Mois - Nom EN",
	"Mois Année - Abbrév. FR",
	"Mois Année - Abbrév. EN",
	"Mois Année - Nom FR",
	"Mois Année - Nom EN",
	"Mois - Numéro",
	"Trimestre - Code",
	"Trimestre - Numéro",
	"Trimestre - Abbrév. FR",
	"Trimestre - Abbrév. EN",
	"Trimestre - Nom FR",
	"Trimestre - Nom EN",
	"Trimestre Année - Abbrév. FR",
	"Trimestre Année - Abbrév. EN",
	"Trimestre Année - Nom FR",
	"Trimestre Année - Nom EN",
	"Semestre - Code",
	"Semestre - Numéro ",
	"Semestre - Abbrév. FR",
	"Semestre - Abbrév. EN",
	"Semestre - Nom FR",
	"Semestre - Nom EN",
	"Semestre Année - Abbrév. FR",
	"Semestre Année - Abbrév. EN",
	"Semestre Année - Nom FR",
	"Semestre Année - Nom EN",
	"Année - Code",
	"Année - Abbrév. FR",
	"Année - Abbrév. EN",
	"Année - Nom FR",
	"Année - Nom EN"
) as

SELECT  
          ID_DIM_DATE                 AS "ID_DIM_ISSUE_DATE"
        , MONTH_CD                          AS "Mois - Code"
        , MONTH_SHORT_NAME_FR               AS "Mois - Abbrév. FR"
        , MONTH_SHORT_NAME_EN               AS "Mois - Abbrév. EN"
        , MONTH_NAME_FR                     AS "Mois - Nom FR"
        , MONTH_NAME_EN                     AS "Mois - Nom EN"
        , MONTH_YEAR_SHORT_NAME_FR          AS "Mois Année - Abbrév. FR"
        , MONTH_YEAR_SHORT_NAME_EN          AS "Mois Année - Abbrév. EN"
        , MONTH_YEAR_NAME_FR                AS "Mois Année - Nom FR"
        , MONTH_YEAR_NAME_EN                AS "Mois Année - Nom EN"
        , MONTH_NO                          AS "Mois - Numéro"
        , QUARTER_CD                        AS "Trimestre - Code"
        , QUARTER_NO					    AS "Trimestre - Numéro"
        , QUARTER_SHORT_NAME_FR				AS "Trimestre - Abbrév. FR"
        , QUARTER_SHORT_NAME_EN				AS "Trimestre - Abbrév. EN"
        , QUARTER_NAME_FR					AS "Trimestre - Nom FR"
        , QUARTER_NAME_EN					AS "Trimestre - Nom EN"
        , QUARTER_YEAR_SHORT_NAME_FR		AS "Trimestre Année - Abbrév. FR"
        , QUARTER_YEAR_SHORT_NAME_EN		AS "Trimestre Année - Abbrév. EN"
        , QUARTER_YEAR_NAME_FR				AS "Trimestre Année - Nom FR"
        , QUARTER_YEAR_NAME_EN				AS "Trimestre Année - Nom EN"
        , SEMESTER_CD						AS "Semestre - Code"
        , SEMESTER_NO						AS "Semestre - Numéro "
        , SEMESTER_SHORT_NAME_FR			AS "Semestre - Abbrév. FR"
        , SEMESTER_SHORT_NAME_EN			AS "Semestre - Abbrév. EN"
        , SEMESTER_NAME_FR					AS "Semestre - Nom FR"
        , SEMESTER_NAME_EN					AS "Semestre - Nom EN"
        , SEMESTER_YEAR_SHORT_NAME_FR 		AS "Semestre Année - Abbrév. FR"
        , SEMESTER_YEAR_SHORT_NAME_EN 		AS "Semestre Année - Abbrév. EN"
        , SEMESTER_YEAR_NAME_FR				AS "Semestre Année - Nom FR"
        , SEMESTER_YEAR_NAME_EN				AS "Semestre Année - Nom EN"
        , YEAR_CD							AS "Année - Code"
        , YEAR_SHORT_NAME_FR				AS "Année - Abbrév. FR"
        , YEAR_SHORT_NAME_EN				AS "Année - Abbrév. EN"
        , YEAR_NAME_FR						AS "Année - Nom FR"
        , YEAR_NAME_EN						AS "Année - Nom EN"
       
FROM DM_US_VI.DIM_DATE;
create or replace view VW_DIM_ISSUE_STATE(
	SK_ID_DIM_ISSUE_STATE,
	ISSUE_STATE_CD,
	ISSUE_STATE_NAME
) as

SELECT
      SK_ID_DIM_STATE   AS SK_ID_DIM_ISSUE_STATE
    , STATE_CD          AS ISSUE_STATE_CD
    , STATE_NAME        AS ISSUE_STATE_NAME

FROM DM_US_VI.DIM_STATE;
create or replace view VW_DIM_PFT(
	SK_ID_DIM_PFT,
	AXIS_PLAN_CODE,
	CD_AXIS_CELL_NAME,
	CD_AXIS_MODULE,
	CD_PRM_PAYING_PERIOD_CODE,
	DESCRIPT,
	PRODUCT,
	GROUPE,
	SUB_GROUP,
	OTHER_BENEFIT_LINK_1,
	OTHER_BENEFIT_LINK_2,
	OTHER_BENEFIT_LINK_3,
	REINSURANCE_TERMS_1,
	BONUS_METHODS,
	CRV_MGM_PPAYMENT_PERIOD,
	RT_MODAL_PREMIUM_FACTORS_MONTHLY,
	RT_MODAL_PREMIUM_FACTORS_PAC,
	RT_MINIMUM_CREDITED_INTEREST,
	RT_CREDITED_SPREAD,
	RT_FLAT_FOR_CRVM_GUAR_MIN_CRI,
	N_POLICY_FEE_WITH_EACH_PREMIUM_ANNUAL,
	N_POLICY_FEE_WITH_EACH_PREMIUM_SEMIANNUAL,
	N_POLICY_FEE_WITH_EACH_PREMIUM_QUATERLY,
	N_POLICY_FEE_WITH_EACH_PREMIUM_MONTHLY,
	N_POLICY_FEE_WITH_EACH_PREMIUM_PAC,
	N_MODAL_PREMIUM_FACTORS_SEMIANNUAL,
	N_MODAL_PREMIUM_FACTORS_QUATERLY,
	N_FIRST_LIFE_DEFINITION,
	N_FLAT_FOR_PROP_OF_POLICY_FEE_COMM,
	N_MATURITY_VALUE_METHOD,
	N_MULTIPLE_REINSURANCE,
	N_FIRST_YEAR_COMMISSION,
	N_PROP_OF_FIRST_YEAR_COMM_ADVANCE,
	N_PERIOD_USING_COMM_ADVANCEMENT_SETTING,
	N_GUARANTEED_PERIOD_FOR_NLG_CRITERIA_1,
	N_SINGLE_PREM_INDICATOR,
	N_PREMIUM_SCHEDULE,
	N_CRVM_ALTERNATIVE_GMP,
	N_GMP_PREMIUM_MODE,
	N_BENEFIT_PERIOD_CAUSE_1,
	N_ELIMINATION_PERIOD_CAUSE_1,
	N_MAXIMUM_BENEFIT_MONTHS_CAUSE_1,
	N_BENEFIT_PERIOD_METHOD,
	N_FREQUENCY_OF_CHARGE_SMETHOD,
	N_VANISHING_PREMIUM_METHOD,
	N_VANISH_DURATION,
	N_PRM_PAYING_PERIOD_AGE,
	N_PRM_PAYING_PERIOD_DUR,
	N_DI_BENEFIT_FACTOR,
	N_MID_YEAR_CSV_METHOD,
	N_PLAN_TYPE,
	N_ANN_LIFE_STATUS,
	N_MULT_FOR_FACE_AMOUNT,
	TBL_PREMIUM,
	TBL_COMMISSION,
	TBL_CASH_VALUE,
	TBL_ROP,
	TBL_FACE_AMOUNT,
	TBL_BONUS_AND_CHARGE_BACK,
	TBL_DIVIDEND,
	TBL_PREMIUM_LOAD,
	TBL_GARANTEE_PREMIUMLOAD,
	TBL_EXPENSE_CHARGE,
	TBL_GARANTEE_EXPENSE_CHARGE,
	TBL_RISK_CHARGE,
	TBL_GARANTEED_RISK_CHARGE,
	TBL_SURRENDER_CHARGE,
	TBL_GARANTEED_PREMIUM,
	TBL_MIN_SURRENDER_VALUE,
	TBL_FUND_BONUS,
	TBL_CRVM_FUND_BONUS,
	TBL_CRVM_GMP,
	TBL_DUMPING_PREMIUM,
	TBL_PRICING_UTILIZATION,
	TBL_ANN_PAYOUT
) as

SELECT
    SK_ID_DIM_PFT
    ,AXIS_PLAN_CODE	
    ,CD_AXIS_CELL_NAME	
    ,CD_AXIS_MODULE	
    ,CD_PRM_PAYING_PERIOD_CODE	
    ,DESCRIPT	
    ,PRODUCT	
    ,GROUPE	
    ,SUB_GROUP	
    ,OTHER_BENEFIT_LINK_1	
    ,OTHER_BENEFIT_LINK_2	
    ,OTHER_BENEFIT_LINK_3	
    ,REINSURANCE_TERMS_1	
    ,BONUS_METHODS	
    ,CRV_MGM_PPAYMENT_PERIOD	
    ,RT_MODAL_PREMIUM_FACTORS_MONTHLY
    ,RT_MODAL_PREMIUM_FACTORS_PAC
    ,RT_MINIMUM_CREDITED_INTEREST
    ,RT_CREDITED_SPREAD
    ,RT_FLAT_FOR_CRVM_GUAR_MIN_CRI
    ,N_POLICY_FEE_WITH_EACH_PREMIUM_ANNUAL
    ,N_POLICY_FEE_WITH_EACH_PREMIUM_SEMIANNUAL
    ,N_POLICY_FEE_WITH_EACH_PREMIUM_QUATERLY
    ,N_POLICY_FEE_WITH_EACH_PREMIUM_MONTHLY
    ,N_POLICY_FEE_WITH_EACH_PREMIUM_PAC
    ,N_MODAL_PREMIUM_FACTORS_SEMIANNUAL
    ,N_MODAL_PREMIUM_FACTORS_QUATERLY
    ,N_FIRST_LIFE_DEFINITION
    ,N_FLAT_FOR_PROP_OF_POLICY_FEE_COMM
    ,N_MATURITY_VALUE_METHOD
    ,N_MULTIPLE_REINSURANCE
    ,N_FIRST_YEAR_COMMISSION
    ,N_PROP_OF_FIRST_YEAR_COMM_ADVANCE
    ,N_PERIOD_USING_COMM_ADVANCEMENT_SETTING
    ,N_GUARANTEED_PERIOD_FOR_NLG_CRITERIA_1
    ,N_SINGLE_PREM_INDICATOR
    ,N_PREMIUM_SCHEDULE
    ,N_CRVM_ALTERNATIVE_GMP
    ,N_GMP_PREMIUM_MODE
    ,N_BENEFIT_PERIOD_CAUSE_1
    ,N_ELIMINATION_PERIOD_CAUSE_1
    ,N_MAXIMUM_BENEFIT_MONTHS_CAUSE_1
    ,N_BENEFIT_PERIOD_METHOD
    ,N_FREQUENCY_OF_CHARGE_SMETHOD
    ,N_VANISHING_PREMIUM_METHOD
    ,N_VANISH_DURATION
    ,N_PRM_PAYING_PERIOD_AGE
    ,N_PRM_PAYING_PERIOD_DUR
    ,N_DI_BENEFIT_FACTOR
    ,N_MID_YEAR_CSV_METHOD
    ,N_PLAN_TYPE
    ,N_ANN_LIFE_STATUS
    ,N_MULT_FOR_FACE_AMOUNT
    ,TBL_PREMIUM	
    ,TBL_COMMISSION	
    ,TBL_CASH_VALUE	
    ,TBL_ROP	
    ,TBL_FACE_AMOUNT	
    ,TBL_BONUS_AND_CHARGE_BACK	
    ,TBL_DIVIDEND	
    ,TBL_PREMIUM_LOAD	
    ,TBL_GARANTEE_PREMIUMLOAD	
    ,TBL_EXPENSE_CHARGE	
    ,TBL_GARANTEE_EXPENSE_CHARGE	
    ,TBL_RISK_CHARGE	
    ,TBL_GARANTEED_RISK_CHARGE	
    ,TBL_SURRENDER_CHARGE	
    ,TBL_GARANTEED_PREMIUM	
    ,TBL_MIN_SURRENDER_VALUE	
    ,TBL_FUND_BONUS	
    ,TBL_CRVM_FUND_BONUS	
    ,TBL_CRVM_GMP	
    ,TBL_DUMPING_PREMIUM	
    ,TBL_PRICING_UTILIZATION	
    ,TBL_ANN_PAYOUT	


FROM DM_US_VI.DIM_PFT;
create or replace view VW_DIM_RATE_TYPE(
	SK_ID_DIM_RATE_TYPE,
	RATE_TYPE_NAME
) as

SELECT
    SK_ID_DIM_RATE_TYPE
    ,RATE_TYPE_NAME	

FROM DM_US_VI.DIM_RATE_TYPE;
create or replace view VW_DIM_RESERVE_RELEASE_TYPE(
	SK_ID_DIM_RESERVE_RELEASE_TYPE,
	RESERVE_RELEASE_TYPE
) as

SELECT
SK_ID_DIM_RESERVE_RELEASE_TYPE
,RESERVE_RELEASE_TYPE	


FROM DM_US_VI.DIM_RESERVE_RELEASE_TYPE;
create or replace view VW_DIM_RESIDENT_STATE(
	SK_ID_DIM_RESIDENT_STATE,
	RESIDENT_STATE_CD,
	RESIFENT_STATE_NAME
) as

SELECT
      SK_ID_DIM_STATE   AS SK_ID_DIM_RESIDENT_STATE
    , STATE_CD          AS RESIDENT_STATE_CD
    , STATE_NAME        AS RESIFENT_STATE_NAME

FROM DM_US_VI.DIM_STATE;
create or replace view VW_DIM_SEX(
	SK_ID_DIM_SEX,
	SEX_CD,
	SEXE_NAME
) as

SELECT
    SK_ID_DIM_SEX
    ,SEX_CD	
    ,SEXE_NAME	


FROM DM_US_VI.DIM_SEX;
create or replace view VW_DIM_SMOKING_STATUS(
	SK_ID_DIM_SMOKING_STATUS,
	SMOKING_STATUS_CODE,
	SMOKING_STATUS_NAME,
	MD_ACTIVATION_DT,
	MD_MODIFICATION_DT,
	MD_OBSOLESCENCE_DT
) as

SELECT
    SK_ID_DIM_SMOKING_STATUS
    ,SMOKING_STATUS_CODE	
    ,SMOKING_STATUS_NAME	
    ,MD_ACTIVATION_DT
    ,MD_MODIFICATION_DT
    ,MD_OBSOLESCENCE_DT

FROM DM_US_VI.DIM_SMOKING_STATUS;
create or replace view VW_DIM_STATE(
	SK_ID_DIM_STATE,
	STATE_CD,
	STATE_NAME
) as

SELECT
    SK_ID_DIM_STATE
    ,STATE_CD	
    ,STATE_NAME	

FROM DM_US_VI.DIM_STATE;
create or replace view VW_DIM_TERMINATION_REASON(
	SK_ID_DIM_TERMINATION_REASON,
	TERMINATION_REASON_CD,
	TERMINATION_REASON
) as

SELECT
    SK_ID_DIM_TERMINATION_REASON
    ,TERMINATION_REASON_CD	
    ,TERMINATION_REASON	

FROM DM_US_VI.DIM_TERMINATION_REASON;
create or replace view VW_DIM_VAT(
	SK_ID_DIM_VAT,
	AXIS_PLAN_CODE,
	CD_AXIS_CELL_NAME,
	CD_AXIS_MODULE,
	CD_ESCAP_TYPE,
	CD_ESCAP_CLASS,
	CD_ESC_PAR_BLOCK,
	DESCRIPT,
	PRODUCT,
	GROUPE,
	SUB_GROUP,
	BASE_CELL_NAME,
	STAT_RESERVE_METHOD_LINK,
	TAX_RESERVE_METHOD_LINK,
	SECOND_RESERVE_METHOD_LINK,
	ESCAP_ADJUS_TABLE_PRODUCT,
	ESCAP_DEATH_DESIGNATION,
	ESCAP_LAPSE_DESIGNATION,
	ESCAP_MORTALITY_GROUP,
	ESCAP_CSV_DEFICIENCY_GROUP,
	ESCAP_PFAD_EXCLUSION_GROUP,
	ESCAP_PAR_OR_ADJUSTABLEID,
	RT_FLAT_FOR_PREMIUM_TAX_RATE,
	RT_STAT_RES_FLAT_FOR_FINAL_MORTALITY_MAD,
	RT_STAT_RES_FLAT_FOR_LAPSE_PAD,
	N_REINSURANCE_TERMS_1_PERCENTAGE,
	N_PRICING_MULT_FOR_MORTALITY,
	N_PRICING_MULT_FOR_LAPSE_RATE,
	N_PRICING_MULT_FOR_OTHER_BENEFIT_RATES,
	N_STAT_RES_MULT_FOR_MORTALITY,
	N_STAT_RES_MULT_FOR_LAPSE_RATE,
	N_STAT_RES_MULT_FOR_OTHER_BENEFIT_RATES,
	N_STAT_RES_MULT_FOR_EXPENSES,
	N_TAX_RES_MULT_FOR_OTHER_BENEFIT_RATES,
	N_SECOND_RES_MULT_FOR_OTHER_BENEFIT_RATES,
	N_TAX_RES_REVALUATION_METHOD,
	N_STAT_RES_REVALUATIO_NMETHOD,
	N_SCND_RES_REVALUATION_METHOD,
	N_STAT_RES_MULT_FOR_CAUSE_1_QI,
	N_STAT_RES_MULT_FOR_TERMINATION_CAUSE_1,
	N_PRICING_ANN_MULT_FOR_2ND_LIFE_Q,
	N_STAT_RES_ANN_MULT_FOR_2ND_LIFE_Q,
	TBL_AGE_DISTRIBUTION,
	TBL_PRICING_MORTALITY,
	TBL_PRICING_LAPSE_RATE,
	TBL_PRICING_OTHER_BENEFIT_RATES,
	TBL_PRICING_EXPENSES,
	TBL_PRICING_INTEREST,
	TBL_STAT_RES_MORTALITY,
	TBL_STAT_RES_LAPSERATE,
	TBL_STAT_RES_OTHER_BENEFIT_RATES,
	TBL_STAT_RES_EXPENSES,
	TBL_STAT_RES_INTEREST,
	TBL_TAX_RES_MORTALITY,
	TBL_TAX_RES_INTEREST,
	TBL_TAX_RES_OTHER_BENEFIT_RATES,
	TBL_TAX_INPUT_TERMINAL_RES_FACTORS,
	TBL_SECOND_RES_MORTALITY,
	TBL_SECOND_RES_INTEREST,
	TBL_SECOND_RES_ANN_INTEREST,
	TBL_SECOND_RES_OTHER_BENEFIT_RATES,
	TBL_SCND_INPUT_TERMINAL_RES_FACTORS,
	TBL_SECOND_RES_TOTAL_PREMIUM,
	TBL_PRICING_CAUSE_1_QI,
	TBL_PRICING_TERMINATION_CAUSE_1,
	TBL_STAT_RES_CAUSE_1_QI,
	TBL_STAT_RES_TERMINATION_CAUSE_1,
	TBL_PRICING_ANN_2ND_LIFE_Q,
	TBL_STAT_RES_ANN_2ND_LIFE_Q,
	TBL_TAX_RES_ANN_2ND_LIFE_Q,
	TBL_SECOND_RES_ANN_2ND_LIFE_Q,
	TBL_PRICING_2ND_LIFE_ANN_PROJ,
	TBL_STAT_RES_2ND_LIFE_ANN_PROJ,
	TBL_PRICING_ANN_PROJ,
	TBL_STAT_RES_ANN_PROJ,
	TBL_ESCAP_BASE_LAPSE,
	PBR,
	VM20_CREDIBILITY,
	VM20_YEAR_TO_BEGING_RADING,
	VM20_YEAR_TO_GRADE_TO_INDUTRY,
	THIRD_RESERVE_METHOD_LINK,
	VM20_DR_SR_INTEREST_TABLE,
	VM20_DR_SR_EXPENSES_TABLE,
	VM20_DR_SR_MULT_FOR_EXPENSES,
	VM20_DR_SR_LAPSE_RATE_TABLE,
	VM20_DR_SR_FLATFORLAPSEPAD,
	VM20_DR_SR_MORTALITY_TABLE,
	VM20_DR_SR_MORTALITY_PAD_TABLE,
	VM20_DR_SR_MULT_FOR_LAPSE_RATE,
	VM20_DR_SR_MULT_FOR_MORTALITY,
	VM20_DR_SR_MULT_FOR_OTHER_BENEFIT_RATES,
	VM20_DR_SR_OTHER_BENEFIT_RATES_TABLE,
	FOURTH_RESERVE_METHOD_LINK,
	VM20_NPR_INTEREST_TABLE,
	VM20_NPR_LAPSE_RATE_TABLE,
	VM20_NPR_MORTALITY_TABLE,
	VM20_NPR_EXPENSES_TABLE,
	PROXY_FOR_STATUS,
	ANALYSIS_GROUPING,
	ANALYSIS_GROUPING_STATUS,
	STAT_INPUT_TERMINAL_RES_FACTORS_TABLE
) as

SELECT
    SK_ID_DIM_VAT
    ,AXIS_PLAN_CODE	
    ,CD_AXIS_CELL_NAME	
    ,CD_AXIS_MODULE	
    ,CD_ESCAP_TYPE	
    ,CD_ESCAP_CLASS	
    ,CD_ESC_PAR_BLOCK	
    ,DESCRIPT	
    ,PRODUCT	
    ,GROUPE	
    ,SUB_GROUP	
    ,BASE_CELL_NAME	
    ,STAT_RESERVE_METHOD_LINK	
    ,TAX_RESERVE_METHOD_LINK	
    ,SECOND_RESERVE_METHOD_LINK	
    ,ESCAP_ADJUS_TABLE_PRODUCT	
    ,ESCAP_DEATH_DESIGNATION	
    ,ESCAP_LAPSE_DESIGNATION	
    ,ESCAP_MORTALITY_GROUP	
    ,ESCAP_CSV_DEFICIENCY_GROUP	
    ,ESCAP_PFAD_EXCLUSION_GROUP	
    ,ESCAP_PAR_OR_ADJUSTABLEID	
    ,RT_FLAT_FOR_PREMIUM_TAX_RATE
    ,RT_STAT_RES_FLAT_FOR_FINAL_MORTALITY_MAD
    ,RT_STAT_RES_FLAT_FOR_LAPSE_PAD
    ,N_REINSURANCE_TERMS_1_PERCENTAGE
    ,N_PRICING_MULT_FOR_MORTALITY
    ,N_PRICING_MULT_FOR_LAPSE_RATE
    ,N_PRICING_MULT_FOR_OTHER_BENEFIT_RATES
    ,N_STAT_RES_MULT_FOR_MORTALITY
    ,N_STAT_RES_MULT_FOR_LAPSE_RATE
    ,N_STAT_RES_MULT_FOR_OTHER_BENEFIT_RATES
    ,N_STAT_RES_MULT_FOR_EXPENSES
    ,N_TAX_RES_MULT_FOR_OTHER_BENEFIT_RATES
    ,N_SECOND_RES_MULT_FOR_OTHER_BENEFIT_RATES
    ,N_TAX_RES_REVALUATION_METHOD
    ,N_STAT_RES_REVALUATIO_NMETHOD
    ,N_SCND_RES_REVALUATION_METHOD
    ,N_STAT_RES_MULT_FOR_CAUSE_1_QI
    ,N_STAT_RES_MULT_FOR_TERMINATION_CAUSE_1
    ,N_PRICING_ANN_MULT_FOR_2ND_LIFE_Q
    ,N_STAT_RES_ANN_MULT_FOR_2ND_LIFE_Q
    ,TBL_AGE_DISTRIBUTION	
    ,TBL_PRICING_MORTALITY	
    ,TBL_PRICING_LAPSE_RATE	
    ,TBL_PRICING_OTHER_BENEFIT_RATES	
    ,TBL_PRICING_EXPENSES	
    ,TBL_PRICING_INTEREST	
    ,TBL_STAT_RES_MORTALITY	
    ,TBL_STAT_RES_LAPSERATE	
    ,TBL_STAT_RES_OTHER_BENEFIT_RATES	
    ,TBL_STAT_RES_EXPENSES	
    ,TBL_STAT_RES_INTEREST	
    ,TBL_TAX_RES_MORTALITY	
    ,TBL_TAX_RES_INTEREST	
    ,TBL_TAX_RES_OTHER_BENEFIT_RATES	
    ,TBL_TAX_INPUT_TERMINAL_RES_FACTORS	
    ,TBL_SECOND_RES_MORTALITY	
    ,TBL_SECOND_RES_INTEREST	
    ,TBL_SECOND_RES_ANN_INTEREST	
    ,TBL_SECOND_RES_OTHER_BENEFIT_RATES	
    ,TBL_SCND_INPUT_TERMINAL_RES_FACTORS	
    ,TBL_SECOND_RES_TOTAL_PREMIUM	
    ,TBL_PRICING_CAUSE_1_QI	
    ,TBL_PRICING_TERMINATION_CAUSE_1	
    ,TBL_STAT_RES_CAUSE_1_QI	
    ,TBL_STAT_RES_TERMINATION_CAUSE_1	
    ,TBL_PRICING_ANN_2ND_LIFE_Q	
    ,TBL_STAT_RES_ANN_2ND_LIFE_Q	
    ,TBL_TAX_RES_ANN_2ND_LIFE_Q	
    ,TBL_SECOND_RES_ANN_2ND_LIFE_Q	
    ,TBL_PRICING_2ND_LIFE_ANN_PROJ	
    ,TBL_STAT_RES_2ND_LIFE_ANN_PROJ	
    ,TBL_PRICING_ANN_PROJ	
    ,TBL_STAT_RES_ANN_PROJ	
    ,TBL_ESCAP_BASE_LAPSE	
    ,PBR
    ,VM20_CREDIBILITY
    ,VM20_YEAR_TO_BEGING_RADING
    ,VM20_YEAR_TO_GRADE_TO_INDUTRY
    ,THIRD_RESERVE_METHOD_LINK	
    ,VM20_DR_SR_INTEREST_TABLE	
    ,VM20_DR_SR_EXPENSES_TABLE	
    ,VM20_DR_SR_MULT_FOR_EXPENSES
    ,VM20_DR_SR_LAPSE_RATE_TABLE	
    ,VM20_DR_SR_FLATFORLAPSEPAD
    ,VM20_DR_SR_MORTALITY_TABLE	
    ,VM20_DR_SR_MORTALITY_PAD_TABLE	
    ,VM20_DR_SR_MULT_FOR_LAPSE_RATE
    ,VM20_DR_SR_MULT_FOR_MORTALITY
    ,VM20_DR_SR_MULT_FOR_OTHER_BENEFIT_RATES
    ,VM20_DR_SR_OTHER_BENEFIT_RATES_TABLE	
    ,FOURTH_RESERVE_METHOD_LINK	
    ,VM20_NPR_INTEREST_TABLE	
    ,VM20_NPR_LAPSE_RATE_TABLE	
    ,VM20_NPR_MORTALITY_TABLE	
    ,VM20_NPR_EXPENSES_TABLE	
    ,PROXY_FOR_STATUS	
    ,ANALYSIS_GROUPING	
    ,ANALYSIS_GROUPING_STATUS	
    ,STAT_INPUT_TERMINAL_RES_FACTORS_TABLE	

FROM DM_US_VI.DIM_VAT;
create or replace view VW_FT_COVERAGE(
	SK_ID_DIM_COVERAGE,
	ID_DIM_ISSUE_DATE,
	ID_DIM_DOD_DATE,
	ID_DIM_CLOSE_DATE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	SK_ID_DIM_PFT,
	SK_ID_DIM_SEX,
	SK_ID_ISSUE_AGE_GROUP,
	SK_ID_ATTEINED_AGE_GROUP,
	SK_ID_DIM_SMOKING_STATUS,
	SK_ID_DIM_DURATION_RANGE,
	SK_ID_DIM_VAT,
	SK_ID_DIM_COVERAGE_STATUS,
	SK_ID_DIM_RESIDENT_STATE,
	SK_ID_DIM_AGENT,
	SK_ID_DIM_AGENCY,
	SK_ID_DIM_TERMINATION_REASON,
	POLICY_ID,
	AXIS_PLAN_CODE,
	ISSUE_AGE,
	ATTEINED_AGE,
	DURATION_IN_YEARS,
	AMT_CURRENT_DEATH_BENEFIT,
	AMT_CURRENT_FACE_AMOUNT,
	AMT_ORIGINAL_FACE_AMOUNT,
	AMT_CURRENT_BENEFIT_VALUE,
	ANT_CURRENT_CASH_VALUE,
	AMT_PREVIOUS_CASH_VALUE,
	CD_PAYMENT_MODE,
	CD_DEATH_BENEFIT_OPTION,
	CD_LINE_OF_BUSINESS,
	IND_COUVERTURE_TERMINEE,
	CD_PARTICIPATION_CODE,
	CD_JOINT_TYPE,
	CD_SUSPENSION,
	CD_TAX_QUALIFIED_STATUS
) as

SELECT
    SK_ID_DIM_COVERAGE
    , ID_DIM_ISSUE_DATE
    , ID_DIM_DOD_DATE 
    , ID_DIM_CLOSE_DATE 
    , SK_ID_DIM_COVERAGE_AXIS_MODULE
    , SK_ID_DIM_PFT
    , SK_ID_DIM_SEX
    , SK_ID_ISSUE_AGE_GROUP
    , SK_ID_ATTEINED_AGE_GROUP
    , SK_ID_DIM_SMOKING_STATUS
    , SK_ID_DIM_DURATION_RANGE
    , SK_ID_DIM_VAT
    , SK_ID_DIM_COVERAGE_STATUS
    , SK_ID_DIM_RESIDENT_STATE
    , SK_ID_DIM_AGENT
    , SK_ID_DIM_AGENCY
    , SK_ID_DIM_TERMINATION_REASON
    , POLICY_ID
    , AXIS_PLAN_CODE
    , ISSUE_AGE
    , ATTEINED_AGE
    , DURATION_IN_YEARS
    , AMT_CURRENT_DEATH_BENEFIT
    , AMT_CURRENT_FACE_AMOUNT
    , AMT_ORIGINAL_FACE_AMOUNT
    , AMT_CURRENT_BENEFIT_VALUE
    , ANT_CURRENT_CASH_VALUE
    , AMT_PREVIOUS_CASH_VALUE
    , CD_PAYMENT_MODE
    , CD_DEATH_BENEFIT_OPTION
    , CD_LINE_OF_BUSINESS
    , IND_COUVERTURE_TERMINEE
    , CD_PARTICIPATION_CODE
    , CD_JOINT_TYPE
    , CD_SUSPENSION
    , CD_TAX_QUALIFIED_STATUS

FROM DM_US_VI.FT_COVERAGE;
create or replace view VW_FT_GL_BALANCE(
	SK_ID_FT_GL_BALANCE,
	SK_ID_FT_COVERAGE,
	ID_DIM_ACCOUNTING_PERIOD_DATE,
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_GL_CHART,
	SK_ID_DIM_COVERAGE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	ACCOUNTING_PERIOD_CODE,
	POLICY_ID,
	SK_ID_DIM_PFT,
	SK_ID_DIM_SEX,
	SK_ID_ISSUE_AGE_GROUP,
	SK_ID_ATTEINED_AGE_GROUP,
	SK_ID_DIM_SMOKING_STATUS,
	SK_ID_DIM_DURATION_RANGE,
	SK_ID_DIM_VAT,
	SK_ID_DIM_COVERAGE_STATUS,
	ID_DIM_ISSUE_DATE,
	SK_ID_DIM_RESIDENT_STATE,
	SK_ID_DIM_ISSUE_STATE,
	SK_ID_DIM_AGENT,
	SK_ID_DIM_AGENCY,
	SK_ID_DIM_TERMINATION_REASON,
	ID_DIM_ISSUE_AGE,
	ID_DIM_ATTEINTED_AGE,
	ID_DIM_COVERAGE_DURATION,
	ISSUE_AGE,
	ATTEINTED_AGE,
	DURATION_IN_YEARS,
	IND_ICOS,
	CD_ORIGINE,
	CD_SYSTEME_SOURCE,
	DISAGG_BALANCE_AMT,
	BENEFIT_PAID_CURRENT_AMT,
	INVEST_COMP_PAID_CURRENT_AMT,
	UDC
) as

SELECT
      SK_ID_FT_GL_BALANCE						AS SK_ID_FT_GL_BALANCE	
    , SK_ID_FT_COVERAGE                         AS SK_ID_FT_COVERAGE  					
    , ID_DIM_ACCOUNTING_PERIOD_DATE				AS ID_DIM_ACCOUNTING_PERIOD_DATE
    , ID_DIM_ACCOUNTING_PERIOD_DATE             AS ID_DIM_EVALUATION_DATE				
    , FT.SK_ID_DIM_GL_CHART						AS SK_ID_DIM_GL_CHART						
    , FT.SK_ID_DIM_COVERAGE						AS SK_ID_DIM_COVERAGE						
    , FT.SK_ID_DIM_COVERAGE_AXIS_MODULE			AS SK_ID_DIM_COVERAGE_AXIS_MODULE
    , concat(TO_CHAR(YEAR(D_DT.DAY_SHORT_DATE)),'-', CONCAT('0',RIGHT(TO_CHAR(MONTH(D_DT.DAY_SHORT_DATE)),2))) AS ACCOUNTING_PERIOD_CODE
    , FT.POLICY_ID								AS POLICY_ID								
    , SK_ID_DIM_PFT								AS SK_ID_DIM_PFT								
    , SK_ID_DIM_SEX								AS SK_ID_DIM_SEX								
    , SK_ID_ISSUE_AGE_GROUP						AS SK_ID_ISSUE_AGE_GROUP						
    , SK_ID_ATTEINED_AGE_GROUP					AS SK_ID_ATTEINED_AGE_GROUP					
    , SK_ID_DIM_SMOKING_STATUS					AS SK_ID_DIM_SMOKING_STATUS					
    , SK_ID_DIM_DURATION_RANGE					AS SK_ID_DIM_DURATION_RANGE					
    , SK_ID_DIM_VAT								AS SK_ID_DIM_VAT								
    , SK_ID_DIM_COVERAGE_STATUS					AS SK_ID_DIM_COVERAGE_STATUS					
    , ID_DIM_ISSUE_DATE							AS ID_DIM_ISSUE_DATE							
    , SK_ID_DIM_RESIDENT_STATE					AS SK_ID_DIM_RESIDENT_STATE
    , SK_ID_DIM_ISSUE_STATE                                     AS SK_ID_DIM_ISSUE_STATE					
    , SK_ID_DIM_AGENT							AS SK_ID_DIM_AGENT							
    , SK_ID_DIM_AGENCY							AS SK_ID_DIM_AGENCY							
    , SK_ID_DIM_TERMINATION_REASON				AS SK_ID_DIM_TERMINATION_REASON	
    , (FTC.SK_ID_ISSUE_AGE_GROUP * 1000) + FTC.ISSUE_AGE                AS ID_DIM_ISSUE_AGE
    , (FTC.SK_ID_ATTEINED_AGE_GROUP * 1000) + FTC.ATTEINED_AGE          AS ID_DIM_ATTEINTED_AGE
    , (FTC.SK_ID_DIM_DURATION_RANGE * 1000) + FTC.DURATION_IN_YEARS     AS ID_DIM_COVERAGE_DURATION    
    , FTC.ISSUE_AGE                             AS ISSUE_AGE
    , FTC.ATTEINED_AGE                          AS ATTEINTED_AGE
    , FTC.DURATION_IN_YEARS                     AS DURATION_IN_YEARS			
    , IND_ICOS									AS IND_ICOS									
    , CD_ORIGINE								AS CD_ORIGINE								
    , CD_SYSTEME_SOURCE							AS CD_SYSTEME_SOURCE							
    , DISAGG_BALANCE_AMT						AS DISAGG_BALANCE_AMT						
    , BENEFIT_PAID_CURRENT_AMT					AS BENEFIT_PAID_CURRENT_AMT					
    , INVEST_COMP_PAID_CURRENT_AMT				AS INVEST_COMP_PAID_CURRENT_AMT	
    , IFNULL(D_CV.POLICY_NO,'')                 AS UDC			
FROM DM_US_VI.FT_GL_BALANCE FT 
INNER JOIN DM_US_VI.DIM_DATE D_DT 
        ON FT.ID_DIM_ACCOUNTING_PERIOD_DATE = D_DT.ID_DIM_DATE 
LEFT JOIN   DM_US_VI.FT_COVERAGE FTC ON FT.SK_ID_DIM_COVERAGE  = FTC.SK_ID_DIM_COVERAGE
        AND D_DT.DAY_SHORT_DATE BETWEEN FTC.MD_ACTIVATION_DT AND FTC.MD_OBSOLESCENCE_DT
LEFT JOIN DM_US_VI.DIM_COVERAGE D_CV  ON FT.SK_ID_DIM_COVERAGE = D_CV.SK_ID_DIM_COVERAGE;
create or replace view VW_FT_GL_BALANCE_AGGREGATED(
	SK_ID_FT_GL_BALANCE_AGGREGATED,
	ID_DIM_ACCOUNTING_PERIOD_DATE,
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_GL_CHART,
	ACCOUNTING_PERIOD_CODE,
	UDC,
	CD_SYSTEME_SOURCE,
	AGG_BALANCE_AMT
) as
SELECT
      SK_ID_FT_GL_BALANCE_AGGREGATED						AS SK_ID_FT_GL_BALANCE_AGGREGATED					
    , ID_DIM_ACCOUNTING_PERIOD_DATE				AS ID_DIM_ACCOUNTING_PERIOD_DATE
    , ID_DIM_ACCOUNTING_PERIOD_DATE             AS ID_DIM_EVALUATION_DATE				
    , FT.SK_ID_DIM_GL_CHART						AS SK_ID_DIM_GL_CHART						
    , concat(TO_CHAR(YEAR(D_DT.DAY_SHORT_DATE)),'-', CONCAT('0',RIGHT(TO_CHAR(MONTH(D_DT.DAY_SHORT_DATE)),2))) AS ACCOUNTING_PERIOD_CODE
    , FT.UDC								    AS UDC								
    , CD_SYSTEME_SOURCE							AS CD_SYSTEME_SOURCE							
    , AGG_BALANCE_AMT						    AS AGG_BALANCE_AMT						

FROM DM_US_VI.FT_GL_BALANCE_AGGREGATED FT 
INNER JOIN DM_US_VI.DIM_DATE D_DT 
        ON FT.ID_DIM_ACCOUNTING_PERIOD_DATE = D_DT.ID_DIM_DATE;
create or replace view VW_FT_SOE_CASHFLOW(
	SK_ID_FT_SOE_CASHFLOW,
	SK_ID_FT_COVERAGE,
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_RESERVE_RELEASE_TYPE,
	SK_ID_DIM_RATE_TYPE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	SK_ID_DIM_COVERAGE,
	POLICY_ID,
	ID_DIM_ISSUE_DATE,
	ID_DIM_DOD_DATE,
	ID_DIM_CLOSE_DATE,
	SK_ID_DIM_PFT,
	SK_ID_DIM_SEX,
	SK_ID_ISSUE_AGE_GROUP,
	SK_ID_ATTEINED_AGE_GROUP,
	SK_ID_DIM_SMOKING_STATUS,
	SK_ID_DIM_DURATION_RANGE,
	SK_ID_DIM_VAT,
	SK_ID_DIM_COVERAGE_STATUS,
	SK_ID_DIM_RESIDENT_STATE,
	SK_ID_DIM_ISSUE_STATE,
	SK_ID_DIM_AGENT,
	SK_ID_DIM_AGENCY,
	SK_ID_DIM_TERMINATION_REASON,
	ID_DIM_ISSUE_AGE,
	ID_DIM_ATTEINTED_AGE,
	ID_DIM_COVERAGE_DURATION,
	ISSUE_AGE,
	ATTEINTED_AGE,
	DURATION_IN_YEARS,
	AXIS_INCREMENT,
	CODE_LIGNE_AFFAIRE,
	CEDED_ACTUAL_CASHFLOW_COMMISSION,
	CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS,
	CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT,
	CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS,
	CEDED_ACTUAL_CASHFLOW_EXPENSE,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT,
	CEDED_ACTUAL_CASHFLOW_MISCOFF,
	CEDED_ACTUAL_CASHFLOW_MISCON,
	CEDED_ACTUAL_CASHFLOW_NOTTAKENUP,
	CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT,
	CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID,
	CEDED_ACTUAL_CASHFLOW_PREMIUM,
	CEDED_ACTUAL_CASHFLOW_PREMIUMTAX,
	CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE,
	CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN,
	CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS,
	CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT,
	CEDED_EXPECTED_CASHFLOW_COMMISSION,
	CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS,
	CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT,
	CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS,
	CEDED_EXPECTED_CASHFLOW_EXPENSE,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT,
	CEDED_EXPECTED_CASHFLOW_MISCOFF,
	CEDED_EXPECTED_CASHFLOW_MISCON,
	CEDED_EXPECTED_CASHFLOW_NOTTAKENUP,
	CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT,
	CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID,
	CEDED_EXPECTED_CASHFLOW_PREMIUM,
	CEDED_EXPECTED_CASHFLOW_PREMIUMTAX,
	CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE,
	CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN,
	CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS,
	CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT,
	GROSS_ACTUAL_CASHFLOW_COMMISSION,
	GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS,
	GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT,
	GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS,
	GROSS_ACTUAL_CASHFLOW_EXPENSE,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT,
	GROSS_ACTUAL_CASHFLOW_MISCOFF,
	GROSS_ACTUAL_CASHFLOW_MISCON,
	GROSS_ACTUAL_CASHFLOW_NOTTAKENUP,
	GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT,
	GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID,
	GROSS_ACTUAL_CASHFLOW_PREMIUM,
	GROSS_ACTUAL_CASHFLOW_PREMIUMTAX,
	GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE,
	GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN,
	GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS,
	GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT,
	GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS,
	GROSS_EXPECTED_CASHFLOW_COMMISSION,
	GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT,
	GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS,
	GROSS_EXPECTED_CASHFLOW_EXPENSE,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT,
	GROSS_EXPECTED_CASHFLOW_MISCOFF,
	GROSS_EXPECTED_CASHFLOW_MISCON,
	GROSS_EXPECTED_CASHFLOW_NOTTAKENUP,
	GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT,
	GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID,
	GROSS_EXPECTED_CASHFLOW_PREMIUM,
	GROSS_EXPECTED_CASHFLOW_PREMIUMTAX,
	GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE,
	GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN,
	GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS,
	GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT
) as

SELECT
      SK_ID_FT_SOE_CASHFLOW
    , SK_ID_FT_COVERAGE                         AS SK_ID_FT_COVERAGE  
    , ID_DIM_EVALUATION_DATE
    , -2                                        AS SK_ID_DIM_RESERVE_RELEASE_TYPE
    , -2                                        AS SK_ID_DIM_RATE_TYPE
    , CF.SK_ID_DIM_COVERAGE_AXIS_MODULE
    , CF.SK_ID_DIM_COVERAGE
    , CF.POLICY_ID
    , CASE WHEN ID_DIM_ISSUE_DATE = -1 THEN 19000101 ELSE ID_DIM_ISSUE_DATE END AS ID_DIM_ISSUE_DATE
    , CASE WHEN ID_DIM_DOD_DATE = -1 THEN 19000101 ELSE ID_DIM_DOD_DATE END AS ID_DIM_DOD_DATE
    , CASE WHEN ID_DIM_CLOSE_DATE = -1 THEN 19000101 ELSE ID_DIM_CLOSE_DATE END AS ID_DIM_CLOSE_DATE
    , SK_ID_DIM_PFT
    , SK_ID_DIM_SEX
    , SK_ID_ISSUE_AGE_GROUP
    , SK_ID_ATTEINED_AGE_GROUP
    , SK_ID_DIM_SMOKING_STATUS
    , SK_ID_DIM_DURATION_RANGE
    , SK_ID_DIM_VAT
    , SK_ID_DIM_COVERAGE_STATUS
    , SK_ID_DIM_RESIDENT_STATE
    , SK_ID_DIM_ISSUE_STATE
    , SK_ID_DIM_AGENT
    , SK_ID_DIM_AGENCY
    , SK_ID_DIM_TERMINATION_REASON
    , (FTC.SK_ID_ISSUE_AGE_GROUP * 1000) + FTC.ISSUE_AGE                AS ID_DIM_ISSUE_AGE
    , (FTC.SK_ID_ATTEINED_AGE_GROUP * 1000) + FTC.ATTEINED_AGE          AS ID_DIM_ATTEINTED_AGE
    , (FTC.SK_ID_DIM_DURATION_RANGE * 1000) + FTC.DURATION_IN_YEARS     AS ID_DIM_COVERAGE_DURATION   
    , FTC.ISSUE_AGE                             AS ISSUE_AGE
    , FTC.ATTEINED_AGE                          AS ATTEINTED_AGE
    , FTC.DURATION_IN_YEARS                     AS DURATION_IN_YEARS			
    , AXIS_INCREMENT
    , CODE_LIGNE_AFFAIRE
    , CEDED_ACTUAL_CASHFLOW_COMMISSION
    , CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS
    , CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT
    , CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS
    , CEDED_ACTUAL_CASHFLOW_EXPENSE
    , CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH
    , CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE
    , CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF
    , CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON
    , CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS
    , CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP
    , CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN
    , CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT
    , CEDED_ACTUAL_CASHFLOW_MISCOFF
    , CEDED_ACTUAL_CASHFLOW_MISCON
    , CEDED_ACTUAL_CASHFLOW_NOTTAKENUP
    , CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT
    , CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID
    , CEDED_ACTUAL_CASHFLOW_PREMIUM
    , CEDED_ACTUAL_CASHFLOW_PREMIUMTAX
    , CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE
    , CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN
    , CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS
    , CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT
    , CEDED_EXPECTED_CASHFLOW_COMMISSION
    , CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS
    , CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT
    , CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS
    , CEDED_EXPECTED_CASHFLOW_EXPENSE
    , CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH
    , CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE
    , CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF
    , CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON
    , CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS
    , CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP
    , CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN
    , CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT
    , CEDED_EXPECTED_CASHFLOW_MISCOFF
    , CEDED_EXPECTED_CASHFLOW_MISCON
    , CEDED_EXPECTED_CASHFLOW_NOTTAKENUP
    , CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT
    , CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID
    , CEDED_EXPECTED_CASHFLOW_PREMIUM
    , CEDED_EXPECTED_CASHFLOW_PREMIUMTAX
    , CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE
    , CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN
    , CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS
    , CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT
    , GROSS_ACTUAL_CASHFLOW_COMMISSION
    , GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS
    , GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT
    , GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS
    , GROSS_ACTUAL_CASHFLOW_EXPENSE
    , GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH
    , GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE
    , GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF
    , GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON
    , GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS
    , GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP
    , GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN
    , GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT
    , GROSS_ACTUAL_CASHFLOW_MISCOFF
    , GROSS_ACTUAL_CASHFLOW_MISCON
    , GROSS_ACTUAL_CASHFLOW_NOTTAKENUP
    , GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT
    , GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID
    , GROSS_ACTUAL_CASHFLOW_PREMIUM
    , GROSS_ACTUAL_CASHFLOW_PREMIUMTAX
    , GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE
    , GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN
    , GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS
    , GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT
    , GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS
    , GROSS_EXPECTED_CASHFLOW_COMMISSION
    , GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT
    , GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS
    , GROSS_EXPECTED_CASHFLOW_EXPENSE
    , GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH
    , GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE
    , GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF
    , GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON
    , GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS
    , GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP
    , GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN
    , GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT
    , GROSS_EXPECTED_CASHFLOW_MISCOFF
    , GROSS_EXPECTED_CASHFLOW_MISCON
    , GROSS_EXPECTED_CASHFLOW_NOTTAKENUP
    , GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT
    , GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID
    , GROSS_EXPECTED_CASHFLOW_PREMIUM
    , GROSS_EXPECTED_CASHFLOW_PREMIUMTAX
    , GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE
    , GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN
    , GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS
    , GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT

FROM DM_US_VI.FT_SOE_CASHFLOW CF

INNER JOIN DM_US_VI.DIM_DATE D_DT 
        ON CF.ID_DIM_EVALUATION_DATE = D_DT.ID_DIM_DATE 

LEFT JOIN DM_US_VI.FT_COVERAGE FTC 
        ON CF.SK_ID_DIM_COVERAGE  = FTC.SK_ID_DIM_COVERAGE
        AND D_DT.DAY_SHORT_DATE BETWEEN FTC.MD_ACTIVATION_DT AND FTC.MD_OBSOLESCENCE_DT;
create or replace view VW_FT_SOE_INVESTMENT_COMPONENT(
	SK_ID_FT_SOE_INVESTMENT_COMPONENT,
	SK_ID_FT_COVERAGE,
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_RESERVE_RELEASE_TYPE,
	SK_ID_DIM_RATE_TYPE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	SK_ID_DIM_COVERAGE,
	POLICY_ID,
	ID_DIM_ISSUE_DATE,
	ID_DIM_DOD_DATE,
	ID_DIM_CLOSE_DATE,
	SK_ID_DIM_PFT,
	SK_ID_DIM_SEX,
	SK_ID_ISSUE_AGE_GROUP,
	SK_ID_ATTEINED_AGE_GROUP,
	SK_ID_DIM_SMOKING_STATUS,
	SK_ID_DIM_DURATION_RANGE,
	SK_ID_DIM_VAT,
	SK_ID_DIM_COVERAGE_STATUS,
	SK_ID_DIM_RESIDENT_STATE,
	SK_ID_DIM_AGENT,
	SK_ID_DIM_AGENCY,
	SK_ID_DIM_TERMINATION_REASON,
	ID_DIM_ISSUE_AGE,
	ID_DIM_ATTEINTED_AGE,
	ID_DIM_COVERAGE_DURATION,
	ISSUE_AGE,
	ATTEINTED_AGE,
	DURATION_IN_YEARS,
	AXIS_INCREMENT,
	CODE_LIGNE_AFFAIRE,
	CEDED_ACTUAL_INVCOMP_DEATH,
	CEDED_ACTUAL_INVCOMP_LAPSE,
	CEDED_ACTUAL_INVCOMP_OTHERBEN,
	CEDED_ACTUAL_INVCOMP_SURVIVORS,
	CEDED_EXPECTED_INVCOMP_DEATH,
	CEDED_EXPECTED_INVCOMP_LAPSE,
	CEDED_EXPECTED_INVCOMP_OTHERBEN,
	CEDED_EXPECTED_INVCOMP_SURVIVORS,
	GROSS_ACTUAL_INVCOMP_DEATH,
	GROSS_ACTUAL_INVCOMP_LAPSE,
	GROSS_ACTUAL_INVCOMP_OTHERBEN,
	GROSS_ACTUAL_INVCOMP_SURVIVORS,
	GROSS_EXPECTED_INVCOMP_DEATH,
	GROSS_EXPECTED_INVCOMP_LAPSE,
	GROSS_EXPECTED_INVCOMP_OTHERBEN,
	GROSS_EXPECTED_INVCOMP_SURVIVORS
) as

SELECT
      SK_ID_FT_SOE_INVESTMENT_COMPONENT
    , SK_ID_FT_COVERAGE                         AS SK_ID_FT_COVERAGE        
    , ID_DIM_EVALUATION_DATE
    , -2                                        AS SK_ID_DIM_RESERVE_RELEASE_TYPE
    , -2                                        AS SK_ID_DIM_RATE_TYPE
    , IC.SK_ID_DIM_COVERAGE_AXIS_MODULE
    , IC.SK_ID_DIM_COVERAGE
    , IC.POLICY_ID
    , CASE WHEN ID_DIM_ISSUE_DATE = -1 THEN 19000101 ELSE ID_DIM_ISSUE_DATE END AS ID_DIM_ISSUE_DATE
    , CASE WHEN ID_DIM_DOD_DATE = -1 THEN 19000101 ELSE ID_DIM_DOD_DATE END AS ID_DIM_DOD_DATE
    , CASE WHEN ID_DIM_CLOSE_DATE = -1 THEN 19000101 ELSE ID_DIM_CLOSE_DATE END AS ID_DIM_CLOSE_DATE
    , SK_ID_DIM_PFT
    , SK_ID_DIM_SEX
    , SK_ID_ISSUE_AGE_GROUP
    , SK_ID_ATTEINED_AGE_GROUP
    , SK_ID_DIM_SMOKING_STATUS
    , SK_ID_DIM_DURATION_RANGE
    , SK_ID_DIM_VAT
    , SK_ID_DIM_COVERAGE_STATUS
    , SK_ID_DIM_RESIDENT_STATE
    , SK_ID_DIM_AGENT
    , SK_ID_DIM_AGENCY
    , SK_ID_DIM_TERMINATION_REASON
    , (FTC.SK_ID_ISSUE_AGE_GROUP * 1000) + FTC.ISSUE_AGE                AS ID_DIM_ISSUE_AGE
    , (FTC.SK_ID_ATTEINED_AGE_GROUP * 1000) + FTC.ATTEINED_AGE          AS ID_DIM_ATTEINTED_AGE
    , (FTC.SK_ID_DIM_DURATION_RANGE * 1000) + FTC.DURATION_IN_YEARS     AS ID_DIM_COVERAGE_DURATION   
    , FTC.ISSUE_AGE                             AS ISSUE_AGE
    , FTC.ATTEINED_AGE                          AS ATTEINTED_AGE
    , FTC.DURATION_IN_YEARS                     AS DURATION_IN_YEARS			
    , AXIS_INCREMENT
    , CODE_LIGNE_AFFAIRE
    , CEDED_ACTUAL_INVCOMP_DEATH
    , CEDED_ACTUAL_INVCOMP_LAPSE
    , CEDED_ACTUAL_INVCOMP_OTHERBEN
    , CEDED_ACTUAL_INVCOMP_SURVIVORS
    , CEDED_EXPECTED_INVCOMP_DEATH
    , CEDED_EXPECTED_INVCOMP_LAPSE
    , CEDED_EXPECTED_INVCOMP_OTHERBEN
    , CEDED_EXPECTED_INVCOMP_SURVIVORS
    , GROSS_ACTUAL_INVCOMP_DEATH
    , GROSS_ACTUAL_INVCOMP_LAPSE
    , GROSS_ACTUAL_INVCOMP_OTHERBEN
    , GROSS_ACTUAL_INVCOMP_SURVIVORS
    , GROSS_EXPECTED_INVCOMP_DEATH
    , GROSS_EXPECTED_INVCOMP_LAPSE
    , GROSS_EXPECTED_INVCOMP_OTHERBEN
    , GROSS_EXPECTED_INVCOMP_SURVIVORS

FROM DM_US_VI.FT_SOE_INVESTMENT_COMPONENT IC
INNER JOIN DM_US_VI.DIM_DATE D_DT 
        ON IC.ID_DIM_EVALUATION_DATE = D_DT.ID_DIM_DATE 

LEFT JOIN DM_US_VI.FT_COVERAGE FTC 
        ON IC.SK_ID_DIM_COVERAGE  = FTC.SK_ID_DIM_COVERAGE
        AND D_DT.DAY_SHORT_DATE BETWEEN FTC.MD_ACTIVATION_DT AND FTC.MD_OBSOLESCENCE_DT;
create or replace view VW_FT_SOE_RESERVE_RELEASE(
	SK_ID_FT_SOE_RESERVE_RELEASE,
	SK_ID_FT_COVERAGE,
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_RESERVE_RELEASE_TYPE,
	SK_ID_DIM_RATE_TYPE,
	SK_ID_DIM_COVERAGE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	POLICY_ID,
	ID_DIM_ISSUE_DATE,
	ID_DIM_DOD_DATE,
	ID_DIM_CLOSE_DATE,
	SK_ID_DIM_PFT,
	SK_ID_DIM_SEX,
	SK_ID_ISSUE_AGE_GROUP,
	SK_ID_ATTEINED_AGE_GROUP,
	SK_ID_DIM_SMOKING_STATUS,
	SK_ID_DIM_DURATION_RANGE,
	SK_ID_DIM_VAT,
	SK_ID_DIM_COVERAGE_STATUS,
	SK_ID_DIM_RESIDENT_STATE,
	SK_ID_DIM_ISSUE_STATE,
	SK_ID_DIM_AGENT,
	SK_ID_DIM_AGENCY,
	SK_ID_DIM_TERMINATION_REASON,
	ID_DIM_ISSUE_AGE,
	ID_DIM_ATTEINTED_AGE,
	ID_DIM_COVERAGE_DURATION,
	ISSUE_AGE,
	ATTEINTED_AGE,
	DURATION_IN_YEARS,
	AXIS_INCREMENT,
	CODE_LIGNE_AFFAIRE,
	GROSS_ACTUAL_RELEASE_ON_DEATH,
	GROSS_ACTUAL_RELEASE_ON_LAPSE,
	GROSS_ACTUAL_RELEASE_ON_MISC_OFF,
	GROSS_ACTUAL_RELEASE_ON_MISC_ON,
	GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN,
	GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT,
	GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT,
	GROSS_EXPECTED_RELEASE_ON_DEATH,
	GROSS_EXPECTED_RELEASE_ON_LAPSE,
	GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT,
	GROSS_EXP_ADJUSTMENT_LATENB,
	GROSS_EXP_ADJUSTMENT_NEWCESSIONS,
	GROSS_EXP_ADJUSTMENT_PEINFTRUEUP,
	GROSS_EXP_ADJUSTMENT_POLICYCHANGES,
	GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB,
	GROSS_EXP_ADJUSTMENT_REINSTATEMENT,
	CEDED_ACTUAL_RELEASE_ON_DEATH,
	CEDED_ACTUAL_RELEASE_ON_LAPSE,
	CEDED_ACTUAL_RELEASE_ON_MISC_OFF,
	CEDED_ACTUAL_RELEASE_ON_MISC_ON,
	CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN,
	CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT,
	CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT,
	CEDED_EXPECTED_RELEASE_ON_DEATH,
	CEDED_EXPECTED_RELEASE_ON_LAPSE,
	CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT,
	CEDED_EXP_ADJUSTMENT_LATENB,
	CEDED_EXP_ADJUSTMENT_NEWCESSIONS,
	CEDED_EXP_ADJUSTMENT_PEINFTRUEUP,
	CEDED_EXP_ADJUSTMENT_POLICYCHANGES,
	CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB,
	CEDED_EXP_ADJUSTMENT_REINSTATEMENT
) as

SELECT
      SK_ID_FT_SOE_RESERVE_RELEASE
    , SK_ID_FT_COVERAGE                         AS SK_ID_FT_COVERAGE  	     
    , ID_DIM_EVALUATION_DATE
    , SK_ID_DIM_RESERVE_RELEASE_TYPE
    , SK_ID_DIM_RATE_TYPE
    , RL.SK_ID_DIM_COVERAGE
    , RL.SK_ID_DIM_COVERAGE_AXIS_MODULE
    , RL.POLICY_ID	
    , CASE WHEN ID_DIM_ISSUE_DATE = -1 THEN 19000101 ELSE ID_DIM_ISSUE_DATE END AS ID_DIM_ISSUE_DATE
    , CASE WHEN ID_DIM_DOD_DATE = -1 THEN 19000101 ELSE ID_DIM_DOD_DATE END AS ID_DIM_DOD_DATE
    , CASE WHEN ID_DIM_CLOSE_DATE = -1 THEN 19000101 ELSE ID_DIM_CLOSE_DATE END AS ID_DIM_CLOSE_DATE
    , SK_ID_DIM_PFT
    , SK_ID_DIM_SEX
    , SK_ID_ISSUE_AGE_GROUP
    , SK_ID_ATTEINED_AGE_GROUP
    , SK_ID_DIM_SMOKING_STATUS
    , SK_ID_DIM_DURATION_RANGE
    , SK_ID_DIM_VAT
    , SK_ID_DIM_COVERAGE_STATUS
    , SK_ID_DIM_RESIDENT_STATE
    , SK_ID_DIM_ISSUE_STATE
    , SK_ID_DIM_AGENT
    , SK_ID_DIM_AGENCY
    , SK_ID_DIM_TERMINATION_REASON
    , (FTC.SK_ID_ISSUE_AGE_GROUP * 1000) + FTC.ISSUE_AGE                AS ID_DIM_ISSUE_AGE
    , (FTC.SK_ID_ATTEINED_AGE_GROUP * 1000) + FTC.ATTEINED_AGE          AS ID_DIM_ATTEINTED_AGE
    , (FTC.SK_ID_DIM_DURATION_RANGE * 1000) + FTC.DURATION_IN_YEARS     AS ID_DIM_COVERAGE_DURATION
    , FTC.ISSUE_AGE                             AS ISSUE_AGE
    , FTC.ATTEINED_AGE                          AS ATTEINTED_AGE
    , FTC.DURATION_IN_YEARS                     AS DURATION_IN_YEARS			
    , AXIS_INCREMENT	
    , CODE_LIGNE_AFFAIRE	
    , GROSS_ACTUAL_RELEASE_ON_DEATH
    , GROSS_ACTUAL_RELEASE_ON_LAPSE
    , GROSS_ACTUAL_RELEASE_ON_MISC_OFF
    , GROSS_ACTUAL_RELEASE_ON_MISC_ON
    , GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN
    , GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT
    , GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT
    , GROSS_EXPECTED_RELEASE_ON_DEATH
    , GROSS_EXPECTED_RELEASE_ON_LAPSE
    , GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT
    , GROSS_EXP_ADJUSTMENT_LATENB
    , GROSS_EXP_ADJUSTMENT_NEWCESSIONS
    , GROSS_EXP_ADJUSTMENT_PEINFTRUEUP
    , GROSS_EXP_ADJUSTMENT_POLICYCHANGES
    , GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB
    , GROSS_EXP_ADJUSTMENT_REINSTATEMENT
    , CEDED_ACTUAL_RELEASE_ON_DEATH
    , CEDED_ACTUAL_RELEASE_ON_LAPSE
    , CEDED_ACTUAL_RELEASE_ON_MISC_OFF
    , CEDED_ACTUAL_RELEASE_ON_MISC_ON
    , CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN
    , CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT
    , CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT
    , CEDED_EXPECTED_RELEASE_ON_DEATH
    , CEDED_EXPECTED_RELEASE_ON_LAPSE
    , CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT
    , CEDED_EXP_ADJUSTMENT_LATENB
    , CEDED_EXP_ADJUSTMENT_NEWCESSIONS
    , CEDED_EXP_ADJUSTMENT_PEINFTRUEUP
    , CEDED_EXP_ADJUSTMENT_POLICYCHANGES
    , CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB
    , CEDED_EXP_ADJUSTMENT_REINSTATEMENT

FROM DM_US_VI.FT_SOE_RESERVE_RELEASE RL
INNER JOIN DM_US_VI.DIM_DATE D_DT 
        ON RL.ID_DIM_EVALUATION_DATE = D_DT.ID_DIM_DATE 

LEFT JOIN DM_US_VI.FT_COVERAGE FTC 
        ON RL.SK_ID_DIM_COVERAGE  = FTC.SK_ID_DIM_COVERAGE
        AND D_DT.DAY_SHORT_DATE BETWEEN FTC.MD_ACTIVATION_DT AND FTC.MD_OBSOLESCENCE_DT;
create or replace view VW_VI_FT_COVERAGE_INFO(
	SK_ID_FT_COVERAGE,
	SK_ID_DIM_COVERAGE,
	POLICY_ID,
	POLICY_NO,
	COMPANY_CODE,
	PHASE,
	SUB_PHASE,
	COVERAGE_TYPE_CODE,
	INTERNAL_COMPANY,
	IND_ASSUMED,
	DATE_OF_DEATH,
	CD_PAYMENT_MODE,
	CD_DEATH_BENEFIT_OPTION,
	CD_LINE_OF_BUSINESS,
	IND_COUVERTURE_TERMINEE,
	CD_PARTICIPATION_CODE,
	CD_JOINT_TYPE,
	CD_SUSPENSION,
	CD_TAX_QUALIFIED_STATUS
) as

SELECT
      SK_ID_FT_COVERAGE					AS SK_ID_FT_COVERAGE
    , FT.SK_ID_DIM_COVERAGE				AS SK_ID_DIM_COVERAGE
    , COV.POLICY_ID						AS POLICY_ID
    , COV.POLICY_NO						AS POLICY_NO
    , COV.COMPANY_CODE					AS COMPANY_CODE
    , COV.PHASE							AS PHASE
    , COV.SUB_PHASE						AS SUB_PHASE
    , COV.COVERAGE_TYPE_CODE			AS COVERAGE_TYPE_CODE
    , COV.INTERNAL_COMPANY				AS INTERNAL_COMPANY
    , COV.IND_ASSUMED					AS IND_ASSUMED
    , DT.DAY_SHORT_DATE                 AS DATE_OF_DEATH
    , CD_PAYMENT_MODE					AS CD_PAYMENT_MODE
    , CD_DEATH_BENEFIT_OPTION			AS CD_DEATH_BENEFIT_OPTION
    , CD_LINE_OF_BUSINESS				AS CD_LINE_OF_BUSINESS
    , IND_COUVERTURE_TERMINEE			AS IND_COUVERTURE_TERMINEE
    , CD_PARTICIPATION_CODE				AS CD_PARTICIPATION_CODE
    , CD_JOINT_TYPE						AS CD_JOINT_TYPE
    , CD_SUSPENSION						AS CD_SUSPENSION
    , CD_TAX_QUALIFIED_STATUS			AS CD_TAX_QUALIFIED_STATUS

FROM DM_US_VI.FT_COVERAGE FT

INNER JOIN DM_US_VI.DIM_COVERAGE COV
        ON FT.SK_ID_DIM_COVERAGE = COV.SK_ID_DIM_COVERAGE
        
LEFT JOIN DM_US_VI.DIM_DATE DT
        ON FT.ID_DIM_DOD_DATE = DT.ID_DIM_DATE;
create or replace view VW_VI_FT_COVERAGE_MEASURES(
	SK_ID_FT_COVERAGE,
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_COVERAGE,
	ID_DIM_ISSUE_DATE,
	ID_DIM_CLOSE_DATE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	SK_ID_DIM_PFT,
	SK_ID_DIM_SEX,
	SK_ID_ISSUE_AGE_GROUP,
	SK_ID_ATTEINED_AGE_GROUP,
	SK_ID_DIM_SMOKING_STATUS,
	SK_ID_DIM_DURATION_RANGE,
	SK_ID_DIM_VAT,
	SK_ID_DIM_COVERAGE_STATUS,
	SK_ID_DIM_RESIDENT_STATE,
	SK_ID_DIM_ISSUE_STATE,
	SK_ID_DIM_AGENT,
	SK_ID_DIM_AGENCY,
	SK_ID_DIM_TERMINATION_REASON,
	ID_DIM_ISSUE_AGE,
	ID_DIM_ATTEINTED_AGE,
	ID_DIM_COVERAGE_DURATION,
	ISSUE_AGE,
	ATTEINED_AGE,
	DURATION_IN_YEARS,
	AMT_CURRENT_DEATH_BENEFIT,
	AMT_CURRENT_FACE_AMOUNT,
	AMT_ORIGINAL_FACE_AMOUNT,
	AMT_CURRENT_BENEFIT_VALUE,
	ANT_CURRENT_CASH_VALUE,
	AMT_PREVIOUS_CASH_VALUE
) as

SELECT
      SK_ID_FT_COVERAGE
    , EDT.ID_DIM_EVALUATION_DATE  
    , SK_ID_DIM_COVERAGE
    , ID_DIM_ISSUE_DATE
    , ID_DIM_CLOSE_DATE 
    , SK_ID_DIM_COVERAGE_AXIS_MODULE
    , SK_ID_DIM_PFT
    , SK_ID_DIM_SEX
    , SK_ID_ISSUE_AGE_GROUP
    , SK_ID_ATTEINED_AGE_GROUP
    , SK_ID_DIM_SMOKING_STATUS
    , SK_ID_DIM_DURATION_RANGE
    , SK_ID_DIM_VAT
    , SK_ID_DIM_COVERAGE_STATUS
    , SK_ID_DIM_RESIDENT_STATE
    , SK_ID_DIM_ISSUE_STATE
    , SK_ID_DIM_AGENT
    , SK_ID_DIM_AGENCY
    , SK_ID_DIM_TERMINATION_REASON
    , (FT.SK_ID_ISSUE_AGE_GROUP * 1000) + FT.ISSUE_AGE                AS ID_DIM_ISSUE_AGE
    , (FT.SK_ID_ATTEINED_AGE_GROUP * 1000) + FT.ATTEINED_AGE          AS ID_DIM_ATTEINTED_AGE
    , (FT.SK_ID_DIM_DURATION_RANGE * 1000) + FT.DURATION_IN_YEARS     AS ID_DIM_COVERAGE_DURATION        
    , ISSUE_AGE
    , ATTEINED_AGE
    , DURATION_IN_YEARS
    , AMT_CURRENT_DEATH_BENEFIT
    , AMT_CURRENT_FACE_AMOUNT
    , AMT_ORIGINAL_FACE_AMOUNT
    , AMT_CURRENT_BENEFIT_VALUE
    , ANT_CURRENT_CASH_VALUE
    , AMT_PREVIOUS_CASH_VALUE

FROM DM_US_VI_PUBLICATION.VW_DIM_EVALUATION_DATE EDT
INNER JOIN DM_US_VI.FT_COVERAGE FT
        ON EDT."Date du jour" BETWEEN FT.MD_ACTIVATION_DT AND FT.MD_OBSOLESCENCE_DT;
create or replace schema DM_US_VI_TRAVAIL;

create or replace TABLE VW_DIM_GROUP_CSM (
	NOM_GROUP_CSM VARCHAR(100),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50)
);
create or replace TABLE VW_US_VI_FT_COVERAGE (
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	ID_DIM_ISSUE_DATE NUMBER(8,0),
	ID_DIM_DOD_DATE NUMBER(8,0),
	ID_DIM_CLOSE_DATE NUMBER(8,0),
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0),
	SK_ID_DIM_PFT NUMBER(20,0),
	SK_ID_DIM_SEX NUMBER(20,0),
	SK_ID_DIM_ISSUE_AGE_GROUP NUMBER(4,0),
	SK_ID_DIM_ATTEINED_AGE_GROUP NUMBER(4,0),
	SK_ID_DIM_SMOKING_STATUS NUMBER(20,0),
	SK_ID_DIM_DURATION_RANGE NUMBER(4,0),
	SK_ID_DIM_VAT NUMBER(20,0),
	SK_ID_DIM_COVERAGE_STATUS NUMBER(20,0),
	SK_ID_DIM_ISSUE_STATE NUMBER(20,0),
	SK_ID_DIM_RESIDENT_STATE NUMBER(20,0),
	SK_ID_DIM_AGENT NUMBER(20,0),
	SK_ID_DIM_AGENCY NUMBER(20,0),
	SK_ID_DIM_TERMINATION_REASON NUMBER(20,0),
	POLICY_ID VARCHAR(41),
	AXIS_PLAN_CODE VARCHAR(50),
	ISSUE_AGE NUMBER(3,0),
	ATTEINED_AGE NUMBER(17,0),
	DURATION_IN_YEARS NUMBER(16,0),
	AMT_CURRENT_DEATH_BENEFIT NUMBER(28,10),
	AMT_CURRENT_FACE_AMOUNT NUMBER(28,10),
	AMT_ORIGINAL_FACE_AMOUNT NUMBER(28,10),
	AMT_CURRENT_BENEFIT_VALUE NUMBER(28,10),
	ANT_CURRENT_CASH_VALUE NUMBER(28,10),
	AMT_PREVIOUS_CASH_VALUE NUMBER(28,10),
	CD_PAYMENT_MODE VARCHAR(2),
	CD_DEATH_BENEFIT_OPTION VARCHAR(1),
	CD_LINE_OF_BUSINESS VARCHAR(2),
	IND_COUVERTURE_TERMINEE NUMBER(1,0),
	CD_PARTICIPATION_CODE VARCHAR(1),
	CD_JOINT_TYPE VARCHAR(2),
	CD_SUSPENSION VARCHAR(1),
	CD_TAX_QUALIFIED_STATUS VARCHAR(2),
	MD_HASH_NAT_KEY VARCHAR(50),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_START_DT TIMESTAMP_LTZ(9)
);
create or replace TABLE VW_US_VI_FT_COVERAGE_GROUP_CSM (
	ID_DIM_DATE_ASSIGNATION NUMBER(8,0),
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	SK_ID_DIM_GROUP_CSM NUMBER(20,0),
	POLICY_NO VARCHAR(30),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(500)
);
create or replace TABLE VW_US_VI_FT_COVERAGE_OLD (
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	ID_DIM_ISSUE_DATE NUMBER(8,0),
	ID_DIM_DOD_DATE NUMBER(8,0),
	ID_DIM_CLOSE_DATE NUMBER(8,0),
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0),
	SK_ID_DIM_PFT NUMBER(20,0),
	SK_ID_DIM_SEX NUMBER(20,0),
	SK_ID_DIM_ISSUE_AGE_GROUP NUMBER(4,0),
	SK_ID_DIM_ATTEINED_AGE_GROUP NUMBER(4,0),
	SK_ID_DIM_SMOKING_STATUS NUMBER(20,0),
	SK_ID_DIM_DURATION_RANGE NUMBER(4,0),
	SK_ID_DIM_VAT NUMBER(20,0),
	SK_ID_DIM_COVERAGE_STATUS NUMBER(20,0),
	SK_ID_DIM_ISSUE_STATE NUMBER(20,0),
	SK_ID_DIM_RESIDENT_STATE NUMBER(20,0),
	SK_ID_DIM_AGENT NUMBER(20,0),
	SK_ID_DIM_AGENCY NUMBER(20,0),
	SK_ID_DIM_TERMINATION_REASON NUMBER(20,0),
	POLICY_ID VARCHAR(41),
	AXIS_PLAN_CODE VARCHAR(50),
	ISSUE_AGE NUMBER(3,0),
	ATTEINED_AGE NUMBER(17,0),
	DURATION_IN_YEARS NUMBER(16,0),
	AMT_CURRENT_DEATH_BENEFIT NUMBER(28,10),
	AMT_CURRENT_FACE_AMOUNT NUMBER(28,10),
	AMT_ORIGINAL_FACE_AMOUNT NUMBER(28,10),
	AMT_CURRENT_BENEFIT_VALUE NUMBER(28,10),
	ANT_CURRENT_CASH_VALUE NUMBER(28,10),
	AMT_PREVIOUS_CASH_VALUE NUMBER(28,10),
	CD_PAYMENT_MODE VARCHAR(2),
	CD_DEATH_BENEFIT_OPTION VARCHAR(1),
	CD_LINE_OF_BUSINESS VARCHAR(2),
	IND_COUVERTURE_TERMINEE NUMBER(1,0),
	CD_PARTICIPATION_CODE VARCHAR(1),
	CD_JOINT_TYPE VARCHAR(2),
	CD_SUSPENSION VARCHAR(1),
	CD_TAX_QUALIFIED_STATUS VARCHAR(2),
	MD_HASH_NAT_KEY VARCHAR(50),
	MD_HASHDIFF_TYPE_1 NUMBER(1,0),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_START_DT TIMESTAMP_LTZ(9)
);
create or replace TABLE VW_US_VI_FT_COVERAGE_REASSURANCE_GROUP_CSM (
	ID_DIM_DATE_ASSIGNATION NUMBER(8,0),
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	SK_ID_DIM_REASSUREUR NUMBER(20,0),
	SK_ID_DIM_GROUP_CSM_REASSURANCE NUMBER(20,0),
	SK_ID_DIM_GROUP_CSM_DIRECT NUMBER(20,0),
	POLICY_NO VARCHAR(30),
	COMPANY_CODE VARCHAR(3),
	REINSURANCE_COMPANY VARCHAR(30),
	REINSURANCE_CONTRACT VARCHAR(30),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY TIMESTAMP_LTZ(9),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50)
);
create or replace TABLE VW_US_VI_FT_GL_BALANCE (
	ID_DIM_ACCOUNTING_PERIOD_DATE NUMBER(8,0),
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0),
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	SK_ID_DIM_GL_CHART NUMBER(20,0),
	POLICY_ID VARCHAR(30),
	IND_ICOS VARCHAR(1),
	CD_ORIGINE VARCHAR(2),
	CD_SYSTEME_SOURCE VARCHAR(20),
	DISAGG_BALANCE_AMT NUMBER(28,10),
	BENEFIT_PAID_CURRENT_AMT NUMBER(28,10),
	INVEST_COMP_PAID_CURRENT_AMT NUMBER(28,10),
	SK_ID_DIM_MASTER_COA NUMBER(20,0),
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(40),
	MD_HASHDIFF_TYPE_2 VARCHAR(40),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_SOURCE_PROCESS_NAME VARCHAR(50),
	MD_ROW_IS_VALID NUMBER(3,0)
);
create or replace TABLE VW_US_VI_FT_GL_BALANCE_AGGREGATED (
	ID_DIM_ACCOUNTING_PERIOD_DATE NUMBER(8,0),
	SK_ID_DIM_GL_CHART NUMBER(20,0),
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	UDC VARCHAR(30),
	CD_ORIGINE VARCHAR(2),
	CD_SYSTEME_SOURCE VARCHAR(20),
	AGG_BALANCE_AMT NUMBER(28,10),
	SK_ID_DIM_MASTER_COA NUMBER(20,0),
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(40),
	MD_HASHDIFF_TYPE_2 VARCHAR(40),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_ROW_IS_NOT_VALID NUMBER(3,0)
);
create or replace TABLE VW_US_VI_GL_CHART (
	CD_ENTITY VARCHAR(4),
	CD_NATURE VARCHAR(4),
	CD_ORIGIN VARCHAR(4),
	CD_PERIODICITY VARCHAR(4),
	CD_COST_CENTER VARCHAR(4),
	CD_INTERCO VARCHAR(4),
	CD_LINE_OF_BUSINESS VARCHAR(4),
	CD_PRODUCT VARCHAR(4),
	CD_PARTICIPATION VARCHAR(4),
	CD_GEOGRAPHY VARCHAR(4),
	CD_PROJECT VARCHAR(4),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(40),
	MD_HASHDIFF_TYPE_2 VARCHAR(40)
);
create or replace TABLE VW_US_VI_MASTER_COA (
	VARIABLE_CSM VARCHAR(300),
	CUSTOM_DIM_1 VARCHAR(100),
	CUSTOM_DIM_2 VARCHAR(100),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(40)
);
create or replace TABLE VW_US_VI_SOLDE_EXTRAIT_CSM (
	ID_DIM_ACCOUNTING_PERIOD_DATE NUMBER(38,0),
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0),
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	SK_ID_DIM_GL_CHART NUMBER(20,0),
	POLICY_ID VARCHAR(30),
	IND_ICOS VARCHAR(1),
	CD_ORIGINE VARCHAR(2),
	CD_SYSTEME_SOURCE VARCHAR(50),
	DISAGG_BALANCE_AMT NUMBER(38,10),
	BENEFIT_PAID_CURRENT_AMT VARCHAR(1),
	INVEST_COMP_PAID_CURRENT_AMT VARCHAR(1),
	SK_ID_DIM_MASTER_COA NUMBER(20,0),
	MD_HASH_NAT_KEY VARCHAR(1),
	MD_HASHDIFF_TYPE_1 VARCHAR(1),
	MD_HASHDIFF_TYPE_2 VARCHAR(1),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE_PROCESS_NAME VARCHAR(18),
	MD_ROW_IS_VALID NUMBER(1,0)
);
create or replace TABLE VW_US_VI_SOLDE_EXTRAIT_CSM_OLD (
	ID_DIM_ACCOUNTING_PERIOD_DATE NUMBER(38,0),
	SK_ID_DIM_COVERAGE_AXIS_MODULE NUMBER(20,0),
	SK_ID_DIM_COVERAGE NUMBER(20,0),
	SK_ID_DIM_GL_CHART NUMBER(20,0),
	POLICY_ID VARCHAR(30),
	IND_ICOS VARCHAR(1),
	CD_ORIGINE VARCHAR(2),
	CD_SYSTEME_SOURCE VARCHAR(50),
	DISAGG_BALANCE_AMT NUMBER(38,10),
	BENEFIT_PAID_CURRENT_AMT VARCHAR(1),
	INVEST_COMP_PAID_CURRENT_AMT VARCHAR(1),
	SK_ID_DIM_MASTER_COA NUMBER(20,0),
	MD_HASH_NAT_KEY VARCHAR(1),
	MD_HASHDIFF_TYPE_1 VARCHAR(1),
	MD_HASHDIFF_TYPE_2 VARCHAR(1),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE_PROCESS_NAME VARCHAR(18),
	MD_ROW_IS_VALID NUMBER(1,0)
);
create or replace TABLE VW_VI_MASTER_COA (
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50),
	VARIABLE_CSM VARCHAR(300),
	CUSTOM_DIM_1 VARCHAR(100),
	CUSTOM_DIM_2 VARCHAR(100),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(100),
	MD_IS_ACTIVE BOOLEAN
);
create or replace view VW_DIM_REASSUREUR(
	REINSURANCE_COMPANY,
	REINSURANCE_CONTRACT,
	MD_ACTIVATION_DT,
	MD_OBSOLESCENCE_DT,
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2
) as

SELECT DISTINCT
         REINSURANCE_COMPANY                AS REINSURANCE_COMPANY
        ,REINSURANCE_CONTRACT                AS REINSURANCE_CONTRACT
        ,TO_TIMESTAMP_LTZ('1900-01-01')     AS MD_ACTIVATION_DT
        ,TO_TIMESTAMP_LTZ('2999-12-31')     AS MD_OBSOLESCENCE_DT
        ,SHA1 ( REINSURANCE_COMPANY || '||' || REINSURANCE_CONTRACT)       AS MD_HASH_NAT_KEY
        ,SHA1 ( REINSURANCE_COMPANY || '||' || REINSURANCE_CONTRACT )       AS MD_HASHDIFF_TYPE_1
        ,'0'                                        AS MD_HASHDIFF_TYPE_2

FROM    DB_ACT_DEV_STG.MODEL_US_VI.VW_US_VI_COVERAGE_REASSURANCE_GROUP_CSM
WHERE REINSURANCE_COMPANY IS NOT NULL AND REINSURANCE_CONTRACT IS NOT NULL;
create or replace view VW_US_VI_FT_CASHFLOW(
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_RESERVE_RELEASE_TYPE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	SK_ID_DIM_COVERAGE,
	POLICY_ID,
	POLICY_ID_EX,
	AXIS_INCREMENT,
	CODE_LIGNE_AFFAIRE,
	CEDED_ACTUAL_CASHFLOW_COMMISSION,
	CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS,
	CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT,
	CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS,
	CEDED_ACTUAL_CASHFLOW_EXPENSE,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT,
	CEDED_ACTUAL_CASHFLOW_MISCOFF,
	CEDED_ACTUAL_CASHFLOW_MISCON,
	CEDED_ACTUAL_CASHFLOW_NOTTAKENUP,
	CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT,
	CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID,
	CEDED_ACTUAL_CASHFLOW_PREMIUM,
	CEDED_ACTUAL_CASHFLOW_PREMIUMTAX,
	CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE,
	CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN,
	CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS,
	CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT,
	CEDED_EXPECTED_CASHFLOW_COMMISSION,
	CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS,
	CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT,
	CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS,
	CEDED_EXPECTED_CASHFLOW_EXPENSE,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT,
	CEDED_EXPECTED_CASHFLOW_MISCOFF,
	CEDED_EXPECTED_CASHFLOW_MISCON,
	CEDED_EXPECTED_CASHFLOW_NOTTAKENUP,
	CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT,
	CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID,
	CEDED_EXPECTED_CASHFLOW_PREMIUM,
	CEDED_EXPECTED_CASHFLOW_PREMIUMTAX,
	CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE,
	CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN,
	CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS,
	CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT,
	CEDED_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD,
	GROSS_ACTUAL_CASHFLOW_COMMISSION,
	GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS,
	GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT,
	GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS,
	GROSS_ACTUAL_CASHFLOW_EXPENSE,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT,
	GROSS_ACTUAL_CASHFLOW_MISCOFF,
	GROSS_ACTUAL_CASHFLOW_MISCON,
	GROSS_ACTUAL_CASHFLOW_NOTTAKENUP,
	GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT,
	GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID,
	GROSS_ACTUAL_CASHFLOW_PREMIUM,
	GROSS_ACTUAL_CASHFLOW_PREMIUMTAX,
	GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE,
	GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN,
	GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS,
	GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT,
	GROSS_ACTUAL_CASHFLOW_PAYOUT,
	GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS,
	GROSS_EXPECTED_CASHFLOW_COMMISSION,
	GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT,
	GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS,
	GROSS_EXPECTED_CASHFLOW_EXPENSE,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT,
	GROSS_EXPECTED_CASHFLOW_MISCOFF,
	GROSS_EXPECTED_CASHFLOW_MISCON,
	GROSS_EXPECTED_CASHFLOW_NOTTAKENUP,
	GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT,
	GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID,
	GROSS_EXPECTED_CASHFLOW_PREMIUM,
	GROSS_EXPECTED_CASHFLOW_PREMIUMTAX,
	GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE,
	GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN,
	GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS,
	GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT,
	GROSS_EXPECTED_CASHFLOW_PAYOUT,
	GROSS_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD,
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2,
	MD_START_DT,
	MD_ROW_IS_VALID
) as

SELECT  
          TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT       AS ID_DIM_EVALUATION_DATE
        , NVL(D_TYPE.SK_ID_DIM_RESERVE_RELEASE_TYPE,-2)     AS SK_ID_DIM_RESERVE_RELEASE_TYPE
        , NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1)  AS SK_ID_DIM_COVERAGE_AXIS_MODULE
        , NVL(D_COV.SK_ID_DIM_COVERAGE,-1)                  AS SK_ID_DIM_COVERAGE
        , F.POLICY_ID                                       AS POLICY_ID
        , F.POLICY_ID_EX                                    AS POLICY_ID_EX
        , AXIS_INCREMENT                                    AS AXIS_INCREMENT
        , CODE_LIGNE_AFFAIRE                                AS CODE_LIGNE_AFFAIRE
        , CEDED_ACTUAL_CASHFLOW_COMMISSION                  AS CEDED_ACTUAL_CASHFLOW_COMMISSION
        , CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS             AS CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS
        , CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT                AS CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT
        , CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS        AS CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS
        , CEDED_ACTUAL_CASHFLOW_EXPENSE                     AS CEDED_ACTUAL_CASHFLOW_EXPENSE
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH            AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE            AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF          AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON           AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS           AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP       AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN         AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT    AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT
        , CEDED_ACTUAL_CASHFLOW_MISCOFF                     AS CEDED_ACTUAL_CASHFLOW_MISCOFF
        , CEDED_ACTUAL_CASHFLOW_MISCON                      AS CEDED_ACTUAL_CASHFLOW_MISCON
        , CEDED_ACTUAL_CASHFLOW_NOTTAKENUP                  AS CEDED_ACTUAL_CASHFLOW_NOTTAKENUP
        , CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT                AS CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT
        , CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID              AS CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID
        , CEDED_ACTUAL_CASHFLOW_PREMIUM                     AS CEDED_ACTUAL_CASHFLOW_PREMIUM
        , CEDED_ACTUAL_CASHFLOW_PREMIUMTAX                  AS CEDED_ACTUAL_CASHFLOW_PREMIUMTAX
        , CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE             AS CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE
        , CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN           AS CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN
        , CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS            AS CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS
        , CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT            AS CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT
        , CEDED_EXPECTED_CASHFLOW_COMMISSION                AS CEDED_EXPECTED_CASHFLOW_COMMISSION
        , CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS           AS CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS
        , CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT              AS CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT
        , CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS      AS CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS
        , CEDED_EXPECTED_CASHFLOW_EXPENSE                   AS CEDED_EXPECTED_CASHFLOW_EXPENSE
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH          AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE          AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF        AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON         AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS         AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP     AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN       AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT  AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT
        , CEDED_EXPECTED_CASHFLOW_MISCOFF                   AS CEDED_EXPECTED_CASHFLOW_MISCOFF
        , CEDED_EXPECTED_CASHFLOW_MISCON                    AS CEDED_EXPECTED_CASHFLOW_MISCON
        , CEDED_EXPECTED_CASHFLOW_NOTTAKENUP                AS CEDED_EXPECTED_CASHFLOW_NOTTAKENUP
        , CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT              AS CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT
        , CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID            AS CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID
        , CEDED_EXPECTED_CASHFLOW_PREMIUM                   AS CEDED_EXPECTED_CASHFLOW_PREMIUM
        , CEDED_EXPECTED_CASHFLOW_PREMIUMTAX                AS CEDED_EXPECTED_CASHFLOW_PREMIUMTAX
        , CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE           AS CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE
        , CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN         AS CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN
        , CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS          AS CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS
        , CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT          AS CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT
        , CEDED_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD          AS CEDED_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD
        , GROSS_ACTUAL_CASHFLOW_COMMISSION                  AS GROSS_ACTUAL_CASHFLOW_COMMISSION
        , GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS             AS GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS
        , GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT                AS GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT
        , GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS        AS GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS
        , GROSS_ACTUAL_CASHFLOW_EXPENSE                     AS GROSS_ACTUAL_CASHFLOW_EXPENSE
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH            AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE            AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF          AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON           AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS           AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP       AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN         AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT    AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT
        , GROSS_ACTUAL_CASHFLOW_MISCOFF                     AS GROSS_ACTUAL_CASHFLOW_MISCOFF
        , GROSS_ACTUAL_CASHFLOW_MISCON                      AS GROSS_ACTUAL_CASHFLOW_MISCON
        , GROSS_ACTUAL_CASHFLOW_NOTTAKENUP                  AS GROSS_ACTUAL_CASHFLOW_NOTTAKENUP
        , GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT                AS GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT
        , GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID              AS GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID
        , GROSS_ACTUAL_CASHFLOW_PREMIUM                     AS GROSS_ACTUAL_CASHFLOW_PREMIUM
        , GROSS_ACTUAL_CASHFLOW_PREMIUMTAX                  AS GROSS_ACTUAL_CASHFLOW_PREMIUMTAX
        , GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE             AS GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE
        , GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN           AS GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN
        , GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS            AS GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS
        , GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT            AS GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT
        , GROSS_ACTUAL_CASHFLOW_PAYOUT                      AS GROSS_ACTUAL_CASHFLOW_PAYOUT
        , GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS           AS GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS
        , GROSS_EXPECTED_CASHFLOW_COMMISSION                AS GROSS_EXPECTED_CASHFLOW_COMMISSION
        , GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT              AS GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT
        , GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS      AS GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS
        , GROSS_EXPECTED_CASHFLOW_EXPENSE                   AS GROSS_EXPECTED_CASHFLOW_EXPENSE
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH          AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE          AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF        AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON         AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS         AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP     AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN       AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT  AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT
        , GROSS_EXPECTED_CASHFLOW_MISCOFF                   AS GROSS_EXPECTED_CASHFLOW_MISCOFF
        , GROSS_EXPECTED_CASHFLOW_MISCON                    AS GROSS_EXPECTED_CASHFLOW_MISCON
        , GROSS_EXPECTED_CASHFLOW_NOTTAKENUP                AS GROSS_EXPECTED_CASHFLOW_NOTTAKENUP
        , GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT              AS GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT
        , GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID            AS GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID
        , GROSS_EXPECTED_CASHFLOW_PREMIUM                   AS GROSS_EXPECTED_CASHFLOW_PREMIUM
        , GROSS_EXPECTED_CASHFLOW_PREMIUMTAX                AS GROSS_EXPECTED_CASHFLOW_PREMIUMTAX
        , GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE           AS GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE
        , GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN         AS GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN
        , GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS          AS GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS
        , GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT          AS GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT
        , GROSS_EXPECTED_CASHFLOW_PAYOUT                    AS GROSS_EXPECTED_CASHFLOW_PAYOUT
        , GROSS_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD          AS GROSS_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD
        , '0'                                               AS MD_HASH_NAT_KEY
        , '0'                                               AS MD_HASHDIFF_TYPE_1
        , '0'                                               AS MD_HASHDIFF_TYPE_2
        , EVALUATION_DT                                     AS MD_START_DT
		, CASE WHEN TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT = 19000101 OR D_TYPE.SK_ID_DIM_RESERVE_RELEASE_TYPE < 0
                    OR D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE <0 OR D_COV.SK_ID_DIM_COVERAGE < 0 THEN 0 ELSE 1 END AS MD_ROW_IS_VALID

FROM        DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_SOE_CASHFLOW AS F

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RESERVE_RELEASE_TYPE D_TYPE
        ON D_TYPE.RESERVE_RELEASE_TYPE = 'BEL'

INNER JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE D_COV_MOD
        ON  F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE D_COV
        ON  F.POLICY_NO = D_COV.POLICY_NO
        AND F.PHASE     = D_COV.PHASE
        AND F.SUB_PHASE = D_COV.SUB_PHASE
        AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
        AND ((D_COV.COMPANY_CODE = '060' AND D_COV.IND_ASSUMED = 'N') OR (D_COV.COMPANY_CODE <> '060'))
        AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
        AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

WHERE (F.AXIS_INCREMENT = '0' )

UNION ALL

SELECT  
          TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT       AS ID_DIM_EVALUATION_DATE
        , NVL(D_TYPE.SK_ID_DIM_RESERVE_RELEASE_TYPE,-2)     AS SK_ID_DIM_RESERVE_RELEASE_TYPE
        , NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1)  AS SK_ID_DIM_COVERAGE_AXIS_MODULE
        , NVL(D_COV.SK_ID_DIM_COVERAGE,-1)                  AS SK_ID_DIM_COVERAGE
        , F.POLICY_ID                                       AS POLICY_ID
        , F.POLICY_ID_EX                                    AS POLICY_ID_EX
        , AXIS_INCREMENT                                    AS AXIS_INCREMENT
        , CODE_LIGNE_AFFAIRE                                AS CODE_LIGNE_AFFAIRE
        , CEDED_ACTUAL_CASHFLOW_COMMISSION                  AS CEDED_ACTUAL_CASHFLOW_COMMISSION
        , CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS             AS CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS
        , CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT                AS CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT
        , CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS        AS CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS
        , CEDED_ACTUAL_CASHFLOW_EXPENSE                     AS CEDED_ACTUAL_CASHFLOW_EXPENSE
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH            AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE            AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF          AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON           AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS           AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP       AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN         AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT    AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT
        , CEDED_ACTUAL_CASHFLOW_MISCOFF                     AS CEDED_ACTUAL_CASHFLOW_MISCOFF
        , CEDED_ACTUAL_CASHFLOW_MISCON                      AS CEDED_ACTUAL_CASHFLOW_MISCON
        , CEDED_ACTUAL_CASHFLOW_NOTTAKENUP                  AS CEDED_ACTUAL_CASHFLOW_NOTTAKENUP
        , CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT                AS CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT
        , CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID              AS CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID
        , CEDED_ACTUAL_CASHFLOW_PREMIUM                     AS CEDED_ACTUAL_CASHFLOW_PREMIUM
        , CEDED_ACTUAL_CASHFLOW_PREMIUMTAX                  AS CEDED_ACTUAL_CASHFLOW_PREMIUMTAX
        , CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE             AS CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE
        , CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN           AS CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN
        , CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS            AS CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS
        , CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT            AS CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT
        , CEDED_EXPECTED_CASHFLOW_COMMISSION                AS CEDED_EXPECTED_CASHFLOW_COMMISSION
        , CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS           AS CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS
        , CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT              AS CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT
        , CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS      AS CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS
        , CEDED_EXPECTED_CASHFLOW_EXPENSE                   AS CEDED_EXPECTED_CASHFLOW_EXPENSE
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH          AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE          AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF        AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON         AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS         AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP     AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN       AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT  AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT
        , CEDED_EXPECTED_CASHFLOW_MISCOFF                   AS CEDED_EXPECTED_CASHFLOW_MISCOFF
        , CEDED_EXPECTED_CASHFLOW_MISCON                    AS CEDED_EXPECTED_CASHFLOW_MISCON
        , CEDED_EXPECTED_CASHFLOW_NOTTAKENUP                AS CEDED_EXPECTED_CASHFLOW_NOTTAKENUP
        , CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT              AS CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT
        , CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID            AS CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID
        , CEDED_EXPECTED_CASHFLOW_PREMIUM                   AS CEDED_EXPECTED_CASHFLOW_PREMIUM
        , CEDED_EXPECTED_CASHFLOW_PREMIUMTAX                AS CEDED_EXPECTED_CASHFLOW_PREMIUMTAX
        , CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE           AS CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE
        , CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN         AS CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN
        , CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS          AS CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS
        , CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT          AS CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT
        , CEDED_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD          AS CEDED_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD
        , GROSS_ACTUAL_CASHFLOW_COMMISSION                  AS GROSS_ACTUAL_CASHFLOW_COMMISSION
        , GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS             AS GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS
        , GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT                AS GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT
        , GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS        AS GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS
        , GROSS_ACTUAL_CASHFLOW_EXPENSE                     AS GROSS_ACTUAL_CASHFLOW_EXPENSE
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH            AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE            AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF          AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON           AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS           AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP       AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN         AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT    AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT
        , GROSS_ACTUAL_CASHFLOW_MISCOFF                     AS GROSS_ACTUAL_CASHFLOW_MISCOFF
        , GROSS_ACTUAL_CASHFLOW_MISCON                      AS GROSS_ACTUAL_CASHFLOW_MISCON
        , GROSS_ACTUAL_CASHFLOW_NOTTAKENUP                  AS GROSS_ACTUAL_CASHFLOW_NOTTAKENUP
        , GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT                AS GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT
        , GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID              AS GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID
        , GROSS_ACTUAL_CASHFLOW_PREMIUM                     AS GROSS_ACTUAL_CASHFLOW_PREMIUM
        , GROSS_ACTUAL_CASHFLOW_PREMIUMTAX                  AS GROSS_ACTUAL_CASHFLOW_PREMIUMTAX
        , GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE             AS GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE
        , GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN           AS GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN
        , GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS            AS GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS
        , GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT            AS GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT
        , GROSS_ACTUAL_CASHFLOW_PAYOUT                      AS GROSS_ACTUAL_CASHFLOW_PAYOUT
        , GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS           AS GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS
        , GROSS_EXPECTED_CASHFLOW_COMMISSION                AS GROSS_EXPECTED_CASHFLOW_COMMISSION
        , GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT              AS GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT
        , GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS      AS GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS
        , GROSS_EXPECTED_CASHFLOW_EXPENSE                   AS GROSS_EXPECTED_CASHFLOW_EXPENSE
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH          AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE          AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF        AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON         AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS         AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP     AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN       AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT  AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT
        , GROSS_EXPECTED_CASHFLOW_MISCOFF                   AS GROSS_EXPECTED_CASHFLOW_MISCOFF
        , GROSS_EXPECTED_CASHFLOW_MISCON                    AS GROSS_EXPECTED_CASHFLOW_MISCON
        , GROSS_EXPECTED_CASHFLOW_NOTTAKENUP                AS GROSS_EXPECTED_CASHFLOW_NOTTAKENUP
        , GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT              AS GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT
        , GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID            AS GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID
        , GROSS_EXPECTED_CASHFLOW_PREMIUM                   AS GROSS_EXPECTED_CASHFLOW_PREMIUM
        , GROSS_EXPECTED_CASHFLOW_PREMIUMTAX                AS GROSS_EXPECTED_CASHFLOW_PREMIUMTAX
        , GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE           AS GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE
        , GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN         AS GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN
        , GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS          AS GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS
        , GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT          AS GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT
        , GROSS_EXPECTED_CASHFLOW_PAYOUT                    AS GROSS_EXPECTED_CASHFLOW_PAYOUT
        , GROSS_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD          AS GROSS_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD
        , '0'                                               AS MD_HASH_NAT_KEY
        , '0'                                               AS MD_HASHDIFF_TYPE_1
        , '0'                                               AS MD_HASHDIFF_TYPE_2
        , EVALUATION_DT                                     AS MD_START_DT
		, CASE WHEN TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT = 19000101 OR D_TYPE.SK_ID_DIM_RESERVE_RELEASE_TYPE < 0
                    OR D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE <0 OR D_COV.SK_ID_DIM_COVERAGE < 0 THEN 0 ELSE 1 END AS MD_ROW_IS_VALID

FROM        DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_SOE_CASHFLOW AS F

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RESERVE_RELEASE_TYPE D_TYPE
        ON D_TYPE.RESERVE_RELEASE_TYPE = 'BEL'
        
INNER JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE D_COV_MOD
        ON  F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

INNER JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE D_COV
        ON  F.POLICY_NO = D_COV.POLICY_NO
        AND F.PHASE     = D_COV.PHASE
        AND F.SUB_PHASE = D_COV.SUB_PHASE
        AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
        AND D_COV.COMPANY_CODE = '060'
        AND D_COV.IND_ASSUMED = 'Y'
        AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
        AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

left JOIN  DB_ACT_DEV_DM.DM_US_VI.FT_COVERAGE FT_COV  -- inner
        ON  D_COV.SK_ID_DIM_COVERAGE = FT_COV.SK_ID_DIM_COVERAGE
        AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT

left JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_VAT D_VAT   -- inner
        ON  FT_COV.SK_ID_DIM_VAT = D_VAT.SK_ID_DIM_VAT
        AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT
        AND D_VAT.GROUPE = 'Horizon Life'

WHERE F.AXIS_INCREMENT = 'H'

UNION ALL

SELECT  
          TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT       AS ID_DIM_EVALUATION_DATE
        , NVL(D_TYPE.SK_ID_DIM_RESERVE_RELEASE_TYPE,-2)     AS SK_ID_DIM_RESERVE_RELEASE_TYPE
        , NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1)  AS SK_ID_DIM_COVERAGE_AXIS_MODULE
        , NVL(D_COV.SK_ID_DIM_COVERAGE,-1)                  AS SK_ID_DIM_COVERAGE
        , F.POLICY_ID                                       AS POLICY_ID
        , F.POLICY_ID_EX                                    AS POLICY_ID_EX
        , AXIS_INCREMENT                                    AS AXIS_INCREMENT
        , CODE_LIGNE_AFFAIRE                                AS CODE_LIGNE_AFFAIRE
        , CEDED_ACTUAL_CASHFLOW_COMMISSION                  AS CEDED_ACTUAL_CASHFLOW_COMMISSION
        , CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS             AS CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS
        , CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT                AS CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT
        , CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS        AS CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS
        , CEDED_ACTUAL_CASHFLOW_EXPENSE                     AS CEDED_ACTUAL_CASHFLOW_EXPENSE
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH            AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE            AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF          AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON           AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS           AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP       AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN         AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN
        , CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT    AS CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT
        , CEDED_ACTUAL_CASHFLOW_MISCOFF                     AS CEDED_ACTUAL_CASHFLOW_MISCOFF
        , CEDED_ACTUAL_CASHFLOW_MISCON                      AS CEDED_ACTUAL_CASHFLOW_MISCON
        , CEDED_ACTUAL_CASHFLOW_NOTTAKENUP                  AS CEDED_ACTUAL_CASHFLOW_NOTTAKENUP
        , CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT                AS CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT
        , CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID              AS CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID
        , CEDED_ACTUAL_CASHFLOW_PREMIUM                     AS CEDED_ACTUAL_CASHFLOW_PREMIUM
        , CEDED_ACTUAL_CASHFLOW_PREMIUMTAX                  AS CEDED_ACTUAL_CASHFLOW_PREMIUMTAX
        , CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE             AS CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE
        , CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN           AS CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN
        , CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS            AS CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS
        , CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT            AS CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT
        , CEDED_EXPECTED_CASHFLOW_COMMISSION                AS CEDED_EXPECTED_CASHFLOW_COMMISSION
        , CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS           AS CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS
        , CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT              AS CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT
        , CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS      AS CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS
        , CEDED_EXPECTED_CASHFLOW_EXPENSE                   AS CEDED_EXPECTED_CASHFLOW_EXPENSE
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH          AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE          AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF        AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON         AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS         AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP     AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN       AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN
        , CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT  AS CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT
        , CEDED_EXPECTED_CASHFLOW_MISCOFF                   AS CEDED_EXPECTED_CASHFLOW_MISCOFF
        , CEDED_EXPECTED_CASHFLOW_MISCON                    AS CEDED_EXPECTED_CASHFLOW_MISCON
        , CEDED_EXPECTED_CASHFLOW_NOTTAKENUP                AS CEDED_EXPECTED_CASHFLOW_NOTTAKENUP
        , CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT              AS CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT
        , CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID            AS CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID
        , CEDED_EXPECTED_CASHFLOW_PREMIUM                   AS CEDED_EXPECTED_CASHFLOW_PREMIUM
        , CEDED_EXPECTED_CASHFLOW_PREMIUMTAX                AS CEDED_EXPECTED_CASHFLOW_PREMIUMTAX
        , CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE           AS CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE
        , CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN         AS CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN
        , CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS          AS CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS
        , CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT          AS CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT
        , CEDED_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD          AS CEDED_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD
        , GROSS_ACTUAL_CASHFLOW_COMMISSION                  AS GROSS_ACTUAL_CASHFLOW_COMMISSION
        , GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS             AS GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS
        , GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT                AS GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT
        , GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS        AS GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS
        , GROSS_ACTUAL_CASHFLOW_EXPENSE                     AS GROSS_ACTUAL_CASHFLOW_EXPENSE
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH            AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE            AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF          AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON           AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS           AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP       AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN         AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN
        , GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT    AS GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT
        , GROSS_ACTUAL_CASHFLOW_MISCOFF                     AS GROSS_ACTUAL_CASHFLOW_MISCOFF
        , GROSS_ACTUAL_CASHFLOW_MISCON                      AS GROSS_ACTUAL_CASHFLOW_MISCON
        , GROSS_ACTUAL_CASHFLOW_NOTTAKENUP                  AS GROSS_ACTUAL_CASHFLOW_NOTTAKENUP
        , GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT                AS GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT
        , GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID              AS GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID
        , GROSS_ACTUAL_CASHFLOW_PREMIUM                     AS GROSS_ACTUAL_CASHFLOW_PREMIUM
        , GROSS_ACTUAL_CASHFLOW_PREMIUMTAX                  AS GROSS_ACTUAL_CASHFLOW_PREMIUMTAX
        , GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE             AS GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE
        , GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN           AS GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN
        , GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS            AS GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS
        , GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT            AS GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT
        , GROSS_ACTUAL_CASHFLOW_PAYOUT                      AS GROSS_ACTUAL_CASHFLOW_PAYOUT
        , GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS           AS GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS
        , GROSS_EXPECTED_CASHFLOW_COMMISSION                AS GROSS_EXPECTED_CASHFLOW_COMMISSION
        , GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT              AS GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT
        , GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS      AS GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS
        , GROSS_EXPECTED_CASHFLOW_EXPENSE                   AS GROSS_EXPECTED_CASHFLOW_EXPENSE
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH          AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE          AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF        AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON         AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS         AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP     AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN       AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN
        , GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT  AS GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT
        , GROSS_EXPECTED_CASHFLOW_MISCOFF                   AS GROSS_EXPECTED_CASHFLOW_MISCOFF
        , GROSS_EXPECTED_CASHFLOW_MISCON                    AS GROSS_EXPECTED_CASHFLOW_MISCON
        , GROSS_EXPECTED_CASHFLOW_NOTTAKENUP                AS GROSS_EXPECTED_CASHFLOW_NOTTAKENUP
        , GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT              AS GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT
        , GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID            AS GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID
        , GROSS_EXPECTED_CASHFLOW_PREMIUM                   AS GROSS_EXPECTED_CASHFLOW_PREMIUM
        , GROSS_EXPECTED_CASHFLOW_PREMIUMTAX                AS GROSS_EXPECTED_CASHFLOW_PREMIUMTAX
        , GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE           AS GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE
        , GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN         AS GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN
        , GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS          AS GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS
        , GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT          AS GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT
        , GROSS_EXPECTED_CASHFLOW_PAYOUT                    AS GROSS_EXPECTED_CASHFLOW_PAYOUT
        , GROSS_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD          AS GROSS_TOTAL_EXP_CLAIMS_IN_CURRENT_PERIOD
        , '0'                                               AS MD_HASH_NAT_KEY
        , '0'                                               AS MD_HASHDIFF_TYPE_1
        , '0'                                               AS MD_HASHDIFF_TYPE_2
        , EVALUATION_DT                                     AS MD_START_DT
		, CASE WHEN TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT = 19000101 OR D_TYPE.SK_ID_DIM_RESERVE_RELEASE_TYPE < 0
                    OR D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE <0 OR D_COV.SK_ID_DIM_COVERAGE < 0 THEN 0 ELSE 1 END AS MD_ROW_IS_VALID

FROM        DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_SOE_CASHFLOW AS F

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RESERVE_RELEASE_TYPE D_TYPE
        ON D_TYPE.RESERVE_RELEASE_TYPE = 'BEL'
        
INNER JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE D_COV_MOD
        ON  F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE D_COV
        ON  F.POLICY_NO = D_COV.POLICY_NO
        AND F.PHASE     = D_COV.PHASE
        AND F.SUB_PHASE = D_COV.SUB_PHASE
        AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
        AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
        AND D_COV.COMPANY_CODE = '060'
        AND D_COV.IND_ASSUMED = 'Y'
        AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.FT_COVERAGE FT_COV 
        ON  D_COV.SK_ID_DIM_COVERAGE = FT_COV.SK_ID_DIM_COVERAGE
        AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT
        
LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_VAT D_VAT
        ON  FT_COV.SK_ID_DIM_VAT = D_VAT.SK_ID_DIM_VAT
        AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT
        AND D_VAT.GROUPE <> 'Horizon Life'

WHERE F.AXIS_INCREMENT = 'T';
create or replace view VW_US_VI_FT_COVERAGE_ORIG(
	SK_ID_DIM_COVERAGE,
	ID_DIM_ISSUE_DATE,
	ID_DIM_DOD_DATE,
	ID_DIM_CLOSE_DATE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	SK_ID_DIM_PFT,
	SK_ID_DIM_SEX,
	SK_ID_DIM_ISSUE_AGE_GROUP,
	SK_ID_DIM_ATTEINED_AGE_GROUP,
	SK_ID_DIM_SMOKING_STATUS,
	SK_ID_DIM_DURATION_RANGE,
	SK_ID_DIM_VAT,
	SK_ID_DIM_COVERAGE_STATUS,
	SK_ID_DIM_ISSUE_STATE,
	SK_ID_DIM_RESIDENT_STATE,
	SK_ID_DIM_AGENT,
	SK_ID_DIM_AGENCY,
	SK_ID_DIM_TERMINATION_REASON,
	POLICY_ID,
	AXIS_PLAN_CODE,
	ISSUE_AGE,
	ATTEINED_AGE,
	DURATION_IN_YEARS,
	AMT_CURRENT_DEATH_BENEFIT,
	AMT_CURRENT_FACE_AMOUNT,
	AMT_ORIGINAL_FACE_AMOUNT,
	AMT_CURRENT_BENEFIT_VALUE,
	ANT_CURRENT_CASH_VALUE,
	AMT_PREVIOUS_CASH_VALUE,
	CD_PAYMENT_MODE,
	CD_DEATH_BENEFIT_OPTION,
	CD_LINE_OF_BUSINESS,
	IND_COUVERTURE_TERMINEE,
	CD_PARTICIPATION_CODE,
	CD_JOINT_TYPE,
	CD_SUSPENSION,
	CD_TAX_QUALIFIED_STATUS,
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2,
	MD_START_DT
) as

SELECT DISTINCT 
      NVL(D_COV.SK_ID_DIM_COVERAGE, -1)                     AS SK_ID_DIM_COVERAGE
    , NVL(D_ISS_DT.ID_DIM_DATE,-1)                          AS ID_DIM_ISSUE_DATE
    , NVL(D_DOD_DT.ID_DIM_DATE,-1)                          AS ID_DIM_DOD_DATE 
    , NVL(D_CLOSE_DT.ID_DIM_DATE,-1)                        AS ID_DIM_CLOSE_DATE 
    , NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1)      AS SK_ID_DIM_COVERAGE_AXIS_MODULE
    , NVL(D_PFT.SK_ID_DIM_PFT,-1)                           AS SK_ID_DIM_PFT
    , NVL(D_SEX.SK_ID_DIM_SEX,-1)                           AS SK_ID_DIM_SEX
    , NVL(D_GRP_A_I.SK_ID_DIM_AGE_GROUP,-1)                 AS SK_ID_DIM_ISSUE_AGE_GROUP
    , NVL(D_GRP_A_A.SK_ID_DIM_AGE_GROUP,-1)                 AS SK_ID_DIM_ATTEINED_AGE_GROUP
    , NVL(D_SMK_S.SK_ID_DIM_SMOKING_STATUS,-1)              AS SK_ID_DIM_SMOKING_STATUS
    , NVL(D_DUR_R.SK_ID_DIM_DURATION_RANGE,-1)              AS SK_ID_DIM_DURATION_RANGE
    , NVL(D_VAT.SK_ID_DIM_VAT,-1)                           AS SK_ID_DIM_VAT
    , NVL(D_COV_ST.SK_ID_DIM_COVERAGE_STATUS,-1)            AS SK_ID_DIM_COVERAGE_STATUS
    , NVl(D_STATE_I.SK_ID_DIM_STATE,-1)                     AS SK_ID_DIM_ISSUE_STATE
    , NVL(D_STATE_R.SK_ID_DIM_STATE,-1)                     AS SK_ID_DIM_RESIDENT_STATE
    , NVL(D_AGN.SK_ID_DIM_AGENT,-1)                         AS SK_ID_DIM_AGENT
    , NVL(D_AGCY.SK_ID_DIM_AGENCY,-1)                       AS SK_ID_DIM_AGENCY
    , NVL(D_TERM_R.SK_ID_DIM_TERMINATION_REASON,-1)         AS SK_ID_DIM_TERMINATION_REASON
    , F.POLICY_ID                                           AS POLICY_ID
    , F.AXIS_PLAN_CODE                                      AS AXIS_PLAN_CODE
    , F.ISSUE_AGE                                           AS ISSUE_AGE
    , F.ATTEINED_AGE                                        AS ATTEINED_AGE
    , F.DURATION_IN_YEARS                                   AS DURATION_IN_YEARS
    , F.AMT_CURRENT_DEATH_BENEFIT                           AS AMT_CURRENT_DEATH_BENEFIT
    , F.AMT_CURRENT_FACE_AMOUNT                             AS AMT_CURRENT_FACE_AMOUNT
    , F.AMT_ORIGINAL_FACE_AMOUNT                            AS AMT_ORIGINAL_FACE_AMOUNT
    , F.AMT_CURRENT_BENEFIT_VALUE                           AS AMT_CURRENT_BENEFIT_VALUE
    , F.ANT_CURRENT_CASH_VALUE                              AS ANT_CURRENT_CASH_VALUE
    , F.AMT_PREVIOUS_CASH_VALUE                             AS AMT_PREVIOUS_CASH_VALUE
    , F.CD_PAYMENT_MODE                                     AS CD_PAYMENT_MODE
    , F.CD_DEATH_BENEFIT_OPTION                             AS CD_DEATH_BENEFIT_OPTION
    , F.CD_LINE_OF_BUSINESS                                 AS CD_LINE_OF_BUSINESS
    , F.IND_COUVERTURE_TERMINEE                             AS IND_COUVERTURE_TERMINEE
    , F.CD_PARTICIPATION_CODE                               AS CD_PARTICIPATION_CODE
    , F.CD_JOINT_TYPE                                       AS CD_JOINT_TYPE
    , F.CD_SUSPENSION                                       AS CD_SUSPENSION
    , F.CD_TAX_QUALIFIED_STATUS                             AS CD_TAX_QUALIFIED_STATUS
    , SHA1(UPPER(
        NVL(D_COV.INTERNAL_COMPANY::STRING, '0')                    || '|' ||
        NVL(F.POLICY_ID::STRING, '0')                               || '|' ||
        NVL(D_COV.PHASE::STRING, '0')                               || '|' ||
        NVL(D_COV.SUB_PHASE::STRING, '0')                           || '|' ||
        NVL(D_COV.COVERAGE_TYPE_CODE::STRING, '0')
        )
        ) :: VARCHAR(50)                                   AS MD_HASH_NAT_KEY   
    , 0                                                    AS MD_HASHDIFF_TYPE_1
    , SHA1(UPPER(
        NVL(D_COV.SK_ID_DIM_COVERAGE::STRING, 0)                    || '|' ||
        NVL(D_ISS_DT.ID_DIM_DATE::STRING, 0)                        || '|' ||
        NVL(D_DOD_DT.ID_DIM_DATE::STRING, 0)                        || '|' ||
        NVL(D_CLOSE_DT.ID_DIM_DATE::STRING, 0)                      || '|' ||
        NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE::STRING, 0)    || '|' ||
        NVL(D_PFT.SK_ID_DIM_PFT::STRING, 0)                         || '|' ||
        NVL(D_SEX.SK_ID_DIM_SEX::STRING, 0)                         || '|' ||
        NVL(D_GRP_A_I.SK_ID_DIM_AGE_GROUP::STRING, 0)               || '|' ||
        NVL(D_GRP_A_A.SK_ID_DIM_AGE_GROUP::STRING, 0)               || '|' ||
        NVL(D_SMK_S.SK_ID_DIM_SMOKING_STATUS::STRING, 0)            || '|' ||
        NVL(D_DUR_R.SK_ID_DIM_DURATION_RANGE::STRING, 0)            || '|' ||
        NVL(D_VAT.SK_ID_DIM_VAT::STRING, 0)                         || '|' ||
        NVL(D_COV_ST.SK_ID_DIM_COVERAGE_STATUS::STRING, 0)          || '|' ||
        NVl(D_STATE_I.SK_ID_DIM_STATE::STRING, 0)                   || '|' ||
        NVL(D_STATE_R.SK_ID_DIM_STATE::STRING, 0)                   || '|' ||
        NVL(D_AGN.SK_ID_DIM_AGENT::STRING, 0)                       || '|' ||
        NVL(D_AGCY.SK_ID_DIM_AGENCY::STRING, 0)                     || '|' ||
        NVL(D_TERM_R.SK_ID_DIM_TERMINATION_REASON::STRING, 0)       || '|' ||
        NVL(F.AXIS_PLAN_CODE::STRING, '#NULL#')                     || '|' ||
        NVL(F.ISSUE_AGE::STRING, '0')                               || '|' ||
        NVL(F.ATTEINED_AGE::STRING, '0')                            || '|' ||
        NVL(F.DURATION_IN_YEARS::STRING, '0')                       || '|' ||
        NVL(F.AMT_CURRENT_DEATH_BENEFIT::STRING, '0')               || '|' ||
        NVL(F.AMT_CURRENT_FACE_AMOUNT::STRING, '0')                 || '|' ||
        NVL(F.AMT_ORIGINAL_FACE_AMOUNT::STRING, '0')                || '|' ||
        NVL(F.AMT_CURRENT_BENEFIT_VALUE::STRING, '0')               || '|' ||
        NVL(F.ANT_CURRENT_CASH_VALUE::STRING, '0')                  || '|' ||
        NVL(F.AMT_PREVIOUS_CASH_VALUE::STRING, '0')                 || '|' ||
        NVL(F.CD_PAYMENT_MODE::STRING, '#NULL#')                    || '|' ||
        NVL(F.CD_DEATH_BENEFIT_OPTION::STRING, '#NULL#')            || '|' ||
        NVL(F.CD_LINE_OF_BUSINESS::STRING, '#NULL#')                || '|' ||
        NVL(F.IND_COUVERTURE_TERMINEE::STRING, '0')                 || '|' ||
        NVL(F.CD_PARTICIPATION_CODE::STRING, '#NULL#')              || '|' ||
        NVL(F.CD_JOINT_TYPE::STRING, '#NULL#')                      || '|' ||
        NVL(F.CD_SUSPENSION::STRING, '#NULL#')                      || '|' ||
        NVL(F.CD_TAX_QUALIFIED_STATUS::STRING, '#NULL#')
        ) 
        ) :: VARCHAR(100)                                   AS MD_HASHDIFF_TYPE_2
    , EVALUATION_DT                                         AS MD_START_DT

FROM        
    DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_COVERAGE_INFO AS F

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE            AS D_COV
        ON  F.HASH_NAT_KEY_COVERAGE = D_COV.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_DATE                AS D_ISS_DT
        ON  F.NK_ISSUE_DATE = D_ISS_DT.ID_DIM_DATE

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_DATE                AS D_DOD_DT
        ON  F.NK_DATE_OF_DEATH = D_DOD_DT.DAY_SHORT_DATE

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_DATE                AS D_CLOSE_DT
        ON  F.NK_CLOSE_DATE = D_CLOSE_DT.DAY_SHORT_DATE

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE AS D_COV_MOD
        ON F.HASH_NAT_KEY_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_PFT                  AS D_PFT
        ON F.HASH_NAT_KEY_PFT = D_PFT.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_PFT.MD_ACTIVATION_DT AND D_PFT.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_SEX                  AS D_SEX 
        ON F.HASH_NAT_KEY_SEX = D_SEX.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_SEX.MD_ACTIVATION_DT AND D_SEX.MD_OBSOLESCENCE_DT

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_AGE_GROUP           AS D_GRP_A_I
        ON  F.ISSUE_AGE BETWEEN D_GRP_A_I.AGE_GROUP_MIN AND D_GRP_A_I.AGE_GROUP_MAX
        AND F.EVALUATION_DT BETWEEN D_GRP_A_I.MD_ACTIVATION_DT AND D_GRP_A_I.MD_OBSOLESCENCE_DT
        AND D_GRP_A_I.AGE_GROUP_CODE = 'ISSUE_AGE_GROUP_1'

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_AGE_GROUP           AS D_GRP_A_A
        ON  F.ATTEINED_AGE BETWEEN D_GRP_A_A.AGE_GROUP_MIN AND D_GRP_A_A.AGE_GROUP_MAX
        AND F.EVALUATION_DT BETWEEN D_GRP_A_A.MD_ACTIVATION_DT AND D_GRP_A_A.MD_OBSOLESCENCE_DT
        AND D_GRP_A_A.AGE_GROUP_CODE = 'ATTEINED_AGE_GROUP_1'

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_SMOKING_STATUS       AS D_SMK_S 
        ON F.HASH_NAT_KEY_SMOKING_STATUS = D_SMK_S.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_SMK_S.MD_ACTIVATION_DT AND D_SMK_S.MD_OBSOLESCENCE_DT

LEFT JOIN   DB_ACT_DEV_DM.DM_US_VI.DIM_DURATION_RANGE      AS D_DUR_R
        ON  F.DURATION_IN_YEARS BETWEEN D_DUR_R.DURATION_RANGE_MIN AND D_DUR_R.DURATION_RANGE_MAX
        AND F.EVALUATION_DT BETWEEN D_DUR_R.MD_ACTIVATION_DT AND D_DUR_R.MD_OBSOLESCENCE_DT
        AND D_DUR_R.DURATION_RANGE_CODE = 'DURATION_RANGE_1'

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_VAT                  AS D_VAT
        ON F.HASH_NAT_KEY_VAT = D_VAT.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_VAT.MD_ACTIVATION_DT AND D_VAT.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_STATUS      AS D_COV_ST
        ON F.HASH_NAT_KEY_COVERAGE_STATUS = D_COV_ST.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_COV_ST.MD_ACTIVATION_DT AND D_COV_ST.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_STATE                AS D_STATE_I
        ON F.HASH_NAT_KEY_ISSUE_STATE = D_STATE_I.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_STATE_I.MD_ACTIVATION_DT AND D_STATE_I.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_STATE                AS D_STATE_R
        ON F.HASH_NAT_KEY_RESIDENT_STATE = D_STATE_R.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_STATE_R.MD_ACTIVATION_DT AND D_STATE_R.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_AGENT                AS D_AGN
        ON F.HASH_NAT_KEY_AGENT = D_AGN.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_AGN.MD_ACTIVATION_DT AND D_AGN.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_AGENCY               AS D_AGCY
        ON F.HASH_NAT_KEY_AGENCY = D_AGCY.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_AGCY.MD_ACTIVATION_DT AND D_AGCY.MD_OBSOLESCENCE_DT

LEFT JOIN  DB_ACT_DEV_DM.DM_US_VI.DIM_TERMINATION_REASON   AS D_TERM_R
        ON F.HASH_NAT_KEY_TERMINATION_REASON = D_TERM_R.MD_HASH_NAT_KEY
        AND F.EVALUATION_DT BETWEEN D_TERM_R.MD_ACTIVATION_DT AND D_TERM_R.MD_OBSOLESCENCE_DT;
create or replace view VW_US_VI_FT_INVESTMENT_COMPONENT(
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	SK_ID_DIM_COVERAGE,
	POLICY_ID,
	AXIS_INCREMENT,
	CODE_LIGNE_AFFAIRE,
	CEDED_ACTUAL_INVCOMP_DEATH,
	CEDED_ACTUAL_INVCOMP_LAPSE,
	CEDED_ACTUAL_INVCOMP_OTHERBEN,
	CEDED_ACTUAL_INVCOMP_SURVIVORS,
	CEDED_EXPECTED_INVCOMP_DEATH,
	CEDED_EXPECTED_INVCOMP_LAPSE,
	CEDED_EXPECTED_INVCOMP_OTHERBEN,
	CEDED_EXPECTED_INVCOMP_SURVIVORS,
	GROSS_ACTUAL_INVCOMP_DEATH,
	GROSS_ACTUAL_INVCOMP_LAPSE,
	GROSS_ACTUAL_INVCOMP_OTHERBEN,
	GROSS_ACTUAL_INVCOMP_SURVIVORS,
	GROSS_EXPECTED_INVCOMP_DEATH,
	GROSS_EXPECTED_INVCOMP_LAPSE,
	GROSS_EXPECTED_INVCOMP_OTHERBEN,
	GROSS_EXPECTED_INVCOMP_SURVIVORS,
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2,
	MD_START_DT
) as

SELECT
TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT AS ID_DIM_EVALUATION_DATE
, NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1) AS SK_ID_DIM_COVERAGE_AXIS_MODULE
, NVL(D_COV.SK_ID_DIM_COVERAGE,-1) AS SK_ID_DIM_COVERAGE
, F.POLICY_ID AS POLICY_ID
, AXIS_INCREMENT AS AXIS_INCREMENT
, CODE_LIGNE_AFFAIRE AS CODE_LIGNE_AFFAIRE
, CEDED_ACTUAL_INVCOMP_DEATH AS CEDED_ACTUAL_INVCOMP_DEATH
, CEDED_ACTUAL_INVCOMP_LAPSE AS CEDED_ACTUAL_INVCOMP_LAPSE
, CEDED_ACTUAL_INVCOMP_OTHERBEN AS CEDED_ACTUAL_INVCOMP_OTHERBEN
, CEDED_ACTUAL_INVCOMP_SURVIVORS AS CEDED_ACTUAL_INVCOMP_SURVIVORS
, CEDED_EXPECTED_INVCOMP_DEATH AS CEDED_EXPECTED_INVCOMP_DEATH
, CEDED_EXPECTED_INVCOMP_LAPSE AS CEDED_EXPECTED_INVCOMP_LAPSE
, CEDED_EXPECTED_INVCOMP_OTHERBEN AS CEDED_EXPECTED_INVCOMP_OTHERBEN
, CEDED_EXPECTED_INVCOMP_SURVIVORS AS CEDED_EXPECTED_INVCOMP_SURVIVORS
, GROSS_ACTUAL_INVCOMP_DEATH AS GROSS_ACTUAL_INVCOMP_DEATH
, GROSS_ACTUAL_INVCOMP_LAPSE AS GROSS_ACTUAL_INVCOMP_LAPSE
, GROSS_ACTUAL_INVCOMP_OTHERBEN AS GROSS_ACTUAL_INVCOMP_OTHERBEN
, GROSS_ACTUAL_INVCOMP_SURVIVORS AS GROSS_ACTUAL_INVCOMP_SURVIVORS
, GROSS_EXPECTED_INVCOMP_DEATH AS GROSS_EXPECTED_INVCOMP_DEATH
, GROSS_EXPECTED_INVCOMP_LAPSE AS GROSS_EXPECTED_INVCOMP_LAPSE
, GROSS_EXPECTED_INVCOMP_OTHERBEN AS GROSS_EXPECTED_INVCOMP_OTHERBEN
, GROSS_EXPECTED_INVCOMP_SURVIVORS AS GROSS_EXPECTED_INVCOMP_SURVIVORS
, '0' AS MD_HASH_NAT_KEY
, '0' AS MD_HASHDIFF_TYPE_1
, '0' AS MD_HASHDIFF_TYPE_2
, EVALUATION_DT AS MD_START_DT

FROM
DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_SOE_INVESTMENT_COMPONENT AS F

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE D_COV_MOD
ON F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

left JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE D_COV 
ON F.POLICY_NO = D_COV.POLICY_NO
AND F.PHASE = D_COV.PHASE
AND F.SUB_PHASE = D_COV.SUB_PHASE
AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
AND ((D_COV.COMPANY_CODE = '060' AND D_COV.IND_ASSUMED = 'N') OR (D_COV.COMPANY_CODE <> '060'))
AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

WHERE (F.AXIS_INCREMENT = '0' )

UNION ALL

SELECT
TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT AS ID_DIM_EVALUATION_DATE
, NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1) AS SK_ID_DIM_COVERAGE_AXIS_MODULE
, NVL(D_COV.SK_ID_DIM_COVERAGE,-1) AS SK_ID_DIM_COVERAGE
, F.POLICY_ID AS POLICY_ID
, AXIS_INCREMENT AS AXIS_INCREMENT
, CODE_LIGNE_AFFAIRE AS CODE_LIGNE_AFFAIRE
, CEDED_ACTUAL_INVCOMP_DEATH AS CEDED_ACTUAL_INVCOMP_DEATH
, CEDED_ACTUAL_INVCOMP_LAPSE AS CEDED_ACTUAL_INVCOMP_LAPSE
, CEDED_ACTUAL_INVCOMP_OTHERBEN AS CEDED_ACTUAL_INVCOMP_OTHERBEN
, CEDED_ACTUAL_INVCOMP_SURVIVORS AS CEDED_ACTUAL_INVCOMP_SURVIVORS
, CEDED_EXPECTED_INVCOMP_DEATH AS CEDED_EXPECTED_INVCOMP_DEATH
, CEDED_EXPECTED_INVCOMP_LAPSE AS CEDED_EXPECTED_INVCOMP_LAPSE
, CEDED_EXPECTED_INVCOMP_OTHERBEN AS CEDED_EXPECTED_INVCOMP_OTHERBEN
, CEDED_EXPECTED_INVCOMP_SURVIVORS AS CEDED_EXPECTED_INVCOMP_SURVIVORS
, GROSS_ACTUAL_INVCOMP_DEATH AS GROSS_ACTUAL_INVCOMP_DEATH
, GROSS_ACTUAL_INVCOMP_LAPSE AS GROSS_ACTUAL_INVCOMP_LAPSE
, GROSS_ACTUAL_INVCOMP_OTHERBEN AS GROSS_ACTUAL_INVCOMP_OTHERBEN
, GROSS_ACTUAL_INVCOMP_SURVIVORS AS GROSS_ACTUAL_INVCOMP_SURVIVORS
, GROSS_EXPECTED_INVCOMP_DEATH AS GROSS_EXPECTED_INVCOMP_DEATH
, GROSS_EXPECTED_INVCOMP_LAPSE AS GROSS_EXPECTED_INVCOMP_LAPSE
, GROSS_EXPECTED_INVCOMP_OTHERBEN AS GROSS_EXPECTED_INVCOMP_OTHERBEN
, GROSS_EXPECTED_INVCOMP_SURVIVORS AS GROSS_EXPECTED_INVCOMP_SURVIVORS
, '0' AS MD_HASH_NAT_KEY
, '0' AS MD_HASHDIFF_TYPE_1
, '0' AS MD_HASHDIFF_TYPE_2
, EVALUATION_DT AS MD_START_DT

FROM
DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_SOE_INVESTMENT_COMPONENT AS F

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE D_COV_MOD
ON F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE D_COV
ON F.POLICY_NO = D_COV.POLICY_NO
AND F.PHASE = D_COV.PHASE
AND F.SUB_PHASE = D_COV.SUB_PHASE
AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
AND D_COV.COMPANY_CODE = '060'
AND D_COV.IND_ASSUMED = 'Y'
AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.FT_COVERAGE FT_COV
ON D_COV.SK_ID_DIM_COVERAGE = FT_COV.SK_ID_DIM_COVERAGE
AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_VAT D_VAT---- inner
ON FT_COV.SK_ID_DIM_VAT = D_VAT.SK_ID_DIM_VAT
AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT
AND D_VAT.GROUPE = 'Horizon Life'

WHERE
F.AXIS_INCREMENT = 'H'

UNION ALL

SELECT
TO_VARCHAR(F.EVALUATION_DT,'YYYYMMDD')::INT AS ID_DIM_EVALUATION_DATE
, NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1) AS SK_ID_DIM_COVERAGE_AXIS_MODULE
, NVL(D_COV.SK_ID_DIM_COVERAGE,-1) AS SK_ID_DIM_COVERAGE
, F.POLICY_ID AS POLICY_ID
, AXIS_INCREMENT AS AXIS_INCREMENT
, CODE_LIGNE_AFFAIRE AS CODE_LIGNE_AFFAIRE
, CEDED_ACTUAL_INVCOMP_DEATH AS CEDED_ACTUAL_INVCOMP_DEATH
, CEDED_ACTUAL_INVCOMP_LAPSE AS CEDED_ACTUAL_INVCOMP_LAPSE
, CEDED_ACTUAL_INVCOMP_OTHERBEN AS CEDED_ACTUAL_INVCOMP_OTHERBEN
, CEDED_ACTUAL_INVCOMP_SURVIVORS AS CEDED_ACTUAL_INVCOMP_SURVIVORS
, CEDED_EXPECTED_INVCOMP_DEATH AS CEDED_EXPECTED_INVCOMP_DEATH
, CEDED_EXPECTED_INVCOMP_LAPSE AS CEDED_EXPECTED_INVCOMP_LAPSE
, CEDED_EXPECTED_INVCOMP_OTHERBEN AS CEDED_EXPECTED_INVCOMP_OTHERBEN
, CEDED_EXPECTED_INVCOMP_SURVIVORS AS CEDED_EXPECTED_INVCOMP_SURVIVORS
, GROSS_ACTUAL_INVCOMP_DEATH AS GROSS_ACTUAL_INVCOMP_DEATH
, GROSS_ACTUAL_INVCOMP_LAPSE AS GROSS_ACTUAL_INVCOMP_LAPSE
, GROSS_ACTUAL_INVCOMP_OTHERBEN AS GROSS_ACTUAL_INVCOMP_OTHERBEN
, GROSS_ACTUAL_INVCOMP_SURVIVORS AS GROSS_ACTUAL_INVCOMP_SURVIVORS
, GROSS_EXPECTED_INVCOMP_DEATH AS GROSS_EXPECTED_INVCOMP_DEATH
, GROSS_EXPECTED_INVCOMP_LAPSE AS GROSS_EXPECTED_INVCOMP_LAPSE
, GROSS_EXPECTED_INVCOMP_OTHERBEN AS GROSS_EXPECTED_INVCOMP_OTHERBEN
, GROSS_EXPECTED_INVCOMP_SURVIVORS AS GROSS_EXPECTED_INVCOMP_SURVIVORS
, '0' AS MD_HASH_NAT_KEY
, '0' AS MD_HASHDIFF_TYPE_1
, '0' AS MD_HASHDIFF_TYPE_2
, EVALUATION_DT AS MD_START_DT

FROM
DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_SOE_INVESTMENT_COMPONENT AS F

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE D_COV_MOD
ON F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE D_COV
ON F.POLICY_NO = D_COV.POLICY_NO
AND F.PHASE = D_COV.PHASE
AND F.SUB_PHASE = D_COV.SUB_PHASE
AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
AND D_COV.COMPANY_CODE = '060'
AND D_COV.IND_ASSUMED = 'Y'
AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.FT_COVERAGE FT_COV
ON D_COV.SK_ID_DIM_COVERAGE = FT_COV.SK_ID_DIM_COVERAGE
AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_VAT D_VAT
ON FT_COV.SK_ID_DIM_VAT = D_VAT.SK_ID_DIM_VAT
AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT
AND D_VAT.GROUPE <> 'Horizon Life'

WHERE
F.AXIS_INCREMENT = 'T';
create or replace view VW_US_VI_FT_RESERVE_RELEASE(
	ID_DIM_EVALUATION_DATE,
	SK_ID_DIM_RESERVE_RELEASE_TYPE,
	SK_ID_DIM_RATE_TYPE,
	SK_ID_DIM_COVERAGE_AXIS_MODULE,
	SK_ID_DIM_COVERAGE,
	POLICY_ID,
	POLICY_ID_EX,
	AXIS_INCREMENT,
	CODE_LIGNE_AFFAIRE,
	GROSS_ACTUAL_RELEASE_ON_DEATH,
	GROSS_ACTUAL_RELEASE_ON_INCIDENCE,
	GROSS_ACTUAL_RELEASE_ON_LAPSE,
	GROSS_ACTUAL_RELEASE_ON_MISC_OFF,
	GROSS_ACTUAL_RELEASE_ON_MISC_ON,
	GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN,
	GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT,
	GROSS_ACTUAL_RELEASE_ON_RECOVERY,
	GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT,
	GROSS_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION,
	GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY,
	GROSS_EXPECTED_RELEASE_ON_DEATH,
	GROSS_EXPECTED_RELEASE_ON_INCIDENCE,
	GROSS_EXPECTED_RELEASE_ON_LAPSE,
	GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT,
	GROSS_EXPECTED_RELEASE_ON_RECOVERY,
	GROSS_EXP_ADJUSTMENT_LATENB,
	GROSS_EXP_ADJUSTMENT_MISCOFF,
	GROSS_EXP_ADJUSTMENT_MISCON,
	GROSS_EXP_ADJUSTMENT_NEWCESSIONS,
	GROSS_EXP_ADJUSTMENT_PEINFTRUEUP,
	GROSS_EXP_ADJUSTMENT_POLICYCHANGES,
	GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB,
	GROSS_EXP_ADJUSTMENT_REINSTATEMENT,
	GROSS_EXP_ADJUSTMENT_TOTAL,
	CEDED_ACTUAL_RELEASE_ON_DEATH,
	CEDED_ACTUAL_RELEASE_ON_INCIDENCE,
	CEDED_ACTUAL_RELEASE_ON_LAPSE,
	CEDED_ACTUAL_RELEASE_ON_MISC_OFF,
	CEDED_ACTUAL_RELEASE_ON_MISC_ON,
	CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN,
	CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT,
	CEDED_ACTUAL_RELEASE_ON_RECOVERY,
	CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT,
	CEDED_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION,
	CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY,
	CEDED_EXPECTED_RELEASE_ON_DEATH,
	CEDED_EXPECTED_RELEASE_ON_INCIDENCE,
	CEDED_EXPECTED_RELEASE_ON_LAPSE,
	CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT,
	CEDED_EXPECTED_RELEASE_ON_RECOVERY,
	CEDED_EXP_ADJUSTMENT_LATENB,
	CEDED_EXP_ADJUSTMENT_MISCOFF,
	CEDED_EXP_ADJUSTMENT_MISCON,
	CEDED_EXP_ADJUSTMENT_NEWCESSIONS,
	CEDED_EXP_ADJUSTMENT_PEINFTRUEUP,
	CEDED_EXP_ADJUSTMENT_POLICYCHANGES,
	CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB,
	CEDED_EXP_ADJUSTMENT_REINSTATEMENT,
	CEDED_EXP_ADJUSTMENT_TOTAL,
	MD_HASH_NAT_KEY,
	MD_HASHDIFF_TYPE_1,
	MD_HASHDIFF_TYPE_2,
	MD_START_DT,
	MD_ROW_IS_VALID
) as

SELECT
NVL(D_EVAL_DT.ID_DIM_DATE,-1) AS ID_DIM_EVALUATION_DATE
, NVL(D_RES_REL.SK_ID_DIM_RESERVE_RELEASE_TYPE,-1) AS SK_ID_DIM_RESERVE_RELEASE_TYPE
, NVL(D_RATE_T.SK_ID_DIM_RATE_TYPE,-1) AS SK_ID_DIM_RATE_TYPE
, NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1) AS SK_ID_DIM_COVERAGE_AXIS_MODULE
, NVL(D_COV.SK_ID_DIM_COVERAGE,-1) AS SK_ID_DIM_COVERAGE
, F.POLICY_ID AS POLICY_ID
, F.POLICY_ID_EX AS POLICY_ID_EX
, AXIS_INCREMENT AS AXIS_INCREMENT
, CODE_LIGNE_AFFAIRE AS CODE_LIGNE_AFFAIRE
, GROSS_ACTUAL_RELEASE_ON_DEATH AS GROSS_ACTUAL_RELEASE_ON_DEATH
, GROSS_ACTUAL_RELEASE_ON_INCIDENCE AS GROSS_ACTUAL_RELEASE_ON_INCIDENCE
, GROSS_ACTUAL_RELEASE_ON_LAPSE AS GROSS_ACTUAL_RELEASE_ON_LAPSE
, GROSS_ACTUAL_RELEASE_ON_MISC_OFF AS GROSS_ACTUAL_RELEASE_ON_MISC_OFF
, GROSS_ACTUAL_RELEASE_ON_MISC_ON AS GROSS_ACTUAL_RELEASE_ON_MISC_ON
, GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN AS GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN
, GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT AS GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT
, GROSS_ACTUAL_RELEASE_ON_RECOVERY AS GROSS_ACTUAL_RELEASE_ON_RECOVERY
, GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT AS GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT
, GROSS_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION AS GROSS_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION
, GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY AS GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY
, GROSS_EXPECTED_RELEASE_ON_DEATH AS GROSS_EXPECTED_RELEASE_ON_DEATH
, GROSS_EXPECTED_RELEASE_ON_INCIDENCE AS GROSS_EXPECTED_RELEASE_ON_INCIDENCE
, GROSS_EXPECTED_RELEASE_ON_LAPSE AS GROSS_EXPECTED_RELEASE_ON_LAPSE
, GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT AS GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT
, GROSS_EXPECTED_RELEASE_ON_RECOVERY AS GROSS_EXPECTED_RELEASE_ON_RECOVERY
, GROSS_EXP_ADJUSTMENT_LATENB AS GROSS_EXP_ADJUSTMENT_LATENB
, GROSS_EXP_ADJUSTMENT_MISCOFF AS GROSS_EXP_ADJUSTMENT_MISCOFF
, GROSS_EXP_ADJUSTMENT_MISCON AS GROSS_EXP_ADJUSTMENT_MISCON
, GROSS_EXP_ADJUSTMENT_NEWCESSIONS AS GROSS_EXP_ADJUSTMENT_NEWCESSIONS
, GROSS_EXP_ADJUSTMENT_PEINFTRUEUP AS GROSS_EXP_ADJUSTMENT_PEINFTRUEUP
, GROSS_EXP_ADJUSTMENT_POLICYCHANGES AS GROSS_EXP_ADJUSTMENT_POLICYCHANGES
, GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB AS GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB
, GROSS_EXP_ADJUSTMENT_REINSTATEMENT AS GROSS_EXP_ADJUSTMENT_REINSTATEMENT
, GROSS_EXP_ADJUSTMENT_TOTAL AS GROSS_EXP_ADJUSTMENT_TOTAL
, CEDED_ACTUAL_RELEASE_ON_DEATH AS CEDED_ACTUAL_RELEASE_ON_DEATH
, CEDED_ACTUAL_RELEASE_ON_INCIDENCE AS CEDED_ACTUAL_RELEASE_ON_INCIDENCE
, CEDED_ACTUAL_RELEASE_ON_LAPSE AS CEDED_ACTUAL_RELEASE_ON_LAPSE
, CEDED_ACTUAL_RELEASE_ON_MISC_OFF AS CEDED_ACTUAL_RELEASE_ON_MISC_OFF
, CEDED_ACTUAL_RELEASE_ON_MISC_ON AS CEDED_ACTUAL_RELEASE_ON_MISC_ON
, CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN AS CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN
, CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT AS CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT
, CEDED_ACTUAL_RELEASE_ON_RECOVERY AS CEDED_ACTUAL_RELEASE_ON_RECOVERY
, CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT AS CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT
, CEDED_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION AS CEDED_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION
, CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY AS CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY
, CEDED_EXPECTED_RELEASE_ON_DEATH AS CEDED_EXPECTED_RELEASE_ON_DEATH
, CEDED_EXPECTED_RELEASE_ON_INCIDENCE AS CEDED_EXPECTED_RELEASE_ON_INCIDENCE
, CEDED_EXPECTED_RELEASE_ON_LAPSE AS CEDED_EXPECTED_RELEASE_ON_LAPSE
, CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT AS CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT
, CEDED_EXPECTED_RELEASE_ON_RECOVERY AS CEDED_EXPECTED_RELEASE_ON_RECOVERY
, CEDED_EXP_ADJUSTMENT_LATENB AS CEDED_EXP_ADJUSTMENT_LATENB
, CEDED_EXP_ADJUSTMENT_MISCOFF AS CEDED_EXP_ADJUSTMENT_MISCOFF
, CEDED_EXP_ADJUSTMENT_MISCON AS CEDED_EXP_ADJUSTMENT_MISCON
, CEDED_EXP_ADJUSTMENT_NEWCESSIONS AS CEDED_EXP_ADJUSTMENT_NEWCESSIONS
, CEDED_EXP_ADJUSTMENT_PEINFTRUEUP AS CEDED_EXP_ADJUSTMENT_PEINFTRUEUP
, CEDED_EXP_ADJUSTMENT_POLICYCHANGES AS CEDED_EXP_ADJUSTMENT_POLICYCHANGES
, CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB AS CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB
, CEDED_EXP_ADJUSTMENT_REINSTATEMENT AS CEDED_EXP_ADJUSTMENT_REINSTATEMENT
, CEDED_EXP_ADJUSTMENT_TOTAL AS CEDED_EXP_ADJUSTMENT_TOTAL
, '0' AS MD_HASH_NAT_KEY
, '0' AS MD_HASHDIFF_TYPE_1
, '0' AS MD_HASHDIFF_TYPE_2
, EVALUATION_DT AS MD_START_DT
, CASE WHEN D_EVAL_DT.ID_DIM_DATE = 19000101 OR D_RES_REL.SK_ID_DIM_RESERVE_RELEASE_TYPE < 0 OR D_RATE_T.SK_ID_DIM_RATE_TYPE < 0
            OR D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE <0 OR D_COV.SK_ID_DIM_COVERAGE < 0 THEN 0 ELSE 1 END AS MD_ROW_IS_VALID
			
FROM DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_RESERVE_RELEASE AS F
INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_DATE AS D_EVAL_DT
ON F.NK_EVALUATION_DATE = D_EVAL_DT.ID_DIM_DATE

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE AS D_COV_MOD
ON F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RESERVE_RELEASE_TYPE AS D_RES_REL
ON F.NK_RESERVE_RELEASE_TYPE = D_RES_REL.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_RES_REL.MD_ACTIVATION_DT AND D_RES_REL.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RATE_TYPE AS D_RATE_T
ON F.NK_RATE_TYPE = D_RATE_T.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_RATE_T.MD_ACTIVATION_DT AND D_RATE_T.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE AS D_COV
ON F.POLICY_NO = D_COV.POLICY_NO
AND F.PHASE = D_COV.PHASE
AND F.SUB_PHASE = D_COV.SUB_PHASE
AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
AND  ((D_COV.COMPANY_CODE = '060' AND D_COV.IND_ASSUMED = 'N') OR (D_COV.COMPANY_CODE <> '060'))
AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

WHERE (F.AXIS_INCREMENT = '0' )

UNION ALL

SELECT
NVL(D_EVAL_DT.ID_DIM_DATE,-1) AS ID_DIM_EVALUATION_DATE
, NVL(D_RES_REL.SK_ID_DIM_RESERVE_RELEASE_TYPE,-1) AS SK_ID_DIM_RESERVE_RELEASE_TYPE
, NVL(D_RATE_T.SK_ID_DIM_RATE_TYPE,-1) AS SK_ID_DIM_RATE_TYPE
, NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1) AS SK_ID_DIM_COVERAGE_AXIS_MODULE
, NVL(D_COV.SK_ID_DIM_COVERAGE,-1) AS SK_ID_DIM_COVERAGE
, F.POLICY_ID AS POLICY_ID
, F.POLICY_ID_EX AS POLICY_ID_EX
, AXIS_INCREMENT AS AXIS_INCREMENT
, CODE_LIGNE_AFFAIRE AS CODE_LIGNE_AFFAIRE
, GROSS_ACTUAL_RELEASE_ON_DEATH AS GROSS_ACTUAL_RELEASE_ON_DEATH
, GROSS_ACTUAL_RELEASE_ON_INCIDENCE AS GROSS_ACTUAL_RELEASE_ON_INCIDENCE
, GROSS_ACTUAL_RELEASE_ON_LAPSE AS GROSS_ACTUAL_RELEASE_ON_LAPSE
, GROSS_ACTUAL_RELEASE_ON_MISC_OFF AS GROSS_ACTUAL_RELEASE_ON_MISC_OFF
, GROSS_ACTUAL_RELEASE_ON_MISC_ON AS GROSS_ACTUAL_RELEASE_ON_MISC_ON
, GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN AS GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN
, GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT AS GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT
, GROSS_ACTUAL_RELEASE_ON_RECOVERY AS GROSS_ACTUAL_RELEASE_ON_RECOVERY
, GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT AS GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT
, GROSS_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION AS GROSS_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION
, GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY AS GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY
, GROSS_EXPECTED_RELEASE_ON_DEATH AS GROSS_EXPECTED_RELEASE_ON_DEATH
, GROSS_EXPECTED_RELEASE_ON_INCIDENCE AS GROSS_EXPECTED_RELEASE_ON_INCIDENCE
, GROSS_EXPECTED_RELEASE_ON_LAPSE AS GROSS_EXPECTED_RELEASE_ON_LAPSE
, GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT AS GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT
, GROSS_EXPECTED_RELEASE_ON_RECOVERY AS GROSS_EXPECTED_RELEASE_ON_RECOVERY
, GROSS_EXP_ADJUSTMENT_LATENB AS GROSS_EXP_ADJUSTMENT_LATENB
, GROSS_EXP_ADJUSTMENT_MISCOFF AS GROSS_EXP_ADJUSTMENT_MISCOFF
, GROSS_EXP_ADJUSTMENT_MISCON AS GROSS_EXP_ADJUSTMENT_MISCON
, GROSS_EXP_ADJUSTMENT_NEWCESSIONS AS GROSS_EXP_ADJUSTMENT_NEWCESSIONS
, GROSS_EXP_ADJUSTMENT_PEINFTRUEUP AS GROSS_EXP_ADJUSTMENT_PEINFTRUEUP
, GROSS_EXP_ADJUSTMENT_POLICYCHANGES AS GROSS_EXP_ADJUSTMENT_POLICYCHANGES
, GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB AS GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB
, GROSS_EXP_ADJUSTMENT_REINSTATEMENT AS GROSS_EXP_ADJUSTMENT_REINSTATEMENT
, GROSS_EXP_ADJUSTMENT_TOTAL AS GROSS_EXP_ADJUSTMENT_TOTAL
, CEDED_ACTUAL_RELEASE_ON_DEATH AS CEDED_ACTUAL_RELEASE_ON_DEATH
, CEDED_ACTUAL_RELEASE_ON_INCIDENCE AS CEDED_ACTUAL_RELEASE_ON_INCIDENCE
, CEDED_ACTUAL_RELEASE_ON_LAPSE AS CEDED_ACTUAL_RELEASE_ON_LAPSE
, CEDED_ACTUAL_RELEASE_ON_MISC_OFF AS CEDED_ACTUAL_RELEASE_ON_MISC_OFF
, CEDED_ACTUAL_RELEASE_ON_MISC_ON AS CEDED_ACTUAL_RELEASE_ON_MISC_ON
, CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN AS CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN
, CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT AS CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT
, CEDED_ACTUAL_RELEASE_ON_RECOVERY AS CEDED_ACTUAL_RELEASE_ON_RECOVERY
, CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT AS CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT
, CEDED_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION AS CEDED_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION
, CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY AS CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY
, CEDED_EXPECTED_RELEASE_ON_DEATH AS CEDED_EXPECTED_RELEASE_ON_DEATH
, CEDED_EXPECTED_RELEASE_ON_INCIDENCE AS CEDED_EXPECTED_RELEASE_ON_INCIDENCE
, CEDED_EXPECTED_RELEASE_ON_LAPSE AS CEDED_EXPECTED_RELEASE_ON_LAPSE
, CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT AS CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT
, CEDED_EXPECTED_RELEASE_ON_RECOVERY AS CEDED_EXPECTED_RELEASE_ON_RECOVERY
, CEDED_EXP_ADJUSTMENT_LATENB AS CEDED_EXP_ADJUSTMENT_LATENB
, CEDED_EXP_ADJUSTMENT_MISCOFF AS CEDED_EXP_ADJUSTMENT_MISCOFF
, CEDED_EXP_ADJUSTMENT_MISCON AS CEDED_EXP_ADJUSTMENT_MISCON
, CEDED_EXP_ADJUSTMENT_NEWCESSIONS AS CEDED_EXP_ADJUSTMENT_NEWCESSIONS
, CEDED_EXP_ADJUSTMENT_PEINFTRUEUP AS CEDED_EXP_ADJUSTMENT_PEINFTRUEUP
, CEDED_EXP_ADJUSTMENT_POLICYCHANGES AS CEDED_EXP_ADJUSTMENT_POLICYCHANGES
, CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB AS CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB
, CEDED_EXP_ADJUSTMENT_REINSTATEMENT AS CEDED_EXP_ADJUSTMENT_REINSTATEMENT
, CEDED_EXP_ADJUSTMENT_TOTAL AS CEDED_EXP_ADJUSTMENT_TOTAL
, '0' AS MD_HASH_NAT_KEY
, '0' AS MD_HASHDIFF_TYPE_1
, '0' AS MD_HASHDIFF_TYPE_2
, EVALUATION_DT AS MD_START_DT
, CASE WHEN D_EVAL_DT.ID_DIM_DATE = 19000101 OR D_RES_REL.SK_ID_DIM_RESERVE_RELEASE_TYPE < 0 OR D_RATE_T.SK_ID_DIM_RATE_TYPE < 0
            OR D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE <0 OR D_COV.SK_ID_DIM_COVERAGE < 0 THEN 0 ELSE 1 END AS MD_ROW_IS_VALID

FROM DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_RESERVE_RELEASE AS F
INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_DATE AS D_EVAL_DT
ON F.NK_EVALUATION_DATE = D_EVAL_DT.ID_DIM_DATE

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE AS D_COV_MOD
ON F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RESERVE_RELEASE_TYPE AS D_RES_REL
ON F.NK_RESERVE_RELEASE_TYPE = D_RES_REL.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_RES_REL.MD_ACTIVATION_DT AND D_RES_REL.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RATE_TYPE AS D_RATE_T
ON F.NK_RATE_TYPE = D_RATE_T.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_RATE_T.MD_ACTIVATION_DT AND D_RATE_T.MD_OBSOLESCENCE_DT

left JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE AS D_COV --inner
ON F.POLICY_NO = D_COV.POLICY_NO
AND F.PHASE = D_COV.PHASE
AND F.SUB_PHASE = D_COV.SUB_PHASE
AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
AND D_COV.COMPANY_CODE = '060'
AND D_COV.IND_ASSUMED = 'Y'
AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

left JOIN DB_ACT_DEV_DM.DM_US_VI.FT_COVERAGE AS FT_COV --inner
ON D_COV.SK_ID_DIM_COVERAGE = FT_COV.SK_ID_DIM_COVERAGE
AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT

left JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_VAT AS D_VAT --inner
ON FT_COV.SK_ID_DIM_VAT = D_VAT.SK_ID_DIM_VAT
AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT
AND D_VAT.GROUPE = 'Horizon Life'

WHERE F.AXIS_INCREMENT = 'H'

UNION ALL

SELECT
NVL(D_EVAL_DT.ID_DIM_DATE,-1) AS ID_DIM_EVALUATION_DATE
, NVL(D_RES_REL.SK_ID_DIM_RESERVE_RELEASE_TYPE,-1) AS SK_ID_DIM_RESERVE_RELEASE_TYPE
, NVL(D_RATE_T.SK_ID_DIM_RATE_TYPE,-1) AS SK_ID_DIM_RATE_TYPE
, NVL(D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE,-1) AS SK_ID_DIM_COVERAGE_AXIS_MODULE
, NVL(D_COV.SK_ID_DIM_COVERAGE,-1) AS SK_ID_DIM_COVERAGE
, F.POLICY_ID AS POLICY_ID
, F.POLICY_ID_EX AS POLICY_ID_EX
, AXIS_INCREMENT AS AXIS_INCREMENT
, CODE_LIGNE_AFFAIRE AS CODE_LIGNE_AFFAIRE
, GROSS_ACTUAL_RELEASE_ON_DEATH AS GROSS_ACTUAL_RELEASE_ON_DEATH
, GROSS_ACTUAL_RELEASE_ON_INCIDENCE AS GROSS_ACTUAL_RELEASE_ON_INCIDENCE
, GROSS_ACTUAL_RELEASE_ON_LAPSE AS GROSS_ACTUAL_RELEASE_ON_LAPSE
, GROSS_ACTUAL_RELEASE_ON_MISC_OFF AS GROSS_ACTUAL_RELEASE_ON_MISC_OFF
, GROSS_ACTUAL_RELEASE_ON_MISC_ON AS GROSS_ACTUAL_RELEASE_ON_MISC_ON
, GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN AS GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN
, GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT AS GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT
, GROSS_ACTUAL_RELEASE_ON_RECOVERY AS GROSS_ACTUAL_RELEASE_ON_RECOVERY
, GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT AS GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT
, GROSS_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION AS GROSS_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION
, GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY AS GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY
, GROSS_EXPECTED_RELEASE_ON_DEATH AS GROSS_EXPECTED_RELEASE_ON_DEATH
, GROSS_EXPECTED_RELEASE_ON_INCIDENCE AS GROSS_EXPECTED_RELEASE_ON_INCIDENCE
, GROSS_EXPECTED_RELEASE_ON_LAPSE AS GROSS_EXPECTED_RELEASE_ON_LAPSE
, GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT AS GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT
, GROSS_EXPECTED_RELEASE_ON_RECOVERY AS GROSS_EXPECTED_RELEASE_ON_RECOVERY
, GROSS_EXP_ADJUSTMENT_LATENB AS GROSS_EXP_ADJUSTMENT_LATENB
, GROSS_EXP_ADJUSTMENT_MISCOFF AS GROSS_EXP_ADJUSTMENT_MISCOFF
, GROSS_EXP_ADJUSTMENT_MISCON AS GROSS_EXP_ADJUSTMENT_MISCON
, GROSS_EXP_ADJUSTMENT_NEWCESSIONS AS GROSS_EXP_ADJUSTMENT_NEWCESSIONS
, GROSS_EXP_ADJUSTMENT_PEINFTRUEUP AS GROSS_EXP_ADJUSTMENT_PEINFTRUEUP
, GROSS_EXP_ADJUSTMENT_POLICYCHANGES AS GROSS_EXP_ADJUSTMENT_POLICYCHANGES
, GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB AS GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB
, GROSS_EXP_ADJUSTMENT_REINSTATEMENT AS GROSS_EXP_ADJUSTMENT_REINSTATEMENT
, GROSS_EXP_ADJUSTMENT_TOTAL AS GROSS_EXP_ADJUSTMENT_TOTAL
, CEDED_ACTUAL_RELEASE_ON_DEATH AS CEDED_ACTUAL_RELEASE_ON_DEATH
, CEDED_ACTUAL_RELEASE_ON_INCIDENCE AS CEDED_ACTUAL_RELEASE_ON_INCIDENCE
, CEDED_ACTUAL_RELEASE_ON_LAPSE AS CEDED_ACTUAL_RELEASE_ON_LAPSE
, CEDED_ACTUAL_RELEASE_ON_MISC_OFF AS CEDED_ACTUAL_RELEASE_ON_MISC_OFF
, CEDED_ACTUAL_RELEASE_ON_MISC_ON AS CEDED_ACTUAL_RELEASE_ON_MISC_ON
, CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN AS CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN
, CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT AS CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT
, CEDED_ACTUAL_RELEASE_ON_RECOVERY AS CEDED_ACTUAL_RELEASE_ON_RECOVERY
, CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT AS CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT
, CEDED_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION AS CEDED_ADJUSTMENT_DUE_TO_LIFE_COMPOSITION
, CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY AS CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY
, CEDED_EXPECTED_RELEASE_ON_DEATH AS CEDED_EXPECTED_RELEASE_ON_DEATH
, CEDED_EXPECTED_RELEASE_ON_INCIDENCE AS CEDED_EXPECTED_RELEASE_ON_INCIDENCE
, CEDED_EXPECTED_RELEASE_ON_LAPSE AS CEDED_EXPECTED_RELEASE_ON_LAPSE
, CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT AS CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT
, CEDED_EXPECTED_RELEASE_ON_RECOVERY AS CEDED_EXPECTED_RELEASE_ON_RECOVERY
, CEDED_EXP_ADJUSTMENT_LATENB AS CEDED_EXP_ADJUSTMENT_LATENB
, CEDED_EXP_ADJUSTMENT_MISCOFF AS CEDED_EXP_ADJUSTMENT_MISCOFF
, CEDED_EXP_ADJUSTMENT_MISCON AS CEDED_EXP_ADJUSTMENT_MISCON
, CEDED_EXP_ADJUSTMENT_NEWCESSIONS AS CEDED_EXP_ADJUSTMENT_NEWCESSIONS
, CEDED_EXP_ADJUSTMENT_PEINFTRUEUP AS CEDED_EXP_ADJUSTMENT_PEINFTRUEUP
, CEDED_EXP_ADJUSTMENT_POLICYCHANGES AS CEDED_EXP_ADJUSTMENT_POLICYCHANGES
, CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB AS CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB
, CEDED_EXP_ADJUSTMENT_REINSTATEMENT AS CEDED_EXP_ADJUSTMENT_REINSTATEMENT
, CEDED_EXP_ADJUSTMENT_TOTAL AS CEDED_EXP_ADJUSTMENT_TOTAL
, '0' AS MD_HASH_NAT_KEY
, '0' AS MD_HASHDIFF_TYPE_1
, '0' AS MD_HASHDIFF_TYPE_2
, EVALUATION_DT AS MD_START_DT
, CASE WHEN D_EVAL_DT.ID_DIM_DATE = 19000101 OR D_RES_REL.SK_ID_DIM_RESERVE_RELEASE_TYPE < 0 OR D_RATE_T.SK_ID_DIM_RATE_TYPE < 0
            OR D_COV_MOD.SK_ID_DIM_COVERAGE_AXIS_MODULE <0 OR D_COV.SK_ID_DIM_COVERAGE < 0 THEN 0 ELSE 1 END AS MD_ROW_IS_VALID

FROM DB_ACT_DEV_DWH.PUBLICATION_US_VI.VW_US_VI_RESERVE_RELEASE AS F
INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_DATE AS D_EVAL_DT
ON F.NK_EVALUATION_DATE = D_EVAL_DT.ID_DIM_DATE

INNER JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE_AXIS_MODULE AS D_COV_MOD
ON F.NK_COVERAGE_AXIS_MODULE = D_COV_MOD.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_COV_MOD.MD_ACTIVATION_DT AND D_COV_MOD.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RESERVE_RELEASE_TYPE AS D_RES_REL
ON F.NK_RESERVE_RELEASE_TYPE = D_RES_REL.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_RES_REL.MD_ACTIVATION_DT AND D_RES_REL.MD_OBSOLESCENCE_DT

LEFT JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_RATE_TYPE AS D_RATE_T
ON F.NK_RATE_TYPE = D_RATE_T.MD_HASH_NAT_KEY
AND F.EVALUATION_DT BETWEEN D_RATE_T.MD_ACTIVATION_DT AND D_RATE_T.MD_OBSOLESCENCE_DT

left JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_COVERAGE AS D_COV -- inner
ON F.POLICY_NO = D_COV.POLICY_NO
AND F.PHASE = D_COV.PHASE
AND F.SUB_PHASE = D_COV.SUB_PHASE
AND F.COMPANY_CODE = D_COV.INTERNAL_COMPANY
AND D_COV.COMPANY_CODE = '060'
AND D_COV.IND_ASSUMED = 'Y'
AND D_COV.COVERAGE_TYPE_CODE <>'P' AND D_COV.COVERAGE_TYPE_CODE <>'O'
AND F.EVALUATION_DT BETWEEN D_COV.MD_ACTIVATION_DT AND D_COV.MD_OBSOLESCENCE_DT

left JOIN DB_ACT_DEV_DM.DM_US_VI.FT_COVERAGE AS FT_COV --inner
ON D_COV.SK_ID_DIM_COVERAGE = FT_COV.SK_ID_DIM_COVERAGE
AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT

left JOIN DB_ACT_DEV_DM.DM_US_VI.DIM_VAT AS D_VAT -- inner
ON FT_COV.SK_ID_DIM_VAT = D_VAT.SK_ID_DIM_VAT
AND F.EVALUATION_DT BETWEEN FT_COV.MD_ACTIVATION_DT AND FT_COV.MD_OBSOLESCENCE_DT
AND D_VAT.GROUPE <> 'Horizon Life'

WHERE F.AXIS_INCREMENT = 'T';
create or replace schema DM_VI;

create or replace TABLE DIM_AGE (
	SK_ID_DIM_AGE NUMBER(4,0) NOT NULL COMMENT 'Clé numérique intelligente correspondant à l''âge (0 à 150)',
	AGE NUMBER(4,0) NOT NULL COMMENT 'Identifiant unique de l''âge  Clé d''affaire de la dimension',
	TRANCHE_AGES_1 VARCHAR(50) NOT NULL COMMENT 'Nom de la tranche d''âge 1 associée à l''âge.  Ex: 0, 1, 2, 3-5, 6-10, 10-15,...',
	TRANCHE_AGES_MIN_1 NUMBER(4,0) NOT NULL COMMENT 'Seuil minimal de la tranche d''âge 1',
	TRANCHE_AGES_MAX_1 NUMBER(4,0) NOT NULL COMMENT 'Seuil maximal de la tranche d''âge 1',
	TRANCHE_AGES_2 VARCHAR(50) COMMENT 'Nom de la tranche d''âge 2 associée à l''âge.  Ex: 0, 1, 2, 3-5, 6-10, 10-15,...',
	TRANCHE_AGES_MIN_2 NUMBER(4,0) COMMENT 'Seuil minimal de la tranche d''âge 2',
	TRANCHE_AGES_MAX_2 NUMBER(4,0) COMMENT 'Seuil maximal de la tranche d''âge 2',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_AGE_PK primary key (SK_ID_DIM_AGE)
)COMMENT='Cette table contient la liste d''âges possibles des assurés (0 à 150), regroupés selon des tranches d''âges pré-établies.'
;
create or replace TABLE DIM_AGE_ATTEINT (
	SK_ID_AGE_ATTEINT NUMBER(38,0) autoincrement,
	AGE_ATTEINT NUMBER(38,0),
	AGE_ATTEINT_BUCKET VARCHAR(100),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_AGE_EMISSION (
	SK_ID_AGE_EMISSION NUMBER(38,0) autoincrement,
	AGE VARCHAR(50),
	AGE_EMISSION_BUCKET VARCHAR(100),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_BENEFICE_SUPPLEMENTAIRE (
	SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	BENEFICE_SUPPLEMENTAIRE VARCHAR(200) NOT NULL COMMENT 'Nom complet du bénéfice supplémentaire relié aux projections actuarielles de morbidité d''Axis',
	NOM_COURT_BENEFICE_SUPPLEMENTAIRE VARCHAR(50) NOT NULL COMMENT 'Nom court du bénéfice supplémentaire relié aux projections actuarielles de morbidité d''Axis',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_BENEFICE_SUPPLEMENTAIRE_PK primary key (SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE)
)COMMENT='Contient la liste des béméfices supplémentaires reliés aux couverture de morbidité'
;
create or replace TABLE DIM_CODE_PLAN_AXIS (
	SK_ID_DIM_CODE_PLAN_AXIS NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	CODE_PLAN_AXIS VARCHAR(15) NOT NULL COMMENT 'Identifiant unique du plan.  Clé d''affaire de la dimension',
	CODE_PLAN_ALIS VARCHAR(7) NOT NULL,
	SUFFIXE VARCHAR(4) NOT NULL,
	CODE_VERSION_PRODUIT VARCHAR(4) NOT NULL,
	COMPANY VARCHAR(10),
	PRODUCT VARCHAR(100) COMMENT 'Attribut utilisé pour regrouper les codes de plan.  Hierarchie par Groupe/Produit.',
	GRP VARCHAR(100) COMMENT 'Attribut utilisé pour regrouper les codes de plan.  Hierarchie par Groupe/Produit.',
	SUB_GROUP VARCHAR(100),
	GENERATION VARCHAR(100),
	DESCRIPTION VARCHAR(255),
	PLAN_CODE_ULIS VARCHAR(100),
	SPLIT_CAD VARCHAR(100),
	TEAM VARCHAR(100),
	AXIS_MODULE VARCHAR(100),
	OTHER_BENEFIT_OBJECT VARCHAR(255),
	TABLE_OTHER_BENEFIT_RATE_FOR_SET VARCHAR(255),
	ACB_MORTALITY_OPTIONS VARCHAR(100),
	ACB_MORTALITY_PER_1000 VARCHAR(100),
	ACTUAL_PREMIUM_TABLE VARCHAR(100),
	AGE_DISTRIBUTION_TABLE VARCHAR(100),
	BENEFIT_LEVEL_INDICATOR NUMBER(38,0),
	BENEFIT_PERIOD_CAUSE_1 VARCHAR(100),
	BENEFIT_PERIOD_CAUSE_2 VARCHAR(100),
	BENEFIT_PERIOD_METHOD VARCHAR(100),
	BONUS_CHARGEBACK_TABLE VARCHAR(100),
	CASH_VALUE_TABLE VARCHAR(100),
	COMMISSION_TABLE VARCHAR(100),
	COMPENSATION_METHOD VARCHAR(100),
	COMPENSATION_TABLE VARCHAR(100),
	DEATH_BENEFIT_PERIOD_AGE VARCHAR(100),
	DEATH_BENEFIT_PERIOD_CODE VARCHAR(100),
	DEATH_BENEFIT_PERIOD_DUR VARCHAR(100),
	DISABILITY_BENEFIT_PERIOD_AGE VARCHAR(100),
	DISABILITY_BENEFIT_PERIOD_CODE VARCHAR(100),
	DISABILITY_BENEFIT_PERIOD_DUR VARCHAR(100),
	DIVIDEND_OPTION NUMBER(38,0),
	DIVIDEND_TABLE VARCHAR(100),
	DIVIDEND_TABLE_DEFINITION NUMBER(38,0),
	EARLY_TERMINATION_CONDITION_OPTION VARCHAR(100),
	ELIMINATION_PERIOD_CAUSE_1 VARCHAR(100),
	ELIMINATION_PERIOD_CAUSE_2 VARCHAR(100),
	EXEMPT_TEST_MORT_TABLE VARCHAR(100),
	EXPENSE_CHARGE_TABLE VARCHAR(100),
	FACE_AMOUNT_TABLE VARCHAR(100),
	FIRST_YEAR_COMMISSION VARCHAR(100),
	FREQUENCY_OF_CHARGES_METHOD VARCHAR(100),
	FUND_BONUS_TABLE VARCHAR(100),
	IIT_GUARANTEED_INTEREST NUMBER(38,0),
	IS_COMMISSION_USE_BASE_PLAN VARCHAR(100),
	MATURITY_VALUE_METHOD NUMBER(38,0),
	MATURITY_VALUE_TABLE VARCHAR(100),
	MAXIMUM_BENEFIT_MONTHS_CAUSE_1 VARCHAR(100),
	MAXIMUM_BENEFIT_MONTHS_CAUSE_2 VARCHAR(100),
	MID_YEAR_CSV_METHOD VARCHAR(100),
	MINIMUM_PREMIUM_TABLE VARCHAR(100),
	MORT_METHOD_FOR_JOINT VARCHAR(100),
	MULT_FOR_RISK_CHARGE VARCHAR(100),
	NAAR_METHOD NUMBER(38,0),
	NON_SMOKER_BONUS VARCHAR(100),
	OACA_OTHER_BENEFIT VARCHAR(100),
	OTHER_BENEFIT_LINK_1 VARCHAR(100),
	OTHER_BENEFIT_LINK_2 VARCHAR(100),
	OTHER_BENEFIT_LINK_3 VARCHAR(100),
	POLICY_CONTINUATION_GUAR_OPTION NUMBER(38,0),
	PRE_DISABILITY_BENEFIT_TABLE VARCHAR(100),
	PREMIUM_LOAD_TABLE VARCHAR(100),
	PREMIUM_TABLE VARCHAR(100),
	PREMIUM_TABLE_CREATE_JOINT_TABLES_AUTOMATICALLY VARCHAR(100),
	PREMIUM_WAIVER_METHOD VARCHAR(100),
	PRICING_UTILIZATION_TABLE VARCHAR(100),
	PRM_PAYING_PERIOD_AGE VARCHAR(100),
	PRM_PAYING_PERIOD_CODE VARCHAR(100),
	PRM_PAYING_PERIOD_DUR VARCHAR(100),
	PROJ_METHOD_FOR_JOINT VARCHAR(100),
	PUA_CSV_TABLE VARCHAR(100),
	PUA_DIV_BONUS_ON_LAPSE NUMBER(38,0),
	PUA_NSP_TABLE VARCHAR(100),
	RETROACTIVE_PERIOD_CAUSE_1 VARCHAR(100),
	RETROACTIVE_PERIOD_CAUSE_2 VARCHAR(100),
	RISK_CHARGE_TABLE VARCHAR(100),
	ROP_TABLE VARCHAR(100),
	SURRENDER_CHARGE_TABLE VARCHAR(100),
	SUB_PREMIUM_TABLE VARCHAR(100),
	SUB_RISK_CHARGE_TABLE VARCHAR(100),
	T5_ACCUM_FUND VARCHAR(100),
	T5_CALCULATION_METHOD VARCHAR(100),
	TARGET_FUND_TABLE VARCHAR(100),
	USE_ACB_IN_EXTRACT VARCHAR(100),
	VOLUME_TYPE VARCHAR(100),
	WAIVER_OF_FUND_CHARGES VARCHAR(100),
	ESCAP_TYPE VARCHAR(100),
	ESCAPCLASS VARCHAR(100),
	ESCAP_PAR_BLOCK VARCHAR(100),
	ESCAP_ADJUSTABLE_PRODUCT VARCHAR(100),
	ESCAP_DEATH_DESIGNATION VARCHAR(100),
	ESCAP_LAPSE_DESIGNATION VARCHAR(100),
	ESCAP_MORTALITY_GROUP VARCHAR(100),
	ESCAP_BASE_LAPSE_TABLE VARCHAR(100),
	ESCAP_CSV_DEFICIENCY_GROUP VARCHAR(100),
	ESCAP_PF_AD_EXCLUSION_GROUP VARCHAR(100),
	ESCAP_PAR_OR_ADJUSTABLE_ID VARCHAR(100),
	BAREME_PAR_BLOCK VARCHAR(100),
	TYPE_FOR_MORTALITY VARCHAR(100),
	IFRS_SPLIT VARCHAR(100),
	LIQUIDITY_PLAN VARCHAR(100),
	LIQUIDITY_TYPE VARCHAR(100),
	AM_BEST_TYPE VARCHAR(100),
	DCAT_SPLIT VARCHAR(100),
	LIVRE_DE_TAUX_POUR_BAREME VARCHAR(100),
	STUDY_GROUPING_CODE VARCHAR(100),
	IFRS17_GROUP VARCHAR(100),
	IND_PROLONGATION_ASSURANCE_MODULAIRE BOOLEAN,
	STUDY_PROTECTION_TYPE VARCHAR(100),
	SOE_PRODUCT VARCHAR(100),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_CODE_PLAN_AXIS_PK primary key (SK_ID_DIM_CODE_PLAN_AXIS)
)COMMENT='Cette table contient les attributs provenant du fichier PFT (ou Product Features Table).  Il s''agit des caractéristiques reliées aux planx représentéx par un code de plan Axis.'
;
create or replace TABLE DIM_COMPTE_GL (
	SK_ID_DIM_COMPTE_GL NUMBER(20,0) NOT NULL autoincrement,
	CD_ENTITE VARCHAR(4) NOT NULL,
	CD_NATURE VARCHAR(6) NOT NULL,
	CD_ORIGINE VARCHAR(4) NOT NULL,
	CD_PERIODICITE VARCHAR(4) NOT NULL,
	CD_CENTRE_COUT VARCHAR(4) NOT NULL,
	CD_INTERCO VARCHAR(4) NOT NULL,
	CD_LIGNE_AFFAIRE VARCHAR(4) NOT NULL,
	CD_PRODUIT VARCHAR(4) NOT NULL,
	CD_PARTICIPATION VARCHAR(4) NOT NULL,
	CD_GEOGRAPHIE VARCHAR(4) NOT NULL,
	CD_PROJET VARCHAR(4) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COMPTE_GL_PK primary key (SK_ID_DIM_COMPTE_GL)
);
create or replace TABLE DIM_COUVERTURE (
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la dimension',
	NO_POLICE VARCHAR(20) NOT NULL COMMENT 'Identifiant de la police à laquelle est ratachée la couverture.',
	CODE_COMPAGNIE VARCHAR(10) NOT NULL COMMENT 'Code identifiant la compagnie émettrice de la couverture',
	LIGNE_AFFAIRE VARCHAR(10) NOT NULL COMMENT 'Code identifiant la ligne d''affaire à laquelle la couverture est reliée.  Équivaut à LAF (Français) ou LOB (anglais)',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COUVERTURE_PK primary key (SK_ID_DIM_COUVERTURE)
)COMMENT='Cette table devrait contenir l''ensemble des attributs de type 1 de la couverture.  Les attibuts de type 2 seront suivis dans la table Factless Fact table.'
;
create or replace TABLE DIM_COUVERTURE_INFO (
	SK_ID_DIM_COUVERTURE_INFO NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	BANDE VARCHAR(50),
	CODE_JOINT_LIFE VARCHAR(10) COMMENT 'Code indiquant si la couverture d''assurance est conjointe ou individuelle. Domaine de valeurs possibles : I, F, L',
	PRM_MODE VARCHAR(50) COMMENT 'Indique la fréquence (mode) du paiement de la prime.  Ex: Mensuel, annuel...',
	IND_COUVERTURE_TERMINEE NUMBER(1,0) COMMENT 'Indicateur (0/1)  1 --> Couverture terminée, 0 --> Couverture en vigueur',
	IND_GARANTIE NUMBER(1,0),
	IND_TRANSFORMATION NUMBER(1,0) COMMENT 'Indicateur (0/1) 1 --> Indique les couvertures temporaires qui ont été transformées en couverture permanente.',
	IND_TRAITE_REASSURANCE NUMBER(1,0) COMMENT 'Indique (1/0) l''existance d''un traité de réassurance (TRAITE_REASSURANCE NOT NULL ou <> '''')',
	CODE_PARTICIPATION VARCHAR(50) COMMENT 'Indique le type de participation des couvertures avec participation. Ex: Appliquer le dividende sur le paiement de la prime, placer le dividende dans le but de générer un revenu, ou recevoir le dividende directement,...',
	CODE_TYPE_TRANSFORMATION NUMBER(4,0) COMMENT 'Code indiquant la raison pour laquelle une couverture a été transformée Ex: Fusion de 2 couvertures, Modification de code de plan...',
	NOM_TYPE_TRANSFORMATION VARCHAR(50) COMMENT 'Nom correspondant au type de transformation',
	S_CDSYSTEMESOURCE VARCHAR(20) COMMENT 'System source',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COUVERTURE_INFO_PK primary key (SK_ID_DIM_COUVERTURE_INFO)
);
create or replace TABLE DIM_DATE (
	ID_DIM_DATE NUMBER(8,0) NOT NULL COMMENT 'Identifiant Date du jour',
	SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Date en format court français selon les paramêtres régionaux, ex: 2016-02-14',
	SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Date en format court anglais selon les paramêtres régionaux, ex: 02/14/2016',
	NAME_FR VARCHAR(50) NOT NULL COMMENT 'Date en format long français selon les paramêtres régionaux, ex: 14 février 2016',
	NAME_EN VARCHAR(50) NOT NULL COMMENT 'Date en format long anglais selon les paramêtres régionaux, ex: Saturday, February 14, 2016',
	WEEK_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro de journée dans la semaine ISO (Lundi=1, Dimanche=7)',
	MONTH_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le mois (1 à 31)',
	QUARTER_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le trimestre (1 à 91)',
	SEMESTER_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans le semestre (1 à 184)',
	YEAR_DAY_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du jour dans l''année (1 à 366)',
	DAY_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom abrégé français de la journée de la semaine, ex: dim.',
	DAY_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom abrégé anglais de la journée de la semaine, ex: Sun',
	DAY_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la journée de la semaine, ex: \"\"dimanche\"\"',
	DAY_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la journée de la semaine, ex: \"\"Sunday\"\"',
	WEEKEND_IND BOOLEAN NOT NULL COMMENT 'Indique si la journée est un jour de fin de semaine (samedi ou dimanche)',
	WEEK_CD VARCHAR(10) NOT NULL COMMENT 'Code de la semaine sous la forme aaaaSnn, ex: 2016S01',
	WEEK_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro de la semaine dans l''année; 53 possible',
	WEEK_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français de la semaine, ex: \"\"Sem. 12\"\"',
	WEEK_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais de la semaine, ex: \"\"Wk 12\"\"',
	WEEK_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la semaine, ex: \"\"Semaine 12\"\"',
	WEEK_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la semaine, ex: \"\"Week 12\"\"',
	WEEK_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français de la semaine dans l''année, ex: \"\"2016, Sem. 12\"\"',
	WEEK_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais de la semaine dans l''année, ex: \"\"2016, Wk. 12\"\"',
	WEEK_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français de la semaine dans l''année, ex: \"\"2016, Semaine 12\"\"',
	WEEK_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais de la semaine dans l''année, ex: \"\"2016, Week 12\"\"',
	WEEK_START_DT DATE NOT NULL COMMENT 'Date du début de la semaine ',
	WEEK_END_DT DATE NOT NULL COMMENT 'Date de la fin de la semaine ',
	WEEK_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours de la semaine ',
	MONTH_CD VARCHAR(10) NOT NULL COMMENT 'Code du mois sous la forme aaaaMnn, ex: 2016M05',
	MONTH_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du mois (1 à 12)',
	MONTH_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du mois, ex: \"\"janv.\"\"',
	MONTH_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du mois,  ex: \"\"Jan\"\"',
	MONTH_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du mois, ex: Janvier\"\"',
	MONTH_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du mois, ex: January\"\"',
	MONTH_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du mois de l''année, ex: \"\"janv. 2016\"\"',
	MONTH_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du mois de l''année, ex: \"\"Jan 2016\"\"',
	MONTH_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du mois de l''année, ex: \"\"janvier 2016\"\"',
	MONTH_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du mois de l''année, ex: \"\"January 2016\"\"',
	MONTH_START_DT DATE NOT NULL COMMENT 'Date du début du mois',
	MONTH_END_DT DATE NOT NULL COMMENT 'Date de fin du mois',
	MONTH_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours du mois',
	QUARTER_CD VARCHAR(10) NOT NULL COMMENT 'Code du trimestre sous la forme aaaaQnn, ex: 2016Q03',
	QUARTER_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du trimestre (1 à 4)',
	QUARTER_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du trimestre, ex : \"\"T1\"\"',
	QUARTER_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du trimestre, ex : \"\"Q1\"\"',
	QUARTER_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du trimestre, ex : \"\"Trimestre 1\"\"',
	QUARTER_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du trimestre, ex : \"\"Quarter 1\"\"',
	QUARTER_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du trimestre de l''année , ex : \"\"T1, 2016\"\"',
	QUARTER_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du trimestre de l''année, ex : \"\"Q1, 2016\"\"',
	QUARTER_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du trimestre de l''année , ex : \"\"Trimestre 1, 2016\"\"',
	QUARTER_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du trimestre de l''année , ex : \"\"Quarter 1, 2016\"\"',
	QUARTER_START_DT DATE NOT NULL COMMENT 'Date de début du trimestre',
	QUARTER_END_DT DATE NOT NULL COMMENT 'Date de fin du trimestre',
	QUARTER_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours dans le trimeste (90, 91 ou 92)',
	SEMESTER_CD VARCHAR(10) NOT NULL COMMENT 'Code de semestre sous la forme aaaaSnn, ex: 2016S01 ou 2016S02 (du 1 janvier au 30 juin et 1 juillet au 31 décembre)',
	SEMESTER_NO NUMBER(38,0) NOT NULL COMMENT 'Numéro du semestre (1 ou 2)',
	SEMESTER_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du semestre, ex: \"\"S1\"\"',
	SEMESTER_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du semestre, ex: \"\"S1\"\"',
	SEMESTER_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du semestre, ex: \"\"Semestre 1\"\"',
	SEMESTER_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du semestre, ex: \"\"Semester 1\"\"',
	SEMESTER_YEAR_SHORT_NAME_FR VARCHAR(20) NOT NULL COMMENT 'Nom court français du semestre dans l''année, ex: \"\"S1, 2016\"\"',
	SEMESTER_YEAR_SHORT_NAME_EN VARCHAR(20) NOT NULL COMMENT 'Nom court anglais du semestre dans l''année, ex: \"\"S1, 2016\"\"',
	SEMESTER_YEAR_NAME_FR VARCHAR(50) NOT NULL COMMENT 'Nom long français du semestre dans l''année, ex: \"\"Semestre 1, 2016\"\"',
	SEMESTER_YEAR_NAME_EN VARCHAR(50) NOT NULL COMMENT 'Nom long anglais du semestre dans l''année, ex: \"\"Semester 1, 2016\"\"',
	SEMESTER_START_DT DATE NOT NULL COMMENT 'Date de début du semestre',
	SEMESTER_END_DT DATE NOT NULL COMMENT 'Date de fin du semestre',
	SEMESTER_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours dans le semestre (183 ou 184)',
	YEAR_CD NUMBER(38,0) NOT NULL COMMENT 'Code de l''année sous la forme aaaa',
	YEAR_SHORT_NAME_FR VARCHAR(4) NOT NULL COMMENT 'Nom court français de l''année, ex: 2016',
	YEAR_SHORT_NAME_EN VARCHAR(4) NOT NULL COMMENT 'Nom court anglais de l''année, ex: 2016',
	YEAR_NAME_FR VARCHAR(4) NOT NULL COMMENT 'Nom long français de l''année, ex: 2016',
	YEAR_NAME_EN VARCHAR(4) NOT NULL COMMENT 'Nom long anglais de l''année, ex: 2016',
	YEAR_START_DT DATE NOT NULL COMMENT 'Date de début de l''année, ex: 2016-01-01',
	YEAR_END_DT DATE NOT NULL COMMENT 'Date de fin de l''année, ex: 2016-12-31',
	YEAR_NB_DAY NUMBER(38,0) NOT NULL COMMENT 'Nombre de jours de l''année',
	constraint PK_DIM_DATE primary key (ID_DIM_DATE)
);
create or replace TABLE DIM_DUREE (
	SK_ID_DIM_DUREE NUMBER(4,0) NOT NULL autoincrement COMMENT 'Clé numérique intelligente correspondant au nombre d''années.',
	DUREE NUMBER(4,0) NOT NULL COMMENT 'Identifiant unique de la durée en nombre d''années.',
	TRANCHE_DUREES_1 VARCHAR(50) NOT NULL COMMENT 'Nom de la tranche de durée 1 associée à la durée représentée en nombre d''années.  Ex: 0, 1, 2, 3-5, 6-10, 10-15,...',
	TRANCHE_DUREES_MIN_1 NUMBER(4,0) NOT NULL COMMENT 'Seuil minimal de la tranche de durées 1',
	TRANCHE_DUREES_MAX_1 NUMBER(4,0) NOT NULL COMMENT 'Seuil maximal de la tranche de durées 1',
	TRANCHE_DUREES_2 VARCHAR(50) COMMENT 'Nom de la tranche de durée 2 associée à la durée représentée en nombre d''années.  Ex: 0, 1, 2, 3-5, 6-10, 10-15,...',
	TRANCHE_DUREES_MIN_2 NUMBER(4,0) COMMENT 'Seuil minimal de la tranche de durées 2',
	TRANCHE_DUREES_MAX_2 NUMBER(4,0) COMMENT 'Seuil maximal de la tranche de durées 2',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_DUREE_PK primary key (SK_ID_DIM_DUREE)
)COMMENT='Cette table contient la liste des durées représentant le nombre d''années qu''une couverture est en vigueur, regroupés selon des tranches de durées pré-établies.'
;
create or replace TABLE DIM_GROUPE_CSM (
	SK_ID_DIM_GROUPE_CSM NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	NOM_GROUPE_CSM VARCHAR(100) NOT NULL COMMENT 'Nom du groupe CSM',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COMPTE_GL_PK primary key (SK_ID_DIM_GROUPE_CSM)
)COMMENT='Table de dimension contenant la liste des groupes CSM (Marge de Service Contractuelle) assignés aux couvertures (directe et réssurance) lors de leur première valorisation.'
;
create or replace TABLE DIM_INFO_COUVERTURE (
	SK_ID_INFO_COUVERTURE NUMBER(38,0) autoincrement,
	MODULE VARCHAR(10),
	CVG_CODEJOINTLIFE VARCHAR(10),
	CVG_PREFSTATUS VARCHAR(10),
	CVG_SEX VARCHAR(10),
	CVG_SMKSTATUS VARCHAR(10),
	BEN_OPTION NUMBER(4,0),
	GEN_COMPANYCODE VARCHAR(10),
	LOB VARCHAR(10),
	INDTERMINE NUMBER(38,0),
	INDGARANTIE NUMBER(38,0),
	GEN_PARCODE VARCHAR(10),
	INDTRANSFORMATION NUMBER(2,0),
	RAISONTERMINAISON VARCHAR(50),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_MASTER_COA (
	SK_ID_DIM_MASTER_COA NUMBER(20,0) NOT NULL autoincrement,
	VARIABLE_CSM VARCHAR(300) NOT NULL,
	CUSTOM_DIM_1 VARCHAR(100) NOT NULL,
	CUSTOM_DIM_2 VARCHAR(100) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COMPTE_GL_PK primary key (SK_ID_DIM_MASTER_COA)
);
create or replace TABLE DIM_MODULE_COUVERTURE (
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	CODE_MODULE_COUVERTURE VARCHAR(10) NOT NULL COMMENT 'Code identifiant le module d''assurance.  Les valeurs possibles sont RL, PAR, UL, DI. Il s''agit également de la clé d''affaire',
	NOM_MODULE_COUVERTURE VARCHAR(50) NOT NULL COMMENT 'Nom du module.  Pour l''instant le domaine de valeurs se limite à PAR = Par produit, RL = Regular Life, UL = Universal Life, DI = Disability',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_MODULE_COUVERTURE_PK primary key (SK_ID_DIM_MODULE_COUVERTURE)
);
create or replace TABLE DIM_MONTANT_ASSURANCE (
	SK_ID_MONTANT_ASSURANCE NUMBER(38,0) autoincrement,
	BANDE VARCHAR(10),
	BEN_CURRENT_VALUE NUMBER(28,10),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_ORIGINE_MONTANT (
	SK_ID_DIM_ORIGINE_MONTANT NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ORIGINE_MONTANT VARCHAR(50) NOT NULL COMMENT 'Nom représentant l''origine des montants utilisés dans les analyses actuarielles (Gross/Ceded).  Il s''agit également de la clé d''affaire',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_ORIGINE_MONTANT_PK primary key (SK_ID_DIM_ORIGINE_MONTANT)
)COMMENT='Contient la liste des origines (Gross/Ceded) possibles des montants pris en compte dans les analyses SOE'
;
create or replace TABLE DIM_RAISON_TERMINAISON (
	SK_ID_DIM_RAISON_TERMINAISON NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	RAISON_TERMINAISON VARCHAR(100) NOT NULL COMMENT 'Raison de terminaison.  Ex:  Abandon, Maturité, Décès,...',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_RAISON_TERMINAISON_PK primary key (SK_ID_DIM_RAISON_TERMINAISON)
)COMMENT='Cette table contient la liste des raisons de terminaison caractérisant la fin de l''en-vigueur d''une couverture.'
;
create or replace TABLE DIM_REASSURANCE (
	SK_ID_REASSURANCE NUMBER(38,0) autoincrement,
	TRAITE_REASSURANCE VARCHAR(2),
	TYPE_REASSURANCE VARCHAR(2),
	REINSCE_NOREINSURER VARCHAR(2),
	REINSCE_TREATYDATE DATE,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_REASSUREUR (
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	CODE_REASSUREUR VARCHAR(4) NOT NULL COMMENT 'Code du réassureur.  De 00 à 99',
	NOM_REASSUREUR VARCHAR(50) NOT NULL COMMENT 'Nom du réassureur',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_COMPTE_GL_PK primary key (SK_ID_DIM_REASSUREUR)
)COMMENT='Table de dimension contenant la liste des identifiants des compagnies de réassurance'
;
create or replace TABLE DIM_RESEAU_DISTRIBUTION (
	SK_ID_DIM_RESEAU_DISTRIBUTION NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	CODE_AGENCE VARCHAR(10),
	CODE_AGENT VARCHAR(10),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50),
	MD_CREATION_AUDIT_ID NUMBER(38,0),
	constraint DIM_RESEAU_DISTRIBUTION_PK primary key (SK_ID_DIM_RESEAU_DISTRIBUTION)
);
create or replace TABLE DIM_SEXE (
	SK_ID_DIM_SEXE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	CODE_SEXE VARCHAR(10) NOT NULL COMMENT 'Code identifiant le genre de l''assuré.',
	NOM_SEXE VARCHAR(50) NOT NULL COMMENT 'Nom du genre de l''assuré',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_SEXE_PK primary key (SK_ID_DIM_SEXE)
);
create or replace TABLE DIM_STATUT_FUMEUR (
	SK_ID_DIM_STATUT_FUMEUR NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	CODE_STATUT_FUMEUR VARCHAR(10) NOT NULL COMMENT 'Code identifiant le statut fumeur',
	NOM_STATUT_FUMEUR VARCHAR(50) NOT NULL COMMENT 'Nom du statut fumeur',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_STATUT_FUMEUR_PK primary key (SK_ID_DIM_STATUT_FUMEUR)
)COMMENT='Cette table contient la liste des différents statuts fumeur considérés lors de la taraification des couvertures.'
;
create or replace TABLE DIM_STATUT_PREFERENTIEL (
	SK_ID_DIM_STATUT_PREFERENTIEL NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	CODE_STATUT_PREFERENTIEL VARCHAR(10) NOT NULL COMMENT 'Code identifiant le statut préférentiel (ou classification)',
	NOM_STATUT_PREFERENTIEL VARCHAR(50) NOT NULL COMMENT 'Nom du statut préférentiel (ou classification)',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_STATUT_PREFERENTIEL_PK primary key (SK_ID_DIM_STATUT_PREFERENTIEL)
);
create or replace TABLE DIM_SURPRIME (
	SK_ID_SURPRIME NUMBER(38,0) autoincrement,
	PRM_USERATING NUMBER(38,0),
	RATING_MULT NUMBER(19,10),
	RATING_FLAT NUMBER(19,10),
	RATING_TEMP NUMBER(19,10),
	RATING_TEMPDUR NUMBER(19,10),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_TERRITOIRE (
	SK_ID_DIM_TERRITOIRE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	CODE_PAYS VARCHAR(10) NOT NULL COMMENT 'Code identifiant le pays',
	NOM_PAYS VARCHAR(50) NOT NULL COMMENT 'Nom du pays',
	CODE_PROVINCE_ETAT VARCHAR(10) NOT NULL COMMENT 'Code province ou état',
	NOM_PROVINCE_ETAT VARCHAR(50) NOT NULL COMMENT 'Nom province ou état',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_TERRITOIRE_PK primary key (SK_ID_DIM_TERRITOIRE)
)COMMENT='Cette table contient la liste des  provinces/états groupés par pays.'
;
create or replace TABLE DIM_TRAITE_REASSURANCE (
	SK_ID_DIM_TRAITE_REASSURANCE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	TYPE_REASSURANCE VARCHAR(10) NOT NULL COMMENT 'Code composé de 2 caractères identifiant le type de réassurance. ',
	TRAITE_REASSURANCE VARCHAR(50) NOT NULL COMMENT 'Égale à C ou ''''.',
	NUMERO_REASSUREUR VARCHAR(10) NOT NULL COMMENT 'Numéro identifiant le réassureur.',
	DATE_TRAITE_REASSURANCE DATE NOT NULL COMMENT 'Date de mise en vigueur du traité de réassurance.',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_TRAITE_REASSURANCE_PK primary key (SK_ID_DIM_TRAITE_REASSURANCE)
);
create or replace TABLE DIM_TYPE_LIBERATION_RESERVE (
	SK_ID_DIM_TYPE_LIBERATION_RESERVE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	TYPE_LIBERATION_RESERVE VARCHAR(50) NOT NULL COMMENT 'Nom du type de liberation de reserve.  Il s''agit également de la clé d''affaire',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_TYPE_LIBERATION_RESERVE_PK primary key (SK_ID_DIM_TYPE_LIBERATION_RESERVE)
)COMMENT='Contient la liste des type d''hypothèse de libération de réserve.  (RA ou BEL)'
;
create or replace TABLE DIM_TYPE_PROJECTION (
	SK_ID_DIM_TYPE_PROJECTION NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	TYPE_PROJECTION VARCHAR(50) NOT NULL COMMENT 'Nom représentant le type de projection (expected/actual) associé aux montants des rapports Axis',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_TYPE_PROJECTION_PK primary key (SK_ID_DIM_TYPE_PROJECTION)
)COMMENT='Contient la liste des types de projection (expected/actual) associés aux montants des analyses SOE'
;
create or replace TABLE DIM_TYPE_TAUX_INTERET (
	SK_ID_DIM_TYPE_TAUX_INTERET NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	NOM_TYPE_TAUX_INTERET VARCHAR(50) NOT NULL COMMENT 'Nom du type de taux d''intérêt utilisé pour les calculs dans AXIS.  Ex: Locked-In = Taux d''intérêt à l''émission de la couverture; CURRENT = Taux d''intérêt à la date d''évaluation.  Il s''agit également de la clé d''affaire',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_TYPE_TAUX_INTERET_PK primary key (SK_ID_DIM_TYPE_TAUX_INTERET)
)COMMENT='Liste des types de taux d''intérêt utilisés pour les calculs dans AXIS. Ex: Locked-In = Taux d''intérêt à l''émission de la couverture; CURRENT = Taux d''intérêt à la date d''évaluation.'
;
create or replace TABLE DIM_VALUATION_ASSUMPTIONS_TABLES (
	SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	CODE_PLAN_AXIS VARCHAR(15) NOT NULL COMMENT 'Identifiant unique du plan.  Clé d''affaire de la dimension',
	PRODUCT VARCHAR(100) COMMENT 'Attribut utilisé pour regrouper les codes de plan.  Hierarchie par Groupe/Produit.',
	GRP VARCHAR(100) COMMENT 'Attribut utilisé pour regrouper les codes de plan.  Hierarchie par Groupe/Produit.',
	SUB_GROUP VARCHAR(100),
	TEAM VARCHAR(100),
	AXIS_MODULE VARCHAR(100),
	SOE_OUTPUT_LAPSE_GROUPING VARCHAR(100),
	BASE_CELL_NAME VARCHAR(100),
	AC_DIVIDEND_MORTALITY_TABLE VARCHAR(100),
	AC_DIVIDEND_EXPENSES_TABLE VARCHAR(100),
	AC_DIVIDEND_INTEREST_TABLE VARCHAR(100),
	EX_DIVIDEND_MORTALITY_TABLE VARCHAR(100),
	EX_DIVIDEND_EXPENSES_TABLE VARCHAR(100),
	EX_DIVIDEND_INTEREST_TABLE VARCHAR(100),
	PRICING_CAUSE_1_QI_TABLE VARCHAR(100),
	PRICING_CAUSE_2_QI_TABLE VARCHAR(100),
	PRICING_DYNAMIC_PREM_ADJUSTMENT_OPTION VARCHAR(100),
	PRICING_EXPENSES_TABLE VARCHAR(100),
	PRICING_INTEREST_TABLE VARCHAR(100),
	PRICING_LAPSE_RATE_TABLE VARCHAR(100),
	PRICING_MODIFICATION_TABLE VARCHAR(100),
	PRICING_MORTALITY_IMPR_TABLE VARCHAR(100),
	PRICING_MORTALITY_TABLE VARCHAR(100),
	PRICING_MULT_FOR_MORTALITY_IMPR VARCHAR(100),
	PRICING_OTHER_BENEFIT_RATES_TABLE VARCHAR(100),
	PRICING_TERMINATION_CAUSE_1_TABLE VARCHAR(100),
	PRICING_TERMINATION_CAUSE_2_TABLE VARCHAR(100),
	PRICING_TOTAL_PREMIUM_TABLE VARCHAR(100),
	STAT_INPUT_TERMINAL_RES_FACTORS_TABLE VARCHAR(100),
	STAT_RES_CAUSE_1_QI_TABLE VARCHAR(100),
	STAT_RES_CAUSE_2_QI_TABLE VARCHAR(100),
	STAT_RES_EXPENSES_TABLE VARCHAR(100),
	STAT_RES_FLAT_FOR_LAPSE_PAD VARCHAR(100),
	STAT_RES_FLAT_FOR_FINAL_MORTALITY_MAD VARCHAR(100),
	STAT_RES_HISTORIC_MORTALITY_IMPROVEMENT VARCHAR(100),
	STAT_RES_INTEREST_TABLE VARCHAR(100),
	STAT_RES_LAPSE_PAD_TABLE VARCHAR(100),
	STAT_RES_LAPSE_RATE_PAD_METHOD VARCHAR(100),
	STAT_RES_LAPSE_RATE_TABLE VARCHAR(100),
	STAT_RES_MODIFICATION_TABLE VARCHAR(100),
	STAT_RES_MORTALITY_IMPR_TABLE VARCHAR(100),
	STAT_RES_FINAL_MORTALITY_MAD_TABLE VARCHAR(100),
	STAT_RES_MULT_FOR_CAUSE_1_QI VARCHAR(100),
	STAT_RES_MULT_FOR_CAUSE_2_QI VARCHAR(100),
	STAT_RES_MULT_FOR_EXPENSES VARCHAR(100),
	STAT_RES_MULT_FOR_MORTALITY_IMPR VARCHAR(100),
	STAT_RES_MULT_FOR_TERMINATION_CAUSE_1 VARCHAR(100),
	STAT_RES_MULT_FOR_TERMINATION_CAUSE_2 VARCHAR(100),
	STAT_RES_OTHER_BENEFIT_RATES_TABLE VARCHAR(100),
	STAT_RES_TERMINATION_CAUSE_1_TABLE VARCHAR(100),
	STAT_RES_TERMINATION_CAUSE_2_TABLE VARCHAR(100),
	STAT_RES_TOTAL_PREMIUM_TABLE VARCHAR(100),
	TAX_RES_EXPENSES_TABLE VARCHAR(100),
	TAX_RES_INTEREST_TABLE VARCHAR(100),
	TAX_RES_LAPSE_RATE_TABLE VARCHAR(100),
	TAX_RES_MORTALITY_IMPR_TABLE VARCHAR(100),
	TAX_RES_MORTALITY_TABLE VARCHAR(100),
	TAX_RES_MULT_FOR_MORTALITY_IMPR VARCHAR(100),
	TAX_RES_OTHER_BENEFIT_RATES_TABLE VARCHAR(100),
	TAX_RES_TOTAL_PREMIUM_TABLE VARCHAR(100),
	ALLOCATION_RULE_TABLE VARCHAR(100),
	CEDED_INPUT_FACTORS_TABLE VARCHAR(100),
	DIV_ACTUAL_DIVIDEND_ADJUSTMENT_TABLE VARCHAR(100),
	DIV_ACTUAL_MULT_FOR_DIVIDEND_ADJUSTMENT VARCHAR(100),
	DIVIDEND_EXPENSE_BASE_METHOD VARCHAR(100),
	DIVIDEND_FORMULA VARCHAR(100),
	FUND1_INVESTMENT VARCHAR(100),
	INTEREST_GAIN_BASIS VARCHAR(100),
	IS_LAPSE_USE_BASE_PLAN VARCHAR(100),
	IS_MORTALITY_USE_BASE_PLAN VARCHAR(100),
	METHOD_FORJ_JOINT_FIRST_LAPSE VARCHAR(100),
	STAT_RESERVE_METHOD_LINK VARCHAR(100),
	TAX_EXEMPT_INV_INC_TABLE VARCHAR(100),
	TAX_FUND_BASED_RESERVE_ADJ_TABLE VARCHAR(100),
	TAX_INPUT_TERMINAL_RES_FACTORS_TABLE VARCHAR(100),
	TAX_RESERVE_METHOD_LINK VARCHAR(100),
	TAXES_IIT_INTEREST_RATE_TABLE VARCHAR(100),
	TREATMENT_OF_GROUP VARCHAR(100),
	BAREME_PAR_BLOCK VARCHAR(100),
	LIVRE_DE_TAUX_POUR_BAREME VARCHAR(100),
	IFRSM_EXPENSES_TABLE VARCHAR(100),
	IFRSM_INTEREST_TABLE VARCHAR(100),
	IFRSM_TAXES_IIT_INTEREST_RATE_TABLE VARCHAR(100),
	IFRSNM_EXPENSES_TABLE VARCHAR(100),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Égale à MD_ACTIVATION_DT lors de l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de la validité de l''enregistrement.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Clé naturelle encyptée (Utilisation de l''algo SHA)  Utilisée par les processus d''insertion et de MÀJ',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Ensemble des attributs de la dimension dont les modifications sont traitées en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint DIM_VALUATION_ASSUMPTIONS_TABLES_PK primary key (SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES)
)COMMENT='Cette table contient les attributs provenant du fichier VAT (ou Valuation Assumptions Tables).  Il s''agit des caractéristiques reliées aux plan représentés par un code de plan Axis. En fait les dimensions DIM_CODE_PLAN_AXIS et DIM_VALUATION_ASSUMPTIONS_TABLES proviennent de la même source de données dont les colonnes ont été réparties entre les deux tables de dimension.'
;
create or replace TABLE FT_COMPTABILITE_DESAGREGEE (
	SK_ID_FT_COMPTABILITE_DESAGREGEE NUMBER(38,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DATE_PERIODE_COMPTABLE NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de fin de période comptable',
	SK_ID_DIM_COMPTE_GL NUMBER(20,0) NOT NULL,
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE.  Ex:  RL, UL, PAR, DI.  Provient de la DIM_COUVERTURE.',
	SK_ID_DIM_MASTER_COA NUMBER(20,0) NOT NULL,
	NO_POLICE VARCHAR(50) NOT NULL COMMENT 'Numéro de la police tel que mentionnée dans l''UDC de la transaction',
	GEN_UID VARCHAR(20) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	SOURCE_SOE VARCHAR(10) NOT NULL COMMENT 'Spécifie la source de SOE à laquelle s''applique le solde.  (Identifié par la nature du compte GL associé)',
	MNT_COMPTABLE NUMBER(38,12) NOT NULL COMMENT 'Montant de solde comptable',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint FT_COMPTABILITE_DESAGREGEE_PK primary key (SK_ID_FT_COMPTABILITE_DESAGREGEE),
	constraint FT_COMPTABILITE_DESAGREGEE_FK_DIM_DATE_ID_DIM_DATE_PERIODE_COMPTABLE foreign key (ID_DATE_PERIODE_COMPTABLE) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_COMPTABILITE_DESAGREGEE_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE)
);
create or replace TABLE FT_COUVERTURE (
	SK_ID_FT_COUVERTURE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EMISSION NUMBER(8,0) COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''émission de la couverture',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE. Relie la couverture au module (RL, UL, PAR, DI). ',
	SK_ID_DIM_DUREE NUMBER(4,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_Duréé. Basée sur un calcul ((Date_evaluation - Date émission de la couverture)/ 365)  Où / représente une division entière.',
	SK_ID_DIM_AGE_EMISSION NUMBER(4,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_AGE en utilisant  l''âge de l''assuré à l''émission de la couverture',
	SK_ID_DIM_AGE_ATTEINT NUMBER(4,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_AGE en utilisant calculant l''âge atteint en additionnant la durée en vigueur à  l''âge de l''assuré à l''émission de la couverture.',
	SK_ID_DIM_STATUT_PREFERENTIEL NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_STATUT_PREFERENTIEL.  Correspond à la classification basée sur la santé de l''assuré réflètant le risque que l''assuré meure alors que sa police est active.   Généralement, il y a 4 ou 5  classifications allant de Preferred Plus à  Standard (ou substandard).  ',
	SK_ID_DIM_SEXE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_SEXE. Détermine le sexe utilisé pour tarifer la couverture ',
	SK_ID_DIM_STATUT_FUMEUR NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_STATUT_FUMEUR. ',
	SK_ID_DIM_TERRITOIRE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur  la table de dimension DIM_TERRITOIRE.  Basée sur le pays et la province.',
	SK_ID_DIM_TRAITE_REASSURANCE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la dimension DIM_TRAITE_REASSURANCE contenant les termes de la convention conclue avec le réassureur.',
	SK_ID_DIM_RESEAU_DISTRIBUTION NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table de dimension DIM_RESEAU_DISTRIBUTION.  Basée sur le code de l''agence et de l''agent à l''origine de la vente de la couverture.',
	SK_ID_DIM_CODE_PLAN_AXIS NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table de dimension DIM_CODE_PLAN_AXIS.  Relie la couverture aux caractéristiques du plan qui lui ait associé',
	SK_ID_VALUATION_ASSUMPTIONS_TABLES NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table de dimension DIM_VALUATION_ASSUMPTIONS_TABLES.  Basée sur le code de plan axis.',
	SK_ID_DIM_RAISON_TERMINAISON NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table dimension DIM_RAISON_TERMINAISON.  Les couvertures en vigueur doivent être reliées à un enregistrement ''NA'' ou sans objet',
	SK_ID_DIM_COUVERTURE_INFO NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table dimension DIM_COUVERTURE_INFO.  La dimension DIM_COUVERTURE_INFO regroupe l''ensemble des attributs servant d''axe d''analyse pour les couvertures.  Ex: ',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	BANDE VARCHAR(50),
	BEN_CURRENT_VALUE NUMBER(28,10) COMMENT 'Montant d''assurance ',
	CODE_JOINT_LIFE VARCHAR(10) COMMENT 'Code indiquant si la couverture d''assurance est conjointe ou individuelle. Domaine de valeurs possibles : I, F, L',
	PRM_USERATING NUMBER(28,10) COMMENT 'Champ utilisé dans le calcul de la surprime',
	RATING_MULT NUMBER(28,10) COMMENT 'Champ utilisé dans le calcul de la surprime',
	RATING_FLAT NUMBER(28,10) COMMENT 'Champ utilisé dans le calcul de la surprime',
	RATING_TEMP NUMBER(28,10) COMMENT 'Champ utilisé dans le calcul de la surprime',
	RATING_TEMPDUR NUMBER(28,10) COMMENT 'Champ utilisé dans le calcul de la surprime',
	PRM_MODE VARCHAR(50) COMMENT 'Indique la fréquence (mode) du paiement de la prime.  Ex: Mensuel, annuel...',
	BEN_OPTION NUMBER(28,10),
	IND_COUVERTURE_TERMINEE BOOLEAN COMMENT 'Indicateur (0/1)  1 --> Couverture terminée, 0 --> Couverture en vigueur',
	IND_GARANTIE BOOLEAN,
	IND_TRANSFORMATION BOOLEAN COMMENT 'Indicateur (0/1) 1 --> Indique les couvertures temporaires qui ont été transformées en couverture permanente.',
	IND_TRAITE_REASSURANCE BOOLEAN COMMENT 'Indique (1/0) l''existance d''un traité de réassurance (TRAITE_REASSURANCE NOT NULL ou <> '''')',
	CODE_PARTICIPATION VARCHAR(50) COMMENT 'Indique le type de participation des couvertures avec participation. Ex: Appliquer le dividende sur le paiement de la prime, placer le dividende dans le but de générer un revenu, ou recevoir le dividende directement,...',
	CODE_TYPE_TRANSFORMATION NUMBER(4,0) COMMENT 'Code indiquant la raison pour laquelle une couverture a été transformée Ex: Fusion de 2 couvertures, Modification de code de plan...',
	NOM_TYPE_TRANSFORMATION VARCHAR(50) COMMENT 'Nom correspondant au type de transformation',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement. Égale à MD_ACTIVATION_DT à l''insertion d''un nouvel enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement ou de fin d''effectivité de l''enregistrement dans le cas d''une mise à jour d''un enregistrement existant.  La modification à un ou plusieurs attributs d''une factless fact table devraient déclencher la MAJ de cette date et l''insertion d''un nouvel enregistrement',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé à l''aide des attributs de la clé naturelle. (Une seule clé naturelle doit être considérée dans le cas où il en existe plus d''une.  Ex: AK1, AK2,...',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait ou de factless fact table.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Calculée en considérant tous les attributs de la table, à l''exception des champs de metadata et les champs constituant les clés naturelles.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.'
)COMMENT='Table de type ''Factless'' qui est utilisée pour faire le suivi des modifications des couvertures.'
;
create or replace TABLE FT_COUVERTURE_GROUPE_CSM (
	SK_ID_FT_COUVERTURE_GROUPE_CSM NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_ASSIGNATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date de l''assignation du groupe CSM à la couverture',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Identifiant unique de la  couverture).',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE. Relie la couverture au module (RL, UL, PAR, DI).',
	SK_ID_DIM_GROUPE_CSM NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table dimension DIM_GROUPE_CSM.  L''assignation à un groupe CSM se fera uniquement pour les couvertures en vigueur ou récemment terminées.',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes. Correspond à la concatenation des champs UIDCouverture et IdSecondaire (Comptoir_XA)',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Si l''enregistrement est inséré pour la première fois = 1900-01-01 Sinon mettre DateExecETL',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Si Nouvel enregistrement alors 2999-12-31 sinon ETL Date Execution - 1 ms',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basnat sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basnat sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL COMMENT 'Indicateur permettant d''identifier les lignes valides (=0) et les lignes présentant une ou plusieurs anomalies (!=0)',
	constraint FT_COUVERTURE_GROUPE_CSM_PK primary key (SK_ID_FT_COUVERTURE_GROUPE_CSM),
	constraint FT_COUVERTURE_GROUPE_CSM_FK1 foreign key (ID_DIM_DATE_ASSIGNATION) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_COUVERTURE_GROUPE_CSM_FK2 foreign key (SK_ID_DIM_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_COUVERTURE(SK_ID_DIM_COUVERTURE),
	constraint FT_COUVERTURE_GROUPE_CSM_FK3 foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE),
	constraint FT_COUVERTURE_GROUPE_CSM_FK4 foreign key (SK_ID_DIM_GROUPE_CSM) references DB_ACT_DEV_DM.DM_VI.DIM_GROUPE_CSM(SK_ID_DIM_GROUPE_CSM)
)COMMENT='Table de faits permettant d''analyser les montants reliés aux bénéfices supplémentaires reliés aux couvertures de morbidité.'
;
create or replace TABLE FT_COUVERTURE_REASSURANCE_GROUPE_CSM (
	SK_ID_FT_COUVERTURE_GROUPE_CSM NUMBER(20,0) NOT NULL autoincrement COMMENT 'Clé technique (surrogate key)',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE. Basé sur le GEN_UID (Identifiant unique de la  couverture).',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE. Relie la couverture au module (RL, UL, PAR, DI).',
	SK_ID_DIM_REASSUREUR NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_REASSUREUR. Relie la couverture au réassureur.',
	SK_ID_DIM_GROUPE_CSM_REASSURANCE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table dimension DIM_GROUPE_CSM. L''assignation à un groupe CSM se fera uniquement pour les couvertures en vigueur ou récemment terminées.',
	SK_ID_DIM_GROUPE_CSM_DIRECT NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table dimension DIM_GROUPE_CSM. L''assignation à un groupe CSM se fera uniquement pour les couvertures en vigueur ou récemment terminées.',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture. Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes. Correspond à la concatenation des champs UIDCouverture et IdSecondaire (Comptoir_XA)',
	NO_SEQUENCE NUMBER(2,0) NOT NULL COMMENT 'Numéro de séquence nécessaire car une couverture peut être réassurée par plusieurs réassureur, ou selon différentes conditions',
	CODE_REASSUREUR VARCHAR(50) NOT NULL COMMENT 'Code identifiant le réassureur.  Fait partie de la clé naturelle.',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début de validité.  Toujours égale à 1900-01-01',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière modification de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin de validité.  Toujours égale à 2999-12-31',
	MD_HASH_NAT_KEY VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basant sur l''ensemble des champs constituant la clé naturelle de la table',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basnat sur l''ensemble des colonnes dont les modifications sont suivis en type 1',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Hash key calculé en se basnat sur l''ensemble des colonnes dont les modifications sont suivis en type 2',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL COMMENT 'Indicateur permettant d''identifier les lignes valides (=0) et les lignes présentant une ou plusieurs anomalies (!=0)',
	constraint FFT_COUVERTURE_REASSURANCE_GROUPE_CSM_PK primary key (SK_ID_FT_COUVERTURE_GROUPE_CSM),
	constraint FT_COUVERTURE_REASSURANCE_GROUPE_CSM_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE)
);
create or replace TABLE FT_FONDS_RECLAMATION (
	SK_ID_FT_FONDS_RECLAMATION NUMBER(38,0) autoincrement,
	NO_POLICE VARCHAR(50),
	GEN_UID VARCHAR(20),
	ID_DATE_EVALUATION NUMBER(38,0),
	SK_ID_COUVERTURE NUMBER(38,0),
	SK_ID_RISQUE NUMBER(38,0),
	SK_ID_INFO_COUVERTURE NUMBER(38,0),
	SK_ID_CD_PLAN_AXIS NUMBER(38,0),
	SK_ID_VALUATION_ASSUMPTIONS_TABLES NUMBER(38,0),
	SK_ID_TERRITOIRE NUMBER(38,0),
	SK_ID_SURPRIME NUMBER(38,0),
	SK_ID_MODULE_COUVERTURE NUMBER(38,0),
	SK_ID_RESEAU_DISTRIBUTION NUMBER(38,0),
	SK_ID_REASSURANCE NUMBER(38,0),
	SK_ID_MONTANT_ASSURANCE NUMBER(38,0),
	ID_DATE_EMISSION_COUVERTURE NUMBER(38,0),
	SK_ID_AGE_EMISSION NUMBER(38,0),
	SK_ID_DUREE NUMBER(38,0),
	SK_ID_AGE_ATTEINT NUMBER(38,0),
	SK_ID_SEXE NUMBER(38,0),
	SK_ID_TABAGISME NUMBER(38,0),
	SK_ID_STATUT_PREFERENTIEL NUMBER(38,0),
	SK_ID_RAISON_TERMINAISON NUMBER(38,0),
	SK_ID_PRODUIT NUMBER(38,0),
	FUNDS_SURRENDERS NUMBER(28,10),
	FUNDS_DEATH_CLAIMS NUMBER(28,10),
	FUNDS_OTHER_MOVEMENT NUMBER(28,10),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE FT_SOE_CASHFLOW (
	SK_ID_FT_SOE_CASHFLOW NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE.  Ex:  RL, UL, PAR, DI.  Est déduit à partir du nom du fichier source provenant d''Axis',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	CEDED_ACTUAL_CASHFLOW_BONUS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_COMMISSION NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_CREDITEDINTEREST NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_DEPOSIT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_DESIGNATEDFUND NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_EXPENSE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_EXPENSECHARGE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIVIDENDDISABLED NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC1 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC2 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC3 NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_MISCON NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_NOTTAKENUP NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_OTHERBENEFITCHARGE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_PARTIALWITHDRAWAL NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_PREMIUM NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_PREMIUMLOAD NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_PREMIUMTAX NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_RISKCHARGE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_BONUS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_COMMISSION NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_CREDITEDINTEREST NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_DEPOSIT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_DESIGNATEDFUND NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_EXPENSE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIVIDENDDISABLED NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC1 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC2 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC3 NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_EXPENSECHARGE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_MISCON NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_NOTTAKENUP NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_OTHERBENEFITCHARGE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_PARTIALWITHDRAWAL NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_PREMIUM NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_PREMIUMLOAD NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_PREMIUMTAX NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_REINSURANCE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_RISKCHARGE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_BONUS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_COMMISSION NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_CREDITEDINTEREST NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_DEPOSIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_DESIGNEDFUND NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_EXPENSE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_EXPENSECHARGE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIVIDENDDISABLED NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC1 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC2 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC3 NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_MISCOFF NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_MISCON NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_NOTTAKENUP NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_OTHERBENEFITCHARGE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_PARTIALWITHDRAWAL NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_PREMIUM NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_PREMIUMLOAD NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_PREMIUMTAX NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_RISKCHARGE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_BONUS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_COMMISSION NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_CREDITEDINTEREST NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_DEPOSIT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_DESIGNATEDFUND NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_EXPENSE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_EXPENSECHARGE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIVIDENDDISABLED NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC1 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC2 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC3 NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_MISCOFF NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_MISCON NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_NOTTAKENUP NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_OTHERBENEFITCHARGE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_PARTIALWITHDRAWAL NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_PREMIUM NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_PREMIUMLOAD NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_PREMIUMTAX NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_RISKCHARGE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_SURRENDER NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint FT_SOE_CASHFLOW_PK primary key (SK_ID_FT_SOE_CASHFLOW),
	constraint FT_SOE_CASHFLOW_FK_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOE_CASHFLOW_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE),
	constraint FT_SOE_CASHFLOW_FK_DIM_COUVERTURE_SK_ID_DIM_COUVERTURE foreign key (SK_ID_DIM_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_COUVERTURE(SK_ID_DIM_COUVERTURE)
)COMMENT='Table de faits permettant d''analyser les montants reliés à au cashflow par source (ou risque) de SOE.'
;
create or replace TABLE FT_SOE_EXPENSE_COMPENSATION (
	SK_ID_FT_SOE_EXPENSE_COMPENSATION NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation.  La date d''évaluation correspond à la date des données dans le rapport',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE  Le module regroupe les couvertures par grande ligne d''affaire',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur la date d''évaluation et POLICY_ID.  Voir la règle de transformation pour relier correctement la table de fait à la dimension coverage',
	GEN_UID VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes. Le POLICY_ID est une concatenation de champs servant à identifier la couverture',
	POLICY_ID_EX VARCHAR(30) COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes. Le POLICY_ID_EX est une concatenation de champs servant à identifier de façon unique une couverture',
	REPRESENTATIVE_BONUS_GROSSCHARGEBACK_FIRSTYEARCOMP NUMBER(28,10) NOT NULL,
	REPRESENTATIVE_BONUS_GROSSBONUS_FIRSTYEAR NUMBER(28,10) NOT NULL,
	REPRESENTATIVE_BONUS_GROSSCOMMISSION_FIRSTYEAR NUMBER(28,10) NOT NULL,
	COMMISSION_GROSSCHARGEBACK_FIRSTYEARCOMP NUMBER(28,10),
	COMMISSION_GROSSCOMMISSION_FIRSTYEAR NUMBER(28,10),
	OVERRIDE_GROSSCHARGEBACK_FIRSTYEARCOMP NUMBER(28,10),
	OVERRIDE_GROSSCOMMISSION_FIRSTYEAR NUMBER(28,10),
	ACQUISITION_ATTRIBUTABLE_EXPENSE_EXPENSE_FIRSTYEAR NUMBER(28,10),
	ADMINISTRATION_ATTRIBUTABLE_EXPENSE_EXPENSE_FIRSTYEAR NUMBER(28,10),
	DIRECTOR_BONUS_GROSSCHARGEBACK_FIRSTYEARCOMP NUMBER(28,10),
	DIRECTOR_BONUS_GROSSBONUS_FIRSTYEAR NUMBER(28,10),
	DIRECTOR_BONUS_GROSSCOMMISSION_FIRSTYEAR NUMBER(28,10),
	MINIMUM_PREMIUM_GROSSCHARGEBACK_FIRSTYEARCOMP NUMBER(28,10),
	MINIMUM_PREMIUM_GROSSBONUS_FIRSTYEAR NUMBER(28,10),
	MINIMUM_PREMIUM_GROSSCOMMISSION_FIRSTYEAR NUMBER(28,10),
	OTHER_BENEFIT_ATTRIBUTABLE_EXPENSE_EXPENSE_FIRSTYEAR NUMBER(28,10),
	OVERRIDE_GROSSBONUS_FIRSTYEAR NUMBER(28,10),
	COMMISSION_GROSSBONUS_FIRSTYEAR NUMBER(28,10),
	ALLOWANCE_FOR_SERVICING_IN_FORCE_GROSSCHARGEBACK_FIRSTYEARCOMP NUMBER(28,10),
	ALLOWANCE_FOR_SERVICING_IN_FORCE_GROSSCOMMISSION_FIRSTYEAR NUMBER(28,10),
	ALLOWANCE_FOR_SERVICING_IN_FORCE_GROSSBONUS_FIRSTYEAR NUMBER(28,10),
	FLAT_NL_FLEX_5$_NON_INFLATABLE_EXPENSE_FIRSTYEAR NUMBER(28,10),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début d''activation de l''enregistrement.  Correspond à la date de fin de période.',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière mise à jour de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin d''activation.  Corresponds à 2999-12-31 pour cette table de faits',
	MD_HASH_NAT_KEY VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL COMMENT 'Champ technique utilisé pour identifier rapidement les enregistrements comportant une ou plusieurs anomalies.',
	constraint FT_SOE_EXPENSE_COMPENSATION_PK primary key (SK_ID_FT_SOE_EXPENSE_COMPENSATION),
	constraint FT_SOE_EXPENSE_COMPENSATION_FK_DIM_DATE_SK_ID_DIM_DATE foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOE_EXPENSE_COMPENSATION_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE)
);
create or replace TABLE FT_SOE_FUND_RELEASE (
	SK_ID_FT_SOE_FUND_RELEASE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE.  Ex:  RL, UL, PAR, DI.  Est déduit à partir du nom du fichier source provenant d''Axis',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	CEDED_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_LATENB NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_MISCON NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve directe RÉELLE - Abandon',
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_SURRENDER NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_LATENB NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_MISCON NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve directe attendue - Abandon',
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_MISCOFF NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_SURRENDER NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_LATENB NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_MISCON NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_MISCOFF NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve réassurance RÉELLE - Abadon ',
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_SURRENDER NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_LATENB NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_MISCON NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_MISCOFF NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve réassurance attendue - Abandon',
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_SURRENDER NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint FT_SOE_FUND_RELEASE_PK primary key (SK_ID_FT_SOE_FUND_RELEASE),
	constraint FT_SOE_FUND_RELEASE_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE),
	constraint FT_SOE_FUND_RELEASE_FK_DIM_COUVERTURE_SK_ID_DIM_COUVERTURE foreign key (SK_ID_DIM_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_COUVERTURE(SK_ID_DIM_COUVERTURE),
	constraint FT_SOE_FUND_RELEASE_FK_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE)
)COMMENT='Table de faits permettant d''analyser les montants reliés à la libération de la réserve par source (ou risque) de SOE.'
;
create or replace TABLE FT_SOE_INVESTMENT_COMPONENT (
	SK_ID_FT_SOE_INVESTMENT_COMPONENT NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE.  Ex:  RL, UL, PAR, DI.  Est déduit à partir du nom du fichier source provenant d''Axis',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	CEDED_ACTUAL_INVCOMP_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_INVCOMP_LAPSE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_INVCOMP_OTHERBEN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_INVCOMP_SURVIVORS NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_LAPSE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_OTHERBEN NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_SURVIVORS NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_LAPSE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_OTHERBEN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_SURVIVORS NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_LAPSE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_OTHERBEN NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_SURVIVORS NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_INVCOMP_INCIDENCE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_INVCOMP_INCIDENCE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_INVCOMP_INCIDENCE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_INVCOMP_INCIDENCE NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint FT_SOE_INVESTMENT_COMPONENT_PK primary key (SK_ID_FT_SOE_INVESTMENT_COMPONENT),
	constraint FT_SOE_INVESTMENT_COMPONENT_FK_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOE_INVESTMENT_COMPONENT_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE),
	constraint FT_SOE_INVESTMENT_COMPONENT_FK_DIM_COUVERTURE_SK_ID_DIM_COUVERTURE foreign key (SK_ID_DIM_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_COUVERTURE(SK_ID_DIM_COUVERTURE)
)COMMENT='Table de faits permettant d''analyser les montants de composantes d''investissement par risque '
;
create or replace TABLE FT_SOE_OTHER_BENEFITS (
	SK_ID_FT_SOE_OTHER_BENEFITS NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE.  Ex:  RL, UL, PAR, DI.  Est déduit à partir du nom du fichier source provenant d''Axis',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_BENEFICE_SUPPLEMENTAIRE',
	SK_ID_DIM_ORIGINE_MONTANT NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_ORIGINE_MONTANT.  Indique si le montant est direct (GROSS) ou Ceded ',
	SK_ID_DIM_TYPE_PROJECTION NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_ORIGINE_MONTANT.  Indique si le montant est direct (GROSS) ou Ceded ',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	AXIS_RUN_ID NUMBER(20,0) NOT NULL COMMENT 'Numéro identifiant le traitement AXIS utilisé pour générer les données.  Il devrait y avoir un run id par module et date d''évaluation',
	AMOUNT_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL COMMENT 'Indicateur permettant d''identifier les lignes valides (=0) et les lignes présentant une ou plusieurs anomalies (!=0)',
	constraint FT_SOE_OTHER_BENEFITS_PK primary key (SK_ID_FT_SOE_OTHER_BENEFITS),
	constraint FT_SOE_OTHER_BENEFITS_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE),
	constraint FT_SOE_OTHER_BENEFITS_FK_DIM_COUVERTURE_SK_ID_DIM_COUVERTURE foreign key (SK_ID_DIM_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_COUVERTURE(SK_ID_DIM_COUVERTURE),
	constraint FT_SOE_OTHER_BENEFITS_FK_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOE_OTHER_BENEFITS_FK_DIM_BENEFICE_SUPPLEMENTAIRE_SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE foreign key (SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE) references DB_ACT_DEV_DM.DM_VI.DIM_BENEFICE_SUPPLEMENTAIRE(SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE),
	constraint FT_SOE_OTHER_BENEFITS_FK_DIM_ORIGINE_MONTANT_SK_ID_DIM_ORIGINE_MONTANT foreign key (SK_ID_DIM_ORIGINE_MONTANT) references DB_ACT_DEV_DM.DM_VI.DIM_ORIGINE_MONTANT(SK_ID_DIM_ORIGINE_MONTANT),
	constraint FT_SOE_OTHER_BENEFITS_FK_DIM_TYPE_PROJECTION_SK_ID_DIM_TYPE_PROJECTION foreign key (SK_ID_DIM_TYPE_PROJECTION) references DB_ACT_DEV_DM.DM_VI.DIM_TYPE_PROJECTION(SK_ID_DIM_TYPE_PROJECTION)
)COMMENT='Table de faits permettant d''analyser les montants reliés aux bénéfices supplémentaires reliés aux couvertures de morbidité.'
;
create or replace TABLE FT_SOE_RESERVE_AT_INITIAL_RECOGNITION (
	SK_ID_FT_SOE_RESERVE_AT_INITIAL_RECOGNITION NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation.  La date d''évaluation correspond à la date des données dans le rapport',
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE  Le module regroupe les couvertures par grande ligne d''affaire',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur la date d''évaluation et POLICY_ID.  Voir la règle de transformation pour relier correctement la table de fait à la dimension coverage',
	GEN_UID VARCHAR(30) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes. Le POLICY_ID est une concatenation de champs servant à identifier la couverture',
	POLICY_ID_EX VARCHAR(30) COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes. Le POLICY_ID_EX est une concatenation de champs servant à identifier de façon unique une couverture',
	RUN_ID VARCHAR(30),
	SCENARIO_ID VARCHAR(30),
	OVERRIDE_ID VARCHAR(30),
	ID VARCHAR(30),
	NAME VARCHAR(50),
	RA_AT_INITIAL_RECOGNITION NUMBER(28,10) NOT NULL,
	BEL_AT_INITIAL_RECOGNITION NUMBER(28,10) NOT NULL,
	RA_EXPER_ADJ_DUE_TO_NEW_CESSIONS NUMBER(28,10) NOT NULL,
	BEL_EXPER_ADJ_DUE_TO_NEW_CESSIONS NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début d''activation de l''enregistrement.  Correspond à la date de fin de période.',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière mise à jour de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin d''activation.  Corresponds à 2999-12-31 pour cette table de faits',
	MD_HASH_NAT_KEY VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_VALID NUMBER(3,0) NOT NULL COMMENT 'Champ technique utilisé pour identifier rapidement les enregistrements comportant une ou plusieurs anomalies.',
	constraint FT_SOE_RESERVE_AT_INITIAL_RECOGNITION_PK primary key (SK_ID_FT_SOE_RESERVE_AT_INITIAL_RECOGNITION),
	constraint FT_SOE_RESERVE_AT_INITIAL_RECOGNITION_FK_DIM_DATE_SK_ID_DIM_DATE foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOE_RESERVE_AT_INITIAL_RECOGNITION_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE)
);
create or replace TABLE FT_SOE_RESERVE_RELEASE (
	SK_ID_FT_SOE_RESERVE_RELEASE NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_EVALUATION NUMBER(8,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_DATE en utilisant la date d''évaluation',
	SK_ID_DIM_TYPE_LIBERATION_RESERVE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_TYPE_LIBERATION_RESERVE en utilisant  le type de libération égale à RA ou BEL',
	SK_ID_DIM_TYPE_TAUX_INTERET NUMBER(20,0) NOT NULL,
	SK_ID_DIM_MODULE_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_MODULE_COUVERTURE.  Ex:  RL, UL, PAR, DI.  Est déduit à partir du nom du fichier source provenant d''Axis',
	SK_ID_DIM_COUVERTURE NUMBER(20,0) NOT NULL COMMENT 'Clé pointant sur la table DIM_COUVERTURE.  Basé sur le GEN_UID (Numéro de couverture). ',
	GEN_UID VARCHAR(15) NOT NULL COMMENT 'Identifiant unique de la couverture.  Clé d''affaire de la couverture conservée dans la table de faits pour faciliter les requêtes.',
	GROSS_ACTUAL_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_LAPSE NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve directe RÉELLE - Abandon',
	GROSS_ACTUAL_RELEASE_ON_MISC_OFF NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_MISC_ON NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_LAPSE NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve directe attendue - Abandon',
	GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_LATENB NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_NEWCESSIONS NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_PEINFTRUEUP NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_POLICYCHANGES NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB NUMBER(28,10) NOT NULL,
	GROSS_EXP_ADJUSTMENT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_LAPSE NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve réassurance RÉELLE - Abadon ',
	CEDED_ACTUAL_RELEASE_ON_MISC_OFF NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_MISC_ON NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_RELEASE_ON_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_RELEASE_ON_LAPSE NUMBER(28,10) NOT NULL COMMENT 'Libération de réserve réassurance attendue - Abandon',
	CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_LATENB NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_NEWCESSIONS NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_PEINFTRUEUP NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_POLICYCHANGES NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB NUMBER(28,10) NOT NULL,
	CEDED_EXP_ADJUSTMENT_REINSTATEMENT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_LIC_INCREASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_LIC_INCREASE_ON_MISC_ON NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_LIC_INCREASE_ON_RE_OPEN NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_LIC_RELEASE_ON_BEN_EXHAUST NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_LIC_RELEASE_ON_DI_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_LIC_RELEASE_ON_MISC_OFF NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_LIC_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_LIC_RELEASE_ON_SETTLEMENT NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_BEN_EXHAUST NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_DI_DEATH NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	CEDED_ACTUAL_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_LIC_RELEASE_ON_BEN_EXHAUST NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_LIC_RELEASE_ON_DI_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_RELEASE_ON_BEN_EXHAUST NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_RELEASE_ON_DI_DEATH NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_RELEASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	CEDED_EXPECTED_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_LIC_INCREASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_LIC_INCREASE_ON_MISC_ON NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_LIC_INCREASE_ON_RE_OPEN NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_LIC_RELEASE_ON_BEN_EXHAUST NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_LIC_RELEASE_ON_DI_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_LIC_RELEASE_ON_MISC_OFF NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_LIC_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_LIC_RELEASE_ON_SETTLEMENT NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_BEN_EXHAUST NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_DI_DEATH NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	GROSS_ACTUAL_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_LIC_RELEASE_ON_BEN_EXHAUST NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_LIC_RELEASE_ON_DI_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_BEN_EXHAUST NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_DI_DEATH NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_INCIDENCE NUMBER(28,10) NOT NULL,
	GROSS_EXPECTED_RELEASE_ON_RECOVERY NUMBER(28,10) NOT NULL,
	GROSS_LIC_ROLL_FORWARD_BELIC_EXP_ADJUSTMENT_PEINFTRUEUP NUMBER(28,10) NOT NULL,
	GROSS_LIC_ROLL_FORWARD_RALIC_EXP_ADJUSTMENT_PEINFTRUEUP NUMBER(28,10) NOT NULL,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date d''insertion de l''enregistrement',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de la dernière mise à jour de l''enregistrement.  Devrait toujours être égale à MD_ACTIVATION_DT, sauf pour traitement spécifique de mise à jour/correction.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Correspond à la date de \"\"\"\"suppression\"\"\"\" de l''enregistrement.  Pour une table de faits devrait toujours égale à ''1900-01-01'' sauf pour traitement exceptionnel.',
	MD_HASH_NAT_KEY VARCHAR(40) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	constraint FT_SOE_RESERVE_RELEASE_PK primary key (SK_ID_FT_SOE_RESERVE_RELEASE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_DATE_ID_DIM_DATE_EVALUATION foreign key (ID_DIM_DATE_EVALUATION) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_TYPE_LIBERATION_RESERVE_SK_ID_DIM_TYPE_LIBERATION_RESERVE foreign key (SK_ID_DIM_TYPE_LIBERATION_RESERVE) references DB_ACT_DEV_DM.DM_VI.DIM_TYPE_LIBERATION_RESERVE(SK_ID_DIM_TYPE_LIBERATION_RESERVE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_MODULE_COUVERTURE_SK_ID_DIM_MODULE_COUVERTURE foreign key (SK_ID_DIM_MODULE_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_MODULE_COUVERTURE(SK_ID_DIM_MODULE_COUVERTURE),
	constraint FT_SOE_RESERVE_RELEASE_FK_DIM_COUVERTURE_SK_ID_DIM_COUVERTURE foreign key (SK_ID_DIM_COUVERTURE) references DB_ACT_DEV_DM.DM_VI.DIM_COUVERTURE(SK_ID_DIM_COUVERTURE)
)COMMENT='Table de faits permettant d''analyser les montants reliés à la libération de la réserve par source (ou risque) de SOE.'
;
create or replace TABLE FT_SOLDE_GL (
	SK_ID_FT_SOLDE_GL NUMBER(20,0) NOT NULL autoincrement COMMENT 'Surrogate Key utilisée pour des fins techniques',
	ID_DIM_DATE_FIN_PERIODE_COMPTABLE NUMBER(8,0) NOT NULL COMMENT 'Clé étrangère pointant sur la table DM_VI.DIM_DATE en se basant sur la date de fin de période comptable',
	SK_ID_DIM_COMPTE_GL NUMBER(20,0) NOT NULL COMMENT 'Clé étrangère pointant sur la table DM_VI.DIM_COMPTE_GL. Basée sur l''ensemble des champs constituant la charte de compte',
	SK_ID_DIM_MASTER_COA NUMBER(20,0) NOT NULL COMMENT 'Clé étrangère pointant sur la table DM_VI.DIM_MASTER_COA.  Basée sur l''ensemble des champs constituant la clé naturelle de la dimension',
	JOURNAL VARCHAR(256) NOT NULL,
	SOURCE VARCHAR(200) NOT NULL,
	SYSTEME_SOURCE VARCHAR(256) NOT NULL,
	TYPE_ENTREE VARCHAR(256) NOT NULL,
	ID_PRIMAIRE VARCHAR(500) COMMENT 'Correspond à l''UDC - Dans le cas des prestations, corresponds au numéro de police.',
	ID_SECONDAIRE VARCHAR(500),
	ID_RECLAMATION VARCHAR(500),
	ID_REASSURANCE VARCHAR(500),
	DEBIT NUMBER(38,6) NOT NULL,
	CREDIT NUMBER(38,6) NOT NULL,
	SOLDE NUMBER(38,6) NOT NULL COMMENT 'Montant du solde (DEBIT - CREDIT)',
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de début d''activation de l''enregistrement.  Correspond à la date de fin de période.',
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de la dernière mise à jour de l''enregistrement.',
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9) NOT NULL COMMENT 'Date de fin d''activation.  Corresponds à 2999-12-31 pour cette table de faits',
	MD_HASH_NAT_KEY VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_1 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_HASHDIFF_TYPE_2 VARCHAR(50) NOT NULL COMMENT 'Égale à ''0''. Pas utilisé dans le chargement de cette table de fait.',
	MD_CREATION_AUDIT_ID NUMBER(20,0) NOT NULL COMMENT 'Identifiant de l''exécution du processus de chargement.',
	MD_ROW_IS_NOT_VALID NUMBER(3,0) NOT NULL COMMENT 'Champ technique utilisé pour identifier rapidement les enregistrements comportant une ou plusieurs anomalies.',
	constraint FT_SOLDE_GL_PK primary key (SK_ID_FT_SOLDE_GL),
	constraint FT_SOLDE_GL_FK_DIM_DATE_ID_DIM_DATE_PERIODE_COMPTABLE foreign key (ID_DIM_DATE_FIN_PERIODE_COMPTABLE) references DB_ACT_DEV_DM.DM_VI.DIM_DATE(ID_DIM_DATE),
	constraint FT_SOLDE_GL_FK_DIM_COMPTE_GL_SK_ID_DIM_COMPTE_GL foreign key (SK_ID_DIM_COMPTE_GL) references DB_ACT_DEV_DM.DM_VI.DIM_COMPTE_GL(SK_ID_DIM_COMPTE_GL),
	constraint FT_SOLDE_GL_FK_DIM_MASTER_COA_SK_ID_DIM_MASTER_COA foreign key (SK_ID_DIM_MASTER_COA) references DB_ACT_DEV_DM.DM_VI.DIM_MASTER_COA(SK_ID_DIM_MASTER_COA)
);
CREATE OR REPLACE PROCEDURE "SP_CONV_M_FACT_COUVERTURE_UPD2"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "MERGE into DB_ACT_"+ ENV +"_DM.DM_VI.FT_COUVERTURE t using (select * from DB_ACT_"+ ENV +"_DM.DM_VI_TRAVAIL.VW_VI_COUVERTURE) s on t.MD_HASH_NAT_KEY = s.MD_HASH_NAT_KEY and t.SK_ID_DIM_MODULE_COUVERTURE = s.SK_ID_DIM_MODULE_COUVERTURE and t.MD_OBSOLESCENCE_DT >= ''2999-12-30'' and t.MD_ACTIVATION_DT < s.MD_START_DT when matched then update set t.MD_OBSOLESCENCE_DT = dateadd(second,-1,s.MD_START_DT);";

   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';
CREATE OR REPLACE PROCEDURE "SP_CONV_M_FT_COMPTABILITE_DESAGREGEE_INS"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command ="INSERT INTO DB_ACT_" + ENV + "_DM.DM_VI.FT_COMPTABILITE_DESAGREGEE(NO_POLICE,RISQUE,GEN_UID,ID_DATE_EVALUATION,SK_ID_COUVERTURE,SK_ID_CD_PLAN_AXIS,SK_ID_VALUATION_ASSUMPTIONS_TABLES,SK_ID_TERRITOIRE,SK_ID_MODULE_COUVERTURE,SK_ID_RESEAU_DISTRIBUTION,ID_DATE_EMISSION_COUVERTURE,SK_ID_AGE_EMISSION,SK_ID_DUREE,SK_ID_AGE_ATTEINT,SK_ID_SEXE,SK_ID_TABAGISME,SK_ID_STATUT_PREFERENTIEL,SK_ID_RAISON_TERMINAISON,MNT_COMPTABLE_REAS,MNT_COMPTABLE_DIRECT,MD_MODIFICATION_DT,MD_CREATION_AUDIT_ID) SELECT DC.NO_POLICE, VVC.RISQUE, VVC.GEN_UID, VVC.ID_EVALUATION_DT, case when DC.SK_ID_DIM_COUVERTURE = '''' then ''-1'' else DC.SK_ID_DIM_COUVERTURE end as o_SK_ID_COUVERTURE, case when DCPA.SK_ID_DIM_CODE_PLAN_AXIS = '''' then ''-1'' else DCPA.SK_ID_DIM_CODE_PLAN_AXIS end as o_SK_ID_CD_PLAN_AXIS, case when DVAT.SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES = '''' then ''-1'' else DVAT.SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES end as o_SK_ID_VALUATION_ASSUMPTION_TABLES, case when DT.SK_ID_DIM_TERRITOIRE = '''' then ''-1'' else DT.SK_ID_DIM_TERRITOIRE end as o_SK_ID_TERRITOIRE, case when DMC.SK_ID_DIM_MODULE_COUVERTURE = '''' then ''-1'' else DMC.SK_ID_DIM_MODULE_COUVERTURE end as o_SK_ID_MODULE_COUVERTURE, case when DRD.SK_ID_DIM_RESEAU_DISTRIBUTION = '''' then ''-1'' else DRD.SK_ID_DIM_RESEAU_DISTRIBUTION end as o_SK_ID_RESEAU_DISTRIBUTION, VVC.ID_DATE_EMISSION_COUVERTURE, case when DA.SK_ID_DIM_AGE = '''' then ''-1'' else DA.SK_ID_DIM_AGE end as o_SK_ID_AGE_EMISSION, case when DD.SK_ID_DIM_DUREE = '''' then ''-1'' else DD.SK_ID_DIM_DUREE end as o_SK_ID_DUREE, case when DA.SK_ID_DIM_AGE = '''' then ''-1'' else DA.SK_ID_DIM_AGE end as o_SK_ID_AGE_ATTEINT, case when DS.SK_ID_DIM_SEXE = '''' then ''-1'' else DS.SK_ID_DIM_SEXE end as o_SK_ID_DIM_SEXE, case when DSF.SK_ID_DIM_STATUT_FUMEUR = '''' then ''-1'' else DSF.SK_ID_DIM_STATUT_FUMEUR end as o_SK_ID_STATUT_FUMEUR, case when DSP.SK_ID_DIM_STATUT_PREFERENTIEL = '''' then ''-1'' else DSP.SK_ID_DIM_STATUT_PREFERENTIEL end as o_SK_ID_STATUT_PREFERENTIEL, case when DRT.SK_ID_DIM_RAISON_TERMINAISON = '''' then ''-1'' else DRT.SK_ID_DIM_RAISON_TERMINAISON end as o_SK_ID_RAISON_TERMINAISON, VVC.MNT_COMPTABLE_REAS, VVC.MNT_COMPTABLE_DIRECT, TO_DATE( TO_CHAR( CURRENT_TIMESTAMP,''YYYY-MM-DD HH:MI:SS'' ), ''YYYY-MM-DD HH:MI:SS'') as o_MODIFICATION_DT, ''-1'' as o_CREATION_AUDIT_ID FROM DB_ACT_" + ENV + "_DWH.PUBLICATION_VI.VW_VI_COMPTABILITEAJUSTE VVC LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_COUVERTURE DC ON DC.MD_HASH_NAT_KEY = VVC.DIM_COUVERTURE_HASH_KEY  LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_CODE_PLAN_AXIS DCPA ON DCPA.MD_HASH_NAT_KEY = VVC.DIM_CD_PLAN_AXIS_HASH_NAT_KEY  LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_VALUATION_ASSUMPTIONS_TABLES DVAT ON DVAT.MD_HASH_NAT_KEY=VVC.DIM_CD_PLAN_AXIS_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_TERRITOIRE DT ON DT.MD_HASH_NAT_KEY=VVC.DIM_TERRITOIRE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_RESEAU_DISTRIBUTION DRD ON DRD.MD_HASH_NAT_KEY=VVC.DIM_RESEAU_DISTRIBUTION_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_AGE DA ON DA.MD_HASH_NAT_KEY=VVC.DIM_AGE_ATTEINT_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_DUREE DD ON DD.MD_HASH_NAT_KEY=VVC.DIM_DUREE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_MODULE_COUVERTURE DMC ON DMC.MD_HASH_NAT_KEY=VVC.DIM_MODULE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_SEXE DS ON DS.MD_HASH_NAT_KEY=VVC.DIM_SEXE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_STATUT_FUMEUR DSF ON DSF.MD_HASH_NAT_KEY=VVC.DIM_STATUT_FUMEUR_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_STATUT_PREFERENTIEL DSP ON DSP.MD_HASH_NAT_KEY=VVC.DIM_STATUT_PREFERENTIEL_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_RAISON_TERMINAISON DRT ON DRT.MD_HASH_NAT_KEY=VVC.DIM_RAISON_TERMINAISON_HASH_NAT_KEY WHERE  DC.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DC.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DCPA.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DCPA.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DVAT.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DVAT.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DT.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DT.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DRD.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DRD.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DA.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DA.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DD.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DD.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DMC.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DMC.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DS.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DS.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DSF.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DSF.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DSP.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DSP.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT AND DRT.MD_ACTIVATION_DT <= VVC.EVALUATION_DT AND DRT.MD_OBSOLESCENCE_DT > VVC.EVALUATION_DT;";
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
  result = "Succeeded!";
}
catch (err) {
    result = "Failed: Code: " + err.code + " \\n State: " + err.state;
    result += " \\n Message: " + err.message;
    result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
    throw result;
  }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_M_FT_FONDS_RECLAMATION_INS"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command ="INSERT INTO DB_ACT_" + ENV + "_DM.DM_VI.FT_FONDS_RECLAMATION(NO_POLICE,GEN_UID,ID_DATE_EVALUATION,SK_ID_COUVERTURE,SK_ID_INFO_COUVERTURE,SK_ID_CD_PLAN_AXIS,SK_ID_VALUATION_ASSUMPTIONS_TABLES,SK_ID_TERRITOIRE,SK_ID_SURPRIME,SK_ID_MODULE_COUVERTURE,SK_ID_RESEAU_DISTRIBUTION,SK_ID_REASSURANCE,SK_ID_MONTANT_ASSURANCE,ID_DATE_EMISSION_COUVERTURE,SK_ID_AGE_EMISSION,SK_ID_DUREE,SK_ID_SEXE,SK_ID_TABAGISME,SK_ID_STATUT_PREFERENTIEL,SK_ID_RAISON_TERMINAISON,SK_ID_PRODUIT,SK_ID_AGE_ATTEINT,FUNDS_SURRENDERS,FUNDS_DEATH_CLAIMS,FUNDS_OTHER_MOVEMENT,MD_MODIFICATION_DT,MD_CREATION_AUDIT_ID)SELECT DC.NO_POLICE,VVFR.GEN_UID,VVFR.ID_EVALUATION_DT,CASE WHEN DC.SK_ID_DIM_COUVERTURE = '''' THEN ''-1'' ELSE DC.SK_ID_DIM_COUVERTURE END AS o_SK_ID_COUVERTURE,CASE WHEN DIC.SK_ID_INFO_COUVERTURE = '''' THEN ''-1'' ELSE DIC.SK_ID_INFO_COUVERTURE END AS o_SK_ID_INFO_COUVERTURE,CASE WHEN DCPA.SK_ID_DIM_CODE_PLAN_AXIS = '''' THEN ''-1'' ELSE DCPA.SK_ID_DIM_CODE_PLAN_AXIS END AS o_SK_ID_CD_PLAN_AXIS,CASE WHEN DVAT.SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES = '''' THEN ''-1'' ELSE DVAT.SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES END AS o_SK_ID_VALUATION_ASSUMPTION_TABLES,CASE WHEN DT.SK_ID_DIM_TERRITOIRE = '''' THEN ''-1'' ELSE DT.SK_ID_DIM_TERRITOIRE END AS o_SK_ID_TERRITOIRE,CASE WHEN DSPR.SK_ID_SURPRIME = '''' THEN ''-1'' ELSE DSPR.SK_ID_SURPRIME END AS o_SK_SURPRIME,CASE WHEN DMC.SK_ID_DIM_MODULE_COUVERTURE = '''' THEN ''-1'' ELSE DMC.SK_ID_DIM_MODULE_COUVERTURE END AS o_SK_ID_MODULE_COUVERTURE,CASE WHEN DRD.SK_ID_DIM_RESEAU_DISTRIBUTION = '''' THEN ''-1'' ELSE DRD.SK_ID_DIM_RESEAU_DISTRIBUTION END AS o_SK_ID_RESEAU_DISTRIBUTION,CASE WHEN DR.SK_ID_REASSURANCE = '''' THEN ''-1'' ELSE DR.SK_ID_REASSURANCE END AS o_SK_ID_REASSURANCE,CASE WHEN DMA.SK_ID_MONTANT_ASSURANCE = '''' THEN ''-1'' ELSE DMA.SK_ID_MONTANT_ASSURANCE END AS o_SK_ID_MONTANT_ASSURANCE,VVFR.ID_DATE_EMISSION_COUVERTURE,CASE WHEN DAE.SK_ID_AGE_EMISSION = '''' THEN ''-1'' ELSE DAE.SK_ID_AGE_EMISSION END AS o_SK_ID_AGE_EMISSION,CASE WHEN DD.SK_ID_DIM_DUREE = '''' THEN ''-1'' ELSE DD.SK_ID_DIM_DUREE END AS o_SK_ID_DUREE,CASE WHEN DS.SK_ID_DIM_SEXE = '''' THEN ''-1'' ELSE DS.SK_ID_DIM_SEXE END AS o_SK_ID_SEXE,CASE WHEN DSF.SK_ID_DIM_STATUT_FUMEUR = '''' THEN ''-1'' ELSE DSF.SK_ID_DIM_STATUT_FUMEUR END AS o_SK_ID_STATUT_FUMEUR,CASE WHEN DSP.SK_ID_DIM_STATUT_PREFERENTIEL = '''' THEN ''-1'' ELSE DSP.SK_ID_DIM_STATUT_PREFERENTIEL END AS o_SKI_ID_STATUT_PREFERENTIEL,CASE WHEN DRT.SK_ID_DIM_RAISON_TERMINAISON = '''' THEN ''-1'' ELSE DRT.SK_ID_DIM_RAISON_TERMINAISON END AS o_SK_ID_RAISON_TERMINAISON,CASE WHEN DP.SK_ID_DIM_PRODUIT = '''' THEN ''-1'' ELSE DP.SK_ID_DIM_PRODUIT END AS o_SK_ID_PRODUIT,CASE WHEN DAA.SK_ID_AGE_ATTEINT = '''' THEN ''-1'' ELSE DAA.SK_ID_AGE_ATTEINT END AS o_SK_ID_AGE_ATTEINT,VVFR.FUNDS_SURRENDERS,VVFR.FUNDS_DEATH_CLAIMS,VVFR.FUNDS_OTHER_MOVEMENT,To_Date( To_Char( CURRENT_TIMESTAMP,''YYYY-MM-DD HH:MI:SS'' ), ''YYYY-MM-DD HH:MI:SS'') AS o_MODIFICATION_DT,''-1'' AS o_CREATION_AUDIT_ID FROM DB_ACT_" + ENV + "_DWH.PUBLICATION_VI.VW_VI_FOND_RECLAMATION VVFR LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI_UNIT_SANDBOX.DIM_INFO_COUVERTURE DIC ON DIC.MD_HASH_NAT_KEY = VVFR.DIM_INFO_COUVERTURE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_COUVERTURE DC ON DC.MD_HASH_NAT_KEY=VVFR.DIM_COUVERTURE_HASH_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_CODE_PLAN_AXIS DCPA ON DCPA.MD_HASH_NAT_KEY=VVFR.DIM_CD_PLAN_AXIS_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_VALUATION_ASSUMPTIONS_TABLES DVAT ON DVAT.MD_HASH_NAT_KEY=VVFR.DIM_CD_PLAN_AXIS_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_TERRITOIRE DT ON DT.MD_HASH_NAT_KEY=VVFR.DIM_TERRITOIRE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI_UNIT_SANDBOX.DIM_SURPRIME DSPR ON DSPR.MD_HASH_NAT_KEY=VVFR.DIM_SURPRIME_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_RESEAU_DISTRIBUTION DRD ON DRD.MD_HASH_NAT_KEY=VVFR.DIM_RESEAU_DISTRIBUTION_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI_UNIT_SANDBOX.DIM_REASSURANCE DR ON DR.MD_HASH_NAT_KEY=VVFR.DIM_REASSURANCE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI_UNIT_SANDBOX.DIM_MONTANT_ASSURANCE DMA ON DMA.MD_HASH_NAT_KEY=VVFR.DIM_MONTANT_ASSURANCE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI_UNIT_SANDBOX.DIM_AGE_EMISSION DAE ON DAE.MD_HASH_NAT_KEY=VVFR.DIM_AGE_EMISSION_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_DUREE DD ON DD.MD_HASH_NAT_KEY=VVFR.DIM_DUREE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI_UNIT_SANDBOX.DIM_AGE_ATTEINT DAA ON DAA.MD_HASH_NAT_KEY=VVFR.DIM_AGE_ATTEINT_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_MODULE_COUVERTURE DMC ON DMC.MD_HASH_NAT_KEY=VVFR.DIM_MODULE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_SEXE DS ON DS.MD_HASH_NAT_KEY=VVFR.DIM_SEXE_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_STATUT_FUMEUR DSF ON DSF.MD_HASH_NAT_KEY=VVFR.DIM_STATUT_FUMEUR_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_STATUT_PREFERENTIEL DSP ON DSP.MD_HASH_NAT_KEY=VVFR.DIM_STATUT_PREFERENTIEL_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_VI.DIM_RAISON_TERMINAISON DRT ON DRT.MD_HASH_NAT_KEY=VVFR.DIM_RAISON_TERMINAISON_HASH_NAT_KEY LEFT JOIN DB_ACT_" + ENV + "_DM.DM_ERC.DIM_PRODUIT DP ON DP.MD_HASH_NAT_KEY=VVFR.DIM_RAISON_TERMINAISON_HASH_NAT_KEY WHERE  DIC.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DIC.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DC.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DC.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DCPA.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DCPA.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DSPR.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DSPR.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DRD.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DRD.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DR.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DR.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DMA.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DMA.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DAE.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DAE.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DD.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DD.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DAA.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DAA.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DMC.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DMC.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DS.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DS.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DSF.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DSF.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DSP.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DSP.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DRT.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DRT.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT AND DP.MD_ACTIVATION_DT <= VVFR.EVALUATION_DT AND DP.MD_OBSOLESCENCE_DT > VVFR.EVALUATION_DT;";
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
  result = "Succeeded!";
}
catch (err) {
    result = "Failed: Code: " + err.code + " \\n State: " + err.state;
    result += " \\n Message: " + err.message;
    result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
    throw result;
  }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_M_INSERT_AV_LINK_COVERAGE_BENEFICIARY_CONTINGENT"("ENV" VARCHAR(1000), "CURRENTRUNID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command ="insert into DB_AV_"+ENV+"_DWH.RDV.LINK_COVERAGE_BENEFICIARY_CONTINGENT(HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,HK_HUB_COVERAGE,HK_HUB_CLIENT_BENEFICIARY,HK_HUB_CLIENT_BENEFICIARY_CONTINGENT,MD_SOURCE,MD_CREATION_DT,MD_USER,MD_CREATION_AUDIT_ID) (select  SRC.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT, SRC.HK_HUB_COVERAGE, SRC.HK_HUB_CLIENT_BENEFICIARY, SRC.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT, MIN(SRC.MD_SOURCE), MIN(SRC.MD_CREATION_DT), MIN(SRC.MD_USER), ''"+CURRENTRUNID+"'' FROM  DB_AV_"+ENV+"_STG.MODEL.VW_AV_COVERAGE_BENEFICIARY_CONTINGENT_EXTRACT_DV SRC LEFT JOIN DB_AV_"+ENV+"_DWH.RDV.LINK_COVERAGE_BENEFICIARY_CONTINGENT LKP ON SRC.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT = LKP.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT WHERE LKP.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT IS NULL GROUP BY  SRC.HK_LINK_COVERAGE_BENEFICIARY_CONTINGENT,SRC.HK_HUB_COVERAGE,SRC.HK_HUB_CLIENT_BENEFICIARY,SRC.HK_HUB_CLIENT_BENEFICIARY_CONTINGENT);";
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
  result = "Succeeded!";
}
catch (err) {
    result = "Failed: Code: " + err.code + " \\n State: " + err.state;
    result += " \\n Message: " + err.message;
    result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
    throw result;
  }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_SUPPRIMER_DERNIEREDATE_DM_COMP"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command1 = "DELETE from DB_ACT_"+ ENV +"_DM.DM_VI.DIM_MASTER_COA where MD_ACTIVATION_DT = (select max(MD_ACTIVATION_DT) from DB_ACT_" + ENV +"_DM.DM_VI.DIM_MASTER_COA);";
var sql_command2 = "DELETE from DB_ACT_" + ENV + "_DM.DM_VI.DIM_COMPTE_GL where MD_ACTIVATION_DT = (select max(MD_ACTIVATION_DT) from DB_ACT_" + ENV + "_DM.DM_VI.DIM_COMPTE_GL);";
var sql_command4 = "DELETE from DB_ACT_" + ENV + "_DM.DM_VI.FT_SOLDE_GL where ID_DIM_DATE_FIN_PERIODE_COMPTABLE = (select max(ID_DIM_DATE_FIN_PERIODE_COMPTABLE) from DB_ACT_" + ENV + "_DM.DM_VI.FT_SOLDE_GL);";
try {
	var sql_statement1 = snowflake.createStatement({sqlText: sql_command1 });
    var result_scan0 =  sql_statement1.execute();
	var sql_statement2 = snowflake.createStatement({sqlText: sql_command2 });
    var result_scan1 =  sql_statement2.execute();
	var sql_statement4 = snowflake.createStatement({sqlText: sql_command4 });
    var result_scan3 =  sql_statement4.execute();
	result = "Succeeded!";
}
catch (err) {
    result = "Failed: Code: " + err.code + " \\n State: " + err.state;
    result += " \\n Message: " + err.message;
    result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
    throw result;
  }
 return result;
';
create or replace schema DM_VI_PUBLICATION;

create or replace TABLE VW_DIM_GROUPE_CSM (
	SK_ID_DIM_GROUPE_CSM VARCHAR(255),
	"Nom groupe CSM" VARCHAR(255),
	"Onérosité" VARCHAR(255)
);
create or replace view VW_DIM_AGE_ATTEINT(
	SK_ID_AGE_ATTEINT,
	"Age atteint",
	"Age atteint bucket",
	"Age atteint tranche - min"
) as
SELECT              
      SK_ID_DIM_AGE       AS "SK_ID_AGE_ATTEINT"
    , AGE									AS "Age atteint"	
    , TRANCHE_AGES_1      AS "Age atteint bucket"
    , TRANCHE_AGES_MIN_1  AS "Age atteint tranche - min"
FROM    DM_VI.DIM_AGE;
create or replace view VW_DIM_AGE_EMISSION(
	SK_ID_AGE_EMISSIONT,
	"Age émission",
	"Age émission bucket",
	"Age émission tranche - min"
) as
SELECT              
      SK_ID_DIM_AGE       AS "SK_ID_AGE_EMISSIONT"
    , AGE									AS "Age émission"		
    , TRANCHE_AGES_1      AS "Age émission bucket"
    , TRANCHE_AGES_MIN_1  AS "Age émission tranche - min"
FROM    DM_VI.DIM_AGE;
create or replace view VW_DIM_CODE_PLAN_AXIS(
	SK_ID_CD_PLAN_AXI,
	"Code plan Axis",
	"Code Plan Alis",
	"Suffixe",
	"Code version produit",
	"Company",
	"Produit",
	"Groupe",
	"Sous Groupe",
	"Generation",
	"Description",
	"Plan Code Ulis",
	"Split cad",
	"Team",
	"Axis Module",
	"Other benefit object",
	"Table other benefit rate for set",
	"Acb mortality options",
	"Acb mortality per 1000",
	"Actual Premium Table",
	"Age Distribution Table",
	"Benefit Level_indicator",
	"Benefit Period cause 1",
	"Benefit_Period cause 2",
	"Benefit Period method",
	"Bonus chargeback table",
	"Cash value table",
	"Commission table",
	"Compensation method",
	"Compensation table",
	"Death benefit period age",
	"Death benefit period code",
	"Death benefit period dur",
	"Disability benefit period age",
	"Disability benefit period code",
	"Disability benefit period dur",
	"Dividend option",
	"Dividend table",
	"Dividend table definition",
	"Early termination condition option",
	"Elimination period cause 1",
	"Elimination period cause 2",
	"Exempt test mort table",
	"Expense charge table",
	"Face amount table",
	"First year commission",
	"Frequency of charges method",
	"Fund bonus table",
	"Iit guaranteed interest",
	"Is commission use base plan",
	"Maturity value method",
	"Maturity value table",
	"Maximum benefit months cause 1",
	"Maximum benefit months cause 2",
	"Mid year csv method",
	"Minimum premium table",
	"Mort method for joint",
	"Mult for risk charge",
	"Naar method",
	"Non smoker bonus",
	"Oaca other benefit",
	"Other benefit link 1",
	"Other benefit link 2",
	"Other benefit link 3",
	"Policy continuation guar option",
	"Pre disability benefit table",
	"Premium load table",
	"Premium table",
	"Premium table create joint tables automatically",
	"Premium waiver method",
	"Pricing utilization table",
	"Prm paying period age",
	"Prm paying period code",
	"Prm paying period dur",
	"Proj method for joint",
	"Pua csv table",
	"Pua div bonus on lapse",
	"Pua nsp table",
	"Retroactive period cause 1",
	"Retroactive period cause 2",
	"Risk charge table",
	"Rop table",
	"Surrender charge table",
	"Sub premium table",
	"Sub risk charge table",
	"T5 accum fund",
	"T5 calculation method",
	"Target fund table",
	"Use acb in extract",
	"Volume type",
	"Waiver of fund charges",
	"Escap type",
	"Escapclass",
	"Escap par block",
	"Escap adjustable product",
	"Escap death designation",
	"Escap laps designation",
	"Escap mortality group",
	"Escap base lapse table",
	"Escap csv deficiency group",
	"Escap pf ad exclusion group",
	"Escap par or adjustable id",
	"Bareme par block",
	"Type for mortality",
	"Ifrs split",
	"Liquidity plan",
	"Liquidity type",
	"Am best type",
	"Dcat split",
	"Livre de taux pour bareme",
	"Study grouping code",
	"Ifrs17 group",
	"Ind prolongation assurance modulaire",
	"Study protection type",
	"SOE Product"
) as
SELECT 
      SK_ID_DIM_CODE_PLAN_AXIS                              AS "SK_ID_CD_PLAN_AXI"
    , CODE_PLAN_AXIS                                        AS "Code plan Axis"
    , CODE_PLAN_ALIS                                        AS "Code Plan Alis"
    , SUFFIXE                                               AS "Suffixe"
    , CODE_VERSION_PRODUIT                                  AS "Code version produit"
    , COMPANY                                               AS "Company"
    , PRODUCT                                               AS "Produit"
    , GRP                                                   AS "Groupe"
    , SUB_GROUP                                             AS "Sous Groupe"
    , GENERATION                                            AS "Generation"
    , DESCRIPTION                                           AS "Description"
    , PLAN_CODE_ULIS                                        AS "Plan Code Ulis"
    , SPLIT_CAD                                             AS "Split cad"
    , TEAM                                                  AS "Team"
    , AXIS_MODULE                                           AS "Axis Module"
    , OTHER_BENEFIT_OBJECT                                  AS "Other benefit object"
    , TABLE_OTHER_BENEFIT_RATE_FOR_SET                      AS "Table other benefit rate for set"
    , ACB_MORTALITY_OPTIONS                                 AS "Acb mortality options"
    , ACB_MORTALITY_PER_1000                                AS "Acb mortality per 1000"
    , ACTUAL_PREMIUM_TABLE                                  AS "Actual Premium Table"
    , AGE_DISTRIBUTION_TABLE                                AS "Age Distribution Table"
    , BENEFIT_LEVEL_INDICATOR                               AS "Benefit Level_indicator"
    , BENEFIT_PERIOD_CAUSE_1                                AS "Benefit Period cause 1"
    , BENEFIT_PERIOD_CAUSE_2                                AS "Benefit_Period cause 2"
    , BENEFIT_PERIOD_METHOD                                 AS "Benefit Period method"
    , BONUS_CHARGEBACK_TABLE                                AS "Bonus chargeback table"
    , CASH_VALUE_TABLE                                      AS "Cash value table"
    , COMMISSION_TABLE                                      AS "Commission table"
    , COMPENSATION_METHOD                                   AS "Compensation method"
    , COMPENSATION_TABLE                                    AS "Compensation table"
    , DEATH_BENEFIT_PERIOD_AGE                              AS "Death benefit period age"
    , DEATH_BENEFIT_PERIOD_CODE                             AS "Death benefit period code"
    , DEATH_BENEFIT_PERIOD_DUR                              AS "Death benefit period dur"
    , DISABILITY_BENEFIT_PERIOD_AGE                         AS "Disability benefit period age"
    , DISABILITY_BENEFIT_PERIOD_CODE                        AS "Disability benefit period code"
    , DISABILITY_BENEFIT_PERIOD_DUR                         AS "Disability benefit period dur"
    , DIVIDEND_OPTION                                       AS "Dividend option"
    , DIVIDEND_TABLE                                        AS "Dividend table"
    , DIVIDEND_TABLE_DEFINITION                             AS "Dividend table definition"
    , EARLY_TERMINATION_CONDITION_OPTION                    AS "Early termination condition option"
    , ELIMINATION_PERIOD_CAUSE_1                            AS "Elimination period cause 1"
    , ELIMINATION_PERIOD_CAUSE_2                            AS "Elimination period cause 2"
    , EXEMPT_TEST_MORT_TABLE                                AS "Exempt test mort table"
    , EXPENSE_CHARGE_TABLE                                  AS "Expense charge table"
    , FACE_AMOUNT_TABLE                                     AS "Face amount table"
    , FIRST_YEAR_COMMISSION                                 AS "First year commission"
    , FREQUENCY_OF_CHARGES_METHOD                           AS "Frequency of charges method"
    , FUND_BONUS_TABLE                                      AS "Fund bonus table"
    , IIT_GUARANTEED_INTEREST                               AS "Iit guaranteed interest"
    , IS_COMMISSION_USE_BASE_PLAN                           AS "Is commission use base plan"
    , MATURITY_VALUE_METHOD                                 AS "Maturity value method"
    , MATURITY_VALUE_TABLE                                  AS "Maturity value table"
    , MAXIMUM_BENEFIT_MONTHS_CAUSE_1                        AS "Maximum benefit months cause 1"
    , MAXIMUM_BENEFIT_MONTHS_CAUSE_2                        AS "Maximum benefit months cause 2"
    , MID_YEAR_CSV_METHOD                                   AS "Mid year csv method"
    , MINIMUM_PREMIUM_TABLE                                 AS "Minimum premium table"
    , MORT_METHOD_FOR_JOINT                                 AS "Mort method for joint"
    , MULT_FOR_RISK_CHARGE                                  AS "Mult for risk charge"
    , NAAR_METHOD                                           AS "Naar method"
    , NON_SMOKER_BONUS                                      AS "Non smoker bonus"
    , OACA_OTHER_BENEFIT                                    AS "Oaca other benefit"
    , OTHER_BENEFIT_LINK_1                                  AS "Other benefit link 1"
    , OTHER_BENEFIT_LINK_2                                  AS "Other benefit link 2"
    , OTHER_BENEFIT_LINK_3                                  AS "Other benefit link 3"
    , POLICY_CONTINUATION_GUAR_OPTION                       AS "Policy continuation guar option"
    , PRE_DISABILITY_BENEFIT_TABLE                          AS "Pre disability benefit table"
    , PREMIUM_LOAD_TABLE                                    AS "Premium load table"
    , PREMIUM_TABLE                                         AS "Premium table"
    , PREMIUM_TABLE_CREATE_JOINT_TABLES_AUTOMATICALLY       AS "Premium table create joint tables automatically"
    , PREMIUM_WAIVER_METHOD                                 AS "Premium waiver method"
    , PRICING_UTILIZATION_TABLE                             AS "Pricing utilization table"
    , PRM_PAYING_PERIOD_AGE                                 AS "Prm paying period age"
    , PRM_PAYING_PERIOD_CODE                                AS "Prm paying period code"
    , PRM_PAYING_PERIOD_DUR                                 AS "Prm paying period dur"
    , PROJ_METHOD_FOR_JOINT                                 AS "Proj method for joint"
    , PUA_CSV_TABLE                                         AS "Pua csv table"
    , PUA_DIV_BONUS_ON_LAPSE                                AS "Pua div bonus on lapse"
    , PUA_NSP_TABLE                                         AS "Pua nsp table"
    , RETROACTIVE_PERIOD_CAUSE_1                            AS "Retroactive period cause 1"
    , RETROACTIVE_PERIOD_CAUSE_2                            AS "Retroactive period cause 2"
    , RISK_CHARGE_TABLE                                     AS "Risk charge table"
    , ROP_TABLE                                             AS "Rop table"
    , SURRENDER_CHARGE_TABLE                                AS "Surrender charge table"
    , SUB_PREMIUM_TABLE                                     AS "Sub premium table"
    , SUB_RISK_CHARGE_TABLE                                 AS "Sub risk charge table"
    , T5_ACCUM_FUND                                         AS "T5 accum fund"
    , T5_CALCULATION_METHOD                                 AS "T5 calculation method"
    , TARGET_FUND_TABLE                                     AS "Target fund table"
    , USE_ACB_IN_EXTRACT                                    AS "Use acb in extract"
    , VOLUME_TYPE                                           AS "Volume type"
    , WAIVER_OF_FUND_CHARGES                                AS "Waiver of fund charges"
    , ESCAP_TYPE                                            AS "Escap type"
    , ESCAPCLASS                                            AS "Escapclass"
    , ESCAP_PAR_BLOCK                                       AS "Escap par block"
    , ESCAP_ADJUSTABLE_PRODUCT                              AS "Escap adjustable product"
    , ESCAP_DEATH_DESIGNATION                               AS "Escap death designation"
    , ESCAP_LAPSE_DESIGNATION                               AS "Escap laps designation"
    , ESCAP_MORTALITY_GROUP                                 AS "Escap mortality group"
    , ESCAP_BASE_LAPSE_TABLE                                AS "Escap base lapse table"
    , ESCAP_CSV_DEFICIENCY_GROUP                            AS "Escap csv deficiency group"
    , ESCAP_PF_AD_EXCLUSION_GROUP                           AS "Escap pf ad exclusion group"
    , ESCAP_PAR_OR_ADJUSTABLE_ID                            AS "Escap par or adjustable id"
    , BAREME_PAR_BLOCK                                      AS "Bareme par block"
    , TYPE_FOR_MORTALITY                                    AS "Type for mortality"
    , IFRS_SPLIT                                            AS "Ifrs split"
    , LIQUIDITY_PLAN                                        AS "Liquidity plan"
    , LIQUIDITY_TYPE                                        AS "Liquidity type"
    , AM_BEST_TYPE                                          AS "Am best type"
    , DCAT_SPLIT                                            AS "Dcat split"
    , LIVRE_DE_TAUX_POUR_BAREME                             AS "Livre de taux pour bareme"
    , STUDY_GROUPING_CODE                                   AS "Study grouping code"
    , IFRS17_GROUP                                          AS "Ifrs17 group"
    , IND_PROLONGATION_ASSURANCE_MODULAIRE                  AS "Ind prolongation assurance modulaire"
    , STUDY_PROTECTION_TYPE                                 AS "Study protection type"
    , SOE_PRODUCT                                           AS "SOE Product"

FROM DM_VI.DIM_CODE_PLAN_AXIS;
create or replace view VW_DIM_COMPTE_GL(
	SK_ID_COMPTE_GL,
	"Code Entité",
	"Code Nature",
	"Code Origine",
	"Code Periodicité",
	"Code Centre Cout",
	"Code Interco",
	"Code Ligne Affaire",
	"Code Produit",
	"Code Participation",
	"Code Géographie",
	"Code Projet"
) as
    SELECT 
      SK_ID_DIM_COMPTE_GL 	AS SK_ID_COMPTE_GL,
      CD_ENTITE 			AS "Code Entité",
      CD_NATURE				AS "Code Nature",
      CD_ORIGINE			AS "Code Origine",
      CD_PERIODICITE		AS "Code Periodicité",
      CD_CENTRE_COUT		AS "Code Centre Cout",
      CD_INTERCO			AS "Code Interco",
      CD_LIGNE_AFFAIRE		AS "Code Ligne Affaire",
      CD_PRODUIT			AS "Code Produit",
      CD_PARTICIPATION		AS "Code Participation",
      CD_GEOGRAPHIE			AS "Code Géographie",
      CD_PROJET				AS "Code Projet"
    FROM DM_VI.DIM_COMPTE_GL;
create or replace view VW_DIM_COUVERTURE(
	SK_ID_COUVERTURE,
	GEN_UID,
	"Numéro police"
) as

SELECT   SK_ID_DIM_COUVERTURE           AS SK_ID_COUVERTURE
       , GEN_UID                        AS GEN_UID
       , NO_POLICE                      AS "Numéro police"
from DM_VI.DIM_COUVERTURE;
create or replace view VW_DIM_DATE(
	ID_DIM_DATE,
	"Mois - Code",
	"Mois - Abbrév. FR",
	"Mois - Abbrév. EN",
	"Mois - Nom FR",
	"Mois - Nom EN",
	"Mois Année - Abbrév. FR",
	"Mois Année - Abbrév. EN",
	"Mois Année - Nom FR",
	"Mois Année - Nom EN",
	"Mois - Numéro",
	"Trimestre - Code",
	"Trimestre - Numéro",
	"Trimestre - Abbrév. FR",
	"Trimestre - Abbrév. EN",
	"Trimestre - Nom FR",
	"Trimestre - Nom EN",
	"Trimestre Année - Abbrév. FR",
	"Trimestre Année - Abbrév. EN",
	"Trimestre Année - Nom FR",
	"Trimestre Année - Nom EN",
	"Semestre - Code",
	"Semestre - Numéro ",
	"Semestre - Abbrév. FR",
	"Semestre - Abbrév. EN",
	"Semestre - Nom FR",
	"Semestre - Nom EN",
	"Semestre Année - Abbrév. FR",
	"Semestre Année - Abbrév. EN",
	"Semestre Année - Nom FR",
	"Semestre Année - Nom EN",
	"Année - Code",
	"Année - Abbrév. FR",
	"Année - Abbrév. EN",
	"Année - Nom FR",
	"Année - Nom EN"
) as
SELECT  
          ID_DIM_DATE                       AS "ID_DIM_DATE"
        , MONTH_CD                          AS "Mois - Code"
        , MONTH_SHORT_NAME_FR               AS "Mois - Abbrév. FR"
        , MONTH_SHORT_NAME_EN               AS "Mois - Abbrév. EN"
        , MONTH_NAME_FR                     AS "Mois - Nom FR"
        , MONTH_NAME_EN                     AS "Mois - Nom EN"
        , MONTH_YEAR_SHORT_NAME_FR          AS "Mois Année - Abbrév. FR"
        , MONTH_YEAR_SHORT_NAME_EN          AS "Mois Année - Abbrév. EN"
        , MONTH_YEAR_NAME_FR                AS "Mois Année - Nom FR"
        , MONTH_YEAR_NAME_EN                AS "Mois Année - Nom EN"
        , MONTH_NO                          AS "Mois - Numéro"
        , QUARTER_CD                        AS "Trimestre - Code"
        , QUARTER_NO					    AS "Trimestre - Numéro"
        , QUARTER_SHORT_NAME_FR				AS "Trimestre - Abbrév. FR"
        , QUARTER_SHORT_NAME_EN				AS "Trimestre - Abbrév. EN"
        , QUARTER_NAME_FR					AS "Trimestre - Nom FR"
        , QUARTER_NAME_EN					AS "Trimestre - Nom EN"
        , QUARTER_YEAR_SHORT_NAME_FR		AS "Trimestre Année - Abbrév. FR"
        , QUARTER_YEAR_SHORT_NAME_EN		AS "Trimestre Année - Abbrév. EN"
        , QUARTER_YEAR_NAME_FR				AS "Trimestre Année - Nom FR"
        , QUARTER_YEAR_NAME_EN				AS "Trimestre Année - Nom EN"
		    , SEMESTER_CD						AS "Semestre - Code"
        , SEMESTER_NO						AS "Semestre - Numéro "
        , SEMESTER_SHORT_NAME_FR			AS "Semestre - Abbrév. FR"
        , SEMESTER_SHORT_NAME_EN			AS "Semestre - Abbrév. EN"
        , SEMESTER_NAME_FR					AS "Semestre - Nom FR"
        , SEMESTER_NAME_EN					AS "Semestre - Nom EN"
        , SEMESTER_YEAR_SHORT_NAME_FR 		AS "Semestre Année - Abbrév. FR"
        , SEMESTER_YEAR_SHORT_NAME_EN 		AS "Semestre Année - Abbrév. EN"
        , SEMESTER_YEAR_NAME_FR				AS "Semestre Année - Nom FR"
        , SEMESTER_YEAR_NAME_EN				AS "Semestre Année - Nom EN"
        , YEAR_CD							AS "Année - Code"
        , YEAR_SHORT_NAME_FR				AS "Année - Abbrév. FR"
        , YEAR_SHORT_NAME_EN				AS "Année - Abbrév. EN"
        , YEAR_NAME_FR						AS "Année - Nom FR"
        , YEAR_NAME_EN						AS "Année - Nom EN"
       
FROM DM_VI.DIM_DATE;
create or replace view VW_DIM_DATE_EMISSION(
	ID_DIM_DATE_EMISSION,
	"Mois - Code",
	"Mois - Abbrév. FR",
	"Mois - Abbrév. EN",
	"Mois - Nom FR",
	"Mois - Nom EN",
	"Mois Année - Abbrév. FR",
	"Mois Année - Abbrév. EN",
	"Mois Année - Nom FR",
	"Mois Année - Nom EN",
	"Mois - Numéro",
	"Trimestre - Code",
	"Trimestre - Numéro",
	"Trimestre - Abbrév. FR",
	"Trimestre - Abbrév. EN",
	"Trimestre - Nom FR",
	"Trimestre - Nom EN",
	"Trimestre Année - Abbrév. FR",
	"Trimestre Année - Abbrév. EN",
	"Trimestre Année - Nom FR",
	"Trimestre Année - Nom EN",
	"Semestre - Code",
	"Semestre - Numéro ",
	"Semestre - Abbrév. FR",
	"Semestre - Abbrév. EN",
	"Semestre - Nom FR",
	"Semestre - Nom EN",
	"Semestre Année - Abbrév. FR",
	"Semestre Année - Abbrév. EN",
	"Semestre Année - Nom FR",
	"Semestre Année - Nom EN",
	"Année - Code",
	"Année - Abbrév. FR",
	"Année - Abbrév. EN",
	"Année - Nom FR",
	"Année - Nom EN"
) as
SELECT  
          ID_DIM_DATE                       AS "ID_DIM_DATE_EMISSION"
        , MONTH_CD                          AS "Mois - Code"
        , MONTH_SHORT_NAME_FR               AS "Mois - Abbrév. FR"
        , MONTH_SHORT_NAME_EN               AS "Mois - Abbrév. EN"
        , MONTH_NAME_FR                     AS "Mois - Nom FR"
        , MONTH_NAME_EN                     AS "Mois - Nom EN"
        , MONTH_YEAR_SHORT_NAME_FR          AS "Mois Année - Abbrév. FR"
        , MONTH_YEAR_SHORT_NAME_EN          AS "Mois Année - Abbrév. EN"
        , MONTH_YEAR_NAME_FR                AS "Mois Année - Nom FR"
        , MONTH_YEAR_NAME_EN                AS "Mois Année - Nom EN"
        , MONTH_NO                          AS "Mois - Numéro"
        , QUARTER_CD                        AS "Trimestre - Code"
        , QUARTER_NO					    AS "Trimestre - Numéro"
        , QUARTER_SHORT_NAME_FR				AS "Trimestre - Abbrév. FR"
        , QUARTER_SHORT_NAME_EN				AS "Trimestre - Abbrév. EN"
        , QUARTER_NAME_FR					AS "Trimestre - Nom FR"
        , QUARTER_NAME_EN					AS "Trimestre - Nom EN"
        , QUARTER_YEAR_SHORT_NAME_FR		AS "Trimestre Année - Abbrév. FR"
        , QUARTER_YEAR_SHORT_NAME_EN		AS "Trimestre Année - Abbrév. EN"
        , QUARTER_YEAR_NAME_FR				AS "Trimestre Année - Nom FR"
        , QUARTER_YEAR_NAME_EN				AS "Trimestre Année - Nom EN"
        , SEMESTER_CD						AS "Semestre - Code"
        , SEMESTER_NO						AS "Semestre - Numéro "
        , SEMESTER_SHORT_NAME_FR			AS "Semestre - Abbrév. FR"
        , SEMESTER_SHORT_NAME_EN			AS "Semestre - Abbrév. EN"
        , SEMESTER_NAME_FR					AS "Semestre - Nom FR"
        , SEMESTER_NAME_EN					AS "Semestre - Nom EN"
        , SEMESTER_YEAR_SHORT_NAME_FR 		AS "Semestre Année - Abbrév. FR"
        , SEMESTER_YEAR_SHORT_NAME_EN 		AS "Semestre Année - Abbrév. EN"
        , SEMESTER_YEAR_NAME_FR				AS "Semestre Année - Nom FR"
        , SEMESTER_YEAR_NAME_EN				AS "Semestre Année - Nom EN"
        , YEAR_CD							AS "Année - Code"
        , YEAR_SHORT_NAME_FR				AS "Année - Abbrév. FR"
        , YEAR_SHORT_NAME_EN				AS "Année - Abbrév. EN"
        , YEAR_NAME_FR						AS "Année - Nom FR"
        , YEAR_NAME_EN						AS "Année - Nom EN"
       
FROM DM_VI.DIM_DATE;
create or replace view VW_DIM_DATE_EVALUATION(
	ID_DIM_DATE_EVALUATION,
	"Mois - Code",
	"Mois - Abbrév. FR",
	"Mois - Abbrév. EN",
	"Mois - Nom FR",
	"Mois - Nom EN",
	"Mois Année - Abbrév. FR",
	"Mois Année - Abbrév. EN",
	"Mois Année - Nom FR",
	"Mois Année - Nom EN",
	"Mois - Numéro",
	"Trimestre - Code",
	"Trimestre - Numéro",
	"Trimestre - Abbrév. FR",
	"Trimestre - Abbrév. EN",
	"Trimestre - Nom FR",
	"Trimestre - Nom EN",
	"Trimestre Année - Abbrév. FR",
	"Trimestre Année - Abbrév. EN",
	"Trimestre Année - Nom FR",
	"Trimestre Année - Nom EN",
	"Semestre - Code",
	"Semestre - Numéro ",
	"Semestre - Abbrév. FR",
	"Semestre - Abbrév. EN",
	"Semestre - Nom FR",
	"Semestre - Nom EN",
	"Semestre Année - Abbrév. FR",
	"Semestre Année - Abbrév. EN",
	"Semestre Année - Nom FR",
	"Semestre Année - Nom EN",
	"Année - Code",
	"Année - Abbrév. FR",
	"Année - Abbrév. EN",
	"Année - Nom FR",
	"Année - Nom EN"
) as
SELECT  
          ID_DIM_DATE                       AS "ID_DIM_DATE_EVALUATION"
        , MONTH_CD                          AS "Mois - Code"
        , MONTH_SHORT_NAME_FR               AS "Mois - Abbrév. FR"
        , MONTH_SHORT_NAME_EN               AS "Mois - Abbrév. EN"
        , MONTH_NAME_FR                     AS "Mois - Nom FR"
        , MONTH_NAME_EN                     AS "Mois - Nom EN"
        , MONTH_YEAR_SHORT_NAME_FR          AS "Mois Année - Abbrév. FR"
        , MONTH_YEAR_SHORT_NAME_EN          AS "Mois Année - Abbrév. EN"
        , MONTH_YEAR_NAME_FR                AS "Mois Année - Nom FR"
        , MONTH_YEAR_NAME_EN                AS "Mois Année - Nom EN"
        , MONTH_NO                          AS "Mois - Numéro"
        , QUARTER_CD                        AS "Trimestre - Code"
        , QUARTER_NO					    AS "Trimestre - Numéro"
        , QUARTER_SHORT_NAME_FR				AS "Trimestre - Abbrév. FR"
        , QUARTER_SHORT_NAME_EN				AS "Trimestre - Abbrév. EN"
        , QUARTER_NAME_FR					AS "Trimestre - Nom FR"
        , QUARTER_NAME_EN					AS "Trimestre - Nom EN"
        , QUARTER_YEAR_SHORT_NAME_FR		AS "Trimestre Année - Abbrév. FR"
        , QUARTER_YEAR_SHORT_NAME_EN		AS "Trimestre Année - Abbrév. EN"
        , QUARTER_YEAR_NAME_FR				AS "Trimestre Année - Nom FR"
        , QUARTER_YEAR_NAME_EN				AS "Trimestre Année - Nom EN"
        , SEMESTER_CD						AS "Semestre - Code"
        , SEMESTER_NO						AS "Semestre - Numéro "
        , SEMESTER_SHORT_NAME_FR			AS "Semestre - Abbrév. FR"
        , SEMESTER_SHORT_NAME_EN			AS "Semestre - Abbrév. EN"
        , SEMESTER_NAME_FR					AS "Semestre - Nom FR"
        , SEMESTER_NAME_EN					AS "Semestre - Nom EN"
        , SEMESTER_YEAR_SHORT_NAME_FR 		AS "Semestre Année - Abbrév. FR"
        , SEMESTER_YEAR_SHORT_NAME_EN 		AS "Semestre Année - Abbrév. EN"
        , SEMESTER_YEAR_NAME_FR				AS "Semestre Année - Nom FR"
        , SEMESTER_YEAR_NAME_EN				AS "Semestre Année - Nom EN"
        , YEAR_CD							AS "Année - Code"
        , YEAR_SHORT_NAME_FR				AS "Année - Abbrév. FR"
        , YEAR_SHORT_NAME_EN				AS "Année - Abbrév. EN"
        , YEAR_NAME_FR						AS "Année - Nom FR"
        , YEAR_NAME_EN						AS "Année - Nom EN"
       
FROM DM_VI.DIM_DATE;
create or replace view VW_DIM_DUREE(
	SK_ID_DUREE,
	"Durée",
	"Durée bucket",
	"Durée bucket - min"
) as

SELECT              
        SK_ID_DIM_DUREE            AS "SK_ID_DUREE"
      , DUREE									     AS "Durée"		
      , TRANCHE_DUREES_1           AS "Durée bucket"
      , TRANCHE_DUREES_MIN_1  AS "Durée bucket - min"      
FROM    DM_VI.DIM_DUREE;
create or replace view VW_DIM_MASTER_COA(
	SK_ID_DIM_MASTER_COA,
	"Variable CSM",
	"Custom Dim 1",
	"Custom Dim 2"
) as
    SELECT 
      SK_ID_DIM_MASTER_COA    AS "SK_ID_MASTER_COA"
    , VARIABLE_CSM            AS "Variable CSM"    
    , CUSTOM_DIM_1            AS "Custom Dim 1"
    , CUSTOM_DIM_2            AS "Custom Dim 2"
    FROM DM_VI.DIM_MASTER_COA;
create or replace view VW_DIM_MODULE_COUVERTURE(
	SK_ID_MODULE_COUVERTURE,
	"Code module",
	"Nom module"
) as
SELECT              
      SK_ID_DIM_MODULE_COUVERTURE                 AS "SK_ID_MODULE_COUVERTURE"
    , CODE_MODULE_COUVERTURE									    AS "Code module"											
    , NOM_MODULE_COUVERTURE	                      AS "Nom module"								
FROM    DM_VI.DIM_MODULE_COUVERTURE;
create or replace view VW_DIM_RAISON_TERMINAISON(
	SK_ID_RAISON_TERMINAISON,
	"Raison terminaison"
) as         
SELECT 
      SK_ID_DIM_RAISON_TERMINAISON              AS "SK_ID_RAISON_TERMINAISON"
    , NVL(replace(replace(RAISON_TERMINAISON,'Ã©','é'),'Ã¨','è'),'Non applicable')  AS "Raison terminaison" 
FROM DM_VI.DIM_RAISON_TERMINAISON;
create or replace view VW_DIM_RESEAU_DISTRIBUTION(
	SK_ID_RESEAU_DISTRIBUTION,
	"Code agence",
	"Code agent"
) as
SELECT              
      SK_ID_DIM_RESEAU_DISTRIBUTION   AS "SK_ID_RESEAU_DISTRIBUTION"
    , CODE_AGENCE									AS "Code agence"											
    , CODE_AGENT	                AS "Code agent"								
FROM    DM_VI.DIM_RESEAU_DISTRIBUTION;
create or replace view VW_DIM_SEXE(
	SK_ID_DIM_SEXE,
	"Sexe"
) as
    SELECT 
    SK_ID_DIM_SEXE
    , CODE_SEXE                                       AS "Sexe"
    FROM DM_VI.DIM_SEXE;
create or replace view VW_DIM_STATUT_FUMEUR(
	SK_ID_STATUT_FUMEUR,
	"Code statut fumeur",
	"Nom statut fumeur"
) as
    SELECT 
      SK_ID_DIM_STATUT_FUMEUR                                AS "SK_ID_STATUT_FUMEUR"
    , CODE_STATUT_FUMEUR                                 AS "Code statut fumeur"
    , NOM_STATUT_FUMEUR                                  AS "Nom statut fumeur"
    FROM DM_VI.DIM_STATUT_FUMEUR;
create or replace view VW_DIM_STATUT_PREFERENTIEL(
	SK_ID_STATUT_PREFERENTIEL,
	"Code statut préférentiel",
	"Nom statut préférentiel"
) as
    SELECT 
      SK_ID_DIM_STATUT_PREFERENTIEL                                     AS "SK_ID_STATUT_PREFERENTIEL"
    , CODE_STATUT_PREFERENTIEL                                         AS "Code statut préférentiel"
    , NOM_STATUT_PREFERENTIEL                                        AS "Nom statut préférentiel"
    FROM DM_VI.DIM_STATUT_PREFERENTIEL;
create or replace view VW_DIM_TERRITOIRE(
	SK_ID_TERRITOIRE,
	"Pays",
	"État/Province"
) as
SELECT              
      SK_ID_DIM_TERRITOIRE          AS "SK_ID_TERRITOIRE"
    , CODE_PAYS									    AS "Pays"											
    , NOM_PROVINCE_ETAT	            AS "État/Province"								
FROM    DM_VI.DIM_TERRITOIRE;
create or replace view VW_DIM_TRAITE_REASSURANCE(
	SK_ID_DIM_TRAITE_REASSURANCE,
	TYPE_REASSURANCE,
	TRAITE_REASSURANCE,
	NUMERO_REASSUREUR,
	DATE_TRAITE_REASSURANCE
) as
SELECT
    SK_ID_DIM_TRAITE_REASSURANCE
    ,TYPE_REASSURANCE
    ,TRAITE_REASSURANCE
    ,NUMERO_REASSUREUR
    ,DATE_TRAITE_REASSURANCE
FROM DM_VI.DIM_TRAITE_REASSURANCE;
create or replace view VW_DIM_TYPE_LIBERATION_RESERVE(
	SK_ID_DIM_TYPE_LIBERATION_RESERVE,
	"Type liberation reserve"
) as
SELECT 
    SK_ID_DIM_TYPE_LIBERATION_RESERVE   AS "SK_ID_DIM_TYPE_LIBERATION_RESERVE"
    ,TYPE_LIBERATION_RESERVE            AS "Type liberation reserve"
FROM DM_VI.DIM_TYPE_LIBERATION_RESERVE;
create or replace view VW_DIM_TYPE_TAUX_INTERET(
	SK_ID_DIM_TYPE_TAUX_INTERET,
	"Nom type taux interet"
) as
SELECT 

SK_ID_DIM_TYPE_TAUX_INTERET   AS  "SK_ID_DIM_TYPE_TAUX_INTERET"
,NOM_TYPE_TAUX_INTERET        AS "Nom type taux interet"

FROM DM_VI.DIM_TYPE_TAUX_INTERET;
create or replace view VW_DIM_VALUATION_ASSUMPTIONS_TABLES(
	"SK ID VALUATION ASSUMPTIONS TABLES",
	"Team",
	"Axis module",
	"SOE output lapse grouping",
	"Base cell name",
	"AC dividend mortality table",
	"AC dividend expenses table",
	"AC dividend interest table",
	"EX dividend mortality table",
	"EX dividend expenses table",
	"EX dividend interest table",
	"Pricing cause 1 QI table",
	"Pricing cause 2 QI table",
	"Pricing dynamic prem adjustment option",
	"Pricing expenses table",
	"Pricing interest table",
	"Pricing lapse rate table",
	"Pricing modification table",
	"Pricing mortality impr table",
	"Pricing mortality table",
	"Pricing mult for mortality impr",
	"Pricing other benefit rates table",
	"Pricing termination cause 1 table",
	"Pricing termination cause 2 table",
	"pricing total premium table",
	"Stat input terminal res factors table",
	"Stat RES cause 1 QI table",
	"Stat RES cause 2 QI table",
	"Stat RES expenses table",
	"Stat RES flat for lapse pad",
	"Stat RES flat for final mortality mad",
	"Stat RES historic mortality improvement",
	"Stat RES interest table",
	"Stat RES lapse pad table",
	"Stat RES lapse rate pad method",
	"Stat RES lapse rate table",
	"Stat RES modification table",
	"Stat RES mortality impr table",
	"Stat RES final mortality mad table",
	"Stat RES mult for cause 1 qi",
	"Stat RES mult for cause 2 qi",
	"Stat RES mult for expenses",
	"Stat RES mult for mortality impr",
	"Stat RES mult for termination cause 1",
	"Stat RES mult for termination cause 2",
	"Stat RES other benefit rates table",
	"Stat RES termination cause 1 table",
	"Stat RES termination cause 2 table",
	"Stat RES total premium table",
	"Tax RES expenses table",
	"Tax RES interest table",
	"Tax RES lapse rate table",
	"Tax RES mortality impr table",
	"Tax RES mortality table",
	"Tax RES mult for mortality impr",
	"Tax RES other benefit rates table",
	"Tax RES total premium table",
	"Allocation rule table",
	"Ceded input factors table",
	"Div actual dividend adjustment table",
	"Div actual mult for dividend adjustment",
	"Dividend expense base method",
	"Dividend formula",
	"Fund1 investment",
	"Interest gain basis",
	"Is lapse use base plan",
	"Is mortality use base plan",
	"Method forj joint first lapse",
	"Stat reserve method link",
	"Tax exempt inv inc table",
	"Tax fund based reserve adj table",
	"Tax input terminal res factors table",
	"Tax reserve method link",
	"Taxes IIT interest rate table",
	"Treatment of roup",
	"Bareme par block",
	"Livre de taux pour bareme",
	"IFRSM expenses table",
	"IFRSM interest table",
	"IFRSM taxes IIT interest rate table",
	"IFRSNM expenses table"
) as

SELECT 
	  SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES				AS "SK ID VALUATION ASSUMPTIONS TABLES" 
	, TEAM												AS "Team"							
	, AXIS_MODULE										AS "Axis module"						
	, SOE_OUTPUT_LAPSE_GROUPING							AS "SOE output lapse grouping"		
	, BASE_CELL_NAME									AS "Base cell name"					
	, AC_DIVIDEND_MORTALITY_TABLE						AS "AC dividend mortality table"		
	, AC_DIVIDEND_EXPENSES_TABLE						AS "AC dividend expenses table"		
	, AC_DIVIDEND_INTEREST_TABLE						AS "AC dividend interest table"		
	, EX_DIVIDEND_MORTALITY_TABLE						AS "EX dividend mortality table"		
	, EX_DIVIDEND_EXPENSES_TABLE						AS "EX dividend expenses table"		
	, EX_DIVIDEND_INTEREST_TABLE						AS "EX dividend interest table"		
	, PRICING_CAUSE_1_QI_TABLE							AS "Pricing cause 1 QI table"		
	, PRICING_CAUSE_2_QI_TABLE							AS "Pricing cause 2 QI table"		
	, PRICING_DYNAMIC_PREM_ADJUSTMENT_OPTION			AS "Pricing dynamic prem adjustment option"
	, PRICING_EXPENSES_TABLE							AS "Pricing expenses table"			
	, PRICING_INTEREST_TABLE							AS "Pricing interest table"			
	, PRICING_LAPSE_RATE_TABLE							AS "Pricing lapse rate table"		
	, PRICING_MODIFICATION_TABLE						AS "Pricing modification table"		
	, PRICING_MORTALITY_IMPR_TABLE						AS "Pricing mortality impr table"	
	, PRICING_MORTALITY_TABLE							AS "Pricing mortality table"			
	, PRICING_MULT_FOR_MORTALITY_IMPR 					AS "Pricing mult for mortality impr" 
	, PRICING_OTHER_BENEFIT_RATES_TABLE					AS "Pricing other benefit rates table"		
	, PRICING_TERMINATION_CAUSE_1_TABLE					AS "Pricing termination cause 1 table"		
	, PRICING_TERMINATION_CAUSE_2_TABLE					AS "Pricing termination cause 2 table"		
	, PRICING_TOTAL_PREMIUM_TABLE						AS "pricing total premium table"				
	, STAT_INPUT_TERMINAL_RES_FACTORS_TABLE				AS "Stat input terminal res factors table"
	, STAT_RES_CAUSE_1_QI_TABLE							AS "Stat RES cause 1 QI table"
	, STAT_RES_CAUSE_2_QI_TABLE							AS "Stat RES cause 2 QI table"				
	, STAT_RES_EXPENSES_TABLE							AS "Stat RES expenses table"			
	, STAT_RES_FLAT_FOR_LAPSE_PAD						AS "Stat RES flat for lapse pad"				
	, STAT_RES_FLAT_FOR_FINAL_MORTALITY_MAD				AS "Stat RES flat for final mortality mad"	
	, STAT_RES_HISTORIC_MORTALITY_IMPROVEMENT 			AS "Stat RES historic mortality improvement" 
	, STAT_RES_INTEREST_TABLE							AS "Stat RES interest table"
	, STAT_RES_LAPSE_PAD_TABLE							AS "Stat RES lapse pad table"				
	, STAT_RES_LAPSE_RATE_PAD_METHOD					AS "Stat RES lapse rate pad method"			
	, STAT_RES_LAPSE_RATE_TABLE							AS "Stat RES lapse rate table"		
	, STAT_RES_MODIFICATION_TABLE						AS "Stat RES modification table"				
	, STAT_RES_MORTALITY_IMPR_TABLE						AS "Stat RES mortality impr table"			
	, STAT_RES_FINAL_MORTALITY_MAD_TABLE				AS "Stat RES final mortality mad table"		
	, STAT_RES_MULT_FOR_CAUSE_1_QI						AS "Stat RES mult for cause 1 qi"			
	, STAT_RES_MULT_FOR_CAUSE_2_QI						AS "Stat RES mult for cause 2 qi"			
	, STAT_RES_MULT_FOR_EXPENSES						AS "Stat RES mult for expenses"				
	, STAT_RES_MULT_FOR_MORTALITY_IMPR					AS "Stat RES mult for mortality impr"		
	, STAT_RES_MULT_FOR_TERMINATION_CAUSE_1				AS "Stat RES mult for termination cause 1"	
	, STAT_RES_MULT_FOR_TERMINATION_CAUSE_2				AS "Stat RES mult for termination cause 2"	
	, STAT_RES_OTHER_BENEFIT_RATES_TABLE				AS "Stat RES other benefit rates table"		
	, STAT_RES_TERMINATION_CAUSE_1_TABLE				AS "Stat RES termination cause 1 table"		
	, STAT_RES_TERMINATION_CAUSE_2_TABLE				AS "Stat RES termination cause 2 table"		
	, STAT_RES_TOTAL_PREMIUM_TABLE						AS "Stat RES total premium table"			
	, TAX_RES_EXPENSES_TABLE							AS "Tax RES expenses table"		
	, TAX_RES_INTEREST_TABLE							AS "Tax RES interest table"			
	, TAX_RES_LAPSE_RATE_TABLE							AS "Tax RES lapse rate table"			
	, TAX_RES_MORTALITY_IMPR_TABLE						AS "Tax RES mortality impr table"		
	, TAX_RES_MORTALITY_TABLE							AS "Tax RES mortality table"		
	, TAX_RES_MULT_FOR_MORTALITY_IMPR					AS "Tax RES mult for mortality impr"		
	, TAX_RES_OTHER_BENEFIT_RATES_TABLE					AS "Tax RES other benefit rates table"	
	, TAX_RES_TOTAL_PREMIUM_TABLE						AS "Tax RES total premium table"			
	, ALLOCATION_RULE_TABLE								AS "Allocation rule table"				
	, CEDED_INPUT_FACTORS_TABLE							AS "Ceded input factors table"			
	, DIV_ACTUAL_DIVIDEND_ADJUSTMENT_TABLE				AS "Div actual dividend adjustment table"
	, DIV_ACTUAL_MULT_FOR_DIVIDEND_ADJUSTMENT			AS "Div actual mult for dividend adjustment"		
	, DIVIDEND_EXPENSE_BASE_METHOD						AS "Dividend expense base method"				
	, DIVIDEND_FORMULA									AS "Dividend formula"							
	, FUND1_INVESTMENT									AS "Fund1 investment"							
	, INTEREST_GAIN_BASIS								AS "Interest gain basis"							
	, IS_LAPSE_USE_BASE_PLAN							AS "Is lapse use base plan"						
	, IS_MORTALITY_USE_BASE_PLAN						AS "Is mortality use base plan"					
	, METHOD_FORJ_JOINT_FIRST_LAPSE						AS "Method forj joint first lapse"				
	, STAT_RESERVE_METHOD_LINK							AS "Stat reserve method link"					
	, TAX_EXEMPT_INV_INC_TABLE							AS "Tax exempt inv inc table"					
	, TAX_FUND_BASED_RESERVE_ADJ_TABLE					AS "Tax fund based reserve adj table"			
	, TAX_INPUT_TERMINAL_RES_FACTORS_TABLE				AS "Tax input terminal res factors table"		
	, TAX_RESERVE_METHOD_LINK							AS "Tax reserve method link"						
	, TAXES_IIT_INTEREST_RATE_TABLE						AS "Taxes IIT interest rate table"				
	, TREATMENT_OF_GROUP									AS "Treatment of roup"							
	, BAREME_PAR_BLOCK									AS "Bareme par block"							
	, LIVRE_DE_TAUX_POUR_BAREME							AS "Livre de taux pour bareme"					
	, IFRSM_EXPENSES_TABLE								AS "IFRSM expenses table"						
	, IFRSM_INTEREST_TABLE								AS "IFRSM interest table"						
	, IFRSM_TAXES_IIT_INTEREST_RATE_TABLE				AS "IFRSM taxes IIT interest rate table"			
	, IFRSNM_EXPENSES_TABLE								AS "IFRSNM expenses table"		
FROM DM_VI.DIM_VALUATION_ASSUMPTIONS_TABLES;
create or replace view VW_FT_COMPTABILITE_DESAGREGEE(
	SK_ID_FT_COMPTABILITE_PRESTATION,
	ID_DATE_EVALUATION,
	SK_ID_DIM_COUVERTURE,
	SK_ID_DIM_COMPTE_GL,
	SK_ID_DIM_MASTER_COA,
	SK_ID_DIM_CODE_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_MODULE_COUVERTURE,
	SK_ID_DIM_RESEAU_DISTRIBUTION,
	ID_DIM_DATE_EMISSION,
	SK_ID_DIM_AGE_EMISSION,
	SK_ID_DIM_DUREE,
	ID_DIM_AGE_ATTEINT,
	SK_ID_DIM_SEXE,
	SK_ID_DIM_STATUT_FUMEUR,
	SK_ID_DIM_STATUT_PREFERENTIEL,
	SK_ID_DIM_RAISON_TERMINAISON,
	SK_ID_DIM_TRAITE_REASSURANCE,
	NO_POLICE,
	GEN_UID,
	SOURCE_SOE,
	MNT_COMPTABLE
) as
  SELECT FT.SK_ID_FT_COMPTABILITE_DESAGREGEE          AS SK_ID_FT_COMPTABILITE_PRESTATION,
         FT.ID_DATE_PERIODE_COMPTABLE                 AS ID_DATE_EVALUATION,
         FT.SK_ID_DIM_COUVERTURE                      AS SK_ID_DIM_COUVERTURE,
         CASE WHEN 
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FT.SK_ID_DIM_COMPTE_GL 
         END                                          AS SK_ID_DIM_COMPTE_GL,
         CASE WHEN 
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FT.SK_ID_DIM_MASTER_COA 
         END                                          AS SK_ID_DIM_MASTER_COA,    
         CASE WHEN 
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_CODE_PLAN_AXIS 
         END                                          AS SK_ID_DIM_CODE_PLAN_AXIS,
        CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_VALUATION_ASSUMPTIONS_TABLES 
         END                                          AS SK_ID_VALUATION_ASSUMPTIONS_TABLES,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_TERRITOIRE 
         END                                          AS SK_ID_DIM_TERRITOIRE,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_MODULE_COUVERTURE 
         END                                         AS SK_ID_DIM_MODULE_COUVERTURE,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
             FTC.SK_ID_DIM_RESEAU_DISTRIBUTION 
         END                                         AS SK_ID_DIM_RESEAU_DISTRIBUTION,
         FTC.ID_DIM_DATE_EMISSION                    AS ID_DIM_DATE_EMISSION,   
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_AGE_EMISSION 
         END                                         AS SK_ID_DIM_AGE_EMISSION,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_DUREE 
         END                                         AS SK_ID_DIM_DUREE,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_AGE_ATTEINT  
         END                                         AS ID_DIM_AGE_ATTEINT,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_SEXE 
         END                                         AS SK_ID_DIM_SEXE,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_STATUT_FUMEUR 
         END                                         AS SK_ID_DIM_STATUT_FUMEUR,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_STATUT_PREFERENTIEL 
         END                                         AS SK_ID_DIM_STATUT_PREFERENTIEL,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_RAISON_TERMINAISON 
         END                                         AS SK_ID_DIM_RAISON_TERMINAISON,
         CASE WHEN  
            FT.SK_ID_DIM_COUVERTURE < 0
         THEN
            FT.SK_ID_DIM_COUVERTURE 
         ELSE
            FTC.SK_ID_DIM_TRAITE_REASSURANCE 
         END                                         AS SK_ID_DIM_TRAITE_REASSURANCE,
         FT.NO_POLICE                                AS NO_POLICE,
         FT.GEN_UID                                  AS GEN_UID,
         FT.SOURCE_SOE                               AS SOURCE_SOE,            
         FT.MNT_COMPTABLE                            AS MNT_COMPTABLE
FROM DM_VI.FT_COMPTABILITE_DESAGREGEE FT
INNER JOIN DM_VI.DIM_DATE DD
        ON FT.ID_DATE_PERIODE_COMPTABLE = DD.ID_DIM_DATE
INNER JOIN DM_VI.FT_COUVERTURE FTC
    ON FT.SK_ID_DIM_COUVERTURE = FTC.SK_ID_DIM_COUVERTURE
    And DD.SHORT_NAME_FR between FTC.MD_ACTIVATION_DT and FTC.MD_OBSOLESCENCE_DT;
create or replace view VW_FT_COUVERTURE(
	SK_ID_FT_COUVERTURE,
	ID_DIM_DATE_EMISSION,
	ID_DIM_DATE_EVALUATION,
	SK_ID_DIM_COUVERTURE,
	SK_ID_DIM_MODULE_COUVERTURE,
	SK_ID_DIM_DUREE,
	SK_ID_DIM_AGE_EMISSION,
	SK_ID_DIM_AGE_ATTEINT,
	SK_ID_DIM_STATUT_PREFERENTIEL,
	SK_ID_DIM_SEXE,
	SK_ID_DIM_STATUT_FUMEUR,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_TRAITE_REASSURANCE,
	SK_ID_DIM_RESEAU_DISTRIBUTION,
	SK_ID_DIM_CODE_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_DIM_RAISON_TERMINAISON,
	GEN_UID,
	BANDE,
	BEN_CURRENT_VALUE,
	CODE_JOINT_LIFE,
	PRM_USERATING,
	RATING_MULT,
	RATING_FLAT,
	RATING_TEMP,
	RATING_TEMPDUR,
	PRM_MODE,
	BEN_OPTION,
	IND_COUVERTURE_TERMINEE,
	IND_GARANTIE,
	IND_TRANSFORMATION,
	IND_TRAITE_REASSURANCE,
	CODE_PARTICIPATION
) as

WITH DimDateEval
AS  (

    SELECT   ID_DIM_DATE_EVALUATION, CAST(left(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),4) || '-' || SUBSTRING(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),5,2) || '-' || RIGHT(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),2) AS DATE) AS DATE_EVAL
    FROM    DM_VI.FT_SOE_CASHFLOW
    UNION
    SELECT   ID_DIM_DATE_EVALUATION,  CAST(left(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),4) || '-' || SUBSTRING(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),5,2) || '-' || RIGHT(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),2) AS DATE) AS DATE_EVAL
    FROM    DM_VI.FT_SOE_FUND_RELEASE
    UNION
    SELECT   ID_DIM_DATE_EVALUATION,  CAST(left(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),4) || '-' || SUBSTRING(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),5,2) || '-' || RIGHT(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),2) AS DATE) AS DATE_EVAL
    FROM    DM_VI.FT_SOE_INVESTMENT_COMPONENT
    UNION
    SELECT   ID_DIM_DATE_EVALUATION,  CAST(left(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),4) || '-' || SUBSTRING(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),5,2) || '-' || RIGHT(CAST(ID_DIM_DATE_EVALUATION AS VARCHAR(8)),2) AS DATE) AS DATE_EVAL
    FROM    DM_VI.FT_SOE_RESERVE_RELEASE

)


SELECT 
    SK_ID_FT_COUVERTURE
    ,ID_DIM_DATE_EMISSION
    ,ID_DIM_DATE_EVALUATION
    ,SK_ID_DIM_COUVERTURE
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_MODULE_COUVERTURE 
    END SK_ID_DIM_MODULE_COUVERTURE
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_DUREE 
    END SK_ID_DIM_DUREE
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_AGE_EMISSION 
    END SK_ID_DIM_AGE_EMISSION
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_AGE_ATTEINT 
    END SK_ID_DIM_AGE_ATTEINT
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_STATUT_PREFERENTIEL 
    END SK_ID_DIM_STATUT_PREFERENTIEL
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_SEXE 
    END SK_ID_DIM_SEXE
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_STATUT_FUMEUR 
    END SK_ID_DIM_STATUT_FUMEUR
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_TERRITOIRE 
    END SK_ID_DIM_TERRITOIRE
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_TRAITE_REASSURANCE 
    END SK_ID_DIM_TRAITE_REASSURANCE
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_RESEAU_DISTRIBUTION 
    END SK_ID_DIM_RESEAU_DISTRIBUTION
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_CODE_PLAN_AXIS 
    END SK_ID_DIM_CODE_PLAN_AXIS
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_VALUATION_ASSUMPTIONS_TABLES 
    END SK_ID_VALUATION_ASSUMPTIONS_TABLES
    ,CASE WHEN  
        SK_ID_DIM_COUVERTURE < 0
    THEN
        SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_RAISON_TERMINAISON 
    END SK_ID_DIM_RAISON_TERMINAISON
    ,GEN_UID
    ,BANDE
    ,BEN_CURRENT_VALUE
    ,CODE_JOINT_LIFE
    ,PRM_USERATING
    ,RATING_MULT
    ,RATING_FLAT
    ,RATING_TEMP
    ,RATING_TEMPDUR
    ,PRM_MODE
    ,BEN_OPTION
    ,IND_COUVERTURE_TERMINEE
    ,IND_GARANTIE
    ,IND_TRANSFORMATION
    ,IND_TRAITE_REASSURANCE
    ,CODE_PARTICIPATION

FROM DM_VI.FT_COUVERTURE FT
INNER JOIN DimDateEval DT
        ON DATE_EVAL BETWEEN FT.MD_ACTIVATION_DT AND FT.MD_OBSOLESCENCE_DT;
create or replace view VW_FT_FONDS_RECLAMATION(
	ID_DATE_EVALUATION,
	SK_ID_INFO_COUVERTURE,
	SK_ID_SEXE,
	SK_ID_TABAGISME,
	SK_ID_STATUT_PREFERENTIEL,
	SK_ID_COUVERTURE,
	SK_ID_DUREE,
	SK_ID_AGE_ATTEINT,
	SK_ID_AGE_EMISSION,
	SK_ID_PRODUIT,
	SK_ID_MONTANT_ASSURANCE,
	SK_ID_TERRITOIRE,
	SK_ID_REASSURANCE,
	SK_ID_RESEAU_DISTRIBUTION,
	SK_ID_CD_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_MODULE_COUVERTURE,
	SK_ID_SURPRIME,
	SK_ID_RAISON_TERMINAISON,
	"Date émission couverture",
	"Gen UID",
	"Numéro police",
	"Funds surrenders",
	"Funds death claims",
	"Funds Other Movement"
) as
SELECT
      FT.ID_DATE_EVALUATION                                         AS ID_DATE_EVALUATION
    , FT.SK_ID_INFO_COUVERTURE                                      AS SK_ID_INFO_COUVERTURE
    , FT.SK_ID_SEXE                                                 AS SK_ID_SEXE
    , FT.SK_ID_TABAGISME                                            AS SK_ID_TABAGISME
    , FT.SK_ID_STATUT_PREFERENTIEL                                  AS SK_ID_STATUT_PREFERENTIEL
    , FT.SK_ID_COUVERTURE                                           AS SK_ID_COUVERTURE
    , FT.SK_ID_DUREE                                                AS SK_ID_DUREE
    , FT.SK_ID_AGE_ATTEINT                                          AS SK_ID_AGE_ATTEINT
    , FT.SK_ID_AGE_EMISSION                                         AS SK_ID_AGE_EMISSION
    , FT.SK_ID_PRODUIT                                              AS SK_ID_PRODUIT
    , FT.SK_ID_MONTANT_ASSURANCE                                    AS SK_ID_MONTANT_ASSURANCE
    , FT.SK_ID_TERRITOIRE                                           AS SK_ID_TERRITOIRE
    , FT.SK_ID_REASSURANCE                                          AS SK_ID_REASSURANCE
    , FT.SK_ID_RESEAU_DISTRIBUTION                                  AS SK_ID_RESEAU_DISTRIBUTION
    , FT.SK_ID_CD_PLAN_AXIS                                         AS SK_ID_CD_PLAN_AXIS
    , FT.SK_ID_VALUATION_ASSUMPTIONS_TABLES                         AS SK_ID_VALUATION_ASSUMPTIONS_TABLES
    , FT.SK_ID_MODULE_COUVERTURE                                    AS SK_ID_MODULE_COUVERTURE
    , FT.SK_ID_SURPRIME                                             AS SK_ID_SURPRIME
    , FT.SK_ID_RAISON_TERMINAISON                                   AS SK_ID_RAISON_TERMINAISON
    , TO_DATE(SUBSTRING(CAST(ID_DATE_EMISSION_COUVERTURE AS VARCHAR(8)),1,4)
        || '-' || SUBSTRING(CAST(ID_DATE_EMISSION_COUVERTURE AS VARCHAR(8)),5,2)
        || '-' || SUBSTRING(CAST(ID_DATE_EMISSION_COUVERTURE AS VARCHAR(8)),7,2))
                                                                    AS "Date émission couverture"
    , FT.GEN_UID                                                    AS "Gen UID"
    , FT.NO_POLICE                                                  AS "Numéro police"
    , FUNDS_SURRENDERS                                              AS "Funds surrenders"
    , FUNDS_DEATH_CLAIMS                                            AS "Funds death claims"
    , FUNDS_OTHER_MOVEMENT                                          AS "Funds Other Movement"
FROM DM_VI.FT_FONDS_RECLAMATION AS FT;
create or replace view VW_FT_SOE_CASHFLOW(
	SK_ID_FT_SOE_CASHFLOW,
	ID_DIM_DATE_EVALUATION,
	SK_ID_DIM_MODULE_COUVERTURE,
	SK_ID_DIM_COUVERTURE,
	GEN_UID,
	ID_DIM_DATE_EMISSION,
	SK_ID_DIM_DUREE,
	SK_ID_DIM_AGE_EMISSION,
	ID_DIM_AGE_ATTEINT,
	SK_ID_DIM_STATUT_PREFERENTIEL,
	SK_ID_DIM_SEXE,
	SK_ID_DIM_STATUT_FUMEUR,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_TRAITE_REASSURANCE,
	SK_ID_DIM_RESEAU_DISTRIBUTION,
	SK_ID_DIM_CODE_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_DIM_RAISON_TERMINAISON,
	"Ceded actual cashflow bonus",
	"Ceded actual cashflow commission",
	"Ceded actual cashflow commissionbonus",
	"Ceded actual cashflow creditedinterest",
	"Ceded actual cashflow deathbenefit",
	"Ceded actual cashflow deposit",
	"Ceded actual cashflow designatedfund",
	"Ceded actual cashflow dividendropsurvivors",
	"Ceded actual cashflow expense",
	"Ceded actual cashflow expensecharge",
	"Ceded actual cashflow latereport death",
	"Ceded actual cashflow latereport diclaimpaymentsc1",
	"Ceded actual cashflow latereport diclaimpaymentsc2",
	"Ceded actual cashflow latereport diclaimpaymentsc3",
	"Ceded actual cashflow latereport diclaimsexpense",
	"Ceded actual cashflow latereport dideathbenefitsc1",
	"Ceded actual cashflow latereport dideathbenefitsc2",
	"Ceded actual cashflow latereport dideathbenefitsc3",
	"Ceded actual cashflow latereport dividenddisabled",
	"Ceded actual cashflow latereport incurralc1",
	"Ceded actual cashflow latereport incurralc2",
	"Ceded actual cashflow latereport incurralc3",
	"Ceded actual cashflow latereport lapse",
	"Ceded actual cashflow latereport miscoff",
	"Ceded actual cashflow latereport miscon",
	"Ceded actual cashflow latereport newbus",
	"Ceded actual cashflow latereport nottakenup",
	"Ceded actual cashflow latereport otherben",
	"Ceded actual cashflow latereport reinstatement",
	"Ceded actual cashflow miscoff",
	"Ceded actual cashflow miscon",
	"Ceded actual cashflow nottakenup",
	"Ceded actual cashflow otherbenefit",
	"Ceded actual cashflow otherbenefitcharge",
	"Ceded actual cashflow partialwithdrawal",
	"Ceded actual cashflow policyloanpaid",
	"Ceded actual cashflow premium",
	"Ceded actual cashflow premiumload",
	"Ceded actual cashflow premiumtax",
	"Ceded actual cashflow recapturecharge",
	"Ceded actual cashflow reinsurancemargin",
	"Ceded actual cashflow returnofpremiums",
	"Ceded actual cashflow riskcharge",
	"Ceded actual cashflow surrenderbenefit",
	"Ceded expected cashflow bonus",
	"Ceded expected cashflow commission",
	"Ceded expected cashflow commissionbonus",
	"Ceded expected cashflow creditedinterest",
	"Ceded expected cashflow deathbenefit",
	"Ceded expected cashflow dividendropsurvivors",
	"Ceded expected cashflow deposit",
	"Ceded expected cashflow designatedfund",
	"Ceded expected cashflow expense",
	"Ceded expected cashflow latereport death",
	"Ceded expected cashflow latereport diclaimpaymentsc1",
	"Ceded expected cashflow latereport diclaimpaymentsc2",
	"Ceded expected cashflow latereport diclaimpaymentsc3",
	"Ceded expected cashflow latereport diclaimsexpense",
	"Ceded expected cashflow latereport dideathbenefitsc1",
	"Ceded expected cashflow latereport dideathbenefitsc2",
	"Ceded expected cashflow latereport dideathbenefitsc3",
	"Ceded expected cashflow latereport dividenddisabled",
	"Ceded expected cashflow latereport incurralc1",
	"Ceded expected cashflow latereport incurralc2",
	"Ceded expected cashflow latereport incurralc3",
	"Ceded expected cashflow expensecharge",
	"Ceded expected cashflow latereport lapse",
	"Ceded expected cashflow latereport miscoff",
	"Ceded expected cashflow latereport miscon",
	"Ceded expected cashflow latereport newbus",
	"Ceded expected cashflow latereport nottakenup",
	"Ceded expected cashflow latereport otherben",
	"Ceded expected cashflow latereport reinstatement",
	"Ceded expected cashflow miscoff",
	"Ceded expected cashflow miscon",
	"Ceded expected cashflow nottakenup",
	"Ceded expected cashflow otherbenefit",
	"Ceded expected cashflow otherbenefitcharge",
	"Ceded expected cashflow partialwithdrawal",
	"Ceded expected cashflow policyloanpaid",
	"Ceded expected cashflow premium",
	"Ceded expected cashflow premiumload",
	"Ceded expected cashflow premiumtax",
	"Ceded expected cashflow recapturecharge",
	"Ceded expected cashflow reinsurancemargin",
	"Ceded expected cashflow reinsurance",
	"Ceded expected cashflow returnofpremiums",
	"Ceded expected cashflow riskcharge",
	"Ceded expected cashflow surrenderbenefit",
	"Gross actual cashflow bonus",
	"Gross actual cashflow commission",
	"Gross actual cashflow commissionbonus",
	"Gross actual cashflow creditedinterest",
	"Gross actual cashflow deathbenefit",
	"Gross actual cashflow deposit",
	"Gross actual cashflow dividendropsurvivors",
	"Gross actual cashflow designedfund",
	"Gross actual cashflow expense",
	"Gross actual cashflow expensecharge",
	"Gross actual cashflow latereport death",
	"Gross actual cashflow latereport diclaimpaymentsc1",
	"Gross actual cashflow latereport diclaimpaymentsc2",
	"Gross actual cashflow latereport diclaimpaymentsc3",
	"Gross actual cashflow latereport diclaimsexpense",
	"Gross actual cashflow latereport dideathbenefitsc1",
	"Gross actual cashflow latereport dideathbenefitsc2",
	"Gross actual cashflow latereport dideathbenefitsc3",
	"Gross actual cashflow latereport dividenddisabled",
	"Gross actual cashflow latereport incurralc1",
	"Gross actual cashflow latereport incurralc2",
	"Gross actual cashflow latereport incurralc3",
	"Gross actual cashflow latereport lapse",
	"Gross actual cashflow latereport miscoff",
	"Gross actual cashflow latereport miscon",
	"Gross actual cashflow latereport newbus",
	"Gross actual cashflow latereport nottakenup",
	"Gross actual cashflow latereport otherben",
	"Gross actual cashflow latereport reinstatement",
	"Gross actual cashflow miscoff",
	"Gross actual cashflow miscon",
	"Gross actual cashflow nottakenup",
	"Gross actual cashflow otherbenefit",
	"Gross actual cashflow otherbenefitcharge",
	"Gross actual cashflow partialwithdrawal",
	"Gross actual cashflow policyloanpaid",
	"Gross actual cashflow premium",
	"Gross actual cashflow premiumload",
	"Gross actual cashflow premiumtax",
	"Gross actual cashflow recapturecharge",
	"Gross actual cashflow reinsurancemargin",
	"Gross actual cashflow returnofpremiums",
	"Gross actual cashflow riskcharge",
	"Gross actual cashflow surrenderbenefit",
	"Gross expected cashflow bonus",
	"Gross expected cashflow commission",
	"Gross expected cashflow commissionbonus",
	"Gross expected cashflow creditedinterest",
	"Gross expected cashflow deathbenefit",
	"Gross expected cashflow dividendropsurvivors",
	"Gross expected cashflow deposit",
	"Gross expected cashflow designatedfund",
	"Gross expected cashflow expense",
	"Gross expected cashflow expensecharge",
	"Gross expected cashflow latereport death",
	"Gross expected cashflow latereport diclaimpaymentsc1",
	"Gross expected cashflow latereport diclaimpaymentsc2",
	"Gross expected cashflow latereport diclaimpaymentsc3",
	"Gross expected cashflow latereport diclaimsexpense",
	"Gross expected cashflow latereport dideathbenefitsc1",
	"Gross expected cashflow latereport dideathbenefitsc2",
	"Gross expected cashflow latereport dideathbenefitsc3",
	"Gross expected cashflow latereport dividenddisabled",
	"Gross expected cashflow latereport incurralc1",
	"Gross expected cashflow latereport incurralc2",
	"Gross expected cashflow latereport incurralc3",
	"Gross expected cashflow latereport lapse",
	"Gross expected cashflow latereport miscoff",
	"Gross expected cashflow latereport miscon",
	"Gross expected cashflow latereport newbus",
	"Gross expected cashflow latereport nottakenup",
	"Gross expected cashflow latereport otherben",
	"Gross expected cashflow latereport reinstatement",
	"Gross expected cashflow miscoff",
	"Gross expected cashflow miscon",
	"Gross expected cashflow nottakenup",
	"Gross expected cashflow otherbenefit",
	"Gross expected cashflow otherbenefitcharge",
	"Gross expected cashflow partialwithdrawal",
	"Gross expected cashflow policyloanpaid",
	"Gross expected cashflow premium",
	"Gross expected cashflow premiumload",
	"Gross expected cashflow premiumtax",
	"Gross expected cashflow recapturecharge",
	"Gross expected cashflow reinsurancemargin",
	"Gross expected cashflow returnofpremiums",
	"Gross expected cashflow riskcharge",
	"Gross expected cashflow surrender",
	"Gross expected cashflow surrenderbenefit"
) as

SELECT
     CASH.SK_ID_FT_SOE_CASHFLOW
    ,CASH.ID_DIM_DATE_EVALUATION
    ,CASE WHEN  
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        CASH.SK_ID_DIM_MODULE_COUVERTURE 
    END AS SK_ID_DIM_MODULE_COUVERTURE   
    ,CASH.SK_ID_DIM_COUVERTURE
    ,CASH.GEN_UID
    ,ID_DIM_DATE_EMISSION
    ,CASE WHEN  
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_DUREE 
    END SK_ID_DIM_DUREE
    ,SK_ID_DIM_AGE_EMISSION
    ,CASE WHEN  
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_AGE_ATTEINT  
    END AS ID_DIM_AGE_ATTEINT
    ,CASE WHEN  
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_STATUT_PREFERENTIEL 
    END AS SK_ID_DIM_STATUT_PREFERENTIEL
    ,CASE WHEN  
       CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
       CASH.SK_ID_DIM_COUVERTURE
    ELSE
        SK_ID_DIM_SEXE 
    END AS SK_ID_DIM_SEXE
    ,CASE WHEN  
       CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
       CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_STATUT_FUMEUR
    END AS SK_ID_DIM_STATUT_FUMEUR                       
    ,CASE WHEN  
       CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
       CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_TERRITOIRE 
    END AS SK_ID_DIM_TERRITOIRE
    ,CASE WHEN  
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_TRAITE_REASSURANCE 
    END AS SK_ID_DIM_TRAITE_REASSURANCE
    ,CASE WHEN  
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_RESEAU_DISTRIBUTION 
    END AS SK_ID_DIM_RESEAU_DISTRIBUTION
    ,CASE WHEN 
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_CODE_PLAN_AXIS 
    END AS SK_ID_DIM_CODE_PLAN_AXIS
    ,CASE WHEN  
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_VALUATION_ASSUMPTIONS_TABLES 
    END AS SK_ID_VALUATION_ASSUMPTIONS_TABLES
    ,CASE WHEN  
        CASH.SK_ID_DIM_COUVERTURE < 0
    THEN
        CASH.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_RAISON_TERMINAISON 
    END AS SK_ID_DIM_RAISON_TERMINAISON
    ,CEDED_ACTUAL_CASHFLOW_BONUS AS "Ceded actual cashflow bonus"
    ,CEDED_ACTUAL_CASHFLOW_COMMISSION AS "Ceded actual cashflow commission"
    ,CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS AS "Ceded actual cashflow commissionbonus"
    ,CEDED_ACTUAL_CASHFLOW_CREDITEDINTEREST AS "Ceded actual cashflow creditedinterest"
    ,CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT AS "Ceded actual cashflow deathbenefit"
    ,CEDED_ACTUAL_CASHFLOW_DEPOSIT AS "Ceded actual cashflow deposit"
    ,CEDED_ACTUAL_CASHFLOW_DESIGNATEDFUND AS "Ceded actual cashflow designatedfund"
    ,CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS AS "Ceded actual cashflow dividendropsurvivors"
    ,CEDED_ACTUAL_CASHFLOW_EXPENSE AS "Ceded actual cashflow expense"
    ,CEDED_ACTUAL_CASHFLOW_EXPENSECHARGE AS "Ceded actual cashflow expensecharge"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH AS "Ceded actual cashflow latereport death"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 AS "Ceded actual cashflow latereport diclaimpaymentsc1"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 AS "Ceded actual cashflow latereport diclaimpaymentsc2"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 AS "Ceded actual cashflow latereport diclaimpaymentsc3"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE AS "Ceded actual cashflow latereport diclaimsexpense"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 AS "Ceded actual cashflow latereport dideathbenefitsc1"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 AS "Ceded actual cashflow latereport dideathbenefitsc2"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 AS "Ceded actual cashflow latereport dideathbenefitsc3"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIVIDENDDISABLED AS "Ceded actual cashflow latereport dividenddisabled"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC1 AS "Ceded actual cashflow latereport incurralc1"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC2 AS "Ceded actual cashflow latereport incurralc2"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC3 AS "Ceded actual cashflow latereport incurralc3"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE AS "Ceded actual cashflow latereport lapse"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF AS "Ceded actual cashflow latereport miscoff"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON AS "Ceded actual cashflow latereport miscon"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS AS "Ceded actual cashflow latereport newbus"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP AS "Ceded actual cashflow latereport nottakenup"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN AS "Ceded actual cashflow latereport otherben"
    ,CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT AS "Ceded actual cashflow latereport reinstatement"
    ,CEDED_ACTUAL_CASHFLOW_MISCOFF AS "Ceded actual cashflow miscoff"
    ,CEDED_ACTUAL_CASHFLOW_MISCON AS "Ceded actual cashflow miscon"
    ,CEDED_ACTUAL_CASHFLOW_NOTTAKENUP AS "Ceded actual cashflow nottakenup"
    ,CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT AS "Ceded actual cashflow otherbenefit"
    ,CEDED_ACTUAL_CASHFLOW_OTHERBENEFITCHARGE AS "Ceded actual cashflow otherbenefitcharge"
    ,CEDED_ACTUAL_CASHFLOW_PARTIALWITHDRAWAL AS "Ceded actual cashflow partialwithdrawal"
    ,CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID AS "Ceded actual cashflow policyloanpaid"
    ,CEDED_ACTUAL_CASHFLOW_PREMIUM AS "Ceded actual cashflow premium"
    ,CEDED_ACTUAL_CASHFLOW_PREMIUMLOAD AS "Ceded actual cashflow premiumload"
    ,CEDED_ACTUAL_CASHFLOW_PREMIUMTAX AS "Ceded actual cashflow premiumtax"
    ,CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE AS "Ceded actual cashflow recapturecharge"
    ,CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN AS "Ceded actual cashflow reinsurancemargin"
    ,CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS AS "Ceded actual cashflow returnofpremiums"
    ,CEDED_ACTUAL_CASHFLOW_RISKCHARGE AS "Ceded actual cashflow riskcharge"
    ,CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT AS "Ceded actual cashflow surrenderbenefit"
    ,CEDED_EXPECTED_CASHFLOW_BONUS AS "Ceded expected cashflow bonus"
    ,CEDED_EXPECTED_CASHFLOW_COMMISSION AS "Ceded expected cashflow commission"
    ,CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS AS "Ceded expected cashflow commissionbonus"
    ,CEDED_EXPECTED_CASHFLOW_CREDITEDINTEREST AS "Ceded expected cashflow creditedinterest"
    ,CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT AS "Ceded expected cashflow deathbenefit"
    ,CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS AS "Ceded expected cashflow dividendropsurvivors"
    ,CEDED_EXPECTED_CASHFLOW_DEPOSIT AS "Ceded expected cashflow deposit"
    ,CEDED_EXPECTED_CASHFLOW_DESIGNATEDFUND AS "Ceded expected cashflow designatedfund"
    ,CEDED_EXPECTED_CASHFLOW_EXPENSE AS "Ceded expected cashflow expense"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH AS "Ceded expected cashflow latereport death"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 AS "Ceded expected cashflow latereport diclaimpaymentsc1"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 AS "Ceded expected cashflow latereport diclaimpaymentsc2"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 AS "Ceded expected cashflow latereport diclaimpaymentsc3"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE AS "Ceded expected cashflow latereport diclaimsexpense"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 AS "Ceded expected cashflow latereport dideathbenefitsc1"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 AS "Ceded expected cashflow latereport dideathbenefitsc2"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 AS "Ceded expected cashflow latereport dideathbenefitsc3"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIVIDENDDISABLED AS "Ceded expected cashflow latereport dividenddisabled"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC1 AS "Ceded expected cashflow latereport incurralc1"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC2 AS "Ceded expected cashflow latereport incurralc2"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC3 AS "Ceded expected cashflow latereport incurralc3"
    ,CEDED_EXPECTED_CASHFLOW_EXPENSECHARGE AS "Ceded expected cashflow expensecharge"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE AS "Ceded expected cashflow latereport lapse"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF AS "Ceded expected cashflow latereport miscoff"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON AS "Ceded expected cashflow latereport miscon"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS AS "Ceded expected cashflow latereport newbus"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP AS "Ceded expected cashflow latereport nottakenup"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN AS "Ceded expected cashflow latereport otherben"
    ,CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT AS "Ceded expected cashflow latereport reinstatement"
    ,CEDED_EXPECTED_CASHFLOW_MISCOFF AS "Ceded expected cashflow miscoff"
    ,CEDED_EXPECTED_CASHFLOW_MISCON AS "Ceded expected cashflow miscon"
    ,CEDED_EXPECTED_CASHFLOW_NOTTAKENUP AS "Ceded expected cashflow nottakenup"
    ,CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT AS "Ceded expected cashflow otherbenefit"
    ,CEDED_EXPECTED_CASHFLOW_OTHERBENEFITCHARGE AS "Ceded expected cashflow otherbenefitcharge"
    ,CEDED_EXPECTED_CASHFLOW_PARTIALWITHDRAWAL AS "Ceded expected cashflow partialwithdrawal"
    ,CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID AS "Ceded expected cashflow policyloanpaid"
    ,CEDED_EXPECTED_CASHFLOW_PREMIUM AS "Ceded expected cashflow premium"
    ,CEDED_EXPECTED_CASHFLOW_PREMIUMLOAD AS "Ceded expected cashflow premiumload"
    ,CEDED_EXPECTED_CASHFLOW_PREMIUMTAX AS "Ceded expected cashflow premiumtax"
    ,CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE AS "Ceded expected cashflow recapturecharge"
    ,CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN AS "Ceded expected cashflow reinsurancemargin"
    ,CEDED_EXPECTED_CASHFLOW_REINSURANCE AS "Ceded expected cashflow reinsurance"
    ,CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS AS "Ceded expected cashflow returnofpremiums"
    ,CEDED_EXPECTED_CASHFLOW_RISKCHARGE AS "Ceded expected cashflow riskcharge"
    ,CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT AS "Ceded expected cashflow surrenderbenefit"
    ,GROSS_ACTUAL_CASHFLOW_BONUS AS "Gross actual cashflow bonus"
    ,GROSS_ACTUAL_CASHFLOW_COMMISSION AS "Gross actual cashflow commission"
    ,GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS AS "Gross actual cashflow commissionbonus"
    ,GROSS_ACTUAL_CASHFLOW_CREDITEDINTEREST AS "Gross actual cashflow creditedinterest"
    ,GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT AS "Gross actual cashflow deathbenefit"
    ,GROSS_ACTUAL_CASHFLOW_DEPOSIT AS "Gross actual cashflow deposit"
    ,GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS AS "Gross actual cashflow dividendropsurvivors"
    ,GROSS_ACTUAL_CASHFLOW_DESIGNEDFUND AS "Gross actual cashflow designedfund"
    ,GROSS_ACTUAL_CASHFLOW_EXPENSE AS "Gross actual cashflow expense"
    ,GROSS_ACTUAL_CASHFLOW_EXPENSECHARGE AS "Gross actual cashflow expensecharge"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH AS "Gross actual cashflow latereport death"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 AS "Gross actual cashflow latereport diclaimpaymentsc1"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 AS "Gross actual cashflow latereport diclaimpaymentsc2"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 AS "Gross actual cashflow latereport diclaimpaymentsc3"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE AS "Gross actual cashflow latereport diclaimsexpense"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 AS "Gross actual cashflow latereport dideathbenefitsc1"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 AS "Gross actual cashflow latereport dideathbenefitsc2"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 AS "Gross actual cashflow latereport dideathbenefitsc3"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIVIDENDDISABLED AS "Gross actual cashflow latereport dividenddisabled"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC1 AS "Gross actual cashflow latereport incurralc1"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC2 AS "Gross actual cashflow latereport incurralc2"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC3 AS "Gross actual cashflow latereport incurralc3"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE AS "Gross actual cashflow latereport lapse"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF AS "Gross actual cashflow latereport miscoff"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON AS "Gross actual cashflow latereport miscon"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS AS "Gross actual cashflow latereport newbus"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP AS "Gross actual cashflow latereport nottakenup"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN AS "Gross actual cashflow latereport otherben"
    ,GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT AS "Gross actual cashflow latereport reinstatement"
    ,GROSS_ACTUAL_CASHFLOW_MISCOFF AS "Gross actual cashflow miscoff"
    ,GROSS_ACTUAL_CASHFLOW_MISCON AS "Gross actual cashflow miscon"
    ,GROSS_ACTUAL_CASHFLOW_NOTTAKENUP AS "Gross actual cashflow nottakenup"
    ,GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT AS "Gross actual cashflow otherbenefit"
    ,GROSS_ACTUAL_CASHFLOW_OTHERBENEFITCHARGE AS "Gross actual cashflow otherbenefitcharge"
    ,GROSS_ACTUAL_CASHFLOW_PARTIALWITHDRAWAL AS "Gross actual cashflow partialwithdrawal"
    ,GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID AS "Gross actual cashflow policyloanpaid"
    ,GROSS_ACTUAL_CASHFLOW_PREMIUM AS "Gross actual cashflow premium"
    ,GROSS_ACTUAL_CASHFLOW_PREMIUMLOAD AS "Gross actual cashflow premiumload"
    ,GROSS_ACTUAL_CASHFLOW_PREMIUMTAX AS "Gross actual cashflow premiumtax"
    ,GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE AS "Gross actual cashflow recapturecharge"
    ,GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN AS "Gross actual cashflow reinsurancemargin"
    ,GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS AS "Gross actual cashflow returnofpremiums"
    ,GROSS_ACTUAL_CASHFLOW_RISKCHARGE AS "Gross actual cashflow riskcharge"
    ,GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT AS "Gross actual cashflow surrenderbenefit"
    ,GROSS_EXPECTED_CASHFLOW_BONUS AS "Gross expected cashflow bonus"
    ,GROSS_EXPECTED_CASHFLOW_COMMISSION AS "Gross expected cashflow commission"
    ,GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS AS "Gross expected cashflow commissionbonus"
    ,GROSS_EXPECTED_CASHFLOW_CREDITEDINTEREST AS "Gross expected cashflow creditedinterest"
    ,GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT AS "Gross expected cashflow deathbenefit"
    ,GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS AS "Gross expected cashflow dividendropsurvivors"
    ,GROSS_EXPECTED_CASHFLOW_DEPOSIT AS "Gross expected cashflow deposit"
    ,GROSS_EXPECTED_CASHFLOW_DESIGNATEDFUND AS "Gross expected cashflow designatedfund"
    ,GROSS_EXPECTED_CASHFLOW_EXPENSE AS "Gross expected cashflow expense"
    ,GROSS_EXPECTED_CASHFLOW_EXPENSECHARGE AS "Gross expected cashflow expensecharge"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH AS "Gross expected cashflow latereport death"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 AS "Gross expected cashflow latereport diclaimpaymentsc1"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 AS "Gross expected cashflow latereport diclaimpaymentsc2"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 AS "Gross expected cashflow latereport diclaimpaymentsc3"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE AS "Gross expected cashflow latereport diclaimsexpense"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 AS "Gross expected cashflow latereport dideathbenefitsc1"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 AS "Gross expected cashflow latereport dideathbenefitsc2"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 AS "Gross expected cashflow latereport dideathbenefitsc3"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIVIDENDDISABLED AS "Gross expected cashflow latereport dividenddisabled"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC1 AS "Gross expected cashflow latereport incurralc1"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC2 AS "Gross expected cashflow latereport incurralc2"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC3 AS "Gross expected cashflow latereport incurralc3"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE AS "Gross expected cashflow latereport lapse"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF AS "Gross expected cashflow latereport miscoff"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON AS "Gross expected cashflow latereport miscon"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS AS "Gross expected cashflow latereport newbus"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP AS "Gross expected cashflow latereport nottakenup"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN AS "Gross expected cashflow latereport otherben"
    ,GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT AS "Gross expected cashflow latereport reinstatement"
    ,GROSS_EXPECTED_CASHFLOW_MISCOFF AS "Gross expected cashflow miscoff"
    ,GROSS_EXPECTED_CASHFLOW_MISCON AS "Gross expected cashflow miscon"
    ,GROSS_EXPECTED_CASHFLOW_NOTTAKENUP AS "Gross expected cashflow nottakenup"
    ,GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT AS "Gross expected cashflow otherbenefit"
    ,GROSS_EXPECTED_CASHFLOW_OTHERBENEFITCHARGE AS "Gross expected cashflow otherbenefitcharge"
    ,GROSS_EXPECTED_CASHFLOW_PARTIALWITHDRAWAL AS "Gross expected cashflow partialwithdrawal"
    ,GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID AS "Gross expected cashflow policyloanpaid"
    ,GROSS_EXPECTED_CASHFLOW_PREMIUM AS "Gross expected cashflow premium"
    ,GROSS_EXPECTED_CASHFLOW_PREMIUMLOAD AS "Gross expected cashflow premiumload"
    ,GROSS_EXPECTED_CASHFLOW_PREMIUMTAX AS "Gross expected cashflow premiumtax"
    ,GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE AS "Gross expected cashflow recapturecharge"
    ,GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN AS "Gross expected cashflow reinsurancemargin"
    ,GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS AS "Gross expected cashflow returnofpremiums"
    ,GROSS_EXPECTED_CASHFLOW_RISKCHARGE AS "Gross expected cashflow riskcharge"
    ,GROSS_EXPECTED_CASHFLOW_SURRENDER AS "Gross expected cashflow surrender"
    ,GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT AS "Gross expected cashflow surrenderbenefit"
FROM DM_VI.FT_SOE_CASHFLOW CASH
INNER JOIN DM_VI.DIM_DATE DT on DT.ID_DIM_DATE = CASH.ID_DIM_DATE_EVALUATION
LEFT JOIN DM_VI.FT_COUVERTURE FTC ON CASH.SK_ID_DIM_COUVERTURE  = FTC.SK_ID_DIM_COUVERTURE
and CASH.SK_ID_DIM_MODULE_COUVERTURE  = FTC.SK_ID_DIM_MODULE_COUVERTURE
and DT.SHORT_NAME_FR between FTC.MD_ACTIVATION_DT and FTC.MD_OBSOLESCENCE_DT;
create or replace view VW_FT_SOE_FUND_RELEASE(
	SK_ID_FT_SOE_FUND_RELEASE,
	SK_ID_DIM_MODULE_COUVERTURE,
	SK_ID_DIM_COUVERTURE,
	ID_DIM_DATE_EVALUATION,
	GEN_UID,
	SK_ID_DIM_DUREE,
	SK_ID_DIM_AGE_EMISSION,
	SK_ID_DIM_AGE_ATTEINT,
	SK_ID_DIM_STATUT_PREFERENTIEL,
	SK_ID_DIM_SEXE,
	SK_ID_DIM_STATUT_FUMEUR,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_TRAITE_REASSURANCE,
	SK_ID_DIM_RESEAU_DISTRIBUTION,
	SK_ID_DIM_CODE_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_DIM_RAISON_TERMINAISON,
	"Ceded actual cashflows fund increase on latenb",
	"Ceded actual cashflows fund increase on miscon",
	"Ceded actual cashflows fund release on death",
	"Ceded actual cashflows fund release on miscoff",
	"Ceded actual cashflows fund release on otherbenefit",
	"Ceded actual cashflows fund release on partialwithdrawal",
	"Ceded actual cashflows fund release on surrender",
	"Ceded expected cashflows fund increase on latenb",
	"Ceded expected cashflows fund increase on miscon",
	"Ceded expected cashflows fund release on death",
	"Ceded expected cashflows fund release on miscoff",
	"Ceded expected cashflows fund release on otherbenefit",
	"Ceded expected cashflows fund release on partialwithdrawal",
	"Ceded expected cashflows fund release on surrender",
	"Gross actual cashflows fund increase on latenb",
	"Gross actual cashflows fund increase on miscon",
	"Gross actual cashflows fund release on death",
	"Gross actual cashflows fund release on miscoff",
	"Gross actual cashflows fund release on otherbenefit",
	"Gross actual cashflows fund release on partialwithdrawal",
	"Gross actual cashflows fund release on surrender",
	"Gross expected cashflows fund increase on latenb",
	"Gross expected cashflows fund increase on miscon",
	"Gross expected cashflows fund release on death",
	"Gross expected cashflows fund release on miscoff",
	"Gross expected cashflows fund release on otherbenefit",
	"Gross expected cashflows fund release on partialwithdrawal",
	"Gross expected cashflows fund release on surrender"
) as

SELECT
 
     FRL.SK_ID_FT_SOE_FUND_RELEASE
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        FRL.SK_ID_DIM_MODULE_COUVERTURE
    END SK_ID_DIM_MODULE_COUVERTURE  
    ,FRL.SK_ID_DIM_COUVERTURE
    ,FRL.ID_DIM_DATE_EVALUATION
    ,FRL.GEN_UID
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_DUREE 
    END SK_ID_DIM_DUREE
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_AGE_EMISSION 
    END SK_ID_DIM_AGE_EMISSION
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_AGE_ATTEINT 
    END SK_ID_DIM_AGE_ATTEINT
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_STATUT_PREFERENTIEL 
    END SK_ID_DIM_STATUT_PREFERENTIEL
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_SEXE 
    END SK_ID_DIM_SEXE
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_STATUT_FUMEUR 
    END SK_ID_DIM_STATUT_FUMEUR
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_TERRITOIRE 
    END SK_ID_DIM_TERRITOIRE
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_TRAITE_REASSURANCE 
    END SK_ID_DIM_TRAITE_REASSURANCE
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_RESEAU_DISTRIBUTION 
    END SK_ID_DIM_RESEAU_DISTRIBUTION
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_CODE_PLAN_AXIS 
    END SK_ID_DIM_CODE_PLAN_AXIS
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_VALUATION_ASSUMPTIONS_TABLES 
    END SK_ID_VALUATION_ASSUMPTIONS_TABLES
    ,CASE WHEN  
        FRL.SK_ID_DIM_COUVERTURE < 0
    THEN
        FRL.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_RAISON_TERMINAISON 
    END SK_ID_DIM_RAISON_TERMINAISON    
    ,CEDED_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_LATENB AS "Ceded actual cashflows fund increase on latenb"
    ,CEDED_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_MISCON AS "Ceded actual cashflows fund increase on miscon"
    ,CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_DEATH AS "Ceded actual cashflows fund release on death"
    ,CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_MISCOFF AS "Ceded actual cashflows fund release on miscoff"
    ,CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT AS "Ceded actual cashflows fund release on otherbenefit"
    ,CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL AS "Ceded actual cashflows fund release on partialwithdrawal"
    ,CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_SURRENDER AS "Ceded actual cashflows fund release on surrender"
    ,CEDED_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_LATENB AS "Ceded expected cashflows fund increase on latenb"
    ,CEDED_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_MISCON AS "Ceded expected cashflows fund increase on miscon"
    ,CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_DEATH AS "Ceded expected cashflows fund release on death"
    ,CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_MISCOFF AS "Ceded expected cashflows fund release on miscoff"
    ,CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT AS "Ceded expected cashflows fund release on otherbenefit"
    ,CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL AS "Ceded expected cashflows fund release on partialwithdrawal"
    ,CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_SURRENDER AS "Ceded expected cashflows fund release on surrender"
    ,GROSS_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_LATENB AS "Gross actual cashflows fund increase on latenb"
    ,GROSS_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_MISCON AS "Gross actual cashflows fund increase on miscon"
    ,GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_DEATH AS "Gross actual cashflows fund release on death"
    ,GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_MISCOFF AS "Gross actual cashflows fund release on miscoff"
    ,GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT AS "Gross actual cashflows fund release on otherbenefit"
    ,GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL AS "Gross actual cashflows fund release on partialwithdrawal"
    ,GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_SURRENDER AS "Gross actual cashflows fund release on surrender"
    ,GROSS_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_LATENB AS "Gross expected cashflows fund increase on latenb"
    ,GROSS_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_MISCON AS "Gross expected cashflows fund increase on miscon"
    ,GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_DEATH AS "Gross expected cashflows fund release on death"
    ,GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_MISCOFF AS "Gross expected cashflows fund release on miscoff"
    ,GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT AS "Gross expected cashflows fund release on otherbenefit"
    ,GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL AS "Gross expected cashflows fund release on partialwithdrawal"
    ,GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_SURRENDER AS "Gross expected cashflows fund release on surrender"

FROM DM_VI.FT_SOE_FUND_RELEASE FRL
INNER JOIN DM_VI.DIM_DATE DT on DT.ID_DIM_DATE = FRL.ID_DIM_DATE_EVALUATION
LEFT JOIN DM_VI.FT_COUVERTURE FTC ON FRL.SK_ID_DIM_COUVERTURE  = FTC.SK_ID_DIM_COUVERTURE
and FRL.SK_ID_DIM_MODULE_COUVERTURE  = FTC.SK_ID_DIM_MODULE_COUVERTURE
and DT.SHORT_NAME_FR between FTC.MD_ACTIVATION_DT and FTC.MD_OBSOLESCENCE_DT;
create or replace view VW_FT_SOE_INVESTMENT_COMPONENT(
	SK_ID_FT_SOE_INVESTMENT_COMPONENT,
	ID_DIM_DATE_EVALUATION,
	SK_ID_DIM_MODULE_COUVERTURE,
	SK_ID_DIM_COUVERTURE,
	GEN_UID,
	ID_DIM_DATE_EMISSION,
	SK_ID_DIM_DUREE,
	SK_ID_DIM_AGE_EMISSION,
	SK_ID_DIM_AGE_ATTEINT,
	SK_ID_DIM_STATUT_PREFERENTIEL,
	SK_ID_DIM_SEXE,
	SK_ID_DIM_STATUT_FUMEUR,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_TRAITE_REASSURANCE,
	SK_ID_DIM_RESEAU_DISTRIBUTION,
	SK_ID_DIM_CODE_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_DIM_RAISON_TERMINAISON,
	CEDED_ACTUAL_INVCOMP_DEATH,
	CEDED_ACTUAL_INVCOMP_LAPSE,
	CEDED_ACTUAL_INVCOMP_OTHERBEN,
	CEDED_ACTUAL_INVCOMP_SURVIVORS,
	CEDED_EXPECTED_INVCOMP_DEATH,
	CEDED_EXPECTED_INVCOMP_LAPSE,
	CEDED_EXPECTED_INVCOMP_OTHERBEN,
	CEDED_EXPECTED_INVCOMP_SURVIVORS,
	GROSS_ACTUAL_INVCOMP_DEATH,
	GROSS_ACTUAL_INVCOMP_LAPSE,
	GROSS_ACTUAL_INVCOMP_OTHERBEN,
	GROSS_ACTUAL_INVCOMP_SURVIVORS,
	GROSS_EXPECTED_INVCOMP_DEATH,
	GROSS_EXPECTED_INVCOMP_LAPSE,
	GROSS_EXPECTED_INVCOMP_OTHERBEN,
	GROSS_EXPECTED_INVCOMP_SURVIVORS,
	CEDED_ACTUAL_INVCOMP_INCIDENCE,
	GROSS_ACTUAL_INVCOMP_INCIDENCE,
	CEDED_EXPECTED_INVCOMP_INCIDENCE,
	GROSS_EXPECTED_INVCOMP_INCIDENCE
) as

SELECT
 
    INV.SK_ID_FT_SOE_INVESTMENT_COMPONENT
    ,INV.ID_DIM_DATE_EVALUATION
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        INV.SK_ID_DIM_MODULE_COUVERTURE
    END SK_ID_DIM_MODULE_COUVERTURE  
    ,INV.SK_ID_DIM_COUVERTURE
    ,INV.GEN_UID
    ,ID_DIM_DATE_EMISSION
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_DUREE 
    END SK_ID_DIM_DUREE
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_AGE_EMISSION 
    END SK_ID_DIM_AGE_EMISSION
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_AGE_ATTEINT 
    END SK_ID_DIM_AGE_ATTEINT
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_STATUT_PREFERENTIEL 
    END SK_ID_DIM_STATUT_PREFERENTIEL
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_SEXE 
    END SK_ID_DIM_SEXE
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_STATUT_FUMEUR 
    END SK_ID_DIM_STATUT_FUMEUR
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_TERRITOIRE 
    END SK_ID_DIM_TERRITOIRE
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_TRAITE_REASSURANCE 
    END SK_ID_DIM_TRAITE_REASSURANCE
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_RESEAU_DISTRIBUTION 
    END SK_ID_DIM_RESEAU_DISTRIBUTION
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_CODE_PLAN_AXIS 
    END SK_ID_DIM_CODE_PLAN_AXIS
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_VALUATION_ASSUMPTIONS_TABLES 
    END SK_ID_VALUATION_ASSUMPTIONS_TABLES
    ,CASE WHEN  
        INV.SK_ID_DIM_COUVERTURE < 0
    THEN
        INV.SK_ID_DIM_COUVERTURE 
    ELSE
        SK_ID_DIM_RAISON_TERMINAISON 
    END SK_ID_DIM_RAISON_TERMINAISON
    ,CEDED_ACTUAL_INVCOMP_DEATH
    ,CEDED_ACTUAL_INVCOMP_LAPSE
    ,CEDED_ACTUAL_INVCOMP_OTHERBEN
    ,CEDED_ACTUAL_INVCOMP_SURVIVORS
    ,CEDED_EXPECTED_INVCOMP_DEATH
    ,CEDED_EXPECTED_INVCOMP_LAPSE
    ,CEDED_EXPECTED_INVCOMP_OTHERBEN
    ,CEDED_EXPECTED_INVCOMP_SURVIVORS
    ,GROSS_ACTUAL_INVCOMP_DEATH
    ,GROSS_ACTUAL_INVCOMP_LAPSE
    ,GROSS_ACTUAL_INVCOMP_OTHERBEN
    ,GROSS_ACTUAL_INVCOMP_SURVIVORS
    ,GROSS_EXPECTED_INVCOMP_DEATH
    ,GROSS_EXPECTED_INVCOMP_LAPSE
    ,GROSS_EXPECTED_INVCOMP_OTHERBEN
    ,GROSS_EXPECTED_INVCOMP_SURVIVORS
    ,CEDED_ACTUAL_INVCOMP_INCIDENCE
    ,GROSS_ACTUAL_INVCOMP_INCIDENCE
    ,CEDED_EXPECTED_INVCOMP_INCIDENCE
    ,GROSS_EXPECTED_INVCOMP_INCIDENCE    

FROM DM_VI.FT_SOE_INVESTMENT_COMPONENT INV
INNER JOIN DM_VI.DIM_DATE DT on DT.ID_DIM_DATE = INV.ID_DIM_DATE_EVALUATION
LEFT JOIN DM_VI.FT_COUVERTURE FTC ON INV.SK_ID_DIM_COUVERTURE  = FTC.SK_ID_DIM_COUVERTURE
and INV.SK_ID_DIM_MODULE_COUVERTURE  = FTC.SK_ID_DIM_MODULE_COUVERTURE
and DT.SHORT_NAME_FR between FTC.MD_ACTIVATION_DT and FTC.MD_OBSOLESCENCE_DT;
create or replace view VW_FT_SOE_OTHER_BENEFITS(
	SK_ID_FT_SOE_OTHER_BENEFITS,
	SK_ID_DIM_MODULE_COUVERTURE,
	SK_ID_DIM_COUVERTURE,
	ID_DIM_DATE_EVALUATION,
	SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE,
	SK_ID_DIM_ORIGINE_MONTANT,
	SK_ID_DIM_TYPE_PROJECTION,
	ID_DIM_DATE_EMISSION,
	SK_ID_DIM_DUREE,
	SK_ID_DIM_AGE_EMISSION,
	SK_ID_DIM_AGE_ATTEINT,
	SK_ID_DIM_STATUT_PREFERENTIEL,
	SK_ID_DIM_SEXE,
	SK_ID_DIM_STATUT_FUMEUR,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_TRAITE_REASSURANCE,
	SK_ID_DIM_RESEAU_DISTRIBUTION,
	SK_ID_DIM_CODE_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_DIM_RAISON_TERMINAISON,
	GEN_UID,
	DEATH,
	FRACTURE
) as

WITH OtherBenefits AS
(
SELECT * FROM (
SELECT
  SK_ID_FT_SOE_OTHER_BENEFITS,
  CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
  THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
       OtherB.SK_ID_DIM_MODULE_COUVERTURE
   END SK_ID_DIM_MODULE_COUVERTURE,
  OtherB.SK_ID_DIM_COUVERTURE,
  ID_DIM_DATE_EVALUATION,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
  THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      OtherB.SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE
   END SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE, 
  BenSupp.NOM_COURT_BENEFICE_SUPPLEMENTAIRE,
  CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
  THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_ORIGINE_MONTANT
   END SK_ID_DIM_ORIGINE_MONTANT,   
  CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
  THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_TYPE_PROJECTION
   END SK_ID_DIM_TYPE_PROJECTION,    
  ID_DIM_DATE_EMISSION,
  CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
  THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_DUREE 
   END SK_ID_DIM_DUREE,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_AGE_EMISSION 
   END SK_ID_DIM_AGE_EMISSION,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_AGE_ATTEINT 
   END SK_ID_DIM_AGE_ATTEINT,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_STATUT_PREFERENTIEL 
   END SK_ID_DIM_STATUT_PREFERENTIEL,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_SEXE 
   END SK_ID_DIM_SEXE,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_STATUT_FUMEUR 
   END SK_ID_DIM_STATUT_FUMEUR,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_TERRITOIRE 
   END SK_ID_DIM_TERRITOIRE,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_TRAITE_REASSURANCE 
   END SK_ID_DIM_TRAITE_REASSURANCE,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_RESEAU_DISTRIBUTION 
   END SK_ID_DIM_RESEAU_DISTRIBUTION,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_CODE_PLAN_AXIS 
   END SK_ID_DIM_CODE_PLAN_AXIS,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_VALUATION_ASSUMPTIONS_TABLES 
   END SK_ID_VALUATION_ASSUMPTIONS_TABLES,
   CASE WHEN  
      OtherB.SK_ID_DIM_COUVERTURE < 0
   THEN
      OtherB.SK_ID_DIM_COUVERTURE 
   ELSE
      SK_ID_DIM_RAISON_TERMINAISON 
   END SK_ID_DIM_RAISON_TERMINAISON,
   OtherB.GEN_UID,
   AMOUNT_OTHER_BENEFIT
FROM DM_VI.FT_SOE_OTHER_BENEFITS OtherB
INNER JOIN DM_VI.DIM_DATE DT ON DT.ID_DIM_DATE = OtherB.ID_DIM_DATE_EVALUATION
LEFT JOIN DM_VI.DIM_BENEFICE_SUPPLEMENTAIRE BenSupp ON OtherB.SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE=BenSupp.SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE
  LEFT JOIN DM_VI.FT_COUVERTURE FTC ON OtherB.SK_ID_DIM_COUVERTURE  = FTC.SK_ID_DIM_COUVERTURE
  AND OtherB.SK_ID_DIM_MODULE_COUVERTURE  = FTC.SK_ID_DIM_MODULE_COUVERTURE
AND DT.SHORT_NAME_FR BETWEEN FTC.MD_ACTIVATION_DT AND FTC.MD_OBSOLESCENCE_DT
  

) t
Pivot (
  
  Sum(AMOUNT_OTHER_BENEFIT)
  for NOM_COURT_BENEFICE_SUPPLEMENTAIRE IN ('Death','Fracture')
  
  ) AS p
  ORDER BY SK_ID_FT_SOE_OTHER_BENEFITS


), Otherbenefits2 AS

(
  SELECT SK_ID_FT_SOE_OTHER_BENEFITS,
  SK_ID_DIM_MODULE_COUVERTURE,
  SK_ID_DIM_COUVERTURE,
  ID_DIM_DATE_EVALUATION,
  SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE,
  SK_ID_DIM_ORIGINE_MONTANT,
  SK_ID_DIM_TYPE_PROJECTION,
  ID_DIM_DATE_EMISSION,
  SK_ID_DIM_DUREE,
  SK_ID_DIM_AGE_EMISSION,
  SK_ID_DIM_AGE_ATTEINT,
  SK_ID_DIM_STATUT_PREFERENTIEL,
  SK_ID_DIM_SEXE,
  SK_ID_DIM_STATUT_FUMEUR,
  SK_ID_DIM_TERRITOIRE,
  SK_ID_DIM_TRAITE_REASSURANCE,
  SK_ID_DIM_RESEAU_DISTRIBUTION,
  SK_ID_DIM_CODE_PLAN_AXIS,
  SK_ID_VALUATION_ASSUMPTIONS_TABLES,
  SK_ID_DIM_RAISON_TERMINAISON,
  GEN_UID,
  CASE WHEN "'Death'" IS NULL THEN 0 ELSE "'Death'" END AS Death, 
  CASE WHEN "'Fracture'" IS NULL THEN 0 ELSE "'Fracture'" END AS Fracture
  FROM OtherBenefits
)

SELECT 
   SK_ID_FT_SOE_OTHER_BENEFITS,
	SK_ID_DIM_MODULE_COUVERTURE,
	SK_ID_DIM_COUVERTURE,
   ID_DIM_DATE_EVALUATION,
   SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE,
   SK_ID_DIM_ORIGINE_MONTANT,
   SK_ID_DIM_TYPE_PROJECTION,
	ID_DIM_DATE_EMISSION,
	SK_ID_DIM_DUREE,
	SK_ID_DIM_AGE_EMISSION,
	SK_ID_DIM_AGE_ATTEINT,
	SK_ID_DIM_STATUT_PREFERENTIEL,
	SK_ID_DIM_SEXE,
	SK_ID_DIM_STATUT_FUMEUR,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_TRAITE_REASSURANCE,
	SK_ID_DIM_RESEAU_DISTRIBUTION,
	SK_ID_DIM_CODE_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_DIM_RAISON_TERMINAISON,
   GEN_UID,
   Death,
   Fracture
   FROM Otherbenefits2;
create or replace view VW_FT_SOE_RESERVE_RELEASE(
	SK_ID_FT_SOE_RESERVE_RELEASE,
	ID_DIM_DATE_EVALUATION,
	SK_ID_DIM_TYPE_LIBERATION_RESERVE,
	SK_ID_DIM_TYPE_TAUX_INTERET,
	SK_ID_DIM_MODULE_COUVERTURE,
	SK_ID_DIM_COUVERTURE,
	GEN_UID,
	ID_DIM_DATE_EMISSION,
	SK_ID_DIM_DUREE,
	SK_ID_DIM_AGE_EMISSION,
	SK_ID_DIM_AGE_ATTEINT,
	SK_ID_DIM_STATUT_PREFERENTIEL,
	SK_ID_DIM_SEXE,
	SK_ID_DIM_STATUT_FUMEUR,
	SK_ID_DIM_TERRITOIRE,
	SK_ID_DIM_TRAITE_REASSURANCE,
	SK_ID_DIM_RESEAU_DISTRIBUTION,
	SK_ID_DIM_CODE_PLAN_AXIS,
	SK_ID_VALUATION_ASSUMPTIONS_TABLES,
	SK_ID_DIM_RAISON_TERMINAISON,
	"Gross actual release on death",
	"Gross actual release on lapse",
	"Gross actual release on misc off",
	"Gross actual release on misc on",
	"Gross actual release on not taken",
	"Gross actual release on other benefit",
	"Gross actual release on reinstatement",
	"Gross expected release on death",
	"Gross expected release on lapse",
	"Gross expected release on other benefit",
	"Gross expected adjustment latenb",
	"Gross expected adjustment new cessions",
	"Gross expected adjustment peinftrueup",
	"Gross expected adjustment policy changes",
	"Gross expected adjustment policy changes latenb",
	"Gross expected adjustment reinstatement",
	"Ceded actual release on death",
	"Ceded actual release on lapse",
	"Ceded actual release on misc off",
	"Ceded actual release on misc on",
	"Ceded actual release on not taken",
	"Ceded actual release on other benefit",
	"Ceded actual release on reinstatement",
	"Ceded expected release on death",
	"Ceded expected release on lapse",
	"Ceded expected release on other benefit",
	"Ceded expected adjustment latenb",
	"Ceded expected adjustment new cessions",
	"Ceded expected adjustment peinftrueup",
	"Ceded expected adjustment policy changes",
	"Ceded expected adjustment policy changes latenb",
	"Ceded expected adjustment reinstatement",
	"Ceded actual lic increase on incidence",
	"Ceded actual lic increase on misc on",
	"Ceded actual lic increase on re open",
	"Ceded actual lic release on ben exhaust",
	"Ceded actual lic release on di death",
	"Ceded actual lic release on misc off",
	"Ceded actual lic release on recovery",
	"Ceded actual lic release on settlement",
	"Ceded actual release on ben exhaust",
	"Ceded actual release on di death",
	"Ceded actual release on incidence",
	"Ceded actual release on recovery",
	"Ceded expected lic release on ben exhaust",
	"Ceded expected lic release on di death",
	"Ceded expected lic release on recovery",
	"Ceded expected release on ben exhaust",
	"Ceded expected release on di death",
	"Ceded expected release on incidence",
	"Ceded expected release on recovery",
	"gross actual lic increase on incidence",
	"Gross actual lic increase on misc on",
	"Gross actual lic increase on re open",
	"Gross actual lic release on ben exhaust",
	"Gross actual lic release on di death",
	"Gross actual lic release on misc off",
	"Gross actual lic release on recovery",
	"Gross actual lic release on settlement",
	"Gross actual release on ben exhaust",
	"Gross actual release on di death",
	"Gross actual release on incidence",
	"Gross actual release on recovery",
	"Gross expected lic release on ben exhaust",
	"Gross expected lic release on di death",
	"Gross expected lic release on recovery",
	"Gross expected release on ben exhaust",
	"Gross expected release on di death",
	"Gross expected release on incidence",
	"Gross expected release on recovery  ",
	"Gross lic roll forward belic exp adjustment peinftrueup",
	"Gross lic roll forward ralic exp adjustment peinftrueup"
) as
    SELECT 
         RES.SK_ID_FT_SOE_RESERVE_RELEASE
        ,RES.ID_DIM_DATE_EVALUATION
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            RES.SK_ID_DIM_TYPE_LIBERATION_RESERVE
        END SK_ID_DIM_TYPE_LIBERATION_RESERVE           
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            RES.SK_ID_DIM_TYPE_TAUX_INTERET 
        END SK_ID_DIM_TYPE_TAUX_INTERET         
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            RES.SK_ID_DIM_MODULE_COUVERTURE 
        END SK_ID_DIM_MODULE_COUVERTURE        
        ,RES.SK_ID_DIM_COUVERTURE
        ,RES.GEN_UID
        ,ID_DIM_DATE_EMISSION
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_DUREE 
        END SK_ID_DIM_DUREE        
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_AGE_EMISSION 
        END SK_ID_DIM_AGE_EMISSION
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_AGE_ATTEINT 
        END SK_ID_DIM_AGE_ATTEINT
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_STATUT_PREFERENTIEL 
        END SK_ID_DIM_STATUT_PREFERENTIEL
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_SEXE 
        END SK_ID_DIM_SEXE
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_STATUT_FUMEUR 
        END SK_ID_DIM_STATUT_FUMEUR
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_TERRITOIRE 
        END SK_ID_DIM_TERRITOIRE
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_TRAITE_REASSURANCE 
        END SK_ID_DIM_TRAITE_REASSURANCE
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_RESEAU_DISTRIBUTION 
        END SK_ID_DIM_RESEAU_DISTRIBUTION
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_CODE_PLAN_AXIS 
        END SK_ID_DIM_CODE_PLAN_AXIS
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_VALUATION_ASSUMPTIONS_TABLES 
        END SK_ID_VALUATION_ASSUMPTIONS_TABLES
        ,CASE WHEN  
            RES.SK_ID_DIM_COUVERTURE < 0
        THEN
            RES.SK_ID_DIM_COUVERTURE 
        ELSE
            SK_ID_DIM_RAISON_TERMINAISON 
        END SK_ID_DIM_RAISON_TERMINAISON       
        ,GROSS_ACTUAL_RELEASE_ON_DEATH              AS "Gross actual release on death"
        ,GROSS_ACTUAL_RELEASE_ON_LAPSE              AS "Gross actual release on lapse"
        ,GROSS_ACTUAL_RELEASE_ON_MISC_OFF           AS "Gross actual release on misc off"
        ,GROSS_ACTUAL_RELEASE_ON_MISC_ON            AS "Gross actual release on misc on"
        ,GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN          AS "Gross actual release on not taken"
        ,GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT      AS "Gross actual release on other benefit"
        ,GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT      AS "Gross actual release on reinstatement"
        ,GROSS_EXPECTED_RELEASE_ON_DEATH            AS "Gross expected release on death"
        ,GROSS_EXPECTED_RELEASE_ON_LAPSE            AS "Gross expected release on lapse"
        ,GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT    AS "Gross expected release on other benefit"
        ,GROSS_EXP_ADJUSTMENT_LATENB                AS "Gross expected adjustment latenb"
        ,GROSS_EXP_ADJUSTMENT_NEWCESSIONS           AS "Gross expected adjustment new cessions" 
        ,GROSS_EXP_ADJUSTMENT_PEINFTRUEUP           AS "Gross expected adjustment peinftrueup"
        ,GROSS_EXP_ADJUSTMENT_POLICYCHANGES         AS "Gross expected adjustment policy changes"
        ,GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB   AS "Gross expected adjustment policy changes latenb"
        ,GROSS_EXP_ADJUSTMENT_REINSTATEMENT         AS "Gross expected adjustment reinstatement"
        ,CEDED_ACTUAL_RELEASE_ON_DEATH              AS "Ceded actual release on death"
        ,CEDED_ACTUAL_RELEASE_ON_LAPSE              AS "Ceded actual release on lapse"
        ,CEDED_ACTUAL_RELEASE_ON_MISC_OFF           AS "Ceded actual release on misc off"
        ,CEDED_ACTUAL_RELEASE_ON_MISC_ON            AS "Ceded actual release on misc on"
        ,CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN          AS "Ceded actual release on not taken"
        ,CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT      AS "Ceded actual release on other benefit"
        ,CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT      AS "Ceded actual release on reinstatement"
        ,CEDED_EXPECTED_RELEASE_ON_DEATH            As "Ceded expected release on death"
        ,CEDED_EXPECTED_RELEASE_ON_LAPSE            AS "Ceded expected release on lapse"
        ,CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT    AS "Ceded expected release on other benefit"
        ,CEDED_EXP_ADJUSTMENT_LATENB                AS "Ceded expected adjustment latenb"
        ,CEDED_EXP_ADJUSTMENT_NEWCESSIONS           AS "Ceded expected adjustment new cessions" 
        ,CEDED_EXP_ADJUSTMENT_PEINFTRUEUP           AS "Ceded expected adjustment peinftrueup"
        ,CEDED_EXP_ADJUSTMENT_POLICYCHANGES         AS "Ceded expected adjustment policy changes"
        ,CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB   AS "Ceded expected adjustment policy changes latenb"
        ,CEDED_EXP_ADJUSTMENT_REINSTATEMENT         AS "Ceded expected adjustment reinstatement"
        ,CEDED_ACTUAL_LIC_INCREASE_ON_INCIDENCE      AS "Ceded actual lic increase on incidence"
        ,CEDED_ACTUAL_LIC_INCREASE_ON_MISC_ON      AS "Ceded actual lic increase on misc on"
        ,CEDED_ACTUAL_LIC_INCREASE_ON_RE_OPEN      AS "Ceded actual lic increase on re open"
        ,CEDED_ACTUAL_LIC_RELEASE_ON_BEN_EXHAUST      AS "Ceded actual lic release on ben exhaust"
        ,CEDED_ACTUAL_LIC_RELEASE_ON_DI_DEATH      AS "Ceded actual lic release on di death"
        ,CEDED_ACTUAL_LIC_RELEASE_ON_MISC_OFF      AS "Ceded actual lic release on misc off"
        ,CEDED_ACTUAL_LIC_RELEASE_ON_RECOVERY      AS "Ceded actual lic release on recovery"
        ,CEDED_ACTUAL_LIC_RELEASE_ON_SETTLEMENT      AS "Ceded actual lic release on settlement"
        ,CEDED_ACTUAL_RELEASE_ON_BEN_EXHAUST      AS "Ceded actual release on ben exhaust"
        ,CEDED_ACTUAL_RELEASE_ON_DI_DEATH      AS "Ceded actual release on di death"
        ,CEDED_ACTUAL_RELEASE_ON_INCIDENCE      AS "Ceded actual release on incidence"
        ,CEDED_ACTUAL_RELEASE_ON_RECOVERY      AS "Ceded actual release on recovery"
        ,CEDED_EXPECTED_LIC_RELEASE_ON_BEN_EXHAUST      AS "Ceded expected lic release on ben exhaust"
        ,CEDED_EXPECTED_LIC_RELEASE_ON_DI_DEATH      AS "Ceded expected lic release on di death"
        ,CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY      AS "Ceded expected lic release on recovery"
        ,CEDED_EXPECTED_RELEASE_ON_BEN_EXHAUST      AS "Ceded expected release on ben exhaust"
        ,CEDED_EXPECTED_RELEASE_ON_DI_DEATH      AS "Ceded expected release on di death"
        ,CEDED_EXPECTED_RELEASE_ON_INCIDENCE      AS "Ceded expected release on incidence"
        ,CEDED_EXPECTED_RELEASE_ON_RECOVERY      AS "Ceded expected release on recovery"
        ,GROSS_ACTUAL_LIC_INCREASE_ON_INCIDENCE      AS "gross actual lic increase on incidence"
        ,GROSS_ACTUAL_LIC_INCREASE_ON_MISC_ON      AS "Gross actual lic increase on misc on"
        ,GROSS_ACTUAL_LIC_INCREASE_ON_RE_OPEN      AS "Gross actual lic increase on re open"
        ,GROSS_ACTUAL_LIC_RELEASE_ON_BEN_EXHAUST      AS "Gross actual lic release on ben exhaust"
        ,GROSS_ACTUAL_LIC_RELEASE_ON_DI_DEATH      AS "Gross actual lic release on di death"
        ,GROSS_ACTUAL_LIC_RELEASE_ON_MISC_OFF      AS "Gross actual lic release on misc off"
        ,GROSS_ACTUAL_LIC_RELEASE_ON_RECOVERY      AS "Gross actual lic release on recovery"
        ,GROSS_ACTUAL_LIC_RELEASE_ON_SETTLEMENT      AS "Gross actual lic release on settlement"
        ,GROSS_ACTUAL_RELEASE_ON_BEN_EXHAUST      AS "Gross actual release on ben exhaust"
        ,GROSS_ACTUAL_RELEASE_ON_DI_DEATH      AS "Gross actual release on di death"
        ,GROSS_ACTUAL_RELEASE_ON_INCIDENCE      AS "Gross actual release on incidence"
        ,GROSS_ACTUAL_RELEASE_ON_RECOVERY      AS "Gross actual release on recovery"
        ,GROSS_EXPECTED_LIC_RELEASE_ON_BEN_EXHAUST      AS "Gross expected lic release on ben exhaust"
        ,GROSS_EXPECTED_LIC_RELEASE_ON_DI_DEATH      AS "Gross expected lic release on di death"
        ,GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY      AS "Gross expected lic release on recovery"
        ,GROSS_EXPECTED_RELEASE_ON_BEN_EXHAUST      AS "Gross expected release on ben exhaust"
        ,GROSS_EXPECTED_RELEASE_ON_DI_DEATH      AS "Gross expected release on di death"
        ,GROSS_EXPECTED_RELEASE_ON_INCIDENCE      AS "Gross expected release on incidence"
        ,GROSS_EXPECTED_RELEASE_ON_RECOVERY        AS "Gross expected release on recovery  "
        ,GROSS_LIC_ROLL_FORWARD_BELIC_EXP_ADJUSTMENT_PEINFTRUEUP AS "Gross lic roll forward belic exp adjustment peinftrueup"
        ,GROSS_LIC_ROLL_FORWARD_RALIC_EXP_ADJUSTMENT_PEINFTRUEUP      AS "Gross lic roll forward ralic exp adjustment peinftrueup"
FROM DM_VI.FT_SOE_RESERVE_RElEASE RES
INNER JOIN DM_VI.DIM_DATE DT on DT.ID_DIM_DATE = RES.ID_DIM_DATE_EVALUATION
LEFT JOIN DM_VI.FT_COUVERTURE FTC ON RES.SK_ID_DIM_COUVERTURE  = FTC.SK_ID_DIM_COUVERTURE
and RES.SK_ID_DIM_MODULE_COUVERTURE  = FTC.SK_ID_DIM_MODULE_COUVERTURE
and DT.SHORT_NAME_FR between FTC.MD_ACTIVATION_DT and FTC.MD_OBSOLESCENCE_DT;
create or replace view VW_FT_SOLDE_GL(
	SK_ID_FT_SOLDE_GL,
	ID_DIM_DATE_FIN_PERIODE_COMPTABLE,
	SK_ID_DIM_COMPTE_GL,
	SK_ID_DIM_MASTER_COA,
	JOURNAL,
	SOURCE,
	SYSTEME_SOURCE,
	TYPE_ENTREE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	DEBIT,
	CREDIT,
	SOLDE
) as
    SELECT 
      SK_ID_FT_SOLDE_GL
    , ID_DIM_DATE_FIN_PERIODE_COMPTABLE
    , SK_ID_DIM_COMPTE_GL
    , SK_ID_DIM_MASTER_COA
    , JOURNAL
    , SOURCE
    , SYSTEME_SOURCE
    , TYPE_ENTREE
    , ID_PRIMAIRE
    , ID_SECONDAIRE
    , ID_RECLAMATION
    , ID_REASSURANCE
    , DEBIT
    , CREDIT
    , SOLDE
    FROM DM_VI.FT_SOLDE_GL;
create or replace schema DM_VI_TRAVAIL;

create or replace TABLE SP_OUTPUT (
	RESULTAT VARCHAR(16777216)
);
create or replace TABLE VI_DESAGREGATIONCOMPTABLE (
	GEN_UID VARCHAR(16777216),
	PERIODE_COMPTABLE VARCHAR(10),
	RISQUE VARCHAR(10),
	MNT_COMPTABLE_REAS NUMBER(38,12),
	MNT_COMPTABLE_DIRECT NUMBER(38,12)
);
create or replace TABLE VI_DESAGREGATION_PRESTATION_COMPTABLE (
	CD_ENTITE VARCHAR(4) NOT NULL,
	CD_NATURE VARCHAR(6) NOT NULL,
	CD_ORIGINE VARCHAR(2) NOT NULL,
	CD_PERIODICITE VARCHAR(2) NOT NULL,
	CD_CENTRE_COUT VARCHAR(4) NOT NULL,
	CD_INTERCO VARCHAR(4) NOT NULL,
	CD_LIGNE_AFFAIRE VARCHAR(3) NOT NULL,
	CD_PRODUIT VARCHAR(4) NOT NULL,
	CD_PARTICIPATION VARCHAR(2) NOT NULL,
	CD_GEOGRAPHIE VARCHAR(3) NOT NULL,
	CD_PROJET VARCHAR(3) NOT NULL,
	VARIABLE_CSM VARCHAR(300) NOT NULL,
	CUSTOM_DIM_1 VARCHAR(100) NOT NULL,
	CUSTOM_DIM_2 VARCHAR(100) NOT NULL,
	PERIODE_COMPTABLE VARCHAR(10) NOT NULL,
	SOURCE_SOE VARCHAR(20) NOT NULL,
	GEN_UID VARCHAR(30) NOT NULL,
	NO_POLICE VARCHAR(50) NOT NULL,
	MNT_COMPTABLE NUMBER(32,12) NOT NULL
);
create or replace TABLE VW_DIM_COUVERTURE (
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	GEN_UID VARCHAR(255),
	NO_POLICE VARCHAR(255),
	CODE_COMPAGNIE VARCHAR(255),
	LIGNE_AFFAIRE VARCHAR(255),
	MD_START_DT VARCHAR(255),
	MD_CREATION_DT VARCHAR(255),
	MD_SOURCE VARCHAR(255),
	MD_IS_ACTIVE VARCHAR(255)
);
create or replace TABLE VW_DIM_COUVERTURE_INFO (
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	BANDE VARCHAR(255),
	CODE_JOINT_LIFE VARCHAR(255),
	PRM_MODE VARCHAR(255),
	IND_COUVERTURE_TERMINEE VARCHAR(255),
	IND_GARANTIE VARCHAR(255),
	IND_TRANSFORMATION VARCHAR(255),
	IND_TRAITE_REASSURANCE VARCHAR(255),
	CODE_PARTICIPATION VARCHAR(255),
	CODE_TYPE_TRANSFORMATION VARCHAR(255),
	NOM_TYPE_TRANSFORMATION VARCHAR(255),
	MD_START_DT VARCHAR(255),
	MD_CREATION_DT VARCHAR(255),
	MD_SOURCE VARCHAR(255),
	MD_IS_ACTIVE VARCHAR(255)
);
create or replace TABLE VW_DIM_GROUPE_CSM (
	NOM_GROUPE_CSM VARCHAR(255),
	MD_ACTIVATION_DT VARCHAR(255),
	MD_OBSOLESCENCE_DT VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255)
);
create or replace TABLE VW_DIM_REASSUREUR (
	CODE_REASSUREUR VARCHAR(255),
	NOM_REASSUREUR VARCHAR(255),
	MD_ACTIVATION_DT VARCHAR(255),
	MD_OBSOLESCENCE_DT VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255)
);
create or replace TABLE VW_FT_COMPTABILTE_DESAGREGEE (
	ID_DATE_PERIODE_COMPTABLE VARCHAR(255),
	SK_ID_DIM_COMPTE_GL VARCHAR(255),
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_MASTER_COA VARCHAR(255),
	NO_POLICE VARCHAR(255),
	GEN_UID VARCHAR(255),
	SOURCE_SOE VARCHAR(255),
	MNT_COMPTABLE VARCHAR(255),
	MD_ACTIVATION_DT VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255)
);
create or replace TABLE VW_FT_COUVERTURE_GROUPE_CSM (
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_GROUPE_CSM VARCHAR(255),
	GEN_UID VARCHAR(255),
	MD_ACTIVATION_DT VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_ROW_IS_VALID VARCHAR(255)
);
create or replace TABLE VW_FT_COUVERTURE_REASSURANCE_GROUPE_CSM (
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_REASSUREUR VARCHAR(255),
	SK_ID_DIM_GROUPE_CSM_REASSURANCE VARCHAR(255),
	SK_ID_DIM_GROUPE_CSM_DIRECT VARCHAR(255),
	GEN_UID VARCHAR(255),
	NO_SEQUENCE VARCHAR(255),
	CODE_REASSUREUR VARCHAR(255),
	MD_ACTIVATION_DT VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_ROW_IS_VALID VARCHAR(255)
);
create or replace TABLE VW_FT_SOE_CASHFLOW (
	ID_DIM_DATE_EVALUATION VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	GEN_UID VARCHAR(255),
	CODE_MODULE_COUVERTURE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_BONUS VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_COMMISSION VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_COMMISSIONBONUS VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_CREDITEDINTEREST VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_DEATHBENEFIT VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_DEPOSIT VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_DESIGNATEDFUND VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_EXPENSE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_EXPENSECHARGE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DEATH VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_DIVIDENDDISABLED VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC1 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC2 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC3 VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_LAPSE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_MISCON VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_MISCOFF VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_MISCON VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_NOTTAKENUP VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_OTHERBENEFIT VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_OTHERBENEFITCHARGE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_PARTIALWITHDRAWAL VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_POLICYLOANPAID VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_PREMIUM VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_PREMIUMLOAD VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_PREMIUMTAX VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_RECAPTURECHARGE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_REINSURANCEMARGIN VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_RETURNOFPREMIUMS VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_RISKCHARGE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOW_SURRENDERBENEFIT VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_BONUS VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_COMMISSION VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_COMMISSIONBONUS VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_CREDITEDINTEREST VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_DEATHBENEFIT VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_DEPOSIT VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_DESIGNATEDFUND VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_EXPENSE VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DEATH VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_DIVIDENDDISABLED VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC1 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC2 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC3 VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_EXPENSECHARGE VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_LAPSE VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_MISCON VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_MISCOFF VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_MISCON VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_NOTTAKENUP VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_OTHERBENEFIT VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_OTHERBENEFITCHARGE VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_PARTIALWITHDRAWAL VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_POLICYLOANPAID VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_PREMIUM VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_PREMIUMLOAD VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_PREMIUMTAX VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_RECAPTURECHARGE VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_REINSURANCEMARGIN VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_REINSURANCE VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_RETURNOFPREMIUMS VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_RISKCHARGE VARCHAR(255),
	CEDED_EXPECTED_CASHFLOW_SURRENDERBENEFIT VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_BONUS VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_COMMISSION VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_COMMISSIONBONUS VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_CREDITEDINTEREST VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_DEATHBENEFIT VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_DEPOSIT VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_DIVIDENDROPSURVIVORS VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_DESIGNEDFUND VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_EXPENSE VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_EXPENSECHARGE VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DEATH VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_DIVIDENDDISABLED VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC1 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC2 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_INCURRALC3 VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_LAPSE VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCOFF VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_MISCON VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NEWBUS VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_NOTTAKENUP VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_OTHERBEN VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_LATEREPORT_REINSTATEMENT VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_MISCOFF VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_MISCON VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_NOTTAKENUP VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_OTHERBENEFIT VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_OTHERBENEFITCHARGE VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_PARTIALWITHDRAWAL VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_POLICYLOANPAID VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_PREMIUM VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_PREMIUMLOAD VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_PREMIUMTAX VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_RECAPTURECHARGE VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_REINSURANCEMARGIN VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_RETURNOFPREMIUMS VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_RISKCHARGE VARCHAR(255),
	GROSS_ACTUAL_CASHFLOW_SURRENDERBENEFIT VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_BONUS VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_COMMISSION VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_COMMISSIONBONUS VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_CREDITEDINTEREST VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_DEATHBENEFIT VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_DIVIDENDROPSURVIVORS VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_DEPOSIT VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_DESIGNATEDFUND VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_EXPENSE VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_EXPENSECHARGE VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DEATH VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC1 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC2 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMPAYMENTSC3 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DICLAIMSEXPENSE VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC1 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC2 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIDEATHBENEFITSC3 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_DIVIDENDDISABLED VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC1 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC2 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_INCURRALC3 VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_LAPSE VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCOFF VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_MISCON VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NEWBUS VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_NOTTAKENUP VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_OTHERBEN VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_LATEREPORT_REINSTATEMENT VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_MISCOFF VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_MISCON VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_NOTTAKENUP VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_OTHERBENEFIT VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_OTHERBENEFITCHARGE VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_PARTIALWITHDRAWAL VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_POLICYLOANPAID VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_PREMIUM VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_PREMIUMLOAD VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_PREMIUMTAX VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_RECAPTURECHARGE VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_REINSURANCEMARGIN VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_RETURNOFPREMIUMS VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_RISKCHARGE VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_SURRENDER VARCHAR(255),
	GROSS_EXPECTED_CASHFLOW_SURRENDERBENEFIT VARCHAR(255),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255)
);
create or replace TABLE VW_FT_SOE_EXPENSE_COMPENSATION (
	ID_DIM_DATE_EVALUATION VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	GEN_UID VARCHAR(255),
	POLICY_ID_EX VARCHAR(255),
	REPRESENTATIVE_BONUS_GROSSCHARGEBACK_FIRSTYEARCOMP VARCHAR(255),
	REPRESENTATIVE_BONUS_GROSSBONUS_FIRSTYEAR VARCHAR(255),
	REPRESENTATIVE_BONUS_GROSSCOMMISSION_FIRSTYEAR VARCHAR(255),
	COMMISSION_GROSSCHARGEBACK_FIRSTYEARCOMP VARCHAR(255),
	COMMISSION_GROSSCOMMISSION_FIRSTYEAR VARCHAR(255),
	OVERRIDE_GROSSCHARGEBACK_FIRSTYEARCOMP VARCHAR(255),
	OVERRIDE_GROSSCOMMISSION_FIRSTYEAR VARCHAR(255),
	ACQUISITION_ATTRIBUTABLE_EXPENSE_EXPENSE_FIRSTYEAR VARCHAR(255),
	ADMINISTRATION_ATTRIBUTABLE_EXPENSE_EXPENSE_FIRSTYEAR VARCHAR(255),
	DIRECTOR_BONUS_GROSSCHARGEBACK_FIRSTYEARCOMP VARCHAR(255),
	DIRECTOR_BONUS_GROSSBONUS_FIRSTYEAR VARCHAR(255),
	DIRECTOR_BONUS_GROSSCOMMISSION_FIRSTYEAR VARCHAR(255),
	MINIMUM_PREMIUM_GROSSCHARGEBACK_FIRSTYEARCOMP VARCHAR(255),
	MINIMUM_PREMIUM_GROSSBONUS_FIRSTYEAR VARCHAR(255),
	MINIMUM_PREMIUM_GROSSCOMMISSION_FIRSTYEAR VARCHAR(255),
	OTHER_BENEFIT_ATTRIBUTABLE_EXPENSE_EXPENSE_FIRSTYEAR VARCHAR(255),
	OVERRIDE_GROSSBONUS_FIRSTYEAR VARCHAR(255),
	COMMISSION_GROSSBONUS_FIRSTYEAR VARCHAR(255),
	ALLOWANCE_FOR_SERVICING_IN_FORCE_GROSSCHARGEBACK_FIRSTYEARCOMP VARCHAR(255),
	ALLOWANCE_FOR_SERVICING_IN_FORCE_GROSSCOMMISSION_FIRSTYEAR VARCHAR(255),
	ALLOWANCE_FOR_SERVICING_IN_FORCE_GROSSBONUS_FIRSTYEAR VARCHAR(255),
	FLAT_NL_FLEX_5$_NON_INFLATABLE_EXPENSE_FIRSTYEAR VARCHAR(255),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_ROW_IS_VALID VARCHAR(255)
);
create or replace TABLE VW_FT_SOE_FUND_RELEASE (
	ID_DIM_DATE_EVALUATION VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	GEN_UID VARCHAR(255),
	CODE_MODULE_COUVERTURE VARCHAR(255),
	CEDED_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_LATENB VARCHAR(255),
	CEDED_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_MISCON VARCHAR(255),
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_DEATH VARCHAR(255),
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_MISCOFF VARCHAR(255),
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT VARCHAR(255),
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL VARCHAR(255),
	CEDED_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_SURRENDER VARCHAR(255),
	CEDED_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_LATENB VARCHAR(255),
	CEDED_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_MISCON VARCHAR(255),
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_DEATH VARCHAR(255),
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_MISCOFF VARCHAR(255),
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT VARCHAR(255),
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL VARCHAR(255),
	CEDED_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_SURRENDER VARCHAR(255),
	GROSS_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_LATENB VARCHAR(255),
	GROSS_ACTUAL_CASHFLOWS_FUND_INCREASE_ON_MISCON VARCHAR(255),
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_DEATH VARCHAR(255),
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_MISCOFF VARCHAR(255),
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT VARCHAR(255),
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL VARCHAR(255),
	GROSS_ACTUAL_CASHFLOWS_FUND_RELEASE_ON_SURRENDER VARCHAR(255),
	GROSS_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_LATENB VARCHAR(255),
	GROSS_EXPECTED_CASHFLOWS_FUND_INCREASE_ON_MISCON VARCHAR(255),
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_DEATH VARCHAR(255),
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_MISCOFF VARCHAR(255),
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_OTHERBENEFIT VARCHAR(255),
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_PARTIALWITHDRAWAL VARCHAR(255),
	GROSS_EXPECTED_CASHFLOWS_FUND_RELEASE_ON_SURRENDER VARCHAR(255),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255)
);
create or replace TABLE VW_FT_SOE_INVESTMENT_COMPONENT (
	ID_DIM_DATE_EVALUATION VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	GEN_UID VARCHAR(255),
	CEDED_ACTUAL_INVCOMP_DEATH VARCHAR(255),
	CEDED_ACTUAL_INVCOMP_LAPSE VARCHAR(255),
	CEDED_ACTUAL_INVCOMP_OTHERBEN VARCHAR(255),
	CEDED_ACTUAL_INVCOMP_SURVIVORS VARCHAR(255),
	CEDED_EXPECTED_INVCOMP_DEATH VARCHAR(255),
	CEDED_EXPECTED_INVCOMP_LAPSE VARCHAR(255),
	CEDED_EXPECTED_INVCOMP_OTHERBEN VARCHAR(255),
	CEDED_EXPECTED_INVCOMP_SURVIVORS VARCHAR(255),
	GROSS_ACTUAL_INVCOMP_DEATH VARCHAR(255),
	GROSS_ACTUAL_INVCOMP_LAPSE VARCHAR(255),
	GROSS_ACTUAL_INVCOMP_OTHERBEN VARCHAR(255),
	GROSS_ACTUAL_INVCOMP_SURVIVORS VARCHAR(255),
	GROSS_EXPECTED_INVCOMP_DEATH VARCHAR(255),
	GROSS_EXPECTED_INVCOMP_LAPSE VARCHAR(255),
	GROSS_EXPECTED_INVCOMP_OTHERBEN VARCHAR(255),
	GROSS_EXPECTED_INVCOMP_SURVIVORS VARCHAR(255),
	CEDED_ACTUAL_INVCOMP_INCIDENCE VARCHAR(255),
	GROSS_ACTUAL_INVCOMP_INCIDENCE VARCHAR(255),
	CEDED_EXPECTED_INVCOMP_INCIDENCE VARCHAR(255),
	GROSS_EXPECTED_INVCOMP_INCIDENCE VARCHAR(255),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255)
);
create or replace TABLE VW_FT_SOE_OTHER_BENEFITS (
	ID_DIM_DATE_EVALUATION VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	SK_ID_DIM_BENEFICE_SUPPLEMENTAIRE VARCHAR(255),
	SK_ID_DIM_ORIGINE_MONTANT VARCHAR(255),
	SK_ID_DIM_TYPE_PROJECTION VARCHAR(255),
	GEN_UID VARCHAR(255),
	CODE_MODULE_COUVERTURE VARCHAR(255),
	AXIS_RUN_ID VARCHAR(255),
	AMOUNT_OTHER_BENEFIT VARCHAR(255),
	MD_START_DT VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_ROW_IS_VALID VARCHAR(255)
);
create or replace TABLE VW_FT_SOE_RESERVE_AT_INITIAL_RECOGNITION (
	ID_DIM_DATE_EVALUATION VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	GEN_UID VARCHAR(255),
	POLICY_ID_EX VARCHAR(255),
	RUN_ID VARCHAR(255),
	SCENARIO_ID VARCHAR(255),
	OVERRIDE_ID VARCHAR(255),
	ID VARCHAR(255),
	NAME VARCHAR(255),
	RA_AT_INITIAL_RECOGNITION VARCHAR(255),
	RA_EXPER_ADJ_DUE_TO_NEW_CESSIONS VARCHAR(255),
	BEL_AT_INITIAL_RECOGNITION VARCHAR(255),
	BEL_EXPER_ADJ_DUE_TO_NEW_CESSIONS VARCHAR(255),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_ROW_IS_VALID VARCHAR(255)
);
create or replace TABLE VW_FT_SOE_RESERVE_RELEASE (
	ID_DIM_DATE_EVALUATION VARCHAR(255),
	SK_ID_DIM_TYPE_LIBERATION_RESERVE VARCHAR(255),
	SK_ID_DIM_TYPE_TAUX_INTERET VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	GEN_UID VARCHAR(255),
	CODE_MODULE_COUVERTURE VARCHAR(255),
	RELEASE_TYPE_NAME VARCHAR(255),
	RATE_TYPE VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_DEATH VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_LAPSE VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_MISC_OFF VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_MISC_ON VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_NOT_TAKEN VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_OTHER_BENEFIT VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_REINSTATEMENT VARCHAR(255),
	GROSS_EXPECTED_RELEASE_ON_DEATH VARCHAR(255),
	GROSS_EXPECTED_RELEASE_ON_LAPSE VARCHAR(255),
	GROSS_EXPECTED_RELEASE_ON_OTHER_BENEFIT VARCHAR(255),
	GROSS_EXP_ADJUSTMENT_LATENB VARCHAR(255),
	GROSS_EXP_ADJUSTMENT_NEWCESSIONS VARCHAR(255),
	GROSS_EXP_ADJUSTMENT_PEINFTRUEUP VARCHAR(255),
	GROSS_EXP_ADJUSTMENT_POLICYCHANGES VARCHAR(255),
	GROSS_EXP_ADJUSTMENT_POLICYCHANGESLATENB VARCHAR(255),
	GROSS_EXP_ADJUSTMENT_REINSTATEMENT VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_DEATH VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_LAPSE VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_MISC_OFF VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_MISC_ON VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_NOT_TAKEN VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_OTHER_BENEFIT VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_REINSTATEMENT VARCHAR(255),
	CEDED_EXPECTED_RELEASE_ON_DEATH VARCHAR(255),
	CEDED_EXPECTED_RELEASE_ON_LAPSE VARCHAR(255),
	CEDED_EXPECTED_RELEASE_ON_OTHER_BENEFIT VARCHAR(255),
	CEDED_EXP_ADJUSTMENT_LATENB VARCHAR(255),
	CEDED_EXP_ADJUSTMENT_NEWCESSIONS VARCHAR(255),
	CEDED_EXP_ADJUSTMENT_PEINFTRUEUP VARCHAR(255),
	CEDED_EXP_ADJUSTMENT_POLICYCHANGES VARCHAR(255),
	CEDED_EXP_ADJUSTMENT_POLICYCHANGESLATENB VARCHAR(255),
	CEDED_EXP_ADJUSTMENT_REINSTATEMENT VARCHAR(255),
	CEDED_ACTUAL_LIC_INCREASE_ON_INCIDENCE VARCHAR(255),
	CEDED_ACTUAL_LIC_INCREASE_ON_MISC_ON VARCHAR(255),
	CEDED_ACTUAL_LIC_INCREASE_ON_RE_OPEN VARCHAR(255),
	CEDED_ACTUAL_LIC_RELEASE_ON_BEN_EXHAUST VARCHAR(255),
	CEDED_ACTUAL_LIC_RELEASE_ON_DI_DEATH VARCHAR(255),
	CEDED_ACTUAL_LIC_RELEASE_ON_MISC_OFF VARCHAR(255),
	CEDED_ACTUAL_LIC_RELEASE_ON_RECOVERY VARCHAR(255),
	CEDED_ACTUAL_LIC_RELEASE_ON_SETTLEMENT VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_BEN_EXHAUST VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_DI_DEATH VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_INCIDENCE VARCHAR(255),
	CEDED_ACTUAL_RELEASE_ON_RECOVERY VARCHAR(255),
	CEDED_EXPECTED_LIC_RELEASE_ON_BEN_EXHAUST VARCHAR(255),
	CEDED_EXPECTED_LIC_RELEASE_ON_DI_DEATH VARCHAR(255),
	CEDED_EXPECTED_LIC_RELEASE_ON_RECOVERY VARCHAR(255),
	CEDED_EXPECTED_RELEASE_ON_BEN_EXHAUST VARCHAR(255),
	CEDED_EXPECTED_RELEASE_ON_DI_DEATH VARCHAR(255),
	CEDED_EXPECTED_RELEASE_ON_INCIDENCE VARCHAR(255),
	CEDED_EXPECTED_RELEASE_ON_RECOVERY VARCHAR(255),
	GROSS_ACTUAL_LIC_INCREASE_ON_INCIDENCE VARCHAR(255),
	GROSS_ACTUAL_LIC_INCREASE_ON_MISC_ON VARCHAR(255),
	GROSS_ACTUAL_LIC_INCREASE_ON_RE_OPEN VARCHAR(255),
	GROSS_ACTUAL_LIC_RELEASE_ON_BEN_EXHAUST VARCHAR(255),
	GROSS_ACTUAL_LIC_RELEASE_ON_DI_DEATH VARCHAR(255),
	GROSS_ACTUAL_LIC_RELEASE_ON_MISC_OFF VARCHAR(255),
	GROSS_ACTUAL_LIC_RELEASE_ON_RECOVERY VARCHAR(255),
	GROSS_ACTUAL_LIC_RELEASE_ON_SETTLEMENT VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_BEN_EXHAUST VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_DI_DEATH VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_INCIDENCE VARCHAR(255),
	GROSS_ACTUAL_RELEASE_ON_RECOVERY VARCHAR(255),
	GROSS_EXPECTED_LIC_RELEASE_ON_BEN_EXHAUST VARCHAR(255),
	GROSS_EXPECTED_LIC_RELEASE_ON_DI_DEATH VARCHAR(255),
	GROSS_EXPECTED_LIC_RELEASE_ON_RECOVERY VARCHAR(255),
	GROSS_EXPECTED_RELEASE_ON_BEN_EXHAUST VARCHAR(255),
	GROSS_EXPECTED_RELEASE_ON_DI_DEATH VARCHAR(255),
	GROSS_EXPECTED_RELEASE_ON_INCIDENCE VARCHAR(255),
	GROSS_EXPECTED_RELEASE_ON_RECOVERY VARCHAR(255),
	GROSS_LIC_ROLL_FORWARD_BELIC_EXP_ADJUSTMENT_PEINFTRUEUP VARCHAR(255),
	GROSS_LIC_ROLL_FORWARD_RALIC_EXP_ADJUSTMENT_PEINFTRUEUP VARCHAR(255),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255)
);
create or replace TABLE VW_FT_SOLDE_GL (
	ID_DIM_DATE_FIN_PERIODE_COMPTABLE VARCHAR(255),
	SK_ID_DIM_COMPTE_GL VARCHAR(255),
	SK_ID_DIM_MASTER_COA VARCHAR(255),
	JOURNAL VARCHAR(255),
	SOURCE VARCHAR(255),
	SYSTEME_SOURCE VARCHAR(255),
	TYPE_ENTREE VARCHAR(255),
	ID_PRIMAIRE VARCHAR(255),
	ID_SECONDAIRE VARCHAR(255),
	ID_RECLAMATION VARCHAR(255),
	ID_REASSURANCE VARCHAR(255),
	DEBIT VARCHAR(255),
	CREDIT VARCHAR(255),
	SOLDE VARCHAR(255),
	MD_ACTIVATION_DT VARCHAR(255),
	MD_MODIFICATION_DT VARCHAR(255),
	MD_OBSOLESCENCE_DT VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_ROW_IS_NOT_VALID VARCHAR(255)
);
create or replace TABLE VW_VI_AGE (
	SK_ID_DIM_AGE VARCHAR(255),
	AGE VARCHAR(255),
	TRANCHE_AGES_1 VARCHAR(255),
	TRANCHE_AGES_MIN_1 VARCHAR(255),
	TRANCHE_AGES_MAX_1 VARCHAR(255),
	TRANCHE_AGES_2 VARCHAR(255),
	TRANCHE_AGES_MIN_2 VARCHAR(255),
	TRANCHE_AGES_MAX_2 VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_START_DT VARCHAR(255)
);
create or replace TABLE VW_VI_COUVERTURE (
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	ID_DIM_DATE_EMISSION VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_DUREE VARCHAR(255),
	SK_ID_DIM_AGE_EMISSION VARCHAR(255),
	SK_ID_DIM_AGE_ATTEINT VARCHAR(255),
	SK_ID_DIM_STATUT_PREFERENTIEL VARCHAR(255),
	SK_ID_DIM_SEXE VARCHAR(255),
	SK_ID_DIM_STATUT_FUMEUR VARCHAR(255),
	SK_ID_DIM_TERRITOIRE VARCHAR(255),
	SK_ID_DIM_TRAITE_REASSURANCE VARCHAR(255),
	SK_ID_DIM_RESEAU_DISTRIBUTION VARCHAR(255),
	SK_ID_DIM_CODE_PLAN_AXIS VARCHAR(255),
	SK_ID_DIM_RAISON_TERMINAISON VARCHAR(255),
	SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES VARCHAR(255),
	SK_ID_DIM_COUVERTURE_INFO VARCHAR(255),
	GEN_UID VARCHAR(255),
	BANDE VARCHAR(255),
	BEN_CURRENT_VALUE VARCHAR(255),
	CODE_JOINT_LIFE VARCHAR(255),
	PRM_USERATING VARCHAR(255),
	RATING_MULT VARCHAR(255),
	RATING_FLAT VARCHAR(255),
	RATING_TEMP VARCHAR(255),
	RATING_TEMPDUR VARCHAR(255),
	PRM_MODE VARCHAR(255),
	BEN_OPTION VARCHAR(255),
	IND_COUVERTURE_TERMINEE VARCHAR(255),
	RAISON_TERMINAISON VARCHAR(255),
	IND_GARANTIE VARCHAR(255),
	IND_TRANSFORMATION VARCHAR(255),
	IND_TRAITE_REASSURANCE VARCHAR(255),
	CODE_PARTICIPATION VARCHAR(255),
	CODE_TYPE_TRANSFORMATION VARCHAR(255),
	NOM_TYPE_TRANSFORMATION VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_START_DT VARCHAR(255)
);
create or replace TABLE VW_VI_DUREE (
	DUREE VARCHAR(255),
	TRANCHE_DUREES_1 VARCHAR(255),
	TRANCHE_DUREES_MIN_1 VARCHAR(255),
	TRANCHE_DUREES_MAX_1 VARCHAR(255),
	TRANCHE_DUREES_2 VARCHAR(255),
	TRANCHE_DUREES_MIN_2 VARCHAR(255),
	TRANCHE_DUREES_MAX_2 VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255),
	MD_START_DT VARCHAR(255)
);
create or replace TABLE VW_VI_MASTER_COA (
	MD_HASH_NAT_KEY VARCHAR(40),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50),
	VARIABLE_CSM VARCHAR(300),
	CUSTOM_DIM_1 VARCHAR(100),
	CUSTOM_DIM_2 VARCHAR(100),
	MD_START_DT TIMESTAMP_LTZ(9),
	MD_CREATION_DT TIMESTAMP_LTZ(9),
	MD_SOURCE VARCHAR(100),
	MD_IS_ACTIVE BOOLEAN
);
CREATE OR REPLACE PROCEDURE "SP_CONV_M_USP_VI_DESAGREAGATIONCOMPTABLE_INS"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var pre_sql_command = "TRUNCATE TABLE DB_ACT_DEV_DM.DM_VI_TRAVAIL.SP_OUTPUT;";
var call_sql_command = "CALL DB_ACT_" + ENV + "_DM.DM_VI_TRAVAIL.USP_VI_DESAGREGATIONCOMPTABLE(''DB_ACT_DEV_STG'', ''DB_ACT_DEV_DM'');";
var sql_command ="INSERT INTO DB_ACT_" + ENV + "_DM.DM_VI_TRAVAIL.SP_OUTPUT (SELECT DISTINCT $1 AS resultat FROM table(result_scan(last_query_id())));";
try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
	var call_statement = snowflake.createStatement({sqlText: call_sql_command });
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = pre_sql_statement.execute();
	var result_scan0 = call_statement.execute();
	var result_scan1 = sql_statement.execute();
  result = "Succeeded!";
}
catch (err) {
    result = "Failed: Code: " + err.code + " \\n State: " + err.state;
    result += " \\n Message: " + err.message;
    result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
    throw result;
  }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_M_VALIDATION_DESAGREGATION_OUTPUT_DM"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "select RESULTAT from DB_ACT_"+ENV+"_DM.DM_VI_TRAVAIL.SP_OUTPUT where SP_OUTPUT.RESULTAT <> ''Success''";
var ins_command = "INSERT INTO DB_ACT_"+ENV+"_DM.DM_VI_TRAVAIL.SP_OUTPUT (RESULTAT) SELECT ''La désagrégation a roulé avec succès.'' AS RESULTAT;"
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	while (result_scan.next()) {
		var i_RESULTAT = result_scan.getColumnValue(1);
		if ( i_RESULTAT ) {
			throw ''ERREUR détectée lors de la désagrégation: '' + i_RESULTAT
		}
		
	}
result = i_RESULTAT;
}
catch (err) {
		result = err;
		return result;
	}
return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_VALIDATION_DESAGREGATION_OUTPUT_DM"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var sql_command = "select RESULTAT from DB_ACT_"+ENV+"_DM.DM_VI_TRAVAIL.SP_OUTPUT where SP_OUTPUT.RESULTAT <> ''Success''";
var ins_command = "INSERT INTO DB_ACT_"+ENV+"_DM.DM_VI_TRAVAIL.SP_OUTPUT (RESULTAT) SELECT ''La désagrégation a roulé avec succès.'' AS RESULTAT;"
try {
	var sql_statement = snowflake.createStatement({sqlText: sql_command });
	var result_scan = sql_statement.execute();
	while (result_scan.next()) {
		var i_RESULTAT = result_scan.getColumnValue(1);
		if ( i_RESULTAT ) {
			throw ''ERREUR détectée lors de la désagrégation: '' + i_RESULTAT
		}
		
	}
result = i_RESULTAT;
}
catch (err) {
		result = err;
		return result;
	}
return result;
';
CREATE OR REPLACE PROCEDURE "USP_VI_DESAGREGATIONCOMPTABLE"("SOURCE_DB" VARCHAR(16777216), "TARGET_DB" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS ' 
		var resultat = "";
		var sql_cmd_insert = `
            -- inserer dans une nouvelle table pour deaggregation, l''ancienne table DWH_VI.VI_DESAGREGATIONCOMPTABLE n''est plus utilisée.
			INSERT INTO	` + TARGET_DB + `.DM_VI_TRAVAIL.VI_DESAGREGATION_PRESTATION_COMPTABLE

WITH CTB AS (
                SELECT
					ID_PRIMAIRE 			AS Nopolice,
					PERIODE_COMPTABLE		AS PERIODE_COMPTABLE,
                    CD_ENTITE               AS CD_ENTITE,
                    CD_NATURE               AS CD_NATURE,
                    CD_ORIGINE              AS CD_ORIGINE,
                    CD_PERIODICITE          AS CD_PERIODICITE,
                    CD_CENTRE_COUT          AS CD_CENTRE_COUT,
                    CD_INTERCO              AS CD_INTERCO,
                    CD_LIGNE_AFFAIRE        AS CD_LIGNE_AFFAIRE,
                    CD_PRODUIT              AS CD_PRODUIT,
                    CD_PARTICIPATION        AS CD_PARTICIPATION,
                    CD_GEOGRAPHIE           AS CD_GEOGRAPHIE,
                    CD_PROJET               AS CD_PROJET,
                    VARIABLE_CSM            AS VARIABLE_CSM,
                    CUSTOM_DIM_1            AS CUSTOM_DIM_1,
                    CUSTOM_DIM_2            AS CUSTOM_DIM_2,
                    CASE WHEN UPPER(CUSTOM_DIM_1) = ''SURRENDERBENEFITS'' THEN ''ABANDON''
                         WHEN UPPER(CUSTOM_DIM_1) = ''DEATHBENEFITS'' THEN ''MORTALITE''
                         WHEN UPPER(CUSTOM_DIM_1) IN (''DEATHBENEFITEXO'', ''DISABILITYBENEFITS'', ''EXO'', ''DISABILITYBENEFITSEXO'') THEN ''INVALIDITE''
                         WHEN UPPER(CUSTOM_DIM_1) = ''MORBIDITY'' THEN ''MORBIDITE''
                    END                     AS NATURE,
					sum(ctb.MNT_CTB_POLICE) :: NUMBER(32,12) AS MNT_CTB_POLICE
					
				FROM
					` + SOURCE_DB + `.MODEL_VI.VW_VI_TRANSACTION_COMPTABLE CTB
				GROUP BY
					ID_PRIMAIRE,
					PERIODE_COMPTABLE,
                    CD_ENTITE,
                    CD_NATURE,
                    CD_ORIGINE,
                    CD_PERIODICITE,
                    CD_CENTRE_COUT,
                    CD_INTERCO,
                    CD_LIGNE_AFFAIRE,
                    CD_PRODUIT,
                    CD_PARTICIPATION,
                    CD_GEOGRAPHIE,
                    CD_PROJET,
                    VARIABLE_CSM,
                    CUSTOM_DIM_1,
                    CUSTOM_DIM_2,
                    CASE WHEN UPPER(CUSTOM_DIM_1) = ''SURRENDERBENEFITS'' THEN ''ABANDON''
                         WHEN UPPER(CUSTOM_DIM_1) = ''DEATHBENEFITS'' THEN ''MORTALITE''
                         WHEN UPPER(CUSTOM_DIM_1) IN (''DEATHBENEFITEXO'', ''DISABILITYBENEFITS'', ''EXO'', ''DISABILITYBENEFITSEXO'') THEN ''INVALIDITE''
                         WHEN UPPER(CUSTOM_DIM_1) = ''MORBIDITY'' THEN ''MORBIDITE''
                    END

),
COUV AS (
				SELECT
					gen_uid                                         AS gen_uid,
					Gen_PolNo                                       AS NopoliceCouv,
					Ben_CurrentValue                                AS Ben_CurrentValue,
					IndTermine                                      AS IndTermine,
					LOB                                             AS LOB,
					RaisonTerminaison                               AS RaisonTerminaison,
					Module                                          AS Module,
					Product                                         AS Product,
					count(gen_uid) OVER (PARTITION BY gen_polno)    AS Count_gen
				FROM
					` + SOURCE_DB + `.MODEL_VI.VW_VI_COUVERTURE viCouv
					INNER JOIN ` + SOURCE_DB + `.MODEL_VI.VW_VI_PRODUCT_FEATURE_TABLE pl ON
										viCouv.AXIS_PLANCODE = pl.CD_PLAN_AXIS 
),
CTB_COUV AS (
                SELECT DISTINCT
					COALESCE(couv.Gen_UID, ctb.Nopolice, ''-1'') 	        AS Gen_UID,
					IFNULL(ctb.Nopolice, ''-1'')               				AS nopolice,
					IFNULL(couv.Ben_currentValue, ''-1'')                   AS Ben_currentValue,
					IFNULL(couv.IndTermine, 1) 								AS IndTermine,
					IFNULL(ctb.MNT_CTB_POLICE, 0)::number(32,12)			AS MNT_CTB_POLICE,
					ctb.Nature 												AS Nature,
					COALESCE(couv.Count_gen,1) 			                    AS count_Gen,
					ctb.PERIODE_COMPTABLE 									AS PERIODE_COMPTABLE,
                    ctb.CD_ENTITE                                           AS CD_ENTITE,
                    ctb.CD_NATURE                                           AS CD_NATURE,
                    ctb.CD_ORIGINE                                          AS CD_ORIGINE,
                    ctb.CD_PERIODICITE                                      AS CD_PERIODICITE,
                    ctb.CD_CENTRE_COUT                                      AS CD_CENTRE_COUT,
                    ctb.CD_INTERCO                                          AS CD_INTERCO,
                    ctb.CD_LIGNE_AFFAIRE                                    AS CD_LIGNE_AFFAIRE,
                    ctb.CD_PRODUIT                                          AS CD_PRODUIT,
                    ctb.CD_PARTICIPATION                                    AS CD_PARTICIPATION,
                    ctb.CD_GEOGRAPHIE                                       AS CD_GEOGRAPHIE,
                    ctb.CD_PROJET                                           AS CD_PROJET,
                    ctb.VARIABLE_CSM                                        AS VARIABLE_CSM,
                    ctb.CUSTOM_DIM_1                                        AS CUSTOM_DIM_1,
                    ctb.CUSTOM_DIM_2                                        AS CUSTOM_DIM_2,
                    couv.LOB 											    AS LOB,
					couv.RaisonTerminaison 									AS RaisonTerminaison,
					couv.Module 											AS Module,
					couv.Product 											AS Product,
					CASE
						WHEN couv.RaisonTerminaison = ''Other Benefit (with decrement)'' THEN 1
						ELSE 0 END  										AS ind_prestation,
					CASE
						WHEN (LOB = ''MI'' AND MODULE = ''RL'') OR Product = ''CriticalIllness'' THEN 1
						ELSE 0 END 											AS ind_maladie_grave
				FROM
					couv
					FULL JOIN CTB ctb ON ctb.Nopolice = couv.NopoliceCouv

				WHERE
					MNT_CTB_POLICE IS NOT NULL
					AND MNT_CTB_POLICE <> 0 
)

SELECT
    IFNULL(CD_ENTITE, ''NULL'')                               	AS CD_ENTITE,
    IFNULL(CD_NATURE, ''NULL'')                                 AS CD_NATURE,
    IFNULL(CD_ORIGINE, ''NULL'')                                AS CD_ORIGINE,
    IFNULL(CD_PERIODICITE, ''NULL'')                            AS CD_PERIODICITE,
    IFNULL(CD_CENTRE_COUT, ''NULL'')                            AS CD_CENTRE_COUT,
    IFNULL(CD_INTERCO, ''NULL'')                                AS CD_INTERCO,
    IFNULL(CD_LIGNE_AFFAIRE, ''NULL'')                          AS CD_LIGNE_AFFAIRE,
    IFNULL(CD_PRODUIT, ''NULL'')                                AS CD_PRODUIT,
    IFNULL(CD_PARTICIPATION, ''NULL'')                          AS CD_PARTICIPATION,
    IFNULL(CD_GEOGRAPHIE, ''NULL'')                             AS CD_GEOGRAPHIE,
    IFNULL(CD_PROJET, ''NULL'')                                 AS CD_PROJET,
    IFNULL(VARIABLE_CSM, ''NULL'')                              AS VARIABLE_CSM,
    IFNULL(CUSTOM_DIM_1, ''NULL'')                              AS CUSTOM_DIM_1,
    IFNULL(CUSTOM_DIM_2, ''NULL'')                              AS CUSTOM_DIM_2,
    IFNULL(PERIODE_COMPTABLE, ''NULL'') 						AS PERIODE_COMPTABLE,
    IFNULL(NATURE, ''NULL'') 									AS SOURCE_SOE,
    IFNULL(Gen_UID, ''NULL'') 									AS Gen_UID,
    IFNULL(Nopolice, ''NULL'') 									AS Nopolice,
    
    CAST((IFNULL(CASE WHEN NATURE in (''ABANDON'',''MORTALITE'',''FONDDECES'') THEN
            CASE
                WHEN IndTermine = 1 AND count_gen = 1 THEN MNT_CTB_POLICE
                WHEN IndTermine = 1 AND count_gen > 1 THEN (MNT_CTB_POLICE * Ben_CurrentValue / SUM(Ben_CurrentValue) OVER (PARTITION BY NoPolice, IndTermine, CD_ENTITE, CD_NATURE, CD_ORIGINE, CD_PERIODICITE, CD_CENTRE_COUT, CD_INTERCO, CD_LIGNE_AFFAIRE, CD_PRODUIT, CD_PARTICIPATION,CD_GEOGRAPHIE, CD_PROJET))
                WHEN IndTermine = 1 AND SUM(IndTermine) OVER (PARTITION BY NoPolice) > 0 AND count_gen > 1 THEN (MNT_CTB_POLICE * (Ben_CurrentValue / Ben_CurrentValue))
                WHEN IndTermine = 0 AND SUM(IndTermine) OVER (PARTITION BY NoPolice) > 0 THEN 0
                ELSE (MNT_CTB_POLICE / Count_gen)
            END
        WHEN NATURE in (''MORBIDITE'') THEN
            CASE
                WHEN count_Gen = 1 THEN MNT_CTB_POLICE
                WHEN SUM(ind_prestation) OVER (PARTITION BY NoPolice) > 0 OR SUM(ind_maladie_grave) OVER (PARTITION BY NoPolice) > 0 THEN
                    CASE WHEN ind_prestation = 1 AND SUM(ind_prestation) OVER (PARTITION BY NoPolice, CD_ENTITE, CD_NATURE, CD_ORIGINE, CD_PERIODICITE, CD_CENTRE_COUT, CD_INTERCO, CD_LIGNE_AFFAIRE, CD_PRODUIT, CD_PARTICIPATION,CD_GEOGRAPHIE, CD_PROJET) = 1 THEN MNT_CTB_POLICE
                         WHEN ind_prestation = 1 AND SUM(ind_prestation) OVER (PARTITION BY NoPolice, CD_ENTITE, CD_NATURE, CD_ORIGINE, CD_PERIODICITE, CD_CENTRE_COUT, CD_INTERCO, CD_LIGNE_AFFAIRE, CD_PRODUIT, CD_PARTICIPATION,CD_GEOGRAPHIE, CD_PROJET) > 1 
                                THEN (MNT_CTB_POLICE * Ben_CurrentValue)/ SUM(ind_prestation*Ben_CurrentValue) OVER (PARTITION BY NoPolice, CD_ENTITE, CD_NATURE, CD_ORIGINE, CD_PERIODICITE, CD_CENTRE_COUT, CD_INTERCO, CD_LIGNE_AFFAIRE, CD_PRODUIT, CD_PARTICIPATION,CD_GEOGRAPHIE, CD_PROJET)
                         WHEN ind_maladie_grave = 1 AND SUM(ind_maladie_grave) OVER (PARTITION BY NoPolice, CD_ENTITE, CD_NATURE, CD_ORIGINE, CD_PERIODICITE, CD_CENTRE_COUT, CD_INTERCO, CD_LIGNE_AFFAIRE, CD_PRODUIT, CD_PARTICIPATION,CD_GEOGRAPHIE, CD_PROJET) = 1 THEN MNT_CTB_POLICE
                         WHEN ind_maladie_grave = 1 AND SUM(ind_maladie_grave) OVER (PARTITION BY NoPolice, CD_ENTITE, CD_NATURE, CD_ORIGINE, CD_PERIODICITE, CD_CENTRE_COUT, CD_INTERCO, CD_LIGNE_AFFAIRE, CD_PRODUIT, CD_PARTICIPATION,CD_GEOGRAPHIE, CD_PROJET) > 1 
                                THEN (MNT_CTB_POLICE * Ben_CurrentValue)/ SUM(ind_maladie_grave*Ben_CurrentValue) OVER (PARTITION BY NoPolice, CD_ENTITE, CD_NATURE, CD_ORIGINE, CD_PERIODICITE, CD_CENTRE_COUT, CD_INTERCO, CD_LIGNE_AFFAIRE, CD_PRODUIT, CD_PARTICIPATION,CD_GEOGRAPHIE, CD_PROJET)
                         ELSE 0.0
                    END
                ELSE (MNT_CTB_POLICE / Count_gen)
            END
        END, 0)) AS NUMBER(32,12))                                                 AS MNT_COMPTABLE
FROM CTB_COUV
WHERE NATURE <> ''NULL''
	;`

	try {
		// sql_cmd_insert = "SELECT 1;"              //for debugging, returns Success
		// sql_cmd_insert = "SELECT 1/0";            //for debugging, returns Error status 
		snowflake.execute ({sqlText: sql_cmd_insert});
        resultat = "Success";                             // Retourne un indicateur de succes.
	} 
	catch (err) {
                                              // Retourne un indicateur erreur.
		resultat = "Failed: Code: " + err.code + "\\n  State: " + err.state;
		resultat += "\\n  Message: " + err.message;
        resultat += "\\nStack Trace:\\n" + err.stackTraceTxt; 	
	}	
	return resultat;
';
create or replace schema DM_VI_TRAVAIL_UNIT;

create or replace TABLE VW_VI_COUVERTURE (
	SK_ID_DIM_COUVERTURE VARCHAR(255),
	ID_DIM_DATE_EMISSION VARCHAR(255),
	SK_ID_DIM_MODULE_COUVERTURE VARCHAR(255),
	SK_ID_DIM_DUREE VARCHAR(255),
	SK_ID_DIM_AGE_EMISSION VARCHAR(255),
	SK_ID_DIM_AGE_ATTEINT VARCHAR(255),
	SK_ID_DIM_STATUT_PREFERENTIEL VARCHAR(255),
	SK_ID_DIM_SEXE VARCHAR(255),
	SK_ID_DIM_STATUT_FUMEUR VARCHAR(255),
	SK_ID_DIM_TERRITOIRE VARCHAR(255),
	SK_ID_DIM_TRAITE_REASSURANCE VARCHAR(255),
	SK_ID_DIM_RESEAU_DISTRIBUTION VARCHAR(255),
	SK_ID_DIM_CODE_PLAN_AXIS VARCHAR(255),
	SK_ID_DIM_RAISON_TERMINAISON VARCHAR(255),
	SK_ID_DIM_TRANCHE_MONTANTS VARCHAR(255),
	SK_ID_DIM_VALUATION_ASSUMPTIONS_TABLES VARCHAR(255),
	GEN_UID VARCHAR(255),
	BANDE VARCHAR(255),
	BEN_CURRENT_VALUE VARCHAR(255),
	CODE_JOINT_LIFE VARCHAR(255),
	PRM_USERATING VARCHAR(255),
	RATING_MULT VARCHAR(255),
	RATING_FLAT VARCHAR(255),
	RATING_TEMP VARCHAR(255),
	RATING_TEMPDUR VARCHAR(255),
	PRM_MODE VARCHAR(255),
	BEN_OPTION VARCHAR(255),
	IND_COUVERTURE_TERMINEE VARCHAR(255),
	RAISON_TERMINAISON VARCHAR(255),
	IND_GARANTIE VARCHAR(255),
	IND_TRANSFORMATION VARCHAR(255),
	IND_TRAITE_REASSURANCE VARCHAR(255),
	CODE_PARTICIPATION VARCHAR(255),
	MD_HASH_NAT_KEY VARCHAR(255),
	MD_HASHDIFF_TYPE_1 VARCHAR(255),
	MD_HASHDIFF_TYPE_2 VARCHAR(255)
);
create or replace schema DM_VI_UNIT_SANDBOX;

create or replace TABLE DIM_AGE_ATTEINT (
	SK_ID_AGE_ATTEINT NUMBER(38,0) autoincrement,
	AGE_ATTEINT NUMBER(38,0),
	AGE_ATTEINT_BUCKET VARCHAR(100),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_AGE_EMISSION (
	SK_ID_AGE_EMISSION NUMBER(38,0) autoincrement,
	AGE VARCHAR(50),
	AGE_EMISSION_BUCKET VARCHAR(100),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_INFO_COUVERTURE (
	SK_ID_INFO_COUVERTURE NUMBER(38,0) autoincrement,
	MODULE VARCHAR(10),
	CVG_CODEJOINTLIFE VARCHAR(10),
	CVG_PREFSTATUS VARCHAR(10),
	CVG_SEX VARCHAR(10),
	CVG_SMKSTATUS VARCHAR(10),
	BEN_OPTION NUMBER(4,0),
	GEN_COMPANYCODE VARCHAR(10),
	LOB VARCHAR(10),
	INDTERMINE NUMBER(38,0),
	INDGARANTIE NUMBER(38,0),
	GEN_PARCODE VARCHAR(10),
	INDTRANSFORMATION NUMBER(2,0),
	RAISONTERMINAISON VARCHAR(50),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_MONTANT_ASSURANCE (
	SK_ID_MONTANT_ASSURANCE NUMBER(38,0) autoincrement,
	BANDE VARCHAR(10),
	BEN_CURRENT_VALUE NUMBER(28,10),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_REASSURANCE (
	SK_ID_REASSURANCE NUMBER(38,0) autoincrement,
	TRAITE_REASSURANCE VARCHAR(2),
	TYPE_REASSURANCE VARCHAR(2),
	REINSCE_NOREINSURER VARCHAR(2),
	REINSCE_TREATYDATE DATE,
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(100),
	MD_HASHDIFF_TYPE_2 VARCHAR(100),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace TABLE DIM_SURPRIME (
	SK_ID_SURPRIME NUMBER(38,0) autoincrement,
	PRM_USERATING NUMBER(38,0),
	RATING_MULT NUMBER(19,10),
	RATING_FLAT NUMBER(19,10),
	RATING_TEMP NUMBER(19,10),
	RATING_TEMPDUR NUMBER(19,10),
	MD_ACTIVATION_DT TIMESTAMP_LTZ(9),
	MD_MODIFICATION_DT TIMESTAMP_LTZ(9),
	MD_OBSOLESCENCE_DT TIMESTAMP_LTZ(9),
	MD_HASH_NAT_KEY VARCHAR(100),
	MD_HASHDIFF_TYPE_1 VARCHAR(50),
	MD_HASHDIFF_TYPE_2 VARCHAR(50),
	MD_CREATION_AUDIT_ID NUMBER(38,0)
);
create or replace schema PUBLIC;
