create or replace database DB_AC_DEV_DWH;

create or replace schema DATALAKE;

create or replace schema ENROLLMENT_BDV;

create or replace TABLE SAT_LINK_ENROLLMENT_COMPUTE (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	LOCATION VARCHAR(50) COMMENT 'Location',
	ISPOPULATION NUMBER(1,0) COMMENT 'br_020',
	ISONCAMPAIGN NUMBER(1,0) COMMENT 'br_021',
	ISONGLOBALCAMPAIGN NUMBER(1,0) COMMENT 'br_021',
	ISONLEAVE NUMBER(1,0) COMMENT 'br_21',
	ISNEWHIRE NUMBER(1,0) COMMENT 'br_025',
	ISELIGBLEREENROLLMENT NUMBER(1,0) COMMENT 'br_023 Employee in campaign',
	ISELIGIBLEGLOBALREENROLMENT NUMBER(1,0) COMMENT 'br_023 Employee in campaign',
	ISONLEAVERETURN NUMBER(1,0) COMMENT 'br_024 Employee from population '
);
create or replace schema ENROLLMENT_RDV;

create or replace TABLE LINK_ENROLLMENT (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	HK_HUB_OPEN_SHOPPING_PERIOD VARCHAR(16777216) COMMENT 'HkHub of Open Shopping Period',
	HK_HUB_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'Hkhub of Product Catalog ',
	HK_HUB_PREVIOUS_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'Hkhub of Previous Product Catalog',
	HK_HUB_WORKER VARCHAR(16777216) COMMENT 'HkHub of worker',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HkHub of Customer',
	HK_HUB_ORGANIZATION VARCHAR(16777216) COMMENT 'HkHub og Organisation',
	HK_HUB_CAMPAIGN VARCHAR(16777216) COMMENT 'HkHub of Campaign',
	HK_HUB_LIFEEVENT VARCHAR(16777216) COMMENT 'HkHub of LifeEvent',
	OPEN_SHOPPING_PERIOD_ID NUMBER(38,0) COMMENT 'Open Shopping Period Id from platform',
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Product Catalog Id from platform',
	PREVIOUS_PRODUCTCATALOG_ID VARCHAR(16777216) COMMENT 'Previous Product Catalog Id from platform',
	WORKER_ID VARCHAR(16777216) COMMENT 'worker id from platform',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer id from platform',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Organization id from platform',
	CAMPAIGN_ID VARCHAR(16777216) COMMENT 'Campaign id from platform',
	LIFE_EVENT_ID VARCHAR(16777216) COMMENT 'Life Event id from platform'
);
create or replace TABLE SAT_LINK_ENROLLMENT (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MD_ACTIVE VARCHAR(1) DEFAULT 'A' COMMENT 'Indicate if the record is active'
);
create or replace view VW_SAT_LINK_ENROLLMENT(
	HK_LINK,
	MD_CREATION_DT,
	MD_SOURCE,
	HK_HUB_OPEN_SHOPPING_PERIOD,
	HK_HUB_PRODUCT_CATALOG,
	HK_HUB_PREVIOUS_PRODUCT_CATALOG,
	HK_HUB_WORKER,
	HK_HUB_CUSTOMER,
	HK_HUB_ORGANIZATION,
	HK_HUB_CAMPAIGN,
	HK_HUB_LIFEEVENT,
	OPEN_SHOPPING_PERIOD_ID,
	PRODUCT_CATALOG_ID,
	PREVIOUS_PRODUCTCATALOG_ID,
	WORKER_ID,
	CUSTOMER_ID,
	ORGANIZATION_ID,
	CAMPAIGN_ID,
	LIFE_EVENT_ID
) as 
(
SELECT a.HK_LINK, a.MD_CREATION_DT, a.MD_SOURCE, a.HK_HUB_OPEN_SHOPPING_PERIOD, a.HK_HUB_PRODUCT_CATALOG, a.HK_HUB_PREVIOUS_PRODUCT_CATALOG, a.HK_HUB_WORKER, a.HK_HUB_CUSTOMER, a.HK_HUB_ORGANIZATION, a.HK_HUB_CAMPAIGN, a.HK_HUB_LIFEEVENT, a.OPEN_SHOPPING_PERIOD_ID, a.PRODUCT_CATALOG_ID, a.PREVIOUS_PRODUCTCATALOG_ID, a.WORKER_ID, a.CUSTOMER_ID, a.ORGANIZATION_ID, a.CAMPAIGN_ID, a.LIFE_EVENT_ID 
FROM DB_AC_DEV_DWH.ENROLLMENT_RDV.LINK_ENROLLMENT a 
JOIN DB_AC_DEV_DWH.ENROLLMENT_RDV.SAT_LINK_ENROLLMENT b on a.HK_LINK = b.hk_link
WHERE b.MD_ACTIVE = 'A' );
create or replace schema ENROLLMENT_WT_BDV;

create or replace TRANSIENT TABLE WT_SAT_LINK_ENROLLMENT_COMPUTE (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	LOCATION VARCHAR(50) COMMENT 'Location',
	ISPOPULATION NUMBER(1,0) COMMENT 'br_020',
	ISONCAMPAIGN NUMBER(1,0) COMMENT 'br_021',
	ISONGLOBALCAMPAIGN NUMBER(1,0) COMMENT 'br_021',
	ISONLEAVE NUMBER(1,0) COMMENT 'br_021',
	ISNEWHIRE NUMBER(1,0) COMMENT 'br_025',
	ISELIGIBLEREENROLMENT NUMBER(1,0) COMMENT 'br_023 Employee in Campain',
	ISELIGIBLEGLOBALREENROLMENT NUMBER(1,0) COMMENT 'br_023 Employee in campaign',
	ISONLEAVERETURN NUMBER(1,0) COMMENT 'br_024 Employee from population '
);
create or replace schema PLATFORM_ACCESS_LOG_BDV;

create or replace schema PLATFORM_ACCESS_LOG_RDV;

create or replace TABLE LINK_PLATFORM_ACCESS_LOG (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_WORKER VARCHAR(16777216) COMMENT 'HkHub of the worker',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HkHub of the customer',
	HK_HUB_ORGANIZATION VARCHAR(16777216) COMMENT 'HkHub of the organization',
	WORKER_ID VARCHAR(16777216) COMMENT 'worker Id from the platform',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'customer Id from the platform',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'organization Id from the platform'
);
create or replace TABLE SAT_LINK_PLATFORM_ACCESS_LOG_PLT (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	ACCESS_DT TIMESTAMP_NTZ(9) COMMENT 'The date when the user log on the platform',
	USER_AGENT VARCHAR(16777216) COMMENT 'The user agent of the browser used by the user'
);
create or replace schema PRODUCT_RDV;

create or replace TABLE HUB_PERSONAL_INTEREST (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	INTEREST_ID VARCHAR(16777216) COMMENT 'Interest plateform ID'
);
create or replace TABLE HUB_PRODUCT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Column description'
);
create or replace TABLE HUB_PRODUCT_CATALOG (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Product catalog plateform ID'
);
create or replace TABLE HUB_PRODUCT_TAG (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	TAG VARCHAR(16777216) COMMENT 'Column description'
);
create or replace TABLE LINK_PERSONAL_INTEREST_TAG (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_PERSONAL_INTEREST VARCHAR(16777216) COMMENT 'HASH of the personal interest business key',
	HK_HUB_PRODUCT_TAG VARCHAR(16777216) COMMENT 'HASH of the TAG',
	INTEREST_ID VARCHAR(16777216) COMMENT 'Interest plateform ID ',
	TAG VARCHAR(16777216) COMMENT 'TAG related to the personal interest'
);
create or replace TABLE LINK_PRODUCT_CATALOG_ORGANIZATION (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'HASH of the product catalog business key',
	HK_HUB_ORGANIZATION VARCHAR(16777216) COMMENT 'HASH of the organization business key',
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Product Catalog plateform ID',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Worker organization id'
);
create or replace TABLE LINK_PRODUCT_CATALOG_PRODUCT (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'HASH of the product catalog business key',
	HK_HUB_PRODUCT VARCHAR(16777216) COMMENT 'HASH of the product business key',
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'Product Catalog plateform ID',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Product id'
);
create or replace TABLE LINK_PRODUCT_PACKAGE (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_PRODUCT VARCHAR(16777216) COMMENT 'Column description',
	HK_HUB_PACKAGE_PRODUCT VARCHAR(16777216),
	PRODUCT_ID VARCHAR(16777216),
	PACKAGE_PRODUCT_ID VARCHAR(16777216)
);
create or replace TABLE LINK_PRODUCT_PROVIDER (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HUB_PRODUCT VARCHAR(16777216) COMMENT 'Column description',
	HUB_PROVIDER VARCHAR(16777216),
	PRODUCT_ID VARCHAR(16777216),
	PROVIDER_ID VARCHAR(16777216)
);
create or replace TABLE LINK_PRODUCT_TAG (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_PRODUCT VARCHAR(16777216) COMMENT 'Column description',
	HK_HUB_PRODUCT_TAG VARCHAR(16777216),
	PRODUCT_ID VARCHAR(16777216),
	TAG VARCHAR(16777216)
);
create or replace TABLE SAT_LINK_PERSONAL_INTEREST_TAG_PLT (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID'
);
create or replace TABLE SAT_LINK_PRODUCT_CATALOG_PRODUCT_PLT (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID'
);
create or replace TABLE SAT_LINK_PRODUCT_TAG_PLT (
	HK_LINK VARCHAR(64),
	MD_START_DT TIMESTAMP_NTZ(9),
	MD_HASHDIFF VARCHAR(64),
	MD_CREATION_DT TIMESTAMP_NTZ(9),
	MD_SOURCE VARCHAR(1000),
	MD_CREATION_AUDIT_ID VARCHAR(1000)
);
create or replace TABLE SAT_PERSONAL_INTEREST_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	INTEREST_ID VARCHAR(16777216) COMMENT 'Interest plateform ID',
	NAME_FR VARCHAR(16777216) COMMENT 'Interest name in french',
	NAME_EN VARCHAR(16777216) COMMENT 'Interest name in english'
);
create or replace TABLE SAT_PRODUCT_CATALOG_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	NAME_FR VARCHAR(16777216) COMMENT 'Product Catalog Name (fr)',
	NAME_EN VARCHAR(16777216) COMMENT 'Product Catalog Name (en)',
	DESCRIPTION_EN VARCHAR(16777216) COMMENT 'Product Catalog Description (fr)',
	DESCRIPTION_FR VARCHAR(16777216) COMMENT 'Product Catalog Description (en)',
	START_DATE DATE COMMENT 'Product Catalog Start Date',
	END_DATE DATE COMMENT 'Product Catalog End Date'
);
create or replace TABLE SAT_PRODUCT_INFO_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	CATEGORY VARCHAR(16777216) COMMENT 'Column description',
	NAME_FR VARCHAR(16777216) COMMENT ' Product Name in French',
	NAME_EN VARCHAR(16777216) COMMENT 'Product Name in English',
	DESCRIPTION_FR VARCHAR(16777216) COMMENT 'Product Description in French',
	DESCRIPTION_EN VARCHAR(16777216) COMMENT 'Product Description in English',
	TYPE VARCHAR(16777216) COMMENT 'Type of product',
	COVERAGE_TYPE VARCHAR(16777216) COMMENT 'Coverage type',
	AVAILABILITY_START_DATE DATE COMMENT 'Product availability start date',
	AVAILABILITY_END_DATE DATE COMMENT 'Product availability end date',
	SKU VARCHAR(16777216),
	IS_PACKAGE VARCHAR(16777216)
);
create or replace view VW_LINK_LOAD_PERSONAL_INTEREST_TAG(
	HK_HUB,
	MD_START_DT,
	MD_SOURCE,
	MD_CREATION_AUDIT_ID,
	PERSONAL_INTEREST_ID,
	TAGS
) as
(
       SELECT HK_HUB_PERSONAL_INTEREST AS HK_HUB, 
              MD_START_DT AS MD_START_DT,
              MAX(lnk.MD_SOURCE) AS MD_SOURCE,
              MAX(slnk.MD_CREATION_AUDIT_ID) AS MD_CREATION_AUDIT_ID,
              MAX(INTEREST_ID) as PERSONAL_INTEREST_ID,
              ARRAY_TO_STRING(ARRAY_AGG(TAG) WITHIN GROUP (ORDER BY HK_HUB_PERSONAL_INTEREST, MD_START_DT DESC),',') AS TAGS
        FROM PRODUCT_RDV.LINK_PERSONAL_INTEREST_TAG lnk
        INNER JOIN PRODUCT_RDV.SAT_LINK_PERSONAL_INTEREST_TAG_PLT slnk on lnk.HK_LINK = slnk.HK_LINK
    GROUP BY HK_HUB_PERSONAL_INTEREST, MD_START_DT
    ORDER BY HK_HUB_PERSONAL_INTEREST, MD_START_DT ASC
);
create or replace view VW_LINK_LOAD_PRODUCT_TAG(
	HK_HUB,
	MD_START_DT,
	MD_SOURCE,
	MD_CREATION_AUDIT_ID,
	PRODUCT_ID,
	TAGS
) as
(
       SELECT HK_HUB_PRODUCT AS HK_HUB, 
              MD_START_DT AS MD_START_DT,
              MAX(MD_SOURCE) AS MD_SOURCE,
              MAX(MD_CREATION_AUDIT_ID) AS MD_CREATION_AUDIT_ID,
              MAX(PRODUCT_ID) as PRODUCT_ID,
              ARRAY_TO_STRING(ARRAY_AGG(TAG) WITHIN GROUP (ORDER BY HK_HUB_PRODUCT, MD_START_DT DESC),',') AS TAGS
        FROM PRODUCT_RDV.LINK_PRODUCT_TAG 
    GROUP BY HK_HUB_PRODUCT, MD_START_DT
    ORDER BY HK_HUB_PRODUCT, MD_START_DT ASC
);
create or replace view VW_SAT_LINK_LOAD_PERSONAL_INTEREST_TAG_PLT(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_LINK, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_PRODUCT.PERSONAL_INTEREST_TAG r	
),

SAT_LINK AS
(
	SELECT 	DISTINCT r.HK_LINK, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT_LINK' AS ROW_SRC
	FROM DB_AC_DEV_DWH.PRODUCT_RDV.SAT_LINK_PERSONAL_INTEREST_TAG_PLT r
),

SRC AS
(
	SELECT 	r.HK_LINK, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_LINK order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT_LINK
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.PRODUCT_RDV.SAT_LINK_PERSONAL_INTEREST_TAG_PLT S ON RSLT.HK_LINK = S.HK_LINK AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_LINK IS NULL;
create or replace view VW_SAT_LINK_LOAD_PRODUCT_CATALOG_PRODUCT_PLT(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_LINK, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_PRODUCT.CATALOG_PRODUCT_LIST r	
),

SAT_LINK AS
(
	SELECT 	DISTINCT r.HK_LINK, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT_LINK' AS ROW_SRC
	FROM DB_AC_DEV_DWH.PRODUCT_RDV.SAT_LINK_PRODUCT_CATALOG_PRODUCT_PLT r
),

SRC AS
(
	SELECT 	r.HK_LINK, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_LINK order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT_LINK
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.PRODUCT_RDV.SAT_LINK_PRODUCT_CATALOG_PRODUCT_PLT S ON RSLT.HK_LINK = S.HK_LINK AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_LINK IS NULL;
create or replace view VW_SAT_LOAD_PERSONAL_INTEREST_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_PRODUCT.PERSONAL_INTEREST r
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PERSONAL_INTEREST_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PERSONAL_INTEREST_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_PRODUCT_CATALOG_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_PRODUCT.VW_PRODUCT_CATALOG r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PRODUCT_CATALOG_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PRODUCT_CATALOG_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_PRODUCT_INFO_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_PRODUCT.PRODUCT_INFO r
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PRODUCT_INFO_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PRODUCT_INFO_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace schema PUBLIC;

create or replace schema SHARED_BDV;

create or replace TABLE SAT_INDIVIDUAL_PLT_COMPUTE (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	AGE NUMBER(38,0) COMMENT 'Age of the individual',
	AGE_GROUP VARCHAR(16777216) COMMENT 'Individual age group',
	AGE_GROUP_SORT NUMBER(38,0) COMMENT 'Sort order for the age group'
);
create or replace schema SHARED_RDV;

create or replace TABLE HUB_ADMINISTRATIVE_ENTITIES (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	POSTAL_CODE_ID VARCHAR(16777216) COMMENT 'Column description'
);
create or replace TABLE HUB_CUSTOMER (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform ID'
);
create or replace TABLE HUB_ORGANIZATION (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Worker organization id'
);
create or replace TABLE HUB_PROVIDER (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	PROVIDER_ID VARCHAR(100) COMMENT 'Column description'
);
create or replace TABLE HUB_WORKER (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID'
);
create or replace TABLE REF_ORGANIZATION_STRUCTURE (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	ENTITY_ID VARCHAR(16777216) COMMENT 'id entity'
);
create or replace TABLE SAT_ADMINISTRATIVE_ENTITIES (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	POSTAL_CODE VARCHAR(6),
	POSTAL_CODE_ABBR VARCHAR(3),
	ELECTORAL_DIVISION_CODE VARCHAR(3),
	ELECTORAL_DIVISION VARCHAR(30),
	MUNICIPALITIE_CODE VARCHAR(9),
	MUNICIPALITIE VARCHAR(58),
	MUNICIPALITIE_DESIGNATION_CODE VARCHAR(2),
	MRC_CODE VARCHAR(5),
	MRC VARCHAR(60),
	ADMINISTRATIVE_REGION_CODE VARCHAR(2),
	ADMINISTRATIVE_REGION VARCHAR(60)
);
create or replace TABLE SAT_EMPLOYMENT_INFO_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	HIRE_DATE DATE COMMENT 'Employee hire DATE',
	ORIGINAL_HIRED_DATE DATE COMMENT 'Employee original hired date',
	PROVINCE_OF_EMPLOYMENT VARCHAR(16777216) COMMENT 'Employee Province of employement',
	REMUNERATION_TYPE VARCHAR(16777216) COMMENT 'Employee remuneration type',
	HOURS_PER_WEEK NUMBER(38,2) COMMENT 'Employee hours per week',
	PAY_PERIOD VARCHAR(16777216) COMMENT 'Employee pay periode',
	WORK_PATTERN VARCHAR(16777216) COMMENT 'Employee work pattern',
	JOB_PERMANENCY VARCHAR(16777216) COMMENT 'Employee job permanency',
	JOB_CATEGORY VARCHAR(16777216) COMMENT 'Employee job Category ',
	LOCATION VARCHAR(16777216) COMMENT 'Employee Location',
	IS_MANAGER VARCHAR(16777216) COMMENT 'Employee is a manager'
);
create or replace TABLE SAT_INDIVIDUAL_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MONTH_OF_BIRTH DATE COMMENT 'Month of birth',
	GENDER VARCHAR(16777216) COMMENT 'Individual Gender'
);
create or replace TABLE SAT_LEAVE_STATUS_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	ON_LEAVE VARCHAR(16777216) COMMENT 'On leave predicate',
	LEAVE_START_DATE DATE COMMENT 'Leave start DATE',
	LEAVE_END_DATE DATE COMMENT 'Leave end DATE',
	REASON_CODE VARCHAR(16777216) COMMENT 'Leave reason code'
);
create or replace TABLE SAT_ORGANIZATION_STRUCTURE (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	ENTITY_CODE VARCHAR(16777216) COMMENT 'code of entity',
	ENTITY_NAME_FR VARCHAR(16777216) COMMENT 'description in french',
	ENTITY_NAME_EN VARCHAR(16777216) COMMENT 'description in english',
	ENTITY_TYPE VARCHAR(16777216) COMMENT 'type of entity',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'id of oragnization',
	PARENT_ID VARCHAR(16777216) COMMENT 'parent id of entity'
);
create or replace TABLE SAT_PERSONAL_ADDRESS_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	POSTAL_CODE_PARTIAL VARCHAR(16777216) COMMENT 'Personal address partial postal code ',
	PROVINCE VARCHAR(16777216) COMMENT 'Personal address Province',
	COUNTRY VARCHAR(16777216) COMMENT 'Personal address Counrty'
);
create or replace TABLE SAT_RETIREMENT_STATUS_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	RETIRED VARCHAR(16777216) COMMENT 'Retired predicate',
	RETIREMENT_DATE DATE COMMENT 'Retirement date',
	EXPECTED VARCHAR(16777216) COMMENT 'Retirement expected predicate',
	EXPECTED_RETIREMENT_DATE DATE COMMENT 'Expected retirement date'
);
create or replace TABLE SAT_SALARY_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	SALARY NUMBER(38,2) COMMENT 'Salary',
	SALARY_EFFECTIVE_DATE DATE COMMENT 'Salary effective DATE'
);
create or replace TABLE SAT_TERMINATION_STATUS_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	TERMINATED VARCHAR(16777216) COMMENT 'Terminated predicate',
	TERMINATION_DATE DATE COMMENT 'Termination DATE',
	REASON_CODE VARCHAR(16777216) COMMENT 'Termination reason code'
);
create or replace TABLE SAT_WORKER_PERMIT_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	TYPE VARCHAR(16777216) COMMENT ' Work permit type',
	START_DATE DATE COMMENT 'Work permit start DATE',
	END_DATE DATE COMMENT 'Work permit end DATE'
);
create or replace view VW_SAT_LOAD_EMPLOYMENT_INFO_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHARED.EMPLOYMENT_INFORMATION r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHARED_RDV.SAT_EMPLOYMENT_INFO_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_EMPLOYMENT_INFO_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_INDIVIDUAL_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHARED.INDIVIDUAL r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHARED_RDV.SAT_INDIVIDUAL_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_INDIVIDUAL_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_LEAVE_STATUS_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHARED.LEAVE_STATUS r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHARED_RDV.SAT_LEAVE_STATUS_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_LEAVE_STATUS_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_PERSONAL_ADDRESS_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHARED.PERSONAL_ADDRESS r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHARED_RDV.SAT_PERSONAL_ADDRESS_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_PERSONAL_ADDRESS_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_RETIREMENT_STATUS_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHARED.RETIREMENT_STATUS r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHARED_RDV.SAT_RETIREMENT_STATUS_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_RETIREMENT_STATUS_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_SALARY_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHARED.SALARY r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHARED_RDV.SAT_SALARY_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_SALARY_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_TERMINATION_STATUS_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHARED.TERMINATION_STATUS r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHARED_RDV.SAT_TERMINATION_STATUS_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_TERMINATION_STATUS_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_WORKER_PERMIT_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHARED.WORK_PERMIT r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHARED_RDV.SAT_WORKER_PERMIT_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHARED_RDV.SAT_WORKER_PERMIT_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace schema SHARED_WT_BDV;

create or replace TABLE WT_CAMPAIGN (
	MD_START_DT DATE COMMENT 'Start Date of the image/version'
);
create or replace TABLE WT_SAT_INDIVIDUAL_PLT_COMPUTE (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	AGE NUMBER(38,0) COMMENT 'Age of the individual',
	AGE_GROUP VARCHAR(16777216) COMMENT 'Individual age group',
	AGE_GROUP_SORT NUMBER(38,0) COMMENT 'Sort order for the age group'
);
create or replace TABLE WT_TEMP_SAT_INDIVIDUAL_PLT_COMPUTE (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MONTH_OF_BIRTH DATE COMMENT 'Month of birth',
	AGE_DIFF NUMBER(38,0) COMMENT 'TEMP DATE_DIFF VALUE'
);
create or replace view VW_WT_SAT_INDIVIDUAL_PLT_COMPUTE(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	MD_CREATION_DT,
	MD_SOURCE,
	MD_CREATION_AUDIT_ID,
	AGE,
	AGE_GROUP,
	AGE_GROUP_SORT
) as  (
    
  SELECT 
	HK_HUB ,
	MD_START_DT, 
	SHA1( 
                UPPER(                     
                   NVL(RTRIM(LTRIM(TO_VARCHAR(AGE))),'#NULL#')                    
                   || '|' ||
                   NVL(RTRIM(LTRIM(AGE_GROUP)),'#NULL#')                                                  
                ) 
           )::string AS MD_HASHDIFF, 
	CURRENT_TIMESTAMP AS MD_CREATION_DT,
	MD_SOURCE ,
	MD_CREATION_AUDIT_ID ,
	AGE ,
	AGE_GROUP,
    AGE_GROUP_SORT
  from SHARED_WT_BDV.WT_SAT_INDIVIDUAL_PLT_COMPUTE);
create or replace view VW_WT_TEMP_SAT_INDIVIDUAL_PLT_COMPUTE(
	HK_HUB,
	MD_SOURCE,
	BIRTH_WITH_AGE_DIFF,
	MONTH_OF_BIRTH
) as  (
    
  SELECT 
	HK_HUB ,
	MD_SOURCE ,
	DATEADD(year, AGE_DIFF, MONTH_OF_BIRTH) AS BIRTH_WITH_AGE_DIFF,
    MONTH_OF_BIRTH
  from SHARED_WT_BDV.WT_TEMP_SAT_INDIVIDUAL_PLT_COMPUTE);
CREATE OR REPLACE PROCEDURE "LOADDM_SHARED_RDV_TO_DM_ENROLLMENT_FACT_ENROLLMENT"("ENV" VARCHAR(16777216), "SECURITY_TYPE" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =   "INSERT INTO DB_AC_DEV_DM.ENROLLMENT.FACT_PLATFORM_ENROLLMENT(HK_LINK	, " +	
"MD_START_DT,	" +
"MD_CREATION_DT	,	" +
"MD_CREATION_AUDIT_ID	,	" +
"MD_SECURITY_TYPE,	" +
"MD_SOURCE	," +
"OPEN_SHOPPING_PERIOD_ID	,	" +
"EMPLOYEE_ID	," +
"ORGANIZATION_ID	,	" +
"CAMPAIGN_ID	) " +
"WITH T1 AS (select hK_HUB_CAMPAIGN,DTLS.ID AS EMP_ID,HK_LINK,MSTR.MD_CREATION_DT AS MD_CREATION_DT,MSTR.MD_SOURCE MD_SOURCE,OPEN_SHOPPING_PERIOD_ID,ORGANIZATION_ID " +
 "     from DB_AC_DEV_DWH.ENROLLMENT_RDV.VW_SAT_LINK_ENROLLMENT MSTR JOIN DB_AC_DEV_DM.SHARED.DIM_EMPLOYEE AS DTLS ON HK_HUB = HK_HUB_WORKER WHERE MSTR.MD_CREATION_DT<=SYSDATE()) " +
"SELECT HK_LINK, MSTR.MD_CREATION_DT,SYSTIMESTAMP(), " +
"''" + AUDIT_ID +"''," +
"''" + SECURITY_TYPE +"'',"+
"MSTR.MD_SOURCE,OPEN_SHOPPING_PERIOD_ID, " +
"EMP_ID,MSTR.ORGANIZATION_ID,ID " +
"FROM T1 MSTR JOIN DB_AC_DEV_DM.SHARED.DIM_CAMPAIGN AS DTLS ON HK_HUB = HK_HUB_CAMPAIGN";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADBDV_SHARED_RDV_TO_SHARED_WT_TEMP_BDV_INDIVIDUAL_COMPUTE"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =   "insert into DB_AC_DEV_DWH.shared_WT_BDV.WT_TEMP_SAT_INDIVIDUAL_PLT_COMPUTE(HK_HUB,MD_SOURCE,MONTH_OF_BIRTH,AGE_DIFF) " +
 "select MSTR.HK_HUB,MD_SOURCE,MONTH_OF_BIRTH,DATEDIFF(year,''"+ IO_START_DT  + "''::date,MONTH_OF_BIRTH::date) AS AGE_DIFF " +
 "from DB_AC_DEV_DWH.shared_rdv.SAT_INDIVIDUAL_PLT as mstr join " +
"(select HK_HUB,max(md_start_dt) as max_md_start_dt from  DB_AC_DEV_DWH.shared_rdv.SAT_INDIVIDUAL_PLT where MD_START_DT <= TO_DATE(''"+ IO_START_DT  + "'',''YYYY-MM-DD'') group by HK_HUB) " +
" as dtls on mstr.HK_HUB = dtls.hk_HUB and mstr.md_start_dt = dtls.max_md_start_dt ";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADBDV_TEMP_WT_BDV_TO_ENROLLMENT_WT_BDV_ENROLLMENT_COMPUTE"("ENV" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY = "INSERT INTO DB_AC_DEV_DWH.SHARED_WT_BDV.WT_TEMP_SAT_ENROLLMENT_COMPUTE(HK_HUB, " +
"MD_START_DT	," +
"MD_CREATION_DT	,	" +
"MD_SOURCE	,	" +
"MD_CREATION_AUDIT_ID	,	" +
"LOCATION		," +
"ISPOPULATION	,	" +
"ISONCAMPAIGN	,	" +
"ISONGLOBALCAMPAIGN	," +
"ISONLEAVE		," +
"ISNEWHIRE		," +
"ISELIGIBLEREENROLMENT		, " +
"ISELIGIBLEGLOBALREENROLMENT		," +
"ISONLEAVERETURN )" +
"SELECT " +
"HK_HUB	," +
"MD_START_DT	," +
"SYSTIMESTAMP()	," +
"MD_SOURCE,''		" +
AUDIT_ID +
"'',LOCATION,	" +	
"ISPOPULATION,		" +
"ISONCAMPAIGN, " +
"ISONGLOBALCAMPAIGN	, " +
"ISONLEAVE	,	" +
"ISNEWHIRE	,	" +
"ISELIGIBLEREENROLMENT,	" +	
"ISELIGIBLEGLOBALREENROLMENT,	" +	
"ISONLEAVERETURN	" +
"FROM DB_AC_DEV_DWH.SHARED_WT_BDV.VW_WT_TEMP_SAT_ENROLLMENT_COMPUTE " ;
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADBDV_TEMP_WT_BDV_TO_SHARED_WT_BDV_INDIVIDUAL_COMPUTE"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =   "insert into DB_AC_DEV_DWH.SHARED_WT_BDV.WT_SAT_INDIVIDUAL_PLT_COMPUTE( " +
"HK_HUB	, " +
"MD_START_DT	, " +
"MD_CREATION_DT,	" +	
"MD_SOURCE		, " +
"MD_CREATION_AUDIT_ID,	" +	
"AGE	," +
"AGE_GROUP	," +
"AGE_GROUP_SORT	)" +
"select " +
"HK_HUB,	" +
"TO_DATE(''"+ IO_START_DT  + "'',''YYYY-MM-DD'')," +
"SYSTIMESTAMP()	," +
"MD_SOURCE	," +
"''" + AUDIT_ID + "''," +
"BUSINESS_RULES.SHARED_Clients.UDF_CONV_BR_TBP_CUSTOMER_Age_segmentation_001(MONTH_OF_BIRTH,TO_DATE(''"+ IO_START_DT  + "'',''YYYY-MM-DD''),BIRTH_WITH_AGE_DIFF)[''o_AGE''],	" +
"BUSINESS_RULES.SHARED_Clients.UDF_CONV_BR_TBP_CUSTOMER_Age_segmentation_001(MONTH_OF_BIRTH,TO_DATE(''"+ IO_START_DT  + "'',''YYYY-MM-DD''),BIRTH_WITH_AGE_DIFF)[''o_AGE_GROUP'']," +
"BUSINESS_RULES.SHARED_Clients.UDF_CONV_BR_TBP_CUSTOMER_Age_segmentation_001(MONTH_OF_BIRTH,TO_DATE(''"+ IO_START_DT  + "'',''YYYY-MM-DD''),BIRTH_WITH_AGE_DIFF)[''o_AGE_GROUP_SORT''] " +
"from DB_AC_DEV_DWH.SHARED_WT_BDV.VW_WT_TEMP_SAT_INDIVIDUAL_PLT_COMPUTE";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADBDV_TOOLS_AUDIT_TO_SHARED_WT_BDV_WT_CAMPAIGN"("ENV" VARCHAR(16777216), "JOB_NAME" VARCHAR(16777216))
RETURNS VARIANT
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
INS_QUERY = "INSERT INTO DB_AC_DEV_DWH.SHARED_WT_BDV.WT_CAMPAIGN(MD_START_DT) SELECT TO_DATE(MAX(DATA_START_DT)) as MD_START_DT " +
"FROM DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS " +
"WHERE JOB_STATUS IS NOT NULL AND JOB_NAME = ''"+ JOB_NAME + "'' " +
"GROUP BY JOB_NAME"
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_PRODUCT_RDV_TO_DM_PRODUCT_WT_DIM_PERSONAL_INTEREST"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "AUDIT_ID" VARCHAR(16777216), "SECURITY_TYPE" VARCHAR(16777216), "MD_SORUCE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
DEL_QUERY =  "DELETE FROM DB_AC_DEV_DM.PRODUCT_WT.WT_DIM_PERSONAL_INTEREST WHERE 1=1";
var DEL_QUERY_ENV = DEL_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement1 = snowflake.createStatement({
  sqlText: DEL_QUERY_ENV
});
var result2_scan = sql_statement1.execute(); 
INS_QUERY =   "INSERT INTO DB_AC_DEV_DM.PRODUCT_WT.WT_DIM_PERSONAL_INTEREST( " +
"HK_HUB,	" +
"MD_START_DT,	" +
"MD_CREATION_DT,	" +	
"MD_MODIFY_DT,		" +
"MD_SOURCE,		" +
"MD_CREATION_AUDIT_ID," +		
"MD_MODIFY_AUDIT_ID,	" +
"MD_SECURITY_TYPE,	" +
"PERSONAL_INTEREST_ID,	" +
"NAME_FR	," +
"NAME_EN,	" +
"TAGS	)" +
"WITH T1 AS(select MSTR.HK_HUB AS SAT_HK_HUB,MSTR.INTEREST_ID AS SAT_INTERST_ID,MSTR.NAME_FR AS NAME_FR, MSTR.NAME_EN AS NAME_EN from " + 
" DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PERSONAL_INTEREST_PLT MSTR JOIN ( " +
"  select HK_HUB,max(md_start_dt) as max_md_start_dt from  DB_AC_DEV_DWH.PRODUCT_RDV.SAT_PERSONAL_INTEREST_PLT where MD_START_DT <= " +
" TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_HUB) as dtls " +
"  on mstr.HK_HUB = dtls.hk_HUB and mstr.md_start_dt = dtls.max_md_start_dt), " +
"  T2 AS(SELECT * FROM DB_AC_DEV_DWH.PRODUCT_RDV.HUB_PERSONAL_INTEREST AS MSTR LEFT OUTER JOIN T1 ON MSTR.HK_HUB = SAT_HK_HUB), " +
"  T3 AS(select MSTR.HK_HUB AS S_HK_HUB,MSTR.TAGS AS TAGS from DB_AC_DEV_DWH.PRODUCT_RDV.VW_LINK_LOAD_PERSONAL_INTEREST_TAG MSTR JOIN ( " +
"  select HK_HUB,max(md_start_dt) as max_md_start_dt from  DB_AC_DEV_DWH.PRODUCT_RDV.VW_LINK_LOAD_PERSONAL_INTEREST_TAG " + 
" where MD_START_DT <= " +
" TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD'') group by HK_HUB) as dtls " +
"  on mstr.HK_HUB = dtls.hk_HUB and mstr.md_start_dt = dtls.max_md_start_dt) " +
"  SELECT SAT_HK_HUB,  " +
"''" + IO_START_DT + "''," +
"  SYSTIMESTAMP(), " +
"  SYSTIMESTAMP(), " +
"''" + MD_SORUCE + "''," +
"''" + AUDIT_ID + "''," +
"''" + AUDIT_ID + "''," +
"''" + SECURITY_TYPE + "''," +
"  SAT_INTERST_ID, " +
"  NAME_FR, " +
"  NAME_EN, " +
"  TAGS " +
"   FROM T2 LEFT OUTER JOIN T3 ON S_HK_HUB = Hk_HUB ";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
create or replace schema SHOPPING_RDV;

create or replace TABLE HUB_CAMPAIGN (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	CAMPAIGN_ID VARCHAR(16777216) COMMENT 'Platform Shopping Request Id'
);
create or replace TABLE HUB_OPEN_SHOPPING_PERIOD (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	OPEN_SHOPPING_PERIOD_ID NUMBER(38,0) COMMENT 'Open Shopping Period Id from platform'
);
create or replace TABLE HUB_ORDER (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	ORDER_ID VARCHAR(100) COMMENT 'Platform Order Id'
);
create or replace TABLE HUB_SHOPPING_REQUEST (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	SHOPPING_REQUEST_ID VARCHAR(100) COMMENT 'Platform Shopping Request Id'
);
create or replace TABLE LINK_ORDER_CUSTOMER (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HkHub of the customer',
	HK_HUB_ORDER VARCHAR(16777216) COMMENT 'HkHub of the order',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Platform customer ID that made the shopping request',
	ORDER_ID VARCHAR(16777216) COMMENT 'Order Id from the platform'
);
create or replace TABLE LINK_ORDER_ITEM (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_ORDER VARCHAR(16777216) COMMENT 'HkHub of the order',
	HK_HUB_PRODUCT VARCHAR(16777216) COMMENT 'HkHub of the product',
	ORDER_ID VARCHAR(16777216) COMMENT 'Order Id from the platform',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Platform Product Id'
);
create or replace TABLE LINK_SHOPPING_CUSTOMER (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HkHub of the customer',
	HK_HUB_SHOPPING_REQUEST VARCHAR(16777216) COMMENT 'HkHub of the shopping request',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Platform customer ID that made the shopping request',
	SHOPPING_REQUEST_ID VARCHAR(16777216) COMMENT 'Shopping Request Id from the platform'
);
create or replace TABLE LINK_SHOPPING_ITEM (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_SHOPPING_REQUEST VARCHAR(16777216) COMMENT 'HkHub of the shopping request',
	HK_HUB_PRODUCT VARCHAR(16777216) COMMENT 'HkHub of the product',
	SHOPPING_REQUEST_ID VARCHAR(16777216) COMMENT 'Shopping Request Id from the platform',
	PRODUCT_ID VARCHAR(16777216) COMMENT 'Platform Product Id'
);
create or replace TABLE LINK_SHOPPING_REQUESTS (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_PRODUCT_CATALOG VARCHAR(16777216) COMMENT 'Product Catalog Key',
	HK_HUB_OPEN_SHOPPING_PERIOD VARCHAR(16777216) COMMENT 'Open shopping period key',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HkHub of the customer',
	HK_HUB_WORKER VARCHAR(16777216) COMMENT 'worker key',
	HK_HUB_SHOPPING_REQUEST VARCHAR(16777216) COMMENT 'HkHub of the shopping request',
	SHOPPING_REQUEST_ID VARCHAR(16777216) COMMENT 'Shopping Request id',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Platform customer ID that made the shopping request',
	WORKER_ID VARCHAR(16777216) COMMENT 'Platform worker id',
	OPEN_SHOPPING_PERIOD_ID VARCHAR(16777216) COMMENT 'Platform open shopping period id',
	PRODUCT_CATALOG_ID VARCHAR(16777216) COMMENT 'platform product catalog id'
);
create or replace TABLE SAT_CAMPAIGN (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	TYPE VARCHAR(16777216) COMMENT 'Campaign Type',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Name of the organisation',
	WORKER_GROUP VARCHAR(16777216) COMMENT 'Name of worker group',
	JOB_CATEGORY VARCHAR(16777216) COMMENT 'the name of job category',
	GROUP_TYPE_CODE VARCHAR(16777216) COMMENT 'group type code',
	GROUP_REFERENCES VARCHAR(16777216) COMMENT ' group references',
	SCHEDULED_TIME TIME(7),
	BEGINS_ON TIMESTAMP_NTZ(9) COMMENT 'campaign start date',
	ENDS_ON TIMESTAMP_NTZ(9) COMMENT 'campaign end date',
	BENEFITS_EFFECTIVE_DATE DATE COMMENT 'The date on which benefits will start',
	ELIGIBILITY_RULE_SET VARCHAR(16777216) COMMENT 'rule for eligibility of the benefits',
	IS_STARTED BOOLEAN COMMENT 'campaign is on way or not'
);
create or replace TABLE SAT_LINK_ORDER_ITEM_PLT (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	QUANTITY NUMBER(38,0) COMMENT 'Selected product quantity ',
	AMOUNT NUMBER(14,2) COMMENT 'Product amount'
);
create or replace TABLE SAT_LINK_SHOPPING_ITEM_PLT (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	QUANTITY NUMBER(38,0) COMMENT 'Selected product quantity'
);
create or replace TABLE SAT_OPEN_SHOPPING_PERIOD (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	REASON VARCHAR(255) COMMENT 'reason why the item was created',
	BEGINSON DATE COMMENT 'begin date of the item',
	ENDSON DATE COMMENT 'end date of the item',
	EFFECTIVE_DATE DATE COMMENT 'Effective date of the item',
	EXPIRATION_DATE DATE COMMENT 'Expiration date of the item',
	STATUS VARCHAR(255) COMMENT 'status of the current item'
);
create or replace TABLE SAT_ORDER_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	CREATION_DATE TIMESTAMP_NTZ(9) COMMENT 'The creation date of the order',
	AMOUNT NUMBER(14,2) COMMENT 'Total amount of the Order',
	AMOUNT_AFTER_TAX NUMBER(14,2) COMMENT 'Total amount of the Order including taxes'
);
create or replace TABLE SAT_ORDER_STATUS_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	STATUS VARCHAR(16777216) COMMENT 'Order status',
	STATUS_DATE TIMESTAMP_NTZ(9) COMMENT 'Order status DATE'
);
create or replace TABLE SAT_SHOPPING_REQUEST_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	CREATION_DATE TIMESTAMP_NTZ(9) COMMENT 'The creation date of the shopping request in the platform',
	STATUS VARCHAR(50) COMMENT 'The current status of the shopping request',
	SUBMITTEDON DATE COMMENT 'Date of request',
	CONTEXT VARCHAR(16777216)
);
create or replace view VW_SAT_LINK_LOAD_ORDER_ITEM_PLT(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_LINK, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHOPPING.ORDER_ITEM r	
),

SAT_LINK AS
(
	SELECT 	DISTINCT r.HK_LINK, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT_LINK' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_ORDER_ITEM_PLT r
),

SRC AS
(
	SELECT 	r.HK_LINK, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_LINK order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT_LINK
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_ORDER_ITEM_PLT S ON RSLT.HK_LINK = S.HK_LINK AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_LINK IS NULL;
create or replace view VW_SAT_LINK_LOAD_SHOPPING_ITEM_PLT(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_LINK, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHOPPING.SHOPPING_REQUEST_ITEM r	
),

SAT_LINK AS
(
	SELECT 	DISTINCT r.HK_LINK, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT_LINK' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_SHOPPING_ITEM_PLT r
),

SRC AS
(
	SELECT 	r.HK_LINK, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_LINK order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT_LINK
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHOPPING_RDV.SAT_LINK_SHOPPING_ITEM_PLT S ON RSLT.HK_LINK = S.HK_LINK AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_LINK IS NULL;
create or replace view VW_SAT_LOAD_CAMPAIGN(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as 

WITH STG AS 
(
SELECT DISTINCT c.HK_HUB, c.MD_START_DT, c.MD_HASHDIFF, 'STG' AS ROW_SRC
FROM  DB_AC_DEV_STG.PLT_MODEL_SHOPPING.CAMPAIGN c
),
SAT AS (
SELECT DISTINCT c.HK_HUB, 
			LAST_VALUE(c.MD_START_DT) over (partition by c.HK_HUB order by c.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(c.MD_HASHDIFF) over (partition by c.HK_HUB order by c.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
FROM DB_AC_DEV_DWH.SHOPPING_RDV.SAT_CAMPAIGN c
),
SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)
SELECT RSLT.* 
FROM RSLT 
LEFT JOIN DB_AC_DEV_DWH.SHOPPING_RDV.SAT_CAMPAIGN S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_OPEN_SHOPPING_PERIOD(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as 

WITH STG AS 
(
SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
FROM  DB_AC_DEV_STG.PLT_MODEL_SHOPPING.OPEN_SHOPPING_PERIOD r
),
SAT AS (
SELECT DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
FROM DB_AC_DEV_DWH.SHOPPING_RDV.SAT_OPEN_SHOPPING_PERIOD r
),
SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)
SELECT RSLT.* 
FROM RSLT 
LEFT JOIN DB_AC_DEV_DWH.SHOPPING_RDV.SAT_OPEN_SHOPPING_PERIOD S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_ORDER_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHOPPING.VW_ORDER r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_ORDER_STATUS_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as


WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHOPPING.ORDER_STATUS r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_STATUS_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHOPPING_RDV.SAT_ORDER_STATUS_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace view VW_SAT_LOAD_SHOPPING_REQUEST_PLT(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB_SHOPPING_REQUEST AS HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SHOPPING.SHOPPING_REQUEST r	
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SHOPPING_RDV.SAT_SHOPPING_REQUEST_PLT r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SHOPPING_RDV.SAT_SHOPPING_REQUEST_PLT S ON RSLT.HK_HUB = S.HK_HUB AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_HUB IS NULL;
create or replace schema SUBSCRIPTION_RDV;

create or replace TABLE LINK_CUSTOMER_PERSONAL_INTEREST (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HASH of the customer business key',
	HK_HUB_PERSONAL_INTEREST VARCHAR(16777216) COMMENT 'HASH of the personal interest business key',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Customer plateform ID',
	INTEREST_ID VARCHAR(16777216) COMMENT 'Interest plateform ID ',
	MD_START_DT TIMESTAMP_NTZ(9)
);
create or replace TABLE LINK_SUBSCRIPTION (
	HK_LINK VARCHAR(16777216) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(16777216) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_CREATION_AUDIT_ID VARCHAR(16777216) COMMENT 'Task execution ID',
	HK_HUB_WORKER VARCHAR(16777216) COMMENT 'HASH of the worker business key',
	HK_HUB_CUSTOMER VARCHAR(16777216) COMMENT 'HASH of the cvustomer business key',
	HK_HUB_ORGANIZATION VARCHAR(16777216) COMMENT 'HASH of the organization business key',
	WORKER_ID VARCHAR(16777216) COMMENT 'Worker plateform ID',
	CUSTOMER_ID VARCHAR(16777216) COMMENT 'Worker Customer id',
	ORGANIZATION_ID VARCHAR(16777216) COMMENT 'Worker organization id'
);
create or replace TABLE SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT (
	HK_LINK VARCHAR(64) COMMENT 'Hash key for the Link',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID'
);
create or replace view VW_SAT_LINK_LOAD_CUSTOMER_PERSONAL_INTEREST_PLT(
	HK_LINK,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_LINK, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.PLT_MODEL_SUBSCRIPTION.CUSTOMER_PERSONAL_INTEREST r	
),

SAT_LINK AS
(
	SELECT 	DISTINCT r.HK_LINK, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_LINK order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT_LINK' AS ROW_SRC
	FROM DB_AC_DEV_DWH.SUBSCRIPTION_RDV.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT r
),

SRC AS
(
	SELECT 	r.HK_LINK, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_LINK order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT_LINK
		UNION  
		SELECT * FROM STG
	) AS r
),

RSLT AS
(
  SELECT * 
  FROM SRC r
  WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF 
)

SELECT RSLT.* 
FROM RSLT
LEFT JOIN DB_AC_DEV_DWH.SUBSCRIPTION_RDV.SAT_LINK_CUSTOMER_PERSONAL_INTEREST_PLT S ON RSLT.HK_LINK = S.HK_LINK AND RSLT.MD_START_DT = S.MD_START_DT
WHERE S.HK_LINK IS NULL;
create or replace schema TOOLS;

create or replace TABLE AUDIT_JOBS_DEPENDENCIES (
	DEPENDANT_JOB_NAME VARCHAR(1000) COMMENT 'Dpenedant Taskflow name',
	DEPENDANT_DATA_START_DT DATE COMMENT 'Functional start Load date',
	DEPENDANT_DATA_NEXT_START_DT DATE COMMENT 'Functional next start Load date',
	PRINCIPAL_JOB_NAME_PATTERN VARCHAR(1000) COMMENT 'Principal Taskflow name LIKE pattern is supported',
	PRINCIPAL_DATA_START_DT DATE COMMENT 'Functional start Load date',
	PRINCIPAL_DATA_NEXT_START_DT DATE COMMENT 'Functional end Load date',
	DEPENDENCY_TYPE VARCHAR(100) COMMENT 'PREREQUISITE, CONCURRENT, ...'
);
create or replace TABLE AUDIT_JOBS_EXECUTIONS (
	JOB_NAME VARCHAR(1000) COMMENT 'Taskflow name',
	DATA_START_DT DATE COMMENT 'Functional start Load date',
	DATA_NEXT_START_DT DATE COMMENT 'Functional next start Load date',
	UPDATE_JOB_AUDIT_ID VARCHAR(1000) COMMENT 'Taskflow job ID that updated this record',
	JOB_STATUS VARCHAR(100) COMMENT 'IN PROGRESS, SUCCESS, ERROR',
	JOB_STATUS_DESC VARCHAR(16777216) COMMENT 'Description for the current status',
	JOB_ACTION_RESULT VARCHAR(100) COMMENT 'Last start or end job result',
	JOB_DATA_START_DT_RESULT DATE COMMENT 'start Load date returned from an action on the audit. Example : Start next date'
);
create or replace TABLE AUDIT_JOBS_EXECUTIONS_BKPDT (
	JOB_NAME VARCHAR(1000) COMMENT 'Taskflow name',
	DATA_START_DT DATE COMMENT 'Functional start Load date',
	DATA_NEXT_START_DT DATE COMMENT 'Functional next start Load date',
	UPDATE_JOB_AUDIT_ID VARCHAR(1000) COMMENT 'Taskflow job ID that updated this record',
	JOB_STATUS VARCHAR(100) COMMENT 'IN PROGRESS, SUCCESS, ERROR',
	JOB_STATUS_DESC VARCHAR(16777216) COMMENT 'Description for the current status',
	JOB_ACTION_RESULT VARCHAR(100) COMMENT 'Last start or end job result'
);
create or replace TABLE ENTITY_TYPES_COLUMNS_PATTERNS (
	COLUMN_ID VARCHAR(500) COMMENT 'HKHUB, HKLINK, MD_CREATION_DATE,...',
	COLUMN_ORDER NUMBER(38,0) COMMENT 'Order of the column in the entity',
	ENTITY_TYPE_ID VARCHAR(500) COMMENT 'HUB, SAT_WITH_ACTIVE_FLAG, LINK, ...',
	COLUMN_TYPE VARCHAR(500) COMMENT 'HASHKEY, METADATA,...',
	COLUMN_NAME_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the column name',
	COLUMN_TYPE_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the colmun type',
	COLUMN_OPTIONS_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the column options',
	COLUMN_COMMENTS_PATTERN VARCHAR(1000) COMMENT 'Pattern to build colomn comments',
	COLUMN_DESC VARCHAR(4000) COMMENT 'Column description'
);
create or replace TABLE ENTITY_TYPES_PATTERNS (
	ENTITY_TYPE_ID VARCHAR(500) COMMENT 'HUB, SAT_WITH_ACTIVE_FLAG, LINK, ...',
	ENTITY_CATEGORY VARCHAR(500) COMMENT 'STAGING, DATAVAULT,...',
	ENTITY_TYPE_NAME_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the table name',
	ENTITY_OPTIONS_PATTERN VARCHAR(1000) COMMENT 'Pattern to build the table options',
	ENTITY_DESC VARCHAR(4000) COMMENT 'Entity type description'
);
create or replace TABLE SAT_INDIVIDUAL_PLT (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MONTH_OF_BIRTH DATE COMMENT 'Month of birth',
	GENDER VARCHAR(16777216) COMMENT 'Individual Gender'
);
create or replace TABLE SAT_TEST_MULTI_R (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MONTH_OF_BIRTH DATE COMMENT 'Month of birth',
	GENDER VARCHAR(16777216) COMMENT 'Individual Gender'
);
create or replace TABLE SAT_TEST_MULTI_R_D (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MONTH_OF_BIRTH DATE COMMENT 'Month of birth',
	GENDER VARCHAR(16777216) COMMENT 'Individual Gender'
);
create or replace TABLE TEST_ENV_DWH (
	TEXT_TEST VARIANT COMMENT 'colonne de test'
);
create or replace view VW_SAT_TEST_MULTI_R(
	HK_HUB,
	MD_START_DT,
	MD_HASHDIFF,
	PREVIOUS_HASHDIFF,
	ROW_SRC
) as
WITH STG AS 
(
	SELECT DISTINCT r.HK_HUB, r.MD_START_DT, r.MD_HASHDIFF, 'STG' AS ROW_SRC
	FROM DB_AC_DEV_STG.TOOLS.TEST_MULTI_R r
	WHERE r.MD_RESERVED = TRUE
),

SAT AS
(
	SELECT 	DISTINCT r.HK_HUB, 
			LAST_VALUE(r.MD_START_DT) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_START_DT,
			LAST_VALUE(r.MD_HASHDIFF) over (partition by r.HK_HUB order by r.MD_START_DT asc) AS MD_HASHDIFF,
			'SAT' AS ROW_SRC
	FROM DB_AC_DEV_DWH.TOOLS.SAT_TEST_MULTI_R r
),

SRC AS
(
	SELECT 	r.HK_HUB, 
			r.MD_START_DT, 
			r.MD_HASHDIFF, 
			lag(r.MD_HASHDIFF, 1, '0') over (partition by r.HK_HUB order by r.MD_START_DT asc) AS PREVIOUS_HASHDIFF,
			r.ROW_SRC
	FROM 
	(
		SELECT * FROM SAT
		UNION  
		SELECT * FROM STG
	) AS r
)

SELECT * 
FROM SRC r
WHERE r.MD_HASHDIFF <> r.PREVIOUS_HASHDIFF;
CREATE OR REPLACE PROCEDURE "AUDIT_ENDJOB_FORDATE_DATETIME"("ENV" VARCHAR(16777216), "JOB_END_STATUS" VARCHAR(20), "JOB_START_DT" VARCHAR(20), "AUDIT_ID" VARCHAR(16777216), "JOB_END_DESC" VARCHAR(16777216), "JOB_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var UPD_QUERY = "UPDATE DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS SET " +
"UPDATE_JOB_AUDIT_ID = ''" + AUDIT_ID + "'', " +
"JOB_STATUS = DECODE(TRUE, " +
"JOB_STATUS = ''IN PROGRESS'', ''" + JOB_END_STATUS + "'', "+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS, "+
"''ERROR_FATAL_01'' "+
"), "+
"JOB_STATUS_DESC = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB '' || ''" + JOB_END_STATUS + "'' || '' : '' || ''" + JOB_END_DESC + "'',"+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB ERROR_01 : Job is not running <'' || JOB_STATUS || ''>'',"+
"''ERROR_FATAL_01''"+
"),"+
"JOB_ACTION_RESULT = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', ''SUCCESS'',"+
"JOB_STATUS <> ''IN PROGRESS'', ''ERROR_01'',"+
"''ERROR_FATAL_01''"+
")) WHERE JOB_NAME =  ''" + JOB_NAME + "''  AND DATA_START_DT=TO_DATE(''" + JOB_START_DT + "'',''YYYY-MM-DD'')";
  var UPD_QUERY_ENV = UPD_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: UPD_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
 ';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_ENDJOB_FORDATE_DATETIME"("ENV" VARCHAR(16777216), "JOB_END_STATUS" VARCHAR(20), "JOB_START_DT" VARCHAR(20), "AUDIT_ID" VARCHAR(16777216), "JOB_END_DESC" VARCHAR(16777216), "JOB_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var UPD_QUERY = "UPDATE DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS SET " +
"UPDATE_JOB_AUDIT_ID = ''" + AUDIT_ID + "'', " +
"JOB_STATUS = DECODE(TRUE, " +
"JOB_STATUS = ''IN PROGRESS'', ''" + JOB_END_STATUS + "'', "+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS, "+
"''ERROR_FATAL_01'' "+
"), "+
"JOB_STATUS_DESC = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB '' || ''" + JOB_END_STATUS + "'' || '' : '' || ''" + JOB_END_DESC + "'',"+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB ERROR_01 : Job is not running <'' || JOB_STATUS || ''>'',"+
"''ERROR_FATAL_01''"+
"),"+
"JOB_ACTION_RESULT = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', ''SUCCESS'',"+
"JOB_STATUS <> ''IN PROGRESS'', ''ERROR_01'',"+
"''ERROR_FATAL_01''"+
") WHERE JOB_NAME =  ''" + JOB_NAME + "''  AND DATA_START_DT=TO_DATE(''" + JOB_START_DT + "'',''YYYY-MM-DD'')";
  var UPD_QUERY_ENV = UPD_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: UPD_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
 return  UPD_QUERY
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_ENDJOB_FORDATE_DATETIME"("ENV" VARCHAR(16777216), "JOB_END_STATUS" VARCHAR(20), "JOB_START_DT" VARCHAR(20), "AUDIT_ID" VARCHAR(16777216), "JOB_END_DESC" VARCHAR(16777216), "JOB_NAME" VARCHAR(16777216), "IO_RESULT" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var UPD_QUERY = "UPDATE DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS SET " +
"UPDATE_JOB_AUDIT_ID = ''" + AUDIT_ID + "'', " +
"JOB_STATUS = DECODE(TRUE, " +
"JOB_STATUS = ''IN PROGRESS'', ''" + JOB_END_STATUS + "'', "+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS, "+
"''ERROR_FATAL_01'' "+
"), "+
"JOB_STATUS_DESC = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB '' || ''" + JOB_END_STATUS + "'' || '' : '' || ''" + JOB_END_DESC + "'',"+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB ERROR_01 : Job is not running <'' || JOB_STATUS || ''>'',"+
"''ERROR_FATAL_01''"+
"),"+
"JOB_ACTION_RESULT = GREATEST(''" + IO_RESULT + "'',DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', ''SUCCESS'',"+
"JOB_STATUS <> ''IN PROGRESS'', ''ERROR_01'',"+
"''ERROR_FATAL_01''"+
")) WHERE JOB_NAME =  ''" + JOB_NAME + "''  AND DATA_START_DT=TO_DATE(''" + JOB_START_DT + "'',''YYYY-MM-DD'')";
  var UPD_QUERY_ENV = UPD_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: UPD_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_ENDJOB_FORDATE_DATETIME"("ENV" VARCHAR(2000), "S_AUDIT_JOB_EXECUTIONS_CURRENT" VARCHAR(2000), "T_AUDIT_JOB_EXECUTIONS_UPDATE" VARCHAR(2000), "I_FIELDMAPPING" VARCHAR(2000))
RETURNS VARCHAR(2000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var mapping_json = JSON.parse(I_FIELDMAPPING);
//var mapping_json = I_FIELDMAPPING;
tgt_columns=Object.keys(mapping_json).join()
return tgt_columns;
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_DWH.TOOLS."+T_AUDIT_JOB_EXECUTIONS_UPDATE+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_DWH.TOOLS."+S_AUDIT_JOB_EXECUTIONS_CURRENT;
//return sql_command;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_ENDJOB_FORDATE_DATETIME"("ENV" VARCHAR(2000), "S_AUDIT_JOB_EXECUTIONS_CURRENT" VARCHAR(2000), "T_AUDIT_JOB_EXECUTIONS_UPDATE" VARCHAR(2000), "I_FIELDMAPPING" VARCHAR(2000), "I_JOB_AUDIT_ID" VARCHAR(2000))
RETURNS VARCHAR(2000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var mapping_json = I_FIELDMAPPING;
//var mapping_json = I_FIELDMAPPING;
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_DWH.TOOLS."+T_AUDIT_JOB_EXECUTIONS_UPDATE+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_DWH.TOOLS."+S_AUDIT_JOB_EXECUTIONS_CURRENT;
return sql_command;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_ENDJOB_FORDATE_DATETIME"("ENV" VARCHAR(1000), "S_AUDIT_JOB_EXECUTIONS_CURRENT" VARCHAR(1000), "T_AUDIT_JOB_EXECUTIONS_UPDATE" VARCHAR(1000), "I_JOB_AUDIT_ID" VARCHAR(1000), "I_JOB_END_DESC" VARCHAR(1000), "I_JOB_END_STATUS" VARCHAR(1000), "I_JOB_NAME" VARCHAR(1000), "I_FIELDMAPPING" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(i_FieldMapping);
//var mapping_json =i_FieldMapping;
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_DWH.TOOLS."+t_AUDIT_JOB_EXECUTIONS_Update+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_DWH.TOOLS."+s_AUDIT_JOB_EXECUTIONS_Current;

try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_ENDJOB_FORDATE_DATETIME_PS"("ENV" VARCHAR(16777216), "S_AUDIT_JOB_EXECUTIONS_CURRENT" VARCHAR(1000), "T_AUDIT_JOB_EXECUTIONS_UPDATE" VARCHAR(1000), "I_JOB_END_STATUS" VARCHAR(1000), "I_JOB_AUDIT_ID" VARCHAR(1000), "I_JOB_END_DESC" VARCHAR(1000), "I_JOB_NAME" VARCHAR(1000), "I_FIELDMAPPING" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_FIELDMAPPING);
//var mapping_json =I_FIELDMAPPING;
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()

var SQL_COMMAND = "INSERT INTO DB_AC_"+ENV+"_DWH.TOOLS."+T_AUDIT_JOB_EXECUTIONS_UPDATE+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_DWH.TOOLS."+S_AUDIT_JOB_EXECUTIONS_CURRENT;

var UPD_QUERY = "UPDATE DB_AC_"+ENV+"_DWH.TOOLS."+T_AUDIT_JOB_EXECUTIONS_UPDATE+" SET " +"UPDATE_JOB_AUDIT_ID = ''" + I_JOB_AUDIT_ID + "'', " +
"JOB_STATUS = DECODE(TRUE, " +
"JOB_STATUS = ''IN PROGRESS'', ''" + I_JOB_END_STATUS + "'', "+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS, "+
"''''ERROR_FATAL_01'''' "+
"), "+
"JOB_STATUS_DESC = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB '' || ''" + I_JOB_END_STATUS + "'' || '' : '' || ''" + I_JOB_END_DESC + "'',"+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB ERROR_01 : Job is not running <'' || JOB_STATUS || ''>'',"+
"''ERROR_FATAL_01''"+
"),"+
"JOB_ACTION_RESULT = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', ''SUCCESS'',"+
"JOB_STATUS <> ''IN PROGRESS'', ''ERROR_01'',"+
"''ERROR_FATAL_01''"+
")) WHERE I_JOB_NAME =  ''" + I_JOB_NAME + "'')";
  
var sql_statement1 = snowflake.createStatement({sqlText: SQL_COMMAND });
var result2_scan = sql_statement1.execute(); 
 
var sql_statement2 = snowflake.createStatement({sqlText: UPD_QUERY });
var result2_scan = sql_statement2.execute(); 

var sql_statement2 = snowflake.createStatement({sqlText: UPD_QUERY });
var result2_scan = sql_statement2.execute(); 

 ';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_ENDJOB_FORDATE_DATETIME_PS"("ENV" VARCHAR(16777216), "S_AUDIT_JOB_EXECUTIONS_CURRENT" VARCHAR(1000), "T_AUDIT_JOB_EXECUTIONS_UPDATE" VARCHAR(1000), "I_JOB_END_STATUS" VARCHAR(1000), "JOB_START_DT" VARCHAR(1000), "I_JOB_AUDIT_ID" VARCHAR(1000), "I_JOB_END_DESC" VARCHAR(1000), "I_JOB_NAME" VARCHAR(1000), "I_FIELDMAPPING" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(i_FieldMapping);
//var mapping_json =i_FieldMapping;
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()

var SQL_COMMAND = "INSERT INTO DB_AC_"+ENV+"_DWH.TOOLS."+T_AUDIT_JOB_EXECUTIONS_UPDATE+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_DWH.TOOLS."+S_AUDIT_JOB_EXECUTIONS_CURRENT;

var UPD_QUERY = "UPDATE DB_AC_"+ENV+"_DWH.TOOLS."+T_AUDIT_JOB_EXECUTIONS_UPDATE+" SET " +"UPDATE_JOB_AUDIT_ID = ''" + I_JOB_AUDIT_ID + "'', " +
"JOB_STATUS = DECODE(TRUE, " +
"JOB_STATUS = ''IN PROGRESS'', ''" + I_JOB_END_STATUS + "'', "+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS, "+
"''''ERROR_FATAL_01'''' "+
"), "+
"JOB_STATUS_DESC = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB '' || ''" + I_JOB_END_STATUS + "'' || '' : '' || ''" + I_JOB_END_DESC + "'',"+
"JOB_STATUS <> ''IN PROGRESS'', JOB_STATUS_DESC || CHR(10) ||''<''|| SYSTIMESTAMP() || ''> M_END_JOB ERROR_01 : Job is not running <'' || JOB_STATUS || ''>'',"+
"''ERROR_FATAL_01''"+
"),"+
"JOB_ACTION_RESULT = DECODE(TRUE,"+
"JOB_STATUS = ''IN PROGRESS'', ''SUCCESS'',"+
"JOB_STATUS <> ''IN PROGRESS'', ''ERROR_01'',"+
"''ERROR_FATAL_01''"+
")) WHERE I_JOB_NAME =  ''" + I_JOB_NAME + "''  AND DATA_START_DT=TO_DATE(''" + JOB_START_DT + "'',''YYYY-MM-DD'')";
  
var sql_statement1 = snowflake.createStatement({sqlText: SQL_COMMAND });
var result2_scan = sql_statement1.execute(); 
 
var sql_statement2 = snowflake.createStatement({sqlText: UPD_QUERY });
var result2_scan = sql_statement2.execute(); 

 ';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_LASTEXEC_STARTDATE"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "UPDATE DB_AC_"+ENV+"_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_NAME,DATA_START_DT WHETRE PREVIOUS_JOB_NAME=''1'' AND PREVIOUS_JOB_NAME=''-1'' \\n \\
(select PREVIOUS.JOB_NAME MaxDate.JOB_NAME,PREVIOUS.DATA_START_DT ,PREVIOUS.DATA_NEXT_START_DT,PREVIOUS.UPDATE_JOB_AUDIT_ID,PREVIOUS.JOB_STATUS,PREVIOUS.JOB_STATUS_DESC,PREVIOUS.JOB_ACTION_RESULT,PREVIOUS.JOB_DATA_START_DT_RESULT from DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS PREVIOUS \\n \\
INNER JOIN DB_AC_"+ENV+"_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS MaxDate ON PREVIOUS.JOB_NAME=MaxDate.DATA_START_DT \\n \\
INNER JOIN DB_AC_"+ENV+"_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS MaxDate ON PREVIOUS.DATA_START_DT=MaxDate.o_MaxStartDate \\n \\
where JOB_NAME= ''i_JOB_NAME'' AND JOB_STATUS = ''SUCCESS'' \\n \\
group by JOB_NAME )";
try {
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_LASTEXEC_STARTDATE"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "JOB_NAME" VARCHAR(16777216))
RETURNS VARIANT
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var SEL_QUERY = "SELECT TO_CHAR(GREATEST( TO_DATE(''" + IO_START_DT + "'',''YYYY-MM-DD''),DECODE(TRUE, " +
"DECODE(TRUE, " +
" JOB_STATUS IS NOT NULL AND JOB_ACTION_RESULT=''SUCCESS'', ''SUCCESS'' , " +
"''ERROR'')=''SUCCESS'', DATA_START_DT, " +
"TO_DATE(''2000-01-01'',''YYYY-MM-DD''))),''YYYY-MM-DD'') AS IO_PREV_START_DATE FROM DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS MSTR JOIN " +
"(SELECT JOB_NAME, MAX(DATA_START_DT) AS MAX_START_DT FROM DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS " +
"WHERE JOB_STATUS = ''SUCCESS'' AND JOB_NAME = ''" + JOB_NAME + "'' GROUP BY JOB_NAME) DTLS " +
" ON MSTR.JOB_NAME = DTLS.JOB_NAME AND DATA_START_DT = MAX_START_DT " ;
 var SEL_QUERY_ENV = SEL_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
 var sql_statement = snowflake.createStatement({
  sqlText: SEL_QUERY_ENV
}); 
 var res = sql_statement.execute(); 
 res.next(); 
 return res;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_LASTEXEC_STARTDATE"("ENV" VARCHAR(2000), "S_AUDIT_JOB_EXECUTIONS_FIRST_PREVIOUS" VARCHAR(2000), "S_AUDIT_JOB_EXECUTIONS_PREVIOUS" VARCHAR(2000), "T_AUDIT_JOB_EXECUTIONS_UPDATE" VARCHAR(2000), "I_FIELDMAPPING" VARCHAR(2000))
RETURNS VARCHAR(2000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var mapping_json = JSON.parse(I_FIELDMAPPING);
//var mapping_json = I_FIELDMAPPING;
tgt_columns=Object.keys(mapping_json).join()
//return tgt_columns;
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_DWH.TOOLS."+T_AUDIT_JOB_EXECUTIONS_UPDATE+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_DWH.TOOLS."+S_AUDIT_JOB_EXECUTIONS_FIRST_PREVIOUS \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_DWH.TOOLS."+S_AUDIT_JOB_EXECUTIONS_PREVIOUS;

//return sql_command;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";
}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_LASTEXEC_STARTDATE"("ENV" VARCHAR(1000), "i_JOB_NAME" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "UPDATE DB_AC_"+ENV+"_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_NAME , DATA_START_DT \\n \\
(select PREVIOUS.JOB_NAME JOB_NAME,PREVIOUS.DATA_START_DT DATA_START_DT,PREVIOUS.DATA_NEXT_START_DT  DATA_NEXT_START_DT,PREVIOUS.UPDATE_JOB_AUDIT_ID UPDATE_JOB_AUDIT_ID,PREVIOUS.JOB_STATUS JOB_STATUS,PREVIOUS.JOB_STATUS_DESC JOB_STATUS_DESC,PREVIOUS.JOB_ACTION_RESULT JOB_ACTION_RESULT,PREVIOUS.JOB_DATA_START_DT_RESULT JOB_DATA_START_DT_RESULT from AUDIT_JOBS_EXECUTIONS  \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.TOOLS.AUDIT_JOBS_EXECUTIONS  ON AUDIT_JOBS_EXECUTIONS.PREVIOUS_JOB_NAME=AUDIT_JOBS_EXECUTIONS.MaxDate_JOB_NAME \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.TOOLS.AUDIT_JOBS_EXECUTIONS  ON AUDIT_JOBS_EXECUTIONS.PREVIOUS_DATA_START_DT=AUDIT_JOBS_EXECUTIONS.MaxDate_o_MaxStartDate \\n \\
where JOB_NAME= ''tf_LoadDM_SHARED_RDV_to_FACT_PLATFORM_USER_SUBSCRIPTION'' AND JOB_STATUS = ''SUCCESS'' \\n \\
group by JOB_NAME )";
try {
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_STARTJOB_NEXTDATE"("ENV" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "UPDATE DB_AC_"+ENV+"_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_NAME,DATA_START_DT; \\n \\
(select PREVIOUS.JOB_NAME, MaxDate.JOB_NAME,PREVIOUS.DATA_START_DT, MaxDate.o_MaxStartDate,PREVIOUS.DATA_NEXT_START_DT,PREVIOUS.UPDATE_JOB_AUDIT_ID,PREVIOUS.JOB_STATUS,PREVIOUS.JOB_STATUS_DESC,PREVIOUS.JOB_ACTION_RESULT,PREVIOUS.JOB_DATA_START_DT_RESULT from DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS PREVIOUS \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.TOOLS.AUDIT_JOBS_EXECUTIONS MaxDate ON PREVIOUS.JOB_NAME=MaxDate.DATA_START_DT \\n \\
INNER JOIN DB_AC_"+ENV+"_DM.TOOLS.AUDIT_JOBS_EXECUTIONS MaxDate ON PREVIOUS.DATA_START_DT=MaxDate.o_MaxStartDate \\n \\
where JOB_NAME=''i_JOB_NAME$'' AND JOB_STATUS = ''SUCCESS'' AND PREVIOUS_JOB_NAME=''1'' AND PREVIOUS_JOB_NAME=''-1'' \\n \\
group by JOB_NAME )"
try {
	

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return var sql_command;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_STARTJOB_NEXTDATE"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "JOB_NAME" VARCHAR(16777216), "IO_RESULT" VARCHAR(16777216))
RETURNS VARIANT
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var UPD_QUERY = "update DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS " +
" set JOB_ACTION_RESULT = GREATEST(''" + IO_RESULT + "'',DECODE(TRUE, JOB_STATUS IS NOT NULL AND JOB_ACTION_RESULT=''SUCCESS'', ''SUCCESS'' , ''ERROR''))," +
 " JOB_DATA_START_DT_RESULT = GREATEST(''" + IO_START_DT + "'',DECODE(TRUE,  GREATEST(''" + IO_RESULT + "'',DECODE(TRUE, JOB_STATUS IS NOT NULL AND JOB_ACTION_RESULT=''SUCCESS'', ''SUCCESS'' , ''ERROR''))=''SUCCESS'', TO_DATE(''2000-01-01'',''YYYY-MM-DD''))) " +
       "  WHERE JOB_STATUS=''IN PROGRESS'' AND JOB_NAME=  ''" + JOB_NAME + "''";
  var UPD_QUERY_ENV = UPD_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: UPD_QUERY_ENV
});                 
 var result2_scan = sql_statement2.execute(); 
 var SEL_QUERY = "select JOB_ACTION_RESULT, to_varchar(JOB_DATA_START_DT_RESULT,''YYYY-MM-DD'') from  DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS " +
  "  WHERE JOB_STATUS=''IN PROGRESS'' AND JOB_NAME=  ''" + JOB_NAME + "''";
 var SEL_QUERY_ENV = SEL_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
 var sql_statement = snowflake.createStatement({
  sqlText: SEL_QUERY_ENV
}); 
 var res = sql_statement.execute(); 
 res.next();
 return {JOB_STATUS:res.getColumnValue(1),START_DATE:res.getColumnValue(2)}
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_STARTJOB_NEXTDATE"("ENV" VARCHAR(1000), "io_PreviousStartDate" TIMESTAMP_LTZ(9))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "insert into DB_AC_''+ENV+''_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS(JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT) \\n \\
(select JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT from AUDIT_JOBS_EXECUTIONS where JOB_NAME=''i_JOB_NAME'' AND JOB_STATUS = ''SUCCESS'')";

//join AUDIT_JOBS_EXECUTIONS ON AUDIT_JOBS_EXECUTIONS.PREVIOUS_JOB_NAME=AUDIT_JOBS_EXECUTIONS.PREVIOUS_DATA_START_DT//
try {
	

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return var sql_command;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_STARTJOB_NEXTDATE"("ENV" VARCHAR(1000), "io_jobName" VARCHAR(1000), "io_auditID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
CALL DB_AC_DEV_DWH.TOOLS.USP_AUDIT_START_JOB_NEXT_DATE(io_jobName, io_auditID);

var sql_command = "insert into DB_AC_''+ENV+''_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS(JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT \\n \\
(select JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT from AUDIT_JOBS_EXECUTIONS where JOB_STATUS=''IN PROGRESS'' AND JOB_NAME=  ReplaceStr(1, io_jobName, CHR(39), '''')";


try {
	

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return var sql_command;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_STARTJOB_NEXTDATE"("S_AUDIT_JOB_EXECUTIONS_First_Previous" VARCHAR(1000), "S_AUDIT_JOB_EXECUTIONS_Previous" VARCHAR(1000), "T_AUDIT_JOB_EXECUTIONS_Update" VARCHAR(1000), "I_FieldMapping" VARCHAR(1000), "I_JOB_NAME" VARCHAR(1000), "io_PreviousStartDate" TIMESTAMP_LTZ(9))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "insert into DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS(JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT) \\n \\
(select AD.JOB_NAME,AD.DATA_START_DT,AD.DATA_NEXT_START_DT,AD.UPDATE_JOB_AUDIT_ID,AD.JOB_STATUS,AD.JOB_STATUS_DESC,AD.JOB_ACTION_RESULT,AD.JOB_DATA_START_DT_RESULT from DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS AD \\n \\
 inner join DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS AE \\n \\
 ON AUDIT_JOBS_EXECUTIONS.PREVIOUS_JOB_NAME=AUDIT_JOBS_EXECUTIONS.PREVIOUS_DATA_START_DT \\n \\
 where JOB_NAME=''i_JOB_NAME$'' AND JOB_STATUS = ''SUCCESS'',PREVIOUS_JOB_NAME=''1'' AND PREVIOUS_JOB_NAME=''-1'' \\n \\
 group by JOB_NAME )"
try {
	

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return var sql_command;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_STARTJOB_NEXTDATE"("io_PreviousStartDate" TIMESTAMP_LTZ(9))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
 
var sql_command = "insert into DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS(JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT) \\n \\
(select JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT from AUDIT_JOBS_EXECUTIONS where JOB_NAME=''i_JOB_NAME$'' AND JOB_STATUS = ''SUCCESS'')";

//join AUDIT_JOBS_EXECUTIONS ON AUDIT_JOBS_EXECUTIONS.PREVIOUS_JOB_NAME=AUDIT_JOBS_EXECUTIONS.PREVIOUS_DATA_START_DT//
try {
	

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return var sql_command;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_AUDIT_STARTJOB_NEXTDATE_T"("ENV" VARCHAR(16777216), "IO_START_DT" VARCHAR(16777216), "JOB_NAME" VARCHAR(16777216), "IO_RESULT" VARCHAR(16777216))
RETURNS VARIANT
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var UPD_QUERY = "update DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS " +
" set JOB_ACTION_RESULT = GREATEST(''" + IO_RESULT + "'',DECODE(TRUE, JOB_STATUS IS NOT NULL AND JOB_ACTION_RESULT=''SUCCESS'', ''SUCCESS'' , ''ERROR''))," +
 " JOB_DATA_START_DT_RESULT = GREATEST(''" + IO_START_DT + "'',DECODE(TRUE,  GREATEST(''" + IO_RESULT + "'',DECODE(TRUE, JOB_STATUS IS NOT NULL AND JOB_ACTION_RESULT=''SUCCESS'', ''SUCCESS'' , ''ERROR''))=''SUCCESS'', TO_DATE(''2000-01-01'',''YYYY-MM-DD''))) " +
       "  WHERE JOB_STATUS=''IN PROGRESS'' AND JOB_NAME=  ''" + JOB_NAME + "''";
  var UPD_QUERY_ENV = UPD_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: UPD_QUERY_ENV
});                 
 var result2_scan = sql_statement2.execute(); 
 var SEL_QUERY = "select JOB_ACTION_RESULT, to_varchar(JOB_DATA_START_DT_RESULT,''YYYY-MM-DD'') from  DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS " +
  "  WHERE JOB_STATUS=''IN PROGRESS'' AND JOB_NAME=  ''" + JOB_NAME + "''";
 var SEL_QUERY_ENV = SEL_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
 var sql_statement = snowflake.createStatement({
  sqlText: SEL_QUERY_ENV
}); 
 var res = sql_statement.execute(); 
 res.next(); 
 return res;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_DATAVAULT_LOADHUB_MULTIIMAGE"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " +  SELECT_COLS + " FROM (SELECT * FROM  (SELECT *, ROW_NUMBER() OVER(PARTITION BY HK_HUB ORDER BY MD_START_DT ASC) RN FROM "  + SRC_TBL + "  SAT) SATLINK WHERE SATLINK.RN = 1) STG LEFT JOIN  (SELECT DISTINCT * FROM " + TGT_TBL + " ) HUB ON STG.HK_HUB = HUB.HK_HUB WHERE HUB.HK_HUB  IS NULL ORDER BY STG.HK_HUB ASC;";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";
if (TRUNC_TBL == ''Y'')
    {
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';
CREATE OR REPLACE PROCEDURE "SP_CONV_DATAVAULT_LOADLINK_MULTIIMAGE"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " +  SELECT_COLS + " FROM (SELECT * FROM  (SELECT *, ROW_NUMBER() OVER(PARTITION BY HK_LINK ORDER BY MD_START_DT ASC) RN FROM " + SRC_TBL + "  SAT) SATLINK WHERE SATLINK.RN = 1) SRC LEFT JOIN (SELECT DISTINCT * FROM "  + TGT_TBL + " )   LINK ON LINK.HK_LINK = SRC.HK_LINK WHERE LINK.HK_LINK  IS NULL;";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";

if (TRUNC_TBL == ''Y'')
    {
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';
CREATE OR REPLACE PROCEDURE "SP_CONV_DATAVAULT_LOADSATELLITE_INSERT"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " + SELECT_COLS + " FROM (SELECT DISTINCT * FROM " + SRC_TBL + " ) STG LEFT JOIN "+ TGT_TBL +" HUB ON STG.HK_HUB = HUB.HK_HUB  WHERE HUB.HK_HUB IS NULL ORDER BY STG.HK_HUB;"
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";"


if (TRUNC_TBL == ''Y'')
    {
    
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	} sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';
CREATE OR REPLACE PROCEDURE "SP_CONV_DATAVAULT_LOADSATELLITE_MULTIIMAGE"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " + SELECT_COLS + " FROM " + SRC_TBL + " SAT LEFT JOIN "+ TGT_TBL +" STG ON SAT.HK_HUB = STG.HK_HUB AND SAT.MD_START_DT = STG.MD_START_DT AND SAT.MD_HASHDIFF = STG.MD_HASHDIFF  WHERE SAT.ROW_SRC = ''STG'' ;";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";

if (TRUNC_TBL = ''Y'')
    {
    
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
	

   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
   

';
CREATE OR REPLACE PROCEDURE "SP_CONV_DATAVAULT_LOADSATLINK_INSERT"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " + SELECT_COLS + " FROM " + SRC_TBL + " SRC LEFT JOIN "+ TGT_TBL +" SAT ON SRC.HK_LINK = SAT.HK_LINK WHERE SAT.HK_LINK IS NULL ;";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";

if (TRUNC_TBL = ''Y'')
    {
    
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
	

   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
   

';
CREATE OR REPLACE PROCEDURE "SP_CONV_DATAVAULT_LOADSATLINK_MULTIIMAGE"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " + SELECT_COLS + " FROM " + SRC_TBL + " SAT LEFT JOIN "+ TGT_TBL +" STG ON SAT.HK_LINK = STG.HK_LINK AND SAT.MD_START_DT = STG.MD_START_DT AND SAT.MD_HASHDIFF = STG.MD_HASHDIFF WHERE SAT.ROW_SRC = ''STG'' ;";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";

if (TRUNC_TBL = ''Y'')
    {
    
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
	

   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
   

';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADBDV_TOOLS_AUDIT_TO_SHARED_WT_BDV_WT_CAMPAIGN"("ENV" VARCHAR(16777216), "JOB_NAME" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY = "INSERT INTO DB_AC_DEV_DWH.SHARED_WT_BDV.WT_CAMPAIGN(MD_START_DT) SELECT TO_DATE(MAX(DATA_START_DT)) as MD_START_DT " +
"FROM DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS " +
"WHERE JOB_STATUS IS NOT NULL AND JOB_NAME = ''tf_LoadBDV_RDV_to_SHARED_BDV_ENROLLMENT_COMPUTE'' " +
"GROUP BY JOB_NAME"
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHARED_RDV_TO_DM_SHARED_WT_DIM_CUSTOMER"("ENV" VARCHAR(1000), "IO_DATA_START_DATE" VARCHAR(1000), "I_MD_SOURCE" VARCHAR(1000), "I_JOB_AUDIT_ID" VARCHAR(1000), "I_MD_SECURITY_TYPE" VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_PRE_DEL STRING;
INS_INSERT STRING;

BEGIN
IO_DATA_START_DATE :=CHAR(39)||IO_DATA_START_DATE||CHAR(39);
I_MD_SOURCE :=CHAR(39)||I_MD_SOURCE||CHAR(39);
I_MD_SECURITY_TYPE :=CHAR(39)||I_MD_SECURITY_TYPE||CHAR(39);
INS_PRE_DEL := ''DELETE FROM DB_AC_''||ENV||''_DM.SHARED_WT.WT_DIM_CUSTOMER WHERE 1=1'';
INS_INSERT := ''
INSERT INTO DB_AC_''||ENV||''_DM.SHARED_WT.WT_DIM_CUSTOMER ( 	
HK_HUB	
,MD_START_DT			
,MD_CREATION_DT		
,MD_MODIFY_DT		
,MD_SOURCE		
,MD_CREATION_AUDIT_ID		
,MD_MODIFY_AUDIT_ID		
,MD_SECURITY_TYPE		
,AGE_GROUP		
,AGE_GROUP_SORT		
,GENDER		
,POSTAL_CODE_PARTIAL		
,PROVINCE		
,COUNTRY )
SELECT
	rsh.HK_HUB	
	,TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''')		
	,CURRENT_TIMESTAMP	
	,CURRENT_TIMESTAMP	
	,''||I_MD_SOURCE||''	
	,''||I_JOB_AUDIT_ID||''	
	,''||I_JOB_AUDIT_ID||''	
	,''||I_MD_SECURITY_TYPE||''	
	,dt5.AGE_GROUP	
	,dt5.AGE_GROUP_SORT	
	,rss2.GENDER	
	,dt3.POSTAL_CODE_PARTIAL	
	,dt3.PROVINCE	
	,dt3.COUNTRY
	FROM (
	SELECT *
			FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_INDIVIDUAL_PLT ) rss2 
			JOIN 
			(
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_INDIVIDUAL_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt1 
			ON rss2.HK_HUB = dt1.HK_HUB AND rss2.MD_START_DT = dt1.MAX_MD_START_DT
			JOIN
				(SELECT HK_HUB FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.HUB_CUSTOMER) rsh ON rsh.HK_HUB = rss2.HK_HUB  
		LEFT JOIN
		(
			SELECT dt2.HK_HUB, POSTAL_CODE_PARTIAL, PROVINCE, COUNTRY
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_PERSONAL_ADDRESS_PLT ) rss
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_RDV.SAT_PERSONAL_ADDRESS_PLT 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt2 
			ON rss.HK_HUB = dt2.HK_HUB AND rss.MD_START_DT = dt2.MAX_MD_START_DT
			
		)dt3 ON rsh.HK_HUB = dt3.HK_HUB
		LEFT JOIN
		(
			SELECT dt4.HK_HUB,AGE_GROUP, AGE_GROUP_SORT	
			FROM (
				SELECT *
				FROM DB_AC_''||ENV||''_DWH.SHARED_BDV.SAT_INDIVIDUAL_PLT_COMPUTE ) sbs
			JOIN (
				SELECT HK_HUB, MAX(MD_START_DT) AS MAX_MD_START_DT FROM DB_AC_''||ENV||''_DWH.SHARED_BDV.SAT_INDIVIDUAL_PLT_COMPUTE 
					WHERE MD_START_DT <= TO_DATE(''||IO_DATA_START_DATE||'',''''YYYY-MM-DD'''') GROUP BY HK_HUB) AS dt4 
			ON sbs.HK_HUB = dt4.HK_HUB AND sbs.MD_START_DT = dt4.MAX_MD_START_DT
			
		)dt5 ON rsh.HK_HUB = dt5.HK_HUB             
             '';

EXECUTE IMMEDIATE :INS_PRE_DEL;
EXECUTE IMMEDIATE :INS_INSERT;

END
';
CREATE OR REPLACE PROCEDURE "SP_CONV_LOADDM_SHOPPING_RDV_TO_FACT_PLATFORM_SHOPPING_REQUEST"("ENV" VARCHAR(1000), "io_jobName" VARCHAR(1000), "io_auditID" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var pre_sql_command = "CALL DB_AC_DEV_DWH.TOOLS.USP_AUDIT_START_JOB_NEXT_DATE(io_jobName ,io_auditID)"

var sql_command = "insert into DB_AC_''+ENV+''_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS(JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT \\n \\
(select JOB_NAME,DATA_START_DT,DATA_NEXT_START_DT,UPDATE_JOB_AUDIT_ID,JOB_STATUS,JOB_STATUS_DESC,JOB_ACTION_RESULT,JOB_DATA_START_DT_RESULT from AUDIT_JOBS_EXECUTIONS where JOB_STATUS=''IN PROGRESS'' AND JOB_NAME=  ReplaceStr(1, io_jobName, CHR(39), '''')";


try {
	var pre_sql_statement = snowflake.createStatement({sqlText: pre_sql_command });
    var result_scan1 = pre_sql_statement.execute();

    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan = sql_statement.execute();
    result = "Succeeded!";

}

catch (err)  {
        result =  "Failed: Code: " + err.code + " \\n State: " + err.state;
        result += " \\n Message: " + err.message;
        result += " \\n Stack Trace: \\n" + err.stackTraceTxt;
        throw result; 
    }
     
 return var pre_sql_command;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE"("ENV" VARCHAR(1000), "SRC_TBL" VARCHAR(1000), "TGT_TBL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO "+TGT_TBL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM "+SRC_TBL;
try {
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " + SELECT_COLS + " FROM " + SRC_TBL + " SRC ;"
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";"


if (TRUNC_TBL == ''Y'')
    {
    
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
	

   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
   

';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE_NEW"("ENV" VARCHAR(1000), "SRC_TBL" VARCHAR(1000), "TGT_TBL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO "+TGT_TBL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM "+SRC_TBL;
try {
	
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_MODEL_LOADSTG_MODEL_TABLE_PS"("ENV" VARCHAR(1000), "S_VW_EVENT" VARCHAR(1000), "T_INS_MODEL" VARCHAR(1000), "I_MAPPING_TGT_MODEL" VARCHAR(1000))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var  mapping_json = JSON.parse(I_MAPPING_TGT_MODEL);
tgt_columns=Object.keys(mapping_json).join()
src_columns=Object.values(mapping_json).join()
var sql_command = "INSERT INTO DB_AC_"+ENV+"_STG.PLT_MODEL_SHARED."+T_INS_MODEL+"("+tgt_columns+") \\n \\
SELECT "+src_columns+" FROM DB_AC_"+ENV+"_STG.PLT_EVENTS_WORKER."+S_VW_EVENT;
try {
    
    var sql_statement = snowflake.createStatement({sqlText: sql_command });
    var result_scan1 = sql_statement.execute();
    result = "Succeeded!";
}
catch (err)  {
        result =  "Failed: Code: " + err.code + " \\\\n State: " + err.state;
        result += " \\\\n Message: " + err.message;
        result += " \\\\n Stack Trace: \\\\n" + err.stackTraceTxt;
        throw result;
    }
 return result;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_SCD_CLOSE"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " + SELECT_COLS + " FROM (SELECT DISTINCT * FROM " + SRC_TBL + " ) SRC FULL OUTER JOIN " +
"(SELECT DISTINCT * FROM "+ TGT_TBL +" WHERE MD_END_DT IS NULL) DIM ON SRC.MD_HASH_NAT_KEYS = DIM.MD_HASH_NAT_KEYS " + 
" WHERE (src.MD_HASH_NAT_KEYS IS NULL OR SRC.MD_HASHDIFF_TYPE2 <> dim.MD_HASHDIFF_TYPE2) AND (SRC.MD_START_DT IS NULL OR dim.MD_START_DT < src.MD_START_DT) ORDER  BY src.MD_HASH_NAT_KEYS;"
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";" 
if (TRUNC_TBL == ''Y'')
    {
    
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	} sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
  var result_scan = sql_statement.execute();	
';
CREATE OR REPLACE PROCEDURE "SP_CONV_SCD_INSERT"("INSERT_COLS" VARCHAR(16777216), "SELECT_COLS" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "TRUNC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " + SELECT_COLS + " FROM (SELECT DISTINCT * FROM " + SRC_TBL + " ) SRC FULL OUTER JOIN " +
"(SELECT DISTINCT * FROM "+ TGT_TBL +" WHERE MD_END_DT IS NULL) DIM ON SRC.MD_HASH_NAT_KEYS = DIM.MD_HASH_NAT_KEYS " + 
" WHERE src.MD_HASH_NAT_KEYS IS NULL OR SRC.MD_HASHDIFF_TYPE2 <> dim.MD_HASHDIFF_TYPE2 ORDER  BY src.MD_HASH_NAT_KEYS;"
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";" 
if (TRUNC_TBL == ''Y'')
    {
    
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	} sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
  var result_scan = sql_statement.execute();	
';
CREATE OR REPLACE PROCEDURE "SP_CONV_SCD_UPDATE"("ENV" VARCHAR(16777216), "MAPPING" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =  "update " + TGT_TBL + " SET " + MAPPING + 
" from " + SRC_TBL + 
" AS SRC LEFT OUTER JOIN " + TGT_TBL + 
" as dim   ON src.MD_HASH_NAT_KEYS = DIM.MD_HASH_NAT_KEYS where "  + 
" dim.md_end_dt is null and src.MD_HASH_NAT_KEYS is not NULL AND dim.MD_HASH_NAT_KEYS is not null AND (src.MD_HASHDIFF_TYPE2=dim.MD_HASHDIFF_TYPE2) AND (src.MD_HASHDIFF_TYPE1<>dim.MD_HASHDIFF_TYPE1)";
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "SP_CONV_SCD_UPDATE"("MAPPING" VARCHAR(16777216), "TGT_TBL" VARCHAR(16777216), "SRC_TBL" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS ' 
INS_QUERY =  "update " + TGT_TBL + " SET " + MAPPING + 
" from " + SRC_TBL + 
" AS SRC LEFT OUTER JOIN " + TGT_TBL + 
" as dim   ON src.MD_HASH_NAT_KEYS = DIM.MD_HASH_NAT_KEYS where "  + 
" dim.md_end_dt is null and src.MD_HASH_NAT_KEYS is not NULL AND dim.MD_HASH_NAT_KEYS is not null AND (src.MD_HASHDIFF_TYPE2=dim.MD_HASHDIFF_TYPE2) AND (src.MD_HASHDIFF_TYPE1<>dim.MD_HASHDIFF_TYPE1)";
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY
});
var result2_scan = sql_statement2.execute(); 
';
CREATE OR REPLACE PROCEDURE "USP_AUDIT_CHECK_DEPENDENT_JOBS"("JOB_NAME" VARCHAR(16777216), "PRINCIPAL_DATA_START_DT" VARCHAR(10))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

//remove cotes
JOB_NAME= JOB_NAME.replace("''", "");
PRINCIPAL_DATA_START_DT= PRINCIPAL_DATA_START_DT.replace("''", "");


// Check last execution of each dependent job if there are any
var cmd = "SELECT * FROM (SELECT D.DEPENDANT_JOB_NAME, E.JOB_NAME, COALESCE(E.JOB_STATUS,''NOT RUNNING'') AS JOB_STATUS FROM TOOLS.AUDIT_JOBS_DEPENDENCIES D INNER JOIN TOOLS.AUDIT_JOBS_EXECUTIONS E  ON E.JOB_NAME LIKE  D.PRINCIPAL_JOB_NAME_PATTERN AND DEPENDENCY_TYPE=''PREREQUISITE'' AND E.DATA_START_DT = ''" +PRINCIPAL_DATA_START_DT+ "'' WHERE D.DEPENDANT_JOB_NAME= ''" + JOB_NAME + "'' QUALIFY ROW_NUMBER() OVER (PARTITION BY E.JOB_NAME ORDER BY E.DATA_START_DT DESC)=1) WHERE JOB_STATUS<>''SUCCESS''";

var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();

// A non successful execution is found
var msg = "";

while (res.next()) {

	var subJobName= res.getColumnValue(2);
	var status=res.getColumnValue(3);
	
	if(status=="NOT RUNNING")
	{
		msg += " "+ subJobName + " must run before.";
	}
	else
	{
		msg += " "+ subJobName + " status is "+res.getColumnValue(3)+".";
	}
}

if(msg !=""){

	return "The job "+JOB_NAME+" failed because: " + msg;
}

else{
	return "1";
}
';
CREATE OR REPLACE PROCEDURE "USP_AUDIT_START_JOB_NEXT_DATE"("JOB_NAME" VARCHAR(16777216), "JOB_AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
// Update status command
var cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET UPDATE_JOB_AUDIT_ID=''"+JOB_AUDIT_ID+"'', JOB_STATUS=";
var cmdUpdStatusWhereClause = " WHERE JOB_NAME =''" + JOB_NAME + "''";

// Check last execution
var cmd = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND aje.JOB_STATUS IS NOT NULL AND aje.JOB_STATUS<>'''' ORDER BY aje.DATA_START_DT DESC";
var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();


var stUpdStatus;
var resUpdStatus;


// A previous execution is found
if (res.next())
{
	var dtLastJobStart = res.getColumnValue(1);
	var strLastJobStatus = res.getColumnValue(2);

	//var cmdDG = ""INSERT INTO TOOLS.DEBUG_LOG VALUES (''"+ dtLastJobStart +"'')"";
	//var stDG = snowflake.createStatement( { sqlText: cmdDG } );
	//var resDG = stDG.execute();

	// Job is executed before for the same date but without success 
	// => It is correct to re-execute it  
	if (strLastJobStatus != "SUCCESS" && strLastJobStatus != "IN PROGRESS")
	{
		cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''" + JOB_AUDIT_ID + "('' || CURRENT_TIMESTAMP() || '') START_JOB : Job restart. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+res.getColumnValue(1)+"''";	
		stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
		resUpdStatus = stUpdStatus.execute();
		return res.getColumnValue(1);
	}
	else
	{
		// The last execution was successful
		// => Execute for next date
		if (strLastJobStatus == "SUCCESS")
		{
			// Check last execution
			var cmdNext = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND DATA_START_DT>''"+res.getColumnValue(1)+"'' ORDER BY aje.DATA_START_DT ASC";
			var stNext = snowflake.createStatement( { sqlText: cmdNext } );
			var resNext = stNext.execute();
			if (resNext.next())
			{
				cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB : Job start. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resNext.getColumnValue(1)+"''";	;
				stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
				resUpdStatus = stUpdStatus.execute();
				return resNext.getColumnValue(1);
			}
		}
		// Already executing for this date (IN PROGRESS)
		// Error
		else
		{
			cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_ACTION_RESULT=''ERROR_03'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_03 : Trying to execute a running Job. ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+res.getColumnValue(1)+"''";	
			stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
			resUpdStatus = stUpdStatus.execute();
			return "0000-00-00";
		}	
	}	
}
// First execution of the job : no previous job
else
{
	// Check last execution
	var cmdFirst = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' ORDER BY aje.DATA_START_DT ASC";
	var stFirst = snowflake.createStatement( { sqlText: cmdFirst } );
	var resFirst = stFirst.execute();
	
	if (resFirst.next())
	{
		cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB : Job first start. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resFirst.getColumnValue(1)+"''";
		stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
		resUpdStatus = stUpdStatus.execute();
		return resFirst.getColumnValue(1);
	}
	else 
	{
		return "0000-00-00"
	}
}


return "0000-00-00";

';
CREATE OR REPLACE PROCEDURE "USP_AUDIT_START_JOB_NEXT_DATE_A"("JOB_NAME" VARCHAR(16777216), "JOB_AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
//remove cotes
JOB_NAME= JOB_NAME.replace("''", "");
JOB_AUDIT_ID= JOB_AUDIT_ID.replace("''", "");

// Update status command
var cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET UPDATE_JOB_AUDIT_ID=''"+JOB_AUDIT_ID+"'', JOB_STATUS=";
var cmdUpdStatusWhereClause = " WHERE JOB_NAME ="+"''" + JOB_NAME + "''";

// Check last execution
var cmd = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND aje.JOB_STATUS IS NOT NULL AND aje.JOB_STATUS<>'''' ORDER BY aje.DATA_START_DT DESC";
var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();


var stUpdStatus;
var resUpdStatus;


// A previous execution is found
if (res.next())
{
	var dtLastJobStart = res.getColumnValue(1);
	var strLastJobStatus = res.getColumnValue(2);

	//var cmdDG = ""INSERT INTO TOOLS.DEBUG_LOG VALUES (''""+ dtLastJobStart +""'')"";
	//var stDG = snowflake.createStatement( { sqlText: cmdDG } );
	//var resDG = stDG.execute();

	// Job is executed before for the same date but without success 
	// => It is correct to re-execute it  
	if (strLastJobStatus != "SUCCESS" && strLastJobStatus != "IN PROGRESS")
	{
		// Check last execution
		var cmdNext = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND DATA_START_DT=''"+res.getColumnValue(1)+"'' ORDER BY aje.DATA_START_DT ASC";
		var stNext = snowflake.createStatement( { sqlText: cmdNext } );
		var resNext = stNext.execute();
		if (resNext.next())
			{
			//Check dependent jobs execution, if there are any
			var statementDep = snowflake.createStatement( { sqlText: "CALL TOOLS.USP_AUDIT_CHECK_DEPENDENT_JOBS(''" + JOB_NAME + "'',''" + resNext.getColumnValue(1) + "'')" } );
			var dependencyRslt = statementDep.execute();
			dependencyRslt.next();
			var dependencyMsg = dependencyRslt.getColumnValue(1);
			if(dependencyMsg != "1")
			{
			//throw dependencyMsg;
	        cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_STATUS=''ERROR'' , JOB_ACTION_RESULT=''ERROR_04'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_04 : "+ dependencyMsg +" ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resNext.getColumnValue(1)+"''";	
			stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
			resUpdStatus = stUpdStatus.execute();
			return "0000-00-00";
			}

		cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''" + JOB_AUDIT_ID + "('' || CURRENT_TIMESTAMP() || '') START_JOB : Job restart. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+res.getColumnValue(1)+"''";	
		stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
		resUpdStatus = stUpdStatus.execute();
		return res.getColumnValue(1);
		}
	}
	else
	{
		// The last execution was successful
		// => Execute for next date
		if (strLastJobStatus == "SUCCESS")
		{
			// Check last execution
			var cmdNext = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND DATA_START_DT>''"+res.getColumnValue(1)+"'' ORDER BY aje.DATA_START_DT ASC";
			var stNext = snowflake.createStatement( { sqlText: cmdNext } );
			var resNext = stNext.execute();
			if (resNext.next())
			{


				//Check dependent jobs execution, if there are any
				var statementDep = snowflake.createStatement( { sqlText: "CALL TOOLS.USP_AUDIT_CHECK_DEPENDENT_JOBS(''" + JOB_NAME + "'',''" + resNext.getColumnValue(1) + "'')" } );
				var dependencyRslt = statementDep.execute();
				dependencyRslt.next();
				var dependencyMsg = dependencyRslt.getColumnValue(1);
				if(dependencyMsg != "1")
				{
				//throw dependencyMsg;
                
                cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_STATUS=''ERROR'' , JOB_ACTION_RESULT=''ERROR_04'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_04 : "+ dependencyMsg +" ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resNext.getColumnValue(1)+"''";	
				stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
				resUpdStatus = stUpdStatus.execute();
				return "0000-00-00";
				}


				cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB : Job start. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resNext.getColumnValue(1)+"''";	;
				stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
				resUpdStatus = stUpdStatus.execute();
				return resNext.getColumnValue(1);
			}
		}
		// Already executing for this date (IN PROGRESS)
		// Error
		else
		{
			cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_ACTION_RESULT=''ERROR_03'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_03 : Trying to execute a running Job. ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+res.getColumnValue(1)+"''";	
			stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
			resUpdStatus = stUpdStatus.execute();
			return "0000-00-00";
		}	
	}	
}
// First execution of the job : no previous job
else
{
	// Check last execution
	var cmdFirst = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' ORDER BY aje.DATA_START_DT ASC";
	var stFirst = snowflake.createStatement( { sqlText: cmdFirst } );
	var resFirst = stFirst.execute();
	
	if (resFirst.next())
	{

                //Check dependent jobs execution, if there are any
				var statementDep = snowflake.createStatement( { sqlText: "CALL TOOLS.USP_AUDIT_CHECK_DEPENDENT_JOBS(''" + JOB_NAME + "'',''" + resFirst.getColumnValue(1) + "'')" } );
				var dependencyRslt = statementDep.execute();
				dependencyRslt.next();
				var dependencyMsg = dependencyRslt.getColumnValue(1);
				if(dependencyMsg != "1")
				{

				//throw dependencyMsg;

                cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_STATUS=''ERROR'' ,JOB_ACTION_RESULT=''ERROR_04'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_04 : "+ dependencyMsg +" ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resFirst.getColumnValue(1)+"''";	
				stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
				resUpdStatus = stUpdStatus.execute();
				return "0000-00-00";
				}

		cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB : Job first start. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resFirst.getColumnValue(1)+"''";
		stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
		resUpdStatus = stUpdStatus.execute();
		return resFirst.getColumnValue(1);
	}
	else 
	{
		return "0000-00-00"
	}
}


return "0000-00-00";

';
CREATE OR REPLACE PROCEDURE "USP_AUDIT_START_JOB_VARIABLE_SET"("JOB_NAME" VARCHAR(16777216), "DATA_START_DT" VARCHAR(10))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var cmd =  "SELECT CASE WHEN JOB_STATUS IS NOT NULL AND JOB_ACTION_RESULT = ''SUCCESS'' THEN ''SUCCESS'' ELSE ''ERROR'' END AS tmp_result FROM DB_AC_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS WHERE JOB_STATUS=''IN PROGRESS'' AND  JOB_NAME=  Replace(''"+JOB_NAME+"'', CHR(39), '''')  AND DATA_START_DT =  TO_DATE(Replace(''"+DATA_START_DT+"'', CHR(39), ''''),''YYYY-MM-DD'')";
var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();
var op=''''
while (res.next())  {
 op= res.getColumnValue(1);
 
}
return op;
';
create or replace schema TOOLS_REG_TESTS;

create or replace TABLE DB_AC_DEV_DWH__TOOLS__SAT_INDIVIDUAL_PLT_REF (
	HK_HUB VARCHAR(64) COMMENT 'Hash key for the Hub',
	MD_START_DT TIMESTAMP_NTZ(9) COMMENT 'Start Date of the image/version',
	MD_HASHDIFF VARCHAR(64) COMMENT 'Represents the whole set of hashed attributes to be historized for an occurrence',
	MD_CREATION_DT TIMESTAMP_NTZ(9) COMMENT 'Creation Date Time of the occurrence',
	MD_SOURCE VARCHAR(1000) COMMENT 'Represents the source system, file, etc. of the instance',
	MD_CREATION_AUDIT_ID VARCHAR(1000) COMMENT 'Task execution ID',
	MONTH_OF_BIRTH DATE COMMENT 'Month of birth',
	GENDER VARCHAR(16777216) COMMENT 'Individual Gender'
);
create or replace TABLE DB_AC_DEV_DWH__TOOLS__SAT_INDIVIDUAL_PLT_RES (
	RES VARCHAR(2),
	RES_HK_HUB VARCHAR(64),
	REF_HK_HUB VARCHAR(64),
	RES_MD_START_DT TIMESTAMP_NTZ(9),
	REF_MD_START_DT TIMESTAMP_NTZ(9),
	RES_MD_HASHDIFF VARCHAR(64),
	REF_MD_HASHDIFF VARCHAR(64)
);
create or replace TABLE REG_TESTS_DEFINITION (
	ID NUMBER(38,0) autoincrement COMMENT 'Unique identifier of a regression test definition',
	REG_TEST_VERSION VARCHAR(100) NOT NULL COMMENT 'Version of the regression test set',
	TABLE_FULLNAME VARCHAR(2000) NOT NULL COMMENT 'DbName.SchemaName.TableName of the table to be tested',
	COLUMN_NAME VARCHAR(2000) NOT NULL COMMENT 'Name pof a column to be validated or one of the key columns',
	COLUMN_TYPE VARCHAR(2000) NOT NULL COMMENT 'KEY or VALUE'
);