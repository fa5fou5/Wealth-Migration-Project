create or replace database DB_CTB_DEV_DM;

create or replace schema ACT_PUBLICATION;

create or replace view V_IFRS17_TRX_DETAILS(
	HK_LINK,
	CODE_LOB,
	ACCOUNTING_PERIOD,
	MD_SYSTEM_SOURCE,
	SYSTEMESOURCE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ACCOUNTING_ENTRY_TYPE,
	LEDGER_NAME,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
	DEBIT,
	CREDIT,
	SOLDE,
	VARIABLE,
	CUSTOM_DIM_1,
	CUSTOM_DIM_2,
	MD_CREATIONDATE,
	MD_FILEDATE,
	MD_FILENAME,
	AEHEADERID,
	AELINENUM,
	LEGALENTEFFECTIVEFROM,
	LEGALENTEFFECTIVETO,
	SR1,
	SR10,
	SR11,
	SR12,
	SR13,
	SR14,
	SR15,
	SR16,
	SR17,
	SR18,
	SR19,
	SR2,
	SR20,
	SR21,
	SR22,
	SR23,
	SR24,
	SR25,
	SR26,
	SR27,
	SR28,
	SR29,
	SR3,
	SR30,
	SR31,
	SR32,
	SR33,
	SR34,
	SR35,
	SR36,
	SR37,
	SR38,
	SR39,
	SR4,
	SR40,
	SR41,
	SR42,
	SR43,
	SR44,
	SR45,
	SR46,
	SR47,
	SR48,
	SR49,
	SR5,
	SR50,
	SR51,
	SR52,
	SR53,
	SR54,
	SR55,
	SR56,
	SR57,
	SR58,
	SR59,
	SR6,
	SR60,
	SR7,
	SR8,
	SR9,
	SUBLEDGERAPPLNSETUPAPPLICATIONID,
	SUBLEDGERAPPLNSETUPHEADERJESOURCENAME,
	TRANSACTIONENTITYENTITYCODE,
	TRANSACTIONENTITYENTITYID,
	XLAGLLEDGERSLEDGERID,
	XLAGLLEDGERSNAME,
	XLAGLLEDGERSPERIODSETNAME,
	XLAHDRACCOUNTINGENTRYSTATUSCODE,
	XLAHDRBALANCETYPECODE,
	XLAHDRCREATIONDATE,
	XLAHDRDESCRIPTION,
	XLAHDREVENTTYPECODE,
	XLAHDRGLTRANSFERDATE,
	XLAHDRGLTRANSFERSTATUSCODE,
	XLAHDRJECATEGORYNAME,
	XLAHDRLASTUPDATEDATE,
	XLAHDRPERIODNAME,
	XLALINESACCOUNTEDCR,
	XLALINESACCOUNTEDDR,
	XLALINESACCOUNTINGDATE,
	XLALINESCODECOMBINATIONID,
	XLALINESCREATIONDATE,
	XLALINESCURRENCYCODE,
	XLALINESCURRENCYCONVERSIONDATE,
	XLALINESCURRENCYCONVERSIONRATE,
	XLALINESCURRENCYCONVERSIONTYPE,
	XLALINESDESCRIPTION,
	XLALINESLASTUPDATEDATE,
	XLALINESSUPPREFCOMBINATIONID,
	HK_HUB_SUBLEDGERAPPLICATION,
	XLAHDRACCOUNTINGENTRYTYPECODE
) as
SELECT
    -- Données normalisées en provenance des vues de partage dans DM.CTB
    trx.HK_LINK, 
    trx.CODE_LOB, 
    trx.ACCOUNTING_PERIOD, 
    trx.MD_SYSTEM_SOURCE, 
    trx.SYSTEMESOURCE, 
    trx.ID_PRIMAIRE, 
    trx.ID_SECONDAIRE, 
    trx.ID_RECLAMATION, 
    trx.ID_REASSURANCE, 
    trx.ID_COMPLEMENT, 
    trx.ID_MANUEL_001, 
    trx.ID_MANUEL_002, 
    trx.ID_MANUEL_003, 
    trx.ID_MANUEL_004, 
    trx.ID_MANUEL_005, 
    trx.ACCOUNTING_ENTRY_TYPE, 
    trx.LEDGER_NAME, 
    trx.ENTITY, 
    trx.NATURE, 
    trx.COST_CENTER, 
    trx.INTERCO, 
    trx.LOB, 
    trx.PRODUCT, 
    trx.PARTICIPATION, 
    trx.GEOGRAPHY, 
    trx.PERIODICITY, 
    trx.ORIGIN, 
    trx.PROJECT, 
    trx.FUTUR1, 
    trx.FUTUR2, 
    trx.DEBIT, 
    trx.CREDIT, 
    trx.SOLDE, 
    trx.VARIABLE, 
    trx.CUSTOM_DIM_1, 
    trx.CUSTOM_DIM_2,
    
    -- Données détaillées de références en provenance de la table de transactions sources AHCS
    --ahcs.MD_SYSTEMSOURCE,         --> Doublons de trx.MD_SYSTEM_SOURCE
    ahcs.MD_CREATIONDATE, 
    ahcs.MD_FILEDATE, 
    ahcs.MD_FILENAME, 
    ahcs.AEHEADERID, 
    ahcs.AELINENUM, 
    ahcs.LEGALENTEFFECTIVEFROM, 
    ahcs.LEGALENTEFFECTIVETO, 
    ahcs.SR1, 
    ahcs.SR10, 
    ahcs.SR11, 
    ahcs.SR12, 
    ahcs.SR13, 
    ahcs.SR14, 
    ahcs.SR15, 
    ahcs.SR16, 
    ahcs.SR17, 
    ahcs.SR18, 
    ahcs.SR19, 
    ahcs.SR2, 
    ahcs.SR20, 
    ahcs.SR21, 
    ahcs.SR22, 
    ahcs.SR23, 
    ahcs.SR24, 
    ahcs.SR25, 
    ahcs.SR26, 
    ahcs.SR27, 
    ahcs.SR28, 
    ahcs.SR29, 
    ahcs.SR3, 
    ahcs.SR30, 
    ahcs.SR31, 
    ahcs.SR32, 
    ahcs.SR33, 
    ahcs.SR34, 
    ahcs.SR35, 
    ahcs.SR36, 
    ahcs.SR37, 
    ahcs.SR38, 
    ahcs.SR39, 
    ahcs.SR4, 
    ahcs.SR40, 
    ahcs.SR41, 
    ahcs.SR42, 
    ahcs.SR43, 
    ahcs.SR44, 
    ahcs.SR45, 
    ahcs.SR46, 
    ahcs.SR47, 
    ahcs.SR48, 
    ahcs.SR49, 
    ahcs.SR5, 
    ahcs.SR50, 
    ahcs.SR51, 
    ahcs.SR52, 
    ahcs.SR53, 
    ahcs.SR54, 
    ahcs.SR55, 
    ahcs.SR56, 
    ahcs.SR57, 
    ahcs.SR58, 
    ahcs.SR59, 
    ahcs.SR6, 
    ahcs.SR60, 
    ahcs.SR7, 
    ahcs.SR8, 
    ahcs.SR9, 
    ahcs.SUBLEDGERAPPLNSETUPAPPLICATIONID, 
    ahcs.SUBLEDGERAPPLNSETUPHEADERJESOURCENAME, 
    ahcs.TRANSACTIONENTITYENTITYCODE, 
    ahcs.TRANSACTIONENTITYENTITYID, 
    ahcs.XLAGLLEDGERSLEDGERID, 
    ahcs.XLAGLLEDGERSNAME, 
    ahcs.XLAGLLEDGERSPERIODSETNAME, 
    ahcs.XLAHDRACCOUNTINGENTRYSTATUSCODE, 
    ahcs.XLAHDRBALANCETYPECODE, 
    ahcs.XLAHDRCREATIONDATE, 
    ahcs.XLAHDRDESCRIPTION, 
    ahcs.XLAHDREVENTTYPECODE, 
    ahcs.XLAHDRGLTRANSFERDATE, 
    ahcs.XLAHDRGLTRANSFERSTATUSCODE, 
    ahcs.XLAHDRJECATEGORYNAME, 
    ahcs.XLAHDRLASTUPDATEDATE, 
    ahcs.XLAHDRPERIODNAME, 
    ahcs.XLALINESACCOUNTEDCR, 
    ahcs.XLALINESACCOUNTEDDR, 
    ahcs.XLALINESACCOUNTINGDATE, 
    ahcs.XLALINESCODECOMBINATIONID, 
    ahcs.XLALINESCREATIONDATE, 
    ahcs.XLALINESCURRENCYCODE, 
    ahcs.XLALINESCURRENCYCONVERSIONDATE, 
    ahcs.XLALINESCURRENCYCONVERSIONRATE, 
    ahcs.XLALINESCURRENCYCONVERSIONTYPE, 
    ahcs.XLALINESDESCRIPTION, 
    --ahcs.XLALINESENTEREDCR,                --> Cette colonne est exclus pour éviter la confusion avec la colonne XLALINESACCOUNTEDCR
    --ahcs.XLALINESENTEREDDR,                --> Cette colonne est exclus pour éviter la confusion avec la colonne XLALINESACCOUNTEDDR 
    ahcs.XLALINESLASTUPDATEDATE, 
    ahcs.XLALINESSUPPREFCOMBINATIONID, 
    ahcs.HK_HUB_SUBLEDGERAPPLICATION, 
    ahcs.XLAHDRACCOUNTINGENTRYTYPECODE
FROM DB_CTB_DEV_DM.CTB.V_TRANSACTIONS_BY_LOB trx
LEFT JOIN DB_CTB_DEV_DWH.CTB.LINKTRANSACTIONNEL_SUBLEDGER_ENTRY_LINE_PVO ahcs ON trx.HK_LINK = ahcs.HK_LINK
WHERE IFRS17_UNIQUE_FLAG=1              -- Assures l'unicité des transactions entre GL et AHCS selon le pilotage par code d'auxiliaires.
;
create or replace schema ACT_PUBLICATION_DEV;

create or replace view V_IFRS17_TRX_DETAILS(
	HK_LINK,
	CODE_LOB,
	ACCOUNTING_PERIOD,
	MD_SYSTEM_SOURCE,
	SYSTEMESOURCE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ACCOUNTING_ENTRY_TYPE,
	LEDGER_NAME,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
	DEBIT,
	CREDIT,
	SOLDE,
	VARIABLE,
	CUSTOM_DIM_1,
	CUSTOM_DIM_2,
	MD_CREATIONDATE,
	MD_FILEDATE,
	MD_FILENAME,
	AEHEADERID,
	AELINENUM,
	LEGALENTEFFECTIVEFROM,
	LEGALENTEFFECTIVETO,
	SR1,
	SR10,
	SR11,
	SR12,
	SR13,
	SR14,
	SR15,
	SR16,
	SR17,
	SR18,
	SR19,
	SR2,
	SR20,
	SR21,
	SR22,
	SR23,
	SR24,
	SR25,
	SR26,
	SR27,
	SR28,
	SR29,
	SR3,
	SR30,
	SR31,
	SR32,
	SR33,
	SR34,
	SR35,
	SR36,
	SR37,
	SR38,
	SR39,
	SR4,
	SR40,
	SR41,
	SR42,
	SR43,
	SR44,
	SR45,
	SR46,
	SR47,
	SR48,
	SR49,
	SR5,
	SR50,
	SR51,
	SR52,
	SR53,
	SR54,
	SR55,
	SR56,
	SR57,
	SR58,
	SR59,
	SR6,
	SR60,
	SR7,
	SR8,
	SR9,
	SUBLEDGERAPPLNSETUPAPPLICATIONID,
	SUBLEDGERAPPLNSETUPHEADERJESOURCENAME,
	TRANSACTIONENTITYENTITYCODE,
	TRANSACTIONENTITYENTITYID,
	XLAGLLEDGERSLEDGERID,
	XLAGLLEDGERSNAME,
	XLAGLLEDGERSPERIODSETNAME,
	XLAHDRACCOUNTINGENTRYSTATUSCODE,
	XLAHDRBALANCETYPECODE,
	XLAHDRCREATIONDATE,
	XLAHDRDESCRIPTION,
	XLAHDREVENTTYPECODE,
	XLAHDRGLTRANSFERDATE,
	XLAHDRGLTRANSFERSTATUSCODE,
	XLAHDRJECATEGORYNAME,
	XLAHDRLASTUPDATEDATE,
	XLAHDRPERIODNAME,
	XLALINESACCOUNTEDCR,
	XLALINESACCOUNTEDDR,
	XLALINESACCOUNTINGDATE,
	XLALINESCODECOMBINATIONID,
	XLALINESCREATIONDATE,
	XLALINESCURRENCYCODE,
	XLALINESCURRENCYCONVERSIONDATE,
	XLALINESCURRENCYCONVERSIONRATE,
	XLALINESCURRENCYCONVERSIONTYPE,
	XLALINESDESCRIPTION,
	XLALINESLASTUPDATEDATE,
	XLALINESSUPPREFCOMBINATIONID,
	HK_HUB_SUBLEDGERAPPLICATION,
	XLAHDRACCOUNTINGENTRYTYPECODE
) as
SELECT
    -- Données normalisées en provenance des vues de partage dans DM.CTB
    trx.HK_LINK, 
    trx.CODE_LOB, 
    trx.ACCOUNTING_PERIOD, 
    trx.MD_SYSTEM_SOURCE, 
    trx.SYSTEMESOURCE, 
    trx.ID_PRIMAIRE, 
    trx.ID_SECONDAIRE, 
    trx.ID_RECLAMATION, 
    trx.ID_REASSURANCE, 
    trx.ID_COMPLEMENT, 
    trx.ID_MANUEL_001, 
    trx.ID_MANUEL_002, 
    trx.ID_MANUEL_003, 
    trx.ID_MANUEL_004, 
    trx.ID_MANUEL_005, 
    trx.ACCOUNTING_ENTRY_TYPE, 
    trx.LEDGER_NAME, 
    trx.ENTITY, 
    trx.NATURE, 
    trx.COST_CENTER, 
    trx.INTERCO, 
    trx.LOB, 
    trx.PRODUCT, 
    trx.PARTICIPATION, 
    trx.GEOGRAPHY, 
    trx.PERIODICITY, 
    trx.ORIGIN, 
    trx.PROJECT, 
    trx.FUTUR1, 
    trx.FUTUR2, 
    trx.DEBIT, 
    trx.CREDIT, 
    trx.SOLDE, 
    trx.VARIABLE, 
    trx.CUSTOM_DIM_1, 
    trx.CUSTOM_DIM_2,
    
    -- Données détaillées de références en provenance de la table de transactions sources AHCS
    --ahcs.MD_SYSTEMSOURCE,         --> Doublons de trx.MD_SYSTEM_SOURCE
    ahcs.MD_CREATIONDATE, 
    ahcs.MD_FILEDATE, 
    ahcs.MD_FILENAME, 
    ahcs.AEHEADERID, 
    ahcs.AELINENUM, 
    ahcs.LEGALENTEFFECTIVEFROM, 
    ahcs.LEGALENTEFFECTIVETO, 
    ahcs.SR1, 
    ahcs.SR10, 
    ahcs.SR11, 
    ahcs.SR12, 
    ahcs.SR13, 
    ahcs.SR14, 
    ahcs.SR15, 
    ahcs.SR16, 
    ahcs.SR17, 
    ahcs.SR18, 
    ahcs.SR19, 
    ahcs.SR2, 
    ahcs.SR20, 
    ahcs.SR21, 
    ahcs.SR22, 
    ahcs.SR23, 
    ahcs.SR24, 
    ahcs.SR25, 
    ahcs.SR26, 
    ahcs.SR27, 
    ahcs.SR28, 
    ahcs.SR29, 
    ahcs.SR3, 
    ahcs.SR30, 
    ahcs.SR31, 
    ahcs.SR32, 
    ahcs.SR33, 
    ahcs.SR34, 
    ahcs.SR35, 
    ahcs.SR36, 
    ahcs.SR37, 
    ahcs.SR38, 
    ahcs.SR39, 
    ahcs.SR4, 
    ahcs.SR40, 
    ahcs.SR41, 
    ahcs.SR42, 
    ahcs.SR43, 
    ahcs.SR44, 
    ahcs.SR45, 
    ahcs.SR46, 
    ahcs.SR47, 
    ahcs.SR48, 
    ahcs.SR49, 
    ahcs.SR5, 
    ahcs.SR50, 
    ahcs.SR51, 
    ahcs.SR52, 
    ahcs.SR53, 
    ahcs.SR54, 
    ahcs.SR55, 
    ahcs.SR56, 
    ahcs.SR57, 
    ahcs.SR58, 
    ahcs.SR59, 
    ahcs.SR6, 
    ahcs.SR60, 
    ahcs.SR7, 
    ahcs.SR8, 
    ahcs.SR9, 
    ahcs.SUBLEDGERAPPLNSETUPAPPLICATIONID, 
    ahcs.SUBLEDGERAPPLNSETUPHEADERJESOURCENAME, 
    ahcs.TRANSACTIONENTITYENTITYCODE, 
    ahcs.TRANSACTIONENTITYENTITYID, 
    ahcs.XLAGLLEDGERSLEDGERID, 
    ahcs.XLAGLLEDGERSNAME, 
    ahcs.XLAGLLEDGERSPERIODSETNAME, 
    ahcs.XLAHDRACCOUNTINGENTRYSTATUSCODE, 
    ahcs.XLAHDRBALANCETYPECODE, 
    ahcs.XLAHDRCREATIONDATE, 
    ahcs.XLAHDRDESCRIPTION, 
    ahcs.XLAHDREVENTTYPECODE, 
    ahcs.XLAHDRGLTRANSFERDATE, 
    ahcs.XLAHDRGLTRANSFERSTATUSCODE, 
    ahcs.XLAHDRJECATEGORYNAME, 
    ahcs.XLAHDRLASTUPDATEDATE, 
    ahcs.XLAHDRPERIODNAME, 
    ahcs.XLALINESACCOUNTEDCR, 
    ahcs.XLALINESACCOUNTEDDR, 
    ahcs.XLALINESACCOUNTINGDATE, 
    ahcs.XLALINESCODECOMBINATIONID, 
    ahcs.XLALINESCREATIONDATE, 
    ahcs.XLALINESCURRENCYCODE, 
    ahcs.XLALINESCURRENCYCONVERSIONDATE, 
    ahcs.XLALINESCURRENCYCONVERSIONRATE, 
    ahcs.XLALINESCURRENCYCONVERSIONTYPE, 
    ahcs.XLALINESDESCRIPTION, 
    --ahcs.XLALINESENTEREDCR,                --> Cette colonne est exclus pour éviter la confusion avec la colonne XLALINESACCOUNTEDCR
    --ahcs.XLALINESENTEREDDR,                --> Cette colonne est exclus pour éviter la confusion avec la colonne XLALINESACCOUNTEDDR 
    ahcs.XLALINESLASTUPDATEDATE, 
    ahcs.XLALINESSUPPREFCOMBINATIONID, 
    ahcs.HK_HUB_SUBLEDGERAPPLICATION, 
    ahcs.XLAHDRACCOUNTINGENTRYTYPECODE
FROM DB_CTB_DEV_DM.CTB_DEV.V_TRANSACTIONS_BY_LOB trx
LEFT JOIN DB_CTB_DEV_DWH.CTB_DEV.LINKTRANSACTIONNEL_SUBLEDGER_ENTRY_LINE_PVO ahcs ON trx.HK_LINK = ahcs.HK_LINK
WHERE IFRS17_UNIQUE_FLAG=1;
create or replace schema ACT_VI_PUBLICATION;

create or replace view VW_EXTRAITCOMPTABLESOE(
	CODE_LOB,
	PERIODECOMPTABLE,
	JOURNAL,
	SOURCE,
	SYSTEMESOURCE,
	TYPEENTREE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ENTITE,
	NATURE,
	CENTRECOUT,
	INTERCO,
	LIGNEAFFAIRE,
	PRODUIT,
	PARTICIPATION,
	GEOGRAPHIE,
	PERIODICITE,
	ORIGINE,
	PROJET,
	FUTUR1,
	FUTUR2,
	DEBIT,
	CREDIT,
	SOLDE,
	VARIABLE_CSM,
	CUSTOM_DIM_1,
	CUSTOM_DIM_2
) as
/* ==========================================================================================================================
Auth :  Charles fortier
Date :  2021-11-01
Desc :  Cette vue retourne les transactions aggrérés pour la lignes d'affaire VI (Avec les 3 sous-code de filiale VI, IAE et USL) 
Changements :
    - Pierre Cusson, 2021-11-08 : Standardisation des colonnes ajout ajout du SUM / GROUP BY pour réduire le volume de transactions
	- Pierre Cusson, 2021-12-07 : Enlève la notion de ""prestation"" dans le nom de la vue pour être moins spécifique.
===========================================================================================================================*/
SELECT 
	CODE_LOB as Code_LOB,
	ACCOUNTING_PERIOD as PeriodeComptable,
	LEDGER_NAME as Journal,
	MD_SYSTEM_SOURCE as Source,
	SYSTEMESOURCE as SystemeSource,
	IFNULL(ACCOUNTING_ENTRY_TYPE, '') as TypeEntree,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ENTITY as Entite,
	NATURE as Nature,
	COST_CENTER as CentreCout,
	INTERCO as Interco,
	LOB as LigneAffaire,
	PRODUCT as Produit,
	PARTICIPATION as Participation,
	GEOGRAPHY as Geographie,
	PERIODICITY as Periodicite,
	ORIGIN as Origine,
	PROJECT as Projet,
	FUTUR1 as Futur1,
	FUTUR2 as Futur2,
	SUM(DEBIT) as Debit,
	SUM(CREDIT) as Credit,
	SUM(SOLDE) as Solde,
    Variable as Variable_CSM,
    Custom_Dim_1,
    Custom_Dim_2
from DB_CTB_DEV_DM.CTB.V_TRANSACTIONS_BY_LOB
where CODE_LOB in ('VI-VI','VI-IAE','USL') 
    AND IFRS17_Unique_Flag = 1      -- Retourne le détails de AHCS selon les requis IFRS17 et les compléments des écritures manuelles du GL
    AND date_from_parts(left(PeriodeComptable,4),right(PeriodeComptable,2),01) -- PeriodeComptable as a date must be between current_date and date -24 months
        between  date_from_parts(date_part(year,dateadd(month, -24, current_date())),date_part(month,dateadd(month, -24, current_date())),01) and date_from_parts(date_part(year, current_date()),date_part(month, current_date()),01)
GROUP BY 
	CODE_LOB,
	ACCOUNTING_PERIOD,
	LEDGER_NAME,
	MD_SYSTEM_SOURCE,
	SYSTEMESOURCE,
	ACCOUNTING_ENTRY_TYPE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
    Variable,
    Custom_Dim_1,
    Custom_Dim_2;
create or replace schema ACT_VI_PUBLICATION_DEV;

create or replace view VW_ETL_PROCESS_STATUS(
	PROCESS,
	TASK_STATUS,
	START_TIME,
	END_TIME
) as 
  Select * from DB_CTB_DEV_DWH.CTB_DEV.V_ETL_PROCESS_STATUS;
create or replace view VW_EXTRAITCOMPTABLESOE(
	CODE_LOB,
	PERIODECOMPTABLE,
	JOURNAL,
	SOURCE,
	SYSTEMESOURCE,
	TYPEENTREE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ENTITE,
	NATURE,
	CENTRECOUT,
	INTERCO,
	LIGNEAFFAIRE,
	PRODUIT,
	PARTICIPATION,
	GEOGRAPHIE,
	PERIODICITE,
	ORIGINE,
	PROJET,
	FUTUR1,
	FUTUR2,
	DEBIT,
	CREDIT,
	SOLDE,
	VARIABLE,
	CUSTOM_DIM_1,
	CUSTOM_DIM_2
) as
/* ==========================================================================================================================
Auth :  Charles fortier
Date :  2021-11-01
Desc :  Cette vue retourne les transactions aggrérés pour la lignes d'affaire VI (Avec les 3 sous-code de filiale VI, IAE et USL) 
Changements :
    - Pierre Cusson, 2021-11-08 : Standardisation des colonnes ajout ajout du SUM / GROUP BY pour réduire le volume de transactions
===========================================================================================================================*/
SELECT 
    CODE_LOB as Code_LOB,
	ACCOUNTING_PERIOD as PeriodeComptable,
	LEDGER_NAME as Journal,
    MD_SYSTEM_SOURCE as Source,
	SYSTEMESOURCE as SystemeSource,
	IFNULL(ACCOUNTING_ENTRY_TYPE, '') as TypeEntree,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ENTITY as Entite,
	NATURE as Nature,
	COST_CENTER as CentreCout,
	INTERCO as Interco,
	LOB as LigneAffaire,
	PRODUCT as Produit,
	PARTICIPATION as Participation,
	GEOGRAPHY as Geographie,
	PERIODICITY as Periodicite,
	ORIGIN as Origine,
	PROJECT as Projet,
	FUTUR1 as Futur1,
	FUTUR2 as Futur2,
	SUM(DEBIT) as Debit,
	SUM(CREDIT) as Credit,
	SUM(SOLDE) as Solde,
    Variable as Variable_CSM,
    Custom_Dim_1,
    Custom_Dim_2
from DB_CTB_DEV_DM.CTB_DEV.V_TRANSACTIONS_BY_LOB
where CODE_LOB in ('VI-VI','VI-IAE','USL') 
    AND IFRS17_Unique_Flag = 1      -- Retourne le détails de AHCS selon les requis IFRS17 et les compléments des écritures manuelles du GL
    AND date_from_parts(left(PeriodeComptable,4),right(PeriodeComptable,2),01) -- PeriodeComptable as a date must be between current_date and date -24 months
        between  date_from_parts(date_part(year,dateadd(month, -24, current_date())),date_part(month,dateadd(month, -24, current_date())),01) and date_from_parts(date_part(year, current_date()),date_part(month, current_date()),01)
GROUP BY 
    CODE_LOB,
	ACCOUNTING_PERIOD,
	LEDGER_NAME,
    MD_SYSTEM_SOURCE,
	SYSTEMESOURCE,
	ACCOUNTING_ENTRY_TYPE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
    Variable,
    Custom_Dim_1,
    Custom_Dim_2;
create or replace schema CTB;

create or replace TABLE DUMMY (
	DUMMY VARCHAR(10)
);
create or replace TABLE GL_FISCAL_PERIOD_EXPORT (
	CALENDRIER VARCHAR(50),
	NOMPERIODE VARCHAR(50),
	ANNEPERIODE NUMBER(38,0),
	DATEDEBUTPERIODE DATE,
	DATEFINPERIODE DATE,
	TRIMESTREPERIODE NUMBER(38,0),
	TYPEPERIODE VARCHAR(50),
	DESCRIPTIONTYPEPERIODE VARCHAR(250)
);
create or replace TABLE GL_LEDGER_EXPORT (
	CURRENCYCURRENCYCODE VARCHAR(30),
	LEDGERDESCRIPTION VARCHAR(100),
	LEDGERID VARCHAR(20),
	LEDGERLEDGERCATEGORYCODE VARCHAR(240),
	LEDGERNAME VARCHAR(30),
	LEDGERSHORTNAME VARCHAR(240)
);
create or replace TABLE LOB_FINPERIODE_EXPORT_CIS_CTL (
	DATEFINPERIODE DATE,
	PRODUCT VARCHAR(16777216),
	VARIABLE VARCHAR(16777216),
	DEBIT VARCHAR(16777216),
	CREDIT VARCHAR(16777216),
	SOLDE VARCHAR(16777216),
	ACCOUNTING_PERIOD VARCHAR(16777216)
);
create or replace TABLE TRANSACTIONS (
	HK_LINK VARCHAR(64) NOT NULL COMMENT 'HaskKey de la transactions original. Soit de GL ou de AHCS',
	MD_HASHDIFF VARCHAR(64) NOT NULL COMMENT 'Clé de comparaison pour historisation. Utilisé si les valeurs de références complémentaires changent dans le temps',
	MD_CREATION_DATE TIMESTAMP_NTZ(9),
	MD_SYSTEM_SOURCE VARCHAR(200) NOT NULL COMMENT 'Indique si la transactions provient de la table de GL ou de AHCS (auxiliaire)',
	ACCOUNTING_PERIOD VARCHAR(256),
	SYSTEMESOURCE VARCHAR(256) COMMENT 'Code auxiliaire',
	ID_PRIMAIRE VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_SECONDAIRE VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_RECLAMATION VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_REASSURANCE VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_COMPLEMENT VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_001 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_002 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_003 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_004 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_005 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ACCOUNTING_ENTRY_TYPE VARCHAR(256),
	LEDGER_NAME VARCHAR(256),
	ENTITY VARCHAR(200) COMMENT 'Segment de la charte comptable',
	NATURE VARCHAR(100) COMMENT 'Segment de la charte comptable',
	COST_CENTER VARCHAR(200) COMMENT 'Segment de la charte comptable',
	INTERCO VARCHAR(200) COMMENT 'Segment de la charte comptable',
	LOB VARCHAR(200) COMMENT 'Segment de la charte comptable',
	PRODUCT VARCHAR(200) COMMENT 'Segment de la charte comptable',
	PARTICIPATION VARCHAR(200) COMMENT 'Segment de la charte comptable',
	GEOGRAPHY VARCHAR(200) COMMENT 'Segment de la charte comptable',
	PERIODICITY VARCHAR(200) COMMENT 'Segment de la charte comptable',
	ORIGIN VARCHAR(200) COMMENT 'Segment de la charte comptable',
	PROJECT VARCHAR(200) COMMENT 'Segment de la charte comptable',
	FUTUR1 VARCHAR(200) COMMENT 'Segment de la charte comptable',
	FUTUR2 VARCHAR(200) COMMENT 'Segment de la charte comptable',
	DEBIT NUMBER(38,6),
	CREDIT NUMBER(38,6),
	SOLDE NUMBER(38,6),
	CURRENTVERSION NUMBER(1,0) DEFAULT 1,
	primary key (MD_SYSTEM_SOURCE, HK_LINK, MD_HASHDIFF)
);
create or replace TABLE V_REPORTING_PERIODS (
	NOMPERIODE VARCHAR(256)
);
create or replace view V_EXPORT_DATA_IAAH(
	ACCOUNTING_PERIOD,
	SYSTEMESOURCE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ACCOUNTING_ENTRY_TYPE,
	LEDGER_NAME,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
	VARIABLE,
	CUSTOM_DIM_1,
	DEBIT,
	CREDIT,
	SOLDE
) as (

WITH 

cte_lob AS (
-- Cette section doit être remplacée pour reflété le LOB a extraire)
SELECT 'IAAH' AS "LOB" --Mettre le LOB en LETTRE MAJUSCULE
)
  
,cte_ahcs_last
as
(
    -- Retourne la dernière version d'une transaction, dans les cas ou un changement de références complémentaires aurait affecté une transaction déjà existante.
    SELECT *,
    IFF(ROW_NUMBER() OVER (PARTITION BY MD_SYSTEM_SOURCE, HK_LINK ORDER BY MD_CREATION_DATE DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS
)

  
,cte_AHCS AS
(
  -- Table principales des transactions d'auxiliaires filtrées par LOB
SELECT
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB.V_REF_MASTER_COA_RKI LobFilter ON
    UPPER(LobFilter.EXTRAITLOBKEY) = (SELECT LOB FROM cte_lob)
    AND trx.ENTITY = LobFilter.ENTITY
    AND trx.NATURE = LobFilter.Nature
    AND trx.COST_CENTER = LobFilter.COSTCENTER
    AND trx.INTERCO = LobFilter.INTERCO
    AND trx.LOB = LobFilter.LOB
    AND trx.PRODUCT = LobFilter.PRODUCT
    AND trx.PARTICIPATION = LobFilter.PARTICIPATION
    AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
    AND trx.PERIODICITY = LobFilter.PERIODICITY
    AND trx.ORIGIN = LobFilter.ORIGIN
    AND trx.PROJECT = LobFilter.PROJECT
    AND trx.FUTUR1 = LobFilter.FUTUR1
    AND trx.FUTUR2 = LobFilter.FUTUR2
    WHERE trx.SYSTEMESOURCE IN (SELECT DISTINCT Source FROM DB_CTB_DEV_DWH.CTB.V_REF_FILTRE_SYSTEMESOURCE WHERE upper(LOB)= (SELECT LOB FROM cte_lob)) 
    AND  MD_SYSTEM_SOURCE = 'AHCS'

GROUP BY 
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1)

,cte_GL AS
(
    -- Table principales des transactions de GL filtrées par LOB
SELECT
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB.V_REF_MASTER_COA_RKI LobFilter ON
    UPPER(LobFilter.EXTRAITLOBKEY) = (SELECT LOB FROM cte_lob)
    AND trx.ENTITY = LobFilter.ENTITY
    AND trx.NATURE = LobFilter.Nature
    AND trx.COST_CENTER = LobFilter.COSTCENTER
    AND trx.INTERCO = LobFilter.INTERCO
    AND trx.LOB = LobFilter.LOB
    AND trx.PRODUCT = LobFilter.PRODUCT
    AND trx.PARTICIPATION = LobFilter.PARTICIPATION
    AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
    AND trx.PERIODICITY = LobFilter.PERIODICITY
    AND trx.ORIGIN = LobFilter.ORIGIN
    AND trx.PROJECT = LobFilter.PROJECT
    AND trx.FUTUR1 = LobFilter.FUTUR1
    AND trx.FUTUR2 = LobFilter.FUTUR2
    WHERE trx.SYSTEMESOURCE NOT IN (SELECT DISTINCT Source FROM DB_CTB_DEV_DWH.CTB.V_REF_FILTRE_SYSTEMESOURCE WHERE upper(LOB)= (SELECT LOB FROM cte_lob)) 
    AND  MD_SYSTEM_SOURCE = 'GL'

GROUP BY 
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1)


,cte_union as(
Select * from cte_GL
union
Select * from cte_AHCS)
  
Select * from cte_union);
create or replace view V_EXPORT_DATA_VI(
	ACCOUNTING_PERIOD,
	SYSTEMESOURCE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ACCOUNTING_ENTRY_TYPE,
	LEDGER_NAME,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
	VARIABLE,
	CUSTOM_DIM_1,
	DEBIT,
	CREDIT,
	SOLDE
) as (

WITH 

cte_lob AS (
-- Cette section doit être remplacée pour reflété le LOB a extraire)
SELECT 'VI' AS "LOB" --Mettre le LOB en LETTRE MAJUSCULE
)
  
,cte_ahcs_last
as
(
    -- Retourne la dernière version d'une transaction, dans les cas ou un changement de références complémentaires aurait affecté une transaction déjà existante.
    SELECT *,
    IFF(ROW_NUMBER() OVER (PARTITION BY MD_SYSTEM_SOURCE, HK_LINK ORDER BY MD_CREATION_DATE DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS
)

  
,cte_AHCS AS
(
  -- Table principales des transactions d'auxiliaires filtrées par LOB
SELECT
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB.V_REF_MASTER_COA_RKI LobFilter ON
    UPPER(LobFilter.EXTRAITLOBKEY) = (SELECT LOB FROM cte_lob)
    AND trx.ENTITY = LobFilter.ENTITY
    AND trx.NATURE = LobFilter.Nature
    AND trx.COST_CENTER = LobFilter.COSTCENTER
    AND trx.INTERCO = LobFilter.INTERCO
    AND trx.LOB = LobFilter.LOB
    AND trx.PRODUCT = LobFilter.PRODUCT
    AND trx.PARTICIPATION = LobFilter.PARTICIPATION
    AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
    AND trx.PERIODICITY = LobFilter.PERIODICITY
    AND trx.ORIGIN = LobFilter.ORIGIN
    AND trx.PROJECT = LobFilter.PROJECT
    AND trx.FUTUR1 = LobFilter.FUTUR1
    AND trx.FUTUR2 = LobFilter.FUTUR2
    WHERE trx.SYSTEMESOURCE IN (SELECT DISTINCT Source FROM DB_CTB_DEV_DWH.CTB.V_REF_FILTRE_SYSTEMESOURCE WHERE upper(LOB)= (SELECT LOB FROM cte_lob)) 
    AND  MD_SYSTEM_SOURCE = 'AHCS'

GROUP BY 
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1)

,cte_GL AS
(
    -- Table principales des transactions de GL filtrées par LOB
SELECT
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB.V_REF_MASTER_COA_RKI LobFilter ON
    UPPER(LobFilter.EXTRAITLOBKEY) = (SELECT LOB FROM cte_lob)
    AND trx.ENTITY = LobFilter.ENTITY
    AND trx.NATURE = LobFilter.Nature
    AND trx.COST_CENTER = LobFilter.COSTCENTER
    AND trx.INTERCO = LobFilter.INTERCO
    AND trx.LOB = LobFilter.LOB
    AND trx.PRODUCT = LobFilter.PRODUCT
    AND trx.PARTICIPATION = LobFilter.PARTICIPATION
    AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
    AND trx.PERIODICITY = LobFilter.PERIODICITY
    AND trx.ORIGIN = LobFilter.ORIGIN
    AND trx.PROJECT = LobFilter.PROJECT
    AND trx.FUTUR1 = LobFilter.FUTUR1
    AND trx.FUTUR2 = LobFilter.FUTUR2
    WHERE trx.SYSTEMESOURCE NOT IN (SELECT DISTINCT Source FROM DB_CTB_DEV_DWH.CTB.V_REF_FILTRE_SYSTEMESOURCE WHERE upper(LOB)= (SELECT LOB FROM cte_lob)) 
    AND  MD_SYSTEM_SOURCE = 'GL'

GROUP BY 
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1)


,cte_union as(
Select * from cte_GL
union
Select * from cte_AHCS)
  
Select * from cte_union);
create or replace view V_GL_SOMMAIRE(
	CODE_LOB,
	PERIODE_FISCALE,
	SYSTEME_SOURCE,
	TYPE_ENTREE,
	JOURNAL,
	ENTITE,
	NATURE,
	CENTRE_COUT,
	INTERCO,
	LOB,
	PRODUIT,
	PARTICIPATION,
	GEOGRAPHIE,
	PERIODICITE,
	ORIGINE,
	PROJET,
	FUTUR1,
	FUTUR2,
	DEBIT,
	CREDIT,
	SOLDE
) as
/*
Auth:   Pierre Cusson
Date:   2021-09-28
Desc:   Cette vue donne un sommaire des transactions de GL groupé par période fiscale et par les 13 segments de la charte de compte. Elle y ajout la catégorisation du code de LOB
        Qui provient de la matrice MasterCoaRki. Cette vue sert de base pour produire les vues de consommation pour chaque LOB.
*/
SELECT 
UPPER(LobFilter.EXTRAITLOBKEY) as CODE_LOB,
trx.ACCOUNTING_PERIOD as PERIODE_FISCALE,
trx.SYSTEMESOURCE as SYSTEME_SOURCE,
trx.ACCOUNTING_ENTRY_TYPE as TYPE_ENTREE,
trx.LEDGER_NAME as JOURNAL,
trx.ENTITY as ENTITE,
trx.NATURE as NATURE,
trx.COST_CENTER as CENTRE_COUT,
trx.INTERCO as INTERCO,
trx.LOB as LOB,
trx.PRODUCT as PRODUIT,
trx.PARTICIPATION as PARTICIPATION,
trx.GEOGRAPHY as GEOGRAPHIE,
trx.PERIODICITY as PERIODICITE,
trx.ORIGIN as ORIGINE,
trx.PROJECT as PROJET,
trx.FUTUR1 as FUTUR1,
trx.FUTUR2 as FUTUR2,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB.V_REF_MASTER_COA_RKI LobFilter ON
        trx.ENTITY = LobFilter.ENTITY
        AND trx.NATURE = LobFilter.Nature
        AND trx.COST_CENTER = LobFilter.COSTCENTER
        AND trx.INTERCO = LobFilter.INTERCO
        AND trx.LOB = LobFilter.LOB
        AND trx.PRODUCT = LobFilter.PRODUCT
        AND trx.PARTICIPATION = LobFilter.PARTICIPATION
        AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
        AND trx.PERIODICITY = LobFilter.PERIODICITY
        AND trx.ORIGIN = LobFilter.ORIGIN
        AND trx.PROJECT = LobFilter.PROJECT
        AND trx.FUTUR1 = LobFilter.FUTUR1
        AND trx.FUTUR2 = LobFilter.FUTUR2
WHERE MD_SYSTEM_SOURCE = 'GL' AND CurrentVersion = 1
GROUP BY
LobFilter.EXTRAITLOBKEY,
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2;
create or replace view V_MESSAGE_ERP_LOAD(
	AUDIT_ID,
	DESCRIPTION,
	JSON_CONTENT
) as

WITH cte_Main_JSON
-- Contenu principale de l'entête du message
AS
(
SELECT 
  '1.0' AS specversion,
  'CTB.CalculCSM' AS type,
  'CTB_Staging' as source,
  'TransactionsConfirmationMAJStaging' as subject,
  'application/json' as datacontenttype,
  LEFT(current_timestamp(2)::string,23) as time,
  '0.1' as iaspecversion,
  LOWER(SPLIT_PART(CURRENT_DATABASE(), '_', 3)) AS env, -- Extrait la portion palier du nom de la BD courante
  'Topic' AS topic
)

,cte_guid
as
(
   -- Génère un GUID unique à ré-utiliser dans les clés du fichier.
   SELECT UUID_STRING() AS ID
)

,cte_erp_date
-- Contenu spécifique pour la date de dernier chargement en provenance du ERP.
-- On veut la plus petite date de la dernière batch de fichier reçu (selon le audit ID)
AS
(
SELECT  AUDIT_ID,DESCRIPTION,MIN(Start_Time) as DateImageERP FROM DB_CTB_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS   as DateImageErp
WHERE Job_Name = 'Request_CIS_CTL'  GROUP BY AUDIT_ID,DESCRIPTION
)

,cte_gl_lastdate
-- Contenu spécifique pour la date de dernière modification du GL provenant de ERP Cloud
-- Cette valeur indique à AppWorks le positionnement dans le temps du Staging pour exécuter le rapport de contrôle.
AS
(
SELECT MAX(JRNLLINELASTUPDATEDATE) as GL_LastUpdateTimestamp FROM DB_CTB_DEV_DWH.CTB.LINKTRANSACTIONNEL_GL_JOURNAL_LINE_PVO
)

,cte_ahcs_lastdate
-- Contenu spécifique pour la date de dernière modification du GL provenant de ERP Cloud
-- Cette valeur indique à AppWorks le positionnement dans le temps du Staging pour exécuter le rapport de contrôle.
AS
(
SELECT MAX(XLAHDRLASTUPDATEDATE) as AHCS_LastUpdateTimestamp FROM DB_CTB_DEV_DWH.CTB.LINKTRANSACTIONNEL_SUBLEDGER_ENTRY_LINE_PVO
)


SELECT AUDIT_ID,DESCRIPTION,OBJECT_CONSTRUCT(
  'specversion', cte_Main_JSON.specversion,
  'type', cte_Main_JSON.type,
  'source', cte_Main_JSON.source,
  'subject', cte_Main_JSON.subject,
  'datacontenttype', cte_Main_JSON.datacontenttype,
  'time', cte_Main_JSON.time,
  'iaspecversion', cte_Main_JSON.iaspecversion,
  'correlationid', cte_guid.id,
  'id', cte_guid.id,
  'env', cte_Main_JSON.env,
  'topic', cte_Main_JSON.topic,
  'data', OBJECT_CONSTRUCT(
        'DateImageErp', LEFT(cte_erp_date.DateImageERP::string,23),
        'GL_LastUpdateTimestamp', LEFT(cte_gl_lastdate.GL_LastUpdateTimestamp::string,23),
        'AHCS_LastUpdateTimestamp', LEFT(cte_ahcs_lastdate.AHCS_LastUpdateTimestamp::string,23)
        )
  ) as JSON_Content
FROM cte_Main_JSON
INNER JOIN cte_erp_date ON 1=1
INNER JOIN cte_guid ON 1=1
INNER JOIN cte_gl_lastdate ON 1=1
INNER JOIN cte_ahcs_lastdate ON 1=1;
create or replace view V_QUALITY_DM_TRANSACTIONS(
	TESTNAME,
	OBJECTNAME,
	MISSINGVALUE
) as

-- Retourne les noms de code d'auxiliaires dans correspondance dans les tables des Journal Source
SELECT DISTINCT
    'Incomplete Data' as TestName, 
    'TRANSACTIONS.ID_PRIMAIRE ==> No value found' as ObjectName, 
    '' AS MissingValue
WHERE (SELECT COUNT(*) FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS WHERE IFNULL(ID_PRIMAIRE,'') <> '') = 0

UNION

SELECT DISTINCT
    'Incomplete Data' as TestName, 
    'TRANSACTIONS.ID_SECONDAIRE ==> No value found' as ObjectName, 
    '' AS MissingValue
WHERE (SELECT COUNT(*) FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS WHERE IFNULL(ID_SECONDAIRE,'') <> '') = 0

UNION

SELECT DISTINCT
    'Incomplete Data' as TestName, 
    'TRANSACTIONS.ID_RECLAMATION ==> No value found' as ObjectName, 
    '' AS MissingValue
WHERE (SELECT COUNT(*) FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS WHERE IFNULL(ID_RECLAMATION,'') <> '') = 0

UNION

SELECT DISTINCT
    'Incomplete Data' as TestName, 
    'TRANSACTIONS.ID_REASSURANCE ==> No value found' as ObjectName, 
    '' AS MissingValue
WHERE (SELECT COUNT(*) FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS WHERE IFNULL(ID_REASSURANCE,'') <> '') = 0

UNION

SELECT DISTINCT
    'Incomplete Data' as TestName, 
    'TRANSACTIONS.ID_COMPLEMENT ==> No value found' as ObjectName, 
    '' AS MissingValue
WHERE (SELECT COUNT(*) FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS WHERE IFNULL(ID_COMPLEMENT,'') <> '') = 0

UNION

SELECT DISTINCT
    'Incomplete Data' as TestName, 
    'TRANSACTIONS.ID_MANUEL_001 ==> No value found' as ObjectName, 
    '' AS MissingValue
WHERE (SELECT COUNT(*) FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS WHERE IFNULL(ID_MANUEL_001,'') <> '') = 0;
create or replace view V_TRANSACTIONS_BY_LOB(
	HK_LINK,
	CODE_LOB,
	ACCOUNTING_PERIOD,
	MD_SYSTEM_SOURCE,
	SYSTEMESOURCE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ACCOUNTING_ENTRY_TYPE,
	LEDGER_NAME,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
	DEBIT,
	CREDIT,
	SOLDE,
	VARIABLE,
	CUSTOM_DIM_1,
	CUSTOM_DIM_2,
	IFRS17_FLAG,
	IFRS17_UNIQUE_FLAG
) as 
/* =========================================================================================================================================
Auth:   Pierre Cusson
Date:   2021-11-03
Desc:   Cette vue retourne les dernières versions des transactions de la couche Data Mart (incluant le calcul des références complémentaires).
        La logique d'assignation des codes de LOB selon les 13 segments de la charte de compte y est présente pour faciliter les filtres par lignes d'affaires.
        Elle contient aussi des flags pour permettre de filter selon le niveau de détail requis par IFRS17 et pour éviter de retourner des montants doublés de AHCS et GL.
===========================================================================================================================================*/

    WITH cte_ifrs17 as 
    (
      -- Extrait tous les codes d'auxiliaires dont l'extractions des transactions doit se faire au niveau AHCS pour les requis de IFRS17
      SELECT JRNLSRCJESOURCEKEY as CODE_AUXILIAIRE FROM DB_CTB_DEV_DWH.CTB.LINKTRANSACTIONNEL_GL_JOURNAL_SOURCE_BPVO WHERE TYPE_SOURCE = 'AHCS'
    )
    
    SELECT 
    HK_LINK,
    -- Application des règlges d'affaires qui affecte un code de LOB à une ligne de transactions. La règle principale vient de l'assignation du fichier MasterCOA_RKI, mais d'autres règles hard-codé peuvent être requises.
    CASE 
        WHEN UPPER(LobFilter.ExtraitLobKey) = 'VI' AND IFNULL(SYSTEMESOURCE,'') = 'A010 MEC' THEN 'VI-IAE'
        WHEN UPPER(LobFilter.ExtraitLobKey) = 'VI' AND IFNULL(SYSTEMESOURCE,'') <> 'A010 MEC' THEN 'VI-VI'
        ELSE UPPER(IFNULL(LobFilter.ExtraitLobKey,''))
    END as CODE_LOB,
    trx.ACCOUNTING_PERIOD,
    trx.MD_SYSTEM_SOURCE,
    IFNULL(trx.SYSTEMESOURCE,'') AS SYSTEMESOURCE,
    IFNULL(trx.ID_PRIMAIRE,'') AS ID_PRIMAIRE,
    IFNULL(trx.ID_SECONDAIRE,'') AS ID_SECONDAIRE,
    IFNULL(trx.ID_RECLAMATION,'') AS ID_RECLAMATION,
    IFNULL(trx.ID_REASSURANCE,'') AS ID_REASSURANCE,
    IFNULL(trx.ID_COMPLEMENT,'') AS ID_COMPLEMENT,
    IFNULL(trx.ID_MANUEL_001,'') AS ID_MANUEL_001,
    IFNULL(trx.ID_MANUEL_002,'') AS ID_MANUEL_002,
    IFNULL(trx.ID_MANUEL_003,'') AS ID_MANUEL_003,
    IFNULL(trx.ID_MANUEL_004,'') AS ID_MANUEL_004,
    IFNULL(trx.ID_MANUEL_005,'') AS ID_MANUEL_005,
    trx.ACCOUNTING_ENTRY_TYPE,
    trx.LEDGER_NAME,
    trx.ENTITY,
    trx.NATURE,
    trx.COST_CENTER,
    trx.INTERCO,
    trx.LOB,
    trx.PRODUCT,
    trx.PARTICIPATION,
    trx.GEOGRAPHY,
    trx.PERIODICITY,
    trx.ORIGIN,
    trx.PROJECT,
    trx.FUTUR1,
    trx.FUTUR2,
    trx.DEBIT,
    trx.CREDIT,
    trx.SOLDE,
    IFNULL(LobFilter.VARIABLE,'') AS VARIABLE, 
    IFNULL(LobFilter.CUSTOM_DIM_1,'') AS CUSTOM_DIM_1, 
    IFNULL(LobFilter.CUSTOM_DIM_2,'') AS CUSTOM_DIM_2,
    CASE WHEN cte_ifrs17.code_auxiliaire IS NOT NULL THEN 1 ELSE 0 END as IFRS17_Flag,     -- Indique 1 si le code d'auxiliaires à un mapping UDC de configuré (donc requiert le détail de IFRS17)
    CASE WHEN 
        (trx.MD_SYSTEM_SOURCE = 'AHCS' AND IFRS17_Flag = 1)
        OR
        (trx.MD_SYSTEM_SOURCE = 'GL' AND IFRS17_Flag = 0)
        THEN 1
        ELSE 0
        END as IFRS17_Unique_Flag   -- Retourne un flag 0/1 selon le niveau d'extraction requis. Les codes d'auxiliaires IFRS17 doivent être extract de AHCS, les codes d'auxiliaires non-IFRS17 doivent être extrait du GL
                                    -- La combinaison des transactions de AHCS et GL doit donner le montant total sans double-montant.
    FROM DB_CTB_DEV_DM.CTB.TRANSACTIONS trx
    LEFT JOIN cte_ifrs17 ON trx.systemesource = cte_ifrs17.code_auxiliaire
    LEFT JOIN DB_CTB_DEV_DWH.CTB.V_REF_MASTER_COA_RKI LobFilter ON
        trx.ENTITY = LobFilter.ENTITY
        AND trx.NATURE = LobFilter.Nature
        AND trx.COST_CENTER = LobFilter.COSTCENTER
        AND trx.INTERCO = LobFilter.INTERCO
        AND trx.LOB = LobFilter.LOB
        AND trx.PRODUCT = LobFilter.PRODUCT
        AND trx.PARTICIPATION = LobFilter.PARTICIPATION
        AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
        AND trx.PERIODICITY = LobFilter.PERIODICITY
        AND trx.ORIGIN = LobFilter.ORIGIN
        AND trx.PROJECT = LobFilter.PROJECT
        AND trx.FUTUR1 = LobFilter.FUTUR1
        AND trx.FUTUR2 = LobFilter.FUTUR2
     WHERE CurrentVersion = 1       -- Ce flag gère l'historisation des transactions dans le cas ou une valeur de réréfence complémentaire pourrait changer dans le temps. On veut uniquement lire la version la plus récente.
;
create or replace view V_TRANSACTIONS_SUMMARY(
	TYPE_STATS,
	MD_SYSTEM_SOURCE,
	LEDGER_NAME,
	SYSTEMESOURCE,
	ACCOUNTING_PERIOD,
	GROUPE,
	GROUPE_VALEUR,
	NB_LIGNE,
	TOTAL_DEBIT,
	TOTAL_CREDIT
) as 

WITH cte_transaction_last
as
(
    -- Retourne la dernière version d'une transaction, dans les cas ou un changement de références complémentaires aurait affecté une transaction déjà existante.
    SELECT *
    FROM DB_CTB_DEV_DM.CTB.V_TRANSACTIONS_BY_LOB
)


-- Stats pour la période
SELECT 'STATS_PAR_PÉRIODE' as TYPE_STATS, MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, 'ACCOUNTING_PERIOD' as GROUPE, ACCOUNTING_PERIOD as GROUPE_VALEUR, COUNT(*) as NB_LIGNE, SUM(DEBIT) AS Total_Debit, SUM(Credit) as Total_credit
FROM cte_transaction_last
GROUP BY MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD

UNION

-- Stats par ENTITY
SELECT 'STATS_PAR_ENTITÉ' as TYPE_STATS, MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, 'ENTITY' as GROUPE, ENTITY as GROUPE_VALEUR, COUNT(*) as NB_LIGNE, SUM(DEBIT) AS Total_Debit, SUM(Credit) as Total_credit
FROM cte_transaction_last
GROUP BY MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, ENTITY

UNION

-- Stats par NATURE
SELECT 'STATS_PAR_NATURE' as Summary_Type, MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, 'NATURE' as GROUPE, NATURE as GROUPE_VALEUR, COUNT(*) as NB_LIGNE, SUM(DEBIT) AS Total_Debit, SUM(Credit) as Total_credit
FROM cte_transaction_last
GROUP BY MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, NATURE

UNION

-- Stats par COST_CENTER
SELECT 'STATS_PAR_COST_CENTER' as Summary_Type, MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, 'COST_CENTER' as GROUPE, COST_CENTER as GROUPE_VALEUR, COUNT(*) as NB_LIGNE, SUM(DEBIT) AS Total_Debit, SUM(Credit) as Total_credit
FROM cte_transaction_last
GROUP BY MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, COST_CENTER

UNION

-- Stats par LOB
SELECT 'STATS_PAR_LOB' as Summary_Type, MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, 'LOB' as GROUPE, LOB as GROUPE_VALEUR, COUNT(*) as NB_LIGNE, SUM(DEBIT) AS Total_Debit, SUM(Credit) as Total_credit
FROM cte_transaction_last
GROUP BY MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, LOB

UNION

-- Stats par PRODUCT
SELECT 'STATS_PAR_PRODUCT' as Summary_Type, MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, 'PRODUCT' as GROUPE, PRODUCT as GROUPE_VALEUR, COUNT(*) as NB_LIGNE, SUM(DEBIT) AS Total_Debit, SUM(Credit) as Total_credit
FROM cte_transaction_last
GROUP BY MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, PRODUCT

UNION

-- Stats par CODE_LOB
SELECT 'STATS_PAR_CODE_LOB' as Summary_Type, MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, 'CODE_LOB' as GROUPE, CODE_LOB as GROUPE_VALEUR, COUNT(*) as NB_LIGNE, SUM(DEBIT) AS Total_Debit, SUM(Credit) as Total_credit
FROM cte_transaction_last
GROUP BY MD_SYSTEM_SOURCE, LEDGER_NAME, SYSTEMESOURCE, ACCOUNTING_PERIOD, CODE_LOB;
create or replace view V_TRANSACTIONS_VALIDATION(
	SYSTEMESOURCE,
	LEDGER_NAME,
	ACCOUNTING_ENTRY_TYPE,
	ACCOUNTING_PERIOD,
	ENTITY,
	NATURE,
	NB_SLALINES,
	ID_PRIMAIRE_COUNT,
	ID_SECONDAIRE_COUNT,
	ID_RECLAMATION_COUNT,
	ID_REASSURANCE_COUNT,
	ID_COMPLEMENT_COUNT,
	ID_MANUEL_001_COUNT,
	ID_MANUEL_002_COUNT,
	ID_MANUEL_003_COUNT,
	ID_MANUEL_004_COUNT,
	ID_MANUEL_005_COUNT,
	DEBIT,
	CREDIT
) as (
SELECT 
  SystemeSource, 
  ledger_name, 
  Accounting_Entry_Type, 
  ACCOUNTING_PERIOD, 
  Entity, 
  Nature,
  COUNT(*) as NB_SLALINES,
  SUM(CASE WHEN ID_PRIMAIRE <> '' THEN 1 ELSE 0 END) as ID_PRIMAIRE_Count,
  SUM(CASE WHEN ID_SECONDAIRE <> '' THEN 1 ELSE 0 END) as ID_SECONDAIRE_Count,
  SUM(CASE WHEN ID_RECLAMATION <> '' THEN 1 ELSE 0 END) as ID_RECLAMATION_Count,
  SUM(CASE WHEN ID_REASSURANCE <> '' THEN 1 ELSE 0 END) as ID_REASSURANCE_Count,
  SUM(CASE WHEN ID_COMPLEMENT <> '' THEN 1 ELSE 0 END) as ID_COMPLEMENT_Count,
  SUM(CASE WHEN ID_MANUEL_001 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_001_Count,
  SUM(CASE WHEN ID_MANUEL_002 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_002_Count,
  SUM(CASE WHEN ID_MANUEL_003 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_003_Count,
  SUM(CASE WHEN ID_MANUEL_004 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_004_Count,
  SUM(CASE WHEN ID_MANUEL_005 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_005_Count,
  SUM(DEBIT) as Debit,
  SUM(Credit) as Credit
FROM DB_CTB_dev_DM.CTB.TRANSACTIONS
GROUP BY SystemeSource, ledger_name, Accounting_Entry_Type, ACCOUNTING_PERIOD, Entity, Nature
ORDER BY SystemeSource, ledger_name, Accounting_Entry_Type, ACCOUNTING_PERIOD, Entity, Nature
);
CREATE OR REPLACE FUNCTION "F_EXPORT_LOB_DATA"("PERIOD" VARCHAR(16777216), "SUB_LOB_VALUE" VARCHAR(16777216))
RETURNS TABLE ("DATEFINPERIODE" DATE, "PRODUCT" VARCHAR(16777216), "VARIABLE" VARCHAR(16777216), "DEBIT" VARCHAR(16777216), "CREDIT" VARCHAR(16777216), "SOLDE" VARCHAR(16777216), "ACCOUNTING_PERIOD" VARCHAR(16777216))
LANGUAGE SQL
AS '
    select * from DB_CTB_DEV_DM.CTB.LOB_FINPERIODE_Export_CIS_CTL
    ';
CREATE OR REPLACE FUNCTION "TEST"("ID" NUMBER(38,0))
RETURNS VARCHAR(40)
LANGUAGE SQL
AS 'IFF(id=10, sha1(''ishan'') ,''jithu'')';
create or replace schema CTB_DEV;

create or replace sequence SEQ1 start with 1 increment by 1;
create or replace TABLE DUMMY (
	DUMMY VARCHAR(10)
);
create or replace TABLE GL_FISCAL_PERIOD_EXPORT (
	CALENDRIER VARCHAR(50),
	NOMPERIODE VARCHAR(50),
	ANNEPERIODE NUMBER(38,0),
	DATEDEBUTPERIODE DATE,
	DATEFINPERIODE DATE,
	TRIMESTREPERIODE NUMBER(38,0),
	TYPEPERIODE VARCHAR(50),
	DESCRIPTIONTYPEPERIODE VARCHAR(250)
);
create or replace TABLE GL_LEDGER_EXPORT (
	CURRENCYCURRENCYCODE VARCHAR(30),
	LEDGERDESCRIPTION VARCHAR(100),
	LEDGERID VARCHAR(20),
	LEDGERLEDGERCATEGORYCODE VARCHAR(240),
	LEDGERNAME VARCHAR(30),
	LEDGERSHORTNAME VARCHAR(240)
);
create or replace TABLE ROWS_FILTERING_BY_LOB (
	ROLE_NAME VARCHAR(100),
	ENV VARCHAR(10),
	CODE_LOB_LIST ARRAY
);
create or replace TABLE TRANSACTIONS cluster by (ACCOUNTING_PERIOD)(
	HK_LINK VARCHAR(64) NOT NULL COMMENT 'HaskKey de la transactions original. Soit de GL ou de AHCS',
	MD_HASHDIFF VARCHAR(64) NOT NULL COMMENT 'Clé de comparaison pour historisation. Utilisé si les valeurs de références complémentaires changent dans le temps',
	MD_CREATION_DATE TIMESTAMP_NTZ(9),
	MD_SYSTEM_SOURCE VARCHAR(200) NOT NULL COMMENT 'Indique si la transactions provient de la table de GL ou de AHCS (auxiliaire)',
	ACCOUNTING_PERIOD VARCHAR(256),
	SYSTEMESOURCE VARCHAR(256) COMMENT 'Code auxiliaire',
	ID_PRIMAIRE VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_SECONDAIRE VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_RECLAMATION VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_REASSURANCE VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_COMPLEMENT VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_001 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_002 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_003 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_004 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ID_MANUEL_005 VARCHAR(16777216) COMMENT 'Référence complémentaire',
	ACCOUNTING_ENTRY_TYPE VARCHAR(256),
	LEDGER_NAME VARCHAR(256),
	ENTITY VARCHAR(200) COMMENT 'Segment de la charte comptable',
	NATURE VARCHAR(100) COMMENT 'Segment de la charte comptable',
	COST_CENTER VARCHAR(200) COMMENT 'Segment de la charte comptable',
	INTERCO VARCHAR(200) COMMENT 'Segment de la charte comptable',
	LOB VARCHAR(200) COMMENT 'Segment de la charte comptable',
	PRODUCT VARCHAR(200) COMMENT 'Segment de la charte comptable',
	PARTICIPATION VARCHAR(200) COMMENT 'Segment de la charte comptable',
	GEOGRAPHY VARCHAR(200) COMMENT 'Segment de la charte comptable',
	PERIODICITY VARCHAR(200) COMMENT 'Segment de la charte comptable',
	ORIGIN VARCHAR(200) COMMENT 'Segment de la charte comptable',
	PROJECT VARCHAR(200) COMMENT 'Segment de la charte comptable',
	FUTUR1 VARCHAR(200) COMMENT 'Segment de la charte comptable',
	FUTUR2 VARCHAR(200) COMMENT 'Segment de la charte comptable',
	DEBIT NUMBER(38,6),
	CREDIT NUMBER(38,6),
	SOLDE NUMBER(38,6),
	CURRENTVERSION NUMBER(1,0) DEFAULT 1,
	primary key (MD_SYSTEM_SOURCE, HK_LINK, MD_HASHDIFF)
);
create or replace view V_EXPORT_DATA_IAAH(
	ACCOUNTING_PERIOD,
	SYSTEMESOURCE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ACCOUNTING_ENTRY_TYPE,
	LEDGER_NAME,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
	VARIABLE,
	CUSTOM_DIM_1,
	DEBIT,
	CREDIT,
	SOLDE
) as (

WITH 

cte_lob AS (
-- Cette section doit être remplacée pour reflété le LOB a extraire)
SELECT 'IAAH' AS "LOB" --Mettre le LOB en LETTRE MAJUSCULE
)
  
,cte_ahcs_last
as
(
    -- Retourne la dernière version d'une transaction, dans les cas ou un changement de références complémentaires aurait affecté une transaction déjà existante.
    SELECT *,
    IFF(ROW_NUMBER() OVER (PARTITION BY MD_SYSTEM_SOURCE, HK_LINK ORDER BY MD_CREATION_DATE DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_CTB_DEV_DM.CTB_DEV.TRANSACTIONS
)

  
,cte_AHCS AS
(
  -- Table principales des transactions d'auxiliaires filtrées par LOB
SELECT
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM cte_ahcs_last trx
INNER JOIN DB_CTB_DEV_DWH.CTB_DEV.V_REF_MASTER_COA_RKI LobFilter ON
    UPPER(LobFilter.EXTRAITLOBKEY) = (SELECT LOB FROM cte_lob)
    AND trx.ENTITY = LobFilter.ENTITY
    AND trx.NATURE = LobFilter.Nature
    AND trx.COST_CENTER = LobFilter.COSTCENTER
    AND trx.INTERCO = LobFilter.INTERCO
    AND trx.LOB = LobFilter.LOB
    AND trx.PRODUCT = LobFilter.PRODUCT
    AND trx.PARTICIPATION = LobFilter.PARTICIPATION
    AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
    AND trx.PERIODICITY = LobFilter.PERIODICITY
    AND trx.ORIGIN = LobFilter.ORIGIN
    AND trx.PROJECT = LobFilter.PROJECT
    AND trx.FUTUR1 = LobFilter.FUTUR1
    AND trx.FUTUR2 = LobFilter.FUTUR2
    WHERE trx.SYSTEMESOURCE IN (SELECT DISTINCT Source FROM DB_CTB_DEV_DWH.CTB_DEV.V_REF_FILTRE_SYSTEMESOURCE WHERE upper(LOB)= (SELECT LOB FROM cte_lob)) 
    AND  MD_SYSTEM_SOURCE = 'AHCS'
    AND IND_LAST_ROW = 1    -- retourne uniquement la dernière version d'une transactions selon la clé HK_LINK.

GROUP BY 
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1)

,cte_GL AS
(
    -- Table principales des transactions de GL filtrées par LOB
SELECT
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB_DEV.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB.V_REF_MASTER_COA_RKI LobFilter ON
    UPPER(LobFilter.EXTRAITLOBKEY) = (SELECT LOB FROM cte_lob)
    AND trx.ENTITY = LobFilter.ENTITY
    AND trx.NATURE = LobFilter.Nature
    AND trx.COST_CENTER = LobFilter.COSTCENTER
    AND trx.INTERCO = LobFilter.INTERCO
    AND trx.LOB = LobFilter.LOB
    AND trx.PRODUCT = LobFilter.PRODUCT
    AND trx.PARTICIPATION = LobFilter.PARTICIPATION
    AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
    AND trx.PERIODICITY = LobFilter.PERIODICITY
    AND trx.ORIGIN = LobFilter.ORIGIN
    AND trx.PROJECT = LobFilter.PROJECT
    AND trx.FUTUR1 = LobFilter.FUTUR1
    AND trx.FUTUR2 = LobFilter.FUTUR2
    WHERE trx.SYSTEMESOURCE NOT IN (SELECT DISTINCT Source FROM DB_CTB_DEV_DWH.CTB_DEV.V_REF_FILTRE_SYSTEMESOURCE WHERE upper(LOB)= (SELECT LOB FROM cte_lob)) 
    AND  MD_SYSTEM_SOURCE = 'GL'

GROUP BY 
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1)


,cte_union as(
Select * from cte_GL
union
Select * from cte_AHCS)
  
Select * from cte_union);
create or replace view V_EXPORT_DATA_VI(
	ACCOUNTING_PERIOD,
	SYSTEMESOURCE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ACCOUNTING_ENTRY_TYPE,
	LEDGER_NAME,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
	VARIABLE,
	CUSTOM_DIM_1,
	DEBIT,
	CREDIT,
	SOLDE
) as (

WITH 

cte_lob AS (
-- Cette section doit être remplacée pour reflété le LOB a extraire)
SELECT 'VI' AS "LOB" --Mettre le LOB en LETTRE MAJUSCULE
)
  
,cte_ahcs_last
as
(
    -- Retourne la dernière version d'une transaction, dans les cas ou un changement de références complémentaires aurait affecté une transaction déjà existante.
    SELECT *,
    IFF(ROW_NUMBER() OVER (PARTITION BY MD_SYSTEM_SOURCE, HK_LINK ORDER BY MD_CREATION_DATE DESC) = 1,1,0) IND_LAST_ROW
    FROM DB_CTB_DEV_DM.CTB_DEV.TRANSACTIONS
)

  
,cte_AHCS AS
(
  -- Table principales des transactions d'auxiliaires filtrées par LOB
SELECT
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB_DEV.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB_DEV.V_REF_MASTER_COA_RKI LobFilter ON
    UPPER(LobFilter.EXTRAITLOBKEY) = (SELECT LOB FROM cte_lob)
    AND trx.ENTITY = LobFilter.ENTITY
    AND trx.NATURE = LobFilter.Nature
    AND trx.COST_CENTER = LobFilter.COSTCENTER
    AND trx.INTERCO = LobFilter.INTERCO
    AND trx.LOB = LobFilter.LOB
    AND trx.PRODUCT = LobFilter.PRODUCT
    AND trx.PARTICIPATION = LobFilter.PARTICIPATION
    AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
    AND trx.PERIODICITY = LobFilter.PERIODICITY
    AND trx.ORIGIN = LobFilter.ORIGIN
    AND trx.PROJECT = LobFilter.PROJECT
    AND trx.FUTUR1 = LobFilter.FUTUR1
    AND trx.FUTUR2 = LobFilter.FUTUR2
    WHERE trx.SYSTEMESOURCE IN (SELECT DISTINCT Source FROM DB_CTB_DEV_DWH.CTB_DEV.V_REF_FILTRE_SYSTEMESOURCE WHERE upper(LOB)= (SELECT LOB FROM cte_lob)) 
    AND  MD_SYSTEM_SOURCE = 'AHCS'

GROUP BY 
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1)

,cte_GL AS
(
    -- Table principales des transactions de GL filtrées par LOB
SELECT
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB_DEV.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB_DEV.V_REF_MASTER_COA_RKI LobFilter ON
    UPPER(LobFilter.EXTRAITLOBKEY) = (SELECT LOB FROM cte_lob)
    AND trx.ENTITY = LobFilter.ENTITY
    AND trx.NATURE = LobFilter.Nature
    AND trx.COST_CENTER = LobFilter.COSTCENTER
    AND trx.INTERCO = LobFilter.INTERCO
    AND trx.LOB = LobFilter.LOB
    AND trx.PRODUCT = LobFilter.PRODUCT
    AND trx.PARTICIPATION = LobFilter.PARTICIPATION
    AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
    AND trx.PERIODICITY = LobFilter.PERIODICITY
    AND trx.ORIGIN = LobFilter.ORIGIN
    AND trx.PROJECT = LobFilter.PROJECT
    AND trx.FUTUR1 = LobFilter.FUTUR1
    AND trx.FUTUR2 = LobFilter.FUTUR2
    WHERE trx.SYSTEMESOURCE NOT IN (SELECT DISTINCT Source FROM DB_CTB_DEV_DWH.CTB_DEV.V_REF_FILTRE_SYSTEMESOURCE WHERE upper(LOB)= (SELECT LOB FROM cte_lob)) 
    AND  MD_SYSTEM_SOURCE = 'GL'

GROUP BY 
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ID_PRIMAIRE,
trx.ID_SECONDAIRE,
trx.ID_RECLAMATION,
trx.ID_REASSURANCE,
trx.ID_COMPLEMENT,
trx.ID_MANUEL_001,
trx.ID_MANUEL_002,
trx.ID_MANUEL_003,
trx.ID_MANUEL_004,
trx.ID_MANUEL_005,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2,
LobFilter.VARIABLE,
LobFilter.CUSTOM_DIM_1)


,cte_union as(
Select * from cte_GL
union
Select * from cte_AHCS)
  
Select * from cte_union);
create or replace view V_GL_SOMMAIRE(
	CODE_LOB,
	PERIODE_FISCALE,
	SYSTEME_SOURCE,
	TYPE_ENTREE,
	JOURNAL,
	ENTITE,
	NATURE,
	CENTRE_COUT,
	INTERCO,
	LOB,
	PRODUIT,
	PARTICIPATION,
	GEOGRAPHIE,
	PERIODICITE,
	ORIGINE,
	PROJET,
	FUTUR1,
	FUTUR2,
	DEBIT,
	CREDIT,
	SOLDE
) as
/*
Auth:   Pierre Cusson
Date:   2021-09-28
Desc:   Cette vue donne un sommaire des transactions de GL groupé par période fiscale et par les 13 segments de la charte de compte. Elle y ajout la catégorisation du code de LOB
        Qui provient de la matrice MasterCoaRki. Cette vue sert de base pour produire les vues de consommation pour chaque LOB.
*/
SELECT 
UPPER(LobFilter.EXTRAITLOBKEY) as CODE_LOB,
trx.ACCOUNTING_PERIOD as PERIODE_FISCALE,
trx.SYSTEMESOURCE as SYSTEME_SOURCE,
trx.ACCOUNTING_ENTRY_TYPE as TYPE_ENTREE,
trx.LEDGER_NAME as JOURNAL,
trx.ENTITY as ENTITE,
trx.NATURE as NATURE,
trx.COST_CENTER as CENTRE_COUT,
trx.INTERCO as INTERCO,
trx.LOB as LOB,
trx.PRODUCT as PRODUIT,
trx.PARTICIPATION as PARTICIPATION,
trx.GEOGRAPHY as GEOGRAPHIE,
trx.PERIODICITY as PERIODICITE,
trx.ORIGIN as ORIGINE,
trx.PROJECT as PROJET,
trx.FUTUR1 as FUTUR1,
trx.FUTUR2 as FUTUR2,
SUM(trx.DEBIT) AS DEBIT,
SUM(trx.CREDIT) AS CREDIT,
SUM(trx.SOLDE) AS SOLDE
FROM DB_CTB_DEV_DM.CTB_DEV.TRANSACTIONS trx
INNER JOIN DB_CTB_DEV_DWH.CTB_DEV.V_REF_MASTER_COA_RKI LobFilter ON
        trx.ENTITY = LobFilter.ENTITY
        AND trx.NATURE = LobFilter.Nature
        AND trx.COST_CENTER = LobFilter.COSTCENTER
        AND trx.INTERCO = LobFilter.INTERCO
        AND trx.LOB = LobFilter.LOB
        AND trx.PRODUCT = LobFilter.PRODUCT
        AND trx.PARTICIPATION = LobFilter.PARTICIPATION
        AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
        AND trx.PERIODICITY = LobFilter.PERIODICITY
        AND trx.ORIGIN = LobFilter.ORIGIN
        AND trx.PROJECT = LobFilter.PROJECT
        AND trx.FUTUR1 = LobFilter.FUTUR1
        AND trx.FUTUR2 = LobFilter.FUTUR2
WHERE MD_SYSTEM_SOURCE = 'GL' AND CurrentVersion = 1
GROUP BY
LobFilter.EXTRAITLOBKEY,
trx.ACCOUNTING_PERIOD,
trx.SYSTEMESOURCE,
trx.ACCOUNTING_ENTRY_TYPE,
trx.LEDGER_NAME,
trx.ENTITY,
trx.NATURE,
trx.COST_CENTER,
trx.INTERCO,
trx.LOB,
trx.PRODUCT,
trx.PARTICIPATION,
trx.GEOGRAPHY,
trx.PERIODICITY,
trx.ORIGIN,
trx.PROJECT,
trx.FUTUR1,
trx.FUTUR2;
create or replace view V_MESSAGE_EF_EXPORT(
	AUDIT_ID,
	DESCRIPTION,
	JSON_CONTENT
) as

WITH cte_Main_JSON
-- Contenu principale de l'entête du message
AS
(
SELECT 
  '1.0' AS specversion,
  'CTB.CalculCSM' AS type,
  'Informatica' as source,
  'ExportationStagingVersEFTerminee' as subject,
  'application/json' as datacontenttype,
  LEFT(current_timestamp(2)::string,23) as time,
  '0.1' as iaspecversion,
  LOWER(SPLIT_PART(CURRENT_DATABASE(), '_', 3)) AS env, -- Extrait la portion palier du nom de la BD courante
  'Topic' AS topic
),

cte_guid
as
(
   -- Génère un GUID unique à ré-utiliser dans les clés du fichier.
   SELECT UUID_STRING() AS ID
),

cte_ef_dateFinPeriode
-- date de fin de periode selon le code de la periode dans le fichier export
AS
(
SELECT DISTINCT AUDIT_ID,DESCRIPTION,
       SPLIT_PART(DESCRIPTION,'|',2) AS LOB,
       DATEFINPERIODE AS DateFinPeriode
FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXTRACTIONS
INNER JOIN DB_CTB_DEV_DM.CTB_DEV.GL_FISCAL_PERIOD_EXPORT -- Doit etre changer pas la table DM
ON SPLIT_PART(DESCRIPTION,'|',3) = NOMPERIODE
)
 
SELECT AUDIT_ID,DESCRIPTION, OBJECT_CONSTRUCT(
  'specversion', cte_Main_JSON.specversion,
  'type', cte_Main_JSON.type,
  'source', cte_Main_JSON.source,
  'subject', cte_Main_JSON.subject,
  'datacontenttype', cte_Main_JSON.datacontenttype,
  'time', cte_Main_JSON.time,
  'iaspecversion', cte_Main_JSON.iaspecversion,
  'correlationid', cte_guid.id,
  'id', cte_guid.id,
  'env', cte_Main_JSON.env,
  'topic', cte_Main_JSON.topic,
  'data', OBJECT_CONSTRUCT(
     'DateFinPeriode', cte_ef_dateFinPeriode.DateFinPeriode,
     'BlobContainer', 'out',
     'BlobFileName', (
            -- Extrait tous les noms des fichiers de contrôle qui sont associés à une demande d'extraction spécifique de LOB.
            -- Pour certains LOB, il  peut y avoir plus d'un fichie de données et aussi fichies de contrôles associés à la même requête.
            SELECT ARRAY_AGG(FILE_GENERATED) 
            FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXTRACTIONS ext
            WHERE ext.FILE_GENERATED LIKE '%CONTROLE_OE_ExtraitTransactions%'
                    AND ext.Audit_ID = cte_ef_dateFinPeriode.Audit_ID
                    AND ext.Description = cte_ef_dateFinPeriode.Description
            ),
     'LOB', OBJECT_CONSTRUCT(
        'Code', LOB   
      )
  )
  ) as JSON_Content
FROM cte_Main_JSON
INNER JOIN cte_ef_dateFinPeriode ON 1=1
INNER JOIN cte_guid ON 1=1;
create or replace view V_MESSAGE_ERP_LOAD(
	AUDIT_ID,
	DESCRIPTION,
	JSON_CONTENT
) as

WITH cte_Main_JSON
-- Contenu principale de l'entête du message
AS
(
SELECT 
  '1.0' AS specversion,
  'CTB.CalculCSM' AS type,
  'CTB_Staging' as source,
  'TransactionsConfirmationMAJStaging' as subject,
  'application/json' as datacontenttype,
  LEFT(current_timestamp(2)::string,23) as time,
  '0.1' as iaspecversion,
  LOWER(SPLIT_PART(CURRENT_DATABASE(), '_', 3)) AS env, -- Extrait la portion palier du nom de la BD courante
  'Topic' AS topic
)

,cte_guid
as
(
   -- Génère un GUID unique à ré-utiliser dans les clés du fichier.
   SELECT UUID_STRING() AS ID
)

,cte_erp_date
-- Contenu spécifique pour la date de dernier chargement en provenance du ERP.
-- On veut la plus petite date de la dernière batch de fichier reçu (selon le audit ID)
AS
(
SELECT  AUDIT_ID,DESCRIPTION,MIN(Start_Time) as DateImageERP FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXECUTIONS   as DateImageErp
WHERE Job_Name = 'Request_CIS_CTL'  GROUP BY AUDIT_ID,DESCRIPTION
)

,cte_gl_lastdate
-- Contenu spécifique pour la date de dernière modification du GL provenant de ERP Cloud
-- Cette valeur indique à AppWorks le positionnement dans le temps du Staging pour exécuter le rapport de contrôle.
AS
(
SELECT MAX(JRNLLINELASTUPDATEDATE) as GL_LastUpdateTimestamp FROM DB_CTB_DEV_DWH.CTB_DEV.LINKTRANSACTIONNEL_GL_JOURNAL_LINE_PVO
)

,cte_ahcs_lastdate
-- Contenu spécifique pour la date de dernière modification du GL provenant de ERP Cloud
-- Cette valeur indique à AppWorks le positionnement dans le temps du Staging pour exécuter le rapport de contrôle.
-- Pour bien segmenter les valeurs, on veut cible la date d'update lié au header pour les transactions AHCS.
AS
(
SELECT MAX(XLAHDRLASTUPDATEDATE) as AHCS_LastUpdateTimestamp FROM DB_CTB_DEV_DWH.CTB_DEV.LINKTRANSACTIONNEL_SUBLEDGER_ENTRY_LINE_PVO
)


SELECT AUDIT_ID,DESCRIPTION,OBJECT_CONSTRUCT(
  'specversion', cte_Main_JSON.specversion,
  'type', cte_Main_JSON.type,
  'source', cte_Main_JSON.source,
  'subject', cte_Main_JSON.subject,
  'datacontenttype', cte_Main_JSON.datacontenttype,
  'time', cte_Main_JSON.time,
  'iaspecversion', cte_Main_JSON.iaspecversion,
  'correlationid', cte_guid.id,
  'id', cte_guid.id,
  'env', cte_Main_JSON.env,
  'topic', cte_Main_JSON.topic,
  'data', OBJECT_CONSTRUCT(
        'DateImageErp', LEFT(cte_erp_date.DateImageERP::string,23),
        'GL_LastUpdateTimestamp', LEFT(cte_gl_lastdate.GL_LastUpdateTimestamp::string,23),
        'AHCS_LastUpdateTimestamp', LEFT(cte_ahcs_lastdate.AHCS_LastUpdateTimestamp::string,23)
        )
  ) as JSON_Content
FROM cte_Main_JSON
INNER JOIN cte_erp_date ON 1=1
INNER JOIN cte_guid ON 1=1
INNER JOIN cte_gl_lastdate ON 1=1
INNER JOIN cte_ahcs_lastdate ON 1=1;
create or replace view V_TRANSACTIONS_BY_LOB(
	HK_LINK,
	CODE_LOB,
	ACCOUNTING_PERIOD,
	MD_SYSTEM_SOURCE,
	SYSTEMESOURCE,
	ID_PRIMAIRE,
	ID_SECONDAIRE,
	ID_RECLAMATION,
	ID_REASSURANCE,
	ID_COMPLEMENT,
	ID_MANUEL_001,
	ID_MANUEL_002,
	ID_MANUEL_003,
	ID_MANUEL_004,
	ID_MANUEL_005,
	ACCOUNTING_ENTRY_TYPE,
	LEDGER_NAME,
	ENTITY,
	NATURE,
	COST_CENTER,
	INTERCO,
	LOB,
	PRODUCT,
	PARTICIPATION,
	GEOGRAPHY,
	PERIODICITY,
	ORIGIN,
	PROJECT,
	FUTUR1,
	FUTUR2,
	DEBIT,
	CREDIT,
	SOLDE,
	VARIABLE,
	CUSTOM_DIM_1,
	CUSTOM_DIM_2,
	IFRS17_FLAG,
	IFRS17_UNIQUE_FLAG
) as 
/* =========================================================================================================================================
Auth:   Pierre Cusson
Date:   2021-11-03
Desc:   Cette vue retourne les dernières versions des transactions de la couche Data Mart (incluant le calcul des références complémentaires).
        La logique d'assignation des codes de LOB selon les 13 segments de la charte de compte y est présente pour faciliter les filtres par lignes d'affaires.
        Elle contient aussi des flags pour permettre de filter selon le niveau de détail requis par IFRS17 et pour éviter de retourner des montants doublés de AHCS et GL.
===========================================================================================================================================*/

    WITH cte_ifrs17 as 
    (
      -- Extrait tous les codes d'auxiliaires dont l'extractions des transactions doit se faire au niveau AHCS pour les requis de IFRS17
      SELECT JRNLSRCJESOURCEKEY as CODE_AUXILIAIRE FROM DB_CTB_DEV_DWH.CTB_DEV.LINKTRANSACTIONNEL_GL_JOURNAL_SOURCE_BPVO WHERE TYPE_SOURCE = 'AHCS'
    )
    
    SELECT 
    HK_LINK,
    -- Application des règlges d'affaires qui affecte un code de LOB à une ligne de transactions. La règle principale vient de l'assignation du fichier MasterCOA_RKI, mais d'autres règles hard-codé peuvent être requises.
    CASE 
        WHEN UPPER(LobFilter.ExtraitLobKey) = 'VI' AND IFNULL(SYSTEMESOURCE,'') = 'A010 MEC' THEN 'VI-IAE'
        WHEN UPPER(LobFilter.ExtraitLobKey) = 'VI' AND IFNULL(SYSTEMESOURCE,'') <> 'A010 MEC' THEN 'VI-VI'
        ELSE UPPER(IFNULL(LobFilter.ExtraitLobKey,''))
    END as CODE_LOB,
    trx.ACCOUNTING_PERIOD,
    trx.MD_SYSTEM_SOURCE,
    IFNULL(trx.SYSTEMESOURCE,'') AS SYSTEMESOURCE,
    IFNULL(trx.ID_PRIMAIRE,'') AS ID_PRIMAIRE,
    IFNULL(trx.ID_SECONDAIRE,'') AS ID_SECONDAIRE,
    IFNULL(trx.ID_RECLAMATION,'') AS ID_RECLAMATION,
    IFNULL(trx.ID_REASSURANCE,'') AS ID_REASSURANCE,
    IFNULL(trx.ID_COMPLEMENT,'') AS ID_COMPLEMENT,
    IFNULL(trx.ID_MANUEL_001,'') AS ID_MANUEL_001,
    IFNULL(trx.ID_MANUEL_002,'') AS ID_MANUEL_002,
    IFNULL(trx.ID_MANUEL_003,'') AS ID_MANUEL_003,
    IFNULL(trx.ID_MANUEL_004,'') AS ID_MANUEL_004,
    IFNULL(trx.ID_MANUEL_005,'') AS ID_MANUEL_005,
    trx.ACCOUNTING_ENTRY_TYPE,
    trx.LEDGER_NAME,
    trx.ENTITY,
    trx.NATURE,
    trx.COST_CENTER,
    trx.INTERCO,
    trx.LOB,
    trx.PRODUCT,
    trx.PARTICIPATION,
    trx.GEOGRAPHY,
    trx.PERIODICITY,
    trx.ORIGIN,
    trx.PROJECT,
    trx.FUTUR1,
    trx.FUTUR2,
    trx.DEBIT,
    trx.CREDIT,
    trx.SOLDE,
    IFNULL(LobFilter.VARIABLE,'') AS VARIABLE, 
    IFNULL(LobFilter.CUSTOM_DIM_1,'') AS CUSTOM_DIM_1, 
    IFNULL(LobFilter.CUSTOM_DIM_2,'') AS CUSTOM_DIM_2,
    CASE WHEN cte_ifrs17.code_auxiliaire IS NOT NULL THEN 1 ELSE 0 END as IFRS17_Flag,     -- Indique 1 si le code d'auxiliaires à un mapping UDC de configuré (donc requiert le détail de IFRS17)
    CASE WHEN 
        (trx.MD_SYSTEM_SOURCE = 'AHCS' AND IFRS17_Flag = 1)
        OR
        (trx.MD_SYSTEM_SOURCE = 'GL' AND IFRS17_Flag = 0)
        THEN 1
        ELSE 0
        END as IFRS17_Unique_Flag   -- Retourne un flag 0/1 selon le niveau d'extraction requis. Les codes d'auxiliaires IFRS17 doivent être extract de AHCS, les codes d'auxiliaires non-IFRS17 doivent être extrait du GL
                                    -- La combinaison des transactions de AHCS et GL doit donner le montant total sans double-montant.
    FROM DB_CTB_DEV_DM.CTB_DEV.TRANSACTIONS trx
    LEFT JOIN cte_ifrs17 ON trx.systemesource = cte_ifrs17.code_auxiliaire
    LEFT JOIN DB_CTB_DEV_DWH.CTB_DEV.V_REF_MASTER_COA_RKI LobFilter ON
        trx.ENTITY = LobFilter.ENTITY
        AND trx.NATURE = LobFilter.Nature
        AND trx.COST_CENTER = LobFilter.COSTCENTER
        AND trx.INTERCO = LobFilter.INTERCO
        AND trx.LOB = LobFilter.LOB
        AND trx.PRODUCT = LobFilter.PRODUCT
        AND trx.PARTICIPATION = LobFilter.PARTICIPATION
        AND trx.GEOGRAPHY = LobFilter.GEOGRAPHY
        AND trx.PERIODICITY = LobFilter.PERIODICITY
        AND trx.ORIGIN = LobFilter.ORIGIN
        AND trx.PROJECT = LobFilter.PROJECT
        AND trx.FUTUR1 = LobFilter.FUTUR1
        AND trx.FUTUR2 = LobFilter.FUTUR2
     WHERE CurrentVersion = 1       -- Ce flag gère l'historisation des transactions dans le cas ou une valeur de réréfence complémentaire pourrait changer dans le temps. On veut uniquement lire la version la plus récente.
;
create or replace view V_TRANSACTIONS_VALIDATION(
	SYSTEMESOURCE,
	LEDGER_NAME,
	ACCOUNTING_ENTRY_TYPE,
	ACCOUNTING_PERIOD,
	ENTITY,
	NATURE,
	NB_SLALINES,
	ID_PRIMAIRE_COUNT,
	ID_SECONDAIRE_COUNT,
	ID_RECLAMATION_COUNT,
	ID_REASSURANCE_COUNT,
	ID_COMPLEMENT_COUNT,
	ID_MANUEL_001_COUNT,
	ID_MANUEL_002_COUNT,
	ID_MANUEL_003_COUNT,
	ID_MANUEL_004_COUNT,
	ID_MANUEL_005_COUNT,
	DEBIT,
	CREDIT
) as (
SELECT 
  SystemeSource, 
  ledger_name, 
  Accounting_Entry_Type, 
  ACCOUNTING_PERIOD, 
  Entity, 
  Nature,
  COUNT(*) as NB_SLALINES,
  SUM(CASE WHEN ID_PRIMAIRE <> '' THEN 1 ELSE 0 END) as ID_PRIMAIRE_Count,
  SUM(CASE WHEN ID_SECONDAIRE <> '' THEN 1 ELSE 0 END) as ID_SECONDAIRE_Count,
  SUM(CASE WHEN ID_RECLAMATION <> '' THEN 1 ELSE 0 END) as ID_RECLAMATION_Count,
  SUM(CASE WHEN ID_REASSURANCE <> '' THEN 1 ELSE 0 END) as ID_REASSURANCE_Count,
  SUM(CASE WHEN ID_COMPLEMENT <> '' THEN 1 ELSE 0 END) as ID_COMPLEMENT_Count,
  SUM(CASE WHEN ID_MANUEL_001 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_001_Count,
  SUM(CASE WHEN ID_MANUEL_002 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_002_Count,
  SUM(CASE WHEN ID_MANUEL_003 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_003_Count,
  SUM(CASE WHEN ID_MANUEL_004 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_004_Count,
  SUM(CASE WHEN ID_MANUEL_005 <> '' THEN 1 ELSE 0 END) as ID_MANUEL_005_Count,
  SUM(DEBIT) as Debit,
  SUM(Credit) as Credit
FROM DB_CTB_DEV_DM.CTB_DEV.TRANSACTIONS 
GROUP BY SystemeSource, ledger_name, Accounting_Entry_Type, ACCOUNTING_PERIOD, Entity, Nature
ORDER BY SystemeSource, ledger_name, Accounting_Entry_Type, ACCOUNTING_PERIOD, Entity, Nature
);
create or replace schema CTB_PUBLICATION;

create or replace schema DATALAKE;

create or replace TABLE DUMMY (
	DUMMY VARCHAR(10)
);
create or replace TABLE TEST_JSON (
	V VARIANT
);
CREATE OR REPLACE PROCEDURE "EXPORT_REQUEST"("AUDIT_ID" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS ' 
  //GET REQUEST FILE INFORMATION FROM AUDIT_JOB_EXTRACTIONS(LOB
    var sSql_REQ = "Select ext.AUDIT_ID
    var sMessage =""
    try{ 
        
        objSqlCmd_REQ = {sqlText: sSql_REQ
        binds:[AUDIT_ID]};
        objStmt_REQ = snowflake.createStatement(objSqlCmd_REQ);
        objRs_REQ = objStmt_REQ.execute();
        
   //ASSIGN REQUEST FILE INFORMATION FROM AUDIT_JOB_EXTRACTIONS(LOB
            while (objRs_REQ.next()){
                var RES_AUDIT_ID = objRs_REQ.getColumnValue("AUDIT_ID");
                var RES_DESCRIPTION = objRs_REQ.getColumnValue("DESCRIPTION");
                var RES_EXPORT_TYPE = objRs_REQ.getColumnValue("EXPORT_TYPE");
   
   //FROM EXPORT_TYPE
   //EACH IF or ELSE IF SHOULD CALL A PROCEDURE FOR A SPECIFIC EXPORT_TYPE
   
                if (RES_EXPORT_TYPE==''''LOB'''') {
                    var RES_LOB = objRs_REQ.getColumnValue("PARAM1");
                    var RES_PERIOD = objRs_REQ.getColumnValue("PARAM2");
                
                    var sSql_PROCEDURELOB = "call DB_CTB_DEV_DM.DATALAKE.EXPORT_LOB_DATA(:1
                    objSqlCmd_LOB = {sqlText: sSql_PROCEDURELOB
                                   binds: [RES_AUDIT_ID
                    objStmt_LOB = snowflake.createStatement(objSqlCmd_LOB);
                    objRs_LOB = objStmt_LOB.execute();
                    objRs_LOB.next();
                    var extract_status = objRs_LOB.getColumnValue(1);
                 
                
                } else if (RES_EXPORT_TYPE ==''PERIOD'') {
                    BREAK
                
                } else if (RES_EXPORT_TYPE ==''LEDGER'') {
                    BREAK
                
                } else {
                    return ''Unknown extract code''
                };
                
                
                sMessage += " [SUCCESS]: output is successfuly DONE";
    
            } 
          
    }    
    catch(err) {
        
        sMessage +=  err + "\\\\\\\\n";
        
        return sMessage;
    } 
   
  ';
create or replace schema FSC;

create or replace TABLE DUMMY (
	DUMMY VARCHAR(10)
);
create or replace view V_QUALITY_TM_LOTS(
	TESTNAME,
	OBJECTNAME,
	MISSINGVALUE
) as

/* Ecarts Positions */
-- Retourne les combinaison de Fonds/Titres pour la période en cours de chargement qui sortent en écart selon la vue V_TM_LOTS_DISCREPANCY
SELECT DISTINCT
    'Écart de position' as TestName, 
    'V_TM_LOTS_DISCREPANCY ==> ' || 'FONDS : ' || f.NOM_FONDS || ' | TITRE : ' || t.CODE_TITRE as ObjectName, 
     IFF(ROUND(QUANTITE_FINALE) <> ROUND(QUANTITE_INITIALE), 'QUANTITE_INITIALE ', '')
        || IFF(ROUND(VALEUR_FINALE) <> ROUND(VALEUR_INITIALE), 'VALEUR_INITIALE ', '')
        AS MissingValue
FROM DB_CTB_DEV_DM.FSC.V_TM_LOTS_DISCREPANCY d
INNER JOIN DB_CTB_DEV_DWH.FSC.V_LOAD_TM_SNAPSHOTDATES s ON d.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_FONDS f ON d.ID_FONDS = f.ID_FONDS
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_TITRES t ON d.ID_TITRE = t.ID_TITRE

UNION

/* Fonds Disparus */
-- Retourne les  Fonds disparus pour la période en cours de chargement selon la vue V_TM_LOTS_FONDS_DISPARUS
SELECT DISTINCT
    'Fonds Disparus' as TestName, 
    'V_TM_LOTS_FONDS_DISPARUS ==> ' || 'FONDS : ' || l.ID_FONDS|| '|PERIODE COMPTABLE: '   || l.PERIODE_COMPTABLE || '|PERIODE COMPARATIVE: ' ||l. PERIODE_COMPARATIVE ||'|FONDS MANQUANTS: ' || l.ID_FONDS2 as ObjectName, 
    'FONDS: '|| f.NOM_FONDS || '|ID: '||l.ID_FONDS || '|TYPE: ' || f.TYPE_FONDS as MissingValue
       
FROM DB_CTB_DEV_DM.FSC.V_TM_LOTS_FONDS_DISPARUS l
INNER JOIN DB_CTB_DEV_DWH.FSC.V_LOAD_TM_SNAPSHOTDATES s ON l.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_FONDS f ON l.ID_FONDS = f.ID_FONDS;
create or replace view V_QUALITY_TM_REVENU(
	TESTNAME,
	OBJECTNAME,
	MISSINGVALUE
) as
-- Retourne les Fonds manquants pour la période en cours de chargement pour la vue V_TM_REVENU_FONDS_DISPARUS
SELECT DISTINCT
    'Fonds Disparus' as TestName, 
    'V_TM_REVENU_FONDS_DISPARUS ==> ' || 'FONDS : ' || r.ID_FONDS || '|PERIODE COMPTABLE :'    || r.PERIODE_COMPTABLE || '|PERIODE COMPARATIVE : ' ||r. PERIODE_COMPARATIVE ||'|FONDS MANQUANTS : ' || r.ID_FONDS2  as ObjectName, 
    'FONDS : '|| f.NOM_FONDS || '|ID  '||r.ID_FONDS || '|TYPE : ' || f.TYPE_FONDS as MissingValue
       
FROM DB_CTB_DEV_DM.FSC.V_TM_REVENU_FONDS_DISPARUS r
INNER JOIN DB_CTB_DEV_DWH.FSC.V_LOAD_TM_SNAPSHOTDATES s ON r.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_FONDS f ON r.ID_FONDS = f.ID_FONDS;
create or replace view V_TM_LOTS(
	PERIODE_COMPTABLE,
	ID_FONDS,
	ID_TITRE,
	NOM_FONDS,
	ID_FILIALE,
	DEVISE_FONDS,
	CODE_TITRE,
	NOM_TITRE,
	DESCRIPTION_EMETTEUR,
	TYPE_TITRE,
	PAYS_EMETTEUR,
	DEVISE_TITRE,
	COUPON,
	DATE_ECHEANCE,
	FREQUENCE_COUPON,
	TYPE_SOUS_TITRE,
	TYPE_LOT,
	ID_LOT,
	TYPE_POSITION,
	DATE_TRANSACTION,
	TYPE_TRANSACTION,
	NOMBRE_JOURS_DETENUS,
	QUANTITE_INITIALE,
	QUANTITE_ACHETEE,
	QUANTITE_VENDUE,
	QUANTITE_FINALE,
	VALEUR_INITIALE,
	COUT_ACQUISITION,
	MONTANT_VENTE,
	VALEUR_FINALE,
	INTERET_COURU_INITIAL,
	INTERET_COURU_ACHAT,
	INTERET_COURU_VENTE,
	INTERET_COURU_FINAL,
	DATE_ACHAT,
	DATE_VENTE,
	GAINS_PERTE_PRIX_TITRE,
	GAINS_PERTE_DEVISE,
	QUANTITE_CONTROLE
) as

/*
Auth:   Laurette Bakebana Zola
Date:   2022-01-05
Desc:   Vue de consommation qui retourne les dernières données des lots par période comptable.

*/
WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE
)


SELECT
    l.Periode_comptable,
    l.ID_FONDS,
    l.ID_TITRE,
    NVL(fonds.NOM_FONDS,'') as NOM_FONDS,
    NVL(fonds.CODE_FONDS_EBS,'') as ID_FILIALE,
    NVL(fonds.DEVISE_FONDS,'') as DEVISE_FONDS,
    NVL(t.CODE_TITRE,'') as CODE_TITRE,
    NVL(t.NOM_TITRE,'') as NOM_TITRE,
    NVL(t.DESCRIPTION_EMETTEUR,'') as DESCRIPTION_EMETTEUR,
    NVL(t.TYPE_TITRE,'') as TYPE_TITRE,
    NVL(t.PAYS_EMETTEUR,'') as PAYS_EMETTEUR,
    NVL(t.DEVISE_TITRE,'') as DEVISE_TITRE,
    NVL(TRY_TO_NUMERIC(t.COUPON,38,12),0) as COUPON,
    t.DATE_ECHEANCE as DATE_ECHEANCE,
    NVL(t.FREQUENCE_COUPON,'') as FREQUENCE_COUPON,
    NVL(t.TYPE_SOUS_TITRE,'') as TYPE_SOUS_TITRE,
    l.TYPE_LOT,
    l.ID_LOT,
	l.TYPE_POSITION,
    l.DATE_TRANSACTION as DATE_TRANSACTION,
    NVL(l.TYPE_TRANSACTION,'') as TYPE_TRANSACTION,  
    NVL(l.NOMBRE_JOURS_DETENUS,0) as NOMBRE_JOURS_DETENUS,
    NVL(l.QUANTITE_INITIALE, 0) as QUANTITE_INITIALE,
   	NVL(l.QUANTITE_ACHETEE, 0) as QUANTITE_ACHETEE, 
    NVL(l.QUANTITE_VENDUE, 0) as QUANTITE_VENDUE,
    NVL(l.QUANTITE_FINALE, 0) as QUANTITE_FINALE,
    NVL(l.VALEUR_INITIALE, 0) as VALEUR_INITIALE,
    NVL(l.COUT_ACQUISITION, 0) as COUT_ACQUISITION,
    NVL(l.MONTANT_VENTE, 0) as MONTANT_VENTE, 
    NVL(l.VALEUR_FINALE, 0) as VALEUR_FINALE,
	NVL(l.INTERET_COURU_INITIAL, 0) as INTERET_COURU_INITIAL,
    NVL(l.INTERET_COURU_ACHAT, 0) as INTERET_COURU_ACHAT,
    NVL(l.INTERET_COURU_VENTE, 0) as INTERET_COURU_VENTE,
    NVL(l.INTERET_COURU_FINAL, 0) as INTERET_COURU_FINAL,
    l.DATE_ACHAT as DATE_ACHAT,
    l.DATE_VENTE as DATE_VENTE,
    NVL(l.GAINS_PERTE_PRIX_TITRE, 0) as GAINS_PERTE_PRIX_TITRE,   
    NVL(l.GAINS_PERTE_DEVISE, 0) as GAINS_PERTE_DEVISE, 
    NVL(l.QUANTITE_CONTROLE, 0) as QUANTITE_CONTROLE
 
FROM DB_CTB_DEV_DWH.FSC.LINK_TM_LOTS l
INNER JOIN CTE_Lots_Par_Period lp 
    ON l.Periode_comptable = lp.Periode_comptable 
        and l.MD_AUDIT_ID = lp.MD_AUDIT_ID  -- Filtre les données pour la dernière date de chargement de chacun des blocs de lots par période comptable.
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_FONDS fonds
    ON l.ID_FONDS = fonds.ID_FONDS
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_TITRES t
    ON l.ID_TITRE = t.ID_TITRE;
create or replace view V_TM_LOTS_DISCREPANCY(
	PERIODE_COMPTABLE,
	PERIODE_COMPARATIVE,
	ID_FONDS,
	ID_TITRE,
	TYPE_POSITION,
	ID_FONDS1,
	ID_TITRE1,
	TYPE_POSITION1,
	ID_FONDS2,
	ID_TITRE2,
	TYPE_POSITION2,
	QUANTITE_FINALE,
	QUANTITE_INITIALE,
	VALEUR_FINALE,
	VALEUR_INITIALE
) as

/*===============================================================================================================================
Auth:   Pierre Cusson
Date:   2021-02-04
Des :   Cette vue retourne l'ensemble des positions qui ont un écart entre entre les positions de départ de l'année courante
        et les positions de fins de l'année précédente. Le résultats de ces écarts a pour but d'être inscrit dans la table des 
        points de contrôles et ensuite affiché dans un dashboard à la ligne d'affaire
===============================================================================================================================*/

WITH CTE_Fin as(
    -- Extraction des valeurs de fin de l'année précédente, retourne les valeurs arrondi des SUM pour éliminer les écarts de cents.
    SELECT  l.PERIODE_COMPTABLE, l.ID_FONDS, l.ID_TITRE, l.TYPE_POSITION,
        ROUND(SUM(QUANTITE_FINALE)) AS QUANTITE_FINALE, 
        ROUND(SUM(VALEUR_FINALE)) as VALEUR_FINALE
    FROM DB_CTB_DEV_DM.FSC.V_TM_LOTS l
    GROUP BY l.PERIODE_COMPTABLE, l.ID_FONDS, l.ID_TITRE, l.TYPE_POSITION
)


    
, CTE_Depart as (
    -- Extraction des valeurs de début de l'année courante
    SELECT  l.PERIODE_COMPTABLE,
        (LEFT(l.PERIODE_COMPTABLE,4)::INT - 1)::STRING || '-12' as PERIODE_COMPTABLE_COMPARATIVE,  -- Retourne la période 12 de l'année précédente pour être liée en tant que période comparative
        l.ID_FONDS, l.ID_TITRE, l.TYPE_POSITION,
        ROUND(SUM(QUANTITE_INITIALE)) AS QUANTITE_INITIALE, 
        ROUND(SUM(VALEUR_INITIALE)) as VALEUR_INITIALE
    FROM DB_CTB_DEV_DM.FSC.V_TM_LOTS l
    GROUP BY l.PERIODE_COMPTABLE, l.ID_FONDS, l.ID_TITRE, l.TYPE_POSITION
)

-- Compare les deux set de valeurs et extrait ceux dont les valeurs sont différentes. Ceux-ci représenteraient une anomalies de données ou de processus.
SELECT 
    NVL(d.PERIODE_COMPTABLE, '') AS PERIODE_COMPTABLE,
    NVL(f.PERIODE_COMPTABLE, '') AS Periode_Comprative,
    COALESCE(F.ID_FONDS, d.ID_FONDS) AS ID_FONDS,
    COALESCE(F.ID_TITRE, d.ID_TITRE) AS ID_TITRE,
    COALESCE(F.TYPE_POSITION, d.TYPE_POSITION) AS TYPE_POSITION,
    F.ID_FONDS AS ID_FONDS1,
    F.ID_TITRE AS ID_TITRE1,
    F.TYPE_POSITION AS TYPE_POSITION1,
    d.ID_FONDS AS ID_FONDS2,
    d.ID_TITRE AS ID_TITRE2,
    d.TYPE_POSITION AS TYPE_POSITION2,
    NVL(f.QUANTITE_FINALE, 0) AS QUANTITE_FINALE,
    NVL(d.QUANTITE_INITIALE, 0) AS QUANTITE_INITIALE,
    NVL(f.VALEUR_FINALE, 0) AS VALEUR_FINALE,
    NVL(d.VALEUR_INITIALE, 0) AS VALEUR_INITIALE
FROM CTE_Depart d
FULL OUTER JOIN CTE_Fin f
    ON d.PERIODE_COMPTABLE_COMPARATIVE = f.PERIODE_COMPTABLE
    AND d.ID_FONDS = f.ID_FONDS
    AND d.ID_TITRE = f.ID_TITRE
    AND d.TYPE_POSITION = f.TYPE_POSITION
WHERE 
    ABS(QUANTITE_FINALE - QUANTITE_INITIALE) > 1
    OR 
    ABS(VALEUR_FINALE - VALEUR_INITIALE) > 1;
create or replace view V_TM_LOTS_FONDS_DISPARUS(
	PERIODE_COMPTABLE,
	PERIODE_COMPARATIVE,
	ID_FONDS,
	ID_FONDS1,
	ID_FONDS2
) as

/*===============================================================================================================================
Auth:   Laurette Zola
Date:   2022-04-27
Des :   Cette vue retourne la liste des fonds disparus d'une période à une autre. Le résultats de ces écarts a pour but d'être inscrit dans la table des 
        points de contrôles et ensuite affiché dans un dashboard à la ligne d'affaire
===============================================================================================================================*/

WITH CTE_Fin as(
    -- Extraction de la liste des Fonds de la période courante, retourne une liste des fonds distincts contenus dans la table des Lots.
    SELECT  DISTINCT l.PERIODE_COMPTABLE, 
            l.ID_FONDS
    FROM DB_CTB_DEV_DM.FSC.V_TM_LOTS l

)


    
, CTE_Depart as (
    -- Extraction de la liste des Fonds de la période précedente, retourne une liste des fonds distincts contenus dans la table des Lots.
    SELECT  DISTINCT l.PERIODE_COMPTABLE As PERIODE_COMPTABLE_COMPARATIVE,
            l.ID_FONDS,
        CONCAT(LEFT(l.PERIODE_COMPTABLE,4)::STRING, '-', right('0'||((right(l.PERIODE_COMPTABLE,2)::INT + 1)::STRING),2)) as PERIODE_COMPTABLE  -- Retourne la période précédente pour être liée en tant que période comparative. Cela permettra de comparer à chaque fois le nombre des fonds de la période courante à celui de la période précedente. 
      
    FROM DB_CTB_DEV_DM.FSC.V_TM_LOTS l
 
)

-- Compare les deux set de valeurs et renvoi la liste des fonds diparus. Ceux-ci représenteraient une anomalies de données ou de processus.
SELECT 
    NVL(d.PERIODE_COMPTABLE, '') AS PERIODE_COMPTABLE,
    NVL(f.PERIODE_COMPTABLE, '') AS PERIODE_COMPARATIVE,
    COALESCE(f.ID_FONDS, d.ID_FONDS) AS ID_FONDS,
    f.ID_FONDS AS ID_FONDS1,
    d.ID_FONDS AS ID_FONDS2
FROM CTE_Depart d  
LEFT JOIN CTE_Fin f 
    ON  d.PERIODE_COMPTABLE = f.PERIODE_COMPTABLE
    AND d.ID_FONDS = f.ID_FONDS 
WHERE 
   ID_FONDS1 is NULL;
create or replace view V_TM_REVENU(
	PERIODE_COMPTABLE,
	ID_FONDS,
	NOM_FONDS,
	ID_FILIALE,
	DEVISE_FONDS,
	CODE_TITRE,
	NOM_TITRE,
	DESCRIPTION_EMETTEUR,
	TYPE_TITRE,
	PAYS_EMETTEUR,
	DEVISE_TITRE,
	COUPON,
	DATE_ECHEANCE,
	FREQUENCE_COUPON,
	TYPE_SOUS_TITRE,
	TYPE_POSITION,
	QUANTITE_INITIALE,
	QUANTITE_FINALE,
	INTERET_COURU_INITIAL,
	INTERET_COURU_FINAL,
	DIVIDENDES_RECEVOIR_INITIAL,
	DIVIDENDES_RECEVOIR_FINAL,
	COUPONS_PAYES,
	DIVIDENDES_VERSES,
	INTERETS_GAGNES,
	AMORTISSEMENTS,
	REVENUS_OBLIGATAIRES,
	URGL_DELTA_TITRE_OCI,
	URGL_DELTA_DEVISE_OCI,
	REVENU_LOCAL,
	REVENU_ETRANGER,
	DIVIDENDE_LOCAL,
	DIVIDENDE_ETRANGER,
	GAINS_PERTES_REALISES_PRIX_TITRES_OCI,
	GAINS_PERTES_REALISES_DEVISE_OCI,
	URGL_PRIX_TITRES,
	URGL_DEVISE_FONDS,
	FRAIS_TRANSACTION,
	IMPOT_RETENU_SOURCE,
	GAINS_PERTES_REALISES_PRIX_TITRES,
	COUT_AJUSTEMENT
) as

/*
Auth:   Pierre Cusson
Date:   2021-12-31
Desc:   Vue de consommation qui retourne les dernières données de revenu par période comptable.

*/
WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Revenu_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE
)

SELECT
    r.Periode_comptable,
	NVL(fonds.ID_FONDS,'' ) as ID_FONDS,
    NVL(fonds.NOM_FONDS,'') as NOM_FONDS,
    NVL(fonds.CODE_FONDS_EBS,'') as ID_FILIALE,
    NVL(fonds.DEVISE_FONDS,'') as DEVISE_FONDS,
    NVL(titres.CODE_TITRE,'') as CODE_TITRE,
    NVL(titres.NOM_TITRE,'') as NOM_TITRE,
    NVL(titres.DESCRIPTION_EMETTEUR,'') as DESCRIPTION_EMETTEUR,
    NVL(titres.TYPE_TITRE,'') as TYPE_TITRE,
    NVL(titres.PAYS_EMETTEUR,'') as PAYS_EMETTEUR,
    NVL(titres.DEVISE_TITRE,'') as DEVISE_TITRE,
    NVL(titres.COUPON,0) as COUPON,
    TRY_TO_DATE(titres.DATE_ECHEANCE::STRING, 'YYYY-MM-DD') as DATE_ECHEANCE,
    NVL(titres.FREQUENCE_COUPON, '') as FREQUENCE_COUPON,
    NVL(titres.TYPE_SOUS_TITRE,'') as TYPE_SOUS_TITRE,
	r.TYPE_POSITION, 
    NVL(r.QUANTITE_INITIALE, 0) as QUANTITE_INITIALE,
   	NVL(r.QUANTITE_FINALE, 0) as QUANTITE_FINALE, 
	NVL(r.INTERET_COURU_INITIAL, 0) as INTERET_COURU_INITIAL, 
	NVL(r.INTERET_COURU_FINAL, 0) as INTERET_COURU_FINAL, 
	NVL(r.DIVIDENDES_RECEVOIR_INITIAL, 0) as DIVIDENDES_RECEVOIR_INITIAL, 
	NVL(r.DIVIDENDES_RECEVOIR_FINAL, 0) as DIVIDENDES_RECEVOIR_FINAL,
    NVL(r.COUPONS_PAYES, 0) as COUPONS_PAYES, 
	NVL(r.DIVIDENDES_VERSES, 0) as DIVIDENDES_VERSES, 
	NVL(r.INTERETS_GAGNES, 0) as INTERETS_GAGNES, 
	NVL(r.AMORTISSEMENTS, 0) as AMORTISSEMENTS, 
	NVL(r.REVENUS_OBLIGATAIRES, 0) as REVENUS_OBLIGATAIRES,
    NVL(r.URGL_DELTA_TITRE_OCI, 0) as URGL_DELTA_TITRE_OCI, 
   	NVL(r.URGL_DELTA_DEVISE_OCI, 0) as URGL_DELTA_DEVISE_OCI, 
	NVL(r.REVENU_LOCAL, 0) as REVENU_LOCAL, 
	NVL(r.REVENU_ETRANGER, 0) as REVENU_ETRANGER, 
	NVL(r.DIVIDENDE_LOCAL, 0) as DIVIDENDE_LOCAL, 
	NVL(r.DIVIDENDE_ETRANGER, 0) as DIVIDENDE_ETRANGER,
    NVL(r.GAINS_PERTES_REALISES_PRIX_TITRES_OCI, 0) as GAINS_PERTES_REALISES_PRIX_TITRES_OCI, 
	NVL(r.GAINS_PERTES_REALISES_DEVISE_OCI, 0) as GAINS_PERTES_REALISES_DEVISE_OCI, 
	NVL(r.URGL_PRIX_TITRES, 0) as URGL_PRIX_TITRES, 
	NVL(r.URGL_DEVISE_FONDS, 0) as URGL_DEVISE_FONDS, 
	NVL(r.FRAIS_TRANSACTION, 0) as FRAIS_TRANSACTION, 
	NVL(r.IMPOT_RETENU_SOURCE, 0) as IMPOT_RETENU_SOURCE, 
	NVL(r.GAINS_PERTES_REALISES_PRIX_TITRES, 0) as GAINS_PERTES_REALISES_PRIX_TITRES,
    NVL(r.COUT_AJUSTEMENT, 0) as COUT_AJUSTEMENT
FROM DB_CTB_DEV_DWH.FSC.LINK_TM_REVENU r
INNER JOIN CTE_Revenu_Par_Period rp 
    ON r.Periode_comptable = rp.Periode_comptable 
    AND r.MD_AUDIT_ID = rp.MD_AUDIT_ID  -- Filtre les données pour la dernière date de chargement de chacun des blocs de lots par période comptable.
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_FONDS fonds
    ON r.ID_FONDS = fonds.ID_FONDS
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_TITRES titres
    ON r.ID_TITRE = titres.ID_TITRE;
create or replace view V_TM_REVENU_FONDS_DISPARUS(
	PERIODE_COMPTABLE,
	PERIODE_COMPARATIVE,
	ID_FONDS,
	ID_FONDS1,
	ID_FONDS2
) as

/*===============================================================================================================================
Auth:   Laurette Zola
Date:   2022-04-27
Des :   Cette vue retourne la liste des fonds disparus ( contenus dans la table des revenus) d'une période à une autre. Le résultats de ces écarts a pour but d'être inscrit dans la table des 
        points de contrôles et ensuite affiché dans un dashboard à la ligne d'affaire
===============================================================================================================================*/

WITH CTE_Fin as(
    -- Extraction de la liste des Fonds de la période courante, retourne une liste des fonds distincts contenus dans la table des Revenus.
    SELECT  r.PERIODE_COMPTABLE, 
            r.ID_FONDS As ID_FONDS
    FROM DB_CTB_DEV_DM.FSC.V_TM_REVENU r

)


    
, CTE_Depart as (
    -- Extraction de la liste des Fonds de la période précédente, retourne une liste des fonds distincts contenus dans la table des Revenus.
    SELECT  r.PERIODE_COMPTABLE As PERIODE_COMPTABLE_COMPARATIVE,
            r.ID_FONDS As ID_FONDS,
            CONCAT(LEFT(r.PERIODE_COMPTABLE,4)::STRING, '-', right('0'||((right(r.PERIODE_COMPTABLE,2)::INT + 1)::STRING),2)) as PERIODE_COMPTABLE  -- Retourne la période +1 de comparaison. Cela permettra de comparer à chaque fois le nombre des fonds de la période courante à celui de la période précedente. 
    FROM DB_CTB_DEV_DM.FSC.V_TM_REVENU r

)

-- Compare les deux set de valeurs et renvoi la liste des fonds diparus. Ceux-ci représenteraient une anomalie de données ou de processus.
SELECT 
    NVL(d.PERIODE_COMPTABLE, '') AS PERIODE_COMPTABLE,
    NVL(f.PERIODE_COMPTABLE, '') AS PERIODE_COMPARATIVE,
    COALESCE(f.ID_FONDS, d.ID_FONDS) AS ID_FONDS,
    f.ID_FONDS AS ID_FONDS1,
    d.ID_FONDS AS ID_FONDS2
FROM CTE_Depart d
LEFT JOIN CTE_Fin f
    ON d.PERIODE_COMPTABLE = f.PERIODE_COMPTABLE
    AND d.ID_FONDS = f.ID_FONDS
WHERE 
   ID_FONDS1 is NULL;
create or replace view V_TM_TITRES(
	PERIODE_COMPTABLE,
	ID_TITRE,
	CODE_TITRE,
	NOM_TITRE
) as 


/*=================================================================================================================
================================================
Auth: Laurette Zola
Date: 2022-03-24
Desc: - Vue qui permet d'afficher la liste des titres par période comnptable.
      - Cette  liste permettra de voir dans le temps les titres qui ont disparus, ou ceux dont le nom a changé.

===================================================================
=================================================================================================================*/

WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)


-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID as MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE

)

/*=================================================================================================================
=================================================================================================================*/

SELECT     
    lp.PERIODE_COMPTABLE,
    a.ID_TITRE,
    a.CODE_TITRE,
    a.NOM_TITRE
FROM DB_CTB_DEV_DWH.FSC.LINK_TM_TITRES a
INNER JOIN CTE_Lots_Par_Period lp 
    ON a.Periode_comptable = lp.Periode_comptable 
    and a.MD_AUDIT_ID = lp.MD_AUDIT_ID  -- Filtre les données pour la dernière date de chargement de la liste des titres par période comptable.
;
CREATE OR REPLACE PROCEDURE "SP_CONV_RUNDATACHECK"("PAUDITID" VARCHAR(100))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

    // Extraction des paramètres de BD et Schema
    var sSql_Description = "Select CURRENT_DATABASE() as DB_Name, CURRENT_SCHEMA() as Schema_Name";

    var objSqlCmd_DB_PARAM = {sqlText: sSql_Description}
    var objStmt_DB_PARAM = snowflake.createStatement(objSqlCmd_DB_PARAM);  
    var objRs_DB_PARAM = objStmt_DB_PARAM.execute();  
          
    while (objRs_DB_PARAM.next()){
          vDatabase = objRs_DB_PARAM.getColumnValue(1);
          vSchema = objRs_DB_PARAM.getColumnValue(2);
     };
    
    // Pour les version en DEV, aligne le nom du schéma tools avec le nom du schéma applicatif source.
    var vToolsSchema = "TOOLS"
    var vLen = vSchema.length
    
    if (vSchema.toUpperCase().slice(vLen-4, vLen) == "_DEV")
    {
        vToolsSchema = vToolsSchema + "_DEV"
    }

    
    // ===============================================================================================================================================
    // Lance les appels de validation de qualité des données. Chaque objet à vérifier doit être encapsulé dans une vue standard préfixé de v_quality dans le schema UnitTests
    // ===============================================================================================================================================
    var sql_sp_CheckDataQuality = "CALL DB_CTB_DEV_DWH." + vToolsSchema + ".sp_CheckDataQuality(?,?,?,?,?,?)"

    snowflake.execute( {sqlText: sql_sp_CheckDataQuality, binds:[PAUDITID, "Tax Model", "Validation des lots", vDatabase, vSchema, "V_QUALITY_TM_LOTS"]} );
    
return ''Done''
';
CREATE OR REPLACE PROCEDURE "SP_CONV_RUNDATACONTROLS_SOURCE"("PAUDITID" VARCHAR(100))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
    // Extraction des paramètres de BD et Schema
    var sReturn = ""
    var sSql_Description = "Select concat(''_'',split(CURRENT_DATABASE(),''_'')[2])::STRING as DB_Name, ifnull(concat(''_'',split(CURRENT_SCHEMA(),''_'')[1]),'''') as Schema_Name;";

    var objSqlCmd_DB_PARAM = {sqlText: sSql_Description}
    var objStmt_DB_PARAM = snowflake.createStatement(objSqlCmd_DB_PARAM);  
    var objRs_DB_PARAM = objStmt_DB_PARAM.execute();  
          
    while (objRs_DB_PARAM.next()){
          vDatabase = objRs_DB_PARAM.getColumnValue(1);
          vSchema = objRs_DB_PARAM.getColumnValue(2);
     };

    var DATABASE_ENV = vDatabase;
    var SCHEMA_ENV  = vSchema;
    
    ////DB VARIABLES
    var STG_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_STG.'';
    var DWH_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_DWH.'';
    var DM_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_DM.'';

    //// SCHEMA VARIABLE
    var FSC_SCHEMA = ''FSC'' + SCHEMA_ENV + ''.'';
    var TOOLS_SCHEMA = ''TOOLS'' + SCHEMA_ENV + ''.'';
    


    // ===========================================================================================================================================
    // TM-CTRL-01
    // Insère la quantité finale totale de l''année précédente comme point de contrôle Source.
    // ===========================================================================================================================================
    var sql_Control1 = "INSERT INTO " + DWH_DATABASE + TOOLS_SCHEMA + "DATACONTROLS(MD_AUDIT_ID, MD_CREATION_DATE, APPLICATIONNAME, DATABASENAME, SUBJECTNAME, DATABASEOBJECTNAME, TESTDATE, TESTNAME, UNITOFMEASURE, CONTROLVALUE, CONTROLTYPE) "
            + "SELECT "
            + "''" + PAUDITID + "''  as MD_AUDIT_ID "
            + ",CURRENT_TIMESTAMP as MD_CREATION_DATE "
            + ",''TaxModel'' as APPLICATIONNAME "
            + ",''" + DWH_DATABASE.replace(".", "") +  "'' as DATABASENAME "
            + ",''Lots'' as SUBJECTNAME "
            + ",''" + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS'' as DATABASEOBJECTNAME "
            + ",CURRENT_DATE as TESTDATE "
            + ",''TM-CTRL-01 - Quantité de début'' as TESTNAME "
            + ",''Quantité'' as UNITOFMEASURE "
            + ",ROUND(SUM(QUANTITE_FINALE)) as CONTROLVALUE "
            + ",''Source'' as CONTROLTYPE "
            + "FROM " + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS l "
            + "INNER JOIN " + DWH_DATABASE + FSC_SCHEMA + "V_LOAD_TM_SNAPSHOTDATES d ON l.PERIODE_COMPTABLE = LEFT(d.SNAPSHOT_PREVIOUS_YEAREND,7)"
    var SqlCmd_Control1 = {sqlText: sql_Control1};
    var Stmt_Control1 = snowflake.createStatement(SqlCmd_Control1);  
    sReturn = sReturn + "\\r\\n" + "\\r\\n" + Stmt_Control1.getSqlText();
    var Rs_Control1 = Stmt_Control1.execute();   


    // ===========================================================================================================================================
    // TM-CTRL-02
    // Insère la valeur finale totale de l''année précédente comme point de contrôle Source.
    // ===========================================================================================================================================
    var sql_Control2 = "INSERT INTO " + DWH_DATABASE + TOOLS_SCHEMA + "DATACONTROLS(MD_AUDIT_ID, MD_CREATION_DATE, APPLICATIONNAME, DATABASENAME, SUBJECTNAME, DATABASEOBJECTNAME, TESTDATE, TESTNAME, UNITOFMEASURE, CONTROLVALUE, CONTROLTYPE) "
            + "SELECT "
            + "''" + PAUDITID + "''  as MD_AUDIT_ID "
            + ",CURRENT_TIMESTAMP as MD_CREATION_DATE "
            + ",''TaxModel'' as APPLICATIONNAME "
            + ",''" + DWH_DATABASE.replace(".", "") +  "'' as DATABASENAME "
            + ",''Lots'' as SUBJECTNAME "
            + ",''" + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS'' as DATABASEOBJECTNAME "
            + ",CURRENT_DATE as TESTDATE "
            + ",''TM-CTRL-02 - Valeur de début'' as TESTNAME "
            + ",''Montant'' as UNITOFMEASURE "
            + ",ROUND(SUM(VALEUR_FINALE)) as CONTROLVALUE "
            + ",''Source'' as CONTROLTYPE "
            + "FROM " + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS l "
            + "INNER JOIN " + DWH_DATABASE + FSC_SCHEMA + "V_LOAD_TM_SNAPSHOTDATES d ON l.PERIODE_COMPTABLE = LEFT(d.SNAPSHOT_PREVIOUS_YEAREND,7)"
    var SqlCmd_Control2 = {sqlText: sql_Control2};
    var Stmt_Control2 = snowflake.createStatement(SqlCmd_Control2); 
    sReturn = sReturn + "\\r\\n" + "\\r\\n" + Stmt_Control2.getSqlText();
    var Rs_Control2 = Stmt_Control2.execute();   



    return sReturn;
';
CREATE OR REPLACE PROCEDURE "SP_CONV_RUNDATACONTROLS_TARGET"("PAUDITID" VARCHAR(100))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
    // Extraction des paramètres de BD et Schema
    var sReturn = ""
    var sSql_Description = "Select concat(''_'',split(CURRENT_DATABASE(),''_'')[2])::STRING as DB_Name, ifnull(concat(''_'',split(CURRENT_SCHEMA(),''_'')[1]),'''') as Schema_Name;";

    var objSqlCmd_DB_PARAM = {sqlText: sSql_Description}
    var objStmt_DB_PARAM = snowflake.createStatement(objSqlCmd_DB_PARAM);  
    var objRs_DB_PARAM = objStmt_DB_PARAM.execute();  
          
    while (objRs_DB_PARAM.next()){
          vDatabase = objRs_DB_PARAM.getColumnValue(1);
          vSchema = objRs_DB_PARAM.getColumnValue(2);
     };

    var DATABASE_ENV = vDatabase;
    var SCHEMA_ENV  = vSchema;
    
    ////DB VARIABLES
    var STG_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_STG.'';
    var DWH_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_DWH.'';
    var DM_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_DM.'';

    //// SCHEMA VARIABLE
    var FSC_SCHEMA = ''FSC'' + SCHEMA_ENV + ''.'';
    var TOOLS_SCHEMA = ''TOOLS'' + SCHEMA_ENV + ''.'';

    // ===========================================================================================================================================
    // TM-CTRL-01
    // Insère la quantité initiale total de la période courante comme point de contrôle Target.
    // ===========================================================================================================================================
    var sql_Control1 = "INSERT INTO " + DWH_DATABASE + TOOLS_SCHEMA + "DATACONTROLS(MD_AUDIT_ID, MD_CREATION_DATE, APPLICATIONNAME, DATABASENAME, SUBJECTNAME, DATABASEOBJECTNAME, TESTDATE, TESTNAME, UNITOFMEASURE, CONTROLVALUE, CONTROLTYPE) "
            + "SELECT "
            + "''" + PAUDITID + "''  as MD_AUDIT_ID "
            + ",CURRENT_TIMESTAMP as MD_CREATION_DATE "
            + ",''TaxModel'' as APPLICATIONNAME "
            + ",''" + DWH_DATABASE.replace(".", "") +  "'' as DATABASENAME "
            + ",''Lots'' as SUBJECTNAME "
            + ",''" + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS'' as DATABASEOBJECTNAME "
            + ",CURRENT_DATE as TESTDATE "
            + ",''TM-CTRL-01 - Quantité de début'' as TESTNAME "
            + ",''Quantité'' as UNITOFMEASURE "
            + ",ROUND(SUM(QUANTITE_INITIALE)) as CONTROLVALUE "
            + ",''Target'' as CONTROLTYPE "
            + "FROM " + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS l "
            + "INNER JOIN " + DWH_DATABASE + FSC_SCHEMA + "V_LOAD_TM_SNAPSHOTDATES d ON l.PERIODE_COMPTABLE = d.PERIODE_COMPTABLE"
    var SqlCmd_Control1 = {sqlText: sql_Control1};
    var Stmt_Control1 = snowflake.createStatement(SqlCmd_Control1);  
    sReturn = sReturn + "\\r\\n" + "\\r\\n" + Stmt_Control1.getSqlText();
    var Rs_Control1 = Stmt_Control1.execute();   


    // ===========================================================================================================================================
    // TM-CTRL-02
    // Insère la valeur initiale total de la période courante comme point de contrôle Target.
    // ===========================================================================================================================================
    var sql_Control2 = "INSERT INTO " + DWH_DATABASE + TOOLS_SCHEMA + "DATACONTROLS(MD_AUDIT_ID, MD_CREATION_DATE, APPLICATIONNAME, DATABASENAME, SUBJECTNAME, DATABASEOBJECTNAME, TESTDATE, TESTNAME, UNITOFMEASURE, CONTROLVALUE, CONTROLTYPE) "
            + "SELECT "
            + "''" + PAUDITID + "''  as MD_AUDIT_ID "
            + ",CURRENT_TIMESTAMP as MD_CREATION_DATE "
            + ",''TaxModel'' as APPLICATIONNAME "
            + ",''" + DWH_DATABASE.replace(".", "") +  "'' as DATABASENAME "
            + ",''Lots'' as SUBJECTNAME "
            + ",''" + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS'' as DATABASEOBJECTNAME "
            + ",CURRENT_DATE as TESTDATE "
            + ",''TM-CTRL-02 - Valeur de début'' as TESTNAME "
            + ",''Montant'' as UNITOFMEASURE "
            + ",ROUND(SUM(VALEUR_INITIALE)) as CONTROLVALUE "
            + ",''Target'' as CONTROLTYPE "
            + "FROM " + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS l "
            + "INNER JOIN " + DWH_DATABASE + FSC_SCHEMA + "V_LOAD_TM_SNAPSHOTDATES d ON l.PERIODE_COMPTABLE = d.PERIODE_COMPTABLE"
    var SqlCmd_Control2 = {sqlText: sql_Control2};
    var Stmt_Control2 = snowflake.createStatement(SqlCmd_Control2);  
    sReturn = sReturn + "\\r\\n" + "\\r\\n" + Stmt_Control2.getSqlText();
    var Rs_Control2 = Stmt_Control2.execute();   


    return sReturn;
';
CREATE OR REPLACE PROCEDURE "SP_RUNDATACHECK"("PAUDITID" VARCHAR(100))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

    // Extraction des paramètres de BD et Schema
    var sSql_Description = "Select CURRENT_DATABASE() as DB_Name, CURRENT_SCHEMA() as Schema_Name";

    var objSqlCmd_DB_PARAM = {sqlText: sSql_Description}
    var objStmt_DB_PARAM = snowflake.createStatement(objSqlCmd_DB_PARAM);  
    var objRs_DB_PARAM = objStmt_DB_PARAM.execute();  
          
    while (objRs_DB_PARAM.next()){
          vDatabase = objRs_DB_PARAM.getColumnValue(1);
          vSchema = objRs_DB_PARAM.getColumnValue(2);
     };
    
    // Pour les version en DEV, aligne le nom du schéma tools avec le nom du schéma applicatif source.
    var vToolsSchema = "TOOLS"
    var vLen = vSchema.length
    
    if (vSchema.toUpperCase().slice(vLen-4, vLen) == "_DEV")
    {
        vToolsSchema = vToolsSchema + "_DEV"
    }

    
    // ===============================================================================================================================================
    // Lance les appels de validation de qualité des données. Chaque objet à vérifier doit être encapsulé dans une vue standard préfixé de v_quality dans le schema UnitTests
    // ===============================================================================================================================================
    var sql_sp_CheckDataQuality = "CALL DB_CTB_DEV_DWH." + vToolsSchema + ".sp_CheckDataQuality(?,?,?,?,?,?)"

    snowflake.execute( {sqlText: sql_sp_CheckDataQuality, binds:[PAUDITID, "Tax Model", "Validation des lots", vDatabase, vSchema, "V_QUALITY_TM_LOTS"]} );
    
return ''Done''
';
CREATE OR REPLACE PROCEDURE "SP_RUNDATACONTROLS_SOURCE"("PAUDITID" VARCHAR(100))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
    // Extraction des paramètres de BD et Schema
    var sReturn = ""
    var sSql_Description = "Select concat(''_'',split(CURRENT_DATABASE(),''_'')[2])::STRING as DB_Name, ifnull(concat(''_'',split(CURRENT_SCHEMA(),''_'')[1]),'''') as Schema_Name;";

    var objSqlCmd_DB_PARAM = {sqlText: sSql_Description}
    var objStmt_DB_PARAM = snowflake.createStatement(objSqlCmd_DB_PARAM);  
    var objRs_DB_PARAM = objStmt_DB_PARAM.execute();  
          
    while (objRs_DB_PARAM.next()){
          vDatabase = objRs_DB_PARAM.getColumnValue(1);
          vSchema = objRs_DB_PARAM.getColumnValue(2);
     };

    var DATABASE_ENV = vDatabase;
    var SCHEMA_ENV  = vSchema;
    
    ////DB VARIABLES
    var STG_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_STG.'';
    var DWH_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_DWH.'';
    var DM_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_DM.'';

    //// SCHEMA VARIABLE
    var FSC_SCHEMA = ''FSC'' + SCHEMA_ENV + ''.'';
    var TOOLS_SCHEMA = ''TOOLS'' + SCHEMA_ENV + ''.'';
    


    // ===========================================================================================================================================
    // TM-CTRL-01
    // Insère la quantité finale totale de l''année précédente comme point de contrôle Source.
    // ===========================================================================================================================================
    var sql_Control1 = "INSERT INTO " + DWH_DATABASE + TOOLS_SCHEMA + "DATACONTROLS(MD_AUDIT_ID, MD_CREATION_DATE, APPLICATIONNAME, DATABASENAME, SUBJECTNAME, DATABASEOBJECTNAME, TESTDATE, TESTNAME, UNITOFMEASURE, CONTROLVALUE, CONTROLTYPE) "
            + "SELECT "
            + "''" + PAUDITID + "''  as MD_AUDIT_ID "
            + ",CURRENT_TIMESTAMP as MD_CREATION_DATE "
            + ",''TaxModel'' as APPLICATIONNAME "
            + ",''" + DWH_DATABASE.replace(".", "") +  "'' as DATABASENAME "
            + ",''Lots'' as SUBJECTNAME "
            + ",''" + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS'' as DATABASEOBJECTNAME "
            + ",CURRENT_DATE as TESTDATE "
            + ",''TM-CTRL-01 - Quantité de début'' as TESTNAME "
            + ",''Quantité'' as UNITOFMEASURE "
            + ",ROUND(SUM(QUANTITE_FINALE)) as CONTROLVALUE "
            + ",''Source'' as CONTROLTYPE "
            + "FROM " + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS l "
            + "INNER JOIN " + DWH_DATABASE + FSC_SCHEMA + "V_LOAD_TM_SNAPSHOTDATES d ON l.PERIODE_COMPTABLE = LEFT(d.SNAPSHOT_PREVIOUS_YEAREND,7)"
    var SqlCmd_Control1 = {sqlText: sql_Control1};
    var Stmt_Control1 = snowflake.createStatement(SqlCmd_Control1);  
    sReturn = sReturn + "\\r\\n" + "\\r\\n" + Stmt_Control1.getSqlText();
    var Rs_Control1 = Stmt_Control1.execute();   


    // ===========================================================================================================================================
    // TM-CTRL-02
    // Insère la valeur finale totale de l''année précédente comme point de contrôle Source.
    // ===========================================================================================================================================
    var sql_Control2 = "INSERT INTO " + DWH_DATABASE + TOOLS_SCHEMA + "DATACONTROLS(MD_AUDIT_ID, MD_CREATION_DATE, APPLICATIONNAME, DATABASENAME, SUBJECTNAME, DATABASEOBJECTNAME, TESTDATE, TESTNAME, UNITOFMEASURE, CONTROLVALUE, CONTROLTYPE) "
            + "SELECT "
            + "''" + PAUDITID + "''  as MD_AUDIT_ID "
            + ",CURRENT_TIMESTAMP as MD_CREATION_DATE "
            + ",''TaxModel'' as APPLICATIONNAME "
            + ",''" + DWH_DATABASE.replace(".", "") +  "'' as DATABASENAME "
            + ",''Lots'' as SUBJECTNAME "
            + ",''" + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS'' as DATABASEOBJECTNAME "
            + ",CURRENT_DATE as TESTDATE "
            + ",''TM-CTRL-02 - Valeur de début'' as TESTNAME "
            + ",''Montant'' as UNITOFMEASURE "
            + ",ROUND(SUM(VALEUR_FINALE)) as CONTROLVALUE "
            + ",''Source'' as CONTROLTYPE "
            + "FROM " + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS l "
            + "INNER JOIN " + DWH_DATABASE + FSC_SCHEMA + "V_LOAD_TM_SNAPSHOTDATES d ON l.PERIODE_COMPTABLE = LEFT(d.SNAPSHOT_PREVIOUS_YEAREND,7)"
    var SqlCmd_Control2 = {sqlText: sql_Control2};
    var Stmt_Control2 = snowflake.createStatement(SqlCmd_Control2); 
    sReturn = sReturn + "\\r\\n" + "\\r\\n" + Stmt_Control2.getSqlText();
    var Rs_Control2 = Stmt_Control2.execute();   



    return sReturn;
';
CREATE OR REPLACE PROCEDURE "SP_RUNDATACONTROLS_TARGET"("PAUDITID" VARCHAR(100))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
    // Extraction des paramètres de BD et Schema
    var sReturn = ""
    var sSql_Description = "Select concat(''_'',split(CURRENT_DATABASE(),''_'')[2])::STRING as DB_Name, ifnull(concat(''_'',split(CURRENT_SCHEMA(),''_'')[1]),'''') as Schema_Name;";

    var objSqlCmd_DB_PARAM = {sqlText: sSql_Description}
    var objStmt_DB_PARAM = snowflake.createStatement(objSqlCmd_DB_PARAM);  
    var objRs_DB_PARAM = objStmt_DB_PARAM.execute();  
          
    while (objRs_DB_PARAM.next()){
          vDatabase = objRs_DB_PARAM.getColumnValue(1);
          vSchema = objRs_DB_PARAM.getColumnValue(2);
     };

    var DATABASE_ENV = vDatabase;
    var SCHEMA_ENV  = vSchema;
    
    ////DB VARIABLES
    var STG_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_STG.'';
    var DWH_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_DWH.'';
    var DM_DATABASE = ''DB_CTB'' + DATABASE_ENV + ''_DM.'';

    //// SCHEMA VARIABLE
    var FSC_SCHEMA = ''FSC'' + SCHEMA_ENV + ''.'';
    var TOOLS_SCHEMA = ''TOOLS'' + SCHEMA_ENV + ''.'';

    // ===========================================================================================================================================
    // TM-CTRL-01
    // Insère la quantité initiale total de la période courante comme point de contrôle Target.
    // ===========================================================================================================================================
    var sql_Control1 = "INSERT INTO " + DWH_DATABASE + TOOLS_SCHEMA + "DATACONTROLS(MD_AUDIT_ID, MD_CREATION_DATE, APPLICATIONNAME, DATABASENAME, SUBJECTNAME, DATABASEOBJECTNAME, TESTDATE, TESTNAME, UNITOFMEASURE, CONTROLVALUE, CONTROLTYPE) "
            + "SELECT "
            + "''" + PAUDITID + "''  as MD_AUDIT_ID "
            + ",CURRENT_TIMESTAMP as MD_CREATION_DATE "
            + ",''TaxModel'' as APPLICATIONNAME "
            + ",''" + DWH_DATABASE.replace(".", "") +  "'' as DATABASENAME "
            + ",''Lots'' as SUBJECTNAME "
            + ",''" + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS'' as DATABASEOBJECTNAME "
            + ",CURRENT_DATE as TESTDATE "
            + ",''TM-CTRL-01 - Quantité de début'' as TESTNAME "
            + ",''Quantité'' as UNITOFMEASURE "
            + ",ROUND(SUM(QUANTITE_INITIALE)) as CONTROLVALUE "
            + ",''Target'' as CONTROLTYPE "
            + "FROM " + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS l "
            + "INNER JOIN " + DWH_DATABASE + FSC_SCHEMA + "V_LOAD_TM_SNAPSHOTDATES d ON l.PERIODE_COMPTABLE = d.PERIODE_COMPTABLE"
    var SqlCmd_Control1 = {sqlText: sql_Control1};
    var Stmt_Control1 = snowflake.createStatement(SqlCmd_Control1);  
    sReturn = sReturn + "\\r\\n" + "\\r\\n" + Stmt_Control1.getSqlText();
    var Rs_Control1 = Stmt_Control1.execute();   


    // ===========================================================================================================================================
    // TM-CTRL-02
    // Insère la valeur initiale total de la période courante comme point de contrôle Target.
    // ===========================================================================================================================================
    var sql_Control2 = "INSERT INTO " + DWH_DATABASE + TOOLS_SCHEMA + "DATACONTROLS(MD_AUDIT_ID, MD_CREATION_DATE, APPLICATIONNAME, DATABASENAME, SUBJECTNAME, DATABASEOBJECTNAME, TESTDATE, TESTNAME, UNITOFMEASURE, CONTROLVALUE, CONTROLTYPE) "
            + "SELECT "
            + "''" + PAUDITID + "''  as MD_AUDIT_ID "
            + ",CURRENT_TIMESTAMP as MD_CREATION_DATE "
            + ",''TaxModel'' as APPLICATIONNAME "
            + ",''" + DWH_DATABASE.replace(".", "") +  "'' as DATABASENAME "
            + ",''Lots'' as SUBJECTNAME "
            + ",''" + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS'' as DATABASEOBJECTNAME "
            + ",CURRENT_DATE as TESTDATE "
            + ",''TM-CTRL-02 - Valeur de début'' as TESTNAME "
            + ",''Montant'' as UNITOFMEASURE "
            + ",ROUND(SUM(VALEUR_INITIALE)) as CONTROLVALUE "
            + ",''Target'' as CONTROLTYPE "
            + "FROM " + DM_DATABASE + FSC_SCHEMA + "V_TM_LOTS l "
            + "INNER JOIN " + DWH_DATABASE + FSC_SCHEMA + "V_LOAD_TM_SNAPSHOTDATES d ON l.PERIODE_COMPTABLE = d.PERIODE_COMPTABLE"
    var SqlCmd_Control2 = {sqlText: sql_Control2};
    var Stmt_Control2 = snowflake.createStatement(SqlCmd_Control2);  
    sReturn = sReturn + "\\r\\n" + "\\r\\n" + Stmt_Control2.getSqlText();
    var Rs_Control2 = Stmt_Control2.execute();   


    return sReturn;
';
create or replace schema FSC_DEV;

create or replace TABLE DUMMY (
	DUMMY VARCHAR(10)
);
create or replace view V_QUALITY_TM_LOTS(
	TESTNAME,
	OBJECTNAME,
	MISSINGVALUE
) as

/* Ecarts Positions */
-- Retourne les combinaison de Fonds/Titres pour la période en cours de chargement qui sortent en écart selon la vue V_TM_LOTS_DISCREPANCY

SELECT DISTINCT
    'Écart de position' as TestName, 
    'V_TM_LOTS_DISCREPANCY ==> ' || 'FONDS : ' || f.NOM_FONDS || ' | TITRE : ' || t.CODE_TITRE as ObjectName, 
     IFF(ROUND(QUANTITE_FINALE) <> ROUND(QUANTITE_INITIALE), 'QUANTITE_INITIALE ', '')
        || IFF(ROUND(VALEUR_FINALE) <> ROUND(VALEUR_INITIALE), 'VALEUR_INITIALE ', '')
        AS MissingValue
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS_DISCREPANCY d
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON d.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_TM_FONDS f ON d.ID_FONDS = f.ID_FONDS
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_TM_TITRES t ON d.ID_TITRE = t.ID_TITRE

UNION

/* Fonds Disparus */
-- Retourne les  Fonds pour la période en cours de chargement qui manquent selon la vue V_TM_LOTS_FONDS_DISPARUS
SELECT DISTINCT
    'Fonds Disparus' as TestName, 
    'V_TM_LOTS_FONDS_DISPARUS ==> ' || 'FONDS : ' || l.ID_FONDS|| '|PERIODE COMPTABLE: '   || l.PERIODE_COMPTABLE || '|PERIODE COMPARATIVE: ' ||l. PERIODE_COMPARATIVE ||'|FONDS MANQUANTS: ' || l.ID_FONDS2 as ObjectName, 
    'FONDS: '|| f.NOM_FONDS || '|ID: '||l.ID_FONDS || '|TYPE: ' || f.TYPE_FONDS as MissingValue
       
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS_FONDS_DISPARUS l
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON l.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_TM_FONDS f ON l.ID_FONDS = f.ID_FONDS



/*===============================================================================================================================
=================================================================================================================================

Les Requêtes suivantes servent à détecter pour une période comptable ( la période courante) le métrique dont la somme est égale à 0 

====================================================================================================================================
=====================================================================================================================================*/


UNION

/* Table des Lots*/

SELECT 
    'Somme Métrique Nulle' as TestName,
    'Détection Valeur Nulle ==> ' || 'METRIQUE : ' || 'VALEUR_FINALE' || '| PERIODE COURANTE: ' || l.PERIODE_COMPTABLE as ObjectName,
     IFF (SUM(l.VALEUR_FINALE) <> 0, '', SUM(l.VALEUR_FINALE)) 
         AS  MissingValue
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON l.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
GROUP BY l.PERIODE_COMPTABLE, l.VALEUR_FINALE
HAVING SUM (l.VALEUR_FINALE) = 0
       

UNION

SELECT 
    'Somme Métrique Nulle' as TestName,
    'Détection Valeur Nulle ==> ' || 'METRIQUE : ' || 'QUANTITE_FINALE' || '| PERIODE COURANTE: ' || l.PERIODE_COMPTABLE as ObjectName,
     IFF (SUM (l.QUANTITE_FINALE) <> 0, '', SUM(l.QUANTITE_FINALE)) 
         AS  MissingValue
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON l.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
GROUP BY l.PERIODE_COMPTABLE, l.QUANTITE_FINALE
HAVING SUM (l.QUANTITE_FINALE) = 0

UNION

SELECT 
    'Somme Métrique Nulle' as TestName,
    'Détection Valeur Nulle ==> ' || 'METRIQUE : ' || 'QUANTITE_ACHETEE' || '| PERIODE COURANTE: ' || l.PERIODE_COMPTABLE as ObjectName,
     IFF (SUM (l.QUANTITE_ACHETEE) <> 0, '', SUM(l.QUANTITE_ACHETEE)) 
         AS  MissingValue
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON l.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
GROUP BY l.PERIODE_COMPTABLE, l.QUANTITE_ACHETEE
HAVING SUM (l.QUANTITE_ACHETEE) = 0

UNION

SELECT 
    'Somme Métrique Nulle' as TestName,
    'Détection Valeur Nulle ==> ' || 'METRIQUE : ' || 'QUANTITE_VENDUE' || '| PERIODE COURANTE: ' || l.PERIODE_COMPTABLE as ObjectName,
     IFF (SUM (l.QUANTITE_VENDUE) <> 0, '', SUM(l.QUANTITE_VENDUE)) 
         AS  MissingValue
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON l.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
GROUP BY l.PERIODE_COMPTABLE, l.QUANTITE_VENDUE
HAVING SUM (l.QUANTITE_VENDUE) = 0

UNION

SELECT 
    'Somme Métrique Nulle' as TestName,
    'Détection Valeur Nulle ==> ' || 'METRIQUE : ' || 'COUT_ACQUISITION' || '| PERIODE COURANTE: ' || l.PERIODE_COMPTABLE as ObjectName,
    IFF(SUM (l.COUT_ACQUISITION)   <> 0, '', SUM(l.COUT_ACQUISITION)) 
         AS  MissingValue
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON l.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
GROUP BY l.PERIODE_COMPTABLE, l.COUT_ACQUISITION
HAVING SUM(l.COUT_ACQUISITION) = 0

UNION

SELECT 
    'Somme Métrique Nulle' as TestName,
    'Détection Valeur Nulle ==> ' || 'METRIQUE : ' || 'MONTANT_VENTE' || '| PERIODE COURANTE: ' || l.PERIODE_COMPTABLE as ObjectName,
    IFF(SUM (l.MONTANT_VENTE)   <> 0, '', SUM(l.MONTANT_VENTE)) 
         AS  MissingValue
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON l.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
GROUP BY l.PERIODE_COMPTABLE, l.MONTANT_VENTE
HAVING SUM(l.MONTANT_VENTE) = 0;
create or replace view V_QUALITY_TM_REVENU(
	TESTNAME,
	OBJECTNAME,
	MISSINGVALUE
) as
-- Retourne les  Fonds pour la période en cours de chargement qui manquent selon la vue V_TM_REVENU_FONDS_DISPARUS
SELECT DISTINCT
    'Fonds Disparus' as TestName, 
    'V_TM_REVENU_FONDS_DISPARUS ==> ' || 'FONDS : ' || r.ID_FONDS || '|PERIODE COMPTABLE :'    || r.PERIODE_COMPTABLE || '|PERIODE COMPARATIVE : ' ||r. PERIODE_COMPARATIVE ||'|FONDS MANQUANTS : ' || r.ID_FONDS2  as ObjectName, 
    'FONDS : '|| f.NOM_FONDS || '|ID  '||r.ID_FONDS || '|TYPE : ' || f.TYPE_FONDS as MissingValue
       
FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_REVENU_FONDS_DISPARUS r
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_LOAD_TM_SNAPSHOTDATES s ON r.PERIODE_COMPTABLE = s.PERIODE_COMPTABLE
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_TM_FONDS f ON r.ID_FONDS = f.ID_FONDS;
create or replace view V_TM_LOTS(
	PERIODE_COMPTABLE,
	ID_FONDS,
	ID_TITRE,
	NOM_FONDS,
	ID_FILIALE,
	DEVISE_FONDS,
	CODE_TITRE,
	NOM_TITRE,
	DESCRIPTION_EMETTEUR,
	TYPE_TITRE,
	PAYS_EMETTEUR,
	DEVISE_TITRE,
	COUPON,
	DATE_ECHEANCE,
	FREQUENCE_COUPON,
	TYPE_SOUS_TITRE,
	TYPE_LOT,
	ID_LOT,
	TYPE_POSITION,
	DATE_TRANSACTION,
	TYPE_TRANSACTION,
	NOMBRE_JOURS_DETENUS,
	QUANTITE_INITIALE,
	QUANTITE_ACHETEE,
	QUANTITE_VENDUE,
	QUANTITE_FINALE,
	VALEUR_INITIALE,
	COUT_ACQUISITION,
	MONTANT_VENTE,
	VALEUR_FINALE,
	INTERET_COURU_INITIAL,
	INTERET_COURU_ACHAT,
	INTERET_COURU_VENTE,
	INTERET_COURU_FINAL,
	DATE_ACHAT,
	DATE_VENTE,
	GAINS_PERTE_PRIX_TITRE,
	GAINS_PERTE_DEVISE,
	QUANTITE_CONTROLE
) as

/*
Auth:   Laurette Bakebana Zola
Date:   2022-01-05
Desc:   Vue de consommation qui retourne les dernières données des lots par période comptable.

SELECT * FROM ""DB_CTB_DEV_DWH"".""FSC_DEV"".""REF_TM_SNAPSHOTDATES""
SELECT * FROM ""DB_CTB_DEV_DWH"".""FSC_DEV"".""LINK_TM_LOTS"" WHERE MD_AUDIT_ID = '683674041229615104'

*/
WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE
)


SELECT
    l.Periode_comptable,
    l.ID_FONDS,
    l.ID_TITRE,
    NVL(fonds.NOM_FONDS,'') as NOM_FONDS,
    NVL(fonds.CODE_FONDS_EBS,'') as ID_FILIALE,
    NVL(fonds.DEVISE_FONDS,'') as DEVISE_FONDS,
    NVL(t.CODE_TITRE,'') as CODE_TITRE,
    NVL(t.NOM_TITRE,'') as NOM_TITRE,
    NVL(t.DESCRIPTION_EMETTEUR,'') as DESCRIPTION_EMETTEUR,
    NVL(t.TYPE_TITRE,'') as TYPE_TITRE,
    NVL(t.PAYS_EMETTEUR,'') as PAYS_EMETTEUR,
    NVL(t.DEVISE_TITRE,'') as DEVISE_TITRE,
    NVL(TRY_TO_NUMERIC(t.COUPON,38,12),0) as COUPON,
    t.DATE_ECHEANCE as DATE_ECHEANCE,
    NVL(t.FREQUENCE_COUPON,'') as FREQUENCE_COUPON,
    NVL(t.TYPE_SOUS_TITRE,'') as TYPE_SOUS_TITRE,
    l.TYPE_LOT,
    l.ID_LOT,
	l.TYPE_POSITION,
    l.DATE_TRANSACTION as DATE_TRANSACTION,
    NVL(l.TYPE_TRANSACTION,'') as TYPE_TRANSACTION,  
    NVL(l.NOMBRE_JOURS_DETENUS,0) as NOMBRE_JOURS_DETENUS,
    NVL(l.QUANTITE_INITIALE, 0) as QUANTITE_INITIALE,
   	NVL(l.QUANTITE_ACHETEE, 0) as QUANTITE_ACHETEE, 
    NVL(l.QUANTITE_VENDUE, 0) as QUANTITE_VENDUE,
    NVL(l.QUANTITE_FINALE, 0) as QUANTITE_FINALE,
    NVL(l.VALEUR_INITIALE, 0) as VALEUR_INITIALE,
    NVL(l.COUT_ACQUISITION, 0) as COUT_ACQUISITION,
    NVL(l.MONTANT_VENTE, 0) as MONTANT_VENTE, 
    NVL(l.VALEUR_FINALE, 0) as VALEUR_FINALE,
	NVL(l.INTERET_COURU_INITIAL, 0) as INTERET_COURU_INITIAL,
    NVL(l.INTERET_COURU_ACHAT, 0) as INTERET_COURU_ACHAT,
    NVL(l.INTERET_COURU_VENTE, 0) as INTERET_COURU_VENTE,
    NVL(l.INTERET_COURU_FINAL, 0) as INTERET_COURU_FINAL,
    l.DATE_ACHAT as DATE_ACHAT,
    l.DATE_VENTE as DATE_VENTE,
    NVL(l.GAINS_PERTE_PRIX_TITRE, 0) as GAINS_PERTE_PRIX_TITRE,   
    NVL(l.GAINS_PERTE_DEVISE, 0) as GAINS_PERTE_DEVISE, 
    NVL(l.QUANTITE_CONTROLE, 0) as QUANTITE_CONTROLE
 
FROM DB_CTB_DEV_DWH.FSC_DEV.LINK_TM_LOTS l
INNER JOIN CTE_Lots_Par_Period lp 
    ON l.Periode_comptable = lp.Periode_comptable 
        and l.MD_AUDIT_ID = lp.MD_AUDIT_ID  -- Filtre les données pour la dernière date de chargement de chacun des blocs de lots par période comptable.
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_TM_FONDS fonds
    ON l.ID_FONDS = fonds.ID_FONDS
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_TM_TITRES t
    ON l.ID_TITRE = t.ID_TITRE;
create or replace view V_TM_LOTS_DISCREPANCY(
	PERIODE_COMPTABLE,
	PERIODE_COMPARATIVE,
	ID_FONDS,
	ID_TITRE,
	TYPE_POSITION,
	ID_FONDS1,
	ID_TITRE1,
	TYPE_POSITION1,
	ID_FONDS2,
	ID_TITRE2,
	TYPE_POSITION2,
	QUANTITE_FINALE,
	QUANTITE_INITIALE,
	VALEUR_FINALE,
	VALEUR_INITIALE
) as

/*===============================================================================================================================
Auth:   Pierre Cusson
Date:   2021-02-04
Des :   Cette vue retourne l'ensemble des positions qui ont un écart entre entre les positions de départ de l'année courante
        et les positions de fins de l'année précédente. Le résultats de ces écarts a pour but d'être inscrit dans la table des 
        points de contrôles et ensuite affiché dans un dashboard à la ligne d'affaire
===============================================================================================================================*/

WITH CTE_Fin as(
    -- Extraction des valeurs de fin de l'année précédente, retourne les valeurs arrondi des SUM pour éliminer les écarts de cents.
    SELECT  l.PERIODE_COMPTABLE, l.ID_FONDS, l.ID_TITRE, l.TYPE_POSITION,
        ROUND(SUM(QUANTITE_FINALE)) AS QUANTITE_FINALE, 
        ROUND(SUM(VALEUR_FINALE)) as VALEUR_FINALE
    FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
    GROUP BY l.PERIODE_COMPTABLE, l.ID_FONDS, l.ID_TITRE, l.TYPE_POSITION
)


    
, CTE_Depart as (
    -- Extraction des valeurs de début de l'année courante
    SELECT  l.PERIODE_COMPTABLE,
        (LEFT(l.PERIODE_COMPTABLE,4)::INT - 1)::STRING || '-12' as PERIODE_COMPTABLE_COMPARATIVE,  -- Retourne la période 12 de l'année précédente pour être liée en tant que période comparative
        l.ID_FONDS, l.ID_TITRE, l.TYPE_POSITION,
        ROUND(SUM(QUANTITE_INITIALE)) AS QUANTITE_INITIALE, 
        ROUND(SUM(VALEUR_INITIALE)) as VALEUR_INITIALE
    FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
    GROUP BY l.PERIODE_COMPTABLE, l.ID_FONDS, l.ID_TITRE, l.TYPE_POSITION
)

-- Compare les deux set de valeurs et extrait ceux dont les valeurs sont différentes. Ceux-ci représenteraient une anomalies de données ou de processus.
SELECT 
    NVL(d.PERIODE_COMPTABLE, '') AS PERIODE_COMPTABLE,
    NVL(f.PERIODE_COMPTABLE, '') AS Periode_Comprative,
    COALESCE(F.ID_FONDS, d.ID_FONDS) AS ID_FONDS,
    COALESCE(F.ID_TITRE, d.ID_TITRE) AS ID_TITRE,
    COALESCE(F.TYPE_POSITION, d.TYPE_POSITION) AS TYPE_POSITION,
    F.ID_FONDS AS ID_FONDS1,
    F.ID_TITRE AS ID_TITRE1,
    F.TYPE_POSITION AS TYPE_POSITION1,
    d.ID_FONDS AS ID_FONDS2,
    d.ID_TITRE AS ID_TITRE2,
    d.TYPE_POSITION AS TYPE_POSITION2,
    NVL(f.QUANTITE_FINALE, 0) AS QUANTITE_FINALE,
    NVL(d.QUANTITE_INITIALE, 0) AS QUANTITE_INITIALE,
    NVL(f.VALEUR_FINALE, 0) AS VALEUR_FINALE,
    NVL(d.VALEUR_INITIALE, 0) AS VALEUR_INITIALE
FROM CTE_Depart d
FULL OUTER JOIN CTE_Fin f
    ON d.PERIODE_COMPTABLE_COMPARATIVE = f.PERIODE_COMPTABLE
    AND d.ID_FONDS = f.ID_FONDS
    AND d.ID_TITRE = f.ID_TITRE
    AND d.TYPE_POSITION = f.TYPE_POSITION
WHERE 
    ABS(QUANTITE_FINALE - QUANTITE_INITIALE) > 1
    OR 
    ABS(VALEUR_FINALE - VALEUR_INITIALE) > 1;
create or replace view V_TM_LOTS_FONDS_DISPARUS(
	PERIODE_COMPTABLE,
	PERIODE_COMPARATIVE,
	ID_FONDS,
	ID_FONDS1,
	ID_FONDS2
) as

/*===============================================================================================================================
Auth:   Laurette Zola
Date:   2022-04-27
Des :   Cette vue retourne la liste des fonds disparus d'une période à une autre. Le résultats de ces écarts a pour but d'être inscrit dans la table des 
        points de contrôles et ensuite affiché dans un dashboard à la ligne d'affaire
===============================================================================================================================*/

WITH CTE_Fin as(
    -- Extraction de la liste des Fonds de la période courante, retourne une liste des fonds distincts contenus dans la table des Lots.
    SELECT  DISTINCT l.PERIODE_COMPTABLE, 
            l.ID_FONDS
    FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l

)


    
, CTE_Depart as (
    -- Extraction de la liste des Fonds de la période précedente, retourne une liste des fonds distincts contenus dans la table des Lots.
    SELECT  DISTINCT l.PERIODE_COMPTABLE As PERIODE_COMPTABLE_COMPARATIVE,
            l.ID_FONDS,
        CONCAT(LEFT(l.PERIODE_COMPTABLE,4)::STRING, '-', right('0'||((right(l.PERIODE_COMPTABLE,2)::INT + 1)::STRING),2)) as PERIODE_COMPTABLE  -- Retourne la période précédente pour être liée en tant que période comparative. Cela permettra de comparer à chaque fois le nombre des fonds de la période courante à celui de la période précedente. 
      
    FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_LOTS l
 
)

-- Compare les deux set de valeurs et renvoi la liste des fonds diparus. Ceux-ci représenteraient une anomalies de données ou de processus.
SELECT 
    NVL(d.PERIODE_COMPTABLE, '') AS PERIODE_COMPTABLE,
    NVL(f.PERIODE_COMPTABLE, '') AS PERIODE_COMPARATIVE,
    COALESCE(f.ID_FONDS, d.ID_FONDS) AS ID_FONDS,
    f.ID_FONDS AS ID_FONDS1,
    d.ID_FONDS AS ID_FONDS2
FROM CTE_Depart d  
LEFT JOIN CTE_Fin f 
    ON  d.PERIODE_COMPTABLE = f.PERIODE_COMPTABLE
    AND d.ID_FONDS = f.ID_FONDS 
WHERE 
   ID_FONDS1 is NULL;
create or replace view V_TM_REVENU(
	PERIODE_COMPTABLE,
	ID_FONDS,
	NOM_FONDS,
	ID_FILIALE,
	DEVISE_FONDS,
	CODE_TITRE,
	NOM_TITRE,
	DESCRIPTION_EMETTEUR,
	TYPE_TITRE,
	PAYS_EMETTEUR,
	DEVISE_TITRE,
	COUPON,
	DATE_ECHEANCE,
	FREQUENCE_COUPON,
	TYPE_SOUS_TITRE,
	TYPE_POSITION,
	QUANTITE_INITIALE,
	QUANTITE_FINALE,
	INTERET_COURU_INITIAL,
	INTERET_COURU_FINAL,
	DIVIDENDES_RECEVOIR_INITIAL,
	DIVIDENDES_RECEVOIR_FINAL,
	COUPONS_PAYES,
	DIVIDENDES_VERSES,
	INTERETS_GAGNES,
	AMORTISSEMENTS,
	REVENUS_OBLIGATAIRES,
	URGL_DELTA_TITRE_OCI,
	URGL_DELTA_DEVISE_OCI,
	REVENU_LOCAL,
	REVENU_ETRANGER,
	DIVIDENDE_LOCAL,
	DIVIDENDE_ETRANGER,
	GAINS_PERTES_REALISES_PRIX_TITRES_OCI,
	GAINS_PERTES_REALISES_DEVISE_OCI,
	URGL_PRIX_TITRES,
	URGL_DEVISE_FONDS,
	FRAIS_TRANSACTION,
	IMPOT_RETENU_SOURCE,
	GAINS_PERTES_REALISES_PRIX_TITRES,
	COUT_AJUSTEMENT
) as

/*
Auth:   Pierre Cusson
Date:   2021-12-31
Desc:   Vue de consommation qui retourne les dernières données de revenu par période comptable.

*/
WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Revenu_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE
)

SELECT
    r.Periode_comptable,
    NVL(fonds.ID_FONDS,'') as ID_FONDS,
    NVL(fonds.NOM_FONDS,'') as NOM_FONDS,
    NVL(fonds.CODE_FONDS_EBS,'') as ID_FILIALE,
    NVL(fonds.DEVISE_FONDS,'') as DEVISE_FONDS,
    NVL(titres.CODE_TITRE,'') as CODE_TITRE,
    NVL(titres.NOM_TITRE,'') as NOM_TITRE,
    NVL(titres.DESCRIPTION_EMETTEUR,'') as DESCRIPTION_EMETTEUR,
    NVL(titres.TYPE_TITRE,'') as TYPE_TITRE,
    NVL(titres.PAYS_EMETTEUR,'') as PAYS_EMETTEUR,
    NVL(titres.DEVISE_TITRE,'') as DEVISE_TITRE,
    NVL(titres.COUPON,0) as COUPON,
    TRY_TO_DATE(titres.DATE_ECHEANCE::STRING, 'YYYY-MM-DD') as DATE_ECHEANCE,
    NVL(titres.FREQUENCE_COUPON, '') as FREQUENCE_COUPON,
    NVL(titres.TYPE_SOUS_TITRE,'') as TYPE_SOUS_TITRE,
	r.TYPE_POSITION, 
    NVL(r.QUANTITE_INITIALE, 0) as QUANTITE_INITIALE,
   	NVL(r.QUANTITE_FINALE, 0) as QUANTITE_FINALE, 
	NVL(r.INTERET_COURU_INITIAL, 0) as INTERET_COURU_INITIAL, 
	NVL(r.INTERET_COURU_FINAL, 0) as INTERET_COURU_FINAL, 
	NVL(r.DIVIDENDES_RECEVOIR_INITIAL, 0) as DIVIDENDES_RECEVOIR_INITIAL, 
	NVL(r.DIVIDENDES_RECEVOIR_FINAL, 0) as DIVIDENDES_RECEVOIR_FINAL,
    NVL(r.COUPONS_PAYES, 0) as COUPONS_PAYES, 
	NVL(r.DIVIDENDES_VERSES, 0) as DIVIDENDES_VERSES, 
	NVL(r.INTERETS_GAGNES, 0) as INTERETS_GAGNES, 
	NVL(r.AMORTISSEMENTS, 0) as AMORTISSEMENTS, 
	NVL(r.REVENUS_OBLIGATAIRES, 0) as REVENUS_OBLIGATAIRES,
    NVL(r.URGL_DELTA_TITRE_OCI, 0) as URGL_DELTA_TITRE_OCI, 
   	NVL(r.URGL_DELTA_DEVISE_OCI, 0) as URGL_DELTA_DEVISE_OCI, 
	NVL(r.REVENU_LOCAL, 0) as REVENU_LOCAL, 
	NVL(r.REVENU_ETRANGER, 0) as REVENU_ETRANGER, 
	NVL(r.DIVIDENDE_LOCAL, 0) as DIVIDENDE_LOCAL, 
	NVL(r.DIVIDENDE_ETRANGER, 0) as DIVIDENDE_ETRANGER,
    NVL(r.GAINS_PERTES_REALISES_PRIX_TITRES_OCI, 0) as GAINS_PERTES_REALISES_PRIX_TITRES_OCI, 
	NVL(r.GAINS_PERTES_REALISES_DEVISE_OCI, 0) as GAINS_PERTES_REALISES_DEVISE_OCI, 
	NVL(r.URGL_PRIX_TITRES, 0) as URGL_PRIX_TITRES, 
	NVL(r.URGL_DEVISE_FONDS, 0) as URGL_DEVISE_FONDS, 
	NVL(r.FRAIS_TRANSACTION, 0) as FRAIS_TRANSACTION, 
	NVL(r.IMPOT_RETENU_SOURCE, 0) as IMPOT_RETENU_SOURCE, 
	NVL(r.GAINS_PERTES_REALISES_PRIX_TITRES, 0) as GAINS_PERTES_REALISES_PRIX_TITRES,
    NVL(r.COUT_AJUSTEMENT, 0) as COUT_AJUSTEMENT
FROM DB_CTB_DEV_DWH.FSC_DEV.LINK_TM_REVENU r
INNER JOIN CTE_Revenu_Par_Period rp 
    ON r.Periode_comptable = rp.Periode_comptable 
    AND r.MD_AUDIT_ID = rp.MD_AUDIT_ID  -- Filtre les données pour la dernière date de chargement de chacun des blocs de lots par période comptable.
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_TM_FONDS fonds
    ON r.ID_FONDS = fonds.ID_FONDS
INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.V_TM_TITRES titres
    ON r.ID_TITRE = titres.ID_TITRE;
create or replace view V_TM_REVENU_FONDS_DISPARUS(
	PERIODE_COMPTABLE,
	PERIODE_COMPARATIVE,
	ID_FONDS,
	ID_FONDS1,
	ID_FONDS2
) as

/*===============================================================================================================================
Auth:   Laurette Zola
Date:   2022-04-27
Des :   Cette vue retourne la liste des fonds disparus ( contenus dans la table des revenus) d'une période à une autre. Le résultats de ces écarts a pour but d'être inscrit dans la table des 
        points de contrôles et ensuite affiché dans un dashboard à la ligne d'affaire
===============================================================================================================================*/

WITH CTE_Fin as(
    -- Extraction de la liste des Fonds de la période courante, retourne une liste des fonds distincts contenus dans la table des Revenus.
    SELECT  r.PERIODE_COMPTABLE, 
            r.ID_FONDS AS ID_FONDS
    FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_REVENU r

)


    
, CTE_Depart as (
    -- Extraction de la liste des Fonds de la période précédente, retourne une liste des fonds distincts contenus dans la table des Revenus.
    SELECT  r.PERIODE_COMPTABLE As PERIODE_COMPTABLE_COMPARATIVE,
            r.ID_FONDS As ID_FONDS,
            CONCAT(LEFT(r.PERIODE_COMPTABLE,4)::STRING, '-', right('0'||((right(r.PERIODE_COMPTABLE,2)::INT + 1)::STRING),2)) as PERIODE_COMPTABLE  -- Retourne la période +1 de comparaison. Cela permettra de comparer à chaque fois le nombre des fonds de la période courante à celui de la période précedente. 
    FROM DB_CTB_DEV_DM.FSC_DEV.V_TM_REVENU r

)

-- Compare les deux sets de valeurs et renvoi la liste des fonds diparus. Ceux-ci représenteraient une anomalies de données ou de processus.
SELECT 
    NVL(d.PERIODE_COMPTABLE, '') AS PERIODE_COMPTABLE,
    NVL(f.PERIODE_COMPTABLE, '') AS PERIODE_COMPARATIVE,
    COALESCE(f.ID_FONDS, d.ID_FONDS) AS ID_FONDS,
    f.ID_FONDS AS ID_FONDS1,
    d.ID_FONDS AS ID_FONDS2
FROM CTE_Depart d
LEFT JOIN CTE_Fin f
    ON d.PERIODE_COMPTABLE = f.PERIODE_COMPTABLE
    AND d.ID_FONDS = f.ID_FONDS
WHERE 
   ID_FONDS1 is NULL;
create or replace view V_TM_TITRES(
	PERIODE_COMPTABLE,
	ID_TITRE,
	CODE_TITRE,
	NOM_TITRE
) as 


/*=================================================================================================================
================================================
Auth: Laurette Zola
Date: 2022-03-24
Desc: - Vue qui permet d'afficher la liste des titres par période comnptable.
      - Cette  liste permettra de voir dans le temps les titres qui ont disparus, ou ceux dont le nom a changé.

===================================================================
=================================================================================================================*/

WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)


-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID as MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE

)

/*=================================================================================================================
=================================================================================================================*/

SELECT     
    lp.PERIODE_COMPTABLE,
    a.ID_TITRE,
    a.CODE_TITRE,
    a.NOM_TITRE
FROM DB_CTB_DEV_DWH.FSC_DEV.LINK_TM_TITRES a
INNER JOIN CTE_Lots_Par_Period lp 
    ON a.Periode_comptable = lp.Periode_comptable 
    and a.MD_AUDIT_ID = lp.MD_AUDIT_ID  -- Filtre les données pour la dernière date de chargement de la liste des titres par période comptable.
;
create or replace schema FSC_PUBLICATION;

create or replace view V_DATACONTROLS(
	PERIODE_COMPTABLE,
	MD_AUDIT_ID,
	APPLICATIONNAME,
	SUBJECTNAME,
	TESTDATE,
	SOURCE_TESTTIMESTAMP,
	SOURCE_DATABASE,
	SOURCE_DATABASEOBJECTNAME,
	TARGET_TESTTIMESTAMP,
	TARGET_DATABASE,
	TARGET_DATABASEOBJECTNAME,
	TESTNAME,
	UNITOFMEASURE,
	SOURCE_CONTROLVALUE,
	TARGET_CONTROLVALUE,
	CONTROLSTATUSCODE,
	CONTROLSTATUSMESSAGE
) as 

/*=================================================================================================================
Auth:   Laurette Bakebana Zola
Date:   2022-03-17
Desc:   Vue qui permet d'afficher les resultats des points de contrôles relatifs à l'application TaxModel.
        Vue qui combine les valeurs de points de contrôle de type Source et Target pour les mêmes objets.
        Son but est de prendre la ligne d'un point de contrôle insérée en Source en début de process et de 
        trouver sa valeur correspondante de type Target qui aurait du être insérée en fin de processus et indiquer
        un code de succès ou d'erreur selon que les valeurs de contrôles concordent ou pas. 
=================================================================================================================*/

WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID as MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE

)

/*=================================================================================================================
=================================================================================================================*/

SELECT     
    lp.PERIODE_COMPTABLE,
    a.MD_AUDIT_ID,
	a.APPLICATIONNAME,
	a.SUBJECTNAME,
	a.TESTDATE,
	a.SOURCE_TESTTIMESTAMP,
	a.SOURCE_DATABASE,
	a.SOURCE_DATABASEOBJECTNAME,
	a.TARGET_TESTTIMESTAMP,
	a.TARGET_DATABASE,
	a.TARGET_DATABASEOBJECTNAME,
	a.TESTNAME,
	a.UNITOFMEASURE,
	a.SOURCE_CONTROLVALUE,
	a.TARGET_CONTROLVALUE,
	a.CONTROLSTATUSCODE,
	a.CONTROLSTATUSMESSAGE
FROM DB_CTB_DEV_DWH.TOOLS.V_DATACONTROLS a
INNER JOIN CTE_Lots_Par_Period lp
ON a.MD_AUDIT_ID = lp.MD_AUDIT_ID  -- Filtre les données pour la dernière date de chargement de chacun des blocs de lots par période comptable.
;
create or replace view V_DATAQUALITYCHECKS(
	PERIODE_COMPTABLE,
	MD_AUDIT_ID,
	MD_CREATION_DATE,
	APPLICATIONNAME,
	DATABASENAME,
	SUBJECTNAME,
	DATABASEOBJECTNAME,
	TESTDATE,
	TESTNAME,
	UNITOFMEASURE,
	RESULT,
	STATUS
) as

/*=================================================================================================================
Auth:   Laurette Bakebana Zola
Date:   2022-03-17
Desc:   Vue qui permet d'afficher les résultats d'analyse de la qualité
        de données relatifs à l'application TaxModel et qui seront 
        consommés par Power BI.
 
=================================================================================================================*/

WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID as MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE

)

/*=================================================================================================================
=================================================================================================================*/

SELECT
    lp.PERIODE_COMPTABLE,
    a.MD_AUDIT_ID,
    a.MD_CREATION_DATE,
    a.APPLICATIONNAME,
    a.DATABASENAME,
    a.SUBJECTNAME,
    a.DATABASEOBJECTNAME,
    a.TESTDATE,
    a.TESTNAME,
    a.UNITOFMEASURE,
    a.RESULT,
    a.STATUS

FROM DB_CTB_DEV_DWH.TOOLS.DATAQUALITYCHECKS a
INNER JOIN CTE_Lots_Par_Period lp
ON a.MD_AUDIT_ID = lp.MD_AUDIT_ID;
create or replace view V_DIM_DATES(
	PERIODE_COMPTABLE,
	ANNEE,
	TRIMESTRE,
	PERIODE,
	DATE_DEBUT_PERIODE,
	DATE_FIN_PERIODE
) as  

/*

Auth:   Pierre Cusosn
Date:   2022-03-28
Desc:   Retourne la configuration des périodes comptables en provenance de ERP Cloud pour utilisation dans les dashboard de Tax Model.

*/

SELECT
NOMPERIODE as PERIODE_COMPTABLE,
ANNEPERIODE AS ANNEE,
TRIMESTREPERIODE AS TRIMESTRE,
DATE_PART(MONTH, DATEFINPERIODE) AS PERIODE,
DATEDEBUTPERIODE AS DATE_DEBUT_PERIODE,
DATEFINPERIODE AS DATE_FIN_PERIODE
FROM DB_CTB_DEV_DWH.CTB.GL_FISCAL_PERIOD
ORDER BY 2,3,4;
create or replace view V_ECARTS_LOTS(
	PERIODE_COMPTABLE,
	PERIODE_COMPARATIVE,
	ID_FONDS,
	ID_TITRE,
	NOM_FONDS,
	CODE_TITRE,
	TYPE_POSITION,
	ID_FONDS1,
	ID_TITRE1,
	TYPE_POSITION1,
	ID_FONDS2,
	ID_TITRE2,
	TYPE_POSITION2,
	QUANTITE_FINALE,
	QUANTITE_INITIALE,
	VALEUR_FINALE,
	VALEUR_INITIALE
) as

/*===============================================================================================================================
Auth:   Pierre Cusson
Date:   2021-02-04
Des :   Cette vue retourne l'ensemble des positions qui ont un écart entre entre les positions de départ de l'année courante
        et les positions de fins de l'année précédente. Le résultats de ces écarts a pour but d'être inscrit dans la table des 
        points de contrôles et ensuite affiché dans un dashboard à la ligne d'affaire
===============================================================================================================================*/
SELECT 
	d.PERIODE_COMPTABLE,
	d.PERIODE_COMPARATIVE,
	d.ID_FONDS,
	d.ID_TITRE,
    f.NOM_FONDS,
    t.CODE_TITRE,
	d.TYPE_POSITION,
	d.ID_FONDS1,
	d.ID_TITRE1,
	d.TYPE_POSITION1,
	d.ID_FONDS2,
	d.ID_TITRE2,
	d.TYPE_POSITION2,
	d.QUANTITE_FINALE,
	d.QUANTITE_INITIALE,
	d.VALEUR_FINALE,
	d.VALEUR_INITIALE
FROM DB_CTB_DEV_DM.FSC.V_TM_LOTS_DISCREPANCY d
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_FONDS f ON d.ID_FONDS = f.ID_FONDS
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_TITRES t ON d.ID_TITRE = t.ID_TITRE;
create or replace view V_QUALITY_TM_LOTS(
	TESTNAME,
	OBJECTNAME,
	MISSINGVALUE
) as
-- Retourne les combinaison de Fonds/Titres qui ont un écart dans les positions initiales de l'année courante par rapport aux positions finales de l'année précédente
-- Point de contrôle officiel du tax model.
SELECT DISTINCT
    'Écart de position' as TestName, 
    'V_TM_LOTS_DISCREPANCY ==> ' || 'FONDS : ' || f.NOM_FONDS || ' | TITRE : ' || t.CODE_TITRE as ObjectName, 
     IFF(QUANTITE_FINALE <> QUANTITE_INITIALE, 'QUANTITE_INITIALE ', '')
        || IFF(VALEUR_FINALE <> VALEUR_INITIALE, 'VALEUR_INITIALE ', '')
        AS MissingValue
FROM DB_CTB_DEV_DM.FSC.V_TM_LOTS_DISCREPANCY d
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_FONDS f ON d.ID_FONDS = f.ID_FONDS
INNER JOIN DB_CTB_DEV_DWH.FSC.V_TM_TITRES t ON d.ID_TITRE = t.ID_TITRE;
create or replace view V_TM_EXEC_STATS(
	AUDIT_ID,
	JOB_NAME,
	PERIODE_COMPTABLE,
	START_TIME,
	END_TIME,
	EXEC_STATUS,
	TRIGGER_FILENAME
) as

/*=================================================================================================================
Auth:   Pierre Cusson
Date:   2022-03-18
Desc:   Vue qui retourne les derniers status d'exécution du Tax Modèle par période fiscales.
        cette donnée sera consommé dans le dashboard de qualité de données comme indicateurs d'exécution pour les contrôles
        des affaires.
 
=================================================================================================================*/

WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID as MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE

)

/*=================================================================================================================
=================================================================================================================*/

SELECT
    e.AUDIT_ID,
    e.JOB_NAME,
    lp.PERIODE_COMPTABLE,
    e.START_TIME,
    e.END_TIME,
	e.TASK_STATUS as EXEC_STATUS,
    e.FILE_PROCESSED as TRIGGER_FILENAME
FROM DB_CTB_DEV_DWH.TOOLS.AUDIT_JOBS_EXECUTIONS e
INNER JOIN CTE_Lots_Par_Period lp
ON e.AUDIT_ID = lp.MD_AUDIT_ID
WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model';
create or replace view V_TM_LOTS(
	PERIODE_COMPTABLE,
	ID_FONDS,
	ID_TITRE,
	NOM_FONDS,
	ID_FILIALE,
	DEVISE_FONDS,
	CODE_TITRE,
	NOM_TITRE,
	DESCRIPTION_EMETTEUR,
	TYPE_TITRE,
	PAYS_EMETTEUR,
	DEVISE_TITRE,
	COUPON,
	DATE_ECHEANCE,
	FREQUENCE_COUPON,
	TYPE_SOUS_TITRE,
	TYPE_LOT,
	ID_LOT,
	TYPE_POSITION,
	DATE_TRANSACTION,
	TYPE_TRANSACTION,
	NOMBRE_JOURS_DETENUS,
	QUANTITE_INITIALE,
	QUANTITE_ACHETEE,
	QUANTITE_VENDUE,
	QUANTITE_FINALE,
	VALEUR_INITIALE,
	COUT_ACQUISITION,
	MONTANT_VENTE,
	VALEUR_FINALE,
	INTERET_COURU_INITIAL,
	INTERET_COURU_ACHAT,
	INTERET_COURU_VENTE,
	INTERET_COURU_FINAL,
	DATE_ACHAT,
	DATE_VENTE,
	GAINS_PERTE_PRIX_TITRE,
	GAINS_PERTE_DEVISE,
	QUANTITE_CONTROLE
) as

/*

Auth:   Laurette Bakebana Zola
Date:   2022-03-17
Desc:   Vue de consommation pour Power BI. Elle retourne les dernières données des lots par période comptable.

*/

Select
    a.PERIODE_COMPTABLE,
	a.ID_FONDS,
	a.ID_TITRE,
	a.NOM_FONDS,
	a.ID_FILIALE,
	a.DEVISE_FONDS,
	a.CODE_TITRE,
	a.NOM_TITRE,
	a.DESCRIPTION_EMETTEUR,
	a.TYPE_TITRE,
	a.PAYS_EMETTEUR,
	a.DEVISE_TITRE,
	a.COUPON,
	a.DATE_ECHEANCE,
	a.FREQUENCE_COUPON,
	a.TYPE_SOUS_TITRE,
	a.TYPE_LOT,
	a.ID_LOT,
	a.TYPE_POSITION,
	a.DATE_TRANSACTION,
	a.TYPE_TRANSACTION,
	a.NOMBRE_JOURS_DETENUS,
	a.QUANTITE_INITIALE,
	a.QUANTITE_ACHETEE,
	a.QUANTITE_VENDUE,
	a.QUANTITE_FINALE,
	a.VALEUR_INITIALE,
	a.COUT_ACQUISITION,
	a.MONTANT_VENTE,
	a.VALEUR_FINALE,
	a.INTERET_COURU_INITIAL,
	a.INTERET_COURU_ACHAT,
	a.INTERET_COURU_VENTE,
	a.INTERET_COURU_FINAL,
	a.DATE_ACHAT,
	a.DATE_VENTE,
	a.GAINS_PERTE_PRIX_TITRE,
	a.GAINS_PERTE_DEVISE,
	a.QUANTITE_CONTROLE
  
From DB_CTB_DEV_DM.FSC.V_TM_LOTS a;
create or replace view V_TM_REVENU(
	PERIODE_COMPTABLE,
	NOM_FONDS,
	ID_FILIALE,
	DEVISE_FONDS,
	CODE_TITRE,
	NOM_TITRE,
	DESCRIPTION_EMETTEUR,
	TYPE_TITRE,
	PAYS_EMETTEUR,
	DEVISE_TITRE,
	COUPON,
	DATE_ECHEANCE,
	FREQUENCE_COUPON,
	TYPE_SOUS_TITRE,
	TYPE_POSITION,
	QUANTITE_INITIALE,
	QUANTITE_FINALE,
	INTERET_COURU_INITIAL,
	INTERET_COURU_FINAL,
	DIVIDENDES_RECEVOIR_INITIAL,
	DIVIDENDES_RECEVOIR_FINAL,
	COUPONS_PAYES,
	DIVIDENDES_VERSES,
	INTERETS_GAGNES,
	AMORTISSEMENTS,
	REVENUS_OBLIGATAIRES,
	URGL_DELTA_TITRE_OCI,
	URGL_DELTA_DEVISE_OCI,
	REVENU_LOCAL,
	REVENU_ETRANGER,
	DIVIDENDE_LOCAL,
	DIVIDENDE_ETRANGER,
	GAINS_PERTES_REALISES_PRIX_TITRES_OCI,
	GAINS_PERTES_REALISES_DEVISE_OCI,
	URGL_PRIX_TITRES,
	URGL_DEVISE_FONDS,
	FRAIS_TRANSACTION,
	IMPOT_RETENU_SOURCE,
	GAINS_PERTES_REALISES_PRIX_TITRES,
	COUT_AJUSTEMENT
) as  

/*

Auth:   Laurette Bakebana Zola
Date:   2022-03-17
Desc:   Vue de consommation pour Power BI. Elle retourne les dernières données de revenu par période comptable.

*/

Select
    a.PERIODE_COMPTABLE,
	a.NOM_FONDS,
	a.ID_FILIALE,
	a.DEVISE_FONDS,
	a.CODE_TITRE,
	a.NOM_TITRE,
	a.DESCRIPTION_EMETTEUR,
	a.TYPE_TITRE,
	a.PAYS_EMETTEUR,
	a.DEVISE_TITRE,
	a.COUPON,
	a.DATE_ECHEANCE,
	a.FREQUENCE_COUPON,
	a.TYPE_SOUS_TITRE,
	a.TYPE_POSITION,
	a.QUANTITE_INITIALE,
	a.QUANTITE_FINALE,
	a.INTERET_COURU_INITIAL,
	a.INTERET_COURU_FINAL,
	a.DIVIDENDES_RECEVOIR_INITIAL,
	a.DIVIDENDES_RECEVOIR_FINAL,
	a.COUPONS_PAYES,
	a.DIVIDENDES_VERSES,
	a.INTERETS_GAGNES,
	a.AMORTISSEMENTS,
	a.REVENUS_OBLIGATAIRES,
	a.URGL_DELTA_TITRE_OCI,
	a.URGL_DELTA_DEVISE_OCI,
	a.REVENU_LOCAL,
	a.REVENU_ETRANGER,
	a.DIVIDENDE_LOCAL,
	a.DIVIDENDE_ETRANGER,
	a.GAINS_PERTES_REALISES_PRIX_TITRES_OCI,
	a.GAINS_PERTES_REALISES_DEVISE_OCI,
	a.URGL_PRIX_TITRES,
	a.URGL_DEVISE_FONDS,
	a.FRAIS_TRANSACTION,
	a.IMPOT_RETENU_SOURCE,
	a.GAINS_PERTES_REALISES_PRIX_TITRES,
	a.COUT_AJUSTEMENT
    
FROM DB_CTB_DEV_DM.FSC.V_TM_REVENU a;
create or replace schema FSC_PUBLICATION_DEV;

create or replace view V_DATACONTROLS(
	PERIODE_COMPTABLE,
	MD_AUDIT_ID,
	APPLICATIONNAME,
	SUBJECTNAME,
	TESTDATE,
	SOURCE_TESTTIMESTAMP,
	SOURCE_DATABASE,
	SOURCE_DATABASEOBJECTNAME,
	TARGET_TESTTIMESTAMP,
	TARGET_DATABASE,
	TARGET_DATABASEOBJECTNAME,
	TESTNAME,
	UNITOFMEASURE,
	SOURCE_CONTROLVALUE,
	TARGET_CONTROLVALUE,
	CONTROLSTATUSCODE,
	CONTROLSTATUSMESSAGE
) as 

/*=================================================================================================================
Auth:   Laurette Bakebana Zola
Date:   2022-03-17
Desc:   Vue qui permet d'afficher les resultats des points de contrôles relatifs à l'application TaxModel  et qui seront 
        consommés par Power BI.
        Vue qui combine les valeurs de points de contrôle de type Source et Target pour les même objets.
        Son but est de prendre la ligne d'un point de contrôle insérée en Source en début de process et de 
        trouver sa valeur correspondante de type Target qui aurait du être insérée en fin de processus et indiquer
        un code de succès ou d'erreur selon que les valeurs de contrôles concordent ou pas. 
=================================================================================================================*/

WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID as MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE

)

/*=================================================================================================================
=================================================================================================================*/

SELECT     
    lp.PERIODE_COMPTABLE,
    a.MD_AUDIT_ID,
    a.APPLICATIONNAME,
	a.SUBJECTNAME,
	a.TESTDATE,
	a.SOURCE_TESTTIMESTAMP,
	a.SOURCE_DATABASE,
	a.SOURCE_DATABASEOBJECTNAME,
	a.TARGET_TESTTIMESTAMP,
	a.TARGET_DATABASE,
	a.TARGET_DATABASEOBJECTNAME,
	a.TESTNAME,
	a.UNITOFMEASURE,
	a.SOURCE_CONTROLVALUE,
	a.TARGET_CONTROLVALUE,
	a.CONTROLSTATUSCODE,
	a.CONTROLSTATUSMESSAGE
FROM DB_CTB_DEV_DWH.TOOLS_DEV.V_DATACONTROLS a
INNER JOIN CTE_Lots_Par_Period lp
ON a.MD_AUDIT_ID = lp.MD_AUDIT_ID  -- Filtre les données pour la dernière date de chargement de chacun des blocs de lots par période comptable.
;
create or replace view V_DATAQUALITYCHECKS(
	PERIODE_COMPTABLE,
	MD_AUDIT_ID,
	MD_CREATION_DATE,
	APPLICATIONNAME,
	DATABASENAME,
	SUBJECTNAME,
	DATABASEOBJECTNAME,
	TESTDATE,
	TESTNAME,
	UNITOFMEASURE,
	RESULT,
	STATUS
) as

/*=================================================================================================================
Auth:   Laurette Bakebana Zola
Date:   2022-03-17
Desc:   Vue qui permet d'afficher les résultats d'analyse de la qualité
        de données relatifs à l'application TaxModel et qui seront 
        consommés par Power BI.
 
=================================================================================================================*/

WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID as MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE

)

/*=================================================================================================================
=================================================================================================================*/

SELECT
    lp.PERIODE_COMPTABLE,
    a.MD_AUDIT_ID,
    a.MD_CREATION_DATE,
    a.APPLICATIONNAME,
    a.DATABASENAME,
    a.SUBJECTNAME,
    a.DATABASEOBJECTNAME,
    a.TESTDATE,
    a.TESTNAME,
    a.UNITOFMEASURE,
    a.RESULT,
    a.STATUS

FROM DB_CTB_DEV_DWH.TOOLS_DEV.DATAQUALITYCHECKS a
INNER JOIN CTE_Lots_Par_Period lp
ON a.MD_AUDIT_ID = lp.MD_AUDIT_ID;
create or replace view V_DIM_DATES(
	PERIODE_COMPTABLE,
	ANNEE,
	TRIMESTRE,
	PERIODE,
	DATE_DEBUT_PERIODE,
	DATE_FIN_PERIODE
) as  

/*

Auth:   Pierre Cusosn
Date:   2022-03-28
Desc:   Retourne la configuration des périodes comptables en provenance de ERP Cloud pour utilisation dans les dashboard de Tax Model.

*/

SELECT
NOMPERIODE as PERIODE_COMPTABLE,
ANNEPERIODE AS ANNEE,
TRIMESTREPERIODE AS TRIMESTRE,
DATE_PART(MONTH, DATEFINPERIODE) AS PERIODE,
DATEDEBUTPERIODE AS DATE_DEBUT_PERIODE,
DATEFINPERIODE AS DATE_FIN_PERIODE
FROM DB_CTB_DEV_DWH.CTB.GL_FISCAL_PERIOD
ORDER BY 2,3,4;
create or replace view V_TM_EXEC_STATS(
	AUDIT_ID,
	JOB_NAME,
	PERIODE_COMPTABLE,
	START_TIME,
	END_TIME,
	EXEC_STATUS,
	TRIGGER_FILENAME
) as

/*=================================================================================================================
Auth:   Pierre Cusson
Date:   2022-03-18
Desc:   Vue qui retourne les derniers status d'exécution du Tax Modèle par période fiscales.
        cette donnée sera consommé dans le dashboard de qualité de données comme indicateurs d'exécution pour les contrôles
        des affaires.
 
=================================================================================================================*/

WITH CTE_Last_Exec as (
  -- Retourne la dernière date d'exécution avec succès d'un Refresh Tax Model pour chaque période comptable
  SELECT d.PERIODE_COMPTABLE, MAX(d.MD_CREATION_DATE) as MD_CREATION_DATE
  FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXECUTIONS e
  INNER JOIN DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d 
    ON e.AUDIT_ID = d.MD_AUDIT_ID
  WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model' 
    AND e.TASK_STATUS = 'Success'
  GROUP BY d.PERIODE_COMPTABLE
  
)

-- Retourne le Audit_ID correspondant à la dernière date de chargement réussi pour une période comptable
, CTE_Lots_Par_Period as (
    SELECT 
        d.PERIODE_COMPTABLE, 
        d.MD_CREATION_DATE,
        d.MD_AUDIT_ID as MD_AUDIT_ID
    FROM DB_CTB_DEV_DWH.FSC_DEV.REF_TM_SNAPSHOTDATES d
    INNER JOIN CTE_Last_Exec le 
        ON d.PERIODE_COMPTABLE = le.PERIODE_COMPTABLE
        AND d.MD_CREATION_DATE = le.MD_CREATION_DATE

)

/*=================================================================================================================
=================================================================================================================*/

SELECT
    e.AUDIT_ID,
    e.JOB_NAME,
    lp.PERIODE_COMPTABLE,
    e.START_TIME,
    e.END_TIME,
	e.TASK_STATUS as EXEC_STATUS,
    e.FILE_PROCESSED as TRIGGER_FILENAME
FROM DB_CTB_DEV_DWH.TOOLS_DEV.AUDIT_JOBS_EXECUTIONS e
INNER JOIN CTE_Lots_Par_Period lp
ON e.AUDIT_ID = lp.MD_AUDIT_ID
WHERE e.JOB_NAME = 'TM-001 Refresh Tax Model';
create or replace schema PAY;

create or replace view V_PAY_DEMANDE_PAIEMENT(
	HK_LINK,
	IDINVOICEPAYMENTREQUEST,
	BUSINESSUNITCODE,
	REQUESTEREMAIL,
	INVOICEDATE,
	PAYMENTDATE,
	SUPPLIER,
	LANGUAGECORRESPONDENCE,
	PAYMENTMETHODEN,
	PAYMENTMETHODFR,
	AMOUNT,
	REQUESTNUMBER,
	INVOICENUMBER,
	BUSINESSUNIT,
	TEMPLATENUMBER,
	SPECIALREQUESTTYPECODE,
	PAYMENTCONDITION,
	HASBYPASS,
	INVOICEDATEPRIORITY,
	RESIDENCECOUNTRY
) as
Select 
    a.HK_LINK,
	a.IdInvoicePaymentRequest,
    a.BusinessUnitCode,
    a.RequesterEmail,
    a.InvoiceDate,
    a.PaymentDate,
    a.Supplier,
    a.LanguageCorrespondence,
    a.PaymentMethodEn,
    a.PaymentMethodFr,
    a.Amount,
    a.RequestNumber,
    a.InvoiceNumber,
    a.BusinessUnit,
    a.TemplateNumber,
    a.SpecialRequestTypeCode,
    a.PaymentCondition,
    a.HasByPass,
    a.InvoiceDatePriority,
    a.ResidenceCountry

from DB_CTB_DEV_DWH.PAY.LINK_PAY_DEMANDE_PAIEMENT a
inner join
(Select HK_LINK,max(MD_CREATION_DATE) as MD_CREATION_DATE from DB_CTB_DEV_DWH.PAY.LINK_PAY_DEMANDE_PAIEMENT group by HK_LINK) b on a.HK_LINK = b.HK_LINK and a.MD_CREATION_DATE=b.MD_CREATION_DATE;
create or replace view V_PAY_REQUETE_INFO(
	HK_LINK,
	IDREQUESTINFORMATION,
	IDRELATEDENTITY,
	RELATEDENTITYTYPE,
	TYPE,
	DESCRIPTION,
	CREATEDDATE,
	DUEDATE,
	RESOLVEDDATE,
	RESOLVED,
	RESOLVEDBY,
	OVERDUEFLAG
) as
Select  
    a.HK_LINK,
	a.IdRequestInformation,
    a.IdRelatedEntity,
    a.RelatedEntityType,
    a.Type,
    a.Description,
    a.CreatedDate,
    a.DueDate,
    a.ResolvedDate,
    a.Resolved,
    a.ResolvedBy,
    a.OverdueFlag
from DB_CTB_DEV_DWH.PAY.LINK_PAY_REQUETE_INFO a
inner join
(Select HK_LINK,max(MD_CREATION_DATE) as MD_CREATION_DATE from DB_CTB_DEV_DWH.PAY.LINK_PAY_REQUETE_INFO group by HK_LINK) b on a.HK_LINK = b.HK_LINK and a.MD_CREATION_DATE=b.MD_CREATION_DATE;
create or replace view V_PAY_TACHE(
	HK_LINK,
	IDTASK,
	IDINVOICEPAYMENTREQUEST,
	SUBJECT,
	TARGETNAME,
	SELECTEDSUPPLIERFORM,
	STATUS,
	DELIVERYDATE,
	STARTEDDATE,
	COMPLETEDDATE
) as

Select a.HK_LINK,
    a.IdTask,
    a.IdInvoicePaymentRequest,
    a.Subject,
    a.TargetName,
    a.SelectedSupplierForm,
    a.Status,
    a.DeliveryDate,
    a.StartedDate,
    a.CompletedDate

from DB_CTB_DEV_DWH.PAY.LINK_PAY_TACHE a
inner join
(Select HK_LINK,max(MD_CREATION_DATE) as MD_CREATION_DATE from DB_CTB_DEV_DWH.PAY.LINK_PAY_TACHE group by HK_LINK) b on a.HK_LINK = b.HK_LINK and a.MD_CREATION_DATE=b.MD_CREATION_DATE;
create or replace view V_PAY_TACHES_MANUELLES(
	HK_LINK,
	IDMANUALTASK,
	MANUALTASKTYPE,
	TARGETNAME,
	DESCRIPTION,
	STATUS,
	CREATEDDATE,
	PAUSEDDATE,
	STARTEDDATE,
	COMPLETEDDATE
) as Select 
    a.HK_LINK,
	a.IdManualTask,
    a.ManualTaskType,
    a.TargetName,
    a.Description,
    a.Status,
    a.CreatedDate,
    a.PausedDate,
    a.StartedDate,
    a.CompletedDate
    from DB_CTB_DEV_DWH.PAY.LINK_PAY_TACHES_MANUELLES a
inner join
(Select HK_LINK,max(MD_CREATION_DATE) as MD_CREATION_DATE from DB_CTB_DEV_DWH.PAY.LINK_PAY_TACHES_MANUELLES group by HK_LINK) b on a.HK_LINK = b.HK_LINK and a.MD_CREATION_DATE=b.MD_CREATION_DATE;
create or replace schema PAY_DEV;

create or replace view V_PAY_DEMANDE_PAIEMENT(
	HK_LINK,
	IDINVOICEPAYMENTREQUEST,
	BUSINESSUNITCODE,
	REQUESTEREMAIL,
	INVOICEDATE,
	PAYMENTDATE,
	SUPPLIER,
	LANGUAGECORRESPONDENCE,
	PAYMENTMETHODEN,
	PAYMENTMETHODFR,
	AMOUNT,
	REQUESTNUMBER,
	INVOICENUMBER,
	BUSINESSUNIT,
	TEMPLATENUMBER,
	SPECIALREQUESTTYPECODE,
	PAYMENTCONDITION,
	HASBYPASS,
	INVOICEDATEPRIORITY,
	RESIDENCECOUNTRY
) as
Select 
    a.HK_LINK,
	a.IdInvoicePaymentRequest,
    a.BusinessUnitCode,
    a.RequesterEmail,
    a.InvoiceDate,
    a.PaymentDate,
    a.Supplier,
    a.LanguageCorrespondence,
    a.PaymentMethodEn,
    a.PaymentMethodFr,
    a.Amount,
    a.RequestNumber,
    a.InvoiceNumber,
    a.BusinessUnit,
    a.TemplateNumber,
    a.SpecialRequestTypeCode,
    a.PaymentCondition,
    a.HasByPass,
    a.InvoiceDatePriority,
    a.ResidenceCountry

from DB_CTB_DEV_DWH.PAY_DEV.LINK_PAY_DEMANDE_PAIEMENT a
inner join
(Select HK_LINK,max(MD_CREATION_DATE) as MD_CREATION_DATE from DB_CTB_DEV_DWH.PAY_DEV.LINK_PAY_DEMANDE_PAIEMENT group by HK_LINK) b on a.HK_LINK = b.HK_LINK and a.MD_CREATION_DATE=b.MD_CREATION_DATE;
create or replace view V_PAY_REQUETE_INFO(
	HK_LINK,
	IDREQUESTINFORMATION,
	IDRELATEDENTITY,
	RELATEDENTITYTYPE,
	TYPE,
	DESCRIPTION,
	CREATEDDATE,
	DUEDATE,
	RESOLVEDDATE,
	RESOLVED,
	RESOLVEDBY,
	OVERDUEFLAG
) as
Select  
    a.HK_LINK,
	a.IdRequestInformation,
    a.IdRelatedEntity,
    a.RelatedEntityType,
    a.Type,
    a.Description,
    a.CreatedDate,
    a.DueDate,
    a.ResolvedDate,
    a.Resolved,
    a.ResolvedBy,
    a.OverdueFlag
from DB_CTB_DEV_DWH.PAY_DEV.LINK_PAY_REQUETE_INFO a
inner join
(Select HK_LINK,max(MD_CREATION_DATE) as MD_CREATION_DATE from DB_CTB_DEV_DWH.PAY_DEV.LINK_PAY_REQUETE_INFO group by HK_LINK) b on a.HK_LINK = b.HK_LINK and a.MD_CREATION_DATE=b.MD_CREATION_DATE;
create or replace view V_PAY_TACHES_MANUELLES(
	HK_LINK,
	IDMANUALTASK,
	MANUALTASKTYPE,
	TARGETNAME,
	DESCRIPTION,
	STATUS,
	CREATEDDATE,
	PAUSEDDATE,
	STARTEDDATE,
	COMPLETEDDATE
) as Select 
    a.HK_LINK,
	a.IdManualTask,
    a.ManualTaskType,
    a.TargetName,
    a.Description,
    a.Status,
    a.CreatedDate,
    a.PausedDate,
    a.StartedDate,
    a.CompletedDate
    from DB_CTB_DEV_DWH.PAY_DEV.LINK_PAY_TACHES_MANUELLES a
inner join
(Select HK_LINK,max(MD_CREATION_DATE) as MD_CREATION_DATE from DB_CTB_DEV_DWH.PAY_DEV.LINK_PAY_TACHES_MANUELLES group by HK_LINK) b on a.HK_LINK = b.HK_LINK and a.MD_CREATION_DATE=b.MD_CREATION_DATE;
create or replace schema PAY_PUBLICATION;

create or replace view V_PAY_DEMANDE_PAIEMENT(
	IDINVOICEPAYMENTREQUEST,
	BUSINESSUNITCODE,
	REQUESTEREMAIL,
	INVOICEDATE,
	PAYMENTDATE,
	SUPPLIER,
	LANGUAGECORRESPONDENCE,
	PAYMENTMETHODEN,
	PAYMENTMETHODFR,
	AMOUNT,
	REQUESTNUMBER,
	INVOICENUMBER,
	BUSINESSUNIT,
	TEMPLATENUMBER,
	SPECIALREQUESTTYPECODE,
	PAYMENTCONDITION,
	HASBYPASS,
	INVOICEDATEPRIORITY,
	RESIDENCECOUNTRY
) as
Select 
	a.IdInvoicePaymentRequest,
    a.BusinessUnitCode,
    a.RequesterEmail,
    a.InvoiceDate,
    a.PaymentDate,
    a.Supplier,
    a.LanguageCorrespondence,
    a.PaymentMethodEn,
    a.PaymentMethodFr,
    a.Amount,
    a.RequestNumber,
    a.InvoiceNumber,
    a.BusinessUnit,
    a.TemplateNumber,
    a.SpecialRequestTypeCode,
    a.PaymentCondition,
    a.HasByPass,
    a.InvoiceDatePriority,
    a.ResidenceCountry

from DB_CTB_DEV_DM.PAY.V_PAY_DEMANDE_PAIEMENT a;
create or replace view V_PAY_REQUETE_INFO(
	IDREQUESTINFORMATION,
	IDRELATEDENTITY,
	RELATEDENTITYTYPE,
	TYPE,
	DESCRIPTION,
	CREATEDDATE,
	DUEDATE,
	RESOLVEDDATE,
	RESOLVED,
	RESOLVEDBY,
	OVERDUEFLAG
) as
Select  
	a.IdRequestInformation,
    a.IdRelatedEntity,
    a.RelatedEntityType,
    a.Type,
    a.Description,
    a.CreatedDate,
    a.DueDate,
    a.ResolvedDate,
    a.Resolved,
    a.ResolvedBy,
    a.OverdueFlag
from DB_CTB_DEV_DM.PAY.V_PAY_REQUETE_INFO a;
create or replace view V_PAY_TACHE(
	IDTASK,
	IDINVOICEPAYMENTREQUEST,
	SUBJECT,
	TARGETNAME,
	SELECTEDSUPPLIERFORM,
	STATUS,
	DELIVERYDATE,
	STARTEDDATE,
	COMPLETEDDATE
) as

Select 
    a.IdTask,
    a.IdInvoicePaymentRequest,
    a.Subject,
    a.TargetName,
    a.SelectedSupplierForm,
    a.Status,
    a.DeliveryDate,
    a.StartedDate,
    a.CompletedDate

from DB_CTB_DEV_DM.PAY.V_PAY_TACHE a;
create or replace view V_PAY_TACHES_MANUELLES(
	IDMANUALTASK,
	MANUALTASKTYPE,
	TARGETNAME,
	DESCRIPTION,
	STATUS,
	CREATEDDATE,
	PAUSEDDATE,
	STARTEDDATE,
	COMPLETEDDATE
) as Select 
	a.IdManualTask,
    a.ManualTaskType,
    a.TargetName,
    a.Description,
    a.Status,
    a.CreatedDate,
    a.PausedDate,
    a.StartedDate,
    a.CompletedDate
    from DB_CTB_DEV_DM.PAY.V_PAY_TACHES_MANUELLES a;
create or replace schema PUBLIC;
