CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DWH.TOOLS.USP_AUDIT_END_JOB(JOB_NAME VARCHAR(16777216), DATA_START_DT VARCHAR(16777216), JOB_AUDIT_ID VARCHAR(16777216), JOB_END_STATUS VARCHAR(16777216), JOB_END_DESC VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
// Update status command
var cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET UPDATE_JOB_AUDIT_ID=''"+JOB_AUDIT_ID+"'', JOB_STATUS=";
var cmdUpdStatusWhereClause = " WHERE JOB_NAME =''" + JOB_NAME + "'' AND DATA_START_DT = ''"+DATA_START_DT+"''";
// Check last execution
var cmd = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND aje.DATA_START_DT = ''"+DATA_START_DT+"'' ORDER BY aje.DATA_START_DT DESC";
var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();

var stUpdStatus;
var resUpdStatus;

try 
{	
	// A previous execution is found
	if (res.next())
	{
		var dtLastJobStart = res.getColumnValue(1);
		var strLastJobStatus = res.getColumnValue(2);

		//var cmdDG = "INSERT INTO TOOLS.DEBUG_LOG VALUES (''"+ dtLastJobStart +"'')";
		//var stDG = snowflake.createStatement( { sqlText: cmdDG } );
		//var resDG = stDG.execute();

		// Job is in progress 
		// => end it  
		if (strLastJobStatus == "IN PROGRESS")
		{
			cmdUpdStatus += "''"+JOB_END_STATUS+"'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''" + JOB_AUDIT_ID + "<'' || CURRENT_TIMESTAMP() || ''> END_JOB : "+JOB_END_DESC+" ''" + cmdUpdStatusWhereClause;	
			stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
			resUpdStatus = stUpdStatus.execute();
			return JOB_END_STATUS;
		}
		// Ending a job that is not in progress
		else
		{
			cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> END_JOB ERROR_01 : trying to end a job that is not in progress. ''" + cmdUpdStatusWhereClause;
			stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
			resUpdStatus = stUpdStatus.execute();
			return "ERROR_01";		
		}	
	}
	// Job to be ended not found
	else
	{
		return "ERROR_02";
	}
}
// Technical error
catch(er)
{
	return "ERROR_FATAL : " + er;	
}

return "ERROR_03";	

';