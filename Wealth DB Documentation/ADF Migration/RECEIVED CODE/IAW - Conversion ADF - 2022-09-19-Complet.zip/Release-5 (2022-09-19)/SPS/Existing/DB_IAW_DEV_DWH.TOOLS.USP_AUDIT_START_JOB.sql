CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DWH.TOOLS.USP_AUDIT_START_JOB(JOB_NAME VARCHAR(16777216), DATA_START_DT VARCHAR(10), JOB_AUDIT_ID VARCHAR(16777216))
RETURNS VARCHAR(100)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
// Update status command
var cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET UPDATE_JOB_AUDIT_ID=''"+JOB_AUDIT_ID+"'', JOB_STATUS=";
var cmdUpdStatusWhereClause = " WHERE JOB_NAME =''" + JOB_NAME + "'' AND DATA_START_DT = ''"+DATA_START_DT+"''";
// Check last execution
var cmd = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS, aje.DATA_NEXT_START_DT::VARCHAR FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND aje.JOB_STATUS IS NOT NULL AND aje.JOB_STATUS<>'''' AND aje.DATA_START_DT <= ''"+DATA_START_DT+"'' ORDER BY aje.DATA_START_DT DESC";
var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();
var stUpdStatus;
var resUpdStatus;
var InsCmd = "SELECT DISTINCT JOB_NAME FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND aje.DATA_START_DT = ''" + DATA_START_DT +"''";
var InsSt = snowflake.createStatement( { sqlText: InsCmd } );
var InsRes = InsSt.execute();

try
{   
if (InsRes.next())
{
    // A previous execution is found
    if (res.next())
    {
        var dtLastJobStart = res.getColumnValue(1);
        var strLastJobStatus = res.getColumnValue(2);
        var dtLastJobNextStart = res.getColumnValue(3);
        // Job is executed before for the same date but without success 
        // => It is correct to re-execute it  
        if (dtLastJobStart == DATA_START_DT && strLastJobStatus != "SUCCESS" && strLastJobStatus != "IN PROGRESS")
        {
            cmdUpdStatus += "''IN PROGRESS'', JOB_ACTION_RESULT=''SUCCESS'',  JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''" + JOB_AUDIT_ID + "('' || CURRENT_TIMESTAMP() || '') : Job restart. ''" + cmdUpdStatusWhereClause; 
            stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
            resUpdStatus = stUpdStatus.execute();
            return "IN PROGRESS";
        }
        else
        {
            // Job is not executed before with the same date
            if (dtLastJobStart < DATA_START_DT) 
            {
                //Check if the execution next start date is not skipped
                if (dtLastJobNextStart != DATA_START_DT)
                {
                    cmdUpdStatus += "'''', JOB_ACTION_RESULT=''ERROR_06'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> ERROR_06 : The execution of "+dtLastJobNextStart +" image was skipped. ''" + cmdUpdStatusWhereClause;
                    stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
                    resUpdStatus = stUpdStatus.execute();
                    return "ERROR_06";
                }
                // The last execution was successful
                // => Execute for current date
                else if (strLastJobStatus == "SUCCESS")
                {
                    cmdUpdStatus += "''IN PROGRESS'', JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> : Job start. ''" + cmdUpdStatusWhereClause;
                    stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
                    resUpdStatus = stUpdStatus.execute();
                    return "IN PROGRESS";
                }
                // The last execution is not successful or not done
                // => Error
                else
                {
                    cmdUpdStatus += "'''', JOB_ACTION_RESULT=''ERROR_01'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> ERROR_01 : The previous execution is not done or not successful. ''" + cmdUpdStatusWhereClause;
                    stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
                    resUpdStatus = stUpdStatus.execute();
                    return "ERROR_01";
                }
            }
            // Already successfully executed or executing for this date
            // => Error
            else
            {
                // Already successfully executed
                if (strLastJobStatus == "SUCCESS")
                {
                    cmdUpdStatus += "''SUCCESS'', JOB_ACTION_RESULT=''ERROR_02'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> ERROR_02 : Trying to re-execute a successfully executed job. ''" + cmdUpdStatusWhereClause;
                    stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
                    resUpdStatus = stUpdStatus.execute();
                    return "ERROR_02";
                }
                // Already executing for this date (IN PROGRESS)
                else
                {
                    cmdUpdStatus += "''"+strLastJobStatus+"'', JOB_ACTION_RESULT=''ERROR_03'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> ERROR_03 : Trying to execute a running Job. ''"+ cmdUpdStatusWhereClause;
                    stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
                    resUpdStatus = stUpdStatus.execute();
                    return "ERROR_03";
                }   
            }   
        }   
    }
    // First execution of the job : no previous job
    else
    {
        cmdUpdStatus += "''IN PROGRESS'', JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> : Job first start. ''" + cmdUpdStatusWhereClause;
        stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
        resUpdStatus = stUpdStatus.execute();
        return "IN PROGRESS";
    }
}
else
{
	return "ERROR_07";
}
}
// Technical error
catch(er)
{
    cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET UPDATE_JOB_AUDIT_ID=''"+JOB_AUDIT_ID+"'', JOB_STATUS=";
    cmdUpdStatus += "''ERROR'', JOB_ACTION_RESULT=''ERROR_04'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> ERROR_04 : technical error :"+er+". ''"+ cmdUpdStatusWhereClause;
    stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
    resUpdStatus = stUpdStatus.execute();
    return "ERROR_04";  
return er;
}
cmdUpdStatus += "''ERROR'', JOB_ACTION_RESULT=''ERROR_05'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''>ERROR_05 : Unknown error. ''"+ cmdUpdStatusWhereClause;
stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
resUpdStatus = stUpdStatus.execute();
return "ERROR_05";  
';