CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DWH.TOOLS.USP_AUDIT_START_JOB_NEXT_DATE(JOB_NAME VARCHAR(16777216), JOB_AUDIT_ID VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
//remove cotes
JOB_NAME= JOB_NAME.replace("''", "");
JOB_AUDIT_ID= JOB_AUDIT_ID.replace("''", "");

// Update status command
var cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET UPDATE_JOB_AUDIT_ID=''"+JOB_AUDIT_ID+"'', JOB_STATUS=";
var cmdUpdStatusWhereClause = " WHERE JOB_NAME ="+"''" + JOB_NAME + "''";

// Check last execution
var cmd = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND aje.JOB_STATUS IS NOT NULL AND aje.JOB_STATUS<>'''' ORDER BY aje.DATA_START_DT DESC";
var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();


var stUpdStatus;
var resUpdStatus;


// A previous execution is found
if (res.next())
{
	var dtLastJobStart = res.getColumnValue(1);
	var strLastJobStatus = res.getColumnValue(2);

	//var cmdDG = ""INSERT INTO TOOLS.DEBUG_LOG VALUES (''""+ dtLastJobStart +""'')"";
	//var stDG = snowflake.createStatement( { sqlText: cmdDG } );
	//var resDG = stDG.execute();

	// Job is executed before for the same date but without success 
	// => It is correct to re-execute it  
	if (strLastJobStatus != "SUCCESS" && strLastJobStatus != "IN PROGRESS")
	{
		// Check last execution
		var cmdNext = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND DATA_START_DT=''"+res.getColumnValue(1)+"'' ORDER BY aje.DATA_START_DT ASC";
		var stNext = snowflake.createStatement( { sqlText: cmdNext } );
		var resNext = stNext.execute();
		if (resNext.next())
			{
			//Check dependent jobs execution, if there are any
			var statementDep = snowflake.createStatement( { sqlText: "CALL TOOLS.USP_AUDIT_CHECK_DEPENDENT_JOBS(''" + JOB_NAME + "'',''" + resNext.getColumnValue(1) + "'')" } );
			var dependencyRslt = statementDep.execute();
			dependencyRslt.next();
			var dependencyMsg = dependencyRslt.getColumnValue(1);
			if(dependencyMsg != "1")
			{
			//throw dependencyMsg;
	        cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_STATUS=''ERROR'' , JOB_ACTION_RESULT=''ERROR_04'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_04 : "+ dependencyMsg +" ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resNext.getColumnValue(1)+"''";	
			stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
			resUpdStatus = stUpdStatus.execute();
			return "0000-00-00";
			}

		cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''" + JOB_AUDIT_ID + "('' || CURRENT_TIMESTAMP() || '') START_JOB : Job restart. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+res.getColumnValue(1)+"''";	
		stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
		resUpdStatus = stUpdStatus.execute();
		return res.getColumnValue(1);
		}
	}
	else
	{
		// The last execution was successful
		// => Execute for next date
		if (strLastJobStatus == "SUCCESS")
		{
			// Check last execution
			var cmdNext = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' AND DATA_START_DT>''"+res.getColumnValue(1)+"'' ORDER BY aje.DATA_START_DT ASC";
			var stNext = snowflake.createStatement( { sqlText: cmdNext } );
			var resNext = stNext.execute();
			if (resNext.next())
			{


				//Check dependent jobs execution, if there are any
				var statementDep = snowflake.createStatement( { sqlText: "CALL TOOLS.USP_AUDIT_CHECK_DEPENDENT_JOBS(''" + JOB_NAME + "'',''" + resNext.getColumnValue(1) + "'')" } );
				var dependencyRslt = statementDep.execute();
				dependencyRslt.next();
				var dependencyMsg = dependencyRslt.getColumnValue(1);
				if(dependencyMsg != "1")
				{
				//throw dependencyMsg;
                
                cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_STATUS=''ERROR'' , JOB_ACTION_RESULT=''ERROR_04'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_04 : "+ dependencyMsg +" ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resNext.getColumnValue(1)+"''";	
				stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
				resUpdStatus = stUpdStatus.execute();
				return "0000-00-00";
				}


				cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB : Job start. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resNext.getColumnValue(1)+"''";	;
				stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
				resUpdStatus = stUpdStatus.execute();
				return resNext.getColumnValue(1);
			}
		}
		// Already executing for this date (IN PROGRESS)
		// Error
		else
		{
			cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_ACTION_RESULT=''ERROR_03'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_03 : Trying to execute a running Job. ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+res.getColumnValue(1)+"''";	
			stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
			resUpdStatus = stUpdStatus.execute();
			return "0000-00-00";
		}	
	}	
}
// First execution of the job : no previous job
else
{
	// Check last execution
	var cmdFirst = "SELECT TOP 1 aje.DATA_START_DT::VARCHAR, aje.JOB_STATUS FROM TOOLS.AUDIT_JOBS_EXECUTIONS aje WHERE aje.JOB_NAME =''" + JOB_NAME + "'' ORDER BY aje.DATA_START_DT ASC";
	var stFirst = snowflake.createStatement( { sqlText: cmdFirst } );
	var resFirst = stFirst.execute();
	
	if (resFirst.next())
	{

                //Check dependent jobs execution, if there are any
				var statementDep = snowflake.createStatement( { sqlText: "CALL TOOLS.USP_AUDIT_CHECK_DEPENDENT_JOBS(''" + JOB_NAME + "'',''" + resFirst.getColumnValue(1) + "'')" } );
				var dependencyRslt = statementDep.execute();
				dependencyRslt.next();
				var dependencyMsg = dependencyRslt.getColumnValue(1);
				if(dependencyMsg != "1")
				{

				//throw dependencyMsg;

                cmdUpdStatus = "UPDATE TOOLS.AUDIT_JOBS_EXECUTIONS SET JOB_STATUS=''ERROR'' ,JOB_ACTION_RESULT=''ERROR_04'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB ERROR_04 : "+ dependencyMsg +" ''"+ cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resFirst.getColumnValue(1)+"''";	
				stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
				resUpdStatus = stUpdStatus.execute();
				return "0000-00-00";
				}

		cmdUpdStatus += "''IN PROGRESS'',  JOB_ACTION_RESULT=''SUCCESS'', JOB_STATUS_DESC = COALESCE(JOB_STATUS_DESC,'''') || CHAR(10) || ''"+JOB_AUDIT_ID+"<'' || CURRENT_TIMESTAMP() || ''> START_JOB : Job first start. ''" + cmdUpdStatusWhereClause + " AND DATA_START_DT=''"+resFirst.getColumnValue(1)+"''";
		stUpdStatus = snowflake.createStatement( { sqlText: cmdUpdStatus } );
		resUpdStatus = stUpdStatus.execute();
		return resFirst.getColumnValue(1);
	}
	else 
	{
		return "0000-00-00"
	}
}


return "0000-00-00";

';