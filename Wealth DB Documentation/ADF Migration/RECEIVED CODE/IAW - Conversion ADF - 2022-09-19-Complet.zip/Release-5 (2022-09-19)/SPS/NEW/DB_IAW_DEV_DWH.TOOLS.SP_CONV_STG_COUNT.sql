CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DWH.TOOLS.SP_CONV_STG_COUNT(ENV VARCHAR(16777216), TBL_SCHEMA VARCHAR(16777216), TABLE_NAME VARCHAR(16777216))
RETURNS VARCHAR(10000)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var cmd =  "SELECT COUNT(*) ROW_CNT FROM DB_IAW_"+ENV+"_STG."+TBL_SCHEMA+"."+TABLE_NAME+ " WHERE MD_EXTRACT_DT  IS NULL";
var st = snowflake.createStatement( { sqlText: cmd } );
var res = st.execute();
var op=''''
while (res.next())  {
 op= res.getColumnValue(1);
 return op
}
;
';