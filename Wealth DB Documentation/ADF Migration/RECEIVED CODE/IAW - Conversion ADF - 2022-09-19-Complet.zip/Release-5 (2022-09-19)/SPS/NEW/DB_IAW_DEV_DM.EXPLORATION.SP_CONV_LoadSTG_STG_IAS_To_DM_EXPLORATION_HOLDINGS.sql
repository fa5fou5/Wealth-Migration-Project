CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.EXPLORATION.SP_CONV_LoadSTG_STG_IAS_To_DM_EXPLORATION_HOLDINGS(ENV VARCHAR)
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS $$ 
var delete_query = "DELETE FROM DB_IAW_DEV_DM.EXPLORATION.IAS_HOLDINGS WHERE 1=1";
var delete_query_ENV = delete_query.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement1 = snowflake.createStatement({
  sqlText: delete_query_ENV
});
var result1_scan = sql_statement1.execute(); 
INS_QUERY = "INSERT INTO DB_IAW_DEV_DM.EXPLORATION.IAS_HOLDINGS(HK_LINK , " +
"HK_HUB_CONTRACT, " + 
"HK_HUB_REGISTERED_REPRESENTATIVE	, " + 	
"HK_HUB_INVESTMENT_PRODUCT_TYPE	 , " +
"MD_SEQ	 , " +
"MD_START_DT	, " + 
"MD_HASHDIFF	, " + 
"MD_CREATION_DT	 	, " +
"MD_SOURCE	 , " +
"MD_SRC_SYSTEM	, " + 	
"MD_EXTRACT_DT	, " + 
"A_C_ID	 , " +
"A_C_REPRESENTATIVE	, " + 
"TI_ALTERNATE_ID	, " + 	
"TRAN_SUMM_CURR_MKT_VALUE	, " + 	
"TRAN_SUMM_BUSINESS_DATE	, " + 	
"TI_ALTERNATE_TI_TYPE	 , " +	
"B_V_SECURITY_POSITION_VAL	 , " +	
"B_V_SECURITY_POSITION_COS	 , " +	
"TRAN_SUMM_AVG_UNIT_COST	, " + 	
"TRAN_SUMM_NET_SETT_AMT	 	, " +
"TRAN_SUMM_CURRENCY	 , " +
"TRAN_SUMM_SETT_QTY	 	, " +
"TRAN_SUMM_TRADE_QTY) " +	
"(select " +
"HK_LINK , " +
"HK_HUB_CONTRACT, " + 
"HK_HUB_REGISTERED_REPRESENTATIVE	, " + 	
"HK_HUB_INVESTMENT_PRODUCT_TYPE	 , " +
"MD_SEQ	 , " +
"MD_START_DT	, " + 
"MD_HASHDIFF	, " + 
"MD_CREATION_DT	 	, " +
"MD_SOURCE	 , " +
"MD_SRC_SYSTEM	, " + 	
"MD_EXTRACT_DT	, " + 
"A_C_ID	 , " +
"A_C_REPRESENTATIVE	, " + 
"TI_ALTERNATE_ID	, " + 	
"TRAN_SUMM_CURR_MKT_VALUE	, " + 	
"TRAN_SUMM_BUSINESS_DATE	, " + 	
"TI_ALTERNATE_TI_TYPE	 , " +	
"B_V_SECURITY_POSITION_VAL	 , " +	
"B_V_SECURITY_POSITION_COS	 , " +	
"TRAN_SUMM_AVG_UNIT_COST	, " + 	
"TRAN_SUMM_NET_SETT_AMT	 	, " +
"TRAN_SUMM_CURRENCY	 , " +
"TRAN_SUMM_SETT_QTY	 	, " +
"TRAN_SUMM_TRADE_QTY  " +	
"FROM DB_IAW_DEV_STG.IAS.HOLDINGS);" 
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
 
$$;