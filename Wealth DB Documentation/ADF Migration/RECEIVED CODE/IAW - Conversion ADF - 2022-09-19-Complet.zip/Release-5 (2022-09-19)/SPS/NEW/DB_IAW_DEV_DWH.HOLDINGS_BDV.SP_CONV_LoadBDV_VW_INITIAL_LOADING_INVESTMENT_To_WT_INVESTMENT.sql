CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DWH.HOLDINGS_BDV.SP_CONV_LoadBDV_VW_INITIAL_LOADING_INVESTMENT_To_WT_INVESTMENT(ENV VARCHAR)
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS $$ 
var delete_query = "DELETE FROM DB_IAW_DEV_DWH.HOLDINGS_BDV.WT_INVESTMENT_INVESTIA_UNIVERIS WHERE 1=1";
var delete_query_ENV = delete_query.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement1 = snowflake.createStatement({
  sqlText: delete_query_ENV
});
var result1_scan = sql_statement1.execute(); 
INS_QUERY = "INSERT INTO DB_IAW_DEV_DWH.HOLDINGS_BDV.WT_INVESTMENT_INVESTIA_UNIVERIS(HK_HUB_CONTRACT, " +
"HK_HUB_INVESTMENT_PRODUCT_TYPE , " +
"HK_HUB_PARTY_ROLE_ADVISOR	,  " +
"HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER	, " + 
"HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES	 , " +
"MD_SEQ	, " +
"MD_START_DT	, " +
"MD_EXTRACT_DT	, " +
"MD_SOURCE	, " +
"MD_SRC_SYSTEM	, " +
"CONTRACT_ID	, " +
"INVESTMENT_PRODUCT_ID	, " +
"MASTER_CODE	, " +
"RR_CD	, " +
" CLIENT_ID	, " +
"PLN_MNEM	, " +
"COMMISSIONPCT	, " +
"ISSUER_COMPANY_NAME	, " +
" ADMINISTRATORY_TYPE, " +
"BAL_DATE	, " +
"MV	, " +
"AUA	, " +
"UNIVERIS_PLAN_ID	, " +
"IVD_LOAD_FLAG	,  " +
"WF_IND	 ) " +
"(select " +
"HK_HUB_CONTRACT, " +
"HK_HUB_INVESTMENT_PRODUCT_TYPE , " +
"HK_HUB_PARTY_ROLE_ADVISOR	,  " +
"HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER	,  " +
"HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES	 , " +
"MD_SEQ	, " +
"MD_START_DT	, " +
"MD_EXTRACT_DT	, " +
"MD_SOURCE	, " +
"MD_SRC_SYSTEM	, " +
"CONTRACT_ID	, " +
"INVESTMENT_PRODUCT_ID	, " +
"MASTER_CODE	, " +
"RR_CD	, " +
"UNIVERIS_CLIENT_ID 	, " +
"PLN_MNEM	, " +
"COMMISSIONPCT	, " +
"ISSUER_COMPANY_NAME	, " +
"ADMINISTRATOR_TYPE, " +
"BAL_DATE	, " +
"MV	, " +
"AUA	, " +
"UNIVERIS_PLAN_ID	, " +
"IVD_LOAD_FLAG	, " +
"WF_IND	 " +
"FROM DB_IAW_DEV_DWH.HOLDINGS_BDV.VW_INITIAL_LOADING_INVESTMENT_INVESTIA_UNIVERIS);" 
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
 var update_query = "UPDATE DB_IAW_DEV_DWH.HOLDINGS_BDV.WT_INVESTMENT_INVESTIA_UNIVERIS "+
"SET "+
"HK_LINK = SHA1(UPPER(CONCAT( "+
"      COALESCE(TRIM(MD_SEQ), '#NULL#'), '|' "+
"    , COALESCE(TRIM(MD_SOURCE), '#NULL#'), '|' "+
"    , COALESCE(TRIM(MD_SRC_SYSTEM), '#NULL#'), '|' "+
"    , COALESCE(TRIM(MD_EXTRACT_DT), '#NULL#'), '|' "+
"    , '#NULL#', '|'   "+
"    , COALESCE(TRIM(MASTER_CODE), '#NULL#'), '|' "+
"    , COALESCE(TRIM(INVESTMENT_PRODUCT_ID), '#NULL#'), '|' "+
"    , COALESCE(TRIM(CLIENT_ID), '#NULL#'), '|' "+
"    , COALESCE(TRIM(PLN_MNEM), '#NULL#'), '|' "+
"    , '#NULL#', '|' "+
"    , '#NULL#', '|' "+
"    , '#NULL#', '|' "+
 "   , COALESCE(TRIM(UNIVERIS_PLAN_ID), '#NULL#')"+
 "   ))),"+
"HK_HUB_PARTY_ROLE_ADVISOR= COALESCE(HK_HUB_PARTY_ROLE_ADVISOR,'0'),"+
"HK_HUB_INVESTMENT_PRODUCT_TYPE= COALESCE(HK_HUB_INVESTMENT_PRODUCT_TYPE,'0'),"+
"HK_HUB_CONTRACT= COALESCE(HK_HUB_CONTRACT,'0'),"+
"HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER = COALESCE(HK_HUB_PARTY_ROLE_ACCOUNT_HOLDER,'0'),"+
"HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES = COALESCE(HK_HUB_INVESTMENT_SAVING_PROGRAM_TYPES,'0'),"+
"MD_CREATION_DT = SYSTIMESTAMP() "+
"Where 1=1";
var update_query_ENV = update_query.replaceAll("_DEV_","_" + ENV + "_");
var sql_statement3 = snowflake.createStatement({ 
  sqlText: update_query_ENV
});
 var result3_scan = sql_statement3.execute(); 
$$;