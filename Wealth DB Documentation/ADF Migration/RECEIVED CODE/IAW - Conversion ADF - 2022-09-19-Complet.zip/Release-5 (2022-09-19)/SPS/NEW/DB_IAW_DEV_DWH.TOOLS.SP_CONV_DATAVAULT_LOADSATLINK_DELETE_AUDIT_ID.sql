CREATE OR REPLACE PROCEDURE  DB_IAW_DEV_DWH.TOOLS.SP_CONV_DATAVAULT_LOADSATLINK_DELETE_AUDIT_ID(INSERT_COLS VARCHAR(16777216), SELECT_COLS VARCHAR(16777216), SRC_TBL VARCHAR(16777216), TGT_TBL VARCHAR(16777216), TRUNC_TBL VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
var INS_QUERY = "INSERT INTO "+ TGT_TBL + "(" + INSERT_COLS + ") SELECT " +  SELECT_COLS + " FROM " + SRC_TBL + " STG LEFT JOIN (SELECT * FROM  (SELECT *, ROW_NUMBER() OVER(PARTITION BY HK_LINK ORDER BY MD_START_DT DESC) RN FROM "  + TGT_TBL + "  SAT) SATLINK WHERE SATLINK.RN = 1) SAT ON SAT.HK_LINK = STG.HK_LINK WHERE SAT.HK_LINK  IS NULL AND SAT.MD_ACTIVE != ''D'' ;";
var TRUN_QUERY = "TRUNCATE TABLE " + TGT_TBL +";";

if (TRUNC_TBL == ''Y'')
    {
    var sql_statement = snowflake.createStatement(
          {
          sqlText: TRUN_QUERY
          }
       );
   var result_scan = sql_statement.execute();
	}
   var sql_statement = snowflake.createStatement(
          {
          sqlText: INS_QUERY
          }
       );
   var result_scan = sql_statement.execute();		
';