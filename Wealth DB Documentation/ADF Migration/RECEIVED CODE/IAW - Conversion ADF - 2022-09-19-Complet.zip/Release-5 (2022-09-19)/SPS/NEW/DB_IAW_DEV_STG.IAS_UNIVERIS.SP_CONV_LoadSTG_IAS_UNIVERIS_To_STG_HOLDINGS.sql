CREATE OR REPLACE PROCEDURE DB_IAW_DEV_STG.IAS_UNIVERIS.SP_CONV_LoadSTG_IAS_UNIVERIS_To_STG_HOLDINGS(ENV VARCHAR(1000), IO_PATH VARCHAR(1000))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
INS_PRE_DEL STRING;
INS_PRE_COPY STRING;
INS_UPDATE STRING;
BEGIN
INS_PRE_DEL := ''DELETE FROM DB_IAW_''||ENV||''_STG.IAS_UNIVERIS.HOLDINGS WHERE 1=1'';
INS_PRE_COPY := ''
COPY INTO DB_IAW_''||ENV||''_STG.IAS_UNIVERIS.HOLDINGS
 (
	  MD_START_DT
	, MD_SOURCE	
	, MD_SEQ
	, ACT_SYSID
	, IVD_SYSID
	, REP_SYSID
	, IVR_SYSID
	, PLN_SYSID
	, FISCAL_SYSID
	, BAL_DATE
	, MV
	, CURRENCY_CD
	, EXCH_DT
	, EXCH_RATE
	, AUA
	, PRICE
	, UNITS
	, BV
	, ACB
	, NI_T
	, NI_P
	, FREQ_CD
	, UNITS_TRD_DT
	, FISCAL_TD_UNITS
	, IVD_LOAD_FLAG
	, WF_IND	
	, MD_EXTRACT_DT
	, MD_SRC_SYSTEM
	
	)
FROM
	(
	SELECT
		TO_DATE(split_part(split_part(metadata$filename, ''''__'''', 2), ''''.'''', 0)),metadata$filename, metadata$file_row_number,
		t.$1, t.$2, t.$3, t.$4, t.$5, t.$6, t.$7, t.$8, t.$9, t.$10, t.$11, t.$12, t.$13, t.$14, t.$15, t.$16, t.$17, t.$18, t.$19, t.$20, t.$21, t.$22, t.$23, t.$24, t.$25
	FROM
		@DATALAKE.''||IO_PATH||'' t
	) pattern = ''''.*/HOLDINGS_.*csv'''' file_format =(format_name = DB_IAW_''||ENV||''_STG.IAS.PIPE_UTF16)
		'';
	
INS_UPDATE:=''UPDATE DB_IAW_''||ENV||''_STG.IAS_UNIVERIS.HOLDINGS
SET
	HK_LINK = SHA1(UPPER(CONCAT(
	  COALESCE(TRIM(MD_SEQ), ''''#NULL#''''), ''''|''''
	, COALESCE(TRIM(MD_SRC_SYSTEM), ''''#NULL#''''), ''''|''''
	, COALESCE(TRIM(MD_EXTRACT_DT), ''''#NULL#''''), ''''|''''
	, ''''#NULL#'''', ''''|''''
	, COALESCE(TRIM(IVD_SYSID), ''''#NULL#''''), ''''|''''
	, COALESCE(TRIM(PLN_SYSID), ''''#NULL#''''), ''''|''''
	, COALESCE(TRIM(IVR_SYSID), ''''#NULL#'''')
	))),
	HK_HUB_CONTRACT = DECODE(TRUE, PLN_SYSID IS NULL AND IVR_SYSID IS NULL ,''''0'''',SHA1(UPPER(CONCAT(COALESCE(TRIM(MD_SRC_SYSTEM), ''''#NULL#''''), ''''|'''' ,''''#NULL#'''',''''|'''', COALESCE(TRIM(PLN_SYSID), ''''#NULL#'''')	,''''|'''', COALESCE(TRIM(IVR_SYSID), ''''#NULL#''''))))),
	HK_HUB_INVESTMENT_PRODUCT_TYPE = DECODE(TRUE, IVD_SYSID IS NULL ,''''0'''',SHA1(UPPER(CONCAT(COALESCE(TRIM(MD_SRC_SYSTEM), ''''#NULL#''''), ''''|'''' , COALESCE(TRIM(IVD_SYSID), ''''#NULL#''''))))),
	MD_HASHDIFF=SHA1(CONCAT(
	  COALESCE(TO_VARCHAR(ACT_SYSID),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(REP_SYSID),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(FISCAL_SYSID),''''#NULL#''''), ''''|''''
	, COALESCE(BAL_DATE,''''#NULL#''''),''''|''''
	, COALESCE(TO_VARCHAR(MV),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(CURRENCY_CD),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(EXCH_DT),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(EXCH_RATE),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(AUA),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(PRICE),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(UNITS),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(BV),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(ACB),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(NI_T),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(NI_P),''''#NULL#''''), ''''|''''
	, COALESCE(FREQ_CD,''''#NULL#''''),''''|''''
	, COALESCE(TO_VARCHAR(UNITS_TRD_DT),''''#NULL#''''), ''''|''''
	, COALESCE(TO_VARCHAR(FISCAL_TD_UNITS),''''#NULL#''''), ''''|''''
	, COALESCE(IVD_LOAD_FLAG,''''#NULL#''''),''''|''''
	, COALESCE(TO_VARCHAR(WF_IND),''''#NULL#'''')
	)),	
	MD_CREATION_DT= SYSTIMESTAMP()
	Where 1=1
		'';
EXECUTE IMMEDIATE :INS_PRE_DEL;
EXECUTE IMMEDIATE :INS_PRE_COPY;
EXECUTE IMMEDIATE :INS_UPDATE;
END
';