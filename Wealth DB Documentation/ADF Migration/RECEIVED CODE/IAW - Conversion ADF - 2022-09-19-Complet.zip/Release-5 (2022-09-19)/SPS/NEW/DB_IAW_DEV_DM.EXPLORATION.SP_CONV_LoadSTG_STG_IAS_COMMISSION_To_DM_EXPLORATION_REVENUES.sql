CREATE OR REPLACE PROCEDURE DB_IAW_DEV_DM.EXPLORATION.SP_CONV_LoadSTG_STG_IAS_COMMISSION_To_DM_EXPLORATION_REVENUES(ENV VARCHAR)
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS $$ 
var delete_query = "DELETE FROM DB_IAW_DEV_DM.EXPLORATION.IAS_COMMISSION_REVENUES WHERE 1=1";
var delete_query_ENV = delete_query.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement1 = snowflake.createStatement({
  sqlText: delete_query_ENV
});
var result1_scan = sql_statement1.execute(); 
INS_QUERY = "INSERT INTO DB_IAW_DEV_DM.EXPLORATION.IAS_COMMISSION_REVENUES(HK_LINK , " +
"HK_HUB_CONTRACT	, " +
"HK_HUB_PARTY_ROLE_ADVISOR	, " +	
"MD_CREATION_DT	, " +
"MD_START_DT	, " +
"MD_SOURCE	, " +
"MD_SRC_SYSTEM	, " +
"MD_EXTRACT_DT	, " +	
"REPID	, " +
"ADVISOR_ID	, " +	
"PROGRAM_TYPE	, " +
"ACCOUNTID	, " +
"PROCESSDATE	, " +	
"SOURCECODE		, " +
"QUANTITY	, " +	
"TRANSTYPE	, " +	
"REVENUE	, " +	
"COMMISSION		, " +
"NETCOMMISSION	, " +	
"TRANSFEE) " +
"(select " +
"HK_LINK , " +
"HK_HUB_CONTRACT	, " +
"HK_HUB_PARTY_ROLE_ADVISOR	, " +	
"MD_CREATION_DT	, " +
"MD_START_DT	, " +
"MD_SOURCE	, " +
"MD_SRC_SYSTEM	, " +
"MD_EXTRACT_DT	, " +	
"REPID	, " +
"ADVISOR_ID	, " +	
"PROGRAM_TYPE	, " +
"ACCOUNTID	, " +
"PROCESSDATE	, " +	
"SOURCECODE		, " +
"QUANTITY	, " +	
"TRANSTYPE	, " +	
"REVENUE	, " +	
"COMMISSION		, " +
"NETCOMMISSION	, " +	
"TRANSFEE " +
"FROM DB_IAW_DEV_STG.IAS_COMMISSION.REVENUES);" 
var INS_QUERY_ENV = INS_QUERY.replaceAll("_DEV_","_"+ ENV + "_");
var sql_statement2 = snowflake.createStatement({
  sqlText: INS_QUERY_ENV
});
 var result2_scan = sql_statement2.execute(); 
 
$$;